#!/usr/bin/env python3
"""Vòng kiểm KÍN của Liquify 3D trên ảnh THẬT (R37) — cần mạng chỉ để cài công cụ, KHÔNG nằm trong static_check / CI.

Ý tưởng: không tin hằng số K_* hiệu chỉnh bằng khuôn mặt tổng hợp. Với mỗi ảnh thật:
  1. MediaPipe FaceMesh (legacy, refine_landmarks=True = cùng họ mô hình 478 điểm của face_landmarker.task trên Android) -> lưới 3D;
  2. `face_liquify3d.segments` sinh đoạn đẩy -> `liquify_image` (bản port CHÍNH XÁC của ToneOps.liquify) warp ảnh;
  3. nhận diện LẠI trên ảnh đã warp (mô hình thật tự đo xem khuôn mặt đổi ra sao) -> so các số đo trong khung đầu 3D.
Chuẩn bị (một lần):
  python3 -m venv /tmp/mpv && /tmp/mpv/bin/pip install --no-deps mediapipe==0.10.21 && /tmp/mpv/bin/pip install "numpy<2" "protobuf<5" absl-py attrs flatbuffers opencv-python-headless matplotlib scikit-image
  (wheel 0.10.21 là bản cuối còn `mp.solutions.face_mesh`; bản mới chỉ có Tasks API cần tệp .task tải từ storage.googleapis.com — bị chặn ở sandbox)
Chạy:  /tmp/mpv/bin/python tools/real_face_check.py ẢNH1.jpg ẢNH2.png ... [--out DIR]
  (R37b) đặt FACE_LANDMARKER_TASK=/đường/dẫn/face_landmarker.task để dùng model THẬT qua Tasks API — tệp lấy từ github.com/Qaanaaq/Face_Landmark_Link (Face_Landmarker/face_landmarker.task)
  hoặc github.com/nlml/deconstruct-mediapipe; kiểm SHA-256 = 64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff (bản float16/1 chính thức)
"""
import os
import sys
import numpy as np
import cv2
import mediapipe as mp

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "verify_ports"))
import face_liquify3d as F  # noqa: E402

FM = getattr(mp, "solutions", None) and mp.solutions.face_mesh
TASK_PATH = os.environ.get("FACE_LANDMARKER_TASK", "")      # R37b: đường dẫn face_landmarker.task THẬT (SHA-256 64184e22…bc9ff) -> dùng Tasks API như Android
_TASK = None


def _task():
    global _TASK
    if _TASK is None:
        from mediapipe.tasks import python as mpp
        from mediapipe.tasks.python import vision
        _TASK = vision.FaceLandmarker.create_from_options(vision.FaceLandmarkerOptions(
            base_options=mpp.BaseOptions(model_asset_path=TASK_PATH), running_mode=vision.RunningMode.IMAGE, num_faces=6,
            min_face_detection_confidence=0.3, min_face_presence_confidence=0.3))
    return _TASK


def detect(rgb, ref_xy=None):
    h, w = rgb.shape[:2]
    if TASK_PATH:
        r = _task().detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
        faces = [np.array([[p.x, p.y, p.z] for p in f], np.float64) for f in r.face_landmarks]
        if not faces:
            return []
        if ref_xy is not None:
            faces.sort(key=lambda a: np.hypot(a[1, 0] * w - ref_xy[0], a[1, 1] * h - ref_xy[1]))
        return faces
    with FM.FaceMesh(static_image_mode=True, max_num_faces=6, refine_landmarks=True, min_detection_confidence=0.3) as m:
        r = m.process(rgb)
    if not r.multi_face_landmarks:
        return []
    out = []
    for f in r.multi_face_landmarks:
        out.append(np.array([[p.x, p.y, p.z] for p in f.landmark], np.float64))
    if ref_xy is not None:
        out.sort(key=lambda a: np.hypot(a[1, 0] * w - ref_xy[0], a[1, 1] * h - ref_xy[1]))
    return out


CASES = [
    ("ĐỐI CHỨNG dịch ảnh 1px", None),
    ("thon hàm cả hai bên 1.0", F.Params(slim=1.0)),
    ("thon hàm chỉ bên A 1.0", F.Params(slimA=1.0)),
    ("thon hàm chỉ bên B 1.0", F.Params(slimB=1.0)),
    ("to mắt 1.0", F.Params(eyes=1.0)),
    ("to mắt chỉ bên A 1.0", F.Params(eyesA=1.0)),
    ("thu cánh mũi 1.0", F.Params(nose=1.0)),
    ("nâng khóe môi 1.0", F.Params(smile=1.0)),
    ("rút ngắn cằm 1.0", F.Params(chin=1.0)),
    ("cân bằng 1.0", F.Params(balance=1.0)),
    ("TẤT CẢ 0.5", F.Params(slim=.5, eyes=.5, nose=.5, smile=.5, chin=.5, balance=.5)),
]
KEYS = ["jaw", "jawA", "jawB", "eyeA", "eyeB", "nose", "mouth", "chin", "asym_eye", "asym_mouth"]


def rel(a, b):
    return (b - a) / abs(a) * 100 if abs(a) > 1e-9 else float("nan")


def main(argv):
    out = "/tmp/liquify3d_real"
    if "--out" in argv:
        i = argv.index("--out"); out = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
    os.makedirs(out, exist_ok=True)
    allrows = []
    minjac = []
    for path in argv:
        bgr = cv2.imread(path)
        if bgr is None:
            continue
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        faces = detect(rgb)
        name = os.path.splitext(os.path.basename(path))[0][-22:]
        for fi, lm in enumerate(faces):
            m0 = F.measures(lm, w, h)
            if m0 is None or m0["W3"] < 60:
                continue
            fr = F.frame(lm, w, h)
            print("\n== %s face%d  %dx%d  W3=%.0fpx  yaw=%.1f°" % (name, fi, w, h, m0["W3"], fr.yaw))
            ref = (fr.P[1][0], fr.P[1][1])
            for cname, par in CASES:
                if par is None:      # đối chứng: dịch cả ảnh (1, 0.5) px -> đo nhiễu nhận diện thuần túy
                    M = np.float32([[1, 0, 1.0], [0, 1, 0.5]])
                    warped = cv2.warpAffine(rgb, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
                else:
                    segs = F.segments(lm, w, h, par)
                    arg = F.encode(segs, w, h)
                    warped = F.liquify_image(rgb, arg) if arg else rgb
                    if arg:
                        mj, mx = F.min_jacobian(w, h, arg)
                        minjac.append((cname, mj))
                f2 = detect(warped, ref)
                if not f2:
                    print("   %-26s không nhận diện lại được" % cname)
                    continue
                m1 = F.measures(f2[0], w, h)
                d = {k: (m1[k] - m0[k]) for k in KEYS}
                rr = {k: rel(m0[k], m1[k]) for k in KEYS}
                allrows.append((name, fi, cname, d, rr, m0))
                if cname.startswith(("thon hàm cả", "TẤT")):
                    x0 = int(max(0, fr.P[:, 0].min() - 40)); x1 = int(min(w, fr.P[:, 0].max() + 40))
                    y0 = int(max(0, fr.P[:, 1].min() - 40)); y1 = int(min(h, fr.P[:, 1].max() + 40))
                    pair = np.hstack([bgr[y0:y1, x0:x1], cv2.cvtColor(warped, cv2.COLOR_RGB2BGR)[y0:y1, x0:x1]])
                    cv2.imwrite(os.path.join(out, "%s_f%d_%s.jpg" % (name, fi, "all" if cname.startswith("TẤT") else "slim")), pair)
                print("   %-26s jaw %+6.1f%%  jawA %+6.1f%%  jawB %+6.1f%%  eyeA %+6.1f%%  eyeB %+6.1f%%  nose %+6.1f%%  mouthΔ %+.4f  chinΔ %+.4f  |asymEye| %.4f→%.4f  |asymMouth| %.4f→%.4f" % (
                    cname, rr["jaw"], rr["jawA"], rr["jawB"], rr["eyeA"], rr["eyeB"], rr["nose"], d["mouth"], d["chin"],
                    abs(m0["asym_eye"]), abs(m1["asym_eye"]), abs(m0["asym_mouth"]), abs(m1["asym_mouth"])))
    # tóm tắt trung bình theo ca
    print("\n===== TRUNG BÌNH theo ca (%d ảnh-mặt) =====" % len({(r[0], r[1]) for r in allrows}))
    for cname, _ in CASES:
        rs = [r for r in allrows if r[2] == cname]
        if not rs:
            continue
        mean = lambda k: float(np.nanmean([r[4][k] for r in rs]))
        dmean = lambda k: float(np.nanmean([r[3][k] for r in rs]))
        print("%-26s n=%d  jaw %+6.1f%%  jawA %+6.1f%%  jawB %+6.1f%%  eyeA %+6.1f%%  eyeB %+6.1f%%  nose %+6.1f%%  mouthΔ %+.4f  chinΔ %+.4f" % (
            cname, len(rs), mean("jaw"), mean("jawA"), mean("jawB"), mean("eyeA"), mean("eyeB"), mean("nose"), dmean("mouth"), dmean("chin")))
    print("\n===== định thức Jacobian NHỎ NHẤT (cần > 0,35 để không gấp nếp / nén quá tay) =====")
    for cname, _ in CASES:
        v = [m for c, m in minjac if c == cname]
        if v:
            print("%-26s min=%.3f  trung bình=%.3f" % (cname, min(v), sum(v) / len(v)))
    np.save(os.path.join(out, "rows.npy"), np.array([(r[0], r[1], r[2]) for r in allrows], dtype=object), allow_pickle=True)


if __name__ == "__main__":
    main(sys.argv[1:])
