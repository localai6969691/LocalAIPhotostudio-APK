#!/usr/bin/env python3
"""R37b: thử nghiệm ĐỐI CHỨNG cho "Cân bằng hai bên" của Liquify 3D trên mặt THẬT với model `face_landmarker.task` thật.
Độ lệch tự nhiên của khuôn mặt thấp hơn nhiễu nhận diện nên không đo trực tiếp được; thay vào đó TẠO SẴN một độ lệch đã biết (hạ mắt bên B 3% / khóe môi B 3,5% bề rộng
thái dương bằng Liquify), nhận diện lại, áp balance = 1,0, nhận diện lại lần nữa và xem độ lệch giảm bao nhiêu.
Kết quả R37b (12 mặt, yaw < 22°): mắt giảm 49% phần lệch thêm vào, cải thiện 11/12 mặt; miệng giảm 52%, cải thiện 11/12 mặt.
Chạy:  FACE_LANDMARKER_TASK=/tmp/real/face_landmarker.task /tmp/mpv/bin/python tools/real_balance_check.py   (sửa danh sách ảnh `imgs` bên dưới theo máy bạn)
"""
import sys, os, numpy as np, cv2, glob, math
os.environ.setdefault('FACE_LANDMARKER_TASK','/tmp/real/face_landmarker.task')
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE); sys.path.insert(0,os.path.join(HERE,'verify_ports'))
import real_face_check as R, face_liquify3d as F
imgs=['/tmp/faces/Tom_Cruise_avp_2014_4.jpg','/tmp/faces/ageitgey_face_recognition_master_examples_obama.jpg','/tmp/faces/ageitgey_face_recognition_master_examples_biden.jpg','/tmp/faces/ageitgey_face_recognition_master_examples_obama2.jpg','/tmp/faces/ageitgey_face_recognition_master_examples_alex-lacamoire.png','/tmp/faces/ageitgey_face_recognition_master_examples_lin-manuel-miranda.png','/tmp/faces/cleardusk_3DDFA_V2_master_examples_inputs_JianzhuGuo.jpg','/tmp/faces/yfeng95_PRNet_master_TestImages_0.jpg','/tmp/faces/deepinsight_insightface_python-package_insightface_data_images_t1.jpg','/tmp/faces/bald_guys.jpg','/tmp/faces/1adrianb_face-alignment_master_test_assets_aflw-test.jpg']
imgs=[p for p in imgs if os.path.exists(p)]
def induce(lm,w,h,which,amt):
    fr=F.frame(lm,w,h); items=[]
    if which=='eye':
        for k in range(0,16,2):
            i=F.EYE_B[k]; items.append((fr.P[i][0],fr.P[i][1],amt*fr.W3*fr.v[0],amt*fr.W3*fr.v[1],0.35*fr.fwImg))
    else:
        for i in (F.MOUTH_B,):
            items.append((fr.P[i][0],fr.P[i][1],amt*fr.W3*fr.v[0],amt*fr.W3*fr.v[1],0.17*fr.fwImg))
    return F.encode([F.Seg if False else s for s in F.normalize_group(items)],w,h)
def asym(lm,w,h,key):
    m=F.measures(lm,w,h); return m[key] if m else None
res={'eye':[], 'mouth':[]}
for p in imgs:
    rgb=cv2.cvtColor(cv2.imread(p),cv2.COLOR_BGR2RGB); h,w=rgb.shape[:2]
    for lm in R.detect(rgb):
        fr=F.frame(lm,w,h)
        if fr is None or fr.W3<100 or abs(fr.yaw)>22: continue
        ref=(fr.P[1][0],fr.P[1][1])
        for which,key,amt in (('eye','asym_eye',0.030),('mouth','asym_mouth',0.035)):
            base=asym(lm,w,h,key)
            arg=induce(lm,w,h,which,amt); wr=F.liquify_image(rgb,arg)
            f2=R.detect(wr,ref)
            if not f2: continue
            ind=asym(f2[0],w,h,key)
            bal=F.encode(F.segments(f2[0],w,h,F.Params(balance=1.0)),w,h)
            if not bal: continue
            f3=R.detect(F.liquify_image(wr,bal),ref)
            if not f3: continue
            after=asym(f3[0],w,h,key)
            res[which].append((base,ind,after)); 
for k,v in res.items():
    a=np.array(v)
    if len(a)==0: continue
    print("%s: n=%d | |lệch| gốc %.4f → sau khi tạo lệch %.4f → sau CÂN BẰNG %.4f | giảm được %.0f%% phần lệch tạo thêm; cải thiện ở %d/%d mặt"%(k,len(a),np.mean(abs(a[:,0])),np.mean(abs(a[:,1])),np.mean(abs(a[:,2])),100*(np.mean(abs(a[:,1]))-np.mean(abs(a[:,2])))/(np.mean(abs(a[:,1]))-np.mean(abs(a[:,0]))+1e-9),int(sum(abs(x[2])<abs(x[1]) for x in a)),len(a)))
