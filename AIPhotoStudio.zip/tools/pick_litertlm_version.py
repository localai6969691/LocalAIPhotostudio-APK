#!/usr/bin/env python3
"""R49 - chọn phiên bản com.google.ai.edge.litertlm:litertlm-android mà D8/R8 của AGP đang dùng ĐỌC ĐƯỢC.

Vì sao: Build APK #39 (use_all) đỏ ở mergeExtDexDebug: litertlm-android-0.20.0 (ra 23/11/2026) chứa lớp bytecode Java 25 (class file major 69),
còn D8 của AGP 8.5.2 (R8 8.5.35) báo "Unsupported class file major version 69". `latest.release` luôn lấy bản mới nhất nên sẽ đỏ lại ở mọi bản sau nếu
Google lại dựng bằng JDK mới. Script này tải maven-metadata.xml từ Google Maven, duyệt phiên bản ổn định từ MỚI đến CŨ, tải AAR, đọc số major của MỌI lớp
trong các tệp .jar bên trong và chọn bản mới nhất có major <= LITERTLM_MAX_CLASS_MAJOR (mặc định 65 = Java 21).
Chỉ xét khoảng 0.18.0 <= v < 0.21.0 — khoảng đã đối chiếu với mã nguồn Kotlin thật của thư viện (tools/jvm_check/real_litertlm). Không tải được hoặc
không có bản nào đạt => dùng LITERTLM_FALLBACK (mặc định 0.18.1, bản Google AI Edge Gallery đang dùng) kèm cảnh báo; luôn thoát 0.
Kết quả: in `PICK=<phiên bản>`; trong GitHub Actions ghi ORG_GRADLE_PROJECT_litertlmVersion vào GITHUB_ENV (Gradle đọc thành -PlitertlmVersion; cờ -P trên dòng lệnh vẫn thắng).
Biến môi trường: LITERTLM_MAVEN_BASE (mặc định dl.google.com/dl/android/maven2; chấp nhận file://... để thử), LITERTLM_MAX_CLASS_MAJOR, LITERTLM_FALLBACK."""
import io, os, re, struct, sys, urllib.request, xml.etree.ElementTree as ET, zipfile

BASE = os.environ.get("LITERTLM_MAVEN_BASE", "https://dl.google.com/dl/android/maven2").rstrip("/")
ART = "com/google/ai/edge/litertlm/litertlm-android"
MAX_MAJOR = int(os.environ.get("LITERTLM_MAX_CLASS_MAJOR", "65"))
FALLBACK = os.environ.get("LITERTLM_FALLBACK", "0.18.1")
LOW, HIGH_EXCL, MAX_TRIES = (0, 18, 0), (0, 21, 0), 6


def fetch(url):
    with urllib.request.urlopen(url, timeout=90) as r:
        return r.read()


def vkey(v):
    return tuple(int(x) for x in v.split("."))


def candidates():
    root = ET.fromstring(fetch(f"{BASE}/{ART}/maven-metadata.xml"))
    vs = [e.text.strip() for e in root.iter("version") if e.text and re.fullmatch(r"\d+\.\d+\.\d+", e.text.strip())]
    return sorted((v for v in vs if LOW <= vkey(v) < HIGH_EXCL), key=vkey, reverse=True)


def max_major(aar):
    """Số major lớn nhất của mọi lớp trong các .jar bên trong AAR (bỏ META-INF/versions/ và module-info)."""
    top, n = 0, 0
    outer = zipfile.ZipFile(io.BytesIO(aar))
    for name in outer.namelist():
        if not name.endswith(".jar"):
            continue
        inner = zipfile.ZipFile(io.BytesIO(outer.read(name)))
        for cn in inner.namelist():
            if not cn.endswith(".class") or cn.startswith("META-INF/versions/") or cn.endswith("module-info.class"):
                continue
            head = inner.read(cn)[:8]
            if len(head) == 8 and head[:4] == b"\xca\xfe\xba\xbe":
                top = max(top, struct.unpack(">H", head[6:8])[0]); n += 1
    return top, n


def main():
    rows, pick = [], None
    try:
        vs = candidates()
        print(f"Phiên bản ổn định trong khoảng [0.18.0, 0.21.0): {', '.join(vs) or '(không có)'}")
        for v in vs[:MAX_TRIES]:
            try:
                top, n = max_major(fetch(f"{BASE}/{ART}/{v}/litertlm-android-{v}.aar"))
            except Exception as e:  # tải/đọc lỗi một bản => thử bản kế
                rows.append((v, "?", f"không đọc được AAR: {e}")); print(f"  {v}: không đọc được AAR ({e})"); continue
            ok = 0 < top <= MAX_MAJOR
            rows.append((v, top, "ĐẠT" if ok else f"quá mới cho D8 (> {MAX_MAJOR})"))
            print(f"  {v}: {n} lớp, major lớn nhất {top} -> {'CHỌN' if ok else 'bỏ'}")
            if ok:
                pick = v; break
    except Exception as e:
        print(f"::warning title=LiteRT-LM::không lấy được danh sách phiên bản từ Google Maven ({e}) - dùng {FALLBACK}")
    if pick is None:
        pick = FALLBACK
        print(f"::warning title=LiteRT-LM::không tìm được bản có major <= {MAX_MAJOR}; dùng bản dự phòng {pick} (nếu D8 vẫn báo 'Unsupported class file major version', hạ LITERTLM_MAX_CLASS_MAJOR hoặc nâng AGP)")
    print(f"PICK={pick}")
    if os.environ.get("GITHUB_ENV"):
        open(os.environ["GITHUB_ENV"], "a", encoding="utf-8").write(f"ORG_GRADLE_PROJECT_litertlmVersion={pick}\n")
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(f"### LiteRT-LM: chọn **{pick}** (D8 đọc được lớp có major <= {MAX_MAJOR})\n\n| phiên bản | major lớn nhất | kết quả |\n|---|---|---|\n")
            for v, t, r in rows:
                f.write(f"| {v} | {t} | {r} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
