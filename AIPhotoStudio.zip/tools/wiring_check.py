#!/usr/bin/env python3
"""Rà soát "chưa có giao diện / chưa nối dây" bằng phân tích tĩnh (không cần biên dịch) — R34.
Quét MỌI source set sản phẩm (main + billing*/integrity*/litertlm*), không tính test.
  A  hàm công khai của MainViewModel mà UI không gọi (theo tên)
  B  trường UiState mà UI không đọc
  C  mục enum không nơi nào dùng
  D  @Composable không ai gọi
  E  hàm VM không đến được từ UI / khối khởi tạo (đồ thị gọi)
  F  lớp / đối tượng không đến được từ UI → VM
  G  hàm (ngoài ui/) không ai gọi trong mã sản phẩm
Mục nằm trong ALLOW là ngoại lệ ĐÃ ĐƯỢC XEM XÉT (kèm lý do) — thêm mục mới phải ghi lý do.
Dùng: python3 tools/wiring_check.py   (thoát 1 nếu còn mục chưa được xem xét)"""
import re, os, sys, glob
PROJ = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SRC = os.path.join(PROJ, "app", "src")
ALLOW = {
    "A": {"onCleared": "vòng đời ViewModel (Android gọi)"},
    "B": {"cloneHeal": "chỉ VM đọc (nhãn tiến trình + tên lớp); UI chọn Clone/Heal bằng 2 nút gọi startClone(true/false)",
          "scrubType": "chỉ VM đọc; UI hiện tên tham số đang chỉnh qua `status` (scrubCycle)",
          "plan": "gói đăng ký (free/pro) — UI đọc qua `isPro`, không đọc trực tiếp"},
    "E": {"onCleared": "vòng đời ViewModel (Android gọi)"},
    "G": {"isRunning": "API truy vấn tiến trình sd-server; UI hiện nút 'Giải phóng RAM' luôn nên chưa cần"},
}

def strip(s):
    """Bóc chú thích (kể cả lồng nhau) và nội dung chuỗi bằng máy trạng thái — an toàn với "image/*", "https://"…"""
    out = []; i = 0; n = len(s)
    while i < n:
        c = s[i]; d = s[i:i+2]
        if d == "//":
            while i < n and s[i] != "\n": i += 1
        elif d == "/*":
            depth = 1; i += 2
            while i < n and depth:
                if s[i:i+2] == "/*": depth += 1; i += 2
                elif s[i:i+2] == "*/": depth -= 1; i += 2
                else: i += 1
        elif s[i:i+3] == '"""':
            j = s.find('"""', i + 3); i = n if j < 0 else j + 3; out.append('""')
        elif c == '"':
            i += 1; buf = []
            while i < n and s[i] != '"':
                if s[i] == "\\": i += 2; continue
                if s[i:i+2] == "${":
                    depth = 1; j = i + 2
                    while j < n and depth:
                        depth += (s[j] == "{") - (s[j] == "}"); j += 1
                    buf.append(" " + s[i+2:j-1] + " "); i = j; continue
                i += 1
            i += 1; out.append('"' + "".join(buf) + '"')
        elif c == "'" and i + 2 < n and (s[i+2] == "'" or (s[i+1] == "\\" and s[i+3:i+4] == "'")):
            i += 3 if s[i+2] == "'" else 4; out.append("'c'")
        else:
            out.append(c); i += 1
    return "".join(out)

def _balanced(t, k, o, c):
    d = 1; j = k
    while j < len(t) and d:
        d += (t[j] == o) - (t[j] == c); j += 1
    return j

def analyze():
    prod = {}
    for p in glob.glob(SRC + "/*/java/**/*.kt", recursive=True):
        if os.sep + "test" + os.sep in p.replace(SRC, "", 1): continue
        prod[p] = strip(open(p, encoding="utf-8").read())
    rel = lambda p: os.path.relpath(p, SRC)
    VM = [p for p in prod if p.endswith("MainViewModel.kt")][0]
    ui = [p for p in prod if (os.sep + "ui" + os.sep) in p or p.endswith("MainActivity.kt")]
    ui_code = "\n".join(prod[p] for p in ui); vm = prod[VM]
    R = lambda n, t: len(re.findall(r"(?<![\w])" + re.escape(n) + r"(?![\w])", t))
    ident = lambda t: set(re.findall(r"[A-Za-z_]\w*", t))
    res = {k: [] for k in "ABCDEFG"}
    # A
    pub = sorted(set(m.group(2) for m in re.finditer(r"^    (?:(private|internal|protected)\s+)?(?:override\s+)?(?:suspend\s+)?fun\s+(\w+)\s*\(", vm, flags=re.M) if m.group(1) not in ("private", "protected")))
    res["A"] = [n for n in pub if R(n, ui_code) == 0]
    # B
    k = vm.index("data class UiState(") + len("data class UiState(")
    fields = re.findall(r"(?:^|\n)\s*val\s+(\w+)\s*:", vm[k:_balanced(vm, k, "(", ")") - 1])
    res["B"] = [f for f in fields if R(f, ui_code) == 0]
    # C
    for p, t in prod.items():
        for em in re.finditer(r"enum\s+class\s+(\w+)\s*(?:\([^)]*\))?\s*\{", t):
            ename = em.group(1); body = t[em.end():_balanced(t, em.end(), "{", "}") - 1].split(";")[0]
            for e in sorted(set(re.findall(r"(?:^|[,\s])([A-Z][A-Z0-9_]*)(?=\s*(?:\(|,|$|\n|\{))", body))):
                tot = sum(len(re.findall(r"\b" + ename + r"\." + e + r"\b", tt)) for tt in prod.values())
                bare = sum(R(e, tt) for tt in prod.values())
                if tot == 0 and bare <= 1: res["C"].append(ename + "." + e)
    # D
    for p in ui:
        for mm in re.finditer(r"@Composable\s+(?:private\s+|internal\s+)?fun\s+(\w+)\s*\(", prod[p]):
            if sum(R(mm.group(1), tt) for tt in prod.values()) - 1 <= 0: res["D"].append(mm.group(1))
    # E, F — đồ thị gọi
    funcs = {}; spans = []
    for m in re.finditer(r"^    (?:(?:private|internal|protected|public|override|suspend|inline)\s+)*fun\s+(?:<[^>]+>\s*)?(\w+)\s*\(", vm, flags=re.M):
        i = vm.find("{", m.end())
        if i < 0: continue
        e = _balanced(vm, i + 1, "{", "}")
        funcs.setdefault(m.group(1), []).append(vm[m.start():e]); spans.append((m.start(), e))
    rest = []; last = 0
    for s, e in sorted(spans):
        rest.append(vm[last:s]); last = max(last, e)
    rest.append(vm[last:]); rest = "\n".join(rest)
    ui_ids = ident(ui_code)
    reached = {f for f in funcs if f in ui_ids or f in ident(rest)}; q = list(reached)
    while q:
        f = q.pop(); ids = set()
        for b in funcs[f]: ids |= ident(b)
        for g in funcs:
            if g in ids and g not in reached: reached.add(g); q.append(g)
    res["E"] = sorted(set(funcs) - reached)
    decl = {}
    for p, t in prod.items():
        for m in re.finditer(r"^(?:internal\s+)?(?:data\s+|enum\s+|sealed\s+|abstract\s+|open\s+)?(?:class|object|interface)\s+(\w+)", t, flags=re.M):
            decl.setdefault(m.group(1), []).append(p)
    vm_ids = set(ui_ids) | ident(rest)
    for f in reached:
        for b in funcs[f]: vm_ids |= ident(b)
    reach = {n for n in decl if n in vm_ids}; q = list(reach)
    while q:
        n = q.pop()
        for p in decl[n]:
            for m in ident(prod[p]):
                if m in decl and m not in reach: reach.add(m); q.append(m)
    res["F"] = sorted(n for n in decl if n not in reach and n != "MainViewModel" and not n.endswith("Activity"))
    # G
    skip = {"main", "onCleared", "onCreate", "toString", "equals", "hashCode", "invoke", "get", "set", "compareTo", "iterator"}
    for p, t in prod.items():
        if p in ui: continue
        for m in re.finditer(r"^\s*(?:(?:private|internal|protected|override|open|inline|operator|suspend|tailrec)\s+)*fun\s+(?:<[^>]+>\s*)?(?:[\w.<>?]+\.)?(\w+)\s*\(", t, flags=re.M):
            n = m.group(1)
            if "override" in m.group(0) or n in skip: continue
            if sum(R(n, tt) for tt in prod.values()) - 1 <= 0: res["G"].append(rel(p) + ":" + n)
    for key in res:  # trừ ngoại lệ đã xem xét
        res[key] = [x for x in res[key] if x not in ALLOW.get(key, {}) and x.split(":")[-1] not in ALLOW.get(key, {})]
    meta = dict(vm_pub=len(pub), fields=len(fields), funcs=len(funcs), reached=len(reached), classes=len(decl))
    return res, meta

TITLES = {"A": "hàm công khai của MainViewModel không được UI gọi", "B": "trường UiState không UI nào đọc",
          "C": "mục enum không nơi nào dùng", "D": "@Composable không ai gọi",
          "E": "hàm VM không đến được từ UI / khởi tạo", "F": "lớp/đối tượng không đến được từ UI→VM",
          "G": "hàm không ai gọi trong mã sản phẩm"}

if __name__ == "__main__":
    res, meta = analyze(); bad = 0
    print(f"Quét: {meta['vm_pub']} hàm VM công khai, {meta['fields']} trường UiState, {meta['reached']}/{meta['funcs']} hàm VM đến được, {meta['classes']} lớp/đối tượng")
    for k in "ABCDEFG":
        print(f"[{k}] {TITLES[k]}: {len(res[k])}")
        for x in res[k]: print("     ", x)
        bad += len(res[k])
    print("Ngoại lệ đã xem xét:", {k: sorted(v) for k, v in ALLOW.items()})
    sys.exit(1 if bad else 0)
