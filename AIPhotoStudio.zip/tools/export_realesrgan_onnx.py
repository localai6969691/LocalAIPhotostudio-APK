#!/usr/bin/env python3
"""R38 - xuất Real-ESRGAN-General-x4v3 (BSD-3, ~1,2M tham số) sang ONNX KHÔNG cần PyTorch.

Vì sao: bản ONNX dựng sẵn chỉ có trên HuggingFace / Qualcomm AI Hub (bị chặn ở sandbox) và PyTorch rất nặng. Mạng này (SRVGGNetCompact) chỉ là chuỗi Conv3x3 + PReLU + pixel-shuffle + cộng
ảnh phóng nearest, nên có thể dựng thẳng đồ thị ONNX từ trọng số. Đọc `.pth` (zip + pickle) bằng bộ giải pickle riêng (không import torch).
Kiến trúc (basicsr SRVGGNetCompact: num_feat=64, num_conv=32, upscale=4, act=prelu):
  body[0]=Conv(3→64) body[1]=PReLU(64) rồi 32 × [Conv(64→64) PReLU(64)] rồi Conv(64→48);  out = pixel_shuffle(body(x), 4) + nearest_x4(x)
Hợp đồng với OnnxUpscaler.kt: input float32 NCHW [1,3,128,128] trong [0,1], output [1,3,512,512]; ô chồng viền 10 px do Kotlin lo.
Chạy:  python3 tools/export_realesrgan_onnx.py realesr-general-x4v3.pth out.onnx [tile=128]
Tải trọng số: https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth   (cần: pip install onnx numpy)"""
import collections
import pickle
import sys
import zipfile

import numpy as np
import onnx
from onnx import TensorProto, helper, numpy_helper


class _Storage:
    def __init__(self, dtype, data):
        self.dtype, self.data = dtype, data


_DT = {"FloatStorage": np.float32, "HalfStorage": np.float16, "DoubleStorage": np.float64, "LongStorage": np.int64}


def _rebuild(storage, offset, size, stride, *_):
    arr = np.frombuffer(storage.data, dtype=storage.dtype)
    n = int(np.prod(size)) if len(size) else 1
    out = np.lib.stride_tricks.as_strided(arr[offset:], shape=tuple(size), strides=tuple(s * arr.itemsize for s in stride)) if len(size) else arr[offset:offset + 1]
    return np.array(out)


def load_pth(path):
    z = zipfile.ZipFile(path)
    names = z.namelist()
    pkl = [n for n in names if n.endswith("data.pkl")][0]
    prefix = pkl[:-len("data.pkl")]

    class U(pickle.Unpickler):
        def find_class(self, module, name):
            if module == "torch._utils" and name == "_rebuild_tensor_v2":
                return _rebuild
            if module == "torch" and name.endswith("Storage"):
                return name
            if module == "collections" and name == "OrderedDict":
                return collections.OrderedDict
            if module == "torch._utils" and name == "_rebuild_parameter":
                return lambda data, *a: data
            return super().find_class(module, name)

        def persistent_load(self, pid):
            _, stype, key, _loc, _n = pid
            return _Storage(_DT[stype], z.read(prefix + "data/" + key))
    obj = U(z.open(pkl)).load()
    return obj.get("params", obj.get("params_ema", obj))


def build(sd, tile=128, num_conv=32, scale=4):
    nodes, inits = [], []

    def W(name, arr):
        inits.append(numpy_helper.from_array(np.ascontiguousarray(arr, dtype=np.float32), name))
        return name
    cur = "input"
    n_layers = 2 + 2 * num_conv + 1
    for i in range(n_layers):
        if f"body.{i}.weight" not in sd:
            raise SystemExit("thiếu body.%d.weight — không phải SRVGGNetCompact" % i)
        wgt = sd[f"body.{i}.weight"]
        if wgt.ndim == 4:                                        # Conv
            out = f"c{i}"
            nodes.append(helper.make_node("Conv", [cur, W(f"w{i}", wgt), W(f"b{i}", sd[f"body.{i}.bias"])], [out],
                                          kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1], name=f"conv{i}"))
        else:                                                    # PReLU: slope theo kênh [C] -> [C,1,1]
            out = f"p{i}"
            nodes.append(helper.make_node("PRelu", [cur, W(f"s{i}", wgt.reshape(-1, 1, 1))], [out], name=f"prelu{i}"))
        cur = out
    nodes.append(helper.make_node("DepthToSpace", [cur], ["shuf"], blocksize=scale, mode="CRD", name="pixel_shuffle"))
    inits.append(numpy_helper.from_array(np.array([1, 1, scale, scale], np.float32), "scales"))
    inits.append(numpy_helper.from_array(np.array([], np.float32), "roi"))
    nodes.append(helper.make_node("Resize", ["input", "roi", "scales"], ["base"], mode="nearest", coordinate_transformation_mode="asymmetric",
                                  nearest_mode="floor", name="nearest_up"))
    nodes.append(helper.make_node("Add", ["shuf", "base"], ["output"], name="add_base"))
    g = helper.make_graph(nodes, "realesr_general_x4v3",
                          [helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, tile, tile])],
                          [helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 3, tile * scale, tile * scale])], inits)
    m = helper.make_model(g, opset_imports=[helper.make_opsetid("", 13)], producer_name="export_realesrgan_onnx.py")
    m.ir_version = 8
    onnx.checker.check_model(m)
    return m


if __name__ == "__main__":
    sd = load_pth(sys.argv[1])
    tile = int(sys.argv[3]) if len(sys.argv) > 3 else 128
    m = build(sd, tile)
    onnx.save(m, sys.argv[2])
    print("đã ghi", sys.argv[2], "—", len(sd), "tensor,", sum(int(np.prod(v.shape)) for v in sd.values()), "tham số")
