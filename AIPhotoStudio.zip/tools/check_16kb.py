#!/usr/bin/env python3
"""Kiểm tra căn chỉnh 16 KB của thư viện native (R31) — chỉ dùng thư viện chuẩn của Python, không cần NDK / readelf / Android Studio.

VÌ SAO CÓ: Google Play yêu cầu mọi ứng dụng nhắm Android 15 (API 35) trở lên phải chạy được trên máy dùng trang bộ nhớ 16 KB (64-bit).
Trang chính thức https://developer.android.com/guide/practices/page-sizes ghi: từ 01/02/2027, bản cập nhật không đạt sẽ KHÔNG phát hành được
(mốc cũ 01/11/2025 → 01/05/2026 đã được dời). Thư viện nào còn căn chỉnh 4 KB (ví dụ ONNX Runtime ≤ 1.21) làm cả APK bị từ chối.

CÁCH KIỂM (theo hướng dẫn đó), với MỖI tệp ELF 64-bit (arm64-v8a, x86_64):
  1. mọi đoạn PT_LOAD có p_align là bội của 16 KB (0x4000) và p_vaddr ≡ p_offset (mod p_align);
  2. đoạn PT_GNU_RELRO kết thúc tại ranh giới 16 KB: (p_vaddr + p_memsz) % 0x4000 == 0 (nếu không, ứng dụng sập khi chạy);
  3. với tệp .so nằm trong APK/AAR/ZIP và được LƯU KHÔNG NÉN (STORED): vị trí dữ liệu trong tệp zip phải chia hết cho 16 KB
     (AGP ≥ 8.5.1 tự căn; còn `useLegacyPackaging = true` như dự án này thì .so bị NÉN + giải nén khi cài nên mục này không áp dụng).
  ELF 32-bit (armeabi-v7a, x86) được bỏ qua — yêu cầu chỉ áp cho máy 64-bit.

DÙNG:  python tools/check_16kb.py <tệp.apk|.aar|.zip|.so|thư mục> [...]     Mã thoát 1 nếu có tệp 64-bit không đạt.
"""
import os
import struct
import sys
import zipfile

PAGE = 0x4000
PT_LOAD = 1
PT_GNU_RELRO = 0x6474E552
EM = {62: "x86_64", 183: "aarch64"}


def check_elf(data):
    """Trả về (trạng_thái, [lý do]); trạng thái: 'ok' | 'fail' | 'skip' (không phải ELF 64-bit)."""
    if len(data) < 64 or data[:4] != b"\x7fELF":
        return "skip", ["không phải ELF"]
    if data[4] != 2:
        return "skip", ["ELF 32-bit (yêu cầu 16 KB chỉ áp cho máy 64-bit)"]
    if data[5] != 1:
        return "skip", ["ELF big-endian (không gặp trên Android)"]
    e_phoff = struct.unpack_from("<Q", data, 32)[0]
    e_machine = struct.unpack_from("<H", data, 18)[0]
    e_phentsize, e_phnum = struct.unpack_from("<HH", data, 54)
    if e_phnum == 0 or e_phentsize < 56:
        return "skip", ["không có program header"]
    why = []
    n_load = 0
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        if off + 56 > len(data):
            return "fail", ["program header vượt quá cuối tệp (tệp cắt cụt?)"]
        p_type, _flags, p_offset, p_vaddr, _p_paddr, p_filesz, p_memsz, p_align = struct.unpack_from("<IIQQQQQQ", data, off)
        if p_type == PT_LOAD:
            n_load += 1
            if p_align % PAGE != 0:
                why.append(f"PT_LOAD #{n_load}: p_align = {p_align:#x} không chia hết cho 0x4000 (16 KB)")
            elif (p_vaddr - p_offset) % p_align != 0:
                why.append(f"PT_LOAD #{n_load}: p_vaddr {p_vaddr:#x} không đồng dư p_offset {p_offset:#x} theo p_align {p_align:#x}")
        elif p_type == PT_GNU_RELRO:
            if (p_vaddr + p_memsz) % PAGE != 0:
                why.append(f"PT_GNU_RELRO kết thúc tại {p_vaddr + p_memsz:#x}, không phải ranh giới 16 KB (sẽ sập khi chạy trên máy 16 KB)")
    if n_load == 0:
        return "skip", ["không có PT_LOAD"]
    return ("fail" if why else "ok"), why


def zip_data_offset(path, info):
    with open(path, "rb") as f:
        f.seek(info.header_offset)
        hdr = f.read(30)
    if len(hdr) < 30 or hdr[:4] != b"PK\x03\x04":
        return None
    fname_len, extra_len = struct.unpack_from("<HH", hdr, 26)
    return info.header_offset + 30 + fname_len + extra_len


def scan(path, results):
    if os.path.isdir(path):
        for root, _dirs, files in os.walk(path):
            for fn in sorted(files):
                if fn.endswith((".so", ".apk", ".aar", ".zip")):
                    scan(os.path.join(root, fn), results)
        return
    if path.endswith((".apk", ".aar", ".zip")):
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                if not info.filename.endswith(".so"):
                    continue
                data = z.read(info.filename)
                st, why = check_elf(data)
                if st != "skip" and info.compress_type == zipfile.ZIP_STORED:
                    off = zip_data_offset(path, info)
                    if off is not None and off % PAGE != 0:
                        st = "fail"
                        why = why + [f"lưu KHÔNG NÉN nhưng dữ liệu ở vị trí {off:#x} trong zip, không chia hết cho 16 KB (cần zipalign -P 16 / AGP ≥ 8.5.1)"]
                results.append((f"{os.path.basename(path)}!{info.filename}", st, why))
        return
    with open(path, "rb") as f:
        data = f.read()
    st, why = check_elf(data)
    results.append((path, st, why))


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    results = []
    for p in argv:
        if not os.path.exists(p):
            print(f"Không thấy: {p}")
            return 2
        scan(p, results)
    n_ok = sum(1 for _n, s, _w in results if s == "ok")
    n_fail = sum(1 for _n, s, _w in results if s == "fail")
    n_skip = sum(1 for _n, s, _w in results if s == "skip")
    for name, st, why in results:
        if st == "fail":
            print(f"KHÔNG ĐẠT  {name}")
            for w in why:
                print(f"           - {w}")
        elif st == "ok":
            print(f"đạt        {name}")
        else:
            print(f"bỏ qua     {name}  ({'; '.join(why)})")
    print(f"Tổng: {n_ok} đạt, {n_fail} KHÔNG đạt, {n_skip} bỏ qua (32-bit / không phải ELF).")
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
