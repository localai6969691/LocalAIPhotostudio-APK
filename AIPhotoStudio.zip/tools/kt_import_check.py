#!/usr/bin/env python3
"""
Kiểm tra IMPORT của toàn bộ mã Kotlin mà KHÔNG cần trình biên dịch (loại lỗi dễ mắc nhất khi sửa mã mà không biên dịch được):
  (1) hàm / hằng của kotlin.math dùng mà thiếu `import kotlin.math.<tên>` (min, max, abs, sqrt, pow, roundToInt, ceil, floor, ln, exp, sin, cos, tan, atan2, hypot, sign, PI ...);
  (2) lớp / object / hàm cấp cao của DỰ ÁN nằm ở package KHÁC mà không được import (tường minh hoặc import package.*);
  (3) import trỏ tới tên KHÔNG tồn tại trong dự án (lỗi gõ / đã đổi tên), với package com.aiphoto.studio.*.
Bỏ chú thích và chuỗi trước khi quét. Không thay thế trình biên dịch (không kiểm kiểu, tên phương thức, chữ ký) — chỉ bắt lỗi import.
Chạy: python3 tools/kt_import_check.py        (mã thoát 1 nếu có lỗi)
"""
import os
import re
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src")
MATH_FUNCS = ["min", "max", "abs", "sqrt", "ceil", "floor", "ln", "exp", "sin", "cos", "tan", "atan", "atan2", "hypot", "sign", "round", "truncate", "log10", "log2", "cbrt"]
MATH_EXT = ["pow", "roundToInt", "roundToLong", "absoluteValue", "sign", "withSign"]       # dùng dạng x.pow(2)
MATH_CONST = ["PI", "E"]


def strip(src):
    """Bỏ chú thích và nội dung chuỗi / ký tự (giữ dấu nháy) để quét định danh không bị nhiễu."""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            j = src.find("\n", i)
            i = n if j < 0 else j
        elif src.startswith("/*", i):
            depth, i = 1, i + 2
            while i < n and depth:
                if src.startswith("/*", i):
                    depth += 1; i += 2
                elif src.startswith("*/", i):
                    depth -= 1; i += 2
                else:
                    i += 1
        elif src.startswith('"""', i):
            j = src.find('"""', i + 3)
            seg = src[i:(n if j < 0 else j + 3)]
            out.append('""' + "\n" * seg.count("\n"))
            i = n if j < 0 else j + 3
        elif c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == "\\" else 1
            out.append('""')
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and src[j] != "'":
                j += 2 if src[j] == "\\" else 1
            out.append("''")
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def package_of(src):
    m = re.search(r"^\s*package\s+([\w.]+)", src, re.M)
    return m.group(1) if m else ""



def block_end(s, open_idx):
    """Vị trí dấu } khớp với { tại open_idx (s đã bỏ chú thích / chuỗi)."""
    depth = 0
    for i in range(open_idx, len(s)):
        if s[i] == "{":
            depth += 1
        elif s[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return len(s)


def split_top(text, sep=",", angle=True):
    """Tách theo dấu phẩy ở cấp 0. `angle`: coi <> là ngoặc (khai báo tham số có kiểu generic); tắt khi tách ĐỐI SỐ lời gọi vì khi đó < > thường là phép so sánh. Dấu > của `->` không tính."""
    out, depth, cur, prev = [], 0, [], ""
    for ch in text:
        if ch in "([{" or (angle and ch == "<"):
            depth += 1
        elif ch in ")]}" or (angle and ch == ">" and prev != "-"):
            depth -= 1
        prev = ch
        if ch == sep and depth == 0:
            out.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


def collect_members(srcs):
    """Tên đối tượng / lớp -> tập thành viên truy cập được dạng `Tên.thành_viên` (object, companion object, lớp lồng, hằng, enum)."""
    members = {}
    kinds = {}
    decl_re = re.compile(r"\b(?:fun|val|var|class|object|interface|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+?\.)?([A-Za-z_]\w*)")
    for f, (s, pkg) in srcs.items():
        for m in re.finditer(r"(?<![\w.])(?:enum\s+class|data\s+class|sealed\s+class|class|object|interface)\s+([A-Z]\w*)", s):
            name = m.group(1)
            j = m.end()
            # bỏ qua danh sách tham số hàm tạo / kế thừa tới dấu { của thân (nếu có)
            depth, k = 0, j
            while k < len(s):
                c = s[k]
                if c in "(<":
                    depth += 1
                elif c in ")>":
                    depth -= 1
                elif depth == 0 and c in "{\n=":
                    break
                k += 1
            kw = s[m.start():m.end()]
            is_enum = kw.startswith("enum")
            is_object = kw.startswith("object")
            if k < len(s) and s[k] == "{":
                e = block_end(s, k)
                body = s[k + 1:e]
                mem = members.setdefault(name, set())
                kinds.setdefault(name, set()).add("enum" if is_enum else ("object" if is_object else "class"))
                if is_enum:
                    head = body.split(";")[0] if ";" in body else body
                    # mục enum: các tên viết HOA ở đầu mỗi phần tử cách nhau bởi dấu phẩy ở cấp 0
                    for part in split_top(head):
                        mm = re.match(r"\s*([A-Za-z_]\w*)", part)
                        if mm:
                            mem.add(mm.group(1))
                if is_object:
                    for d in decl_re.finditer(body):
                        mem.add(d.group(1))
                else:
                    for cm in re.finditer(r"companion\s+object\s*(?:[A-Za-z_]\w*)?\s*\{", body):
                        ce = block_end(body, cm.end() - 1)
                        for d in decl_re.finditer(body[cm.end():ce]):
                            mem.add(d.group(1))
                    # lớp / object lồng trong lớp
                    for d in re.finditer(r"\b(?:class|object|interface)\s+([A-Za-z_]\w*)", body):
                        mem.add(d.group(1))
            else:
                members.setdefault(name, set())
                kinds.setdefault(name, set()).add("enum" if is_enum else ("object" if is_object else "class"))
    return members, kinds


COMMON = {"values", "valueOf", "entries", "name", "ordinal", "Companion", "javaClass", "java", "kotlin", "class", "hashCode", "equals", "toString", "copy", "also", "let", "run", "apply", "takeIf"}


def check_members(srcs, problems):
    members, kinds = collect_members(srcs)
    # Chỉ kiểm các tên được khai báo ĐÚNG MỘT LẦN trong dự án (tránh nhầm lớp cùng tên ở package khác) và có thân khai báo
    owners = {}
    for f, (s, pkg) in srcs.items():
        for m in re.finditer(r"(?<![\w.])(?:enum\s+class|data\s+class|sealed\s+class|class|object|interface)\s+([A-Z]\w*)", s):
            owners.setdefault(m.group(1), []).append((f, m.start()))
    for f, (s, pkg) in sorted(srcs.items()):
        rel = os.path.relpath(f, ROOT)
        body = re.sub(r"^\s*(import|package)\s+[^\n]*", "", s, flags=re.M)
        for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\.([A-Za-z_]\w*)", body):
            owner, mem = m.group(1), m.group(2)
            if owner not in members or len(owners.get(owner, [])) != 1 or mem in COMMON or not members[owner]:
                continue
            if mem not in members[owner]:
                ln = body.count("\n", 0, m.start()) + 1
                problems.append(f"{rel}:{ln}: {owner}.{mem} — `{owner}` không có thành viên `{mem}`")
    return problems



def match_paren(s, open_idx):
    depth = 0
    for i in range(open_idx, len(s)):
        if s[i] == "(":
            depth += 1
        elif s[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def collect_arity(srcs):
    """(đối tượng, hàm) -> danh sách (số tham số tối thiểu, tối đa | None nếu vararg) cho hàm khai báo TRONG object / companion object / lớp."""
    ar = {}
    for f, (s, pkg) in srcs.items():
        for m in re.finditer(r"(?<![\w.])(?:object|class)\s+([A-Z]\w*)", s):
            name = m.group(1)
            k = m.end()
            depth = 0
            while k < len(s):
                c = s[k]
                if c in "(<":
                    depth += 1
                elif c in ")>":
                    depth -= 1
                elif depth == 0 and c in "{\n=":
                    break
                k += 1
            if k >= len(s) or s[k] != "{":
                continue
            e = block_end(s, k)
            body = s[k + 1:e]
            regions = [body] if s[m.start():m.end()].startswith("object") else [body[cm.end():block_end(body, cm.end() - 1)] for cm in re.finditer(r"companion\s+object\s*(?:[A-Za-z_]\w*)?\s*\{", body)]
            for reg in regions:
                for fm in re.finditer(r"\bfun\s+(?:<[^>]*>\s*)?([A-Za-z_]\w*)\s*\(", reg):
                    po = fm.end() - 1
                    pc = match_paren(reg, po)
                    if pc < 0:
                        continue
                    # bỏ hàm có receiver: ký tự trước tên là '.'
                    pre = reg[max(0, fm.start()):fm.start(1)]
                    if "." in pre:
                        continue
                    ptxt = reg[po + 1:pc].strip()
                    params = [x for x in split_top(ptxt) if x.strip()] if ptxt else []
                    lo = sum(1 for x in params if "=" not in x.split(":")[0] and not re.search(r"(?<![=!<>])=(?!=)", x) and "vararg" not in x)
                    vararg = any("vararg" in x for x in params)
                    ar.setdefault((name, fm.group(1)), set()).add((lo, None if vararg else len(params)))
    return ar


def check_arity(srcs, problems):
    ar = collect_arity(srcs)
    owners = {}
    for f, (s, pkg) in srcs.items():
        for m in re.finditer(r"(?<![\w.])(?:enum\s+class|data\s+class|sealed\s+class|class|object|interface)\s+([A-Z]\w*)", s):
            owners[m.group(1)] = owners.get(m.group(1), 0) + 1
    for f, (s, pkg) in sorted(srcs.items()):
        rel = os.path.relpath(f, ROOT)
        body = re.sub(r"^\s*(import|package)\s+[^\n]*", "", s, flags=re.M)
        for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\.([a-z_]\w*)\s*\(", body):
            key = (m.group(1), m.group(2))
            if key not in ar or owners.get(m.group(1), 0) != 1:
                continue
            po = m.end() - 1
            pc = match_paren(body, po)
            if pc < 0:
                continue
            atxt = body[po + 1:pc].strip()
            args = [x for x in split_top(atxt, angle=False) if x.strip()] if atxt else []
            n = len(args)
            if re.match(r"\s*\{", body[pc + 1:pc + 4]):
                n += 1                                      # lambda cuối đứng ngoài ngoặc
            ok = any(lo <= n and (hi is None or n <= hi) for lo, hi in ar[key])
            if not ok:
                ln = body.count("\n", 0, m.start()) + 1
                sig = " | ".join("%d..%s" % (lo, "∞" if hi is None else hi) for lo, hi in sorted(ar[key], key=lambda t: (t[0], t[1] or 99)))
                problems.append(f"{rel}:{ln}: {key[0]}.{key[1]}(…) gọi với {n} đối số, khai báo nhận {sig}")
    return problems


def main():
    files = []
    for d, _, fs in os.walk(ROOT):
        for f in fs:
            if f.endswith(".kt"):
                files.append(os.path.join(d, f))
    srcs = {}
    for f in files:
        raw = open(f, encoding="utf-8").read()
        srcs[f] = (strip(raw), package_of(raw))
    # khai báo cấp cao của dự án: tên -> {package}
    decl = {}
    for f, (s, pkg) in srcs.items():
        for m in re.finditer(r"^(?:\s*(?:public|internal|private|data|sealed|enum|abstract|open|inline|const|annotation|value|fun interface)\s+)*(?:class|object|interface|typealias)\s+([A-Za-z_]\w*)", s, re.M):
            if not re.match(r"^\s*private\b", s[m.start():m.end()]):
                decl.setdefault(m.group(1), set()).add(pkg)
        for m in re.finditer(r"^(?:internal\s+|public\s+)?(?:inline\s+)?fun\s+(?:<[^>]*>\s*)?(?:[A-Za-z_][\w.<>?]*\.)?([A-Za-z_]\w*)\s*\(", s, re.M):
            decl.setdefault("fun:" + m.group(1), set()).add(pkg)
        for m in re.finditer(r"^(?:internal\s+|public\s+)?(?:const\s+)?val\s+([A-Za-z_]\w*)", s, re.M):
            decl.setdefault("fun:" + m.group(1), set()).add(pkg)
    problems = []
    for f, (s, pkg) in sorted(srcs.items()):
        rel = os.path.relpath(f, ROOT)
        imports = set(re.findall(r"^\s*import\s+(\S+)", s, re.M))
        star_pkgs = {i[:-2] for i in imports if i.endswith(".*")}
        explicit = {i.split(".")[-1]: i for i in imports if not i.endswith(".*")}
        body = re.sub(r"^\s*(import|package)\s+[^\n]*", "", s, flags=re.M)
        local_funs = set(re.findall(r"\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?]+\.)?([A-Za-z_]\w*)\s*\(", body))
        local_vals = set(re.findall(r"\b(?:val|var)\s+([A-Za-z_]\w*)", body)) | set(re.findall(r"[(,]\s*([A-Za-z_]\w*)\s*:", body))
        # (1) kotlin.math
        for name in MATH_FUNCS:
            if name in local_funs:
                continue
            for m in re.finditer(r"(?<![\w.])" + name + r"\s*\(", body):
                pre = body[max(0, m.start() - 12):m.start()]
                if re.search(r"(Math|math|StrictMath)\.\s*$", pre):
                    continue
                if "kotlin.math." + name not in imports and "kotlin.math.*" not in imports:
                    ln = body.count("\n", 0, m.start()) + 1
                    problems.append(f"{rel}:{ln}: dùng {name}( mà thiếu `import kotlin.math.{name}`")
                    break
        for name in MATH_EXT:
            pat = r"(?<!Math)(?<!math)(?<!Math\.)\.\s*" + name + r"\b"
            if re.search(pat, body) and "kotlin.math." + name not in imports and "kotlin.math.*" not in imports:
                # Float.sign / Double.sign cần import; .absoluteValue cũng vậy
                ln = body.count("\n", 0, re.search(pat, body).start()) + 1
                problems.append(f"{rel}:{ln}: dùng .{name} mà thiếu `import kotlin.math.{name}`")
        for name in MATH_CONST:
            if re.search(r"(?<![\w.])" + name + r"\b(?!\s*[:(=])", body) and name not in local_vals and "kotlin.math." + name not in imports and "kotlin.math.*" not in imports:
                if re.search(r"(?<![\w.])" + name + r"\b\s*[*/+\-)]", body) or re.search(r"[*/+\-(]\s*" + name + r"\b", body):
                    if name not in decl:
                        problems.append(f"{rel}: dùng hằng {name} mà thiếu `import kotlin.math.{name}`")
        # (2) lớp / object / hàm của dự án ở package khác
        for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\b", body):
            name = m.group(1)
            pkgs = decl.get(name)
            if not pkgs or pkg in pkgs or name in explicit and explicit[name].rsplit(".", 1)[0] in pkgs:
                continue
            if any(sp in pkgs for sp in star_pkgs):
                continue
            # tên có thể là thành viên lồng của lớp khác cùng tên? bỏ qua nếu được khai báo lồng trong chính file
            if re.search(r"\b(?:class|object|interface|enum class|data class)\s+" + name + r"\b", body):
                continue
            ln = body.count("\n", 0, m.start()) + 1
            problems.append(f"{rel}:{ln}: dùng {name} (khai báo ở package {', '.join(sorted(pkgs))}) mà thiếu import")
            break
        for m in re.finditer(r"(?<![\w.])([a-z_]\w*)\s*\(", body):
            name = m.group(1)
            pkgs = decl.get("fun:" + name)
            if not pkgs or pkg in pkgs or name in explicit or name in local_funs or any(sp in pkgs for sp in star_pkgs):
                continue
            pre = body[max(0, m.start() - 1):m.start()]
            if pre == ".":
                continue
            # hàm cấp cao của dự án (vd. makeBitmap): chỉ báo khi không có phương thức / hàm cùng tên khai báo trong chính package hiện tại
            if name in ("makeBitmap",) or name.startswith("make") and "Bitmap" in name:
                ln = body.count("\n", 0, m.start()) + 1
                problems.append(f"{rel}:{ln}: dùng hàm {name}(...) (khai báo ở package {', '.join(sorted(pkgs))}) mà thiếu import")
                break
        # (3) import tới tên không tồn tại trong dự án
        for imp in imports:
            if imp.startswith("com.aiphoto.studio.") and not imp.endswith(".*"):
                nm = imp.split(".")[-1]
                if nm not in decl and "fun:" + nm not in decl:
                    problems.append(f"{rel}: import {imp} — không thấy khai báo `{nm}` trong dự án")
    check_members(srcs, problems)
    check_arity(srcs, problems)
    if problems:
        print("CÓ %d VẤN ĐỀ IMPORT / THAM CHIẾU:" % len(problems))
        for p in problems:
            print("  -", p)
        return 1
    print("Import Kotlin sạch: %d tệp, %d khai báo cấp cao của dự án." % (len(files), len(decl)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
