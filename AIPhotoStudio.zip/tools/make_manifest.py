#!/usr/bin/env python3
"""Sinh REPO_MANIFEST.txt (sha1, kích thước, đường dẫn của MỌI tệp trong dự án) để workflow CI đối chiếu với repo GitHub
và chỉ ra chính xác tệp/thư mục nào bị thiếu khi tải lên chưa đủ (vd: GitHub web chỉ cho tải ~100 tệp mỗi lần).
Chạy lại TRƯỚC KHI đóng gói zip: python3 tools/make_manifest.py"""
import hashlib, os, sys
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SKIP_DIRS = {".git", "__pycache__", "build", ".gradle", ".idea", ".cxx", ".externalNativeBuild", "captures", "node_modules"}
SKIP_FILES = {"REPO_MANIFEST.txt", "local.properties"}
SKIP_EXT = (".apk", ".aab", ".iml", ".pyc")
rows = []
for d, dirs, files in os.walk(ROOT):
    dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
    for f in sorted(files):
        if f in SKIP_FILES or f.endswith(SKIP_EXT): continue
        p = os.path.join(d, f); rel = os.path.relpath(p, ROOT).replace(os.sep, "/")
        h = hashlib.sha1(open(p, "rb").read()).hexdigest()
        rows.append(f"{h} {os.path.getsize(p)} {rel}")
rows.sort(key=lambda r: r.split(" ", 2)[2])
open(os.path.join(ROOT, "REPO_MANIFEST.txt"), "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(f"REPO_MANIFEST.txt: {len(rows)} tệp")
