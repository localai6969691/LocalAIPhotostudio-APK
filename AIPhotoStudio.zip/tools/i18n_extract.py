#!/usr/bin/env python3
"""Trích mọi chuỗi tiếng Việt hiển thị cho người dùng từ mã Kotlin → khóa dịch (R33).

Cơ chế dịch của app (xem app/.../i18n/): `Text(...)` đã được bọc để TRA CỨU chuỗi sắp hiển thị trong gói dịch; khóa = chính chuỗi tiếng Việt nguồn.
Chuỗi có nội suy Kotlin được chuẩn hóa thành MẪU: `"Credits còn lại: ${st.credits}"` → `Credits còn lại: {0}` (các biểu thức đánh số theo thứ tự xuất hiện);
lúc chạy, chuỗi thật "Credits còn lại: 12" khớp mẫu và số 12 được đưa vào bản dịch `Credits left: {0}`.

Công cụ này KHÔNG sửa mã: nó chỉ đọc và (khi --write) ghi `tools/i18n/keys.json` — danh sách khóa theo thứ tự ổn định kèm tệp nguồn.
Dùng:  python tools/i18n_extract.py [--write] [--stats]
"""
import json
import os
import re
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(PROJ, "app", "src", "main", "java", "com", "aiphoto", "studio")
# nơi chuỗi tiếng Việt được hiển thị cho người dùng qua Text(...)
SCAN = ["ui", "MainViewModel.kt", os.path.join("engine", "Monetization.kt"), os.path.join("doc", "Recipes.kt"), os.path.join("doc", "History.kt"), os.path.join("ai", "EditModels.kt")]
VI = re.compile(r"[À-ỹà-ỹĐđ]")
# từ tiếng Việt không dấu hay gặp: để bắt cả câu viết không dấu (ít gặp trong UI nhưng có)
ESC = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", '"': '"', "'": "'", "\\": "\\", "$": "$"}


def scan_literals(src):
    """Trả về [(chuỗi_đã_chuẩn_hóa, số_dòng)] cho mọi literal "…" (không xử lý raw string \"\"\"…\"\"\"). Biểu thức ${…}/$id → {n}."""
    out = []
    i, n, line = 0, len(src), 1
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1
            i += 1
        elif src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            line += src.count("\n", i, j)
            i = j
        elif src.startswith('"""', i):
            j = src.find('"""', i + 3)
            j = n if j < 0 else j + 3
            line += src.count("\n", i, j)
            i = j
        elif c == "'":  # ký tự: 'x' hoặc '\n'
            j = i + 1
            if j < n and src[j] == "\\":
                j += 2
            else:
                j += 1
            while j < n and src[j] != "'" and src[j] != "\n":
                j += 1
            i = j + 1
        elif c == '"':
            start_line = line
            buf = []
            ph = 0
            ok = True
            j = i
            while True:  # nối các literal liền nhau bằng "+" (Kotlin gộp hằng lúc biên dịch ⇒ lúc chạy là MỘT chuỗi)
                j += 1
                while j < n:
                    d = src[j]
                    if d == "\\" and j + 1 < n:
                        e = src[j + 1]
                        if e == "u" and j + 5 < n:
                            try:
                                buf.append(chr(int(src[j + 2:j + 6], 16)))
                                j += 6
                                continue
                            except ValueError:
                                pass
                        buf.append(ESC.get(e, e))
                        j += 2
                    elif d == "$" and j + 1 < n and src[j + 1] == "{":
                        depth, k = 1, j + 2
                        while k < n and depth:
                            if src[k] == "{":
                                depth += 1
                            elif src[k] == "}":
                                depth -= 1
                            elif src[k] == '"':  # chuỗi lồng trong biểu thức: nhảy qua
                                k += 1
                                while k < n and src[k] != '"':
                                    k += 2 if src[k] == "\\" else 1
                            k += 1
                        buf.append("{%d}" % ph)
                        ph += 1
                        line += src.count("\n", j, k)
                        j = k
                    elif d == "$" and j + 1 < n and (src[j + 1].isalpha() or src[j + 1] == "_"):
                        k = j + 1
                        while k < n and (src[k].isalnum() or src[k] == "_"):
                            k += 1
                        buf.append("{%d}" % ph)
                        ph += 1
                        j = k
                    elif d == '"':
                        break
                    elif d == "\n":
                        ok = False
                        break
                    else:
                        buf.append(d)
                        j += 1
                if not ok:
                    break
                # sau dấu " đóng: có "+ <literal>" ngay sau không?
                k = j + 1
                while k < n and src[k] in " \t\r\n":
                    k += 1
                if k < n and src[k] == "+":
                    k += 1
                    while k < n and src[k] in " \t\r\n":
                        k += 1
                    if k < n and src[k] == '"' and not src.startswith('"""', k):
                        line += src.count("\n", j, k)
                        j = k
                        continue
                break
            if ok:
                out.append(("".join(buf), start_line))
            i = j + 1
        else:
            i += 1
    return out


def collect():
    """{khóa: [tệp:dòng, …]} theo thứ tự xuất hiện; chỉ giữ chuỗi có chữ tiếng Việt và còn chữ cái ngoài các {n}."""
    keys = {}
    paths = []
    for s in SCAN:
        p = os.path.join(SRC, s)
        if os.path.isdir(p):
            paths += sorted(os.path.join(p, f) for f in os.listdir(p) if f.endswith(".kt"))
        elif os.path.exists(p):
            paths.append(p)
    for p in paths:
        src = open(p, encoding="utf-8").read()
        rel = os.path.relpath(p, SRC)
        for text, ln in scan_literals(src):
            t = text.strip()
            if not VI.search(t) or text != t:   # khóa có khoảng trắng đầu/cuối là mảnh nối chuỗi: không bao giờ hiển thị riêng
                continue
            if not re.sub(r"\{\d+\}", "", t).strip(" .,:;()[]·-–—•…!?/\\|"):
                continue
            keys.setdefault(text, []).append(f"{rel}:{ln}")
    return keys


def main(argv):
    keys = collect()
    plain = [k for k in keys if "{" not in k]
    tmpl = [k for k in keys if "{" in k]
    print(f"Khóa: {len(keys)} (chuỗi thường {len(plain)}, mẫu có nội suy {len(tmpl)})")
    if "--stats" in argv:
        buckets = {"<=16": 0, "17-32": 0, "33-64": 0, ">64": 0}
        for k in keys:
            L = len(k)
            buckets["<=16" if L <= 16 else "17-32" if L <= 32 else "33-64" if L <= 64 else ">64"] += 1
        print("Độ dài:", buckets)
        by = {}
        for k, where in keys.items():
            by.setdefault(where[0].split(":")[0], 0)
            by[where[0].split(":")[0]] += 1
        print("Theo tệp (nơi xuất hiện đầu tiên):", by)
    if "--write" in argv:
        os.makedirs(os.path.join(PROJ, "tools", "i18n"), exist_ok=True)
        out = [{"key": k, "where": v[:3]} for k, v in keys.items()]
        with open(os.path.join(PROJ, "tools", "i18n", "keys.json"), "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=0)
        print("Đã ghi tools/i18n/keys.json")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
