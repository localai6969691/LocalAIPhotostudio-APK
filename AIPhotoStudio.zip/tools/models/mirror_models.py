#!/usr/bin/env python3
"""R43: nạp model vào GitHub Releases của kho (miễn phí, không hết hạn) và sinh `catalog.json` cho trình tải model trong app.

Vì sao GitHub Releases: miễn phí, tệp tới 2 GiB, địa chỉ cố định, hỗ trợ tải tiếp (HTTP Range — đã kiểm: 302 sang release-assets.githubusercontent.com, trả 206 + Content-Range),
không cần tài khoản nào ngoài GitHub. Điều kiện: kho phải CÔNG KHAI (kho riêng thì người dùng app không tải được). Kho riêng: dùng `--repo` trỏ tới một kho công khai khác
(workflow: biến repo MODELS_REPO + secret MODELS_REPO_TOKEN).
Chạy trong workflow `mirror-models.yml` (runner có mạng tới GitHub, Hugging Face, GCS). Chạy tay:
  python3 tools/models/mirror_models.py --repo CHU/KHO --tag models-v1                # tải + đẩy lên Release (cần `gh` và GH_TOKEN)
  python3 tools/models/mirror_models.py --no-upload --only seg_u2netp --out /tmp/o     # chỉ tải + tính SHA-256 + sinh catalog.json
  python3 tools/models/mirror_models.py --no-upload --bundled-out app/src/main/assets/model_catalog.json   # sinh danh mục CÓ SẴN trong app từ các mục verified
Mỗi mục: thử lần lượt các URL nguồn; nếu có `pinSha256` thì chỉ nhận tệp khớp. Mục `optional` lỗi thì bỏ qua; mục không optional lỗi thì thoát mã 1."""
import argparse, datetime, hashlib, json, os, shutil, subprocess, sys, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
UA = "AIPhotoStudio-mirror/1"


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url, dest, retries=3):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=120) as r, open(dest + ".part", "wb") as out:
                shutil.copyfileobj(r, out, 1 << 20)
            os.replace(dest + ".part", dest)
            return None
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            last = e
            time.sleep(2 * (i + 1))
    return str(last)


def fetch_entry(e, out):
    """Trả (đường dẫn tệp, URL nguồn đã dùng) hoặc (None, lý do)."""
    dest = os.path.join(out, e["file"])
    pin = e.get("pinSha256")
    if os.path.exists(dest) and (not pin or sha256_of(dest) == pin):
        return dest, "(đã có trong thư mục đầu ra)"
    if e.get("recipe") == "realesrgan":
        pth = os.path.join(out, "realesr-general-x4v3.pth")
        err = download(e["recipeUrl"], pth)
        if err: return None, "không tải được trọng số .pth: " + err
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "export_realesrgan_onnx.py"), pth, dest], capture_output=True, text=True)
        if r.returncode != 0: return None, "xuất ONNX lỗi: " + (r.stderr or r.stdout)[-300:]
        os.remove(pth)
        return dest, e["recipeUrl"] + " (xuất ONNX)"
    reasons = []
    for url in e["urls"]:
        err = download(url, dest)
        if err:
            reasons.append(f"{url}: {err}"); continue
        if pin and sha256_of(dest) != pin:
            reasons.append(f"{url}: SHA-256 khác bản đã ghim"); os.remove(dest); continue
        return dest, url
    return None, "; ".join(reasons) or "không có URL nguồn"


def catalog_entry(e, path, release_base):
    return {
        "id": e["id"], "slot": e["slot"], "name": e["name"], "file": e["file"],
        "sizeBytes": os.path.getsize(path), "sha256": sha256_of(path),
        "urls": ["{release}/" + e["file"]] + list(e.get("urls", [])),
        "license": e["license"], "licenseUrl": e["licenseUrl"],
        "vi": e["vi"], "en": e["en"], "riskVi": e.get("riskVi", ""), "riskEn": e.get("riskEn", ""),
        "recommended": bool(e.get("recommended")),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default="", help="CHU/KHO nhận Release (bỏ trống khi chỉ --no-upload)")
    ap.add_argument("--tag", default="")
    ap.add_argument("--out", default="/tmp/mirror_out")
    ap.add_argument("--only", default="", help="id cách nhau dấu phẩy; bỏ trống = tất cả")
    ap.add_argument("--no-upload", action="store_true")
    ap.add_argument("--bundled-out", default="", help="ghi danh mục CÓ SẴN trong app (chỉ mục verified, releaseBase chứa __REPO__)")
    ap.add_argument("--sources", default=os.path.join(HERE, "sources.json"))
    a = ap.parse_args()
    src = json.load(open(a.sources, encoding="utf-8"))
    tag = a.tag or src.get("tag", "models-v1")
    if not a.no_upload and not a.repo:
        sys.exit("thiếu --repo (hoặc dùng --no-upload)")
    only = {x.strip() for x in a.only.split(",") if x.strip()}
    os.makedirs(a.out, exist_ok=True)
    rows, entries, bundled, failed = [], [], [], []
    for e in src["models"]:
        if only and e["id"] not in only: continue
        path, why = fetch_entry(e, a.out)
        if not path:
            if not e.get("optional"): failed.append((e["id"], "LỖI", why))
            rows.append((e["id"], "BỎ QUA (optional)" if e.get("optional") else "LỖI", why))
            continue
        ce = catalog_entry(e, path, "")
        entries.append(ce)
        if e.get("verified"): bundled.append(dict(ce))
        rows.append((e["id"], "OK", f'{ce["sizeBytes"]:,} byte  {ce["sha256"][:12]}…  ← {why}'))
    for r in rows: print("%-22s %-18s %s" % r)
    if failed:
        print("CÓ MỤC BẮT BUỘC LỖI:", [f[0] for f in failed]); sys.exit(1)
    release_base = f"https://github.com/{a.repo}/releases/download/{tag}" if a.repo else ""
    cat = {"version": 1, "generated": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "releaseBase": release_base, "models": entries}
    cpath = os.path.join(a.out, "catalog.json")
    json.dump(cat, open(cpath, "w", encoding="utf-8"), ensure_ascii=False, indent=2); open(cpath, "a").write("\n")
    print("đã ghi", cpath, "—", len(entries), "mục")
    if a.bundled_out:
        base = f"https://github.com/__REPO__/releases/download/{tag}"
        b = {"version": 1, "_note": "Danh mục CÓ SẴN trong app (sinh bởi tools/models/mirror_models.py --bundled-out; chỉ các mục verified). CI thay __REPO__ bằng kho thật khi dựng APK. "
             "Danh mục mới nhất lấy từ catalogUrl nếu tải được.", "catalogUrl": base + "/catalog.json", "releaseBase": base, "models": bundled}
        os.makedirs(os.path.dirname(os.path.abspath(a.bundled_out)), exist_ok=True)
        json.dump(b, open(a.bundled_out, "w", encoding="utf-8"), ensure_ascii=False, indent=2); open(a.bundled_out, "a").write("\n")
        print("đã ghi danh mục có sẵn trong app:", a.bundled_out, "—", len(bundled), "mục")
    if a.no_upload: return
    env = os.environ.copy()
    subprocess.run(["gh", "release", "create", tag, "--repo", a.repo, "--title", "Model AI (trình tải trong app)",
                    "--notes", "Tệp model cho trình tải trong app AI Photo Studio. Sinh tự động bởi workflow Mirror models — đừng xóa. Giấy phép từng model: xem catalog.json."],
                   env=env, capture_output=True)   # đã tồn tại thì bỏ qua
    files = [os.path.join(a.out, e["file"]) for e in entries] + [cpath]
    r = subprocess.run(["gh", "release", "upload", tag, "--repo", a.repo, "--clobber"] + files, env=env)
    if r.returncode != 0: sys.exit("đẩy lên Release lỗi")
    print("xong: ", release_base + "/catalog.json")
    summ = os.environ.get("GITHUB_STEP_SUMMARY")
    if summ:
        with open(summ, "a", encoding="utf-8") as f:
            f.write("### Mirror models\n\n| id | kết quả | chi tiết |\n|---|---|---|\n" + "\n".join(f"| {i} | {s} | {d} |" for i, s, d in rows) + f"\n\nDanh mục: {release_base}/catalog.json\n")


if __name__ == "__main__":
    main()
