#!/usr/bin/env python3
"""
Kiểm tra TĨNH mã Kotlin khi chưa có trình biên dịch (không thay thế gradle build, nhưng bắt được các lỗi tham chiếu phổ biến):
  1. cân bằng ngoặc {} () [] (bỏ qua chuỗi và chú thích)
  2. khai báo package khớp thư mục
  3. mọi `import com.aiphoto.studio.*` trỏ tới khai báo có thật
  4. mọi `vm.xxx` trong ui/ là thành viên của MainViewModel; mọi `st.xxx` là trường của UiState
  5. mọi `Enum.ENTRY` (OpType, Scope, Panel, PaintMode, BlendMode, GenQuality, GenProvider...) có thật
  6. mọi OpType được xử lý ở describe()/sanitized() hoặc rơi vào nhánh else (không bắt buộc, chỉ cảnh báo)
  7. (R14) mọi `when (x) { … }` KHÔNG có `else` mà các nhánh là giá trị enum / lớp con sealed phải PHỦ KÍN
     (Kotlin ≥ 1.7: thiếu nhánh là lỗi biên dịch, kể cả khi `when` là câu lệnh)
  8. (R14) mọi lớp/đối tượng có tên implement một `interface` của dự án phải `override` ĐỦ thành viên trừu tượng của nó
  9. (R14) mã sản phẩm thanh toán trong Kotlin (BILLING_PRODUCTS / BILLING_SUBSCRIPTIONS) khớp mặc định ở backend/server.py
 10. (R16) hàm của kotlin.math (abs, sqrt, max, min, roundToInt, pow, hypot, sin, cos, atan2, floor, ceil...) dùng trong một tệp
     phải được import (import kotlin.math.X hoặc kotlin.math.*) - thiếu import là lỗi biên dịch mà compiler Kotlin KHÔNG tự bù
 11. (R17) lớp/đối tượng/hằng cấp cao của dự án dùng ở package KHÁC phải được import (hoặc import package.*) - "Unresolved reference"
 12. (R17) mọi `Object.thanhVien` (object của dự án, tên bất kỳ) phải là thành viên có thật của object đó (gõ sai / đổi tên một phía)
 13. (R17) tên kiểu viết hoa dùng trong tệp phải có nguồn: kiểu mặc định của Kotlin/Java, kiểu khai báo trong dự án, hoặc được import
     (bắt `Bitmap`, `Uri`, `Dispatchers`, thành phần Compose... bị quên import)
 14. (R17) hàm Compose/coroutines viết thường dùng phổ biến (padding, fillMaxWidth, verticalScroll, clickable, remember, mutableStateOf,
     launch, withContext...) và toán tử uỷ quyền `by` (getValue/setValue) phải có import tương ứng
 15. (R23) công tắc tính phí `Monetization` được nối đủ: mọi `Watermark.apply(` nằm cùng dòng với `Monetization.needsWatermark(`; mọi chỗ giao diện
     hiện credits/gói/giá/Team (`TeamSection(`, `loadBillingProducts`, `buy(`, `buySubscription`, `restorePurchases`, "Credits còn lại", "Credits: ")
     phải nằm trong khối `if (Monetization.showPaidUi() …)` - đổi ENABLED mà một chỗ quên nối thì người dùng thử vẫn thấy nút mua / bị đóng dấu;
     điều kiện nhà cung cấp `"token:proxy"` và lệnh gọi `ProxyBackend.editPlan(` phải đi qua `Monetization.proxyAiUsable(` (không gọi AI máy chủ khi máy chủ không cung cấp)
 16. (R24) kênh báo lỗi cho tester được nối đủ: MainActivity cài `CrashHandler.install(CrashStore.at(` TRƯỚC `setContent`; `ui()` ghi `DiagLog`; `launchTask` ghi lỗi;
     VM gọi `checkLastExit()` ở init; giao diện có nút `vm.prepareDiagReport()` và hộp `DiagDialog` theo `st.diagReport != null`; `buildDiagReport()` KHÔNG đưa
     khóa AI / token / URL thô vào báo cáo (chỉ `.isNotBlank()` hoặc `DiagReport.hostOf(`); không ai tạo `CrashStore(` trực tiếp (phải qua `CrashStore.at(` để dùng chung thư mục)
 17. (R24) Auto Frame và Di chuyển vật thể được nối đủ: `ImageEngine.cropRatio` dùng `AutoFrame.cropRect(` (khung xem trước = khung cắt thật), `CROP_RATIO` giữ arg qua
     `AutoFrame.normalizeArg(`; `run()` chuyển yêu cầu "cắt theo chủ thể" sang `autoFrame(` TRƯỚC các nhánh xóa/thay nền/quy tắc; `autoFrame()` gọi `pushUndo()` trước `bakeInternal(`;
     `moveSelection()` tách bằng `MoveObject.cutout(`, xóa chỗ cũ bằng `removeWithRouting(`, `pushUndo()` rồi mở thẻ lớp để kéo; giao diện có nút Auto Frame và "Di chuyển"
Dùng:  python3 tools/static_check.py   (thoát mã 1 nếu có lỗi)
"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src")
errors, warnings = [], []

def kt_files():
    for base, _, files in os.walk(ROOT):
        for f in files:
            if f.endswith(".kt"):
                yield os.path.join(base, f)

def strip_code(src):
    """Bỏ chú thích và nội dung chuỗi (kể cả raw string, ký tự) để đếm ngoặc đúng."""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            j = src.find("\n", i); i = n if j < 0 else j; continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2; continue
        if src.startswith('"""', i):
            j = src.find('"""', i + 3); i = n if j < 0 else j + 3; out.append('""'); continue
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == "\\" else 1
            i = j + 1; out.append('""'); continue
        if c == "'":
            j = i + 1
            while j < n and src[j] != "'":
                j += 2 if src[j] == "\\" else 1
            i = j + 1; out.append("' '"); continue
        out.append(c); i += 1
    return "".join(out)

files = {p: open(p, encoding="utf-8").read() for p in kt_files()}
code = {p: strip_code(s) for p, s in files.items()}

# 1. ngoặc
for p, s in code.items():
    for o, c in ("{}", "()", "[]"):
        if s.count(o) != s.count(c):
            errors.append(f"{os.path.relpath(p, ROOT)}: lệch ngoặc {o}{c}: {s.count(o)} mở / {s.count(c)} đóng")

# 2. package
decl = {}  # package -> set(tên khai báo cấp cao)
top_re = re.compile(r"^(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:public|internal|private|data|sealed|enum|abstract|open|inline|value|annotation)\s+)*"
                    r"(?:class|object|interface|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)", re.M)
for p, s in files.items():
    m = re.search(r"^package\s+([\w.]+)", s, re.M)
    if not m:
        errors.append(f"{os.path.relpath(p, ROOT)}: thiếu package"); continue
    pkg = m.group(1)
    rel = os.path.relpath(os.path.dirname(p), ROOT).replace(os.sep, "/")
    if not (rel.endswith(pkg.replace(".", "/"))):
        errors.append(f"{os.path.relpath(p, ROOT)}: package {pkg} không khớp thư mục")
    names = decl.setdefault(pkg, set())
    for t in top_re.finditer(code[p]):
        names.add(t.group(1))

# 3. import
for p, s in files.items():
    for m in re.finditer(r"^import\s+(com\.aiphoto\.studio\.[\w.]+?)(\.\*)?\s*$", s, re.M):
        full = m.group(1); pkg, _, name = full.rpartition(".")
        if m.group(2):  # import Gói.* hoặc import Enum.*
            if full not in decl and name not in decl.get(pkg, set()):
                errors.append(f"{os.path.relpath(p, ROOT)}: import wildcard không tồn tại: {full}.*")
        elif name not in decl.get(pkg, set()):
            errors.append(f"{os.path.relpath(p, ROOT)}: import không tồn tại: {full}")

# 4. vm.xxx / st.xxx
vm_src = next((code[p] for p in code if p.endswith("MainViewModel.kt")), "")
vm_members = set(re.findall(r"\b(?:fun|val|var)\s+(?:<[^>]*>\s*)?(?:\w+\.)?(\w+)", vm_src))
ui_state = re.search(r"data class UiState\((.*?)\n\)\s*\{", vm_src, re.S)
state_fields = set(re.findall(r"\bval\s+(\w+)\s*:", ui_state.group(1))) if ui_state else set()
state_extra = set(re.findall(r"\bval\s+(\w+)\s*(?::[^=\n]+)?\s*(?:get\(\)|=)", vm_src[ui_state.end():ui_state.end() + 4000])) if ui_state else set()
for p, s in code.items():
    if "/ui/" not in p.replace(os.sep, "/"):
        continue
    for m in re.finditer(r"\bvm\.(\w+)", s):
        if m.group(1) not in vm_members:
            errors.append(f"{os.path.relpath(p, ROOT)}: vm.{m.group(1)} không có trong MainViewModel")
    for m in re.finditer(r"\bst\.(\w+)", s):
        if m.group(1) not in state_fields | state_extra:
            errors.append(f"{os.path.relpath(p, ROOT)}: st.{m.group(1)} không có trong UiState")

# 5. enum
def block_after(s, start):
    """Nội dung trong cặp {} bắt đầu tại vị trí start (ký tự '{')."""
    depth = 0
    for i in range(start, len(s)):
        if s[i] == "{": depth += 1
        elif s[i] == "}":
            depth -= 1
            if depth == 0: return s[start + 1:i]
    return ""

enums, objects = {}, {}
for p, s in code.items():
    for m in re.finditer(r"enum class (\w+)\s*(?:\([^)]*\))?\s*\{", s):
        body = block_after(s, m.end() - 1).split(";")[0]
        body = re.sub(r"\([^)]*\)", "", body)
        enums.setdefault(m.group(1), set()).update(re.findall(r"\b([A-Z][A-Z0-9_]*)\b", body))
    for m in re.finditer(r"\bobject (\w+)\s*\{", s):
        body = block_after(s, m.end() - 1)
        objects.setdefault(m.group(1), set()).update(re.findall(r"\b(?:const )?val ([A-Z][A-Z0-9_]*)\b", body))
checked = {**enums, **{k: v for k, v in objects.items() if v}}
for p, s in code.items():
    for name, ents in checked.items():
        for m in re.finditer(r"\b" + name + r"\.([A-Z][A-Z0-9_]+)\b", s):
            if m.group(1) not in ents:
                errors.append(f"{os.path.relpath(p, ROOT)}: {name}.{m.group(1)} không tồn tại")


# 7. when phải đầy đủ (enum / sealed) — R14
def strip_keep(src):
    """Như strip_code nhưng GIỮ NGUYÊN độ dài và xuống dòng → số dòng báo lỗi đúng."""
    out, i, n = list(src), 0, len(src)
    def blank(a, b):
        for k in range(a, min(b, n)):
            if out[k] != "\n": out[k] = " "
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            j = src.find("\n", i); j = n if j < 0 else j; blank(i, j); i = j; continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2); j = n if j < 0 else j + 2; blank(i, j); i = j; continue
        if src.startswith('"""', i):
            j = src.find('"""', i + 3); j = n if j < 0 else j + 3; blank(i, j); i = j; continue
        if c == '"' or c == "'":
            q, j = c, i + 1
            while j < n and src[j] != q:
                j += 2 if src[j] == "\\" else 1
            j = min(j + 1, n); blank(i, j); i = j; continue
        i += 1
    return "".join(out)

def match_close(s, start, o, c):
    """Vị trí ký tự đóng tương ứng với ký tự mở tại start (hoặc -1)."""
    depth = 0
    for i in range(start, len(s)):
        if s[i] == o: depth += 1
        elif s[i] == c:
            depth -= 1
            if depth == 0: return i
    return -1

keep = {p: strip_keep(src) for p, src in files.items()}

# sealed: tên -> tập lớp con trực tiếp
sealed = {}
for s in keep.values():
    for m in re.finditer(r"\bsealed\s+(?:class|interface)\s+(\w+)", s):
        sealed.setdefault(m.group(1), set())
for s in keep.values():
    for m in re.finditer(r"\b(?:data\s+|enum\s+)?(?:class|object)\s+(\w+)", s):
        i = m.end()
        while i < len(s) and s[i] in " \t": i += 1
        if i < len(s) and s[i] == "<":                       # tham số kiểu
            j = match_close(s, i, "<", ">"); i = j + 1 if j > 0 else i
        while i < len(s) and s[i] in " \t": i += 1
        if i < len(s) and s[i] == "(":                       # hàm khởi tạo chính
            j = match_close(s, i, "(", ")"); i = j + 1 if j > 0 else i
        hdr = s[i:i + 200].split("{")[0].split("\n")[0]
        mm = re.match(r"\s*:\s*(.+)", hdr)
        if mm:
            for sup in re.findall(r"\b([A-Z]\w*)\b", re.sub(r"\([^)]*\)", "", mm.group(1))):
                if sup in sealed and sup != m.group(1):
                    sealed[sup].add(m.group(1))
# lớp con gián tiếp (sealed → sealed → lớp cụ thể): gộp
for _ in range(3):
    for k, v in list(sealed.items()):
        for sub in list(v):
            if sub in sealed and sealed[sub]:
                v.discard(sub); v |= sealed[sub]

def flatten_top(body):
    """Thay mọi thứ nằm trong {} () [] lồng nhau bên trong body bằng khoảng trắng (giữ \n)."""
    out, depth = [], 0
    for ch in body:
        if ch in "{([":
            depth += 1; out.append(" " if depth > 0 else ch)
        elif ch in "})]":
            depth -= 1; out.append(" ")
        else:
            out.append(ch if depth == 0 else (ch if ch == "\n" else " "))
    return "".join(out)

when_re = re.compile(r"\bwhen\s*\(")
n_when = 0
for p, s in keep.items():
    for m in when_re.finditer(s):
        op = m.end() - 1
        cp = match_close(s, op, "(", ")")
        if cp < 0: continue
        k = cp + 1
        while k < len(s) and s[k] in " \t\r\n": k += 1
        if k >= len(s) or s[k] != "{": continue
        ce = match_close(s, k, "{", "}")
        if ce < 0: continue
        body = flatten_top(s[k + 1:ce])
        if re.search(r"(?:^|[\s,])else\s*->", body): continue
        labels = []
        for lm in re.finditer(r"([^\n;>]+?)->", body):        # điều kiện nhánh = phần trước ->
            labels.append(lm.group(1).strip())
        entries, types, quals = set(), set(), set()
        for lab in labels:
            for part in lab.split(","):
                part = part.strip()
                mi = re.match(r"(?:!?is)\s+([\w.]+)", part)
                if mi: types.add(mi.group(1).split(".")[-1]); continue
                mq = re.fullmatch(r"(\w+)\.([A-Z][A-Z0-9_]*)", part)
                if mq and mq.group(1) in enums: quals.add(mq.group(1)); entries.add((mq.group(1), mq.group(2))); continue
                if re.fullmatch(r"[A-Z][A-Z0-9_]*", part): entries.add((None, part)); continue
                subs_all = {x for v in sealed.values() for x in v}
                msq = re.fullmatch(r"(\w+)\.([A-Z]\w*)", part)      # Sealed.Object (tham chiếu đối tượng có tiền tố)
                if msq and msq.group(2) in subs_all: types.add(msq.group(2)); continue
                if re.fullmatch(r"[A-Z]\w*", part) and part in subs_all: types.add(part)
        line = s.count("\n", 0, m.start()) + 1
        rel = os.path.relpath(p, ROOT)
        # enum
        if entries:
            named = {e for (q, e) in entries if q}
            enum_name = next(iter(quals)) if len(quals) == 1 else None
            if enum_name is None:
                bare = {e for (q, e) in entries if q is None}
                cands = [en for en, ents in enums.items() if bare and bare <= ents]
                if len(cands) == 1: enum_name = cands[0]
            if enum_name:
                n_when += 1
                have = {e for (q, e) in entries if q in (None, enum_name)}
                miss = enums[enum_name] - have
                if miss:
                    errors.append(f"{rel}:{line}: when trên enum {enum_name} không có else, thiếu: {', '.join(sorted(miss))}")
        # sealed
        if types:
            owner = [sn for sn, subs in sealed.items() if types & subs]
            if len(owner) == 1 and sealed[owner[0]]:
                n_when += 1
                miss = sealed[owner[0]] - types
                if miss:
                    errors.append(f"{rel}:{line}: when trên sealed {owner[0]} không có else, thiếu: {', '.join(sorted(miss))}")
print(f"[7] when không-else kiểm đủ: {n_when} khối; sealed: { {k: sorted(v) for k, v in sealed.items() if v} }")


# 8. implementor phải override đủ thành viên trừu tượng của interface — R14
ifaces = {}
for p, s in keep.items():
    for m in re.finditer(r"\binterface\s+(\w+)[^{\n]*\{", s):
        body = block_after(s, m.end() - 1)
        abstract, depth = set(), 0
        for line in body.split("\n"):
            if depth == 0:
                mm = re.match(r"\s*(?:@\w+\s+)*(fun|val|var)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)", line)
                if mm and "{" not in line and not re.search(r"\)\s*(?::\s*[\w<>?, .()-]+)?\s*=\s", line) and not re.search(r"\bval\s+\w+[^=\n]*\bget\(", line):
                    abstract.add(mm.group(2))
            depth += line.count("{") - line.count("}")
        ifaces[m.group(1)] = abstract
n_impl = 0
for p, s in keep.items():
    for m in re.finditer(r"\b(?:private\s+|internal\s+)?(class|object)\s+(\w+)", s):
        i = m.end()
        while i < len(s) and s[i] in " \t": i += 1
        if i < len(s) and s[i] == "<":
            j = match_close(s, i, "<", ">"); i = j + 1 if j > 0 else i
        while i < len(s) and s[i] in " \t": i += 1
        if i < len(s) and s[i] == "(":
            j = match_close(s, i, "(", ")"); i = j + 1 if j > 0 else i
        hm = re.match(r"\s*:\s*([^{\n]+)\{", s[i:i + 300])
        if not hm: continue
        supers = {x for x in re.findall(r"\b([A-Z]\w*)\b", re.sub(r"\([^)]*\)", "", hm.group(1)))}
        wanted = [(it, ifaces[it]) for it in supers if it in ifaces and ifaces[it]]
        if not wanted: continue
        ob = i + s[i:].index("{")
        body = block_after(s, ob)
        have = set(re.findall(r"\boverride\s+(?:fun|val|var)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)", body))
        # thành viên khai báo ngay trong hàm khởi tạo chính (class X(override val a: Int)) cũng tính
        hdr = s[m.end():i]
        have |= set(re.findall(r"\boverride\s+(?:val|var)\s+(\w+)", hdr))
        for it, need in wanted:
            n_impl += 1
            miss = need - have
            if miss:
                errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: {m.group(2)} implement {it} nhưng thiếu override: {', '.join(sorted(miss))}")
print(f"[8] implementor kiểm đủ override: {n_impl} cặp; interface: { {k: sorted(v) for k, v in ifaces.items() if v} }")

# 9. mã sản phẩm thanh toán: Kotlin == mặc định backend — R14
def kt_list(name):
    for s in code.values():
        m = re.search(r"\bval\s+" + name + r"\s*=\s*listOf\(([^)]*)\)", files[next(k for k, v in code.items() if v is s)])
        if m: return re.findall(r'"([^"]+)"', m.group(1))
    return None
if not os.path.isfile(os.path.join(ROOT, "..", "..", "backend", "server.py")):
    # R34c: repo GitHub thiếu thư mục backend/ (tải lên chưa đủ) ⇒ không đối chiếu được hằng số Kotlin với server; dừng sớm có chú thích thay vì văng lỗi
    print("::warning title=static_check dừng sớm::Repo thiếu backend/server.py - các mục [9] trở đi cần nó. Tải thư mục backend/ lên cùng cấp với app/ rồi chạy lại.")
    for _e in errors: print("LỖI:", _e)
    print(f"static_check DỪNG SỚM sau mục [8]: {len(errors)} lỗi (thiếu backend/)")
    sys.exit(1 if errors else 0)
srv = open(os.path.join(ROOT, "..", "..", "backend", "server.py"), encoding="utf-8").read()
def srv_default(var):
    m = re.search(var + r'", ""\) or \'(\{.*?\})\'\)', srv)
    return json.loads(m.group(1)) if m else None
import json
kp, ks = kt_list("BILLING_PRODUCTS"), kt_list("BILLING_SUBSCRIPTIONS")
packs, plans, subs = srv_default("CREDIT_PACKS"), srv_default("PLAN_PRODUCTS"), srv_default("SUBSCRIPTION_PRODUCTS")
if None in (kp, ks, packs, plans, subs):
    errors.append("không đọc được danh sách mã sản phẩm (BILLING_PRODUCTS/BILLING_SUBSCRIPTIONS hoặc mặc định backend)")
else:
    if set(kp) != set(packs) | set(plans):
        errors.append(f"BILLING_PRODUCTS {sorted(kp)} khác mặc định backend CREDIT_PACKS+PLAN_PRODUCTS {sorted(set(packs) | set(plans))}")
    if set(ks) != set(subs):
        errors.append(f"BILLING_SUBSCRIPTIONS {sorted(ks)} khác mặc định backend SUBSCRIPTION_PRODUCTS {sorted(subs)}")
    print(f"[9] mã sản phẩm: một lần {sorted(kp)} · đăng ký {sorted(ks)} (khớp backend)")


# 10. dùng hàm kotlin.math mà thiếu import — R16
MATH_FUNS = ["abs", "sqrt", "max", "min", "roundToInt", "roundToLong", "pow", "hypot", "sin", "cos", "tan", "atan2", "atan", "acos", "asin",
             "floor", "ceil", "exp", "ln", "log10", "log2", "sign", "truncate", "cbrt", "sinh", "cosh", "tanh"]
EXT_STYLE = {"roundToInt", "roundToLong", "pow", "sign"}      # dạng x.roundToInt() / x.pow(2)
n_math = 0
for p, s in keep.items():
    imports = set(re.findall(r"^import\s+kotlin\.math\.(\w+|\*)\s*$", s, re.M))
    declared = set(re.findall(r"\bfun\s+(?:[\w<>?, .]+\.)?(\w+)\s*\(", s))
    for name in MATH_FUNS:
        if "*" in imports or name in imports or name in declared:
            continue
        pats = [r"(?<![\w.])" + name + r"\s*\("] if name not in EXT_STYLE else [r"(?<!Math)(?<!math)\." + name + r"\s*\(", r"(?<![\w.])" + name + r"\s*\("]
        found_line = None
        for pat in pats:
            m = re.search(pat, s)
            if m:
                found_line = s.count(chr(10), 0, m.start()) + 1
                break
        if found_line is None:      # mã nằm TRONG chuỗi mẫu "...${x.roundToInt()}..." (strip_keep đã xóa) -> đọc riêng từ văn bản gốc
            orig = files[p]
            for tm in re.finditer(r"\$\{([^{}]*)\}", orig):
                if any(re.search(pat, tm.group(1)) for pat in pats):
                    found_line = orig.count(chr(10), 0, tm.start()) + 1
                    break
        if found_line is not None:
            n_math += 1
            errors.append(f"{os.path.relpath(p, ROOT)}:{found_line}: dùng {name}() của kotlin.math nhưng thiếu `import kotlin.math.{name}`")
print(f"[10] kiểm import kotlin.math: {n_math} lỗi trong {len(keep)} tệp")


# 11. thiếu import kiểu của dự án — R17
top_names = {}
for pkg_, names_ in decl.items():
    for n_ in names_:
        if n_[:1].isupper(): top_names.setdefault(n_, set()).add(pkg_)
n_imp = 0
for p, s in keep.items():
    mpk = re.search(r"^package\s+([\w.]+)", files[p], re.M)
    pkg = mpk.group(1) if mpk else ""
    imported, stars = set(), set()
    for im in re.finditer(r"^import\s+([\w.]+?)(\.\*)?(?:\s+as\s+(\w+))?\s*$", files[p], re.M):
        if im.group(2): stars.add(im.group(1))
        else: imported.add(im.group(3) or im.group(1).split(".")[-1])
    seen = set()
    for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\b", s):
        t = m.group(1)
        if t in seen or t not in top_names: continue
        seen.add(t)
        if pkg in top_names[t] or t in imported or (stars & top_names[t]): continue
        decl_here = re.search(r"(?m)^\s*(?:@\w+\s+)*(?:(?:private|internal|public|const|override|data|enum|sealed|abstract|open|inner|lateinit)\s+)*"
                              r"(?:class|object|interface|typealias|val|var|fun)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?" + t + r"\b", s) \
            or re.search(r"(?m)^\s*" + t + r"\s*(?:\(|,|;|$)", s) \
            or re.search(r"\b(?:val|var)\s+" + t + r"\b", s) or re.search(r"[(,]\s*" + t + r"\s*:", s)
        if decl_here: continue
        n_imp += 1
        errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: dùng {t} (khai báo ở {', '.join(sorted(top_names[t]))}) nhưng thiếu import")
print(f"[11] kiểm import kiểu dự án: {n_imp} lỗi")

# 12. Object.thanhVien phải tồn tại — R17
obj_members = {}
mem_re = re.compile(r"^\s*(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:private|internal|public|protected|const|override|inline|operator|infix|tailrec|suspend|lateinit|abstract|open|data|enum|sealed)\s+)*"
                    r"(?:fun|val|var|class|object|interface|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)")
for p, s in keep.items():
    for m in re.finditer(r"(?<![\w.])object\s+(\w+)[^{\n]*\{", s):
        body = block_after(s, m.end() - 1)
        names, depth = set(), 0
        for line in body.split("\n"):
            if depth == 0:
                mm = mem_re.match(line)
                if mm: names.add(mm.group(1))
                # tham số khai báo trong constructor / thuộc tính kiểu `val x = ...` đã được mem_re bắt
            depth += line.count("{") - line.count("}")
        obj_members.setdefault(m.group(1), set()).update(names)
ALWAYS = {"javaClass", "hashCode", "toString", "equals", "let", "also", "apply", "run", "takeIf", "takeUnless", "with", "to"}
n_mem = 0
for p, s in keep.items():
    for oname, mem in obj_members.items():
        if not mem: continue
        for m in re.finditer(r"(?<![\w.])" + oname + r"\.(\w+)", s):
            if m.group(1) in mem or m.group(1) in ALWAYS: continue
            n_mem += 1
            errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: {oname}.{m.group(1)} không phải thành viên của object {oname}")
print(f"[12] kiểm Object.thanhVien: {len(obj_members)} object, {n_mem} lỗi")


# 11b. hàm / thuộc tính cấp cao (kể cả hàm mở rộng) của dự án dùng ở package khác mà thiếu import — R17
top_fun = {}      # tên -> {gói: là-hàm-mở-rộng}
for p, s in keep.items():
    mpk = re.search(r"^package\s+([\w.]+)", files[p], re.M)
    if not mpk: continue
    for m in re.finditer(r"(?m)^(?!private)(?:(?:public|internal|inline|operator|infix|suspend|tailrec)\s+)*fun\s+(?:<[^>]*>\s*)?(?:([\w.<>?, ]+)\.)?([a-z]\w*)\s*\(", s):
        top_fun.setdefault(m.group(2), {})[mpk.group(1)] = bool(m.group(1))
n_fun = 0
for p, s in keep.items():
    mpk = re.search(r"^package\s+([\w.]+)", files[p], re.M)
    pkg = mpk.group(1) if mpk else ""
    imported = set(); stars = set()
    for im in re.finditer(r"^import\s+([\w.]+?)(\.\*)?(?:\s+as\s+(\w+))?\s*$", files[p], re.M):
        if im.group(2): stars.add(im.group(1))
        else: imported.add(im.group(3) or im.group(1).split(".")[-1])
    for name, pk in top_fun.items():
        if pkg in pk or name in imported or (stars & set(pk)): continue
        if re.search(r"\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?" + name + r"\s*\(", s): continue        # tệp tự khai báo (thành viên/cục bộ)
        is_ext = any(pk.values())
        pat = (r"(?<![\w])" + name + r"\s*\(") if not is_ext else (r"\." + name + r"\s*\(")
        if not is_ext:
            pat = r"(?<![\w.])" + name + r"\s*\("
        m = re.search(pat, s)
        if m:
            n_fun += 1
            errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: dùng hàm cấp cao {name}() (khai báo ở {', '.join(sorted(pk))}) nhưng thiếu import")
print(f"[11b] kiểm import hàm cấp cao: {len(top_fun)} hàm, {n_fun} lỗi")


# 13. kiểu thư viện ngoài thiếu import — R17
DEFAULT_TYPES = set("""String Int Long Float Double Boolean Byte Short Char Unit Nothing Any Array IntArray FloatArray ByteArray LongArray DoubleArray BooleanArray CharArray ShortArray
List MutableList Map MutableMap Set MutableSet Pair Triple Exception RuntimeException IllegalStateException IllegalArgumentException UnsupportedOperationException
IndexOutOfBoundsException NumberFormatException ArithmeticException NullPointerException ClassCastException OutOfMemoryError StackOverflowError AssertionError Throwable Error Math System Thread Runnable StringBuilder
Regex Result Iterable Sequence Comparable CharSequence Number Enum Volatile Synchronized JvmStatic JvmOverloads JvmField JvmName Suppress Deprecated OptIn ArrayList HashMap LinkedHashMap HashSet
LinkedHashSet Class Object Character Process AutoCloseable Closeable Iterator MutableIterator Collection MutableCollection Lazy Function Comparator Appendable Cloneable Void
Integer Override Throws Strictfp Transient Target Retention Repeatable MustBeDocumented Annotation ReplaceWith IntRange LongRange CharRange ClosedRange Entry
ArrayDeque StringBuffer Locale Random UInt ULong UByte UShort Charsets ProcessBuilder Runtime ClosedFloatingPointRange Regex MatchResult StackTraceElement RegexOption MutableEntry""".split())
n_ext = 0
for p, s in keep.items():
    imported = set()
    for im in re.finditer(r"^import\s+([\w.]+?)(\.\*)?(?:\s+as\s+(\w+))?\s*$", files[p], re.M):
        if not im.group(2): imported.add(im.group(3) or im.group(1).split(".")[-1])
    star_import = bool(re.search(r"^import\s+(?!com\.aiphoto)[\w.]+\.\*\s*$", files[p], re.M))
    if star_import: continue               # không biết được nguồn của import sao ngoài dự án -> không kết luận
    pk = re.search(r"^package\s+([\w.]+)", files[p], re.M).group(1)
    declared_any = set(re.findall(r"\b(?:class|object|interface|typealias)\s+([A-Z]\w*)", s))
    seen = set()
    for m in re.finditer(r"(?<![\w.])@?([A-Z][a-z][A-Za-z0-9_]*)\b", s):
        t = m.group(1)
        if t in seen or t in DEFAULT_TYPES or t in imported or t in declared_any: continue
        seen.add(t)
        if t in top_names and pk in top_names[t]: continue            # cùng package dự án
        if t in top_names: continue                                     # đã được kiểm ở mục 11
        n_ext += 1
        errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: kiểu {t} không có nguồn (thiếu import?)")
print(f"[13] kiểm kiểu thư viện ngoài thiếu import: {n_ext} lỗi")


# 14. hàm Compose / coroutines viết thường + toán tử uỷ quyền `by` thiếu import — R17
L_ = "androidx.compose.foundation.layout."
F_ = "androidx.compose.foundation."
R_ = "androidx.compose.runtime."
LIB_FUN = {
    "padding": L_ + "padding", "fillMaxWidth": L_ + "fillMaxWidth", "fillMaxSize": L_ + "fillMaxSize", "fillMaxHeight": L_ + "fillMaxHeight",
    "size": L_ + "size", "height": L_ + "height", "width": L_ + "width", "heightIn": L_ + "heightIn", "widthIn": L_ + "widthIn",
    "offset": L_ + "offset", "aspectRatio": L_ + "aspectRatio", "wrapContentSize": L_ + "wrapContentSize", "wrapContentWidth": L_ + "wrapContentWidth",
    "verticalScroll": F_ + "verticalScroll", "horizontalScroll": F_ + "horizontalScroll", "clickable": F_ + "clickable", "background": F_ + "background",
    "border": F_ + "border", "rememberScrollState": F_ + "rememberScrollState",
    "clip": "androidx.compose.ui.draw.clip", "alpha": "androidx.compose.ui.draw.alpha", "pointerInput": "androidx.compose.ui.input.pointer.pointerInput",
    "remember": R_ + "remember", "mutableStateOf": R_ + "mutableStateOf", "derivedStateOf": R_ + "derivedStateOf", "collectAsState": R_ + "collectAsState",
    "rememberCoroutineScope": R_ + "rememberCoroutineScope", "mutableFloatStateOf": R_ + "mutableFloatStateOf", "mutableIntStateOf": R_ + "mutableIntStateOf",
    "launch": "kotlinx.coroutines.launch", "withContext": "kotlinx.coroutines.withContext", "delay": "kotlinx.coroutines.delay",
    "async": "kotlinx.coroutines.async", "runBlocking": "kotlinx.coroutines.runBlocking",
}
CALL_STYLE = {"alpha", "clip", "border", "background", "clickable"}                  # chỉ tính dạng gọi `.name(` / `.name {`
DP_STYLE = {"size", "height", "width", "heightIn", "widthIn", "offset", "padding"}     # chỉ tính khi đối số có `.dp`
n_lib = 0
for p, s in keep.items():
    imports = set(re.findall(r"^import\s+([\w.]+)\s*$", files[p], re.M))
    stars = set(re.findall(r"^import\s+([\w.]+)\.\*\s*$", files[p], re.M))
    for name, need in LIB_FUN.items():
        if need in imports or need.rsplit(".", 1)[0] in stars: continue
        if re.search(r"\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?" + name + r"\s*\(", s): continue
        if name in DP_STYLE:            # Modifier.size(48.dp) khác ByteArrayOutputStream.size(): chỉ tính khi đối số có kích thước .dp
            pat = r"\." + name + r"\s*\([^()]*\.dp"
        elif name == "launch":          # coroutines: launch { … } / launch(Dispatchers.IO) { … }; ActivityResultLauncher.launch(x) KHÔNG tính
            pat = r"(?<![\w])launch\s*(?:\([^()]*\)\s*)?\{"
        elif name in CALL_STYLE:
            pat = r"\." + name + r"\s*[({]"
        else:
            pat = r"(?<![\w])" + name + r"\s*[({]"
        m = re.search(pat, s)
        if m:
            n_lib += 1
            errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: dùng {name}() nhưng thiếu `import {need}`")
    # toán tử uỷ quyền: `val x by remember {…}` cần getValue; `var x by …` cần cả setValue
    for m in re.finditer(r"\b(val|var)\s+\w+\s*(?::[^=\n]+?)?\s+by\s+(?:remember|mutableStateOf|rememberSaveable|derivedStateOf|[\w.]+\.collectAsState)", s):
        needs = ["getValue"] + (["setValue"] if m.group(1) == "var" else [])
        for op in needs:
            if R_ + op not in imports and R_.rstrip(".") not in stars:
                n_lib += 1
                errors.append(f"{os.path.relpath(p, ROOT)}:{s.count(chr(10), 0, m.start()) + 1}: `{m.group(1)} … by` cần `import {R_}{op}`")
print(f"[14] kiểm hàm Compose/coroutines + toán tử by thiếu import: {n_lib} lỗi")

# ---- 15. (R23) công tắc tính phí được nối đủ
n_mon = 0
for p, s in files.items():
    rel = os.path.relpath(p, ROOT)
    if os.sep + "main" + os.sep not in p or p.endswith(os.sep + "Watermark.kt"):
        continue
    lines = s.split("\n")
    for i, ln in enumerate(lines):
        code = ln.split("//")[0] if '"' not in ln else ln
        if "Watermark.apply(" in code and "Monetization.needsWatermark(" not in code:
            n_mon += 1
            errors.append(f"{rel}:{i + 1}: Watermark.apply() không được bọc bởi Monetization.needsWatermark()")
    if os.sep + "ui" + os.sep in p:
        gated = ("TeamSection(", "vm.loadBillingProducts", "vm.buy(", "vm.buySubscription", "vm.restorePurchases", "Credits còn lại", '"Credits: ')
        for i, ln in enumerate(lines):
            if ln.lstrip().startswith("//") or ln.lstrip().startswith("fun ") or not any(g in ln for g in gated):
                continue
            ok_line = "Monetization.showPaidUi()" in ln
            indent = len(ln) - len(ln.lstrip())
            j = i - 1
            while not ok_line and j >= 0 and indent > 0:
                lj = lines[j]
                ij = len(lj) - len(lj.lstrip())
                if lj.strip() and ij < indent:
                    indent = ij
                    if "Monetization.showPaidUi()" in lj:
                        ok_line = True
                j -= 1
            if not ok_line:
                n_mon += 1
                errors.append(f"{rel}:{i + 1}: giao diện tiền không nằm trong `if (Monetization.showPaidUi() …)`")
    # (R23) đường gọi AI đám mây qua máy chủ của chủ app phải đi qua Monetization.proxyAiUsable (bản dùng thử: máy chủ mặc định KHÔNG cung cấp AI)
    for i, ln in enumerate(lines):
        if '"token:proxy" ->' in ln and "Monetization.proxyAiUsable(" not in ln:
            n_mon += 1
            errors.append(f"{rel}:{i + 1}: điều kiện nhà cung cấp proxy_cloud (\"token:proxy\") không đi qua Monetization.proxyAiUsable()")
        if "ProxyBackend.editPlan(" in ln and "fun " not in ln and not any("Monetization.proxyAiUsable(" in lines[j] for j in range(max(0, i - 4), i)):
            n_mon += 1
            errors.append(f"{rel}:{i + 1}: gọi ProxyBackend.editPlan() mà 4 dòng trước không kiểm Monetization.proxyAiUsable()")
print(f"[15] công tắc Monetization được nối đủ: {n_mon} lỗi")

# ---- 16. (R24) kênh báo lỗi cho tester được nối đủ
n_diag = 0
def _src(name):
    for p_, s_ in files.items():
        if p_.endswith(os.sep + name) and os.sep + "main" + os.sep in p_:
            return os.path.relpath(p_, ROOT), s_
    return name, None
def _body(src, head):
    """Thân (theo ngoặc nhọn) của hàm bắt đầu bằng `head`."""
    i = src.find(head)
    if i < 0:
        return None
    j = src.find("{", i)
    d = 0
    for k in range(j, len(src)):
        if src[k] == "{": d += 1
        elif src[k] == "}":
            d -= 1
            if d == 0:
                return src[j:k + 1]
    return None
rel_a, act = _src("MainActivity.kt")
if act is None or "CrashHandler.install(CrashStore.at(" not in act or act.find("CrashHandler.install(") > act.find("setContent {"):
    n_diag += 1; errors.append(f"{rel_a}: thiếu `CrashHandler.install(CrashStore.at(filesDir))` trước setContent (không bắt được lỗi đóng đột ngột)")
rel_v, vmsrc = _src("MainViewModel.kt")
if vmsrc is None:
    n_diag += 1; errors.append("không thấy MainViewModel.kt")
else:
    b = _body(vmsrc, "private fun ui(block")
    if b is None or "DiagLog.add(" not in b:
        n_diag += 1; errors.append(f"{rel_v}: ui() không ghi DiagLog (nhật ký báo lỗi mất trạng thái)")
    b = _body(vmsrc, "private fun launchTask(")
    if b is None or b.count('DiagLog.add("lỗi"') < 2 or 'DiagLog.add("việc"' not in b:
        n_diag += 1; errors.append(f"{rel_v}: launchTask() không ghi việc/lỗi vào DiagLog (cả nhánh hết bộ nhớ lẫn lỗi khác)")
    b = _body(vmsrc, "init {")
    if b is None or "checkLastExit()" not in b:
        n_diag += 1; errors.append(f"{rel_v}: init không gọi checkLastExit() (lần trước app đóng đột ngột sẽ không được báo)")
    b = _body(vmsrc, "private fun buildDiagReport(")
    if b is None:
        n_diag += 1; errors.append(f"{rel_v}: thiếu buildDiagReport()")
    else:
        for m in re.finditer(r"st\.(cloudKey|proxyToken|proxyUrl|sdUrl)\b(?!\.isNotBlank\(\))", b):
            line = b.count("\n", 0, m.start())
            seg = b.split("\n")[line]
            if m.group(1) in ("proxyUrl", "sdUrl") and "DiagReport.hostOf(" in seg:
                continue
            n_diag += 1; errors.append(f"{rel_v}: buildDiagReport() dùng st.{m.group(1)} thô (chỉ được .isNotBlank() hoặc DiagReport.hostOf())")
    for p_, s_ in files.items():
        if os.sep + "main" + os.sep in p_ and not p_.endswith(os.sep + "Diagnostics.kt") and re.search(r"(?<![A-Za-z.])CrashStore\(", s_):
            n_diag += 1; errors.append(f"{os.path.relpath(p_, ROOT)}: tạo CrashStore( trực tiếp - phải dùng CrashStore.at(filesDir) để MainActivity và VM chung thư mục")
rel_e, ed = _src("EditorScreen.kt")
if ed is None or "vm.prepareDiagReport()" not in ed or not re.search(r"if \(st\.diagReport != null\) DiagDialog\(", ed):
    n_diag += 1; errors.append(f"{rel_e}: thiếu nút `vm.prepareDiagReport()` hoặc hộp `if (st.diagReport != null) DiagDialog(`")
print(f"[16] kênh báo lỗi (R24) được nối đủ: {n_diag} lỗi")

# ---- 17. (R24) Auto Frame + Di chuyển vật thể được nối đủ
n_af = 0
rel_i, ie = _src("ImageEngine.kt")
if ie is None or "AutoFrame.cropRect(" not in ie or "AutoFrame.parseArg(" not in ie or "(w - cw) / 2" in ie:
    n_af += 1; errors.append(f"{rel_i}: cropRatio phải dùng AutoFrame.cropRect/parseArg (khung xem trước = khung cắt thật), không tự tính lại")
rel_m, em = _src("EditModels.kt")
if em is None or "AutoFrame.normalizeArg(" not in em:
    n_af += 1; errors.append(f"{rel_m}: CROP_RATIO phải giữ arg Auto Frame qua AutoFrame.normalizeArg()")
if vmsrc is not None:
    b = _body(vmsrc, "fun run()")
    if b is None or "AutoFrameIntent.detect(" not in b or "autoFrame(" not in b or b.find("autoFrame(") > b.find("runStrangerRemoval()"):
        n_af += 1; errors.append(f"{rel_v}: run() phải chuyển yêu cầu cắt theo chủ thể sang autoFrame() trước các nhánh khác")
    b = _body(vmsrc, "fun autoFrame(")
    if b is None or "AutoFrame.suggest(" not in b or "bakeInternal(" not in b or "pushUndo()" not in b or b.find("pushUndo()") > b.find("bakeInternal("):
        n_af += 1; errors.append(f"{rel_v}: autoFrame() phải suggest rồi pushUndo() TRƯỚC bakeInternal() (hoàn tác được)")
    b = _body(vmsrc, "fun moveSelection()")
    if b is None or any(k not in b for k in ("MoveObject.cutout(", "removeWithRouting(", "pushUndo()", "Panel.LAYERS", "MoveObject.dilate(")):
        n_af += 1; errors.append(f"{rel_v}: moveSelection() thiếu bước: tách (MoveObject.cutout), nới + xóa chỗ cũ (dilate + removeWithRouting), pushUndo, mở thẻ lớp")
    b = _body(vmsrc, "fun selectionAction(")
    if b is None or 'kind == "move"' not in b or "moveSelection()" not in b:
        n_af += 1; errors.append(f"{rel_v}: selectionAction() không chuyển \"move\" sang moveSelection()")
rel_p, pn = _src("Panels.kt")
if pn is None or "vm.autoFrame(null)" not in pn or "vm.autoFrame(r)" not in pn:
    n_af += 1; errors.append(f"{rel_p}: thiếu nút Auto Frame (vm.autoFrame(null) siết khung và vm.autoFrame(r) theo tỉ lệ)")
if ed is None or '"move" to "Di chuyển"' not in ed:
    n_af += 1; errors.append(f"{rel_e}: thiếu nút \"Di chuyển\" trong thanh hành động sau khi chạm chọn")
print(f"[17] Auto Frame + Di chuyển vật thể được nối đủ: {n_af} lỗi")

# ---- 18. (R25) Làm nét lại (Unblur) + Khử moiré được nối đủ
n_ub = 0
if ie is None or "Moire.applyReport(" not in ie or "Deblur.apply(" not in ie or ie.find("Moire.applyReport(") > ie.find("Deblur.apply("):
    n_ub += 1; errors.append(f"{rel_i}: process() phải gọi Moire.applyReport rồi mới Deblur.apply (làm nét trước sẽ khuếch đại vân moiré)")
if em is None or "Deblur.canonical(" not in em or "OpType.UNBLUR ->" not in em:
    n_ub += 1; errors.append(f"{rel_m}: sanitized()/describe() phải xử lý UNBLUR (arg qua Deblur.canonical)")
if vmsrc is not None:
    bt = re.search(r"val BAKE_TYPES = setOf\((.*?)\)\s*\n", vmsrc, re.S)
    if bt is None or "OpType.UNBLUR" not in bt.group(1) or "OpType.MOIRE" not in bt.group(1):
        n_ub += 1; errors.append(f"{rel_v}: BAKE_TYPES phải có UNBLUR và MOIRE (nặng: áp một lần vào ảnh nền, không chạy lại mỗi lần dựng lớp)")
    # R30g: mọi chỗ gán perf đều đi qua applyPerf() (khởi động, sau đo máy, sau khi tải cấu hình định tuyến) và applyPerf() đặt Moire.capDefault theo hạng
    if "Moire.capDefault = Moire.capFor(perf.tier == Tier.LOW)" not in (_body(vmsrc, "private fun applyPerf(") or "") or vmsrc.count("applyPerf()") < 3:
        n_ub += 1; errors.append(f"{rel_v}: Moire.capDefault phải đặt theo hạng trong applyPerf() và applyPerf() phải được gọi ở khởi động, sau khi đo máy và sau khi tải cấu hình định tuyến")
rel_pl, pl = _src("RuleBasedPlanner.kt")
if pl is None or "add(UNBLUR" not in pl or "add(MOIRE" not in pl or pl.find("add(UNBLUR") > pl.find("add(MOTION_BLUR") or pl.find("add(UNBLUR") > pl.find("add(SHARPEN, mag(0.5f))"):
    n_ub += 1; errors.append(f"{rel_pl}: luật UNBLUR/MOIRE phải đứng TRƯỚC luật motion blur / làm nét (nếu không \"remove motion blur\", \"làm nét lại\" bị luật cũ ăn từ khóa)")
rel_lp, lp = _src("LlmPrompts.kt")
if lp is None or "\nunblur: value" not in lp or "\nmoire: value" not in lp:
    n_ub += 1; errors.append(f"{rel_lp}: prompt LLM phải liệt kê unblur và moire (và cập nhật tools/verify_ports/llm_prompts.py)")
print(f"[18] Làm nét lại + Khử moiré được nối đủ: {n_ub} lỗi")

# ---- 19. (R25) Phong cách tranh (STYLE) + AI toàn ảnh (WholeEditIntent) + Hòa màu vật vào nền (Harmonize) được nối đủ
n_st = 0
if ie is None or "Stylize.apply(" not in ie or "OpType.STYLE" not in ie:
    n_st += 1; errors.append(f"{rel_i}: process() phải áp OpType.STYLE qua Stylize.apply")
if em is None or "Stylize.canonical(" not in em or "OpType.STYLE ->" not in em or "== OpType.STYLE" not in em:
    n_st += 1; errors.append(f"{rel_m}: sanitized()/describe()/mergeOps phải xử lý STYLE (arg qua Stylize.canonical, phép sau thay phép trước)")
if pl is None or "add(STYLE" not in pl:
    n_st += 1; errors.append(f"{rel_pl}: planner thiếu luật STYLE (sơn dầu / hoạt hình / màu nước chạy ngay trên máy)")
if lp is None or "\nstyle: value" not in lp:
    n_st += 1; errors.append(f"{rel_lp}: prompt LLM phải liệt kê style (và cập nhật tools/verify_ports/llm_prompts.py)")
rel_gi, gi = _src("GenIntent.kt")
if gi is None or "STYLE_CONVERT" not in gi:
    n_st += 1; errors.append(f"{rel_gi}: GenIntent phải chặn \"biến ảnh thành tranh sơn dầu\" (không tô vùng) khỏi luồng thêm vật thể")
if vmsrc is not None:
    b = _body(vmsrc, "fun run()")
    if b is None or "WholeEditIntent.detect(" not in b or "runWholeEdit(" not in b or b.find("runWholeEdit(") > b.find("runGenerative("):
        n_st += 1; errors.append(f"{rel_v}: run() phải chuyển yêu cầu xóa phản chiếu / bóng đổ / đổi phong cách sang runWholeEdit() TRƯỚC runGenerative() (\"xóa phản chiếu\" chứa từ \"xóa\")")
    b = _body(vmsrc, "fun runWholeEdit(")
    if b is None or "fillWithRouting(" not in b or "instructionOnly" not in b or "offerPatch(" not in b:
        n_st += 1; errors.append(f"{rel_v}: runWholeEdit() phải đi qua fillWithRouting(instructionOnly) và trả kết quả bằng offerPatch (chờ người dùng Áp dụng)")
rel_c, cm = _src("Compositor.kt")
if cm is None or "Harmonize.match(" not in cm or "l.harmonize" not in cm:
    n_st += 1; errors.append(f"{rel_c}: applyOverlay phải gọi Harmonize.match theo OverlayLayer.harmonize")
rel_pc, pc = _src("ProjectCodec.kt")
if pc is None or pc.count("harmonize") < 2:
    n_st += 1; errors.append(f"{rel_pc}: harmonize phải được ghi VÀ đọc lại trong phiên làm việc")
if pn is None or "harmonize" not in pn:
    n_st += 1; errors.append(f"{rel_p}: thiếu thanh trượt \"Hòa màu với nền\" cho lớp ảnh phủ")
print(f"[19] Phong cách tranh + AI toàn ảnh + Hòa màu được nối đủ: {n_st} lỗi")

# ---- 20. (R26) Phác thảo → ảnh (Sketch) được nối đủ
n_sk = 0
if vmsrc is not None:
    b = _body(vmsrc, "fun run()")
    if b is None or "PaintMode.SKETCH" not in b or "runSketch(" not in b or b.find("runSketch(") > b.find("autoFrame("):
        n_sk += 1; errors.append(f"{rel_v}: run() phải chuyển chế độ Phác thảo sang runSketch() TRƯỚC mọi nhánh hiểu ý khác")
    b = _body(vmsrc, "fun runSketch(")
    if b is None or any(k not in b for k in ("Sketch.rasterize(", "Sketch.mask(", "Sketch.overlay(", "Sketch.instruction(", "Sketch.sdPrompt(", "fillWithRouting(", "offerPatch(")):
        n_sk += 1; errors.append(f"{rel_v}: runSketch() thiếu bước: vẽ nét (rasterize), mặt nạ (mask), ảnh dẫn (overlay), câu lệnh (instruction / sdPrompt), fillWithRouting, offerPatch")
    elif "offerPatch(GenKind.FILL, base," not in b:
        n_sk += 1; errors.append(f"{rel_v}: runSketch() phải so lớp vá với ảnh GỐC (base), không phải ảnh dẫn có nét phác")
    b = _body(vmsrc, "fun beginStroke(")
    if b is None or "Sketch.alignColors(" not in b or "strokeColors" not in b:
        n_sk += 1; errors.append(f"{rel_v}: beginStroke() phải ghi màu nét ở chế độ Phác thảo (đồng bộ bằng Sketch.alignColors)")
    b = _body(vmsrc, "fun undoStroke(")
    if b is None or "strokeColors" not in b:
        n_sk += 1; errors.append(f"{rel_v}: undoStroke() phải bỏ cả màu của nét cuối")
rel_e2, ed2 = _src("EditorScreen.kt")
if ed2 is None or "Sketch.PALETTE" not in ed2 or "vm.setSketchColor(" not in ed2 or "Vẽ thành ảnh" not in ed2 or "sketchColors" not in ed2:
    n_sk += 1; errors.append(f"{rel_e2}: thiếu bảng màu / vẽ nét có màu / nút \"Vẽ thành ảnh\" cho chế độ Phác thảo")
if pn is None or "PaintMode.SKETCH" not in pn:
    n_sk += 1; errors.append(f"{rel_p}: thiếu chip \"Phác thảo → ảnh\"")
print(f"[20] Phác thảo → ảnh được nối đủ: {n_sk} lỗi")

# ---- 21. (R27) "Giữ nguyên X" (ProtectIntent) được nối đủ
n_pt = 0
if vmsrc is not None:
    b = _body(vmsrc, "fun runClassic(")
    if b is None or "ProtectIntent.split(" not in b or "planPrompt" not in b:
        n_pt += 1; errors.append(f"{rel_v}: runClassic() phải tách cụm \"giữ nguyên…\" bằng ProtectIntent.split() và dùng planPrompt")
    else:
        for k in ("localVisionPlan(img, planPrompt)", "ProxyBackend.editPlan(st0.proxyUrl, st0.proxyToken, img, planPrompt", "PromptPlanner.plan(planPrompt"):
            if k not in b:
                n_pt += 1; errors.append(f"{rel_v}: runClassic() phải đưa phần lệnh đã cắt cụm giữ nguyên (planPrompt) cho bộ hiểu ý: thiếu `{k}`")
        i = b.find("if (protectKey != null)")
        pb = b[i:] if i >= 0 else ""
        if i < 0 or "bakeOps = emptyList()" not in pb or "maskForProtect(" not in pb or "Chưa chỉnh gì: không dựng được vùng cần giữ nguyên" not in pb or "return@launchTask" not in pb:
            n_pt += 1; errors.append(f"{rel_v}: runClassic() thiếu khối giữ nguyên: bỏ phép bake, dựng mặt nạ bằng maskForProtect, TỪ CHỐI (return) khi không dựng được")
        if "mask = protectMask" not in b or "scope = if (protectMask != null) protectKey else null" not in b:
            n_pt += 1; errors.append(f"{rel_v}: lớp chỉnh toàn cục phải mang mặt nạ giữ nguyên (mask = protectMask) và scope = protectKey để dựng lại khi đổi ảnh nền")
    b = _body(vmsrc, "fun maskForScope(")
    if b is None or "Scope.isProtect(scope)" not in b or "maskForProtect(" not in b:
        n_pt += 1; errors.append(f"{rel_v}: maskForScope() phải xử lý chuỗi vùng not:… qua maskForProtect()")
    b = _body(vmsrc, "fun maskForProtect(")
    if b is None or "!m.invert" not in b or "MaskRenderer.render(" not in b or "?: return null" not in b:
        n_pt += 1; errors.append(f"{rel_v}: maskForProtect() phải đảo mặt nạ, hợp nhiều vùng bằng MaskRenderer.render và trả null khi một vùng không dựng được")
rel_em, em = _src("EditModels.kt")
if em is None or "Scope.valid(s.scope)" not in em or "NOT_PREFIX" not in em or "fun protectedOf(" not in em:
    n_pt += 1; errors.append(f"{rel_em}: Scope phải có NOT_PREFIX/protectedOf và normalizeScoped phải dùng Scope.valid()")
rel_pi, pis = _src("ProtectIntent.kt")
if pis is None or "fun split(" not in pis:
    n_pt += 1; errors.append(f"{rel_pi}: thiếu ProtectIntent.split()")
print(f"[21] Giữ nguyên vùng (ProtectIntent) được nối đủ: {n_pt} lỗi")

# ---- 22. (R28) Best Take (chọn khuôn mặt đẹp nhất từ nhiều ảnh) được nối đủ
n_bt = 0
if vmsrc is not None:
    b = _body(vmsrc, "fun runBestTake(")
    if b is None or any(k not in b for k in ("BestTake.plan(", "BestTake.alignShift(", "BestTake.applyFace(", "BestTake.sharpness(", "decodeBestTakeFrame(", "offerPatch(")):
        n_bt += 1; errors.append(f"{rel_v}: runBestTake() thiếu bước: plan (chọn mặt), alignShift (căn khung), sharpness, applyFace (ghép), decodeBestTakeFrame, offerPatch")
    else:
        if "offerPatch(GenKind.FILL, base," not in b:
            n_bt += 1; errors.append(f"{rel_v}: runBestTake() phải so lớp vá với ảnh GỐC (base) để hoàn tác được")
        if b.count("decodeBestTakeFrame(") < 2 or "recycle()" not in b:
            n_bt += 1; errors.append(f"{rel_v}: runBestTake() phải giải mã ảnh phụ 2 lượt (đo rồi chỉ giải mã lại khung được chọn) và recycle() từng ảnh để máy yếu không hết RAM")
        if "ensureFace()" not in b or "face_landmarker.task" not in b:
            n_bt += 1; errors.append(f"{rel_v}: runBestTake() phải báo rõ khi thiếu model face_landmarker.task")
    b = _body(vmsrc, "fun decodeBestTakeFrame(")
    if b is None or "BestTake.sameFraming(" not in b or "createScaledBitmap(" not in b:
        n_bt += 1; errors.append(f"{rel_v}: decodeBestTakeFrame() phải kiểm tra cùng khung hình (sameFraming) và đưa ảnh phụ về đúng cỡ ảnh gốc")
    b = _body(vmsrc, "fun addBestTakeUris(")
    if b is None or "BestTake.MAX_FRAMES" not in b or ".distinct()" not in b:
        n_bt += 1; errors.append(f"{rel_v}: addBestTakeUris() phải loại trùng và giới hạn BestTake.MAX_FRAMES ảnh phụ")
    b = _body(vmsrc, "fun setBackgroundOnly(")
    if b is None or "bestTakeUris = emptyList()" not in b:
        n_bt += 1; errors.append(f"{rel_v}: setBackgroundOnly() phải xoá bestTakeUris khi đổi ảnh nền (ảnh phụ thuộc cảnh cũ)")
if pn is None or "PickMultipleVisualMedia(BestTake.MAX_FRAMES)" not in pn or "vm.addBestTakeUris(" not in pn or "vm.runBestTake()" not in pn or "vm.clearBestTake()" not in pn or "Chọn mặt đẹp nhất" not in pn:
    n_bt += 1; errors.append(f"{rel_p}: AiPanel thiếu hàng Best Take (chọn ảnh phụ, \"Chọn mặt đẹp nhất\", \"Bỏ ảnh phụ\")")
rel_bt, bts = _src("BestTake.kt")
if bts is None or any(k not in bts for k in ("fun plan(", "fun applyFace(", "fun alignShift(", "fun sameFraming(", "const val MAX_FRAMES")):
    n_bt += 1; errors.append(f"{rel_bt}: thiếu plan / applyFace / alignShift / sameFraming / MAX_FRAMES")
print(f"[22] Best Take được nối đủ: {n_bt} lỗi")

# ---- 23. (R29) Reframe 2.5D (đổi góc nhìn nhẹ từ một ảnh, độ sâu giả) được nối đủ
n_rf = 0
if vmsrc is not None:
    b = _body(vmsrc, "fun runReframe(")
    if b is None or any(k not in b for k in ("Reframe.depthMap(", "Reframe.shift(", "Reframe.render(", "Reframe.describe(", "SkyFx.mask(", "foregroundMask(", "offerPatch(")):
        n_rf += 1; errors.append(f"{rel_v}: runReframe() thiếu bước: SkyFx.mask (trời), foregroundMask (chủ thể), Reframe.depthMap / shift / render / describe, offerPatch")
    else:
        if "offerPatch(GenKind.FILL, base," not in b:
            n_rf += 1; errors.append(f"{rel_v}: runReframe() phải so lớp vá với ảnh GỐC (base) để hoàn tác được")
        if "Reframe.WORK_SIDE" not in b or "perf.maxSide" not in b or "scaleToMax(" not in b:
            n_rf += 1; errors.append(f"{rel_v}: runReframe() phải chạy ở cỡ ≤ min(Reframe.WORK_SIDE, perf.maxSide) (scaleToMax) để máy yếu không hết RAM")
        if "recycle()" not in b or "createScaledBitmap(" not in b:
            n_rf += 1; errors.append(f"{rel_v}: runReframe() phải recycle() ảnh làm việc và phóng kết quả về đúng cỡ ảnh gốc (createScaledBitmap)")
        if "runCatching { currentSeg()" not in b:
            n_rf += 1; errors.append(f"{rel_v}: runReframe() phải chịu được lỗi/thiếu model tách nền (runCatching) — không có chủ thể thì vẫn dựng độ sâu theo trời + mặt đất")
        for bad in ("chain(", "generative_fill", "ProxyBackend", "Gemini"):
            if bad in b:
                n_rf += 1; errors.append(f"{rel_v}: runReframe() không được gọi dịch vụ AI ({bad}) — chế độ miễn phí không được tốn hạn mức của chủ ứng dụng")
    b = _body(vmsrc, "fun setReframe(")
    if b is None or "coerceIn(-1f, 1f)" not in b or "coerceIn(0f, 2f)" not in b:
        n_rf += 1; errors.append(f"{rel_v}: setReframe() phải kẹp góc về −1..1 và độ sâu về 0..2")
    b = _body(vmsrc, "fun setBackgroundOnly(")
    if b is None or "reframeX = 0f" not in b or "reframeY = 0f" not in b:
        n_rf += 1; errors.append(f"{rel_v}: setBackgroundOnly() phải đưa góc Reframe về 0 khi đổi ảnh nền")
if pn is None or any(k not in pn for k in ("vm.runReframe()", "vm.setReframe(", "vm.resetReframe()", "Áp dụng góc nhìn", "Xoay ngang", "Xoay dọc", "Độ sâu")):
    n_rf += 1; errors.append(f"{rel_p}: AiPanel thiếu khối Reframe (chip, 3 thanh trượt \"Xoay ngang\" / \"Xoay dọc\" / \"Độ sâu\", \"Áp dụng góc nhìn\", \"Về giữa\")")
rel_rf, rfs = _src("Reframe.kt")
if rfs is None or any(k not in rfs for k in ("fun depthMap(", "fun shift(", "fun render(", "fun warp(", "fun fill(", "fun guidedFilter(", "const val WORK_SIDE")):
    n_rf += 1; errors.append(f"{rel_rf}: thiếu depthMap / shift / render / warp / fill / guidedFilter / WORK_SIDE")
print(f"[23] Reframe 2.5D được nối đủ: {n_rf} lỗi")

# ---- 24. (R30) Model đo độ sâu tùy chọn cho Reframe 2.5D được nối đủ
n_dp = 0
rel_de, des = _src("DepthEstimator.kt")
if des is None or any(k not in des for k in ("object DepthProfile", "fun inputSize(", "fun toNchw(", "class DepthEstimator(", "fun estimate(", "AutoCloseable", "OrtTuning.createSession(", "Reframe.Field(")):
    n_dp += 1; errors.append(f"{rel_de}: thiếu DepthProfile.inputSize / toNchw hoặc lớp DepthEstimator (estimate, AutoCloseable, OrtTuning.createSession, trả Reframe.Field)")
elif "close()" not in (_body(des, "init {") or ""):
    n_dp += 1; errors.append(f"{rel_de}: init của DepthEstimator phải đóng phiên ONNX khi model sai hợp đồng input (tránh giữ tệp / bộ nhớ của model không dùng được)")
if rfs is None or any(k not in rfs for k in ("fun stretch(", "fun depthFromField(", "class Field(", "val fromModel", "const val SUBJECT_KEEP", "const val FIELD_LO_PCT", "fun reliefKeep(", "shiftPx: Float = 0f", "reliefKeep(full, up, w, h, shiftPx)", "const val GRADIENT_BINS")):
    n_dp += 1; errors.append(f"{rel_rf}: thiếu stretch / depthFromField(shiftPx) / reliefKeep / Field / Depth.fromModel / SUBJECT_KEEP / FIELD_LO_PCT")
if vmsrc is not None:
    for need in ('const val DEPTH_FILE = "depth.onnx"', '"file:depth.onnx" -> File(modelDir, DEPTH_FILE).exists()', '"depth" -> pool.register("depth"'):
        if need not in vmsrc:
            n_dp += 1; errors.append(f"{rel_v}: thiếu `{need}` (nối model độ sâu vào định tuyến / hồ model)")
    b = _body(vmsrc, "private fun ensureDepth(")
    if b is None or "depth_estimate" not in b or "depth_onnx" not in b or "DepthEstimator(" not in b:
        n_dp += 1; errors.append(f"{rel_v}: ensureDepth() phải theo định tuyến depth_estimate / depth_onnx và dựng DepthEstimator")
    b = _body(vmsrc, "fun runReframe(")
    if b is not None:
        for need in ("ensureDepth()", "Reframe.depthFromField(", "Reframe.depthMap(", "estimateDepthAdaptive("):
            if need not in b:
                n_dp += 1; errors.append(f"{rel_v}: runReframe() thiếu `{need}` (model độ sâu nếu có, độ sâu giả nếu không)")
        if b.find("Reframe.depthFromField(") > b.find("Reframe.depthMap(") or "runCatching { ensureDepth() }" not in b:
            n_dp += 1; errors.append(f"{rel_v}: runReframe() phải thử model độ sâu TRƯỚC (trong runCatching) rồi mới rơi về Reframe.depthMap - lỗi model không được làm hỏng Reframe")
    b = _body(vmsrc, "fun importDepth(")
    if b is None or "DepthEstimator(dest.absolutePath).close()" not in b or "dest.delete()" not in b:
        n_dp += 1; errors.append(f"{rel_v}: importDepth() phải thử nạp rồi đóng (DepthEstimator(dest.absolutePath).close()) và xóa tệp nếu hỏng")
    b = _body(vmsrc, "fun removeModels(")
    if b is None or "DEPTH_FILE" not in b or "depthEst?.close()" not in b or "depthReady = false" not in b:
        n_dp += 1; errors.append(f"{rel_v}: removeModels() phải đóng + xóa model độ sâu và đặt depthReady = false")
    b = _body(vmsrc, "private fun restoreModels(")
    if b is None or "depthReady" not in b:
        n_dp += 1; errors.append(f"{rel_v}: restoreModels() phải đặt depthReady theo tệp trên máy")
if ed is None or "vm.importDepth(" not in ed or "pickDepth" not in ed:
    n_dp += 1; errors.append(f"{rel_e}: Cài đặt thiếu nút chọn model độ sâu (pickDepth -> vm.importDepth)")
if pn is None or "st.depthReady" not in pn:
    n_dp += 1; errors.append(f"{rel_p}: khối Reframe phải cho biết nguồn độ sâu (st.depthReady)")
rt = _src("Routing.kt")[1]
if rt is None or '"depth_onnx"' not in rt:
    n_dp += 1; errors.append("Routing.kt: KNOWN_KINDS thiếu depth_onnx")
PROJ = os.path.join(ROOT, "..", "..")
for rel_f in (os.path.join("app", "src", "main", "assets", "routing_default.json"), os.path.join("backend", "server.py")):
    try:
        txt = open(os.path.join(PROJ, rel_f), encoding="utf-8").read()
    except OSError:
        txt = ""
    if "depth_estimate" not in txt or "depth_onnx" not in txt or "file:depth.onnx" not in txt:
        n_dp += 1; errors.append(f"{rel_f}: thiếu tác vụ depth_estimate (kind depth_onnx, needs file:depth.onnx)")
print(f"[24] Model độ sâu tùy chọn (R30) được nối đủ: {n_dp} lỗi")

# ---- 25. (R30) Phóng to ×4 tùy chọn: trần cạnh dài dùng chung + chip + ghi chú hệ số thực tế
n_up = 0
rel_ie, ies = _src("ImageEngine.kt")
if ies is None or "const val UPSCALE_MAX_SIDE" not in ies or "fun upscaleFactor(" not in ies or "fun upscaleMaxSide(" not in ies or "upscaleFactor(b.width, b.height, factor, upscaleMaxSide(" not in ies:
    n_up += 1; errors.append(f"{rel_ie}: thiếu UPSCALE_MAX_SIDE / upscaleFactor, hoặc upscale() không dùng upscaleFactor (hai đường phóng phải chung một trần)")
if vmsrc is not None:
    b = _body(vmsrc, "private suspend fun bakeInternal(")
    if b is None or "ImageEngine.upscaleMaxSide(" not in b or "ImageEngine.heapHeadroom()" not in b or "bị giới hạn còn" not in b:
        n_up += 1; errors.append(f"{rel_v}: bakeInternal() phải dùng trần phóng suy từ heap (ImageEngine.upscaleMaxSide + heapHeadroom) cho đường AI và báo hệ số THỰC TẾ khi bị giới hạn")
if pn is None or "bake(OpType.UPSCALE, 4f)" not in pn or "bake(OpType.UPSCALE, 2f)" not in pn:
    n_up += 1; errors.append(f"{rel_p}: thiếu chip Phóng to ×2 / ×4")
print(f"[25] Phóng to ×4 tùy chọn (R30): {n_up} lỗi")

# ---- 26. (R30) Agent AI nhận ảnh MẪU phong cách + backend có giới hạn tần suất
n_ag = 0
rel_pb, pbs = _src("ProxyBackend.kt")
if pbs is None or "reference: Bitmap? = null" not in pbs or '.put("reference"' not in pbs:
    n_ag += 1; errors.append(f"{rel_pb}: editPlan() phải nhận ảnh mẫu tùy chọn (reference: Bitmap? = null) và gửi trường \"reference\"")
if vmsrc is not None:
    for need in ("fun setAgentReference(", "fun clearAgentReference(", "val agentRefReady", "ProxyBackend.editPlan(st0.proxyUrl, st0.proxyToken, img, planPrompt, agentRef)"):
        if need not in vmsrc:
            n_ag += 1; errors.append(f"{rel_v}: thiếu `{need}` (ảnh mẫu phong cách cho Agent AI)")
if pn is None or "vm.setAgentReference(" not in pn or "vm.clearAgentReference(" not in pn:
    n_ag += 1; errors.append(f"{rel_p}: thiếu nút chọn / bỏ ảnh mẫu cho Agent AI")
try:
    srv_txt = open(os.path.join(PROJ, "backend", "server.py"), encoding="utf-8").read()
    rate_txt = open(os.path.join(PROJ, "backend", "test_rate.py"), encoding="utf-8").read()
    tsrv_txt = open(os.path.join(PROJ, "backend", "test_server.py"), encoding="utf-8").read()
except OSError:
    srv_txt = rate_txt = tsrv_txt = ""
for need in ("class RateLimiter", "def _rate_block(", "RATE_REGISTER_PER_IP_HOUR", "RATE_PER_DEVICE_MINUTE", "TRUST_PROXY_HOPS", "PLAN_REFERENCE_NOTE", 'PLAN_INSTRUCTION.replace("{request}"'):
    if need not in srv_txt:
        n_ag += 1; errors.append(f"backend/server.py: thiếu `{need}`")
if any("PLAN_INSTRUCTION %" in ln and not ln.lstrip().startswith("#") for ln in srv_txt.splitlines()):
    n_ag += 1; errors.append("backend/server.py: PLAN_INSTRUCTION không được định dạng bằng % lần hai (còn dấu % thật trong chuỗi -> TypeError ở mọi lần gọi Gemini thật)")
if "test_rate.run(" not in tsrv_txt or "def run(" not in rate_txt:
    n_ag += 1; errors.append("backend/test_server.py phải gọi test_rate.run(...)")
print(f"[26] Agent AI ảnh mẫu + giới hạn tần suất backend (R30): {n_ag} lỗi")

# ---- 27. (R30c) Công cụ nén trọng số ONNX không cần gói onnx + bài kiểm đi kèm
n_q = 0
try:
    qt = open(os.path.join(PROJ, "tools", "convert_models", "onnx_weight_quant.py"), encoding="utf-8").read()
    qv = open(os.path.join(PROJ, "tools", "verify_ports", "onnx_weight_quant.py"), encoding="utf-8").read()
except OSError:
    qt = qv = ""
for need in ("def quantize_model(", "def quantize_per_axis(", "def verify(", "def main(", "DequantizeLinear", "nén cỡ tệp"):
    if need not in qt:
        n_q += 1; errors.append(f"tools/convert_models/onnx_weight_quant.py: thiếu `{need}`")
if "import onnx\n" in qt or "from onnx " in qt or "import onnx " in qt:
    n_q += 1; errors.append("tools/convert_models/onnx_weight_quant.py: không được phụ thuộc gói `onnx` (mục đích của công cụ là chạy khi không có nó)")
try:
    qs = open(os.path.join(PROJ, "tools", "convert_models", "onnx_static_qdq.py"), encoding="utf-8").read()
    qsv = open(os.path.join(PROJ, "tools", "verify_ports", "onnx_static_qdq.py"), encoding="utf-8").read()
except OSError:
    qs = qsv = ""
for need in ("def quantize_static(", "def act_qparams(", "def calibrate(", "def fused_ops(", "QuantizeLinear", "DequantizeLinear", "THẬT"):
    if need not in qs:
        n_q += 1; errors.append(f"tools/convert_models/onnx_static_qdq.py: thiếu `{need}`")
if "import onnx\n" in qs or "from onnx " in qs or "import onnx " in qs:
    n_q += 1; errors.append("tools/convert_models/onnx_static_qdq.py: không được phụ thuộc gói `onnx`")
if "except ImportError" not in qsv or "sys.exit(0)" not in qsv or "QLinearConv" not in qsv:
    n_q += 1; errors.append("tools/verify_ports/onnx_static_qdq.py: phải bỏ qua có thông báo khi thiếu onnxruntime và kiểm QLinearConv thật")
if "except ImportError" not in qv or "sys.exit(0)" not in qv:
    n_q += 1; errors.append("tools/verify_ports/onnx_weight_quant.py: phải bỏ qua có thông báo khi thiếu onnxruntime (không làm đỏ run_all / CI)")
print(f"[27] Công cụ nén trọng số ONNX (R30c): {n_q} lỗi")

# ---- 28. (R30f) Thích nghi thay cho ngưỡng viết cứng theo máy
n_ad = 0
rel_ad, ads = _src("Adaptive.kt")
if ads is None or any(k not in ads for k in ("object Adaptive", "fun nextEdge(", "fun afterFailure(", "const val SHRINK_EXPONENT", "const val GROW_EXPONENT", "const val COLD_TOLERANCE", "const val DEFAULT_BUDGET_MS")):
    n_ad += 1; errors.append(f"{rel_ad}: thiếu bộ điều khiển thích nghi (nextEdge / afterFailure / hằng số suy ra)")
if vmsrc is not None:
    b = _body(vmsrc, "private fun estimateDepthAdaptive(")
    if b is None or any(k not in b for k in ("Adaptive.nextEdge(", "Adaptive.afterFailure(", "m.runs == 0", "prefs.edit().putInt(key", 'budget_ms')):
        n_ad += 1; errors.append(f"{rel_v}: estimateDepthAdaptive() phải học từ thời gian chạy thật (nextEdge), thu nhỏ khi lỗi bộ nhớ (afterFailure), bỏ qua lần chạy đầu (m.runs == 0), nhớ qua prefs và đọc budget_ms")
    if "depthModel.estimate(work, depthEdge())" in vmsrc or "private fun depthEdge(" in vmsrc:
        n_ad += 1; errors.append(f"{rel_v}: không còn được chọn cạnh model độ sâu cố định (depthEdge) — dùng estimateDepthAdaptive")
if "@Volatile var runs" not in des:
    n_ad += 1; errors.append("DepthEstimator.kt: thiếu bộ đếm runs (để Adaptive biết lần chạy đầu)")
if ies is not None and ("fun upscaleMaxSide(" not in ies or "var heapHeadroom" not in ies or "UPSCALE_HEAP_BYTES_PER_PIXEL" not in ies):
    n_ad += 1; errors.append(f"{rel_ie}: thiếu trần phóng suy từ heap (upscaleMaxSide / heapHeadroom / UPSCALE_HEAP_BYTES_PER_PIXEL)")
try:
    adp = open(os.path.join(PROJ, "tools", "verify_ports", "adaptive.py"), encoding="utf-8").read()
except OSError:
    adp = ""
if "def next_edge(" not in adp or "flops(" not in adp:
    n_ad += 1; errors.append("tools/verify_ports/adaptive.py: thiếu mô phỏng bộ điều khiển thích nghi")
print(f"[28] Thích nghi thay ngưỡng viết cứng theo máy (R30f): {n_ad} lỗi")

# ---- 29. (R30g) Hồ sơ hiệu năng suy ra từ số đo thật thay cho bảng RAM
n_pf = 0
try:
    pks = open(os.path.join(ROOT, "main", "java", "com", "aiphoto", "studio", "routing", "Perf.kt"), encoding="utf-8").read()
except OSError:
    pks = ""
for need in ("object PerfModel", "data class PerfMeasure", "fun derive(", "fun blend(", "const val NATIVE_BITMAPS", "const val FRAME_COUNT", "const val SIDE_CEIL"):
    if need not in pks:
        n_pf += 1; errors.append(f"routing/Perf.kt: thiếu `{need}`")
rel_pc, pcs = _src("PerfCalibrator.kt")
if pcs is None or "fun measureMsPerMp(" not in pcs or "ImageEngine.process(" not in pcs:
    n_pf += 1; errors.append(f"{rel_pc}: thiếu PerfCalibrator.measureMsPerMp chạy bằng chính ImageEngine.process")
if vmsrc is not None:
    for need in ("private fun computePerf(", "private fun applyPerf(", "private fun calibratePerf(", "PerfProfile.derive(", "displayRefreshHz()", "KEY_PERF_MS_PER_MP"):
        if need not in vmsrc:
            n_pf += 1; errors.append(f"{rel_v}: thiếu `{need}` (hồ sơ hiệu năng đo thật)")
    if "perf = PerfProfile.from(" in vmsrc.replace("private fun computePerf", ""):
        # from() chỉ được dùng làm giá trị khởi đầu bên trong computePerf và ở khai báo ban đầu
        body = _body(vmsrc, "private fun computePerf(") or ""
        stray = vmsrc.count("perf = PerfProfile.from(")
        if stray > 0:
            n_pf += 1; errors.append(f"{rel_v}: không gán perf = PerfProfile.from(...) trực tiếp — qua computePerf() (đã đo thì derive)")
if "@Volatile private var perf" not in (vmsrc or ""):
    n_pf += 1; errors.append(f"{rel_v}: perf được ghi từ luồng nền (calibratePerf) nên phải là @Volatile")
try:
    pm = open(os.path.join(PROJ, "tools", "verify_ports", "perf_model.py"), encoding="utf-8").read()
except OSError:
    pm = ""
if "def derive(" not in pm or "đột biến" not in pm:
    n_pf += 1; errors.append("tools/verify_ports/perf_model.py: thiếu bản port kiểm hồ sơ hiệu năng")
print(f"[29] Hồ sơ hiệu năng đo thật (R30g): {n_pf} lỗi")

# ---- 30. (R30h) Kiểm import / tham chiếu / số đối số của TOÀN BỘ mã Kotlin không cần trình biên dịch (tools/kt_import_check.py)
import subprocess
_kc = os.path.join(PROJ, "tools", "kt_import_check.py")
n_kt = 0
if not os.path.exists(_kc):
    n_kt += 1; errors.append("tools/kt_import_check.py: thiếu bộ kiểm import / tham chiếu Kotlin")
else:
    _r = subprocess.run([sys.executable, _kc], capture_output=True, text=True)
    if _r.returncode != 0:
        n_kt += 1
        for _ln in (_r.stdout.strip().splitlines() or ["(không có đầu ra)"])[:25]:
            errors.append("kt_import_check: " + _ln)
print(f"[30] Import / tham chiếu / số đối số Kotlin (R30h): {n_kt} lỗi")

# ---- 31. (R31) Yêu cầu của Google Play: ONNX Runtime/MediaPipe đủ mới để căn chỉnh 16 KB, edge-to-edge, công tắc target SDK 36, CI kiểm 16 KB
import re as _re31
def _ver(t):
    return tuple(int(x) for x in _re31.findall(r"\d+", t)[:3])
n_pl = 0
try:
    _g = open(os.path.join(PROJ, "app", "build.gradle.kts"), encoding="utf-8").read()
except OSError:
    _g = ""
_m = _re31.search(r'val ortVersion = "([0-9.]+)"', _g)
if not _m:
    n_pl += 1; errors.append("build.gradle.kts: thiếu `val ortVersion` (một số duy nhất cho onnxruntime-android và -qnn)")
elif _ver(_m.group(1)) < (1, 22, 0):
    n_pl += 1; errors.append(f"build.gradle.kts: ONNX Runtime {_m.group(1)} < 1.22.0 — thư viện native chưa căn chỉnh 16 KB, Google Play sẽ chặn bản cập nhật (hạn 01/02/2027)")
for _art in ("onnxruntime-android", "onnxruntime-android-qnn"):
    if f'{_art}:$ortVersion' not in _g:
        n_pl += 1; errors.append(f"build.gradle.kts: {_art} phải dùng $ortVersion (đừng ghim số riêng — dễ lệch giữa hai biến thể)")
for _m2 in _re31.finditer(r'com\.google\.mediapipe:tasks-(?:vision|genai|text|audio):([0-9.]+)', _g):
    if _ver(_m2.group(1)) < (0, 10, 26):
        n_pl += 1; errors.append(f"build.gradle.kts: MediaPipe {_m2.group(1)} < 0.10.26 — bản trước đó chưa hỗ trợ 16 KB")
if "playRelease" not in _g or "sdkLevel" not in _g or "36" not in _g:
    n_pl += 1; errors.append("build.gradle.kts: thiếu công tắc -PplayRelease (targetSdk/compileSdk 36 theo yêu cầu Google Play từ 31/8/2026)")
if "targetSdk = sdkLevel" not in _g or "compileSdk = sdkLevel" not in _g:
    n_pl += 1; errors.append("build.gradle.kts: compileSdk/targetSdk phải lấy từ sdkLevel (công tắc playRelease)")
try:
    _ma = open(os.path.join(PROJ, "app", "src", "main", "java", "com", "aiphoto", "studio", "MainActivity.kt"), encoding="utf-8").read()
except OSError:
    _ma = ""
if "enableEdgeToEdge(" not in _ma or "safeDrawingPadding()" not in _ma:
    n_pl += 1; errors.append("MainActivity.kt: thiếu enableEdgeToEdge() + safeDrawingPadding() — app nhắm API 35+ bị vẽ dưới thanh hệ thống nếu không xử lý")
try:
    _wf = open(os.path.join(PROJ, ".github", "workflows", "build-apk.yml"), encoding="utf-8").read()
except OSError:
    _wf = ""
for _need, _why in (("play_release", "ô nhập play_release"), ("max-page-size=16384", "cờ liên kết 16 KB cho sd-server"),
                    ("check_16kb.py", "bước kiểm căn chỉnh 16 KB sau khi build"), ("-PversionCode=", "versionCode tăng dần cho Play")):
    if _need not in _wf:
        n_pl += 1; errors.append(f"build-apk.yml: thiếu {_why}")
try:
    _st = open(os.path.join(PROJ, "settings.gradle.kts"), encoding="utf-8").read()
except OSError:
    _st = ""
if "PLAY_RELEASE" not in _st or "8.9.1" not in _st:
    n_pl += 1; errors.append("settings.gradle.kts: thiếu nâng AGP lên >= 8.9.1 khi PLAY_RELEASE=true (API 36 cần AGP >= 8.9.1)")
if "PLAY_RELEASE" not in _wf or "8.14.3" not in _wf:
    n_pl += 1; errors.append("build-apk.yml: job build phải đặt PLAY_RELEASE và dùng Gradle >= 8.11.1 khi play_release")
for _f in ("tools/check_16kb.py", "tools/verify_ports/elf_16kb.py"):
    if not os.path.exists(os.path.join(PROJ, _f)):
        n_pl += 1; errors.append(f"{_f}: thiếu")
try:
    _ot = open(os.path.join(PROJ, "app", "src", "main", "java", "com", "aiphoto", "studio", "engine", "OrtTuning.kt"), encoding="utf-8").read()
except OSError:
    _ot = ""
if "NNAPIFlags" in _ot:
    n_pl += 1; errors.append("OrtTuning.kt: không import NNAPIFlags trực tiếp — NNAPI đã lỗi thời (Android 15), gọi bằng reflection để bản ORT bỏ API này vẫn biên dịch được")
print(f"[31] Yêu cầu Google Play (16 KB, target SDK 36, edge-to-edge) (R31): {n_pl} lỗi")

# ---- 32. (R32) Tầng bằng chứng cho RAM nạp model: ModelMemory + MemoryLedger, móc Routing.memoryGuard, MainViewModel nối đủ, có test + bản port + stub
n_mm = 0
def _read32(*parts):
    try:
        return open(os.path.join(PROJ, *parts), encoding="utf-8").read()
    except OSError:
        return ""
_mm = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "engine", "ModelMemory.kt")
_rt = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "routing", "Routing.kt")
_vm = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "MainViewModel.kt")
for _need in ("object ModelMemory", "class MemoryLedger", "fun estimateMb", "fun fits", "KILL_TTL_MS", "fun recoverAfterCrash", "fun beginLoad", "fun endLoad", "fun abortLoad"):
    if _need not in _mm:
        n_mm += 1; errors.append(f"ModelMemory.kt: thiếu `{_need}`")
if "var memoryGuard" not in _rt or "memoryGuard(p)" not in _rt:
    n_mm += 1; errors.append("Routing.kt: thiếu móc `memoryGuard` trong chain()")
for _need in ("Routing.memoryGuard = ", "memLedger.recoverAfterCrash()", 'trackLoad("gemma")', 'trackLoad("lama")', 'trackLoad("migan")', "private fun memoryFits"):
    if _need not in _vm:
        n_mm += 1; errors.append(f"MainViewModel.kt: thiếu `{_need}`")
if "if (providerLoaded(p.id)) return true" not in _vm:
    n_mm += 1; errors.append("MainViewModel.kt: memoryFits phải bỏ qua model ĐÃ nạp (RAM của nó đã nằm trong mức đã dùng — nếu không sẽ tự khóa chính model đang chạy)")
for _f in ("app/src/test/java/com/aiphoto/studio/R32MemoryTest.kt", "tools/verify_ports/model_memory.py", "tools/jvm_check/stubs/java/android/os/Debug.java"):
    if not os.path.exists(os.path.join(PROJ, _f)):
        n_mm += 1; errors.append(f"{_f}: thiếu")
# hằng của bản Kotlin phải khớp bản port Python (nguồn của các số trong test)
_py = _read32("tools", "verify_ports", "model_memory.py")
for _name in ("LOAD_FACTOR", "WORKING_MB", "RESERVE_FRACTION", "LEARN_MARGIN", "KILL_FACTOR", "MAX_KILLS", "MIN_ESTIMATE_MB"):
    _k = _re31.search(r"const val " + _name + r" = ([0-9.]+)f?", _mm)
    _p = _re31.search(r"^" + _name + r" = ([0-9.]+)", _py, _re31.M)
    if not _k or not _p or float(_k.group(1)) != float(_p.group(1)):
        n_mm += 1; errors.append(f"ModelMemory.{_name}: bản Kotlin ({_k.group(1) if _k else '?'}) lệch bản port Python ({_p.group(1) if _p else '?'})")
print(f"[32] Tầng bằng chứng RAM nạp model (R32): {n_mm} lỗi")

# ---- 33. (R32) Client Play Integrity: giao diện + hai flavor + móc ProxyBackend/MainViewModel + Gradle/manifest/CI + stub + băm khớp máy chủ
import hashlib as _hl33
n_pi = 0
_ig = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "integrity", "IntegrityGateway.kt")
_pb = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "engine", "ProxyBackend.kt")
_gr = _read32("app", "build.gradle.kts")
_mf = _read32("app", "src", "main", "AndroidManifest.xml")
_t33 = _read32("app", "src", "test", "java", "com", "aiphoto", "studio", "R32IntegrityTest.kt")
_wf33 = _read32(".github", "workflows", "build-apk.yml")
for _need in ("interface IntegrityGateway", "object IntegrityHash", "class IntegrityCoordinator", 'joinToString("")', '"$deviceId|$challenge"'):
    if _need not in _ig:
        n_pi += 1; errors.append(f"IntegrityGateway.kt: thiếu `{_need}` (công thức requestHash phải là sha256 hex của device_id|thử thách — khớp backend/integrity.py)")
for _f in ("app/src/integrityStub/java/com/aiphoto/studio/integrity/IntegrityGatewayFactory.kt",
           "app/src/integrityReal/java/com/aiphoto/studio/integrity/IntegrityGatewayFactory.kt",
           "app/src/integrityReal/java/com/aiphoto/studio/integrity/PlayIntegrityGateway.kt",
           "tools/jvm_check/stubs_integrity/com/google/android/play/core/integrity/StandardIntegrityManager.java",
           "app/src/test/java/com/aiphoto/studio/R32IntegrityTest.kt"):
    if not os.path.exists(os.path.join(PROJ, _f)):
        n_pi += 1; errors.append(f"{_f}: thiếu")
for _need in ("var integrityHook", "fun attest(", "class IntegrityRequired", "/v1/integrity/challenge", "/v1/integrity/verify", "integrity_required"):
    if _need not in _pb:
        n_pi += 1; errors.append(f"ProxyBackend.kt: thiếu `{_need}`")
if _pb.count("catch (e: IntegrityRequired)") < 2:
    n_pi += 1; errors.append("ProxyBackend.kt: cả `request` (instance) lẫn `call` (companion) đều phải thử lại sau chứng thực — thiếu một trong hai")
if "ProxyBackend.integrityHook = " not in _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "MainViewModel.kt"):
    n_pi += 1; errors.append("MainViewModel.kt: chưa gắn ProxyBackend.integrityHook")
for _need in ("useIntegrity", "integrityReal", "integrityStub", "com.google.android.play:integrity:", "integrityCloudProject"):
    if _need not in _gr:
        n_pi += 1; errors.append(f"build.gradle.kts: thiếu `{_need}`")
if "integrity.cloud_project" not in _mf or "${integrityCloudProject}" not in _mf:
    n_pi += 1; errors.append("AndroidManifest.xml: thiếu meta-data integrity.cloud_project ${integrityCloudProject}")
for _need in ("use_integrity", "integrity_cloud_project", "-PuseIntegrity=", "-PintegrityCloudProject="):
    if _need not in _wf33:
        n_pi += 1; errors.append(f"build-apk.yml: thiếu `{_need}`")
for _dev, _ch in (("dev", "abc"), ("device-12345678", "0123456789abcdef")):
    _h = _hl33.sha256(f"{_dev}|{_ch}".encode()).hexdigest()
    if _h not in _t33:
        n_pi += 1; errors.append(f"R32IntegrityTest.kt: thiếu hằng băm sha256({_dev}|{_ch}) = {_h} (phải khớp hashlib / backend)")
print(f"[33] Client Play Integrity (R32): {n_pi} lỗi")

# ---- 34. (R33) Đa ngôn ngữ + Trợ giúp: lớp dịch, Text bọc, hộp thoại, gói dịch/Trợ giúp trong assets đúng và mới
import contextlib as _cl34
import io as _io34
import json as _json34
n_i18n = 0
_ui_dir = os.path.join(PROJ, "app", "src", "main", "java", "com", "aiphoto", "studio", "ui")
for _f in ("EditorScreen.kt", "Panels.kt", "TeamPanel.kt", "Widgets.kt"):
    _t = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "ui", _f)
    if "import com.aiphoto.studio.i18n.Text" not in _t:
        n_i18n += 1; errors.append(f"ui/{_f}: phải import com.aiphoto.studio.i18n.Text (Text đã bọc để dịch) — nếu không chuỗi trong tệp này không được dịch")
    if _re31.search(r"^import androidx\.compose\.material3\.Text\s*$", _t, _re31.M):
        n_i18n += 1; errors.append(f"ui/{_f}: còn import androidx.compose.material3.Text — Text gốc không dịch")
_tx = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "i18n", "Text.kt")
if "I18n.tr(text)" not in _tx or "LocalTextStyle.current" not in _tx:
    n_i18n += 1; errors.append("i18n/Text.kt: Text bọc phải gọi I18n.tr(text) và giữ LocalTextStyle.current làm style mặc định (nếu không nút / thẻ mất kiểu chữ)")
for _need in ("I18n.init(this)", "LocalLayoutDirection provides", "I18n.isRtl"):
    if _need not in _ma:
        n_i18n += 1; errors.append(f"MainActivity.kt: thiếu `{_need}`")
_es = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "ui", "EditorScreen.kt")
for _need in ("HelpDialog {", "LanguageDialog {", "WelcomeDialog(", "showHelp = true", "onHelp = { showHelp = true }", "onLanguage = { showLanguage = true }"):
    if _need not in _es:
        n_i18n += 1; errors.append(f"EditorScreen.kt: thiếu `{_need}` (nút ? / Trợ giúp / chọn ngôn ngữ / chào lần đầu)")
_al = _read32("app", "src", "main", "java", "com", "aiphoto", "studio", "i18n", "AppLanguage.kt")
_codes = _re31.findall(r'AppLanguage\("([a-z]{2})"', _al)
sys.path.insert(0, os.path.join(PROJ, "tools"))
import i18n_build as _ib34
if sorted(_codes) != sorted(["vi"] + _ib34.LANGS):
    n_i18n += 1; errors.append(f"AppLanguage.kt: danh sách mã {sorted(_codes)} lệch tools/i18n_build.py LANGS + vi")
_buf = _io34.StringIO()
with _cl34.redirect_stdout(_buf):
    _rc = _ib34.run(False, True)
if _rc != 0:
    n_i18n += 1
    for _ln in _buf.getvalue().splitlines():
        if _ln.startswith("LỖI"):
            errors.append("i18n: " + _ln[5:].strip())
_keys34 = set(_json34.load(open(os.path.join(PROJ, "tools", "i18n", "ids.json"), encoding="utf-8"))["keys"])
import i18n_extract as _ix34
_new = [k for k in _ix34.collect() if k not in _keys34]
if _new:
    warnings.append(f"i18n: {len(_new)} chuỗi tiếng Việt mới chưa có mã dịch (ví dụ {_new[0]!r}) — chạy python tools/i18n_build.py --assign rồi dịch")
print(f"[34] Đa ngôn ngữ + Trợ giúp (R33): {n_i18n} lỗi")

# ---- [35] Nối dây UI <-> ViewModel <-> engine (R34): không còn hàm VM / trường trạng thái / lớp "mồ côi" ----
import wiring_check as _wc35
_res35, _m35 = _wc35.analyze()
n_wr = 0
for _k in "ABCDEFG":
    for _x in _res35[_k]:
        n_wr += 1
        errors.append(f"nối dây [{_k}] {_wc35.TITLES[_k]}: {_x} — nối vào UI/VM hoặc xóa; nếu cố ý thì ghi lý do vào ALLOW trong tools/wiring_check.py")
print(f"[35] Nối dây UI↔ViewModel↔engine (R34): {n_wr} lỗi")

print(f"Đã quét {len(files)} tệp .kt  |  enum/object: {sorted(checked)}")
for w in warnings: print("CẢNH BÁO:", w)
for e in errors: print("LỖI:", e)
print(f"Kết quả: {len(errors)} lỗi, {len(warnings)} cảnh báo")
sys.exit(1 if errors else 0)
