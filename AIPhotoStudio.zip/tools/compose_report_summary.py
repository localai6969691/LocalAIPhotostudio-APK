#!/usr/bin/env python3
"""
R36 - Tóm tắt báo cáo của Compose compiler (do `-PcomposeCompilerReports=true`, xem app/build.gradle.kts) thành vài dòng đọc được / dán được.

Dùng:  python3 tools/compose_report_summary.py app/build/compose_compiler        (CI ghi kết quả vào $GITHUB_STEP_SUMMARY)

Đọc: <module>-composables.csv (đếm), <module>-composables.txt (tham số 'unstable' của từng composable), <module>-classes.txt (lớp 'unstable' và trường làm nó mất ổn định).
Mục đích: biết composable nào KHÔNG bỏ qua được khi tái vẽ (restartable nhưng không skippable) và vì tham số / lớp nào — bằng chứng để quyết định có tách EditorScreen hay không.
Định dạng theo tài liệu developer.android.com (compiler metrics); chưa thấy báo cáo thật của dự án này nên bộ đọc khoan dung: dòng lạ bị bỏ qua, không văng.
"""
import csv, glob, os, re, sys

TOP = 30

def read_csv(path):
    rows = []
    with open(path, encoding="utf-8", errors="replace", newline="") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows

def parse_composables_txt(path):
    """name -> dict(skippable: bool, restartable: bool, unstable: [param...])"""
    out = {}
    cur = None
    head = re.compile(r"^((?:restartable|skippable|inline|readonly|scheme\(.*?\)|\S+)\s+)*?fun\s+([A-Za-z0-9_$<>.\-]+)\s*\(")
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            raw = line.rstrip("\n")
            if raw.startswith("  "):
                m = re.match(r"^\s+unstable\s+([A-Za-z0-9_]+)\s*:", raw)
                if m and cur is not None:
                    cur["unstable"].append(m.group(1))
                continue
            m = re.search(r"\bfun\s+([A-Za-z0-9_$<>.\-]+)\s*\(", raw)
            if m:
                words = raw.split("fun ")[0].split()
                cur = {"skippable": "skippable" in words, "restartable": "restartable" in words, "unstable": []}
                out[m.group(1)] = cur
    return out

def parse_classes_txt(path):
    """lớp 'unstable' -> danh sách trường unstable"""
    out = {}
    cur = None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            raw = line.rstrip("\n")
            m = re.match(r"^(stable|unstable|runtime)\s+class\s+([A-Za-z0-9_.$<>]+)", raw)
            if m:
                cur = (m.group(2), m.group(1)) if m.group(1) == "unstable" else None
                if cur:
                    out[cur[0]] = []
                continue
            if cur is not None:
                f_ = re.match(r"^\s+unstable\s+(?:val|var)\s+([A-Za-z0-9_]+)\s*:\s*(.*)$", raw)
                if f_:
                    out[cur[0]].append(f"{f_.group(1)}: {f_.group(2).strip()}")
    return out

def summarize(directory):
    lines = ["## Báo cáo Compose compiler (R36)", ""]
    if not os.path.isdir(directory):
        return "\n".join(lines + [f"Không thấy thư mục báo cáo `{directory}` (build chưa bật -PcomposeCompilerReports=true hoặc Kotlin chưa chạy xong)."]) + "\n"
    csvs = sorted(glob.glob(os.path.join(directory, "*-composables.csv")))
    txts = sorted(glob.glob(os.path.join(directory, "*-composables.txt")))
    clss = sorted(glob.glob(os.path.join(directory, "*-classes.txt")))
    if not (csvs or txts or clss):
        return "\n".join(lines + [f"Thư mục `{directory}` không có tệp *-composables.csv / *-composables.txt / *-classes.txt."]) + "\n"
    total = skippable = restart_not_skip = 0
    for c in csvs:
        for r in read_csv(c):
            if r.get("composable") != "1" or r.get("isLambda") == "1":
                continue
            total += 1
            sk, rs = r.get("skippable") == "1", r.get("restartable") == "1"
            skippable += sk
            restart_not_skip += (rs and not sk)
    if total:
        lines += [f"- Composable (không tính lambda): **{total}**; bỏ qua được (skippable): **{skippable}**; "
                  f"**chạy lại mỗi khi cha tái vẽ** (restartable nhưng KHÔNG skippable): **{restart_not_skip}**", ""]
    funcs = {}
    for t in txts:
        funcs.update(parse_composables_txt(t))
    bad = sorted(((n, d) for n, d in funcs.items() if d["restartable"] and not d["skippable"]),
                 key=lambda x: (-len(x[1]["unstable"]), x[0]))
    if bad:
        lines += [f"### Composable KHÔNG bỏ qua được (top {min(TOP, len(bad))}/{len(bad)}; ưu tiên cái có tham số không ổn định)", ""]
        for n, d in bad[:TOP]:
            lines.append(f"- `{n}`" + (f" — tham số không ổn định: {', '.join(d['unstable'])}" if d["unstable"] else " — (không có tham số 'unstable' được ghi; thường do tham số kiểu lớp không ổn định ở mức lớp, xem phần lớp)"))
        lines.append("")
    classes = {}
    for c in clss:
        classes.update(parse_classes_txt(c))
    if classes:
        ranked = sorted(classes.items(), key=lambda x: (-len(x[1]), x[0]))
        lines += [f"### Lớp 'unstable' (top {min(TOP, len(ranked))}/{len(ranked)})", ""]
        for n, fl in ranked[:TOP]:
            lines.append(f"- `{n}`" + (f" — trường: {'; '.join(fl[:6])}" + (" …" if len(fl) > 6 else "") if fl else ""))
        lines.append("")
    if not (bad or classes) and total:
        lines.append("Không có composable không-skippable và không có lớp 'unstable' — không cần tách EditorScreen vì lý do ổn định.")
    return "\n".join(lines) + "\n"

if __name__ == "__main__":
    sys.stdout.write(summarize(sys.argv[1] if len(sys.argv) > 1 else "app/build/compose_compiler"))
