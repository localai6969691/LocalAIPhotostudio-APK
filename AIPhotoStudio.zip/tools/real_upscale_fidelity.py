#!/usr/bin/env python3
"""R51 - đo THẬT tác dụng của hiệu chỉnh nhất quán + thanh Độ trung thực trên model Real-ESRGAN đi kèm (onnxruntime Python, CPU).
Cần: pip install numpy onnxruntime scikit-image opencv-python-headless. Ảnh mẫu của scikit-image (4 ảnh) thu nhỏ ×4 theo 4 kiểu (area/cubic/gauss/jpeg).
Giới hạn: 4 ảnh, ảnh vào là ảnh giả lập (không phải ảnh chụp thật), PSNR/SSIM không đo cảm nhận thị giác."""
import os
import numpy as np, cv2, onnxruntime as ort, time, sys
from skimage import data
from skimage.metrics import structural_similarity as ssim
sess=ort.InferenceSession(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','app','src','main','assets','models','realesr-general-x4v3.onnx')  ,providers=['CPUExecutionProvider'])
inn=sess.get_inputs()[0].name
T=128; PAD=10; CORE=T-2*PAD; S=4
def sr_model(lr):  # lr float32 HxWx3 0..1 -> (H*4,W*4,3), đúng cách chia ô của OnnxUpscaler
    h,w,_=lr.shape; out=np.zeros((h*S,w*S,3),np.float32)
    for y0 in range(0,h,CORE):
        for x0 in range(0,w,CORE):
            ys=np.clip(np.arange(y0-PAD,y0-PAD+T),0,h-1); xs=np.clip(np.arange(x0-PAD,x0-PAD+T),0,w-1)
            tile=lr[np.ix_(ys,xs)].transpose(2,0,1)[None].astype(np.float32)
            o=sess.run(None,{inn:tile})[0][0].transpose(1,2,0)
            ch=min(CORE,h-y0); cw=min(CORE,w-x0)
            out[y0*S:(y0+ch)*S, x0*S:(x0+cw)*S]=o[PAD*S:(PAD+ch)*S, PAD*S:(PAD+cw)*S]
    return np.clip(out,0,1)
def down_area(x,k=4):
    h,w,c=x.shape; return x.reshape(h//k,k,w//k,k,c).mean((1,3))
def up_bil(x,k=4):
    h,w,_=x.shape; return cv2.resize(x,(w*k,h*k),interpolation=cv2.INTER_LINEAR)
def backproj(sr,lr,it,lam=1.0):
    x=sr.copy()
    for _ in range(it):
        r=lr-down_area(x); x=np.clip(x+lam*up_bil(r),0,1)
    return x
def psnr(a,b): 
    m=((a-b)**2).mean(); return 99 if m<1e-12 else 10*np.log10(1/m)
def lapvar(x): 
    g=cv2.cvtColor((x*255).astype(np.uint8),cv2.COLOR_RGB2GRAY); return cv2.Laplacian(g,cv2.CV_64F).var()
imgs={'astronaut':data.astronaut()[:384,64:448],'coffee':data.coffee()[:384,100:484],'chelsea':data.chelsea()[:296,:296],'rocket':data.rocket()[20:404,100:484]}
def make_lr(gt,op):
    h,w,_=gt.shape; sz=(w//4,h//4)
    if op=='area': return cv2.resize(gt,sz,interpolation=cv2.INTER_AREA)
    if op=='cubic': return cv2.resize(gt,sz,interpolation=cv2.INTER_CUBIC)
    if op=='gauss': return cv2.resize(cv2.GaussianBlur(gt,(0,0),1.4),sz,interpolation=cv2.INTER_NEAREST)
    if op=='jpeg':
        lr=cv2.resize(gt,sz,interpolation=cv2.INTER_AREA); b=(lr*255).astype(np.uint8)
        ok,enc=cv2.imencode('.jpg',cv2.cvtColor(b,cv2.COLOR_RGB2BGR),[cv2.IMWRITE_JPEG_QUALITY,60]); d=cv2.cvtColor(cv2.imdecode(enc,1),cv2.COLOR_BGR2RGB); return d.astype(np.float32)/255

import sys; import os; sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'verify_ports'))
import numpy as np, cv2
from skimage.metrics import structural_similarity as ssim
import upscale_fidelity as uf
# (phần nạp model + hàm đo ở đầu tệp)
def to8(x): return np.clip(np.floor(x*255+0.5),0,255).astype(np.int64)
res={}
for op in ['area','cubic','gauss','jpeg']:
    acc={}
    for name,im in imgs.items():
        gt=im[:im.shape[0]//4*4,:im.shape[1]//4*4].astype(np.float32)/255
        lr=make_lr(gt,op); lr8=to8(lr); raw8=to8(sr_model(lr8/255.0))
        gt8=to8(gt)
        cands={'bicubic (nội suy)':np.clip(np.floor(uf.bicubic(lr8,4)+0.5),0,255).astype(np.int64),
               'AI thô (app trước R51)':raw8}
        for f in (0.0,0.15,0.3,0.6): cands[f'AI + nhất quán, trung thực {int(f*100)}%']=uf.refine(raw8,lr8,f)
        for k,v in cands.items():
            g=cv2.cvtColor(gt8.astype(np.uint8),cv2.COLOR_RGB2GRAY); o=cv2.cvtColor(v.astype(np.uint8),cv2.COLOR_RGB2GRAY)
            acc.setdefault(k,[]).append((psnr(v/255.0,gt8/255.0),ssim(g,o,data_range=255),lapvar(v/255.0)/lapvar(gt8/255.0),psnr(down_area(v/255.0),lr8/255.0)))
    res[op]={k:np.mean(v,0) for k,v in acc.items()}
for op,d in res.items():
    print(f'\n[thu nhỏ: {op}]  PSNR dB | SSIM | độ nét so với ảnh thật | khớp ảnh đầu vào dB')
    for k,m in d.items(): print(f'  {k:38s} {m[0]:6.2f} {m[1]:6.3f} {m[2]:5.2f} {m[3]:6.1f}')
avg={k:np.mean([res[o][k] for o in res],0) for k in res['area']}
print('\n[TRUNG BÌNH 4 kiểu thu nhỏ × 4 ảnh]')
for k,m in avg.items(): print(f'  {k:38s} {m[0]:6.2f} {m[1]:6.3f} {m[2]:5.2f} {m[3]:6.1f}')
