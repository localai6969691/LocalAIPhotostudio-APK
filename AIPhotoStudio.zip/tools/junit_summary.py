#!/usr/bin/env python3
"""R42: tóm tắt kết quả JUnit của Gradle (app/build/test-results/testDebugUnitTest/TEST-*.xml) thành Markdown cho Summary của GitHub Actions,
để thấy NGAY bài nào đỏ và vì sao mà không phải mở log dài. Dùng: junit_summary.py <thư mục chứa TEST-*.xml> [số_bài_tối_đa_liệt_kê]
Mã thoát luôn 0 (bước CI này không chặn)."""
import collections, glob, os, re, sys
import xml.etree.ElementTree as ET

def summarize(folder, limit=25):
    files = sorted(glob.glob(os.path.join(folder, '*.xml')))
    if not files:
        return f"### Kết quả Unit tests\n\nKhông thấy tệp kết quả trong `{folder}` (Gradle chưa chạy tới bước test, hoặc biên dịch test đã lỗi — xem log bước *Unit tests*).\n"
    tests = fails = errs = skips = 0
    bad = []                                   # (lớp, tên bài, thông điệp)
    for f in files:
        try:
            root = ET.parse(f).getroot()
        except ET.ParseError:
            continue
        for tc in root.iter('testcase'):
            tests += 1
            cls = (tc.get('classname') or '').split('.')[-1]
            name = tc.get('name') or '?'
            fl = tc.find('failure'); er = tc.find('error'); sk = tc.find('skipped')
            node = fl if fl is not None else er
            if node is not None:
                if fl is not None: fails += 1
                else: errs += 1
                msg = (node.get('message') or (node.text or '')).strip().split('\n')[0]
                bad.append((cls, name, msg[:240]))
            elif sk is not None:
                skips += 1
    out = [f"### Kết quả Unit tests (Gradle, `testDebugUnitTest`)", "",
           f"**{tests} bài** — đạt {tests - fails - errs - skips}, **hỏng {fails + errs}** (lỗi so sánh {fails}, ngoại lệ {errs}), bỏ qua {skips}.", ""]
    if not bad:
        out.append("Không có bài nào hỏng.")
        return '\n'.join(out) + '\n'
    # gom theo thông điệp (bỏ số / tên lớp thay đổi) để thấy nguyên nhân chung, vd. 'Method ... not mocked'
    def key(m): return re.sub(r'\d+(\.\d+)?', 'N', m)[:110]
    grp = collections.Counter(key(m) for _, _, m in bad)
    out += ["**Nguyên nhân hay gặp nhất:**", ""]
    for k, c in grp.most_common(6): out.append(f"- {c} bài: `{k}`")
    out += ["", f"**Các bài hỏng (tối đa {limit}):**", ""]
    for cls, name, msg in bad[:limit]: out.append(f"- `{cls}.{name}` — {msg}")
    if len(bad) > limit: out.append(f"- … và {len(bad) - limit} bài nữa")
    out += ["", "_Ghi chú: `unitTests.isReturnDefaultValues = true` đang bật nên hàm Android gọi trong test JVM thuần trả 0 / null / false thay vì ném lỗi "
            "(Color, Bitmap, Log…) — một bài có thể HỎNG VÌ GIÁ TRỊ SAI im lặng (vd. màu = 0). jvm-check dùng stub có hành vi thật nên không thấy. "
            "Cách sửa: Robolectric, hoặc tách phần logic khỏi lớp Android._"]
    return '\n'.join(out) + '\n'

if __name__ == '__main__':
    folder = sys.argv[1] if len(sys.argv) > 1 else 'app/build/test-results/testDebugUnitTest'
    lim = int(sys.argv[2]) if len(sys.argv) > 2 else 25
    sys.stdout.write(summarize(folder, lim))
