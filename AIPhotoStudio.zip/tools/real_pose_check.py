#!/usr/bin/env python3
"""R37b: đối chiếu góc yaw do `face_liquify3d.frame` ước lượng (từ z của 478 điểm) với MA TRẬN BIẾN ĐỔI KHUÔN MẶT của chính model `face_landmarker.task` THẬT.
Tệp model: github.com/Qaanaaq/Face_Landmark_Link/raw/main/Face_Landmarker/face_landmarker.task (hoặc github.com/nlml/deconstruct-mediapipe — cùng tệp);
SHA-256 phải = 64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff (bản float16/1 chính thức của Google; storage.googleapis.com bị chặn ở sandbox).
Cần venv có mediapipe (Tasks API) + opencv + numpy. Chạy:  python3 tools/real_pose_check.py ẢNH1 ẢNH2 ... [--task đường/dẫn/face_landmarker.task]
Kết quả R37b (36 mặt thật, yaw tới 56°): sai số tuyệt đối trung bình 3,7°, trung vị 2,3°, lớn nhất 15,5° (một mặt trong ảnh 3913 px); đổi tập cặp điểm không cải thiện thêm."""
import hashlib
import math
import os
import sys
import urllib.request

import cv2
import mediapipe as mp
import numpy as np
from mediapipe.tasks import python as mpp
from mediapipe.tasks.python import vision

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "verify_ports"))
import face_liquify3d as F  # noqa: E402

URL = "https://raw.githubusercontent.com/Qaanaaq/Face_Landmark_Link/main/Face_Landmarker/face_landmarker.task"
SHA = "64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff"


def get_task(path):
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        urllib.request.urlretrieve(URL, path)
    got = hashlib.sha256(open(path, "rb").read()).hexdigest()
    assert got == SHA, "SHA-256 %s khác bản chính thức" % got
    return path


def landmarker(path):
    return vision.FaceLandmarker.create_from_options(vision.FaceLandmarkerOptions(
        base_options=mpp.BaseOptions(model_asset_path=path), running_mode=vision.RunningMode.IMAGE, num_faces=6,
        min_face_detection_confidence=0.3, min_face_presence_confidence=0.3, output_facial_transformation_matrixes=True))


def yaw_from_matrix(M):
    R = np.array(M)[:3, :3]
    R = R / np.cbrt(abs(np.linalg.det(R)))
    return math.degrees(math.asin(max(-1, min(1, R[0, 2]))))


if __name__ == "__main__":
    argv = sys.argv[1:]
    task = "/tmp/real/face_landmarker.task"
    if "--task" in argv:
        i = argv.index("--task"); task = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
    lm = landmarker(get_task(task))
    errs = []
    for p in argv:
        bgr = cv2.imread(p)
        if bgr is None:
            continue
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        r = lm.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
        for k, f in enumerate(r.face_landmarks):
            a = np.array([[q.x, q.y, q.z] for q in f], np.float64)
            fr = F.frame(a, w, h)
            if fr is None or fr.W3 < 40:
                continue
            ym = yaw_from_matrix(r.facial_transformation_matrixes[k])
            errs.append(abs(fr.yaw - ym))
            print("%-40s f%d  khung yaw %+6.1f  ma trận yaw %+6.1f  lệch %.1f°" % (os.path.basename(p)[-40:], k, fr.yaw, ym, abs(fr.yaw - ym)))
    if errs:
        print("n=%d  MAE %.2f°  trung vị %.2f°  lớn nhất %.1f°" % (len(errs), np.mean(errs), np.median(errs), np.max(errs)))
