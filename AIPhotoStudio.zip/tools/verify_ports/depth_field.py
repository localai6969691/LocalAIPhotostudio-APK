#!/usr/bin/env python3
"""
R30 - Kiểm tra số học của phần "độ sâu do model đo" cho Reframe 2.5D:
  engine/DepthEstimator.kt  (DepthProfile.inputSize / toNchw)
  engine/Reframe.kt         (Reframe.stretch / Reframe.depthFromField)

Không có model thật ở đây, nên kiểm TÍNH CHẤT mà code phải thỏa trên dữ liệu tổng hợp có đáp án:
  * cỡ vào của model: bội của 14, cạnh dài = LONG_EDGE, giữ tỉ lệ, shape cố định thì theo shape;
  * chuẩn hóa ImageNet đúng thứ tự kênh R,G,B;
  * stretch BẤT BIẾN với a·x + b (a > 0) - bản chất độ sâu tương đối -, bền với điểm lạc, trả None khi phẳng / có NaN;
  * depthFromField: giữ thứ tự gần-xa, đưa về 0..1, điểm xoay = trung vị trong chủ thể, biến thiên trong chủ thể chỉ còn SUBJECT_KEEP,
    ngoài chủ thể KHÔNG đổi, chịu field khác cỡ / khác tỉ lệ ảnh, từ chối field hỏng.
  * đột biến: bỏ stretch, đảo chiều, SUBJECT_KEEP = 1, cắt cụt thay vì làm tròn -> phải bị bắt.
Hằng số đọc TỪ mã Kotlin (không chép tay) để bản port không lệch khỏi mã thật.
Đây là bản dịch Python của thuật toán Kotlin, KHÔNG phải chạy chính mã Kotlin: nó chứng minh THIẾT KẾ đúng, không chứng minh mã Kotlin
đã biên dịch / chạy đúng (việc đó là của tools/jvm_check/run_all.sh + R30DepthTest).
Chạy: python3 tools/verify_ports/depth_field.py
"""
import math, os, re, sys
import numpy as np
from scipy.ndimage import uniform_filter

HERE = os.path.dirname(os.path.abspath(__file__))
ENG = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio", "engine")
rf_src = open(os.path.join(ENG, "Reframe.kt"), encoding="utf-8").read()
de_src = open(os.path.join(ENG, "DepthEstimator.kt"), encoding="utf-8").read()


def const(src, name):
    m = re.search(r"const val " + name + r"\s*=\s*([0-9.]+)f?", src)
    assert m, f"không thấy hằng số {name}"
    return float(m.group(1))


def arr3(src, name):
    m = re.search(r"val " + name + r"\s*=\s*floatArrayOf\(([^)]*)\)", src)
    assert m, f"không thấy mảng {name}"
    return np.array([float(x.strip().rstrip("f")) for x in m.group(1).split(",")], dtype=np.float32)


F = np.float32
LO_PCT, HI_PCT, KEEP = F(const(rf_src, "FIELD_LO_PCT")), F(const(rf_src, "FIELD_HI_PCT")), F(const(rf_src, "SUBJECT_KEEP"))
DEPTH_SIDE, SUBJECT_MIN_AREA = int(const(rf_src, "DEPTH_SIDE")), F(const(rf_src, "SUBJECT_MIN_AREA"))
GRAD_BINS, GRAD_MAX, GRAD_PCT = int(const(rf_src, "GRADIENT_BINS")), F(const(rf_src, "GRADIENT_MAX")), F(const(rf_src, "GRADIENT_PCT"))
MAX_CRACK = int(const(rf_src, "MAX_CRACK"))
PATCH, LONG_EDGE = int(const(de_src, "PATCH")), int(const(de_src, "LONG_EDGE"))
MEAN, STD = arr3(de_src, "MEAN"), arr3(de_src, "STD")

fails = []


def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)


def round_half_up(x):  # Kotlin Float.roundToInt: làm tròn về phía +vô cực khi hòa
    return int(np.floor(F(x) + F(0.5)))


# ------------------------------------------------------------------ bản dịch Kotlin: DepthProfile
def input_size(h, w, fixed_h, fixed_w, long_edge=LONG_EDGE, _truncate=False):
    if fixed_h > 0 and fixed_w > 0:
        return fixed_h, fixed_w
    hh, ww = max(1, h), max(1, w)
    target = max(PATCH, long_edge)
    k = F(target) / F(max(hh, ww))
    def side(v):
        q = F(v) * k / F(PATCH)
        n = int(q) if _truncate else round_half_up(q)
        return max(1, n) * PATCH
    return side(hh), side(ww)


def to_nchw(px, _bgr=False):
    r = ((px >> 16) & 255).astype(F) / F(255)
    g = ((px >> 8) & 255).astype(F) / F(255)
    b = (px & 255).astype(F) / F(255)
    if _bgr:
        r, b = b, r
    return np.stack([(r - MEAN[0]) / STD[0], (g - MEAN[1]) / STD[1], (b - MEAN[2]) / STD[2]])


# ------------------------------------------------------------------ bản dịch Kotlin: Resample / guidedFilter
def area_matrix(sn, dn):
    m = np.zeros((dn, sn), dtype=np.float64)
    s = sn / dn
    for x in range(dn):
        a, b = x * s, (x + 1) * s
        i = int(a)
        while i < b and i < sn:
            m[x, i] = (min(b, i + 1) - max(a, i)) / s
            i += 1
    return m


def area(src, dw, dh):
    sh, sw = src.shape
    if (sw, sh) == (dw, dh):
        return src.copy()
    return (area_matrix(sh, dh) @ src.astype(np.float64) @ area_matrix(sw, dw).T).astype(F)


def bilinear(src, dw, dh):
    sh, sw = src.shape
    if (sw, sh) == (dw, dh):
        return src.copy()
    out = np.zeros((dh, dw), dtype=F)
    fx, fy = F(sw) / F(dw), F(sh) / F(dh)
    for y in range(dh):
        gy = float(np.clip((F(y) + F(0.5)) * fy - F(0.5), 0, sh - 1)); y0 = int(gy); y1 = min(sh - 1, y0 + 1); ty = F(gy - y0)
        for x in range(dw):
            gx = float(np.clip((F(x) + F(0.5)) * fx - F(0.5), 0, sw - 1)); x0 = int(gx); x1 = min(sw - 1, x0 + 1); tx = F(gx - x0)
            a = src[y0, x0] * (1 - tx) + src[y0, x1] * tx
            b = src[y1, x0] * (1 - tx) + src[y1, x1] * tx
            out[y, x] = a * (1 - ty) + b * ty
    return out


def box_mean(a, r):  # trung bình hộp (2r+1)^2, chia theo số điểm thật trong cửa sổ (như Kotlin boxMean)
    size = 2 * r + 1
    num = uniform_filter(a.astype(np.float64), size=size, mode="constant", cval=0.0)
    den = uniform_filter(np.ones_like(a, dtype=np.float64), size=size, mode="constant", cval=0.0)
    return (num / den).astype(F)


def guided_filter(guide, p, r, eps):
    mi, mp = box_mean(guide, r), box_mean(p, r)
    cip, ci = box_mean(guide * p, r), box_mean(guide * guide, r)
    var, cov = ci - mi * mi, cip - mi * mp
    a = cov / (var + F(eps))
    b = mp - a * mi
    return box_mean(a, r) * guide + box_mean(b, r)


# ------------------------------------------------------------------ bản dịch Kotlin: Reframe.stretch / depthFromField
def stretch(v, lo=LO_PCT, hi=HI_PCT, _skip=False, _flip=False):
    v = np.asarray(v, dtype=F).ravel()
    if v.size == 0 or not np.all(np.isfinite(v)):
        return None
    if _skip:
        return np.clip(v, 0, 1)
    s = np.sort(v)
    last = s.size - 1
    a = s[int(np.clip(round_half_up(F(lo) * F(last)), 0, last))]
    b = s[int(np.clip(round_half_up(F(hi) * F(last)), 0, last))]
    if b - a <= F(1e-4) * max(max(abs(a), abs(b)), F(1)):
        return None
    out = np.clip((v - a) * (F(1) / (b - a)), 0, 1).astype(F)
    return (1 - out) if _flip else out


class Depth:
    def __init__(self, d, focus, has_subject, from_model):
        self.d, self.focus, self.has_subject, self.from_model = d, focus, has_subject, from_model


def relief_keep(d, inside, shift_px):
    """Bản dịch Reframe.reliefKeep: k = min(1, MAX_CRACK / (shift_px * g99)), g99 = phân vị GRADIENT_PCT của độ dốc BÊN TRONG chủ thể (biểu đồ, lấy cận trên của ô)."""
    if shift_px <= 0 or d.shape != inside.shape:
        return KEEP
    gx = np.abs(d[:-1, 1:] - d[:-1, :-1])
    gy = np.abs(d[1:, :-1] - d[:-1, :-1])
    m = (inside[:-1, :-1] > 0.5) & (inside[:-1, 1:] > 0.5) & (inside[1:, :-1] > 0.5)
    g = np.maximum(gx, gy)[m].astype(F)
    n = g.size
    if n < 100:
        return KEEP
    bins = np.minimum(GRAD_BINS - 1, (g / GRAD_MAX * F(GRAD_BINS)).astype(np.int64))
    acc = np.cumsum(np.bincount(bins, minlength=GRAD_BINS))
    hit = acc >= GRAD_PCT * n
    b = int(np.argmax(hit)) if hit.any() else GRAD_BINS - 1
    g99 = (b + 1) * GRAD_MAX / GRAD_BINS
    gap = shift_px * g99
    return F(1.0) if gap <= MAX_CRACK else F(MAX_CRACK / gap)


def depth_from_field(px, w, h, fv, fw, fh, subject, _skip=False, _flip=False, _keep=None, shift_px=0.0):
    keep = None if _keep is None else F(_keep)
    if fw <= 0 or fh <= 0 or fv.size != fw * fh:
        return None
    norm = stretch(fv, _skip=_skip, _flip=_flip)
    if norm is None:
        return None
    norm = norm.reshape(fh, fw)
    scale = min(1.0, DEPTH_SIDE / max(w, h))
    dw, dh = max(1, int(np.floor(w * scale + 0.5))), max(1, int(np.floor(h * scale + 0.5)))
    n = dw * dh
    pxi = px.astype(np.int64).reshape(h, w)
    luma_full = (0.299 * ((pxi >> 16) & 255) + 0.587 * ((pxi >> 8) & 255) + 0.114 * (pxi & 255)).astype(F)
    luma = area(luma_full, dw, dh) / F(255)
    raw = area(norm, dw, dh) if (fw >= dw and fh >= dh) else bilinear(norm, dw, dh)
    r = max(2, max(dw, dh) // 120)
    smooth = np.clip(guided_filter(luma, raw, r, 4e-3), 0, 1).astype(F)
    full = smooth.copy() if (dw == w and dh == h) else bilinear(smooth, w, h)
    sub = area(subject.reshape(h, w).astype(F), dw, dh) if (subject is not None and subject.size == w * h) else None
    has_subject, subj_d = False, F(0)
    if sub is not None:
        cover = int(np.sum(sub > 0.5))
        if cover >= SUBJECT_MIN_AREA * n:
            has_subject = True
            inside = np.sort(smooth[sub > 0.5])
            subj_d = inside[cover // 2]
            ms = np.clip(guided_filter(luma, np.clip(sub, 0, 1), r, 1e-3), 0, 1)
            up = ms if (dw == w and dh == h) else bilinear(ms, w, h)
            m = up > 0.5
            k_eff = relief_keep(full, up, shift_px) if keep is None else keep
            full[m] = np.clip(subj_d + k_eff * (full[m] - subj_d), 0, 1)
    focus = subj_d if has_subject else np.sort(smooth.ravel())[n // 2]
    return Depth(full, F(focus), has_subject, True)


# ------------------------------------------------------------------ 1) cỡ vào của model
rng = np.random.default_rng(7)
for (h, w) in [(3000, 4000), (4000, 3000), (1080, 1920), (600, 600), (120, 160), (100, 4000), (4000, 100), (1, 1), (37, 41)]:
    ih, iw = input_size(h, w, 0, 0)
    ok = ih % PATCH == 0 and iw % PATCH == 0 and ih >= PATCH and iw >= PATCH and max(ih, iw) == LONG_EDGE if max(h, w) > 1 else ih % PATCH == 0 and iw % PATCH == 0
    # tỉ lệ giữ trong sai số một mảnh (làm tròn về bội của PATCH) - trừ ảnh cực dẹt, nơi cạnh ngắn bị kẹp ở một mảnh
    if min(h, w) * LONG_EDGE / max(h, w) >= 2 * PATCH:
        ok = ok and abs(ih / iw - h / w) <= PATCH / min(ih, iw) * (h / w if h > w else 1) * 1.01 + 0.02
    check(f"cỡ vào {h}x{w} -> {ih}x{iw}: bội của {PATCH}, cạnh dài {LONG_EDGE}, giữ tỉ lệ", ok, (ih, iw))
check("shape cố định 518x518 -> luôn 518x518 dù ảnh dọc/ngang", input_size(4000, 3000, 518, 518) == (518, 518) and input_size(3000, 4000, 518, 518) == (518, 518))
check("shape cố định không vuông 392x700 -> đúng 392x700", input_size(100, 100, 392, 700) == (392, 700))
check("chỉ MỘT chiều cố định (bất thường) -> coi như động, không ném lỗi", input_size(1000, 2000, 518, 0)[1] % PATCH == 0)
check("cạnh dài tùy chỉnh 392 (máy yếu): 4:3 -> 294x392, cạnh dài 392", input_size(3000, 4000, 0, 0, 392) == (294, 392), input_size(3000, 4000, 0, 0, 392))
check("cạnh dài nhỏ hơn một mảnh được nâng lên một mảnh", input_size(500, 500, 0, 0, 3) == (PATCH, PATCH))
check("518 = 37 mảnh: ảnh vuông -> 518x518", input_size(777, 777, 0, 0) == (518, 518))
check("đột biến: cắt cụt thay vì làm tròn -> BỊ BẮT (ít nhất một cỡ khác đi)",
      any(input_size(h, w, 0, 0, _truncate=True) != input_size(h, w, 0, 0) for (h, w) in [(3000, 4000), (1080, 1920), (37, 41), (4000, 3000)]))

# ------------------------------------------------------------------ 2) chuẩn hóa ImageNet
px = np.array([0xFFFFFFFF, 0xFF000000, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF], dtype=np.int64)
t = to_nchw(px)
check("trắng -> (1-mean)/std ở cả 3 kênh", np.allclose(t[:, 0], (1 - MEAN) / STD, atol=1e-6))
check("đen -> -mean/std", np.allclose(t[:, 1], -MEAN / STD, atol=1e-6))
check("đỏ thuần: kênh 0 cao, kênh 1,2 thấp (đúng thứ tự R,G,B)", t[0, 2] > 2 and t[1, 2] < -1.9 and t[2, 2] < -1.7)
check("xanh lá thuần: kênh 1 cao", t[1, 3] > 2 and t[0, 3] < -1.9)
check("xanh dương thuần: kênh 2 cao", t[2, 4] > 2 and t[0, 4] < -1.9)
check("đột biến: đảo R<->B -> BỊ BẮT", not np.allclose(to_nchw(px, _bgr=True)[:, 2], t[:, 2]))

# ------------------------------------------------------------------ 3) stretch
field = rng.normal(5, 2, 5000).astype(F)
s0 = stretch(field)
check("stretch: đầu ra trong [0,1], không NaN", s0 is not None and float(s0.min()) >= 0 and float(s0.max()) <= 1 and np.all(np.isfinite(s0)))
frac0, frac1 = float(np.mean(s0 == 0)), float(np.mean(s0 == 1))
check("stretch: ~2% điểm bị kẹp ở mỗi đầu (phân vị 2% / 98%)", 0.015 <= frac0 <= 0.06 and 0.015 <= frac1 <= 0.06, (frac0, frac1))
worst = 0.0
for _ in range(25):
    a, b = float(rng.uniform(0.05, 40)), float(rng.uniform(-30, 30))
    worst = max(worst, float(np.max(np.abs(stretch(field * F(a) + F(b)) - s0))))
check("stretch BẤT BIẾN với a·x + b (a > 0): sai lệch tối đa < 1e-4 qua 25 phép đổi", worst < 1e-4, worst)
check("stretch: ảnh đảo chiều (a < 0) cho kết quả ĐẢO (1 - s): hợp đồng 'lớn = gần' phụ thuộc chiều đầu ra của model",
      float(np.max(np.abs(stretch(-field) - (1 - s0)))) < 0.02)
big = field.copy(); big[0] = 1e6
check("stretch bền với một điểm lạc khổng lồ (các điểm còn lại đổi < 0.02)", float(np.max(np.abs(stretch(big)[1:] - s0[1:]))) < 0.02)
check("stretch: mảng phẳng -> None", stretch(np.full(100, 3.0, dtype=F)) is None)
check("stretch: gần phẳng (biên độ 1e-6) -> None", stretch((3 + 1e-6 * rng.random(100)).astype(F)) is None)
check("stretch: có NaN / Inf / mảng rỗng -> None", stretch(np.array([1, np.nan, 3], dtype=F)) is None and stretch(np.array([1, np.inf, 3], dtype=F)) is None and stretch(np.array([], dtype=F)) is None)
check("stretch: model xuất thang nhỏ (0..0.01) vẫn dùng được (không bị coi là phẳng)", stretch((rng.random(500) * 0.01).astype(F)) is not None)
check("stretch: thang lớn (0..1e5) vẫn dùng được", stretch((rng.random(500) * 1e5).astype(F)) is not None)
check("đột biến: bỏ stretch -> mất bất biến thang, BỊ BẮT", float(np.max(np.abs(stretch(field * F(3) + F(1), _skip=True) - stretch(field, _skip=True)))) > 0.5)

# ------------------------------------------------------------------ 4) depthFromField trên cảnh tổng hợp
W, H = 160, 120
yy, xx = np.mgrid[0:H, 0:W]
img = (0xFF << 24) | ((90 + (xx % 7)) << 16) | ((150 + (yy % 5)) << 8) | 200
img = img.astype(np.int64).ravel()
# nghịch đảo độ sâu: càng xuống thấp càng gần (đáy ảnh gần nhất), thang và gốc tùy ý như model thật
fw, fh = 74, 56
fy = np.mgrid[0:fh, 0:fw][0].astype(F)
ramp = (fy / (fh - 1) * 6.0 + 2.0).astype(F).ravel()
d = depth_from_field(img, W, H, ramp, fw, fh, None)
rows = d.d.mean(axis=1)
check("không chủ thể: độ sâu tăng đều từ trên xuống dưới (trên xa, dưới gần)", d is not None and np.all(np.diff(rows) > -1e-3) and rows[-1] - rows[0] > 0.8, (rows[0], rows[-1]))
check("độ sâu trong [0,1], phủ gần hết dải (min < 0.05, max > 0.95), không NaN", float(d.d.min()) >= 0 and float(d.d.max()) <= 1 and float(d.d.min()) < 0.05 and float(d.d.max()) > 0.95 and np.all(np.isfinite(d.d)))
check("không chủ thể: hasSubject = False, từ model, điểm xoay ≈ trung vị ảnh (0.5 ± 0.1)", (not d.has_subject) and d.from_model and abs(float(d.focus) - 0.5) < 0.1, d.focus)
d2 = depth_from_field(img, W, H, ramp * F(7.5) + F(3), fw, fh, None)
check("BẤT BIẾN thang end-to-end: field·7.5 + 3 cho cùng bản đồ độ sâu (sai lệch < 1e-3)", float(np.max(np.abs(d2.d - d.d))) < 1e-3, float(np.max(np.abs(d2.d - d.d))))
check("đột biến: đảo chiều (1 - stretch) -> thứ tự gần-xa đảo, BỊ BẮT", depth_from_field(img, W, H, ramp, fw, fh, None, _flip=True).d.mean(axis=1)[0] > depth_from_field(img, W, H, ramp, fw, fh, None, _flip=True).d.mean(axis=1)[-1])
d3 = depth_from_field(img, W, H, ramp * F(7.5) + F(3), fw, fh, None, _skip=True)
check("đột biến: bỏ stretch -> độ sâu phụ thuộc thang model, BỊ BẮT", d3 is None or float(np.max(np.abs(d3.d - d.d))) > 0.3)

# field khác cỡ / khác tỉ lệ ảnh
for (bw, bh, label) in [(518, 518, "ép vuông lớn hơn ảnh (nhánh area)"), (64, 64, "ép vuông nhỏ hơn ảnh (nhánh bilinear)"), (200, 100, "lẫn: rộng hơn, thấp hơn (bilinear)"), (160, 120, "đúng cỡ ảnh")]:
    gy = np.mgrid[0:bh, 0:bw][0].astype(F)
    f = (gy / (bh - 1) * 4 + 1).ravel()
    dd = depth_from_field(img, W, H, f, bw, bh, None)
    r2 = dd.d.mean(axis=1) if dd is not None else None
    check(f"field {bw}x{bh} ({label}): ra bản đồ cỡ ảnh, đơn điệu theo chiều dọc", dd is not None and dd.d.shape == (H, W) and np.all(np.diff(r2) > -2e-3) and r2[-1] - r2[0] > 0.8, None if dd is None else (r2[0], r2[-1]))

# chủ thể: elip ở giữa; trong chủ thể model đo có độ lồi (mũi/má) + thang nền
cx, cy, rx, ry = 80, 62, 22, 34
ell = (((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2 <= 1.0)
sub = ell.astype(F).ravel()
sy_, sx_ = np.mgrid[0:fh, 0:fw]
ex, ey = (sx_ + 0.5) / fw * W, (sy_ + 0.5) / fh * H
bump = np.clip(1 - (((ex - cx) / rx) ** 2 + ((ey - cy) / ry) ** 2), 0, None)
fld = ((fy / (fh - 1) * 2 + 3) + 5.0 * bump).astype(F).ravel()      # nền dốc nhẹ + chủ thể nhô lên tới +5
dn = depth_from_field(img, W, H, fld, fw, fh, None)
ds = depth_from_field(img, W, H, fld, fw, fh, sub)
check("có chủ thể: hasSubject = True", ds.has_subject)
outside = ~ell
check("NGOÀI chủ thể độ sâu KHÔNG đổi so với khi không có mặt nạ (đúng từng điểm)", float(np.max(np.abs(ds.d[outside] - dn.d[outside]))) < 1e-6, float(np.max(np.abs(ds.d[outside] - dn.d[outside]))))
far = (((xx - cx) / (rx + 2)) ** 2 + ((yy - cy) / (ry + 2)) ** 2 > 1.0)
check("NGOÀI elip nới 2 điểm: không đổi (điều kiện dùng trong R30DepthTest)", float(np.max(np.abs(ds.d[far] - dn.d[far]))) < 1e-6)
check("mặt nạ sau lọc dẫn hướng chỉ lấn tối đa 1 điểm ra ngoài elip (số điểm đổi ngoài elip < 3% chu vi·1)", int(np.sum((np.abs(ds.d - dn.d) > 1e-6) & outside)) < 0.03 * 2 * math.pi * math.sqrt((rx * rx + ry * ry) / 2) * 3)
yy2, xx2 = yy, xx
core = (((xx2 - cx) / (rx * 0.6)) ** 2 + ((yy2 - cy) / (ry * 0.6)) ** 2 <= 1.0)   # lõi, xa mép
std_before, std_after = float(dn.d[core].std()), float(ds.d[core].std())
check("biến thiên TRONG chủ thể giảm còn ≈ SUBJECT_KEEP (tỉ lệ trong ±0.06 quanh %.2f)" % KEEP, abs(std_after / std_before - float(KEEP)) < 0.06, std_after / std_before)
inside_med = float(np.median(dn.d[ell]))      # trung vị trên TOÀN mặt nạ chủ thể (đúng vùng mà Kotlin lấy), không phải riêng lõi
check("điểm xoay ≈ độ sâu trung vị trên toàn mặt nạ chủ thể (± 0.06)", abs(float(ds.focus) - inside_med) < 0.06, (float(ds.focus), inside_med))
check("điểm xoay KHÔNG phải trung vị lõi nhô cao (đã phân biệt hai vùng: lõi cao hơn toàn mặt nạ ≥ 0.1)", float(np.median(dn.d[core])) - inside_med > 0.1)
check("chủ thể nhô gần hơn nền xung quanh (focus > độ sâu nền sát mép ngoài)", float(ds.focus) > float(ds.d[(~ell) & (np.abs(xx - cx) < rx + 6) & (np.abs(xx - cx) > rx + 2) & (np.abs(yy - cy) < 4)].mean()))
check("đột biến: SUBJECT_KEEP = 1 (không làm phẳng) -> biến thiên trong chủ thể không giảm, BỊ BẮT",
      abs(depth_from_field(img, W, H, fld, fw, fh, sub, _keep=1.0).d[core].std() / std_before - float(KEEP)) > 0.5)
check("đột biến: SUBJECT_KEEP = 0 (phẳng hoàn toàn) -> lệch khỏi thiết kế, BỊ BẮT",
      abs(depth_from_field(img, W, H, fld, fw, fh, sub, _keep=0.0).d[core].std() / std_before - float(KEEP)) > 0.15)

# ---- hệ số giữ độ lồi SUY RA từ độ dịch thực tế (reliefKeep) thay cho hằng số đoán
def inner_stats(dmap, sel_mask):
    gx = np.abs(dmap[:-1, 1:] - dmap[:-1, :-1]); gy = np.abs(dmap[1:, :-1] - dmap[:-1, :-1])
    mm = (sel_mask[:-1, :-1]) & (sel_mask[:-1, 1:]) & (sel_mask[1:, :-1])
    return np.maximum(gx, gy)[mm]


sel = np.zeros((H, W), bool); sel[ell] = True
sub2 = sub.reshape(H, W)
keeps = {}
for sp in (0.5, 2, 8, 24, 48, 96):
    dd = depth_from_field(img, W, H, fld, fw, fh, sub, shift_px=sp)
    ratio = float(dd.d[core].std() / std_before)
    g_after = inner_stats(dd.d, sel & (np.abs(xx - cx) < rx - 3) & (np.abs(yy - cy) < ry - 3))
    exact_g99 = float(np.percentile(g_after, 99)) if g_after.size else 0.0
    keeps[sp] = (ratio, exact_g99)
check("reliefKeep: dịch NHỎ (0.5 px) giữ nguyên độ lồi (tỉ lệ biến thiên >= 0.95) — không còn bị làm phẳng cứng 0.25", keeps[0.5][0] >= 0.95, keeps[0.5])
check("reliefKeep: tỉ lệ giữ KHÔNG tăng khi độ dịch tăng (0.5 -> 96 px)", all(keeps[a][0] >= keeps[b][0] - 0.01 for a, b in [(0.5, 2), (2, 8), (8, 24), (24, 48), (48, 96)]), {k: round(v[0], 3) for k, v in keeps.items()})
check("reliefKeep: dịch LỚN (96 px) làm phẳng mạnh (tỉ lệ < 0.5) nhưng vẫn > 0", 0 < keeps[96][0] < 0.5, keeps[96])
check("BẢO ĐẢM: độ dốc phân vị 99 trong chủ thể sau khi giữ x độ dịch <= MAX_CRACK (%d px) ở mọi độ dịch (đo bằng phân vị chính xác)" % MAX_CRACK,
      all(sp * v[1] <= MAX_CRACK * 1.001 for sp, v in keeps.items() if v[0] < 0.999), {k: round(k * v[1], 3) for k, v in keeps.items()})
# kiểm tuyệt đối trên đoạn dốc tuyến tính biết trước đáp án
ramp_d = np.tile(np.linspace(0, 0.3, 120, dtype=F), (60, 1))             # dốc 0.3/119 mỗi điểm ảnh theo x
ins = np.ones((60, 120), F)
slope = 0.3 / 119
for sp in (10, 40, 100, 300):
    exp = 1.0 if sp * slope <= MAX_CRACK else MAX_CRACK / (sp * slope)
    got = float(relief_keep(ramp_d, ins, sp))
    check(f"reliefKeep trên dốc tuyến tính, dịch {sp}: ra {got:.4f}, đáp án giải tích {exp:.4f} (sai số <= 2 %, lệch về phía AN TOÀN: không lớn hơn)", got <= exp * 1.0005 and got >= exp * 0.98, (got, exp))
check("reliefKeep: mặt phẳng (dốc 0) -> giữ nguyên 1.0", float(relief_keep(np.full((60, 120), 0.4, F), ins, 80)) == 1.0)
check("reliefKeep: không truyền độ dịch (0) hoặc quá ít điểm trong chủ thể -> dự phòng SUBJECT_KEEP", relief_keep(ramp_d, ins, 0) == KEEP and relief_keep(ramp_d[:5, :5], ins[:5, :5], 50) == KEEP)
mut_const = depth_from_field(img, W, H, fld, fw, fh, sub, shift_px=0.5, _keep=KEEP)
check("đột biến: quay lại hằng số 0.25 -> dịch nhỏ vẫn bị làm phẳng, BỊ BẮT (tỉ lệ %.2f < 0.95)" % float(mut_const.d[core].std() / std_before), float(mut_const.d[core].std() / std_before) < 0.95)
mut_big = depth_from_field(img, W, H, fld, fw, fh, sub, shift_px=96, _keep=1.0)
gm = inner_stats(mut_big.d, sel & (np.abs(xx - cx) < rx - 3) & (np.abs(yy - cy) < ry - 3))
check("đột biến: không làm phẳng (keep = 1) -> dịch lớn vượt MAX_CRACK, BỊ BẮT", 96 * float(np.percentile(gm, 99)) > MAX_CRACK * 1.2, 96 * float(np.percentile(gm, 99)))

# chủ thể quá nhỏ (< SUBJECT_MIN_AREA) -> bỏ qua; mặt nạ sai cỡ -> bỏ qua
tiny = np.zeros((H, W), dtype=F); tiny[10:14, 10:14] = 1
dt = depth_from_field(img, W, H, fld, fw, fh, tiny.ravel())
check("chủ thể nhỏ hơn SUBJECT_MIN_AREA -> hasSubject = False", not dt.has_subject)
dbad = depth_from_field(img, W, H, fld, fw, fh, np.ones(7, dtype=F))
check("mặt nạ sai cỡ -> bỏ qua (không ném lỗi), hasSubject = False", dbad is not None and not dbad.has_subject)

# từ chối field hỏng
check("field phẳng -> None (người gọi quay về độ sâu giả)", depth_from_field(img, W, H, np.full(fw * fh, 4.0, dtype=F), fw, fh, None) is None)
check("field sai kích thước (v.size != w*h) -> None", depth_from_field(img, W, H, ramp[:-1], fw, fh, None) is None)
check("field có NaN -> None", depth_from_field(img, W, H, np.where(np.arange(fw * fh) == 5, np.nan, ramp).astype(F), fw, fh, None) is None)
check("field cỡ 0 -> None", depth_from_field(img, W, H, ramp, 0, fh, None) is None)

# ảnh lớn hơn DEPTH_SIDE: bản đồ dựng ở cỡ nhỏ rồi phóng về cỡ ảnh
BW, BH = 900, 600
big_img = np.full(BW * BH, 0xFF808080, dtype=np.int64)
gy = np.mgrid[0:BH // 4, 0:BW // 4][0].astype(F)
dbg = depth_from_field(big_img, BW, BH, (gy / (BH // 4 - 1) * 3 + 1).ravel(), BW // 4, BH // 4, None)
check("ảnh 900x600 (> DEPTH_SIDE): bản đồ cỡ ảnh, đơn điệu, hữu hạn", dbg.d.shape == (BH, BW) and np.all(np.isfinite(dbg.d)) and np.all(np.diff(dbg.d.mean(axis=1)) > -2e-3))

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
