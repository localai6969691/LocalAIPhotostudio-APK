"""Port Python của ToneOps.selectiveColor (Selective Color kiểu Photoshop, chế độ Relative trên CMYK ngây thơ)."""
import numpy as np, math

def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)

CENTERS = [0, 60, 120, 180, 240, 300]   # Reds, Yellows, Greens, Cyans, Blues, Magentas

def weights(r, g, b):
    mx = np.maximum(r, np.maximum(g, b)); mn = np.minimum(r, np.minimum(g, b)); d = mx - mn
    dd = np.where(d < 1e-6, 1, d)
    h = np.where(mx == r, 60 * (((g - b) / dd) % 6), np.where(mx == g, 60 * ((b - r) / dd + 2), 60 * ((r - g) / dd + 4)))
    h = h % 360
    sw = smooth(0.03, 0.25, d)
    W = []
    for c in CENTERS:
        diff = np.abs(h - c); diff = np.where(diff > 180, 360 - diff, diff)
        W.append(np.maximum(0, 1 - diff / 60) * sw)
    whites = smooth(0.55, 0.95, mn)
    blacks = 1 - smooth(0.12, 0.45, mx)
    neutrals = (1 - sw) * (1 - whites) * (1 - blacks)
    return W + [whites, neutrals, blacks]

def selective(img, vals, absolute=False):
    """img: (...,3) float 0..1; vals: 36 số (9 dải x C,M,Y,K) trong -1..1."""
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    k = 1 - np.maximum(r, np.maximum(g, b)); den = np.where(1 - k < 1e-6, 1, 1 - k)
    c = np.where(1 - k < 1e-6, 0, (1 - r - k) / den); m = np.where(1 - k < 1e-6, 0, (1 - g - k) / den); y = np.where(1 - k < 1e-6, 0, (1 - b - k) / den)
    W = weights(r, g, b)
    dC = sum(W[i] * vals[i * 4] for i in range(9)); dM = sum(W[i] * vals[i * 4 + 1] for i in range(9))
    dY = sum(W[i] * vals[i * 4 + 2] for i in range(9)); dK = sum(W[i] * vals[i * 4 + 3] for i in range(9))
    if absolute:   # Photoshop "Absolute": cộng thẳng điểm phần trăm
        c2 = np.clip(c + dC, 0, 1); m2 = np.clip(m + dM, 0, 1); y2 = np.clip(y + dY, 0, 1); k2 = np.clip(k + dK, 0, 1)
    else:          # "Relative": thay đổi theo tỉ lệ lượng mực đang có
        c2 = np.clip(c * np.maximum(0, 1 + dC), 0, 1); m2 = np.clip(m * np.maximum(0, 1 + dM), 0, 1)
        y2 = np.clip(y * np.maximum(0, 1 + dY), 0, 1); k2 = np.clip(k * np.maximum(0, 1 + dK), 0, 1)
    return np.stack([(1 - c2) * (1 - k2), (1 - m2) * (1 - k2), (1 - y2) * (1 - k2)], -1)

if __name__ == "__main__":
    rng = np.random.default_rng(3)
    img = rng.random((200, 200, 3))
    zero = [0.0] * 36
    print("identity max error:", float(np.abs(selective(img, zero) - img).max()))
    ws = np.stack(weights(img[..., 0], img[..., 1], img[..., 2]), -1)
    print("hue weights sum to sw (chromatic part):", float(np.abs(ws[..., :6].sum(-1) - smooth(0.03, 0.25, img.max(-1) - img.min(-1))).max()))
    print("weight range:", float(ws.min()), float(ws.max()))
    def px(rgb): return np.array([[rgb]], float)
    red = px((1, 0, 0))
    v = zero[:]; v[0 * 4 + 1] = -1   # Reds: Magenta -100%
    print("red with Reds magenta -100% ->", np.round(selective(red, v)[0, 0], 3), "(expect yellow 1,1,0)")
    v = zero[:]; v[1 * 4 + 0] = 1    # Yellows: cyan +100%
    yel = px((1, 1, 0)); print("yellow with Yellows cyan +100% ->", np.round(selective(yel, v)[0, 0], 3), "(c was 0 so relative mode leaves it)")
    v = zero[:]; v[2 * 4 + 1] = 0.5  # Greens: magenta +50%
    grn = px((0.2, 0.7, 0.3)); print("green", grn[0, 0], "Greens magenta +50% ->", np.round(selective(grn, v)[0, 0], 3), "(green drops: more magenta)")
    v = zero[:]; v[7 * 4 + 3] = -0.8  # Neutrals: black -80%
    gray = px((0.5, 0.5, 0.5)); print("gray 0.5 with Neutrals black -80% ->", np.round(selective(gray, v)[0, 0], 3), "(lighter)")
    v = zero[:]; v[6 * 4 + 2] = 1     # Whites: yellow +100% on a white pixel with tiny yellow tint
    wh = px((1, 0.97, 0.9)); print("white-ish", wh[0, 0], "Whites yellow +100% ->", np.round(selective(wh, v)[0, 0], 3), "(warmer)")
    # selectivity: adjusting Reds must not touch blue pixels
    v = zero[:]; v[0 * 4 + 1] = -1; blue = px((0.1, 0.2, 0.9)); print("blue untouched by Reds:", float(np.abs(selective(blue, v) - blue).max()))

    v = zero[:]; v[2 * 4 + 1] = 0.5
    print("ABSOLUTE green", grn[0, 0], "Greens magenta +50 points ->", np.round(selective(grn, v, True)[0, 0], 3), "(green channel drops)")
    v = zero[:]; v[8 * 4 + 3] = 0.5; dark = px((0.1, 0.1, 0.12))
    print("ABSOLUTE dark", dark[0, 0], "Blacks black +50 ->", np.round(selective(dark, v, True)[0, 0], 3), "(darker)")
    print("ABSOLUTE identity error:", float(np.abs(selective(img, zero, True) - img).max()))
