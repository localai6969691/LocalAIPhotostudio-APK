import numpy as np
from collections import deque
def select(px,sx,sy,tol=28):
    h,w,_=px.shape
    x0=min(max(sx,0),w-1); y0=min(max(sy,0),h-1)
    ys=[min(max(y0+d,0),h-1) for d in range(-2,3)]; xs=[min(max(x0+d,0),w-1) for d in range(-2,3)]
    blk=px[np.ix_(ys,xs)].reshape(-1,3).astype(int)
    r0,g0,b0=(blk.sum(0)//25)
    limit=tol*3
    out=np.zeros((h,w),np.uint8); q=deque([(y0,x0)]); out[y0,x0]=255
    while q:
        y,x=q.popleft()
        for dy,dx in ((0,-1),(0,1),(-1,0),(1,0)):
            yy,xx=y+dy,x+dx
            if 0<=yy<h and 0<=xx<w and out[yy,xx]==0:
                p=px[yy,xx].astype(int)
                if abs(p[0]-r0)+abs(p[1]-g0)+abs(p[2]-b0)<=limit:
                    out[yy,xx]=255; q.append((yy,xx))
    return out
rng=np.random.default_rng(1)
# 1) two flat regions + noise: left red, right blue
img=np.zeros((100,200,3),np.uint8); img[:,:100]=(200,40,40); img[:,100:]=(40,60,200)
img=np.clip(img.astype(int)+rng.integers(-6,7,img.shape),0,255).astype(np.uint8)
m=select(img,30,50)
print("red half selected:",int((m[:,:100]>0).sum()),"/",100*100,"  leaked to blue:",int((m[:,100:]>0).sum()))
# 2) a vertical sky gradient: the selection must stop where color drifts beyond tolerance (fixed reference color)
g=np.zeros((200,50,3),np.uint8)
for y in range(200): g[y,:]=(60+y*0.6,120+y*0.5,230-y*0.3)
for tol in (10,28,60):
    m=select(g,25,0,tol); rows=int((m[:,25]>0).sum()); print(f"gradient tol={tol}: selected rows={rows}/200")
# 3) hole: a different-colored island inside the region must stay excluded (4-connectivity)
img2=np.full((60,60,3),(120,200,120),np.uint8); img2[25:35,25:35]=(250,250,20)
m=select(img2,5,5); print("island excluded:",int((m[25:35,25:35]>0).sum())==0,"  region px:",int((m>0).sum()),"of",60*60-100)
