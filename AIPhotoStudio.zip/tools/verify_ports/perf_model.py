#!/usr/bin/env python3
"""
Kiểm tra hồ sơ hiệu năng SUY RA từ phép đo (R30g) thay cho bảng ba hạng theo RAM:
  routing/Perf.kt  (PerfModel.sideForBudget / previewLo / previewHi / maxSide / poolSlots / threads / tierOf / blend, PerfProfile.derive)
Hằng số đọc TỪ mã Kotlin. Kiểm TÍNH CHẤT trên lưới máy giả lập (tốc độ ms/MP x tần số làm tươi x heap x RAM còn trống) — KHÔNG có số đo từ điện thoại thật:
  * mỗi cạnh dựng ra đúng là cạnh LỚN NHẤT còn trong ngân sách thời gian tương ứng (trừ khi bị sàn / trần kẹp);
  * cạnh làm việc là nhỏ nhất của chặn thời gian / heap Java / bộ nhớ native (20 bản ảnh x 4 B = lịch sử hoàn tác 15 + 5 đang dùng) và bị kẹp [sàn, 2560];
  * đơn điệu: máy nhanh hơn / nhiều bộ nhớ hơn không bao giờ nhận cỡ nhỏ hơn; màn 120 Hz không nhận xem-trước-khi-kéo lớn hơn 60 Hz;
  * xem trước kéo <= xem trước thả <= cạnh làm việc; hồ model 1..12; số luồng 1..4; nhãn hạng tái hiện bảng cũ (1536 / 2048 / 2560 -> LOW / MID / HIGH);
  * blend: số đo nhanh được nhận ngay, số đo chậm chỉ đẩy lên tối đa 5 %/lần (một lần đo trúng lúc máy bận không làm hồ sơ kém đi);
  * đột biến: bỏ chặn native, bỏ chặn heap, đảo đơn vị khung -> phải bị bắt.
Chạy: python3 tools/verify_ports/perf_model.py
"""
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio")
pk = open(os.path.join(SRC, "routing", "Perf.kt"), encoding="utf-8").read()
ie = open(os.path.join(SRC, "engine", "ImageEngine.kt"), encoding="utf-8").read()
vm = open(os.path.join(SRC, "MainViewModel.kt"), encoding="utf-8").read()
obj = pk[pk.index("object PerfModel"):]

C = {}
for m in re.finditer(r"const val (\w+) = ([^\n]+)", obj):
    expr = m.group(2).strip()
    if not re.fullmatch(r"[0-9A-Za-z_ .*/+()-]+", expr):
        continue
    C[m.group(1)] = eval(expr, {"__builtins__": {}}, dict(C))
need = ["INSTANT_MS", "FRAME_COUNT", "BAKE_MS", "BAKE_CHAIN_FACTOR", "HEAP_BYTES_PER_PIXEL", "HEAP_SAFETY", "NATIVE_BITMAPS", "NATIVE_BYTES_PER_PIXEL", "NATIVE_SHARE",
        "POOL_SLOT_MB", "POOL_SHARE", "ASPECT", "MAX_THREADS", "BLEND_UP", "SIDE_FLOOR", "SIDE_CEIL", "TIER_LOW_BELOW", "TIER_HIGH_FROM"]
missing = [k for k in need if k not in C]
assert not missing, f"thiếu hằng số {missing}"
IE_HEAP_BPP = int(re.search(r"const val UPSCALE_HEAP_BYTES_PER_PIXEL = (\d+)", ie).group(1))
UNDO_MAX = int(re.search(r"if \(undoStack\.size > (\d+)\) undoStack\.removeFirst\(\)", vm).group(1))

fails = []


def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)


def round_half_up(x):
    return int(math.floor(x + 0.5))


# ------------------------------------------------------------------ bản dịch Kotlin
def side_for_budget(ms_per_mp, budget_ms, c=C):
    if not (ms_per_mp > 0) or not (budget_ms > 0):
        return 0
    return int(math.sqrt(budget_ms / ms_per_mp * 1e6 * c["ASPECT"]))


def side_for_memory(nbytes, safety, bpp, c=C):
    if not (nbytes > 0):
        return 0
    return int(math.sqrt(nbytes * safety / bpp * c["ASPECT"]))


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def preview_lo(m, c=C, _frame_ms=None):
    ms, hz, heap, avail = m
    fr = (1000.0 / max(1.0, hz) * c["FRAME_COUNT"]) if _frame_ms is None else _frame_ms
    return clamp(side_for_budget(ms, fr, c), 320, 1024)


def preview_hi(m, c=C):
    return clamp(side_for_budget(m[0], c["INSTANT_MS"], c), 512, 2048)


def max_side(m, c=C, _no_native=False, _no_heap=False):
    ms, hz, heap, avail = m
    t = side_for_budget(ms * c["BAKE_CHAIN_FACTOR"], c["BAKE_MS"], c)
    h = side_for_memory(max(0, heap), c["HEAP_SAFETY"], c["HEAP_BYTES_PER_PIXEL"], c) if not _no_heap else 10 ** 9
    n = side_for_memory(max(0, avail) * 1024.0 * 1024.0, c["NATIVE_SHARE"], c["NATIVE_BYTES_PER_PIXEL"], c) if not _no_native else 10 ** 9
    return clamp(min(t, h, n), c["SIDE_FLOOR"], c["SIDE_CEIL"])


def pool_slots(avail_mb, c=C):
    return clamp(round_half_up(max(0, avail_mb) * c["POOL_SHARE"] / c["POOL_SLOT_MB"]), 1, 12)


def threads(cores, c=C):
    return clamp(cores, 1, c["MAX_THREADS"])


def tier_of(side, c=C):
    return "LOW" if side < c["TIER_LOW_BELOW"] else ("HIGH" if side >= c["TIER_HIGH_FROM"] else "MID")


def derive(m, cores=8, c=C, **kw):
    ms = max_side(m, c, **kw)
    hi = min(preview_hi(m, c), ms)
    lo = min(preview_lo(m, c), hi)
    return dict(tier=tier_of(ms, c), maxSide=ms, previewHi=hi, previewLo=lo, threads=threads(cores, c), pool=pool_slots(m[3], c))


def blend(stored, measured, c=C):
    return measured if not (stored > 0) else min(measured, stored * c["BLEND_UP"])


MB = 1024 * 1024
# ------------------------------------------------------------------ hằng số suy ra từ mã khác
check("20 B / điểm ảnh heap = ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL (cùng một số đếm)", C["HEAP_BYTES_PER_PIXEL"] == IE_HEAP_BPP, (C["HEAP_BYTES_PER_PIXEL"], IE_HEAP_BPP))
check("số bitmap native = lịch sử hoàn tác trong MainViewModel (%d) + 5 bản đang dùng; 4 B x số đó = byte / điểm ảnh" % UNDO_MAX,
      C["NATIVE_BITMAPS"] == UNDO_MAX + 5 and C["NATIVE_BYTES_PER_PIXEL"] == 4 * C["NATIVE_BITMAPS"], (C["NATIVE_BITMAPS"], UNDO_MAX))
check("trần cạnh làm việc 2560 = cạnh lớn nhất của bảng cũ (phạm vi sản phẩm đã thiết kế)", C["SIDE_CEIL"] == 2560)
check("điểm cắt hạng là điểm GIỮA các cạnh bảng cũ: (1536+2048)/2 = 1792, (2048+2560)/2 = 2304", C["TIER_LOW_BELOW"] == 1792 and C["TIER_HIGH_FROM"] == 2304)
check("nhãn hạng tái hiện bảng cũ: 1536 -> LOW, 2048 -> MID, 2560 -> HIGH", [tier_of(1536), tier_of(2048), tier_of(2560)] == ["LOW", "MID", "HIGH"])
check("khe hồ model = bộ nhớ đỉnh ONNX 511 MB (AI Hub, Galaxy S25) x 1,3 dự phòng = 664 ~ 660", abs(C["POOL_SLOT_MB"] - 511 * 1.3) <= 10)

# ------------------------------------------------------------------ cạnh theo ngân sách: đúng là cạnh LỚN NHẤT còn trong ngân sách
bad = []
for ms in (10, 25, 60, 120, 250, 600, 1500):
    for budget in (8.3, 50, 100, 3000):
        s = side_for_budget(ms, budget)
        px = s * (s / C["ASPECT"])
        px2 = (s + 2) * ((s + 2) / C["ASPECT"])
        if px / 1e6 * ms > budget * 1.0001 or px2 / 1e6 * ms <= budget:
            bad.append((ms, budget, s))
check("sideForBudget: thời gian ở cạnh trả về <= ngân sách và cạnh +2 điểm đã vượt (lớn nhất) — 28 tổ hợp", not bad, bad[:3])
check("số đo không hợp lệ (0, âm, NaN) -> 0 (rồi bị kẹp vào sàn, không chia cho 0)", side_for_budget(0, 100) == 0 and side_for_budget(-5, 100) == 0 and side_for_budget(float("nan"), 100) == 0 and side_for_budget(50, 0) == 0)

# ------------------------------------------------------------------ lưới máy giả lập
grid = []
for ms in (10, 25, 60, 120, 250, 600, 1500):
    for hz in (60, 90, 120):
        for heap in (64, 128, 256, 512):
            for avail in (500, 1000, 2000, 4000, 8000):
                grid.append((ms, hz, heap * MB, avail))
viol = []
for m in grid:
    d = derive(m)
    if not (1024 <= d["maxSide"] <= C["SIDE_CEIL"] and 512 <= d["previewHi"] <= d["maxSide"] + 0 or d["maxSide"] < 512):
        viol.append(("giới hạn", m, d))
    if not (d["previewLo"] <= d["previewHi"] <= d["maxSide"]):
        viol.append(("thứ tự", m, d))
    if not (320 <= d["previewLo"] and 1 <= d["pool"] <= 12 and 1 <= d["threads"] <= 4):
        viol.append(("biên", m, d))
check("lưới %d máy: kéo <= thả <= cạnh làm việc, trong sàn / trần, hồ 1..12, luồng 1..4" % len(grid), not viol, viol[:2])

# maxSide: đúng là min của ba chặn khi chưa chạm sàn / trần
viol = []
for m in grid:
    ms, hz, heap, avail = m
    t = side_for_budget(ms * C["BAKE_CHAIN_FACTOR"], C["BAKE_MS"])
    h = side_for_memory(heap, C["HEAP_SAFETY"], C["HEAP_BYTES_PER_PIXEL"])
    n = side_for_memory(avail * MB, C["NATIVE_SHARE"], C["NATIVE_BYTES_PER_PIXEL"])
    exp = clamp(min(t, h, n), C["SIDE_FLOOR"], C["SIDE_CEIL"])
    if max_side(m) != exp:
        viol.append((m, max_side(m), exp))
    s = max_side(m)
    if s > C["SIDE_FLOOR"]:                                           # chưa bị sàn nâng lên: mọi chặn đều phải được tôn trọng
        px = s * s / C["ASPECT"]
        if px / 1e6 * ms * C["BAKE_CHAIN_FACTOR"] > C["BAKE_MS"] * 1.001 or px * C["HEAP_BYTES_PER_PIXEL"] > heap * C["HEAP_SAFETY"] * 1.001 or px * C["NATIVE_BYTES_PER_PIXEL"] > avail * MB * C["NATIVE_SHARE"] * 1.001:
            viol.append(("vi phạm chặn", m, s))
check("maxSide = min(thời gian, heap, native) kẹp [sàn, 2560]; khi chưa chạm sàn thì CẢ BA chặn đều được tôn trọng (420 máy)", not viol, viol[:2])

# đơn điệu
def monotone(f, key_values, axis):
    bad = []
    for base in grid:
        prev = None
        for kv in key_values:
            m = list(base); m[axis] = kv; v = f(tuple(m))
            if prev is not None and v > prev + 0:                      # axis tăng làm kết quả tăng -> vi phạm (dùng cho trục "chậm hơn")
                bad.append((base, kv))
            prev = v
    return bad


slow = [10, 25, 60, 120, 250, 600, 1500]
check("máy CHẬM hơn (ms/MP tăng) không bao giờ nhận cạnh LỚN hơn: maxSide, previewHi, previewLo", not monotone(max_side, slow, 0) and not monotone(preview_hi, slow, 0) and not monotone(preview_lo, slow, 0))
more_heap = [64 * MB, 128 * MB, 256 * MB, 512 * MB]
bad = []
for base in grid:
    prev = None
    for hv in more_heap:
        m = list(base); m[2] = hv; v = max_side(tuple(m))
        if prev is not None and v < prev:
            bad.append(base)
        prev = v
    prev = None
    for av in (500, 1000, 2000, 4000, 8000):
        m = list(base); m[3] = av; v = max_side(tuple(m)); p = pool_slots(av)
        if prev is not None and (v < prev[0] or p < prev[1]):
            bad.append(("avail", base))
        prev = (v, p)
check("NHIỀU bộ nhớ hơn (heap, RAM còn trống) không bao giờ nhận cạnh / hồ NHỎ hơn", not bad, bad[:2])
check("màn 120 Hz không nhận xem-trước-khi-kéo LỚN hơn 60 Hz (khung ngắn hơn)", all(preview_lo((ms, 120, 0, 0)) <= preview_lo((ms, 60, 0, 0)) for ms in slow))
check("ví dụ: máy 120 ms/MP, 60 Hz -> xem trước kéo ~745 (50 ms), thả ~1054 (100 ms)", abs(preview_lo((120, 60, 0, 0)) - 745) <= 8 and abs(preview_hi((120, 60, 0, 0)) - 1054) <= 8, (preview_lo((120, 60, 0, 0)), preview_hi((120, 60, 0, 0))))

# so sánh với bảng cũ (thông tin, kiểm thứ tự)
print("     ví dụ hồ sơ suy ra (ms/MP, Hz, heap MB, RAM trống MB) -> hạng, cạnh, thả, kéo, hồ:")
for m in [(40, 120, 256 * MB, 5000), (120, 60, 256 * MB, 2500), (250, 60, 192 * MB, 1200), (500, 60, 128 * MB, 700), (1200, 60, 96 * MB, 400)]:
    d = derive(m)
    print("       ", (m[0], m[1], m[2] // MB, m[3]), "->", d["tier"], d["maxSide"], d["previewHi"], d["previewLo"], d["pool"])
tiers = [derive(m)["tier"] for m in [(40, 120, 256 * MB, 5000), (120, 60, 256 * MB, 2500), (250, 60, 192 * MB, 1200), (500, 60, 128 * MB, 700), (1200, 60, 96 * MB, 400)]]
rank = {"LOW": 0, "MID": 1, "HIGH": 2}
check("máy nhanh + nhiều bộ nhớ -> HIGH, chậm + ít bộ nhớ -> LOW, thứ hạng không đảo theo độ mạnh", tiers[0] == "HIGH" and tiers[-1] == "LOW" and all(rank[tiers[i]] >= rank[tiers[i + 1]] for i in range(len(tiers) - 1)), tiers)
check("hồ model: RAM trống 8000 MB -> 5 khe, 2000 MB -> 1, 500 MB -> 1 (luôn >= 1), 40000 MB -> 12 (trần)", [pool_slots(8000), pool_slots(2000), pool_slots(500), pool_slots(40000)] == [5, 1, 1, 12], [pool_slots(8000), pool_slots(2000), pool_slots(500), pool_slots(40000)])
check("số luồng = số nhân, tối đa 4 (1 -> 1, 3 -> 3, 8 -> 4, 0 -> 1)", [threads(1), threads(3), threads(8), threads(0)] == [1, 3, 4, 1])

# ------------------------------------------------------------------ blend
check("blend: chưa có số đã lưu -> nhận số đo", blend(0, 80.0) == 80.0 and blend(-1, 80.0) == 80.0)
check("blend: số đo NHANH hơn được nhận ngay", blend(100.0, 60.0) == 60.0)
check("blend: số đo CHẬM hơn chỉ đẩy lên tối đa 5 %% mỗi lần (một lần đo trúng lúc máy bận x5 chỉ làm chậm 5 %%)", abs(blend(100.0, 500.0) - 105.0) < 1e-9)
v = 100.0
n = 0
while v < 500.0 - 1e-9 and n < 100:
    v = blend(v, 500.0)
    n += 1
check("blend: máy THẬT SỰ chậm đi (500 ms/MP liên tục) được phản ánh sau %d lần mở app (<= 40)" % n, n <= 40, n)
check("đột biến: coi số đo chậm là nhận ngay (không giới hạn 5 %) -> một lần đo xấu làm hỏng hồ sơ, BỊ BẮT", blend(100.0, 500.0) < 500.0)

# ------------------------------------------------------------------ đột biến
m0 = (120, 60, 128 * MB, 700)
check("đột biến: bỏ chặn NATIVE -> cạnh làm việc vượt giới hạn bộ nhớ native trên máy ít RAM, BỊ BẮT",
      max_side(m0, _no_native=True) > max_side(m0), (max_side(m0, _no_native=True), max_side(m0)))
m1 = (30, 60, 48 * MB, 8000)
check("đột biến: bỏ chặn HEAP -> vượt heap Java trên máy heap nhỏ, BỊ BẮT", max_side(m1, _no_heap=True) > max_side(m1), (max_side(m1, _no_heap=True), max_side(m1)))
check("đột biến: dùng 1 khung thay vì %d khung cho ngân sách kéo -> xem trước nhỏ đi, BỊ BẮT" % C["FRAME_COUNT"], preview_lo((120, 60, 0, 0), _frame_ms=1000 / 60.0) < preview_lo((120, 60, 0, 0)))

# ------------------------------------------------------------------ cấu trúc mã Kotlin khớp bản port (bản port tự cài lại công thức nên phải kiểm cả thân hàm)
def kt_body(src, header):
    i = src.index(header)
    j = src.index("\n    }", i) if "{" in src[i:i + 200] and "= when" not in src[i:i + 200] else src.index("\n", i)
    return src[i:j]


body_max = kt_body(obj, "fun maxSide(")
check("Kotlin maxSide: dùng đủ ba chặn (thời gian x BAKE_CHAIN_FACTOR, heap, native) và kẹp [SIDE_FLOOR, SIDE_CEIL]",
      all(k in body_max for k in ("BAKE_CHAIN_FACTOR", "BAKE_MS", "HEAP_BYTES_PER_PIXEL", "NATIVE_BYTES_PER_PIXEL", "minOf(time, heap, nativeSide)", "coerceIn(SIDE_FLOOR, SIDE_CEIL)")), body_max)
check("Kotlin previewLo dùng FRAME_COUNT x khung hình THẬT (1000 / tần số làm tươi), previewHi dùng INSTANT_MS",
      "FRAME_COUNT" in kt_body(obj, "fun previewLo(") and "refreshHz" in kt_body(obj, "fun previewLo(") and "INSTANT_MS" in kt_body(obj, "fun previewHi("))
dpos = pk.index("fun derive(")
body_derive = pk[dpos:pk.index("private fun applyOverrides", dpos)]
check("Kotlin derive: previewHi <= maxSide, previewLo <= previewHi, nhãn hạng và hồ model suy từ số đo (không từ RAM)",
      "min(PerfModel.previewHi(m), maxSide)" in body_derive and "min(PerfModel.previewLo(m), hi)" in body_derive and "PerfModel.tierOf(maxSide)" in body_derive and "PerfModel.poolSlots(m.availMb)" in body_derive and "ramMb" not in body_derive, body_derive)
check("Kotlin blend: số nhanh nhận ngay, số chậm giới hạn BLEND_UP", "min(measured, stored * BLEND_UP)" in kt_body(obj, "fun blend("))

# ------------------------------------------------------------------ nối mã
check("MainViewModel: mọi chỗ gán perf đi qua computePerf() + applyPerf(), hiệu chuẩn nền một lần khi mở app",
      "perf = computePerf()" in vm and vm.count("applyPerf()") >= 3 and "calibratePerf()" in vm and "PerfModel.blend(" in vm)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
