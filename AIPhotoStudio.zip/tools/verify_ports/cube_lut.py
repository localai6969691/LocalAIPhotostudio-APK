#!/usr/bin/env python3
"""Port Python của engine/CubeLut.kt (R11, R13 chuyển sang nội suy TỨ DIỆN): parser .cube + nội suy + cường độ. Cần numpy."""
import re
import sys
import numpy as np

FAIL = []


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


MAX_SIZE = 65


def parse(text):
    """Trả (lut | None, lỗi | None). lut = dict(size, data[N,N,N,3] chỉ số [b][g][r], dmin, dmax)."""
    size = 0
    one_d = False
    dmin = [0.0, 0.0, 0.0]
    dmax = [1.0, 1.0, 1.0]
    data = None
    count = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line[0] == "#":
            continue
        if line[0].isalpha():
            parts = re.split(r"\s+", line)
            key = parts[0].upper()
            if key == "LUT_3D_SIZE":
                try:
                    size = int(parts[1])
                except Exception:
                    return None, "LUT_3D_SIZE không hợp lệ"
                if size < 2 or size > MAX_SIZE:
                    return None, f"LUT_3D_SIZE phải trong 2..{MAX_SIZE}"
                data = np.zeros(size ** 3 * 3)
            elif key == "LUT_1D_SIZE":
                one_d = True
            elif key == "DOMAIN_MIN":
                for k in range(3):
                    try:
                        dmin[k] = float(parts[1 + k])
                    except Exception:
                        dmin[k] = 0.0
            elif key == "DOMAIN_MAX":
                for k in range(3):
                    try:
                        dmax[k] = float(parts[1 + k])
                    except Exception:
                        dmax[k] = 1.0
            continue
        if data is None:
            return None, ("LUT 1D chưa được hỗ trợ (cần LUT 3D)" if one_d else "Thiếu LUT_3D_SIZE trước dữ liệu")
        parts = re.split(r"\s+", line)
        if len(parts) < 3:
            return None, "Dòng dữ liệu thiếu giá trị"
        if count * 3 + 3 > data.size:
            return None, "Dữ liệu LUT dư so với LUT_3D_SIZE"
        for k in range(3):
            try:
                v = float(parts[k])
            except Exception:
                return None, "Giá trị LUT không hợp lệ"
            if not np.isfinite(v):
                return None, "Giá trị LUT không hợp lệ"
            data[count * 3 + k] = v
        count += 1
    if one_d and data is None:
        return None, "LUT 1D chưa được hỗ trợ (cần LUT 3D)"
    if data is None:
        return None, "Không có LUT_3D_SIZE"
    if count != size ** 3:
        return None, f"Số dòng dữ liệu ({count}) khác {size}³"
    for k in range(3):
        if dmax[k] <= dmin[k]:
            return None, "DOMAIN_MAX phải lớn hơn DOMAIN_MIN"
    return dict(size=size, data=data.reshape(size, size, size, 3), dmin=np.array(dmin), dmax=np.array(dmax)), None


def to_text(lut_fn, n, extra=""):
    """Ghi LUT .cube theo đúng thứ tự file: đỏ chạy nhanh nhất."""
    lines = [extra, f"LUT_3D_SIZE {n}"]
    for b in range(n):
        for g in range(n):
            for r in range(n):
                o = lut_fn(r / (n - 1), g / (n - 1), b / (n - 1))
                lines.append(f"{o[0]:.6f} {o[1]:.6f} {o[2]:.6f}")
    return "\n".join(lines) + "\n"


def _frac(img, lut):
    n = lut["size"]
    nm = n - 1.0
    dm, dx = lut["dmin"], lut["dmax"]
    f = np.clip((img / 255.0 - dm) / (dx - dm) * nm, 0, nm)
    i0 = np.floor(f).astype(int)
    i1 = np.minimum(i0 + 1, n - 1)
    return f - i0, i0, i1


def _blend(img, lut_out, k):
    res = img + (lut_out * 255.0 - img) * k
    return np.clip(np.floor(res + 0.5), 0, 255)


def apply_trilinear(img, lut, intensity):
    """Bản tam tuyến cũ (R11) — giữ để SO SÁNH với tứ diện."""
    k = float(np.clip(intensity, 0, 1))
    if k <= 0.001:
        return img
    d = lut["data"]
    fr3, i0, i1 = _frac(img, lut)
    out = np.zeros_like(img, dtype=np.float64)
    for cz in (0, 1):
        bi = i1[..., 2] if cz else i0[..., 2]
        wz = fr3[..., 2] if cz else 1 - fr3[..., 2]
        for cy in (0, 1):
            gi = i1[..., 1] if cy else i0[..., 1]
            wy = fr3[..., 1] if cy else 1 - fr3[..., 1]
            for cx in (0, 1):
                ri = i1[..., 0] if cx else i0[..., 0]
                wx = fr3[..., 0] if cx else 1 - fr3[..., 0]
                out += (wx * wy * wz)[..., None] * d[bi, gi, ri]
    return _blend(img, out, k)


def apply(img, lut, intensity):
    """Nội suy TỨ DIỆN — đúng thứ tự trục và đường đi như CubeLut.kt."""
    k = float(np.clip(intensity, 0, 1))
    if k <= 0.001:
        return img
    d = lut["data"]
    fr3, i0, i1 = _frac(img, lut)
    fr, fg, fb = fr3[..., 0], fr3[..., 1], fr3[..., 2]
    r0, g0, b0 = i0[..., 0], i0[..., 1], i0[..., 2]
    r1, g1, b1 = i1[..., 0], i1[..., 1], i1[..., 2]
    c = lambda bi, gi, ri: d[bi, gi, ri]
    c000, c111 = c(b0, g0, r0), c(b1, g1, r1)
    c100, c010, c001 = c(b0, g0, r1), c(b0, g1, r0), c(b1, g0, r0)
    c110, c101, c011 = c(b0, g1, r1), c(b1, g0, r1), c(b1, g1, r0)
    out = np.zeros_like(img, dtype=np.float64)
    cases = [
        (fr >= fg, fg >= fb, None, c100, c110, fr, fg, fb),
        (fr >= fg, fg < fb, fr >= fb, c100, c101, fr, fb, fg),
        (fr >= fg, fg < fb, fr < fb, c001, c101, fb, fr, fg),
        (fr < fg, fb >= fg, None, c001, c011, fb, fg, fr),
        (fr < fg, fb < fg, fb >= fr, c010, c011, fg, fb, fr),
        (fr < fg, fb < fg, fb < fr, c010, c110, fg, fr, fb),
    ]
    for c1, c2, c3, pa, pb, w1, w2, w3 in cases:
        m = c1 & c2 if c3 is None else (c1 & c2 & c3)
        res = (c000 + w1[..., None] * (pa - c000) + w2[..., None] * (pb - pa) + w3[..., None] * (c111 - pb))
        out = np.where(m[..., None], res, out)
    return _blend(img, out, k)


def main():
    rng = np.random.default_rng(3)
    img = rng.integers(0, 256, (64, 64, 3)).astype(np.float64)

    ident_txt = to_text(lambda r, g, b: (r, g, b), 17, "TITLE \"Identity\"\n# chú thích")
    lut, err = parse(ident_txt)
    check("parse LUT đồng nhất 17³ thành công", lut is not None and err is None, str(err))
    out = apply(img, lut, 1.0)
    check("LUT đồng nhất giữ nguyên ảnh (|Δ| ≤ 1)", np.abs(out - img).max() <= 1, f"max|Δ|={np.abs(out-img).max()}")

    # thứ tự dữ liệu: LUT hoán đổi R↔B (tuyến tính → nội suy tam tuyến chính xác) — sai thứ tự index sẽ lộ ngay
    swap, _ = parse(to_text(lambda r, g, b: (b, g, r), 9))
    o = apply(img, swap, 1.0)
    want = img[..., ::-1]
    check("LUT hoán R↔B cho đúng kết quả (|Δ| ≤ 1) → thứ tự đỏ-nhanh-nhất đúng", np.abs(o - want).max() <= 1,
          f"max|Δ|={np.abs(o-want).max()}")
    onlyr, _ = parse(to_text(lambda r, g, b: (r, 0.0, 0.0), 9))
    o = apply(img, onlyr, 1.0)
    check("LUT chỉ-giữ-đỏ: G,B = 0 và R giữ nguyên", np.abs(o[..., 1]).max() <= 1 and np.abs(o[..., 2]).max() <= 1
          and np.abs(o[..., 0] - img[..., 0]).max() <= 1)

    # đường cong S trơn: sai số nội suy nhỏ khi N=33
    s_curve = lambda x: 0.5 - 0.5 * np.cos(np.pi * x)
    sc, _ = parse(to_text(lambda r, g, b: (s_curve(r), s_curve(g), s_curve(b)), 33))
    o = apply(img, sc, 1.0)
    analytic = np.clip(np.floor(255 * s_curve(img / 255) + 0.5), 0, 255)
    err_max = np.abs(o - analytic).max()
    check("LUT đường cong S 33³ khớp công thức (|Δ| ≤ 2)", err_max <= 2, f"max|Δ|={err_max}")
    # hàm có độ dốc vô hạn tại 0 (gamma 0.45) sai số gần đen là BẢN CHẤT của LUT — ghi nhận, không coi là lỗi
    gam, _ = parse(to_text(lambda r, g, b: (r ** 0.45, g ** 0.45, b ** 0.45), 33))
    og = apply(img, gam, 1.0)
    ag = np.clip(np.floor(255 * (img / 255) ** 0.45 + 0.5), 0, 255)
    far = img > 40
    check("LUT gamma 0.45: ngoài vùng gần đen (>40/255) sai số ≤ 4", np.abs(og - ag)[far].max() <= 4,
          f"max|Δ| ngoài vùng tối={np.abs(og-ag)[far].max():.1f}, gần đen={np.abs(og-ag)[~far].max():.1f}")

    # cường độ
    half = apply(img, swap, 0.5)
    want_half = np.clip(np.floor(img + (want - img) * 0.5 + 0.5), 0, 255)
    check("cường độ 0.5 = trung điểm gốc ↔ LUT (|Δ| ≤ 1)", np.abs(half - want_half).max() <= 1)
    check("cường độ 0 → không đổi", (apply(img, swap, 0.0) == img).all())

    # DOMAIN 0..2 chỉ là miền ĐẦU VÀO: đầu vào 0..1 chỉ phủ nửa đầu khối -> LUT đồng nhất cho ra img/2
    dom_txt = to_text(lambda r, g, b: (r, g, b), 9, "DOMAIN_MIN 0 0 0\nDOMAIN_MAX 2 2 2")
    dom, err = parse(dom_txt)
    check("parse DOMAIN_MAX 2 thành công", dom is not None, str(err))
    check("DOMAIN 0..2 chỉ co giãn đầu vào: LUT đồng nhất cho ảnh/2 (|Δ| ≤ 1)", np.abs(apply(img, dom, 1.0) - np.floor(img / 2 + 0.5)).max() <= 1)
    dom1, _ = parse(to_text(lambda r, g, b: (r, g, b), 9, "DOMAIN_MIN 0.25 0.25 0.25\nDOMAIN_MAX 0.75 0.75 0.75"))
    mid = np.full((1, 1, 3), 127.5)
    check("DOMAIN 0.25..0.75: đầu vào 0.5 → giữa khối → đầu ra 0.5", abs(apply(mid, dom1, 1.0)[0, 0, 0] - 128) <= 1)

    # ---- đặc trưng của TỨ DIỆN: LUT trung tính (xám → xám) nhưng các nút ngoài trục xám bị ám màu mạnh
    def tinted(r, g, b):
        v = ((r + g + b) / 3.0) ** 1.4
        chroma = max(r, g, b) - min(r, g, b)
        return (v + 0.35 * chroma, v, v)
    tl, _ = parse(to_text(tinted, 9))
    ramp = np.stack([np.linspace(0, 255, 256)] * 3, -1)[None, ...]          # dải xám 256 mức
    tet = apply(ramp, tl, 1.0)[0]
    tri = apply_trilinear(ramp, tl, 1.0)[0]
    tet_cast = (tet.max(-1) - tet.min(-1)).max()
    tri_cast = (tri.max(-1) - tri.min(-1)).max()
    check("tứ diện: dải xám qua LUT trung tính vẫn XÁM (lệch kênh ≤ 1)", tet_cast <= 1, f"lệch tối đa {tet_cast:.1f}")
    check("tam tuyến cũ: cùng LUT đó bị ám màu (> 4) — lý do chuyển sang tứ diện", tri_cast > 4, f"lệch tối đa {tri_cast:.1f}")
    # nhất quán: trên LUT tuyến tính hai phương pháp cho cùng kết quả
    lin, _ = parse(to_text(lambda r, g, b: (0.2 + 0.5 * r + 0.1 * g, 0.9 * g + 0.05 * b, 0.1 + 0.3 * b + 0.2 * r), 7))
    dl = np.abs(apply(img, lin, 1.0) - apply_trilinear(img, lin, 1.0)).max()
    check("LUT tuyến tính: tứ diện = tam tuyến (|Δ| ≤ 1)", dl <= 1, f"{dl:.1f}")
    # tính liên tục khi đổi tứ diện (hai điểm sát nhau nhưng khác thứ tự trục) không nhảy giá trị
    p1 = np.array([[[100.0, 100.0, 99.0]]]); p2 = np.array([[[100.0, 99.0, 100.0]]])
    sm, _ = parse(to_text(lambda r, g, b: (r ** 2, g ** 2, b ** 2), 5))
    check("liên tục khi đổi tứ diện (|Δ| ≤ 3 giữa hai điểm sát nhau)", np.abs(apply(p1, sm, 1.0) - apply(p2, sm, 1.0)).max() <= 3)
    # cả 6 thứ tự trục đều được dùng (mỗi nhánh đều có mẫu thử) và chính xác với hàm affine
    aff, _ = parse(to_text(lambda r, g, b: (0.3 * r + 0.2 * g + 0.1 * b, 0.1 * r + 0.5 * g, 0.4 * b + 0.2 * g), 5))
    rng2 = np.random.default_rng(9)
    pts = rng2.uniform(0, 255, (2000, 1, 3))
    exp = np.stack([0.3 * pts[..., 0] + 0.2 * pts[..., 1] + 0.1 * pts[..., 2], 0.1 * pts[..., 0] + 0.5 * pts[..., 1], 0.4 * pts[..., 2] + 0.2 * pts[..., 1]], -1)
    check("hàm affine: tứ diện chính xác ở cả 6 thứ tự trục (|Δ| ≤ 1)", np.abs(apply(pts, aff, 1.0) - np.clip(np.floor(exp + 0.5), 0, 255)).max() <= 1)

    # CRLF + khoảng trắng + dòng trống
    crlf = ident_txt.replace("\n", "\r\n").replace("LUT_3D_SIZE 17", "  LUT_3D_SIZE   17  ")
    check("parse chịu được CRLF và khoảng trắng thừa", parse(crlf)[0] is not None)

    # lỗi
    check("LUT 1D bị từ chối với thông báo rõ", parse("LUT_1D_SIZE 4\n0 0 0\n1 1 1\n")[1] is not None and "1D" in parse("LUT_1D_SIZE 4\n0 0 0\n1 1 1\n")[1])
    check("thiếu LUT_3D_SIZE → lỗi", parse("0 0 0\n1 1 1\n")[0] is None)
    check("SIZE = 1 → lỗi", parse("LUT_3D_SIZE 1\n0 0 0\n")[0] is None)
    check("SIZE = 66 → lỗi", parse("LUT_3D_SIZE 66\n")[0] is None)
    check("thiếu dòng dữ liệu → lỗi", parse("LUT_3D_SIZE 2\n" + "0 0 0\n" * 7)[0] is None)
    check("dư dòng dữ liệu → lỗi", parse("LUT_3D_SIZE 2\n" + "0 0 0\n" * 9)[0] is None)
    check("giá trị chữ → lỗi", parse("LUT_3D_SIZE 2\n" + "0 0 x\n" * 8)[0] is None)
    check("giá trị NaN → lỗi", parse("LUT_3D_SIZE 2\n" + "0 nan 0\n" * 8)[0] is None)
    check("dòng thiếu cột → lỗi", parse("LUT_3D_SIZE 2\n" + "0 0\n" * 8)[0] is None)
    check("DOMAIN_MAX ≤ MIN → lỗi", parse("LUT_3D_SIZE 2\nDOMAIN_MIN 1 1 1\nDOMAIN_MAX 1 1 1\n" + "0 0 0\n" * 8)[0] is None)
    check("tệp rỗng → lỗi", parse("")[0] is None)
    check("dữ liệu trước LUT_3D_SIZE → lỗi", parse("0 0 0\nLUT_3D_SIZE 2\n")[0] is None)

    # giá trị ngoài [0,1] trong LUT được kẹp ở đầu ra
    hot, _ = parse(to_text(lambda r, g, b: (r * 3, g * 3, b * 3), 5))
    check("đầu ra LUT vượt 1.0 được kẹp 255", apply(np.full((2, 2, 3), 200.0), hot, 1.0).max() == 255)

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
