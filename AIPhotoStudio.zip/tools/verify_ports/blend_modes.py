#!/usr/bin/env python3
"""
R14 - Kiểm tra số học 21 chế độ hòa trộn của doc/Blend.kt bằng bản port Python.
  * `kt_*`  : dịch từng dòng từ Kotlin (cùng cấu trúc, cùng kẹp, cùng ngưỡng 1e-6)
  * `ref_*` : bản THAM CHIẾU ĐỘC LẬP viết thẳng từ đặc tả W3C Compositing & Blending Level 1
              (SetSat sắp xếp 3 kênh; ClipColor theo đúng mã giả) - để bắt lỗi dịch/lối tắt
  * kiểm tính chất: phần tử trung hòa, độ chói được giữ, biên (dodge/burn), không NaN, kẹp trước khi trộn độ mờ
  * đối chiếu danh sách enum trong Blend.kt với bảng chế độ ở đây (hai bên không lệch nhau)
Chạy: python3 tools/verify_ports/blend_modes.py
"""
import itertools, math, os, random, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
KT = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio", "doc", "Blend.kt")
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + detail) if detail and not ok else ""))
    if not ok: fails.append(name)

# ------------------------------------------------------------------ bản dịch từ Kotlin
def clamp01(v): return 0.0 if v < 0 else 1.0 if v > 1 else v
def dodge(b, t): return 0.0 if b <= 0 else 1.0 if t >= 1 else min(1.0, b / (1 - t))
def burn(b, t):  return 1.0 if b >= 1 else 0.0 if t <= 0 else 1 - min(1.0, (1 - b) / t)

def kt_mix(mode, b, t):
    if mode == "NORMAL": v = t
    elif mode == "MULTIPLY": v = b * t
    elif mode == "SCREEN": v = 1 - (1 - b) * (1 - t)
    elif mode == "OVERLAY": v = 2 * b * t if b < 0.5 else 1 - 2 * (1 - b) * (1 - t)
    elif mode == "SOFT_LIGHT":
        if t <= 0.5: v = b - (1 - 2 * t) * b * (1 - b)
        else:
            d = ((16 * b - 12) * b + 4) * b if b <= 0.25 else math.sqrt(b)
            v = b + (2 * t - 1) * (d - b)
    elif mode == "COLOR_DODGE": v = dodge(b, t)
    elif mode == "COLOR_BURN": v = burn(b, t)
    elif mode == "DARKEN": v = min(b, t)
    elif mode == "LIGHTEN": v = max(b, t)
    elif mode == "HARD_LIGHT":
        if t <= 0.5: v = b * 2 * t
        else: s = 2 * t - 1; v = b + s - b * s
    elif mode == "VIVID_LIGHT": v = burn(b, 2 * t) if t < 0.5 else dodge(b, 2 * t - 1)
    elif mode == "LINEAR_LIGHT": v = b + 2 * t - 1
    elif mode == "PIN_LIGHT": v = min(b, 2 * t) if t < 0.5 else max(b, 2 * t - 1)
    elif mode == "LINEAR_BURN": v = b + t - 1
    elif mode == "LINEAR_DODGE": v = b + t
    elif mode == "DIFFERENCE": v = abs(b - t)
    elif mode == "EXCLUSION": v = b + t - 2 * b * t
    else: raise KeyError(mode)
    return clamp01(v)

def lum(r, g, b): return 0.3 * r + 0.59 * g + 0.11 * b
def sat(r, g, b): return max(r, g, b) - min(r, g, b)
def kt_setsat(r, g, b, s):
    mx, mn = max(r, g, b), min(r, g, b)
    if mx > mn:
        k = s / (mx - mn); return ((r - mn) * k, (g - mn) * k, (b - mn) * k)
    return (0.0, 0.0, 0.0)
def kt_setlum(r, g, b, l):
    d = l - lum(r, g, b)
    cr, cg, cb = r + d, g + d, b + d
    ll = lum(cr, cg, cb); n = min(cr, cg, cb); x = max(cr, cg, cb)
    if n < 0:
        den = ll - n
        if den > 1e-6: k = ll / den; cr, cg, cb = ll + (cr - ll) * k, ll + (cg - ll) * k, ll + (cb - ll) * k
        else: cr = cg = cb = ll
    if x > 1:
        den = x - ll
        if den > 1e-6: k = (1 - ll) / den; cr, cg, cb = ll + (cr - ll) * k, ll + (cg - ll) * k, ll + (cb - ll) * k
        else: cr = cg = cb = ll
    return (cr, cg, cb)
def kt_nonsep(mode, B, T):
    br, bg, bb = B; tr, tg, tb = T
    if mode == "HUE":
        o = kt_setsat(tr, tg, tb, sat(br, bg, bb)); o = kt_setlum(*o, lum(br, bg, bb))
    elif mode == "SATURATION":
        o = kt_setsat(br, bg, bb, sat(tr, tg, tb)); o = kt_setlum(*o, lum(br, bg, bb))
    elif mode == "COLOR": o = kt_setlum(tr, tg, tb, lum(br, bg, bb))
    else: o = kt_setlum(br, bg, bb, lum(tr, tg, tb))        # LUMINOSITY
    return tuple(clamp01(v) for v in o)

SEP = ["NORMAL", "MULTIPLY", "SCREEN", "OVERLAY", "SOFT_LIGHT", "COLOR_DODGE", "COLOR_BURN", "DARKEN", "LIGHTEN",
       "HARD_LIGHT", "VIVID_LIGHT", "LINEAR_LIGHT", "PIN_LIGHT", "LINEAR_BURN", "LINEAR_DODGE", "DIFFERENCE", "EXCLUSION"]
NONSEP = ["HUE", "SATURATION", "COLOR", "LUMINOSITY"]
ALL = SEP + NONSEP

def kt_pixel(mode, B, T):
    if mode in NONSEP: return kt_nonsep(mode, B, T)
    return tuple(kt_mix(mode, B[i], T[i]) for i in range(3))

# ------------------------------------------------------------------ THAM CHIẾU độc lập (đặc tả W3C)
def ref_sep(mode, cb, cs):
    if mode == "NORMAL": r = cs
    elif mode == "MULTIPLY": r = cb * cs
    elif mode == "SCREEN": r = cb + cs - cb * cs
    elif mode == "OVERLAY": r = ref_sep("HARD_LIGHT", cs, cb)               # Overlay(cb,cs) = HardLight(cs,cb)
    elif mode == "HARD_LIGHT":
        r = ref_sep("MULTIPLY", cb, 2 * cs) if cs <= 0.5 else ref_sep("SCREEN", cb, 2 * cs - 1)
    elif mode == "SOFT_LIGHT":
        if cs <= 0.5: r = cb - (1 - 2 * cs) * cb * (1 - cb)
        else:
            D = ((16 * cb - 12) * cb + 4) * cb if cb <= 0.25 else math.sqrt(cb)
            r = cb + (2 * cs - 1) * (D - cb)
    elif mode == "COLOR_DODGE": r = 0.0 if cb == 0 else (1.0 if cs == 1 else min(1.0, cb / (1 - cs)))
    elif mode == "COLOR_BURN": r = 1.0 if cb == 1 else (0.0 if cs == 0 else 1 - min(1.0, (1 - cb) / cs))
    elif mode == "DARKEN": r = min(cb, cs)
    elif mode == "LIGHTEN": r = max(cb, cs)
    elif mode == "DIFFERENCE": r = abs(cb - cs)
    elif mode == "EXCLUSION": r = cb + cs - 2 * cb * cs
    elif mode == "LINEAR_BURN": r = cb + cs - 1
    elif mode == "LINEAR_DODGE": r = cb + cs
    elif mode == "LINEAR_LIGHT": r = cb + 2 * cs - 1
    elif mode == "VIVID_LIGHT":
        r = ref_sep("COLOR_BURN", cb, 2 * cs) if cs < 0.5 else ref_sep("COLOR_DODGE", cb, 2 * (cs - 0.5))
    elif mode == "PIN_LIGHT":
        r = min(cb, 2 * cs) if cs < 0.5 else max(cb, 2 * cs - 1)
    else: raise KeyError(mode)
    return min(1.0, max(0.0, r))

def ref_lum(C): return 0.3 * C[0] + 0.59 * C[1] + 0.11 * C[2]
def ref_clip(C):
    l = ref_lum(C); n = min(C); x = max(C)
    C = list(C)
    if n < 0: C = [l + ((c - l) * l) / (l - n) for c in C]
    if x > 1: C = [l + ((c - l) * (1 - l)) / (x - l) for c in C]
    return C
def ref_setlum(C, l):
    d = l - ref_lum(C); return ref_clip([c + d for c in C])
def ref_sat(C): return max(C) - min(C)
def ref_setsat(C, s):
    idx = sorted(range(3), key=lambda i: C[i])      # [min, mid, max]
    out = [0.0, 0.0, 0.0]
    imin, imid, imax = idx
    if C[imax] > C[imin]:
        out[imid] = (C[imid] - C[imin]) * s / (C[imax] - C[imin]); out[imax] = s
    return out
def ref_nonsep(mode, Cb, Cs):
    if mode == "HUE": r = ref_setlum(ref_setsat(Cs, ref_sat(Cb)), ref_lum(Cb))
    elif mode == "SATURATION": r = ref_setlum(ref_setsat(Cb, ref_sat(Cs)), ref_lum(Cb))
    elif mode == "COLOR": r = ref_setlum(Cs, ref_lum(Cb))
    else: r = ref_setlum(Cb, ref_lum(Cs))
    return tuple(min(1.0, max(0.0, v)) for v in r)
def ref_pixel(mode, B, T):
    if mode in NONSEP: return ref_nonsep(mode, B, T)
    return tuple(ref_sep(mode, B[i], T[i]) for i in range(3))

# ------------------------------------------------------------------ 0) đồng bộ danh sách enum với Blend.kt
src = open(KT, encoding="utf-8").read()
body = src.split("enum class BlendMode", 1)[1].split("fun next()", 1)[0]
body = re.sub(r"\"[^\"]*\"", '""', body)
entries = re.findall(r"\b([A-Z][A-Z_]+)\s*\(", body)
check("enum trong Blend.kt khớp danh sách chế độ của port (không lệch)", entries == ALL, f"{entries}")
nonsep_kt = re.findall(r"\b([A-Z][A-Z_]+)\(\"\", false\)", body)
check("Blend.kt đánh dấu đúng 4 chế độ không tách kênh", nonsep_kt == NONSEP, f"{nonsep_kt}")
check("mixCh có đủ nhánh cho mọi chế độ tách kênh", all(re.search(r"BlendMode\." + m + r"\b", src.split("private fun mixCh")[1].split("private fun lum")[0]) for m in SEP))

# ------------------------------------------------------------------ 1) bản dịch == tham chiếu, quét ngẫu nhiên + biên
random.seed(14)
vals = [0.0, 0.25, 0.5, 0.75, 1.0]
samples = [tuple(random.random() for _ in range(3)) for _ in range(400)]
edge = [(a, b, c) for a in vals for b in vals for c in vals]            # 125 màu biên (gồm xám, đen, trắng)
pairs = [(B, T) for B in edge[::3] for T in edge[1::4]] + [(random.choice(samples), random.choice(samples)) for _ in range(3000)]
worst = {}
for mode in ALL:
    w = 0.0
    for B, T in pairs:
        a, b = kt_pixel(mode, B, T), ref_pixel(mode, B, T)
        w = max(w, max(abs(a[i] - b[i]) for i in range(3)))
    worst[mode] = w
bad = {m: w for m, w in worst.items() if w > 1e-5}
check(f"bản dịch Kotlin == tham chiếu W3C trên {len(pairs)} cặp màu × 21 chế độ", not bad, f"lệch: {bad}")

# ------------------------------------------------------------------ 2) không NaN/Inf, luôn trong 0..1 (kể cả mọi tổ hợp {0, .5, 1}^6)
grid = [0.0, 0.5, 1.0]
ok_range = True; where = ""
for mode in ALL:
    for B in itertools.product(grid, repeat=3):
        for T in itertools.product(grid, repeat=3):
            o = kt_pixel(mode, B, T)
            if any((not math.isfinite(v)) or v < -1e-9 or v > 1 + 1e-9 for v in o): ok_range = False; where = f"{mode} {B} {T} -> {o}"
check("không NaN/Inf và luôn trong [0,1] (729 tổ hợp biên × 21 chế độ)", ok_range, where)

# ------------------------------------------------------------------ 3) phần tử trung hòa
random.seed(5)
neutral = {"MULTIPLY": 1.0, "SCREEN": 0.0, "OVERLAY": 0.5, "SOFT_LIGHT": 0.5, "HARD_LIGHT": 0.5, "VIVID_LIGHT": 0.5,
           "LINEAR_LIGHT": 0.5, "PIN_LIGHT": 0.5, "LINEAR_BURN": 1.0, "LINEAR_DODGE": 0.0, "DIFFERENCE": 0.0,
           "EXCLUSION": 0.0, "DARKEN": 1.0, "LIGHTEN": 0.0}
for mode, t in neutral.items():
    e = max(abs(kt_mix(mode, b, t) - b) for b in [random.random() for _ in range(300)] + [0.0, 1.0])
    check(f"{mode}: lớp trên = {t} thì nền không đổi", e < 1e-6, f"sai lệch {e}")
# Overlay: nền 0.5 -> kết quả = lớp trên? (đối ngẫu Hard Light)
check("Hard Light(b,t) == Overlay(t,b)", all(abs(kt_mix("HARD_LIGHT", b, t) - kt_mix("OVERLAY", t, b)) < 1e-9
      for b, t in [(random.random(), random.random()) for _ in range(500)]))
check("Linear Light = Linear Burn (t<.5) / Linear Dodge (t>.5) liên tục tại t=.5",
      all(abs(kt_mix("LINEAR_LIGHT", b, 0.5) - b) < 1e-9 for b in [0, .3, .7, 1]))
check("Vivid Light và Pin Light liên tục tại t=.5",
      all(abs(kt_mix(m, b, 0.5 - 1e-9) - kt_mix(m, b, 0.5)) < 1e-4 for m in ("VIVID_LIGHT", "PIN_LIGHT") for b in [0.1, .3, .6, .9]))

# ------------------------------------------------------------------ 4) giá trị tính tay (đối chiếu đặc tả)
def near(a, b, e=1e-6): return abs(a - b) <= e
check("MULTIPLY .5*.5 = .25", near(kt_mix("MULTIPLY", .5, .5), .25))
check("DIFFERENCE |.2-.7| = .5", near(kt_mix("DIFFERENCE", .2, .7), .5))
check("EXCLUSION b=.5 t=.5 -> .5; b=1 t=1 -> 0", near(kt_mix("EXCLUSION", .5, .5), .5) and near(kt_mix("EXCLUSION", 1, 1), 0))
check("LINEAR_DODGE .7+.6 kẹp = 1; LINEAR_BURN .3+.4-1 kẹp = 0", near(kt_mix("LINEAR_DODGE", .7, .6), 1) and near(kt_mix("LINEAR_BURN", .3, .4), 0))
check("HARD_LIGHT b=.4 t=.8: .4+.6-.24 = .76", near(kt_mix("HARD_LIGHT", .4, .8), .76))
check("HARD_LIGHT b=.4 t=.25: 2*.4*.25 = .2", near(kt_mix("HARD_LIGHT", .4, .25), .2))
check("PIN_LIGHT b=.4: t=.1 -> .2 ; t=.9 -> .8", near(kt_mix("PIN_LIGHT", .4, .1), .2) and near(kt_mix("PIN_LIGHT", .4, .9), .8))
check("VIVID_LIGHT b=.4 t=.25 -> burn(.4,.5) = 0 (kẹp)", near(kt_mix("VIVID_LIGHT", .4, .25), 0.0))
check("VIVID_LIGHT b=.4 t=.75 -> dodge(.4,.5) = .8", near(kt_mix("VIVID_LIGHT", .4, .75), .8))
check("LINEAR_LIGHT b=.5 t=.7 -> .9", near(kt_mix("LINEAR_LIGHT", .5, .7), .9))
# biên W3C (R14 sửa): trước đó cb=0&cs=1 cho 1 và cb=1&cs=0 cho 0
check("COLOR_DODGE: nền đen luôn đen (b=0,t=1 -> 0); t=1, b>0 -> 1", near(kt_mix("COLOR_DODGE", 0, 1), 0) and near(kt_mix("COLOR_DODGE", .3, 1), 1))
check("COLOR_BURN: nền trắng luôn trắng (b=1,t=0 -> 1); t=0, b<1 -> 0", near(kt_mix("COLOR_BURN", 1, 0), 1) and near(kt_mix("COLOR_BURN", .7, 0), 0))

# ------------------------------------------------------------------ 5) tính chất của 4 chế độ không tách kênh
random.seed(9)
rnd = [tuple(random.random() for _ in range(3)) for _ in range(2500)]
rp = [(rnd[i], rnd[(i * 7 + 3) % len(rnd)]) for i in range(len(rnd))]
e_lum_L = max(abs(lum(*kt_nonsep("LUMINOSITY", B, T)) - lum(*T)) for B, T in rp)
e_lum_C = max(abs(lum(*kt_nonsep("COLOR", B, T)) - lum(*B)) for B, T in rp)
e_lum_H = max(abs(lum(*kt_nonsep("HUE", B, T)) - lum(*B)) for B, T in rp)
e_lum_S = max(abs(lum(*kt_nonsep("SATURATION", B, T)) - lum(*B)) for B, T in rp)
check("LUMINOSITY giữ ĐỘ CHÓI của lớp trên (sai số < 1e-5)", e_lum_L < 1e-5, f"{e_lum_L}")
check("COLOR / HUE / SATURATION giữ ĐỘ CHÓI của nền (sai số < 1e-5)", max(e_lum_C, e_lum_H, e_lum_S) < 1e-5, f"{e_lum_C} {e_lum_H} {e_lum_S}")
check("HUE không bao giờ làm TĂNG độ bão hòa so với nền (kẹp gam màu chỉ làm giảm)",
      all(sat(*kt_nonsep("HUE", B, T)) <= sat(*B) + 1e-5 for B, T in rp))
# ví dụ không bị kẹp: Hue của (1,0,0) đỏ lên nền cam nhạt (.8,.6,.4) -> cùng độ bão hòa nền, sắc độ đỏ
ex = kt_nonsep("HUE", (.8, .6, .4), (.2, .0, .0))
check("HUE ví dụ: giữ độ bão hòa .4 và độ chói nền, sắc độ lấy từ lớp trên (đỏ: R lớn nhất, G=B)",
      near(sat(*ex), .4, 1e-5) and near(lum(*ex), lum(.8, .6, .4), 1e-5) and ex[0] > ex[1] and near(ex[1], ex[2], 1e-5))
for m in NONSEP:
    e = max(max(abs(kt_nonsep(m, c, c)[i] - c[i]) for i in range(3)) for c in rnd[:600])
    check(f"{m}: trộn màu với CHÍNH NÓ thì không đổi", e < 1e-5, f"{e}")
gray = kt_nonsep("COLOR", (.8, .3, .2), (.5, .5, .5))
check("COLOR với lớp trên xám -> kết quả XÁM có độ chói của nền (khử màu giữ sáng)",
      near(gray[0], gray[1], 1e-6) and near(gray[1], gray[2], 1e-6) and near(gray[0], lum(.8, .3, .2), 1e-6))
satz = kt_nonsep("SATURATION", (.8, .3, .2), (.4, .4, .4))
check("SATURATION với lớp trên xám -> xám (độ bão hòa 0), giữ độ chói nền",
      near(sat(*satz), 0, 1e-6) and near(lum(*satz), lum(.8, .3, .2), 1e-5))
lumz = kt_nonsep("LUMINOSITY", (.8, .3, .2), (1.0, 1.0, 1.0))
check("LUMINOSITY với lớp trên trắng -> kết quả trắng (độ chói 1)", all(near(v, 1.0, 1e-5) for v in lumz))

# ------------------------------------------------------------------ 6) blend(): độ mờ, mặt nạ, kẹp TRƯỚC khi trộn độ mờ, giữ alpha nền
def ch_(v): return 0 if v <= 0 else 255 if v >= 255 else int(v + 0.5)
def kt_blend_px(mode, b, t, opacity, mask=None):
    a = opacity * (1.0 if mask is None else mask)
    if a <= 0.001: return b
    f = lambda x, s: ((x >> s) & 255) / 255.0
    B = (f(b, 16), f(b, 8), f(b, 0)); T = (f(t, 16), f(t, 8), f(t, 0))
    M = kt_pixel(mode, B, T)
    c = [ch_((B[i] + (M[i] - B[i]) * a) * 255.0) for i in range(3)]
    return (b & 0xFF000000) | (c[0] << 16) | (c[1] << 8) | c[2]
base, top = 0xCC808080, 0xFF404040
check("opacity 0 -> giữ nền", kt_blend_px("MULTIPLY", base, top, 0.0) == base)
check("mặt nạ 0 -> giữ nền", kt_blend_px("HUE", base, top, 1.0, 0.0) == base)
check("opacity .0005 (dưới ngưỡng .001) -> giữ nền", kt_blend_px("SCREEN", base, top, 0.0005) == base)
check("NORMAL opacity 1 -> điểm ảnh lớp trên NHƯNG giữ alpha của nền",
      kt_blend_px("NORMAL", base, top, 1.0) == ((base & 0xFF000000) | (top & 0xFFFFFF)))
mid = kt_blend_px("NORMAL", 0xFF000000, 0xFFFFFFFF, 0.5)
check("NORMAL opacity .5 giữa đen-trắng -> 128 mỗi kênh", (mid & 255) == 128 and ((mid >> 8) & 255) == 128 and ((mid >> 16) & 255) == 128, hex(mid))
# kẹp trước khi trộn: b=.9, t=.5, Linear Dodge = 1.4 -> kẹp 1.0 -> trộn 50% = .95 (242), KHÔNG phải 1.15 -> 255
r = kt_blend_px("LINEAR_DODGE", 0xFFE5E5E5, 0xFF808080, 0.5)
check("Linear Dodge 50%: kẹp TRƯỚC khi trộn độ mờ -> ~242, không bão hòa 255", abs((r & 255) - 243) <= 1 and (r & 255) < 250, f"{r & 255}")
# Color Burn nền trắng + lớp đen: trước R14 trả đen, nay giữ trắng (đúng Photoshop/W3C)
r = kt_blend_px("COLOR_BURN", 0xFFFFFFFF, 0xFF000000, 1.0)
check("Color Burn: nền trắng + lớp đen giữ TRẮNG (biên W3C)", (r & 0xFFFFFF) == 0xFFFFFF, hex(r))

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
