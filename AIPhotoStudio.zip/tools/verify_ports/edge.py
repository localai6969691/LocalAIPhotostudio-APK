import numpy as np, math
from scipy.ndimage import uniform_filter1d
def erf_as(z):
    t=1/(1+0.3275911*z); poly=((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592
    return 1-poly*t*math.exp(-z*z)
def cdf(x):
    e=erf_as(abs(x)/1.41421356); return 0.5*(1+(e if x>=0 else -e))
def box3(a,r):
    out=a.astype(np.float64)
    for _ in range(3):
        # integer-division box blur per axis with clamped borders, as in Blur.kt
        for ax in (1,0):
            out=np.floor(uniform_filter1d(out,size=2*r+1,axis=ax,mode='nearest')+1e-9)
    return out
def smooth(e0,e1,x):
    t=np.clip((x-e0)/(e1-e0),0,1); return t*t*(3-2*t)
def shift_edge(mask,shift):
    h,w=mask.shape; d=max(-1,min(1,shift))*0.02*max(w,h)
    if abs(d)<0.5: return mask
    r=max(2,int(round(abs(d)))); g=np.floor(mask*255+0.5)
    b=box3(g,r)/255.0; sigma=math.sqrt(r*(r+1)); t=cdf(-d/sigma)
    return smooth(t-0.15,t+0.15,b)
w,h=400,40
m=np.zeros((h,w)); m[:,:200]=1
for s in (-1,-0.5,0.5,1):
    o=shift_edge(m,s); row=o[20]
    pos=np.interp(0.5,row[::-1],np.arange(w)[::-1]) if False else None
    # position where mask crosses 0.5 (monotone decreasing along x)
    idx=np.argmax(row<0.5); x=idx-1+(row[idx-1]-0.5)/(row[idx-1]-row[idx]) if idx>0 else float('nan')
    print(f"shift={s:+.1f}: expected edge move={s*0.02*400:+.1f}px  measured={x-199.5:+.2f}px")
# decontaminate
def decon(px,alpha,r):
    num=np.floor(px*alpha[...,None]+0.5)
    den=np.floor(alpha*255+0.5)
    bn=np.stack([box3(num[...,c],r) for c in range(3)],-1); bd=box3(den,r)
    out=px.copy()
    sel=(alpha<0.98)&(bd>=8)
    out[sel]=np.clip(np.round(bn[sel]*255/bd[sel][:,None]),0,255)
    return out
h,w=60,200
xs=np.arange(w)
alpha=np.clip((100-xs)/12.0+0.5,0,1)[None,:].repeat(h,0)    # soft ramp ~12px
fg=np.array([200,30,30.]); oldbg=np.array([30,200,30.])
px=alpha[...,None]*fg+(1-alpha[...,None])*oldbg           # contaminated edge colors
ramp=(alpha>0.05)&(alpha<0.95)
before=np.abs(px[ramp]-fg).mean()
after=np.abs(decon(px,alpha,4)[ramp]-fg).mean()
print(f"edge color error vs true foreground: before={before:.1f}  after={after:.1f}")

print("--- weighting experiments (weight = alpha^k, radius r) ---")
def decon2(px,alpha,r,k):
    wgt=alpha**k
    num=np.floor(px*wgt[...,None]+0.5); den=np.floor(wgt*255+0.5)
    bn=np.stack([box3(num[...,c],r) for c in range(3)],-1); bd=box3(den,r)
    out=px.copy(); sel=(alpha<0.98)&(bd>=8)
    out[sel]=np.clip(np.round(bn[sel]*255/bd[sel][:,None]),0,255); return out
for k in (1,2,4,8):
    for r in (3,6,10):
        e=np.abs(decon2(px,alpha,r,k)[ramp]-fg).mean(); print(f"k={k} r={r}: err={e:.1f}")
