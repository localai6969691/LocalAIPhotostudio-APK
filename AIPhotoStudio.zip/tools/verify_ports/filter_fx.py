"""Port Python của engine/FilterFx.kt: kiểm các tính chất số học (không cần Android)."""
import numpy as np, math, colorsys, cv2

def poster_levels(v): return int(min(16, max(2, round(16 - min(1, max(0, v)) * 14))))
def posterize(img, v):
    n = poster_levels(v); lut = np.array([min(255, max(0, round(round(c / 255 * (n - 1)) * 255 / (n - 1)))) for c in range(256)], np.uint8)
    return lut[img]
def pixelate(img, v):
    h, w, _ = img.shape; bs = max(2, round(min(1, max(0, v)) * max(w, h) / 20)); out = img.copy()
    for y in range(0, h, bs):
        for x in range(0, w, bs):
            out[y:y+bs, x:x+bs] = img[y:y+bs, x:x+bs].reshape(-1, 3).mean(0).astype(np.uint8)
    return out
def duotone(img, v, sh=(0x20,0x12,0x4D), hi=(0xF6,0xC1,0x77)):
    f = img.astype(float); l = (0.299*f[...,0] + 0.587*f[...,1] + 0.114*f[...,2]) / 255
    t = np.array(sh) + (np.array(hi) - np.array(sh)) * l[..., None]
    return np.clip(f * (1 - v) + t * v + .5, 0, 255).astype(np.uint8)
def emboss(img, v):
    f = img.astype(float); g = 0.299*f[...,0] + 0.587*f[...,1] + 0.114*f[...,2]
    gp = np.pad(g, 1, mode='edge'); e = 128 + 1.5 * (gp[:-2, :-2] - gp[2:, 2:])
    return np.clip(f * (1 - v) + e[..., None] * v + .5, 0, 255).astype(np.uint8)
def sketch(img, v):
    h, w, _ = img.shape; f = img.astype(float); g = np.clip(0.299*f[...,0] + 0.587*f[...,1] + 0.114*f[...,2] + .5, 0, 255)
    r = max(2, max(w, h) // 150); b = cv2.GaussianBlur((255 - g).astype(np.float32), (0, 0), r * 0.9).astype(float)
    s = np.where(b >= 255, 255, np.minimum(255, g * 255 / np.maximum(1, 255 - b)))
    return np.clip(f * (1 - v) + s[..., None] * v + .5, 0, 255).astype(np.uint8)
def glow(img, v):
    h, w, _ = img.shape; f = img.astype(float) / 255; r = max(3, max(w, h) // 60)
    b = cv2.GaussianBlur(f.astype(np.float32), (0, 0), r * 0.9).astype(float); k = min(1, max(0, v)) * .85
    return np.clip(255 * (1 - (1 - f) * (1 - b * k)) + .5, 0, 255).astype(np.uint8)
def chroma(img, v):
    h, w, _ = img.shape; s = min(1, max(0, v)) * max(w, h) * 0.008; cx, cy = (w - 1) / 2, (h - 1) / 2; R = math.hypot(cx, cy)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32); tx = (xx - cx) / R; ty = (yy - cy) / R
    r = cv2.remap(img[..., 0].astype(np.float32), xx - s * tx, yy - s * ty, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    b = cv2.remap(img[..., 2].astype(np.float32), xx + s * tx, yy + s * ty, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    out = img.copy(); out[..., 0] = np.clip(r + .5, 0, 255); out[..., 2] = np.clip(b + .5, 0, 255); return out
def matte(img, v):
    c = np.arange(256, dtype=float); lut = np.clip(c * (1 - v) + (36 + c * 219 / 255) * v + .5, 0, 255).astype(np.uint8); return lut[img]
def colorize_px(rgb, target, v, lift=0.45):
    h, l, s = colorsys.rgb_to_hls(*[c / 255 for c in rgb]); th, tl, ts = colorsys.rgb_to_hls(*[c / 255 for c in target])
    l2 = min(1, max(0, l + (tl - l) * lift)); r, g, b = colorsys.hls_to_rgb(th, l2, ts)
    return tuple(min(255, max(0, round(o * (1 - v) + n * 255 * v))) for o, n in zip(rgb, (r, g, b)))

def hue_deg(rgb):
    h, l, s = colorsys.rgb_to_hls(*[c / 255 for c in rgb]); return h * 360

if __name__ == "__main__":
    rng = np.random.default_rng(1); img = rng.integers(0, 256, (120, 160, 3), dtype=np.uint8); ok = True
    def chk(name, cond):
        global ok; ok &= bool(cond); print(("OK  " if cond else "FAIL"), name)
    for v in (0.0, 0.5, 1.0):
        n = poster_levels(v); u = [len(np.unique(posterize(img, v)[..., c])) for c in range(3)]
        chk(f"posterize v={v}: <= {n} mức/kênh {u}", max(u) <= n)
    p = pixelate(img, 0.5); bs = max(2, round(0.5 * 160 / 20)); blk = p[:bs, :bs].reshape(-1, 3)
    chk(f"pixelate: khối {bs}x{bs} đồng nhất", (blk == blk[0]).all())
    chk("pixelate: giữ trung bình khối", abs(float(p[:bs,:bs].mean()) - float(img[:bs,:bs].mean())) < 1.0)
    black = np.zeros((4, 4, 3), np.uint8); white = np.full((4, 4, 3), 255, np.uint8)
    chk("duotone: đen -> màu bóng", tuple(duotone(black, 1.0)[0, 0]) == (0x20, 0x12, 0x4D))
    chk("duotone: trắng -> màu sáng", tuple(duotone(white, 1.0)[0, 0]) == (0xF6, 0xC1, 0x77))
    chk("duotone: v=0 giữ nguyên", (duotone(img, 0.0) == img).all())
    flat = np.full((20, 20, 3), 90, np.uint8)
    chk("emboss: vùng phẳng -> xám 128", abs(int(emboss(flat, 1.0)[10, 10, 0]) - 128) <= 1)
    chk("sketch: vùng phẳng -> trắng", int(sketch(flat, 1.0)[10, 10, 0]) >= 250)
    chk("glow: không làm tối ảnh (Screen)", (glow(img, 0.8).astype(int) >= img.astype(int) - 1).all())
    chk("chroma: v=0 giữ nguyên", (chroma(img, 0.0) == img).all())
    gimg = np.tile(np.linspace(0, 255, 160, dtype=np.uint8)[None, :, None], (120, 1, 3)); c = chroma(gimg, 1.0)
    chk("chroma: tâm ảnh không đổi", tuple(c[60, 80]) == tuple(gimg[60, 80]) or max(abs(int(a) - int(b)) for a, b in zip(c[60, 80], gimg[60, 80])) <= 2)
    chk("chroma: mép ảnh xuất hiện viền màu (R != B)", int(abs(c[60, 150, 0].astype(int) - c[60, 150, 2].astype(int))) > 3)
    m = matte(img, 1.0)
    chk("matte: đen -> 36, trắng giữ 255", int(matte(black, 1.0)[0, 0, 0]) == 36 and int(matte(white, 1.0)[0, 0, 0]) == 255)
    tgt = (200, 30, 30)   # đỏ -> hue ~0
    for src in [(40, 30, 25), (90, 60, 40), (30, 30, 30), (150, 120, 90)]:
        o = colorize_px(src, tgt, 1.0); hd = hue_deg(o); d = min(abs(hd - hue_deg(tgt)), 360 - abs(hd - hue_deg(tgt)))
        chk(f"colorize {src} -> {o}: sắc độ lệch {d:.1f}°", d < 3)
    chk("colorize v=0 giữ nguyên", colorize_px((40, 30, 25), tgt, 0.0) == (40, 30, 25))
    lum = [colorsys.rgb_to_hls(*[c / 255 for c in colorize_px((g, g, g), tgt, 1.0)])[1] for g in (10, 60, 120, 200)]
    chk("colorize: giữ thứ tự sáng-tối " + str([round(x, 2) for x in lum]), lum == sorted(lum))
    blond = (230, 190, 90); o = colorize_px((25, 20, 18), blond, 1.0)
    chk(f"colorize tóc đen -> vàng: nhìn thấy được {o}", max(o) > 70)
    print("TẤT CẢ OK" if ok else "CÓ LỖI"); raise SystemExit(0 if ok else 1)
