"""Port Python của engine/MeshWarp.kt, engine/MaskMath.kt, engine/FaceLiquify.kt (kiểm số học + chọn hằng số)."""
import numpy as np, math, cv2

# ------------------------------------------------------------------ MeshWarp
def mesh_field_at(d, gx, gy, w, h, xs, ys):
    """Độ dời (điểm ảnh) tại tọa độ NGUỒN (xs, ys), nội suy song tuyến từ lưới nút (gy+1, gx+1, 2)."""
    u = np.clip(xs / max(1, w - 1) * gx, 0, gx); v = np.clip(ys / max(1, h - 1) * gy, 0, gy)
    i0 = np.minimum(np.floor(u).astype(int), gx - 1); j0 = np.minimum(np.floor(v).astype(int), gy - 1); fu = u - i0; fv = v - j0
    out = []
    for k in (0, 1):
        out.append(d[j0, i0, k] * (1 - fu) * (1 - fv) + d[j0, i0 + 1, k] * fu * (1 - fv) + d[j0 + 1, i0, k] * (1 - fu) * fv + d[j0 + 1, i0 + 1, k] * fu * fv)
    return out[0] * w, out[1] * h
MESH_ITERS = 4
def mesh_warp(img, d, gx, gy):
    """Nút lưới là điểm NGUỒN dời đi d: với điểm ra x tìm s sao cho s + D(s) = x (lặp điểm cố định), rồi lấy ảnh nguồn tại s."""
    h, w = img.shape[:2]; ys, xs = np.mgrid[0:h, 0:w].astype(np.float64); sx, sy = xs.copy(), ys.copy()
    for _ in range(MESH_ITERS):
        dx, dy = mesh_field_at(d, gx, gy, w, h, sx, sy); sx, sy = xs - dx, ys - dy
    return cv2.remap(img, sx.astype(np.float32), sy.astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

# ------------------------------------------------------------------ MaskMath
def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)
def rgb_to_lab(rgb):
    c = np.asarray(rgb, np.float64) / 255; lin = np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    M = np.array([[0.4124564, 0.3575761, 0.1804375], [0.2126729, 0.7151522, 0.0721750], [0.0193339, 0.1191920, 0.9503041]])
    xyz = lin @ M.T / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 216 / 24389, np.cbrt(xyz), (24389 / 27 * xyz + 16) / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)
def channel_value(img, space, ch):
    if space == 0: return img[..., ch].astype(np.float64) / 255
    if space == 1:
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV_FULL).astype(np.float64) / 255; return hsv[..., ch]
    lab = rgb_to_lab(img); return [lab[..., 0] / 100, np.clip((lab[..., 1] + 128) / 255, 0, 1), np.clip((lab[..., 2] + 128) / 255, 0, 1)][ch]
def channel_mask(img, space, ch, lo, hi):
    v = channel_value(img, space, ch); return smooth(lo - 0.04, lo, v) * (1 - smooth(hi, hi + 0.04, v))
def focus_mask(img, lo, hi):
    h, w = img.shape[:2]; g = (0.299 * img[..., 0] + 0.587 * img[..., 1] + 0.114 * img[..., 2]).astype(np.float32)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, borderType=cv2.BORDER_REPLICATE); gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, borderType=cv2.BORDER_REPLICATE)
    mag = np.hypot(gx, gy); ref = max(4.0, float(np.percentile(mag, 95)))
    m255 = np.clip(mag * 255 / ref, 0, 255); r = max(2, max(w, h) // 80)
    s = cv2.GaussianBlur(m255, (0, 0), r * 0.9) / 255
    return smooth(lo - 0.1, lo, s) * (1 - smooth(hi, hi + 0.1, s))

# ------------------------------------------------------------------ FaceLiquify
RIGHT_EYE = [33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7]
LEFT_EYE = [263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249]
JAW_A = [323, 361, 288, 397, 365, 379, 378, 400, 377]   # phía ảnh phải: từ gần tai -> gần cằm
JAW_B = [93, 132, 58, 172, 136, 150, 149, 176, 148]     # phía ảnh trái
NOSE_L, NOSE_R, MOUTH_R, MOUTH_L, FOREHEAD, CHIN, CHEEK_A, CHEEK_B = 129, 358, 61, 291, 10, 152, 234, 454
K_SLIM, K_EYES, K_NOSE, K_SMILE = 0.034, 0.050, 0.030, 0.030   # hằng số hiệu chỉnh (xem calib bên dưới)

def face_liquify_args(lm, w, h, slim, eyes, nose, smile):
    P = lambda i: np.array([lm[2 * i] * w, lm[2 * i + 1] * h])
    fw = float(np.linalg.norm(P(CHEEK_A) - P(CHEEK_B))); F, C = P(FOREHEAD), P(CHIN)
    a = (C - F) / max(1e-6, np.linalg.norm(C - F)); n = np.array([-a[1], a[0]]); long = max(w, h); segs = []
    def seg(p, v, r): segs.append((p[0] / w, p[1] / h, v[0] / w, v[1] / h, r / long))
    if slim > 0.005:
        for ids in (JAW_A, JAW_B):
            for k, i in enumerate(ids):
                p = P(i); side = float(np.dot(p - F, n)); dirv = -n * (1 if side > 0 else -1)
                seg(p, dirv * slim * fw * K_SLIM * math.sin(math.pi * (k + 0.5) / len(ids)), fw * 0.20)
    if eyes > 0.005:
        for ring, (ca, cb) in ((RIGHT_EYE, (33, 133)), (LEFT_EYE, (263, 362))):
            pts = np.array([P(i) for i in ring]); c = pts.mean(0); ew = float(np.linalg.norm(P(ca) - P(cb)))
            for p in pts[::2]:
                d = p - c; dn = np.linalg.norm(d)
                if dn > 1e-6: seg(p, d / dn * eyes * ew * K_EYES, ew * 0.7)
    if nose > 0.005:
        for i in (NOSE_L, NOSE_R):
            p = P(i); side = float(np.dot(p - F, n)); seg(p, -n * (1 if side > 0 else -1) * nose * fw * K_NOSE, fw * 0.12)
    if smile > 0.005:
        for i in (MOUTH_R, MOUTH_L): seg(P(i), -a * smile * fw * K_SMILE, fw * 0.13)
    return segs
def liquify(img, segs):
    h, w = img.shape[:2]; long = max(w, h); dx = np.zeros((h, w), np.float32); dy = np.zeros((h, w), np.float32)
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    for (x, y, mx, my, r) in segs:
        cx, cy, mx, my, r = x * w, y * h, mx * w, my * h, max(4, r * long); d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        t = np.clip(1 - d / r, 0, 1); wg = np.where(d < r, t * t * (3 - 2 * t), 0); dx += mx * wg; dy += my * wg
    return cv2.remap(img, xs - dx, ys - dy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

def synth_face(W=800, H=1000):
    lm = np.zeros(2 * 478, np.float64); cx, cy, a, b = 0.5, 0.5, 0.20, 0.28
    OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109]
    for k, i in enumerate(OVAL):
        t = math.radians(-90 + 10 * k); lm[2 * i], lm[2 * i + 1] = cx + a * math.cos(t), cy + b * math.sin(t)
    for ring, ecx in ((RIGHT_EYE, 0.40), (LEFT_EYE, 0.60)):
        for k, i in enumerate(ring):
            t = math.radians((180 if ecx < 0.5 else 0) + 22.5 * k * (1 if ecx < 0.5 else -1)); lm[2 * i], lm[2 * i + 1] = ecx + 0.05 * math.cos(t), 0.42 + 0.02 * math.sin(t)
    lm[2 * NOSE_L], lm[2 * NOSE_L + 1] = 0.46, 0.56; lm[2 * NOSE_R], lm[2 * NOSE_R + 1] = 0.54, 0.56
    lm[2 * MOUTH_R], lm[2 * MOUTH_R + 1] = 0.43, 0.68; lm[2 * MOUTH_L], lm[2 * MOUTH_L + 1] = 0.57, 0.68
    img = np.full((H, W, 3), 60, np.uint8)
    cv2.ellipse(img, (int(cx * W), int(cy * H)), (int(a * W), int(b * H)), 0, 0, 360, (225, 180, 150), -1)
    for ecx in (0.40, 0.60): cv2.ellipse(img, (int(ecx * W), int(0.42 * H)), (int(0.05 * W), int(0.02 * H)), 0, 0, 360, (20, 20, 20), -1)
    return lm, img, W, H
def face_width_at(img, y):
    row = (np.abs(img[y].astype(int) - 60).sum(1) > 40); xs = np.where(row)[0]; return int(xs.max() - xs.min()) if len(xs) else 0
def eye_area(img, ecx_px, ey):
    r = img[ey - 30:ey + 30, ecx_px - 60:ecx_px + 60]; return int((r.sum(2) < 90).sum())

if __name__ == "__main__":
    ok = True
    def chk(name, cond):
        global ok; ok &= bool(cond); print(("OK  " if cond else "FAIL"), name)
    rng = np.random.default_rng(3); H, W = 120, 160
    base = rng.integers(0, 256, (H, W, 3), dtype=np.uint8); base = cv2.GaussianBlur(base, (0, 0), 2)
    gx = gy = 4; z = np.zeros((gy + 1, gx + 1, 2))
    chk("MeshWarp: lưới 0 = giữ nguyên", (mesh_warp(base, z, gx, gy) == base).all())
    d = z.copy(); d[..., 0] = 0.05; out = mesh_warp(base, d, gx, gy); sh = int(round(0.05 * W))
    chk(f"MeshWarp: dời cả lưới +5% = dịch {sh}px", np.abs(out[:, sh + 2:-2].astype(int) - base[:, 2:-sh - 2].astype(int)).mean() < 2.0)
    dot = np.zeros((H, W, 3), np.uint8); cv2.circle(dot, (W // 2, H // 2), 3, (255, 255, 255), -1)
    d = z.copy(); d[2, 2, 0] = 0.06; d[2, 2, 1] = -0.08; o = mesh_warp(dot, d, gx, gy); ys, xs = np.nonzero(o[..., 0] > 128)
    cxm, cym = xs.mean(), ys.mean()
    chk(f"MeshWarp: kéo nút giữa (+6%,-8%) làm chấm dời ({cxm - W/2:+.1f},{cym - H/2:+.1f}) px kỳ vọng (+{0.06*W:.1f},{-0.08*H:.1f})",
        abs((cxm - W / 2) - 0.06 * W) < 1.5 and abs((cym - H / 2) + 0.08 * H) < 1.5)
    # Lab
    px = rng.integers(0, 256, (200, 3), dtype=np.uint8); mine = rgb_to_lab(px)
    ref = cv2.cvtColor((px.reshape(1, -1, 3).astype(np.float32) / 255), cv2.COLOR_RGB2Lab).reshape(-1, 3)
    chk(f"Lab khớp OpenCV (sai số tối đa {np.abs(mine - ref).max():.2f})", np.abs(mine - ref).max() < 0.6)
    img = np.zeros((40, 40, 3), np.uint8); img[:, :20] = (220, 30, 30); img[:, 20:] = (30, 30, 220)
    mr = channel_mask(img, 0, 0, 0.6, 1.0)
    chk("Kênh R trong 0.6..1: trái=1, phải=0", mr[:, :20].mean() > 0.99 and mr[:, 20:].mean() < 0.01)
    ms = channel_mask(img, 1, 1, 0.5, 1.0); chk("Kênh S (HSV) bão hòa cao chọn cả hai nửa", ms.mean() > 0.95)
    ml = channel_mask(img, 2, 0, 0.0, 0.4); chk("Kênh L (Lab) tối: chọn nửa xanh đậm", ml[:, 20:].mean() > 0.9 and ml[:, :20].mean() < 0.9)
    tex = np.zeros((200, 300, 3), np.uint8); tex[:, :150] = rng.integers(0, 256, (200, 150, 3), dtype=np.uint8); tex[:, 150:] = 120
    fm = focus_mask(tex, 0.35, 1.0)
    chk(f"Focus Area: nét(trái)={fm[:, :130].mean():.2f} >> phẳng(phải)={fm[:, 170:].mean():.3f}", fm[:, :130].mean() > 0.8 and fm[:, 170:].mean() < 0.05)
    # Face liquify (hiệu chỉnh hằng số)
    lm, face, W, H = synth_face(); yj = int(0.5 * H + 0.28 * H * 0.6); w0 = face_width_at(face, yj)
    f1 = liquify(face, face_liquify_args(lm, W, H, 1.0, 0, 0, 0)); w1 = face_width_at(f1, yj)
    f05 = liquify(face, face_liquify_args(lm, W, H, 0.5, 0, 0, 0)); w05 = face_width_at(f05, yj)
    print(f"   hàm: rộng hàm {w0}px -> {w1}px (slim=1: -{100*(w0-w1)/w0:.1f}%), slim=0.5: -{100*(w0-w05)/w0:.1f}%")
    chk("Thon mặt: slim=1 thu hàm 6–14%", 0.06 <= (w0 - w1) / w0 <= 0.14)
    chk("Thon mặt: slim=0.5 nằm giữa", 0 < (w0 - w05) < (w0 - w1))
    chk("Thon mặt: đường viền trán (không đẩy) không đổi quá 1.5%", abs(face_width_at(f1, int(0.5 * H - 0.28 * H * 0.7)) - face_width_at(face, int(0.5 * H - 0.28 * H * 0.7))) / w0 < 0.015)
    e0 = eye_area(face, int(0.40 * W), int(0.42 * H)); e1 = eye_area(liquify(face, face_liquify_args(lm, W, H, 0, 1.0, 0, 0)), int(0.40 * W), int(0.42 * H))
    print(f"   mắt: {e0} -> {e1} px (+{100*(e1-e0)/e0:.0f}%)")
    chk("To mắt: eyes=1 tăng diện tích mắt 15–60%", 1.15 <= e1 / e0 <= 1.60)
    chk("0 tham số -> không có đoạn đẩy", face_liquify_args(lm, W, H, 0, 0, 0, 0) == [])
    base_mouth = liquify(face, face_liquify_args(lm, W, H, 0, 0, 0, 1.0)); chk("Nụ cười không làm vỡ ảnh (khác ảnh gốc, cùng kích thước)", base_mouth.shape == face.shape)
    print("TẤT CẢ OK" if ok else "CÓ LỖI"); raise SystemExit(0 if ok else 1)
