"""Port Python của ColorFx (hueShift, lensFlare) để kiểm số học."""
import numpy as np, math

def hue_shift(rgb, deg):
    r, g, b = [float(v) / 255 for v in rgb]
    mx, mn = max(r, g, b), min(r, g, b); d = mx - mn
    if d < 1e-6: return tuple(rgb)
    t = (g - b) / d if mx == r else ((b - r) / d + 2 if mx == g else (r - g) / d + 4)
    h = 60 * (t + 6 if t < 0 else t); h = ((h + deg) % 360 + 360) % 360
    c = d; hp = h / 60; x = c * (1 - abs(hp % 2 - 1)); m0 = mx - c
    rr, gg, bb = [(c, x, 0), (x, c, 0), (0, c, x), (0, x, c), (x, 0, c), (c, 0, x)][min(int(hp), 5)]
    return tuple(int(round((v + m0) * 255)) for v in (rr, gg, bb))

def flare(img, intensity, cx, cy):
    h, w, _ = img.shape; s = max(w, h); lx, ly = cx * w, cy * h; ax, ay = w / 2 - lx, h / 2 - ly; k = intensity
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    F = np.zeros((h, w, 3))
    def glow(bx, by, sig, amp, tint):
        d2 = (xx - bx) ** 2 + (yy - by) ** 2; a = amp * np.exp(-d2 / (2 * sig * sig)) * (d2 <= (4 * sig) ** 2)
        F[...] += a[..., None] * np.array(tint)
    def disc(bx, by, rad, amp, tint):
        t = np.sqrt((xx - bx) ** 2 + (yy - by) ** 2) / rad
        a = amp * np.where(t < 0.6, 1, (1 - t) / 0.4) * (t <= 1)
        F[...] += a[..., None] * np.array(tint)
    glow(lx, ly, 0.05 * s, 1.0 * k, (1, .93, .78)); glow(lx, ly, 0.18 * s, 0.25 * k, (1, .85, .6))
    disc(lx + ax * .5, ly + ay * .5, 0.03 * s, .35 * k, (.6, .85, 1)); disc(lx + ax, ly + ay, 0.045 * s, .25 * k, (1, .55, .45)); disc(lx + ax * 1.6, ly + ay * 1.6, 0.07 * s, .2 * k, (.65, 1, .7))
    sx, sy = 0.35 * s, 0.004 * s
    a = 0.5 * k * np.exp(-((xx - lx) ** 2) / (2 * sx * sx) - ((yy - ly) ** 2) / (2 * sy * sy)) * (np.abs(yy - ly) < 5 * sy) * (np.abs(xx - lx) < 3 * sx)
    F[...] += a[..., None] * np.array((.7, .8, 1.0))
    F = np.clip(F, 0, 1)
    return 1 - (1 - img) * (1 - F), F

if __name__ == "__main__":
    print("red+120 ->", hue_shift((255, 0, 0), 120), "(expect 0,255,0)")
    print("red+240 ->", hue_shift((255, 0, 0), 240), "(expect 0,0,255)")
    print("(200,100,50)+0 ->", hue_shift((200, 100, 50), 0), "(identity)")
    print("(200,100,50)+360 ->", hue_shift((200, 100, 50), 360), "(identity)")
    print("gray unchanged ->", hue_shift((90, 90, 90), 77))
    print("(200,100,50)+90 ->", hue_shift((200, 100, 50), 90), " V preserved (max=200):", max(hue_shift((200, 100, 50), 90)))
    img = np.full((300, 400, 3), 0.2)
    out, F = flare(img, 0.8, 0.8, 0.2)
    print("never darker:", bool((out >= img - 1e-12).all()), " max flare:", round(float(F.max()), 3))
    print("brightest at light:", np.unravel_index(out.sum(-1).argmax(), out.shape[:2]), "(expect ~ (60, 320))")
    print("far corner unchanged:", bool(np.allclose(out[290, 5], img[290, 5])))
    out0, _ = flare(img, 0.0, 0.8, 0.2); print("intensity 0 -> identity:", bool(np.allclose(out0, img)))
