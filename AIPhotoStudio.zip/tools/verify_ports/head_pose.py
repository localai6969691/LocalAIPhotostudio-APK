#!/usr/bin/env python3
"""
R17 - Kiểm tra số học của engine/HeadPose.kt (ước lượng góc quay ngang của đầu từ điểm mốc có chiều sâu z + cổng giảm liquify).
  * mô hình mặt 3D tổng hợp (478 điểm; gò má 234/454 là hai đầu trục ngang), quay theo yaw/pitch/roll đã biết, chiếu TRỰC GIAO,
    chuẩn hóa kiểu MediaPipe trên ảnh KHÔNG vuông (x,z / w ; y / h) để bắt lỗi nhầm đơn vị
  * ước lượng = atan2(|Δz|·w, hypot(Δx·w, Δy·h)) giữa hai gò má; roll không ảnh hưởng (xoay trong mặt phẳng ảnh)
  * đo SAI SỐ khi có pitch và khi z có nhiễu (đặc trưng hóa giới hạn, không giả vờ chính xác tuyệt đối)
  * cổng: 1 khi yaw ≤ YAW_FULL_DEG, 0 khi ≥ YAW_ZERO_DEG, mượt, đơn điệu - hằng số đọc TỪ HeadPose.kt
  * kiểm thử đột biến: nhầm thước z (dùng h thay w), đảo atan2, bỏ hypot -> phải bị bắt
Chạy: python3 tools/verify_ports/head_pose.py
"""
import math, os, re, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
KT = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio", "engine", "HeadPose.kt")
src = open(KT, encoding="utf-8").read()
def const(name, kind="f"):
    m = re.search(r"const val " + name + r"\s*=\s*([0-9.]+)f?", src)
    return float(m.group(1)) if m else None
YAW_FULL, YAW_ZERO, MIN_FACE_PX = const("YAW_FULL_DEG"), const("YAW_ZERO_DEG"), const("MIN_FACE_PX")
POINTS = int(const("POINTS"))
CHEEK_R, CHEEK_L = int(const("CHEEK_R")), int(const("CHEEK_L"))
F = np.float32
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok: fails.append(name)

# ------------------------------------------------------------------ bản dịch Kotlin
def yaw_abs_deg(lm, w, h, _z_scale="w", _swap=False, _no_hypot=False):
    if w <= 0 or h <= 0 or lm.size < 3 * POINTS: return None
    dx = F(lm[2 * CHEEK_L] - lm[2 * CHEEK_R]) * F(w)
    dy = F(lm[2 * CHEEK_L + 1] - lm[2 * CHEEK_R + 1]) * F(h)
    in_plane = F(abs(dx)) if _no_hypot else F(math.hypot(float(dx), float(dy)))
    if in_plane < MIN_FACE_PX: return None
    zs = w if _z_scale == "w" else h
    dz = F(lm[2 * POINTS + CHEEK_L] - lm[2 * POINTS + CHEEK_R]) * F(zs)
    deg = math.degrees(math.atan2(float(in_plane), abs(float(dz)))) if _swap else math.degrees(math.atan2(abs(float(dz)), float(in_plane)))
    return None if math.isnan(deg) else F(deg)

def smooth(t):
    c = 0.0 if t < 0 else (1.0 if t > 1 else t)
    return c * c * (3.0 - 2.0 * c)
def liquify_gain(yaw):
    if yaw is None: return 1.0
    return 1.0 - smooth((float(yaw) - YAW_FULL) / (YAW_ZERO - YAW_FULL))

# ------------------------------------------------------------------ mặt 3D tổng hợp -> toạ độ kiểu MediaPipe
rng = np.random.default_rng(17)
BASE = rng.normal(0, 0.18, (POINTS, 3))          # 478 điểm rải quanh tâm đầu (đơn vị: bề rộng mặt = 1)
BASE[CHEEK_R] = (-0.5, 0.0, 0.0); BASE[CHEEK_L] = (0.5, 0.0, 0.0)
def rot_y(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rot_x(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def rot_z(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
def make_lm(w, h, yaw=0, pitch=0, roll=0, face_px_frac=0.3, order="yaw_pitch", z_noise=0.0, seed=0):
    R = rot_z(math.radians(roll)) @ (rot_x(math.radians(pitch)) @ rot_y(math.radians(yaw)) if order == "yaw_pitch"
                                     else rot_y(math.radians(yaw)) @ rot_x(math.radians(pitch)))
    P = BASE @ R.T * (face_px_frac * w)          # pixel, trực giao: x,y ra ảnh, z = độ sâu (cùng thước pixel)
    if z_noise:
        P[:, 2] += np.random.default_rng(seed).normal(0, z_noise * face_px_frac * w, POINTS)
    lm = np.zeros(3 * POINTS, dtype=F)
    lm[0:2 * POINTS:2] = (P[:, 0] + w / 2) / w
    lm[1:2 * POINTS:2] = (P[:, 1] + h / 2) / h
    lm[2 * POINTS:] = P[:, 2] / w                # MediaPipe: z cùng thước với x (chuẩn hóa theo chiều rộng ảnh)
    return lm

# ------------------------------------------------------------------ 0) hằng số
check("hằng số đọc từ HeadPose.kt: YAW_FULL=20, YAW_ZERO=55, MIN_FACE_PX=8, POINTS=478, CHEEK 234/454",
      (YAW_FULL, YAW_ZERO, MIN_FACE_PX, POINTS, CHEEK_R, CHEEK_L) == (20.0, 55.0, 8.0, 478, 234, 454), (YAW_FULL, YAW_ZERO, MIN_FACE_PX, POINTS, CHEEK_R, CHEEK_L))

# ------------------------------------------------------------------ 1) khôi phục yaw (ảnh không vuông: 1000×600)
W, H = 1000, 600
errs = []
for yaw in range(0, 81, 10):
    for sgn in (1, -1):
        est = float(yaw_abs_deg(make_lm(W, H, yaw=sgn * yaw), W, H))
        errs.append(abs(est - yaw))
check("yaw 0..80° (cả hai chiều quay), ảnh 1000×600, không pitch: sai số < 0,05°", max(errs) < 0.05, f"{max(errs):.3f}")
errs_sq = [abs(float(yaw_abs_deg(make_lm(800, 800, yaw=y), 800, 800)) - y) for y in range(0, 81, 10)]
check("ảnh vuông 800×800 cũng chính xác (sai số < 0,05°)", max(errs_sq) < 0.05)
errs_port = [abs(float(yaw_abs_deg(make_lm(400, 1200, yaw=y), 400, 1200)) - y) for y in range(0, 81, 10)]
check("ảnh dọc 400×1200 cũng chính xác (không lẫn thước w/h)", max(errs_port) < 0.05)

# ------------------------------------------------------------------ 2) roll không ảnh hưởng; pitch gây sai số có giới hạn
errs = [abs(float(yaw_abs_deg(make_lm(W, H, yaw=y, roll=r), W, H)) - y) for y in (0, 25, 50) for r in (-60, -25, 0, 25, 60)]
check("roll (xoay trong mặt phẳng ảnh) KHÔNG làm đổi yaw ước lượng (sai số < 0,05°)", max(errs) < 0.05, f"{max(errs):.3f}")
worst = {}
for order in ("yaw_pitch", "pitch_yaw"):
    w_err = 0.0
    for yaw in range(0, 61, 10):
        for pitch in (-20, -10, 0, 10, 20):
            w_err = max(w_err, abs(float(yaw_abs_deg(make_lm(W, H, yaw=yaw, pitch=pitch, order=order), W, H)) - yaw))
    worst[order] = w_err
check("có pitch ≤ 20°, yaw ≤ 60°: sai số ≤ 7° ở cả hai thứ tự quay (đo được tối đa 5,5°; ghi ở A98)", max(worst.values()) <= 7.0, worst)
check("pitch nhỏ (≤ 10°): sai số ≤ 2° (đo được tối đa 1,5°)", max(abs(float(yaw_abs_deg(make_lm(W, H, yaw=y, pitch=p), W, H)) - y) for y in range(0, 61, 10) for p in (-10, 0, 10)) <= 2.0)

# ------------------------------------------------------------------ 3) nhiễu z (MediaPipe ước lượng z, không đo)
for sigma in (0.02, 0.05):
    e = [abs(float(yaw_abs_deg(make_lm(W, H, yaw=30, z_noise=sigma, seed=s), W, H)) - 30) for s in range(300)]
    bound = {0.02: 1.6, 0.05: 3.5}[sigma]
    check(f"nhiễu z σ={sigma:.2f}×bề rộng mặt, yaw 30°: sai số trung bình < {bound}°", float(np.mean(e)) < bound, f"{np.mean(e):.2f}")
fr = [liquify_gain(yaw_abs_deg(make_lm(W, H, yaw=0, z_noise=0.05, seed=s), W, H)) for s in range(300)]
check("mặt nhìn thẳng + nhiễu z σ=0,05: cổng KHÔNG bao giờ giảm hiệu ứng (gain = 1 ở 300 lần thử)", min(fr) == 1.0, min(fr))
pr = [liquify_gain(yaw_abs_deg(make_lm(W, H, yaw=75, z_noise=0.05, seed=s), W, H)) for s in range(300)]
check("mặt gần nghiêng hẳn (75°) + nhiễu: cổng tắt hầu hết (gain < 0,05 ở ≥ 95% lần thử)", float(np.mean(np.array(pr) < 0.05)) >= 0.95, np.mean(np.array(pr) < 0.05))

# ------------------------------------------------------------------ 4) cổng
ys = np.linspace(0, 90, 901)
g = [liquify_gain(F(y)) for y in ys]
check("gain = 1 khi yaw ≤ YAW_FULL; = 0 khi yaw ≥ YAW_ZERO", all(liquify_gain(F(y)) == 1.0 for y in (0, 10, 20)) and all(liquify_gain(F(y)) == 0.0 for y in (55, 70, 90)))
check("gain đơn điệu không tăng và liên tục (bước nhảy < 0,03 mỗi 0,1°)", all(g[i + 1] <= g[i] + 1e-12 for i in range(len(g) - 1)) and max(abs(g[i + 1] - g[i]) for i in range(len(g) - 1)) < 0.03)
check("gain tại điểm giữa (37,5°) = 0,5 (smoothstep đối xứng)", abs(liquify_gain(F(37.5)) - 0.5) < 1e-6)
check("không có z (mảng chỉ có x,y) hoặc None -> không giảm hiệu ứng (gain = 1)", liquify_gain(None) == 1.0 and yaw_abs_deg(make_lm(W, H)[:2 * POINTS], W, H) is None)
check("mặt quá nhỏ (< 8 px giữa hai gò má) -> không ước lượng (None) -> không giảm", yaw_abs_deg(make_lm(W, H, face_px_frac=0.005), W, H) is None)
check("kích thước ảnh sai (0) -> None, không ném lỗi", yaw_abs_deg(make_lm(W, H), 0, H) is None and yaw_abs_deg(make_lm(W, H), W, 0) is None)
check("không NaN: toàn bộ điểm trùng nhau (suy biến) -> None hoặc số hữu hạn", (lambda r: r is None or math.isfinite(float(r)))(yaw_abs_deg(np.full(3 * POINTS, 0.5, dtype=F), W, H)))

# ------------------------------------------------------------------ 5) đột biến
check("đột biến: dùng chiều cao h làm thước z -> phép đo ảnh không vuông BỊ BẮT",
      max(abs(float(yaw_abs_deg(make_lm(W, H, yaw=y), W, H, _z_scale="h")) - y) for y in range(10, 71, 10)) > 1.0)
check("đột biến: đảo atan2 -> BỊ BẮT", max(abs(float(yaw_abs_deg(make_lm(W, H, yaw=y), W, H, _swap=True)) - y) for y in range(10, 71, 10)) > 10.0)
check("đột biến: bỏ hypot (chỉ dùng Δx) -> phép đo có roll BỊ BẮT",
      max(abs(float(yaw_abs_deg(make_lm(W, H, yaw=y, roll=40), W, H, _no_hypot=True)) - y) for y in range(10, 71, 10)) > 2.0)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
