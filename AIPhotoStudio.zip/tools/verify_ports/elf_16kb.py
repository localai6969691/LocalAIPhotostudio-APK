#!/usr/bin/env python3
"""Kiểm chứng tools/check_16kb.py (R31) — bộ kiểm căn chỉnh 16 KB của thư viện native cho Google Play.

Ba lớp bằng chứng, để KHÔNG phải tin vào chính bộ kiểm:
  A. ELF tổng hợp dựng tay (đúng từng byte) với đáp án biết trước + ĐỘT BIẾN (đổi p_align, lệch RELRO, lệch vaddr/offset, ELF 32-bit);
  B. nếu có `gcc`: biên dịch THẬT một thư viện dùng chung với `-z max-page-size=4096` và `=16384`, đối chiếu kết luận với `readelf -lW`;
  C. tệp zip: .so lưu KHÔNG NÉN ở vị trí lệch / đã căn 16 KB (dựng bằng zipfile), .so bị NÉN thì không xét căn chỉnh zip.
"""
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import check_16kb as C  # noqa: E402

FAIL = []
N = 0


def expect(name, cond, detail=""):
    global N
    N += 1
    if not cond:
        FAIL.append(name)
        print(f"  ✗ {name} {detail}")


def build_elf(loads, relro=None, elf_class=2, machine=183):
    """loads = [(offset, vaddr, filesz, memsz, align)], relro = (vaddr, memsz) | None."""
    ph = []
    for off, va, fsz, msz, al in loads:
        ph.append(struct.pack("<IIQQQQQQ", C.PT_LOAD, 5, off, va, va, fsz, msz, al))
    if relro:
        ph.append(struct.pack("<IIQQQQQQ", C.PT_GNU_RELRO, 4, 0, relro[0], relro[0], relro[1], relro[1], 1))
    ident = b"\x7fELF" + bytes([elf_class, 1, 1, 0]) + b"\x00" * 8
    hdr = ident + struct.pack("<HHIQQQIHHHHHH", 3, machine, 1, 0, 64, 0, 0, 64, 56, len(ph), 0, 0, 0)
    assert len(hdr) == 64
    body = b"".join(ph)
    total = max([o + f for o, _v, f, _m, _a in loads] + [64 + len(body)])
    return hdr + body + b"\x00" * (total - 64 - len(body))


GOOD = [(0, 0, 0x8000, 0x8000, 0x4000), (0x8000, 0x8000, 0x4000, 0x6000, 0x4000)]
RELRO_OK = (0x8000, 0x4000)  # kết thúc ở 0xC000 = 3 × 16 KB


def part_a():
    print("A. ELF tổng hợp + đột biến")
    st, why = C.check_elf(build_elf(GOOD, RELRO_OK))
    expect("A1 ELF đạt (align 16 KB, RELRO chuẩn) → ok", st == "ok", str(why))
    # đột biến 1: p_align 4 KB
    bad = [(o, v, f, m, 0x1000) for o, v, f, m, _a in GOOD]
    st, why = C.check_elf(build_elf(bad, RELRO_OK))
    expect("A2 p_align = 4 KB → fail", st == "fail" and any("p_align" in w for w in why), str(why))
    # đột biến 2: chỉ MỘT đoạn lỗi
    one = [GOOD[0], (0x8000, 0x8000, 0x4000, 0x6000, 0x2000)]
    st, why = C.check_elf(build_elf(one, RELRO_OK))
    expect("A3 một trong hai PT_LOAD lỗi → vẫn fail", st == "fail", str(why))
    # đột biến 3: RELRO kết thúc lệch ranh giới
    st, why = C.check_elf(build_elf(GOOD, (0x8000, 0x3000)))
    expect("A4 RELRO không kết thúc ở ranh giới 16 KB → fail", st == "fail" and any("RELRO" in w for w in why), str(why))
    # đột biến 4: vaddr không đồng dư offset
    skew = [GOOD[0], (0x8000, 0x9000, 0x4000, 0x6000, 0x4000)]
    st, why = C.check_elf(build_elf(skew, None))
    expect("A5 p_vaddr lệch p_offset theo p_align → fail", st == "fail" and any("đồng dư" in w for w in why), str(why))
    # p_align lớn hơn (64 KB) vẫn đạt vì là bội của 16 KB
    big = [(0, 0, 0x10000, 0x10000, 0x10000), (0x10000, 0x10000, 0x4000, 0x4000, 0x10000)]
    st, why = C.check_elf(build_elf(big, None))
    expect("A6 p_align = 64 KB (bội của 16 KB) → ok", st == "ok", str(why))
    # ELF 32-bit bị bỏ qua
    e32 = bytearray(build_elf(GOOD, RELRO_OK))
    e32[4] = 1
    st, _ = C.check_elf(bytes(e32))
    expect("A7 ELF 32-bit → skip", st == "skip")
    st, _ = C.check_elf(b"not an elf at all" * 10)
    expect("A8 không phải ELF → skip", st == "skip")
    # tệp cắt cụt giữa program header
    cut = build_elf(GOOD, RELRO_OK)[:64 + 56]
    st, _ = C.check_elf(cut)
    expect("A9 program header bị cắt cụt → fail (không im lặng cho qua)", st == "fail")


def readelf_aligns(path):
    out = subprocess.run(["readelf", "-lW", path], capture_output=True, text=True).stdout
    aligns = []
    for ln in out.splitlines():
        t = ln.split()
        if t and t[0] == "LOAD":
            aligns.append(int(t[-1], 16))
    return aligns


def part_b():
    print("B. biên dịch THẬT bằng gcc (nếu có)")
    if not shutil.which("gcc") or not shutil.which("readelf"):
        print("  (không có gcc/readelf — bỏ qua phần B)")
        return
    with tempfile.TemporaryDirectory() as d:
        src = os.path.join(d, "x.c")
        with open(src, "w") as f:
            f.write("int g_data[4096] = {1};\nstatic const char *msg = \"hi\";\nint add(int a, int b) { return a + b + g_data[0] + (int)msg[0]; }\n")
        for page, want in ((4096, "fail"), (16384, "ok")):
            so = os.path.join(d, f"lib{page}.so")
            cmd = ["gcc", "-shared", "-fPIC", "-O1", "-o", so, src, f"-Wl,-z,max-page-size={page}", f"-Wl,-z,common-page-size={page}"]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                print("  (gcc không dựng được thư viện dùng chung — bỏ qua)", r.stderr[:120])
                return
            with open(so, "rb") as f:
                st, why = C.check_elf(f.read())
            al = readelf_aligns(so)
            expect(f"B max-page-size={page}: bộ kiểm = {want} (readelf: p_align {[hex(a) for a in al]})", st == want, f"{st} {why}")
            # đối chiếu độc lập với readelf: kết luận về p_align phải trùng
            readelf_ok = all(a % 0x4000 == 0 for a in al)
            expect(f"B max-page-size={page}: bộ kiểm khớp readelf về p_align", (st == "ok") == readelf_ok or (st == "fail" and not readelf_ok) or why and "RELRO" in " ".join(why), f"{st} {al}")


def part_c():
    print("C. tệp zip")
    with tempfile.TemporaryDirectory() as d:
        elf = build_elf(GOOD, RELRO_OK)
        # c1: STORED, không căn → fail
        p1 = os.path.join(d, "unaligned.apk")
        with zipfile.ZipFile(p1, "w") as z:
            z.writestr(zipfile.ZipInfo("lib/arm64-v8a/pad.txt"), b"x" * 123)  # làm lệch
            zi = zipfile.ZipInfo("lib/arm64-v8a/libx.so")
            zi.compress_type = zipfile.ZIP_STORED
            z.writestr(zi, elf)
        res = []
        C.scan(p1, res)
        r = [x for x in res if x[0].endswith("libx.so")][0]
        expect("C1 .so lưu không nén ở vị trí lệch → fail", r[1] == "fail" and any("zipalign" in w for w in r[2]), str(r))
        # c2: STORED + căn 16 KB bằng trường extra → ok
        p2 = os.path.join(d, "aligned.apk")
        with zipfile.ZipFile(p2, "w") as z:
            z.writestr(zipfile.ZipInfo("lib/arm64-v8a/pad.txt"), b"x" * 123)
            name = "lib/arm64-v8a/libx.so"
            pos = z.fp.tell()
            pad = (-(pos + 30 + len(name))) % C.PAGE
            if 0 < pad < 4:
                pad += C.PAGE
            zi = zipfile.ZipInfo(name)
            zi.compress_type = zipfile.ZIP_STORED
            if pad:
                zi.extra = struct.pack("<HH", 0xD935, pad - 4) + b"\x00" * (pad - 4)
            z.writestr(zi, elf)
        res = []
        C.scan(p2, res)
        r = [x for x in res if x[0].endswith("libx.so")][0]
        expect("C2 .so lưu không nén, đã căn 16 KB → ok", r[1] == "ok", str(r))
        # c3: bị NÉN (đúng cấu hình useLegacyPackaging = true của dự án) → không xét căn chỉnh zip
        p3 = os.path.join(d, "deflated.apk")
        with zipfile.ZipFile(p3, "w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr(zipfile.ZipInfo("lib/arm64-v8a/pad.txt"), b"x" * 123)
            z.writestr("lib/arm64-v8a/libx.so", elf)
        res = []
        C.scan(p3, res)
        r = [x for x in res if x[0].endswith("libx.so")][0]
        expect("C3 .so bị nén → ok (chỉ xét ELF)", r[1] == "ok", str(r))
        # c4: ELF lỗi bên trong zip vẫn bị bắt, 32-bit thì bỏ qua; mã thoát của main()
        bad = build_elf([(o, v, f, m, 0x1000) for o, v, f, m, _a in GOOD], RELRO_OK)
        e32 = bytearray(elf); e32[4] = 1
        p4 = os.path.join(d, "mixed.apk")
        with zipfile.ZipFile(p4, "w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr("lib/arm64-v8a/libbad.so", bad)
            z.writestr("lib/armeabi-v7a/libold.so", bytes(e32))
        expect("C4 main() trả 1 khi có thư viện 64-bit lỗi", C.main([p4]) == 1)
        p5 = os.path.join(d, "clean.apk")
        with zipfile.ZipFile(p5, "w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr("lib/arm64-v8a/libgood.so", elf)
            z.writestr("lib/armeabi-v7a/libold.so", bytes(e32))
        expect("C5 main() trả 0 khi mọi thư viện 64-bit đạt (32-bit bị bỏ qua)", C.main([p5]) == 0)
        expect("C6 main() trả 2 khi thiếu đường dẫn", C.main([os.path.join(d, "khong_co.apk")]) == 2)


part_a()
part_b()
part_c()
print()
if FAIL:
    print(f"THẤT BẠI {len(FAIL)}/{N}:", FAIL)
    sys.exit(1)
print(f"TẤT CẢ OK ({N} kiểm tra)")
