import re, unicodedata
def rx(key):
    exact=key.endswith("!"); body=re.escape(key[:-1] if exact else key)
    return re.compile(r"(?<![a-z0-9])"+body+(r"(?![a-z0-9])" if exact else ""))
class Clause:
    def __init__(s,t): s.t=t
    def has(s,*keys): return any(rx(k).search(s.t) for k in keys)
def normalize(x):
    x=unicodedata.normalize("NFD",x); x=re.sub(r"[\u0300-\u036f]+","",x).replace("đ","d")
    x=re.sub(r"[^a-z0-9%:/&\s]"," ",x); return re.sub(r"\s+"," ",x).strip()
STRONG=["rat!","manh!","nhieu!","cuc!","very!","strong","much!","heavy","max!"]; WEAK=["nhe!","chut!","hoi!","slight","little!","bit!","subtle"]
def intensity(t): return 1.6 if any(rx(k).search(t) for k in STRONG) else (0.5 if any(rx(k).search(t) for k in WEAK) else 1.0)
def scoped(orig,t):
    c=Clause(t); k=intensity(t); red=c.has("giam","bot!","less!","reduce","lower","decrease")
    v=lambda b:min(b*k,1.0)
    if c.has("quang tham","bong mat","tham mat","dark circle","under eye","under-eye","eye bag","eyebag"):
        return [] if red else [("dark_circles",[("SHADOWS",v(.55)),("BRIGHTNESS",v(.10))])]
    if c.has("trang rang","rang trang","tay trang rang","whiten","teeth","tooth"):
        return [("teeth",[("BRIGHTNESS",v(.22)),("SATURATION",-v(.45))])]
    eyeWord="mắt" in orig or c.has("eye!","eyes!","long lanh")
    if eyeWord and c.has("sang","bright","long lanh","ro!","net","lam ro","sharp"):
        return [] if red else [("eyes",[("BRIGHTNESS",v(.15)),("CLARITY",v(.35)),("CONTRAST",v(.10))])]
    if c.has("chu the","subject") and c.has("noi bat","pop","sang","bright","ro!","net","lam ro"):
        return [] if red else [("subject",[("BRIGHTNESS",v(.12)),("CONTRAST",v(.15)),("CLARITY",v(.30))])]
    if c.has("toi nen","toi phong","toi hau canh","darken background","dim background","background darker"):
        return [("background",[("BRIGHTNESS",-v(.30))])]
    if c.has("nhat nen","bot mau nen","desaturate background","muted background"):
        return [("background",[("SATURATION",-v(.50))])]
    if c.has("bau troi","sky!"):
        if red: return []
        if c.has("an tuong","kich tinh","dramatic","hung vi"): o=[("CLARITY",v(.4)),("CONTRAST",v(.25)),("SATURATION",v(.2))]
        elif c.has("hoang hon","sunset","am ap","warm","vang!","cam!"): o=[("WARMTH",v(.4)),("SATURATION",v(.2))]
        elif c.has("toi!","dark","dim"): o=[("BRIGHTNESS",-v(.2))]
        elif c.has("sang","bright"): o=[("BRIGHTNESS",v(.2))]
        elif c.has("xanh","blue"): o=[("SATURATION",v(.35)),("CONTRAST",v(.10))]
        else: o=[("SATURATION",v(.25)),("CONTRAST",v(.10))]
        return [("sky",o)]
    return None
def plan(prompt):
    raw=unicodedata.normalize("NFC",prompt.lower())
    parts=re.split(r"[,;.!?\n]+|\s+(?:và|and|rồi|then|với|kèm|đồng thời|also)\s+",raw)
    res=[]
    for o in parts:
        o=o.strip(); t=normalize(o)
        if not t: continue
        r=scoped(o,t); res.append(("scoped",r) if r is not None else ("global",t))
    return res
tests=[
 ("làm trắng răng","teeth"),("làm sáng mắt","eyes"),("mắt long lanh hơn","eyes"),("làm sáng mặt","NOT eyes"),("sáng da mặt","NOT eyes"),
 ("xóa quầng thâm","dark_circles"),("giảm bọng mắt","[] reduce"),("remove dark circles","dark_circles"),
 ("bầu trời xanh hơn","sky"),("làm bầu trời ấn tượng hơn","sky"),("bầu trời hoàng hôn","sky"),("làm tối nền","background"),
 ("làm nổi bật chủ thể","subject"),("da mịn, răng trắng, bầu trời xanh","3 clauses"),("brighten eyes and whiten teeth","2 clauses"),
 ("rất trắng răng","teeth strong"),("làm sáng ảnh","global"),("tông ấm","global"),
]
for prm,exp in tests:
    print(f"{prm!r:42} -> {plan(prm)}   [{exp}]")
