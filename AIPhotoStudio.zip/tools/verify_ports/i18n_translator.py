#!/usr/bin/env python3
"""Bản port Python của i18n/Translator.kt + AppLanguage + HelpContent.filter (R33), chạy trên CHÍNH các gói dịch đã đóng gói trong assets/.

Vì sandbox không có kotlinc, đây là bằng chứng cho LOGIC tra cứu: khớp chính xác, khớp mẫu có chỗ trống, thứ tự ưu tiên mẫu, dịch phần nằm trong chỗ trống,
và — quan trọng nhất — KHÔNG mẫu nào bị mẫu khác nuốt mất (mỗi mẫu sinh một chuỗi thử và phải ra đúng bản dịch của nó). Có đột biến để chứng minh bài kiểm bắt được lỗi.
"""
import json
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.dirname(os.path.dirname(HERE))
ASSETS = os.path.join(PROJ, "app", "src", "main", "assets")
PH = re.compile(r"\{(\d+)\}")
MAX_LEN = 400


class Translator:
    def __init__(self, entries, mut=None):
        self.mut = mut
        self.exact = {}
        self.templates = []  # (regex, out, fixed_len)
        self.cache = {}
        for k, v in entries.items():
            if not v:
                continue
            if PH.search(k):
                b, last, fixed = "^", 0, 0
                for m in PH.finditer(k):
                    lit = k[last:m.start()]
                    b += re.escape(lit) + "(.+?)"
                    fixed += len(lit)
                    last = m.end()
                tail = k[last:]
                b += re.escape(tail) + "$"
                fixed += len(tail)
                self.templates.append((re.compile(b, re.S), v, fixed))
            else:
                self.exact[k] = v
        if mut != "no_sort":
            self.templates.sort(key=lambda t: -t[2])

    def lookup(self, s):
        if not s or len(s) > MAX_LEN:
            return None
        if s in self.exact:
            return self.exact[s]
        if not self.templates:
            return None
        if s in self.cache:
            return self.cache[s]
        result = None
        for rx, out, _fx in self.templates:
            m = rx.fullmatch(s)
            if not m:
                continue

            def sub(p):
                idx = int(p.group(1))
                if idx + 1 <= len(m.groups()):
                    cap = m.group(idx + 1)
                    return cap if self.mut == "no_capture_translate" else self.exact.get(cap, cap)
                return p.group(0)

            result = PH.sub(sub, out)
            break
        self.cache[s] = result
        return result

    def translate(self, s):
        r = self.lookup(s)
        return s if r is None else r


# ---- AppLanguages
LANGS = ["vi", "en", "zh", "es", "hi", "ar", "pt", "ru", "ja", "ko", "fr", "de", "id"]


def resolve_auto(sys_lang):
    l = {"in": "id", "iw": "he"}.get(sys_lang.lower(), sys_lang.lower())
    return l if l in LANGS else "en"


def resolve(pref, sys_lang):
    return pref if pref != "auto" and pref in LANGS else resolve_auto(sys_lang)


# ---- HelpContent.fold / filter
def fold(s):
    d = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return d.replace("đ", "d").replace("Đ", "D").lower()


def help_filter(sections, query):
    q = fold(query.strip())
    if not q:
        return sections
    out = []
    for s in sections:
        hit = q in fold(s["title"])
        items = s["items"] if hit else [i for i in s["items"] if q in fold(i["t"]) or q in fold(i["b"])]
        if items:
            out.append({"title": s["title"], "items": items})
    return out


FAIL = []
N = 0


def expect(name, cond, detail=""):
    global N
    N += 1
    if not cond:
        FAIL.append(name)
        print(f"  ✗ {name} {detail}")


def unit(mut=None):
    global FAIL, N
    FAIL, N = [], 0
    T = lambda d: Translator(d, mut)
    t = T({"Mở": "Open", "Lớp ({0})": "Layers ({0})", "Đã xóa {0} vật thể": "Removed {0} object(s)", "{0}×{1}": "{0} by {1}", "Cắt {0}": "Crop {0}",
           "Nhuộm {0}": "Dye {0}", "Nâu": "Brown", "{0} lớp": "{0} layers", "Đã lưu {0} lớp ({1})": "Saved {1}: {0} layers", "Chữ (a+b)": "Text (a+b)"})
    expect("U1 khớp chính xác", t.lookup("Mở") == "Open")
    expect("U2 không có ⇒ None, translate giữ nguyên", t.lookup("Xyz") is None and t.translate("Xyz") == "Xyz")
    expect("U3 mẫu một chỗ trống", t.lookup("Lớp (3)") == "Layers (3)")
    expect("U4 mẫu hai chỗ trống đảo thứ tự trong bản dịch", t.lookup("Đã lưu 5 lớp (nháp)") == "Saved nháp: 5 layers", str(t.lookup("Đã lưu 5 lớp (nháp)")))
    expect("U5 chỗ trống ở đầu và giữa: {0}×{1}", t.lookup("1920×1080") == "1920 by 1080")
    expect("U6 phần trong chỗ trống được dịch nếu là khóa nguyên văn (Nhuộm Nâu ⇒ Dye Brown)", t.lookup("Nhuộm Nâu") == "Dye Brown", str(t.lookup("Nhuộm Nâu")))
    expect("U7 phần trong chỗ trống là số/tên riêng thì giữ nguyên", t.lookup("Cắt 16:9") == "Crop 16:9")
    expect("U8 mẫu cụ thể hơn thắng mẫu ngắn: 'Đã xóa 2 vật thể' không bị '{0} lớp' nuốt", t.lookup("Đã xóa 2 vật thể") == "Removed 2 object(s)")
    expect("U9 ký tự regex trong phần cố định được thoát: 'Chữ (a+b)' khớp chính xác", t.lookup("Chữ (a+b)") == "Text (a+b)")
    expect("U10 chuỗi quá dài (>400) không tra", t.lookup("Mở" + "x" * 500) is None)
    expect("U11 chuỗi rỗng ⇒ None", t.lookup("") is None)
    expect("U12 nhiều dòng khớp mẫu (DOTALL)", t.lookup("Lớp (a\nb)") == "Layers (a\nb)")
    expect("U13 kết quả được nhớ đệm giống nhau", t.lookup("Lớp (9)") == t.lookup("Lớp (9)") == "Layers (9)")
    expect("U14 bản dịch rỗng bị bỏ qua", T({"A": ""}).lookup("A") is None)
    # ưu tiên: khớp chính xác thắng mẫu
    t2 = T({"Lớp (1)": "Layer one", "Lớp ({0})": "Layers ({0})"})
    expect("U15 khớp chính xác thắng khớp mẫu", t2.lookup("Lớp (1)") == "Layer one" and t2.lookup("Lớp (2)") == "Layers (2)")
    # AppLanguages
    expect("A1 auto: vi/en/zh giữ nguyên, 'in' ⇒ id, lạ ⇒ en", resolve_auto("vi") == "vi" and resolve_auto("zh") == "zh" and resolve_auto("in") == "id" and resolve_auto("th") == "en" and resolve_auto("EN") == "en")
    expect("A2 resolve: mã được hỗ trợ giữ nguyên; mã lạ ⇒ như auto", resolve("ja", "vi") == "ja" and resolve("xx", "fr") == "fr" and resolve("auto", "de") == "de")
    # Help filter
    secs = [{"title": "Bắt đầu", "items": [{"t": "Mở ảnh", "b": "Bấm Mở"}, {"t": "Lưu", "b": "Xuất ra thư viện"}]}, {"title": "Màu", "items": [{"t": "Cân bằng", "b": "ấm lạnh"}]}]
    expect("H1 từ khóa trống ⇒ nguyên bản", help_filter(secs, "  ") == secs)
    expect("H2 lọc theo nội dung, bỏ nhóm rỗng", [s["title"] for s in help_filter(secs, "thư viện")] == ["Bắt đầu"] and len(help_filter(secs, "thư viện")[0]["items"]) == 1)
    expect("H3 khớp tiêu đề nhóm ⇒ giữ cả nhóm", len(help_filter(secs, "bắt đầu")[0]["items"]) == 2)
    expect("H4 không phân biệt hoa thường", [s["title"] for s in help_filter(secs, "ẤM LẠNH")] == ["Màu"])
    expect("H4b tìm không phân biệt dấu nên 'ẤM' cũng khớp 'Bấm' (2 nhóm) — đúng thiết kế", len(help_filter(secs, "ẤM")) == 2)
    expect("H5 không khớp ⇒ rỗng", help_filter(secs, "zzz") == [])
    expect("H6 không phân biệt dấu: 'mo anh' tìm được 'Mở ảnh'", [s["title"] for s in help_filter(secs, "mo anh")] == ["Bắt đầu"])
    expect("H7 'đ' và 'd' như nhau; cách gõ tổ hợp (NFD) cũng tìm được", len(help_filter(secs, "bat dau")) == 1 and len(help_filter(secs, unicodedata.normalize("NFD", "thư viện"))) == 1)
    expect("H8 tiếng Tây Ban Nha: 'camara' tìm được 'cámara'", len(help_filter([{"title": "x", "items": [{"t": "cámara", "b": "b"}]}], "camara")) == 1)
    return list(FAIL)


def integration(mut=None):
    """Chạy trên gói dịch THẬT trong assets/."""
    global FAIL, N
    FAIL, N = [], 0
    idx = json.load(open(os.path.join(ASSETS, "i18n", "index.json"), encoding="utf-8"))
    total = idx["keys"]
    for code in LANGS[1:]:
        pack = json.load(open(os.path.join(ASSETS, "i18n", code + ".json"), encoding="utf-8"))
        tr = Translator(pack, mut)
        expect(f"I1 [{code}] số mục trong gói = index.json", len(pack) == idx["packs"][code], f"{len(pack)} vs {idx['packs'][code]}")
        bad_exact = [k for k, v in pack.items() if not PH.search(k) and tr.lookup(k) != v]
        expect(f"I2 [{code}] mọi khóa thường tra ra đúng bản dịch", not bad_exact, str(bad_exact[:3]))
        # mỗi MẪU sinh một chuỗi thử; phải ra đúng bản dịch của chính nó (không bị mẫu khác nuốt)
        shadow = []
        for k, v in pack.items():
            if not PH.search(k):
                continue
            sample = PH.sub(lambda m: "ZQ%s7" % m.group(1), k)
            want = PH.sub(lambda m: "ZQ%s7" % m.group(1), v)
            got = tr.lookup(sample)
            if got != want:
                shadow.append((k, got))
        expect(f"I3 [{code}] không mẫu nào bị mẫu khác nuốt ({sum(1 for k in pack if PH.search(k))} mẫu)", not shadow, str(shadow[:2]))
    en = Translator(json.load(open(os.path.join(ASSETS, "i18n", "en.json"), encoding="utf-8")), mut)
    expect("I4 chuỗi thật: 'Lớp (3)' ⇒ 'Layers (3)'", en.translate("Lớp (3)") == "Layers (3)", en.translate("Lớp (3)"))
    expect("I5 chuỗi thật: 'Credits còn lại: 12'", en.translate("Credits còn lại: 12") == "Credits left: 12", en.translate("Credits còn lại: 12"))
    expect("I6 chuỗi thật: 'Nhuộm Nâu' dịch cả màu ⇒ 'Dye Brown'", en.translate("Nhuộm Nâu") == "Dye Brown", en.translate("Nhuộm Nâu"))
    expect("I7 chuỗi thật: 'Hủy' có trong khóa ⇒ đã dịch", en.translate("Mở") == "Open")
    expect("I8 chữ người dùng gõ (không có trong gói) giữ nguyên", en.translate("ảnh của tôi") == "ảnh của tôi")
    expect("I9 số khóa trong index khớp ids.json", total == len(json.load(open(os.path.join(PROJ, "tools", "i18n", "ids.json"), encoding="utf-8"))["keys"]))
    # Trợ giúp: mọi ngôn ngữ cùng cấu trúc với tiếng Việt
    vi = json.load(open(os.path.join(ASSETS, "help", "vi.json"), encoding="utf-8"))
    shape = [len(s["items"]) for s in vi["sections"]]
    for code in LANGS[1:]:
        h = json.load(open(os.path.join(ASSETS, "help", code + ".json"), encoding="utf-8"))
        expect(f"I10 [{code}] Trợ giúp cùng cấu trúc với tiếng Việt", [len(s["items"]) for s in h["sections"]] == shape)
    return list(FAIL)


if __name__ == "__main__":
    ok = True
    f1, f2 = unit(), integration()
    print(f"Bản gốc: {len(f1)} + {len(f2)} thất bại")
    ok = not f1 and not f2
    for mut, what in (("no_sort", "bỏ sắp xếp mẫu theo độ dài phần cố định (mẫu ngắn nuốt mẫu cụ thể)"),
                      ("no_capture_translate", "không dịch phần trong chỗ trống")):
        failed = unit(mut) + integration(mut)
        print(f"  đột biến [{mut}] {what}: {'bị bắt ✓' if failed else 'KHÔNG bị bắt ✗'} ({len(failed)} khẳng định hỏng)")
        ok = ok and bool(failed)
    print()
    if not ok:
        print("THẤT BẠI")
        sys.exit(1)
    print("TẤT CẢ OK")
