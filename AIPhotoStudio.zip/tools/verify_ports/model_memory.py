#!/usr/bin/env python3
"""Bản port Python của engine/ModelMemory.kt + MemoryLedger (R32) để kiểm chứng LOGIC khi sandbox không có kotlinc.

Cùng hằng, cùng công thức, cùng thứ tự rẽ nhánh với bản Kotlin; các số khẳng định ở đây được chép nguyên sang
app/src/test/.../R32MemoryTest.kt. Có ĐỘT BIẾN: mỗi quy tắc quan trọng bị bẻ gãy thử, bài kiểm phải bắt được.
"""
import math
import sys

LOAD_FACTOR = 2.0
WORKING_MB = 256
RESERVE_FRACTION = 0.15
LEARN_MARGIN = 1.25
KILL_FACTOR = 1.5
MAX_KILLS = 2
KILL_TTL_MS = 7 * 24 * 60 * 60 * 1000
MIN_ESTIMATE_MB = 64


def estimate_mb(file_mb, learned_mb, kills, mut=None):
    k = min(max(kills, 0), MAX_KILLS) if mut != "no_kill_cap" else max(kills, 0)
    if learned_mb <= 0 and k == 0:
        return 0
    file = float(max(0, file_mb))
    formula = file * LOAD_FACTOR + WORKING_MB
    if learned_mb > 0:
        e = max(learned_mb * LEARN_MARGIN, file)
        if mut != "no_clamp":
            e = min(e, formula)
    else:
        e = formula
    for _ in range(k):
        e *= KILL_FACTOR
    return max(MIN_ESTIMATE_MB, int(math.ceil(e)))


def fits(est, avail_mb, total_mb, mut=None):
    if mut == "zero_blocks":
        return avail_mb - int(total_mb * RESERVE_FRACTION) >= est
    return est <= 0 or avail_mb - int(total_mb * RESERVE_FRACTION) >= est


class Ledger:
    def __init__(self, clock, mut=None):
        self.d = {}
        self.clock = clock
        self.mut = mut

    def learned(self, i):
        return self.d.get(f"mem.learned.{i}", 0)

    def kills(self, i):
        n = self.d.get(f"mem.kills.{i}", 0)
        if n <= 0:
            return 0
        at = self.d.get(f"mem.killAt.{i}")
        if at is None:
            return 0
        if self.mut == "no_ttl":
            return n
        return n if self.clock() - at <= KILL_TTL_MS else 0

    def recover(self):
        i = self.d.get("mem.loading", "")
        if i:
            self.d[f"mem.kills.{i}"] = self.kills(i) + 1
            self.d[f"mem.killAt.{i}"] = self.clock()
            self.d["mem.loading"] = ""

    def begin(self, i):
        self.d["mem.loading"] = i

    def end(self, i, measured):
        self.d["mem.loading"] = ""
        if self.mut != "keep_kills":
            self.d[f"mem.kills.{i}"] = 0
        if measured > 0:
            self.d[f"mem.learned.{i}"] = measured

    def abort(self):
        if self.mut == "abort_penalizes":
            self.d["mem.loading"] = self.d.get("mem.loading", "")  # để nguyên dấu ⇒ lần sau bị tính là bị giết
        else:
            self.d["mem.loading"] = ""


FAIL = []
N = 0


def expect(name, cond, detail=""):
    global N
    N += 1
    if not cond:
        FAIL.append(name)
        print(f"  ✗ {name} {detail}")


def suite(mut=None):
    """Chạy toàn bộ khẳng định; trả về danh sách khẳng định thất bại (để chạy đột biến)."""
    global FAIL, N
    FAIL, N = [], 0
    e = lambda f, l, k: estimate_mb(f, l, k, mut)
    ft = lambda es, a, t: fits(es, a, t, mut)
    # 1. chưa có bằng chứng ⇒ 0 và luôn cho qua (ngưỡng tay minRamMb vẫn áp ở Routing)
    expect("E1 chưa đo, chưa bị giết ⇒ ước lượng 0", e(555, 0, 0) == 0)
    expect("E2 ước lượng 0 ⇒ luôn vừa, kể cả RAM trống = 0", ft(0, 0, 4096))
    # 2. đã đo
    expect("E3 đã đo 900 MB, tệp 555 ⇒ 900×1,25 = 1125", e(555, 900, 0) == 1125, str(e(555, 900, 0)))
    expect("E4 số đo phình 5000 MB bị kẹp ở công thức tệp×2+256 = 1366 (không khóa vĩnh viễn)", e(555, 5000, 0) == 1366, str(e(555, 5000, 0)))
    expect("E5 số đo nhỏ vô lý 10 MB bị nâng lên bằng kích thước tệp 555", e(555, 10, 0) == 555, str(e(555, 10, 0)))
    # 3. bị giết
    expect("E6 bị giết 1 lần, chưa đo ⇒ (555×2+256)×1,5 = 2049", e(555, 0, 1) == 2049, str(e(555, 0, 1)))
    expect("E7 bị giết 2 lần ⇒ ×2,25 = 3074", e(555, 0, 2) == 3074, str(e(555, 0, 2)))
    expect("E8 bị giết 9 lần vẫn kẹp ở 2 lần (3074)", e(555, 0, 9) == 3074, str(e(555, 0, 9)))
    expect("E9 vừa có số đo vừa bị giết: 1125 × 1,5 = 1688", e(555, 900, 1) == 1688, str(e(555, 900, 1)))
    expect("E10 sàn tối thiểu 64 MB (tệp 0 MB, bị giết 1 lần ⇒ 256×1,5 = 384, không bị sàn nuốt)", e(0, 0, 1) == 384, str(e(0, 0, 1)))
    expect("E11 tệp âm / vô lý được coi là 0 MB: số đo 100 ⇒ 100×1,25 = 125", e(-5, 100, 0) == 125, str(e(-5, 100, 0)))
    expect("E12 sàn tối thiểu 64 MB: số đo 10 MB, tệp 0 ⇒ 13 được nâng lên 64", e(0, 10, 0) == 64, str(e(0, 10, 0)))
    # 4. quyết định vừa / không vừa: máy 4096 MB ⇒ chừa int(4096×0,15) = 614
    expect("F1 trống 3000, tổng 4096: dư 2386 ≥ 1366 ⇒ vừa", ft(1366, 3000, 4096))
    expect("F2 trống 1900, tổng 4096: dư 1286 < 1366 ⇒ không vừa", not ft(1366, 1900, 4096))
    expect("F3 đúng biên: trống 1980 ⇒ dư 1366 ≥ 1366 ⇒ vừa", ft(1366, 1980, 4096))
    expect("F4 trống 1979 ⇒ dư 1365 < 1366 ⇒ không vừa", not ft(1366, 1979, 4096))
    # 5. sổ ghi nhớ
    now = [1_000_000]
    L = Ledger(lambda: now[0], mut)
    expect("L1 chưa có gì: kills 0, learned 0", L.kills("gemma") == 0 and L.learned("gemma") == 0)
    L.begin("gemma")
    L.recover()  # mô phỏng: app chết rồi mở lại
    expect("L2 chết giữa lúc nạp ⇒ kills = 1", L.kills("gemma") == 1, str(L.kills("gemma")))
    expect("L3 dấu đã được xóa sau khi ghi nhận", L.d["mem.loading"] == "")
    L.recover()
    expect("L4 mở app lần nữa không chết ⇒ không tăng thêm", L.kills("gemma") == 1)
    L.begin("gemma")
    L.recover()
    expect("L5 chết lần hai ⇒ kills = 2", L.kills("gemma") == 2, str(L.kills("gemma")))
    now[0] += KILL_TTL_MS + 1
    expect("L6 sau 7 ngày bằng chứng hết hạn ⇒ kills = 0", L.kills("gemma") == 0, str(L.kills("gemma")))
    L.begin("gemma")
    L.recover()
    expect("L7 chết lần ba sau khi hết hạn ⇒ đếm lại từ 1", L.kills("gemma") == 1, str(L.kills("gemma")))
    L.begin("gemma")
    L.end("gemma", 800)
    expect("L8 nạp thành công ⇒ xóa đếm bị giết và ghi số đo", L.kills("gemma") == 0 and L.learned("gemma") == 800)
    L.begin("lama")
    L.abort()
    L.recover()
    expect("L9 nạp lỗi bằng ngoại lệ (abort) không bị tính là bị giết", L.kills("lama") == 0)
    L.begin("lama")
    L.end("lama", 0)
    expect("L10 số đo 0 không ghi đè số đo cũ", L.learned("lama") == 0)
    L.begin("isnet")
    L.end("isnet", 300)
    L.begin("isnet")
    L.end("isnet", 0)
    expect("L11 nạp lần sau đo 0 giữ nguyên 300", L.learned("isnet") == 300)
    expect("L12 sổ độc lập theo từng model", L.learned("gemma") == 800 and L.learned("isnet") == 300 and L.kills("isnet") == 0)
    return list(FAIL)


if __name__ == "__main__":
    base = suite()
    print(f"Bản gốc: {N} khẳng định, {len(base)} thất bại")
    ok = not base
    # ĐỘT BIẾN: mỗi bản bẻ gãy MỘT quy tắc, bài kiểm PHẢI thất bại
    for mut, what in (
        ("no_clamp", "bỏ kẹp số đo vào [tệp, công thức] (khóa vĩnh viễn)"),
        ("no_kill_cap", "bỏ trần số lần bị giết"),
        ("zero_blocks", "ước lượng 0 cũng bị chặn (hồi quy: chặn nhầm khi chưa có bằng chứng)"),
        ("no_ttl", "bỏ hạn 7 ngày của bằng chứng bị giết"),
        ("keep_kills", "nạp thành công không xóa đếm bị giết"),
        ("abort_penalizes", "ngoại lệ khi nạp bị tính là bị giết"),
    ):
        failed = suite(mut)
        caught = len(failed) > 0
        print(f"  đột biến [{mut}] {what}: {'bị bắt ✓' if caught else 'KHÔNG bị bắt ✗'} ({len(failed)} khẳng định hỏng)")
        ok = ok and caught
    print()
    if not ok:
        print("THẤT BẠI")
        sys.exit(1)
    print("TẤT CẢ OK")
