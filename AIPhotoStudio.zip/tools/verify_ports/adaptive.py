#!/usr/bin/env python3
"""
Kiểm tra cơ chế THÍCH NGHI thay cho ngưỡng viết cứng theo máy (R30f):
  engine/Adaptive.kt     - bộ điều khiển cạnh vào của model độ sâu theo thời gian chạy thật (nextEdge / afterFailure / snap)
  engine/ImageEngine.kt  - trần phóng ảnh suy từ heap còn trống (upscaleMaxSide)
Hằng số đọc TỪ mã Kotlin. Mô phỏng nhiều "máy" có tốc độ khác nhau theo ĐÚNG đường cong chi phí của ViT-S/14 (FLOPs), gồm cả máy NPU (46 ms ở 518: Galaxy S25 / ONNX, bảng của
Qualcomm AI Hub), máy CPU chậm, nhiễu thời gian, lần chạy đầu tốn thêm (biên dịch) và lỗi hết bộ nhớ, rồi kiểm:
  * hội tụ về cạnh lớn nhất còn trong ngân sách (không dưới 75 % cạnh tối ưu), ổn định (không dao động), không vượt biên [min, max];
  * lần chạy đầu không bị dùng để học (trừ khi quá chậm), lỗi bộ nhớ thì thu nhỏ dần và dừng;
  * mũ chi phí dùng trong mã (2,0 / 2,75) đúng là cận dưới / cận trên suy từ FLOPs;
  * trần phóng ảnh: đơn điệu theo heap, không vượt trần cứng, không nhỏ hơn ảnh vào, số điểm ảnh * byte <= heap * hệ số an toàn.
Đây là bản dịch Python của thuật toán Kotlin, KHÔNG phải chạy chính mã Kotlin.
Chạy: python3 tools/verify_ports/adaptive.py
"""
import math
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ENG = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio", "engine")
ad_src = open(os.path.join(ENG, "Adaptive.kt"), encoding="utf-8").read()
ie_src = open(os.path.join(ENG, "ImageEngine.kt"), encoding="utf-8").read()
de_src = open(os.path.join(ENG, "DepthEstimator.kt"), encoding="utf-8").read()


def const(src, name):
    m = re.search(r"const val " + name + r"\s*=\s*([0-9.]+)[fL]?", src)
    assert m, f"không thấy hằng số {name}"
    return float(m.group(1))


BUDGET = int(const(ad_src, "DEFAULT_BUDGET_MS"))
MIN_PATCHES = int(const(ad_src, "MIN_PATCHES"))
SHRINK_EXP, GROW_EXP = const(ad_src, "SHRINK_EXPONENT"), const(ad_src, "GROW_EXPONENT")
SHRINK_SAFETY, GROW_BELOW, GROW_TARGET = const(ad_src, "SHRINK_SAFETY"), const(ad_src, "GROW_BELOW"), const(ad_src, "GROW_TARGET")
MAX_GROW, FAIL_SHRINK, COLD_TOL = const(ad_src, "MAX_GROW"), const(ad_src, "FAIL_SHRINK"), const(ad_src, "COLD_TOLERANCE")
PATCH, LONG_EDGE = int(const(de_src, "PATCH")), int(const(de_src, "LONG_EDGE"))
HARD_MAX = int(const(ie_src, "UPSCALE_MAX_SIDE"))
BPP, SAFETY = const(ie_src, "UPSCALE_HEAP_BYTES_PER_PIXEL"), const(ie_src, "UPSCALE_HEAP_SAFETY")

fails = []


def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)


def round_half_up(x):
    return int(math.floor(x + 0.5))


# ------------------------------------------------------------------ bản dịch Kotlin: Adaptive
def snap(v, patch, lo, hi):
    return max(lo, min(hi, round_half_up(v / patch) * patch))


def next_edge(edge, elapsed, budget, lo, hi, patch, cold, _grow_exp=None, _shrink_exp=None, _max_grow=None):
    mg = MAX_GROW if _max_grow is None else _max_grow
    ge, se = (GROW_EXP if _grow_exp is None else _grow_exp), (SHRINK_EXP if _shrink_exp is None else _shrink_exp)
    e = max(lo, min(hi, edge))
    if elapsed <= 0 or budget <= 0:
        return e
    if cold and elapsed <= budget * COLD_TOL:
        return e
    ratio = budget / elapsed
    if elapsed > budget:
        return snap(e * ratio ** (1 / se) * SHRINK_SAFETY, patch, lo, e)
    if elapsed < budget * GROW_BELOW and e < hi:
        return snap(min(e * mg, e * (ratio * GROW_TARGET) ** (1 / ge)), patch, e, hi)
    return e


def after_failure(edge, lo, patch):
    if edge <= lo:
        return lo
    s = snap(edge * FAIL_SHRINK, patch, lo, edge)
    return max(lo, edge - patch) if s >= edge else s


# ------------------------------------------------------------------ đường cong chi phí thật của ViT-S/14 (nguồn của các mũ)
D, L = 384, 12


def flops(e):
    n = (e / PATCH) ** 2
    return L * (12 * n * D * D + 2 * n * n * D)


def local_exponent(e):
    n = (e / PATCH) ** 2
    a, b = 12 * D * D, 2 * D
    return 2 * (a * n + 2 * b * n * n) / (a * n + b * n * n)       # d ln F / d ln e


lo_edge, hi_edge = PATCH * MIN_PATCHES, LONG_EDGE
check("mũ chi phí THU NHỎ trong mã = 2.0 = cận dưới (phần tuyến tính theo số điểm ảnh)", abs(SHRINK_EXP - 2.0) < 1e-9)
check("mũ chi phí PHÓNG TO trong mã >= mũ cục bộ của ViT-S ở cạnh lớn nhất (%.3f) và không lớn hơn quá 0.05 (cận trên, suy từ FLOPs)" % local_exponent(hi_edge),
      local_exponent(hi_edge) <= GROW_EXP <= local_exponent(hi_edge) + 0.05, (GROW_EXP, local_exponent(hi_edge)))
check("mũ thực (FLOPs) giữa mọi cặp cạnh trong [min, max] nằm trong [SHRINK_EXP, GROW_EXP]",
      all(SHRINK_EXP - 1e-9 <= math.log(flops(b) / flops(a)) / math.log(b / a) <= GROW_EXP + 1e-9 for a in range(lo_edge, hi_edge, PATCH) for b in range(a + PATCH, hi_edge + 1, PATCH)))
check("MIN_PATCHES * PATCH và LONG_EDGE đều là bội của PATCH (không sinh cạnh lẻ)", lo_edge % PATCH == 0 and hi_edge % PATCH == 0)


# ------------------------------------------------------------------ mô phỏng thiết bị
def device(t_max_ms, noise=0.0, cold_extra=0.0, seed=0):
    """Thời gian một lần suy luận ở cạnh e = t_max * F(e)/F(max) * (1 ± nhiễu); lần chạy đầu tốn thêm cold_extra * t_max."""
    rnd = random.Random(seed)
    state = {"runs": 0}

    def run(e):
        t = t_max_ms * flops(e) / flops(hi_edge) * (1 + noise * (2 * rnd.random() - 1))
        if state["runs"] == 0:
            t += cold_extra
        state["runs"] += 1
        return t
    return run


def best_edge(t_max_ms, budget):
    """Cạnh lớn nhất (bội của PATCH, trong [min, max]) mà thời gian KHÔNG nhiễu vẫn trong ngân sách."""
    best = lo_edge
    for e in range(lo_edge, hi_edge + 1, PATCH):
        if t_max_ms * flops(e) / flops(hi_edge) <= budget:
            best = e
    return best


def converge(t_max_ms, runs=12, noise=0.0, cold_extra=0.0, start=None, seed=0):
    dev = device(t_max_ms, noise, cold_extra, seed)
    edge = hi_edge if start is None else start
    hist = []
    for k in range(runs):
        t = dev(edge)
        hist.append((edge, t))
        edge = next_edge(edge, t, BUDGET, lo_edge, hi_edge, PATCH, cold=(k == 0))
    return edge, hist


speeds = {"NPU Snapdragon 8 Elite (46 ms ở 518, ONNX, bảng AI Hub)": 46, "NPU Snapdragon 8 Gen 3 (60 ms)": 60, "NPU thế hệ cũ 80 ms": 80, "CPU mạnh 400 ms": 400, "CPU vừa 1500 ms": 1500, "CPU yếu 4000 ms": 4000,
          "CPU rất yếu 9000 ms": 9000, "CPU cực yếu 30000 ms": 30000}
for name, tm in speeds.items():
    final, hist = converge(tm)
    opt = best_edge(tm, BUDGET)
    steady = tm * flops(final) / flops(hi_edge)
    ok = lo_edge <= final <= hi_edge and final % PATCH == 0 and (steady <= BUDGET or final == lo_edge) and final >= 0.75 * opt
    check(f"hội tụ [{name}]: cạnh cuối {final} (tối ưu {opt}), thời gian ổn định {steady:.0f} ms <= {BUDGET}, không dưới 75 % tối ưu", ok, (final, opt, steady, hist[:6]))
    again = next_edge(final, steady, BUDGET, lo_edge, hi_edge, PATCH, cold=False)
    check(f"ổn định [{name}]: chạy thêm một lần không đổi cạnh (không dao động)", again == final, (final, again))

# nhiễu thời gian ±15 %: không dao động mạnh, ít khi vượt ngân sách sau khi hội tụ
bad = []
for name, tm in speeds.items():
    for seed in range(8):
        dev = device(tm, noise=0.15, seed=seed)
        edge = hi_edge
        tail = []
        over = 0
        for k in range(60):
            t = dev(edge)
            if k >= 20:
                tail.append(edge)
                over += t > BUDGET * 1.0001 and edge > lo_edge
            edge = next_edge(edge, t, BUDGET, lo_edge, hi_edge, PATCH, cold=(k == 0))
        if max(tail) > 1.3 * min(tail) or over > 0.2 * 40:
            bad.append((name, seed, min(tail), max(tail), over))
check("nhiễu ±15 %: sau khi hội tụ, cạnh dao động tối đa 30 % và vượt ngân sách <= 20 % số lần (7 loại máy x 8 hạt giống)", not bad, bad[:3])

# lần chạy đầu tốn thêm (biên dịch) — NPU: 15 s (AI Hub) khi nạp lần đầu
final_c, hist_c = converge(46, cold_extra=11200)
check("NPU + lần chạy đầu mất thêm 11,2 s (số tệ nhất của AI Hub): KHÔNG bị thu nhỏ vì lần đầu (<= 6 x ngân sách), cuối cùng giữ cạnh tối đa", final_c == hi_edge, hist_c[:3])
final_s, hist_s = converge(40000, cold_extra=0)
check("máy cực yếu: lần chạy đầu 40 s > 6 x ngân sách thì vẫn thu nhỏ ngay từ lần đầu", hist_s[1][0] < hi_edge, hist_s[:3])
check("hằng COLD_TOLERANCE phủ được lần nạp đầu tệ nhất đã công bố (11,2 s, Galaxy S25 float TFLite) với ngân sách mặc định (11200 <= COLD_TOL * budget)", 11200 <= COLD_TOL * BUDGET)
mut_final, mut_hist = None, None
dev = device(46, cold_extra=11200)
e = hi_edge
t0 = dev(e)
e_mut = next_edge(e, t0, BUDGET, lo_edge, hi_edge, PATCH, cold=False)      # đột biến: coi lần đầu như lần thường
check("đột biến: học từ lần chạy đầu (cold=False) -> NPU bị thu nhỏ oan, BỊ BẮT", e_mut < hi_edge, e_mut)

# bắt đầu từ cạnh nhỏ (đã nhớ từ lần trước, nhưng máy nhanh hơn / phiên bản mới nhanh hơn): phải lớn dần
final_g, hist_g = converge(100, start=lo_edge, runs=14)
check("bắt đầu ở cạnh tối thiểu trên máy nhanh: lớn dần, mỗi bước không quá MAX_GROW, tới cạnh tối ưu", final_g >= 0.75 * best_edge(100, BUDGET)
      and all(hist_g[i + 1][0] <= math.ceil(hist_g[i][0] * MAX_GROW) + PATCH for i in range(len(hist_g) - 1)), hist_g)
# BẤT BIẾN không vượt ngân sách khi phóng to: với mọi lần đo ngay dưới ngưỡng GROW_BELOW x ngân sách, cạnh mới dự đoán theo đường cong FLOPs THẬT vẫn trong ngân sách
def worst_growth_time(**kw):
    worst = 0.0
    for e in range(lo_edge, hi_edge, PATCH):
        for frac in (0.02, 0.1, 0.25, 0.4, GROW_BELOW - 1e-3):
            t = BUDGET * frac
            e2 = next_edge(e, t, BUDGET, lo_edge, hi_edge, PATCH, False, **kw)
            worst = max(worst, t * flops(e2) / flops(e) / BUDGET)       # tỉ lệ so với ngân sách sau khi phóng
    return worst


w_ok = worst_growth_time()
check("bất biến: sau khi PHÓNG TO, thời gian dự đoán (FLOPs thật) <= ngân sách với mọi cạnh / mọi lần đo dưới ngưỡng (tệ nhất %.2f x ngân sách; GROW_BELOW * MAX_GROW^GROW_EXP = %.2f < 1)"
      % (w_ok, GROW_BELOW * MAX_GROW ** GROW_EXP), w_ok <= 1.0 and GROW_BELOW * MAX_GROW ** GROW_EXP < 1.0, w_ok)
w_mut = worst_growth_time(_grow_exp=1.0, _max_grow=2.0)
check("đột biến: mũ phóng to 1.0 và MAX_GROW 2.0 -> vượt ngân sách (%.2f x), BỊ BẮT" % w_mut, w_mut > 1.0, w_mut)
# thu nhỏ đủ mạnh trong MỘT bước?
under = []
for tm in (2000, 4000, 9000, 30000):
    e1 = next_edge(hi_edge, tm, BUDGET, lo_edge, hi_edge, PATCH, False)
    if e1 > lo_edge and tm * flops(e1) / flops(hi_edge) > BUDGET:
        under.append((tm, e1, tm * flops(e1) / flops(hi_edge)))
check("thu nhỏ: với mũ cận dưới, MỘT bước đã đủ đưa thời gian về trong ngân sách (không cần chạy lại nhiều lần)", not under, under)

# lỗi hết bộ nhớ
e = hi_edge
chain = [e]
for _ in range(20):
    n = after_failure(e, lo_edge, PATCH)
    if n >= e:
        break
    e = n
    chain.append(e)
check("lỗi bộ nhớ: cạnh giảm NGHIÊM NGẶT từng bước tới mức tối thiểu rồi dừng (chuỗi %s)" % chain, all(chain[i] > chain[i + 1] for i in range(len(chain) - 1)) and chain[-1] == lo_edge)
check("lỗi bộ nhớ ở mức tối thiểu: giữ nguyên (không đi dưới tối thiểu)", after_failure(lo_edge, lo_edge, PATCH) == lo_edge and after_failure(lo_edge + PATCH, lo_edge, PATCH) == lo_edge)
check("mọi cạnh trong chuỗi lỗi là bội của PATCH", all(c % PATCH == 0 for c in chain))

# biên đầu vào
check("elapsed <= 0 hoặc budget <= 0: giữ nguyên", next_edge(300, 0, BUDGET, lo_edge, hi_edge, PATCH, False) == 300 and next_edge(300, 100, 0, lo_edge, hi_edge, PATCH, False) == 300)
check("cạnh ngoài biên được kẹp vào [min, max]", next_edge(9999, 1500, BUDGET, lo_edge, hi_edge, PATCH, False) <= hi_edge and next_edge(5, 1500, BUDGET, lo_edge, hi_edge, PATCH, False) >= lo_edge)
check("ở cạnh tối đa và rất nhanh: không vượt tối đa", next_edge(hi_edge, 1, BUDGET, lo_edge, hi_edge, PATCH, False) == hi_edge)
check("vùng trễ [GROW_BELOW x ngân sách, ngân sách]: giữ nguyên", all(next_edge(294, BUDGET * f, BUDGET, lo_edge, hi_edge, PATCH, False) == 294 for f in (GROW_BELOW + 0.01, 0.75, 1.0)))


# ------------------------------------------------------------------ trần phóng ảnh theo heap
def upscale_max_side(w, h, headroom):
    long_, short = max(w, h), max(1, min(w, h))
    if long_ <= 0:
        return HARD_MAX
    pixels = max(0, headroom) * SAFETY / BPP
    side = int(math.sqrt(pixels * long_ / short))
    return max(long_, min(HARD_MAX, side))


mb = 1024 * 1024
check("số byte / điểm ảnh = 5 mảng Int x 4 byte = 20 (src, a, b, tmp, out của sharpen + Blur.gaussian)", BPP == 5 * 4)
prev = 0
mono = True
for hm in range(0, 1200, 25):
    v = upscale_max_side(1536, 1152, hm * mb)
    mono &= v >= prev
    prev = v
check("trần theo heap ĐƠN ĐIỆU không giảm khi heap tăng", mono)
check("heap rất lớn: bằng trần cứng 4096; heap = 0 hoặc âm: bằng cạnh dài ảnh vào (không phóng)", upscale_max_side(1536, 1152, 1 << 40) == HARD_MAX and upscale_max_side(1536, 1152, 0) == 1536 and upscale_max_side(1536, 1152, -5) == 1536)
viol = []
for (w, h) in [(1536, 1152), (1152, 1536), (2000, 100), (100, 2000), (1000, 1000), (4096, 3072), (640, 480)]:
    for hm in (16, 48, 96, 150, 256, 512, 1024):
        side = upscale_max_side(w, h, hm * mb)
        long_, short = max(w, h), min(w, h)
        if side > long_:                                      # chỉ khi thực sự cho phóng
            out_pixels = side * (short * side / long_)
            if side > HARD_MAX or out_pixels * BPP > hm * mb * SAFETY * 1.002:
                viol.append((w, h, hm, side, out_pixels * BPP / mb))
        if side < long_ or side > HARD_MAX:
            viol.append((w, h, hm, side, "ngoài biên"))
check("trần phóng: không vượt trần cứng, không nhỏ hơn ảnh vào, điểm ảnh x byte <= heap x hệ số an toàn (7 cỡ x 7 mức heap)", not viol, viol[:3])
check("ví dụ: heap trống 150 MB, ảnh 1536x1152 -> cạnh dài tối đa ~2449 (không còn 4096 cứng gây hết bộ nhớ)", abs(upscale_max_side(1536, 1152, 150 * mb) - 2449) <= 60, upscale_max_side(1536, 1152, 150 * mb))
check("với trần cứng cũ 4096 ở heap 256 MB: 12,6 triệu điểm x 20 byte = 252 MB > heap -> trần cũ KHÔNG an toàn (lý do đổi)", 4096 * 3072 * BPP > 256 * mb * SAFETY)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
