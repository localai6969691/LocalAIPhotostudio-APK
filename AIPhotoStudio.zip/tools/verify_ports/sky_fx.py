#!/usr/bin/env python3
"""Port Python của engine/SkyFx.kt (R11): phát hiện bầu trời không cần model + thay bầu trời thủ tục.
Kiểm bằng các cảnh TỔNG HỢP có đáp án (IoU của mặt nạ, vật xanh dưới đất không bị lấy, ảnh không có trời, ...).
Cần numpy, scipy."""
import sys
from collections import deque
import numpy as np
from scipy.ndimage import uniform_filter, label

FAIL = []
SIDE = 320
CHROMA_GAIN = 0.35
MASK32 = 0xFFFFFFFF


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


def lum(r, g, b):
    return 0.299 * r + 0.587 * g + 0.114 * b


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def shrink(img):
    h, w, _ = img.shape
    f = max(1, (max(w, h) + SIDE - 1) // SIDE)
    sw, sh = max(1, w // f), max(1, h // f)
    return img[:sh * f, :sw * f].reshape(sh, f, sw, f, 3).mean(axis=(1, 3)) / 255.0


def box(a, rad):
    return uniform_filter(a, size=2 * rad + 1, mode="nearest") if rad >= 1 else a.copy()


def detect_small(sm, sens=0.5):
    sh, sw, _ = sm.shape
    r, g, b = sm[..., 0], sm[..., 1], sm[..., 2]
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    ls = box(lum, 1)
    grad = np.zeros_like(ls)
    for y in range(sh):
        yu, yd = max(0, y - 1), min(sh - 1, y + 1)
        for x in range(sw):
            xl, xr = max(0, x - 1), min(sw - 1, x + 1)
            gx = (ls[y, xr] - ls[y, xl]) / max(1, xr - xl)
            gy = (ls[yd, x] - ls[yu, x]) / max(1, yd - yu)
            grad[y, x] = np.hypot(gx, gy)
    gs = box(grad, 1)
    t_tex = 0.02 + 0.05 * sens
    step = 0.06 + 0.10 * sens
    mx = sm.max(axis=2)
    veg = (g > r * 1.08 + 0.02) & (g > b * 1.08 + 0.02)
    cand = (gs < t_tex) & (mx > 0.30) & (~veg)
    # xói mòn 1 điểm (4-lân cận; ngoài ảnh coi như ứng viên)
    pad = np.pad(cand, 1, constant_values=True)
    core = cand & pad[1:-1, :-2] & pad[1:-1, 2:] & pad[:-2, 1:-1] & pad[2:, 1:-1]
    region = np.zeros((sh, sw), bool)
    q = deque()
    seed_rows = max(1, int(sh * 0.04))
    seeds = 0
    for y in range(seed_rows):
        for x in range(sw):
            if core[y, x]:
                region[y, x] = True
                q.append((y, x))
                seeds += 1
    if seeds < 0.05 * sw:
        return None
    while q:
        y, x = q.popleft()
        for dy, dx in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            ny, nx = y + dy, x + dx
            if ny < 0 or nx < 0 or ny >= sh or nx >= sw or region[ny, nx] or not core[ny, nx]:
                continue
            if np.sqrt(((sm[y, x] - sm[ny, nx]) ** 2).sum()) >= step:
                continue
            region[ny, nx] = True
            q.append((ny, nx))
    # chỉ giữ các thành phần liên thông đủ lớn
    lab, ncomp = label(region)
    if ncomp > 0:
        sizes = np.bincount(lab.ravel())[1:]
        min_size = max(int(0.01 * sh * sw), int(0.15 * sizes.max()))
        keep = np.zeros(ncomp + 1, bool)
        keep[1:] = sizes >= min_size
        region = keep[lab]
    # nở lại 1 điểm trong tập ứng viên gốc
    rp = np.pad(region, 1, constant_values=False)
    near = rp[1:-1, :-2] | rp[1:-1, 2:] | rp[:-2, 1:-1] | rp[2:, 1:-1]
    region = region | (cand & near)
    outside = np.zeros((sh, sw), bool)
    q = deque()

    def seed(y, x):
        if not region[y, x] and not outside[y, x]:
            outside[y, x] = True
            q.append((y, x))

    for y in range(sh):
        seed(y, 0)
        seed(y, sw - 1)
    for x in range(sw):
        seed(sh - 1, x)
    while q:
        y, x = q.popleft()
        for dy, dx in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            ny, nx = y + dy, x + dx
            if ny < 0 or nx < 0 or ny >= sh or nx >= sw or region[ny, nx] or outside[ny, nx]:
                continue
            outside[ny, nx] = True
            q.append((ny, nx))
    region = region | (~outside)
    if region.sum() < 0.03 * sh * sw:
        return None
    return region


def sky_mask(img, sens=0.5):
    h, w, _ = img.shape
    out = np.zeros((h, w))
    if w < 8 or h < 8:
        return out
    sm = shrink(img)
    region = detect_small(sm, sens)
    if region is None:
        return out
    sh, sw = region.shape
    rv = region.astype(np.float64)
    ys = np.clip((np.arange(h) + 0.5) * sh / h - 0.5, 0, sh - 1)
    xs = np.clip((np.arange(w) + 0.5) * sw / w - 0.5, 0, sw - 1)
    y0 = ys.astype(int); y1 = np.minimum(sh - 1, y0 + 1); wy = (ys - y0)[:, None]
    x0 = xs.astype(int); x1 = np.minimum(sw - 1, x0 + 1); wx = (xs - x0)[None, :]
    t = ((rv[y0][:, x0] * (1 - wx) + rv[y0][:, x1] * wx) * (1 - wy) +
         (rv[y1][:, x0] * (1 - wx) + rv[y1][:, x1] * wx) * wy)
    m = smooth(0.35, 0.85, t)
    rad = max(1, int(round(max(w, h) * 0.003)))
    gray = np.floor(m * 255 + 0.5)
    for _ in range(3):
        gray = uniform_filter(gray, size=2 * rad + 1, mode="nearest")
    return np.clip(np.floor(gray + 1e-6), 0, 255) / 255.0   # Blur.gaussian trả số nguyên (kẹp để không dính sai số float âm)


# ---------------------------------------------------------------- bầu trời thủ tục
PRESETS = {
    "blue": ((36, 107, 206), (165, 208, 246), 0.40, (255, 255, 255), False),
    "sunset": ((58, 58, 128), (255, 153, 72), 0.45, (255, 196, 176), False),
    "dusk": ((22, 26, 70), (205, 112, 122), 0.30, (190, 130, 150), False),
    "overcast": ((148, 156, 168), (208, 213, 219), 0.65, (232, 235, 238), False),
    "night": ((3, 7, 24), (30, 44, 88), 0.0, (0, 0, 0), True),
}


def hash_(ix, iy, seed):
    ix = np.asarray(ix, dtype=np.int64); iy = np.asarray(iy, dtype=np.int64)
    h = (ix * 374761393 + iy * 668265263 + seed * 1274126177) & MASK32
    h = ((h ^ (h >> 13)) * 1274126177) & MASK32
    h = h ^ (h >> 16)
    return (h & 0xFFFFFF) / 16777215.0


def value_noise(x, y, seed):
    x0 = np.floor(x).astype(np.int64); y0 = np.floor(y).astype(np.int64)
    fx = x - x0; fy = y - y0
    sx = fx * fx * (3 - 2 * fx); sy = fy * fy * (3 - 2 * fy)
    a = hash_(x0, y0, seed); b = hash_(x0 + 1, y0, seed)
    c = hash_(x0, y0 + 1, seed); d = hash_(x0 + 1, y0 + 1, seed)
    return (a + (b - a) * sx) * (1 - sy) + (c + (d - c) * sx) * sy


def fbm(x, y, seed):
    amp, f, s, norm = 0.5, 1.0, 0.0, 0.0
    for o in range(4):
        s = s + amp * value_noise(x * f, y * f, seed + o)
        norm += amp
        amp *= 0.5
        f *= 2
    return s / norm


def render_sky(w, h, name, bottom):
    zen, hor, cover, cloud, stars = PRESETS[name]
    bm = max(1, bottom)
    yy, xx = np.mgrid[0:h, 0:w]
    tt = np.clip(yy / bm, 0, 1) ** 1.15
    u = xx / w
    v = yy / h
    out = np.zeros((h, w, 3))
    for c in range(3):
        out[..., c] = zen[c] + (hor[c] - zen[c]) * tt
    if cover > 0:
        n = fbm(u * 4, v * 2.4, 7)
        cl_ = smooth(1 - cover - 0.10, 1 - cover + 0.10, n) * 0.85 * (0.6 + 0.4 * (1 - tt))
        for c in range(3):
            out[..., c] = out[..., c] + (cloud[c] - out[..., c]) * cl_
    if stars:
        hv = hash_((u * 600).astype(np.int64), (v * 600).astype(np.int64), 99)
        s = np.where(hv > 0.9965, (hv - 0.9965) / 0.0035 * 255 * (1 - tt), 0.0)
        for c in range(3):
            out[..., c] += s
    return np.clip(np.floor(out + 0.5), 0, 255)


def _compose(img, sky_img, m, k, relight):
    """Trộn trời + tái chiếu sáng tiền cảnh — đúng công thức SkyFx.replaceUsing."""
    rl = float(np.clip(relight, 0, 1))
    dd = np.zeros(3)
    lum_factor = 1.0
    if rl > 0.005:
        sel = m > 0.5
        wsum = float(m[sel].sum())
        if wsum > 1.0:
            old = (img[sel] * m[sel][:, None]).sum(0) / wsum
            new = (sky_img[sel] * m[sel][:, None]).sum(0) / wsum
            d = new - old
            l = 0.299 * d[0] + 0.587 * d[1] + 0.114 * d[2]
            dd = (d - l) * CHROMA_GAIN
            lo = 0.299 * old[0] + 0.587 * old[1] + 0.114 * old[2]
            ln = 0.299 * new[0] + 0.587 * new[1] + 0.114 * new[2]
            lum_factor = float(np.clip(1.0 + 0.5 * (ln / max(lo, 1.0) - 1.0), 0.5, 1.3))
    a = (m * k)[..., None]
    fw = (rl * k * (1 - m))[..., None]
    out = img + (sky_img - img) * a
    adj = np.clip((out + dd) * lum_factor, 0, 255)
    out = out + (adj - out) * fw
    return np.clip(np.floor(out + 0.5), 0, 255), dd, lum_factor


def replace_sky(img, preset, intensity, relight=0.0, info=None):
    k = float(np.clip(intensity, 0, 1))
    if k <= 0.005:
        return img
    m = sky_mask(img)
    rows = np.where((m > 0.5).any(axis=1))[0]
    if rows.size == 0:
        return img
    sky = render_sky(img.shape[1], img.shape[0], preset, int(rows.max()))
    out, dd, lf = _compose(img, sky, m, k, relight)
    if info is not None:
        info.update(dd=dd, lum_factor=lf, mask=m)
    return out


def fit_cover(sky, w, h, bottom):
    sh, sw, _ = sky.shape
    region_h = max(1, bottom + 1)
    scale = max(w / sw, region_h / sh)
    ox = (w - sw * scale) / 2.0
    ys = np.clip((np.arange(h) + 0.5) / scale - 0.5, 0, sh - 1)
    xs = np.clip((np.arange(w) + 0.5 - ox) / scale - 0.5, 0, sw - 1)
    y0 = ys.astype(int); y1 = np.minimum(sh - 1, y0 + 1); wy = (ys - y0)[:, None, None]
    x0 = xs.astype(int); x1 = np.minimum(sw - 1, x0 + 1); wx = (xs - x0)[None, :, None]
    a = sky[y0][:, x0]; b = sky[y0][:, x1]; c = sky[y1][:, x0]; d = sky[y1][:, x1]
    top = a * (1 - wx) + b * wx
    bot = c * (1 - wx) + d * wx
    return np.clip(np.floor(top * (1 - wy) + bot * wy + 0.5), 0, 255)


def replace_sky_image(img, sky, intensity, relight=0.0):
    k = float(np.clip(intensity, 0, 1))
    if k <= 0.005 or sky.shape[0] < 2 or sky.shape[1] < 2:
        return img
    m = sky_mask(img)
    rows = np.where((m > 0.5).any(axis=1))[0]
    if rows.size == 0:
        return img
    fitted = fit_cover(sky, img.shape[1], img.shape[0], int(rows.max()))
    return _compose(img, fitted, m, k, relight)[0]


# ================================================================= cảnh tổng hợp
def blank(h=240, w=320):
    return np.zeros((h, w, 3))


def grad_sky(h, w, top, bot, y_end):
    img = np.zeros((h, w, 3))
    for y in range(y_end):
        t = y / max(1, y_end - 1)
        img[y] = np.array(top) * (1 - t) + np.array(bot) * t
    return img


def iou(a, b):
    inter = np.logical_and(a, b).sum()
    uni = np.logical_or(a, b).sum()
    return inter / max(1, uni)


def textured_ground(h0, h1, w, base, rng, amp=40):
    return np.clip(np.array(base) + rng.normal(0, amp, (h1 - h0, w, 3)), 0, 255)


def main():
    rng = np.random.default_rng(11)
    H, W = 240, 320

    # A. trời xanh chuyển sắc + đất xanh lá có kết cấu
    A = blank(H, W)
    A[:110] = grad_sky(110, W, (30, 90, 200), (170, 205, 240), 110)
    A[110:] = textured_ground(110, H, W, (50, 120, 45), rng)
    A = np.clip(A + rng.normal(0, 2, A.shape), 0, 255)
    truth = np.zeros((H, W), bool); truth[:110] = True
    mA = sky_mask(A)
    check("A trời xanh chuyển sắc / đất lục: IoU ≥ 0.93", iou(mA > 0.5, truth) >= 0.93, f"IoU={iou(mA>0.5, truth):.3f}")
    check("A: mặt nạ gần như 0 hẳn dưới đất (trung bình < 0.02)", mA[130:].mean() < 0.02, f"{mA[130:].mean():.4f}")

    # B. trời âm u xám-trắng + nhà nâu có kết cấu
    B = blank(H, W)
    B[:100] = np.array([205, 208, 212]) + np.linspace(-12, 12, 100)[:, None, None]
    B[100:] = textured_ground(100, H, W, (120, 85, 60), rng, amp=35)
    B = np.clip(B + rng.normal(0, 2.5, B.shape), 0, 255)
    truthB = np.zeros((H, W), bool); truthB[:100] = True
    mB = sky_mask(B)
    check("B trời âm u xám-trắng: IoU ≥ 0.9", iou(mB > 0.5, truthB) >= 0.9, f"IoU={iou(mB>0.5, truthB):.3f}")

    # C. hoàng hôn cam-hồng + bóng đen
    C = blank(H, W)
    C[:130] = grad_sky(130, W, (90, 70, 150), (255, 160, 80), 130)
    C[130:] = textured_ground(130, H, W, (25, 22, 28), rng, amp=10)
    truthC = np.zeros((H, W), bool); truthC[:130] = True
    mC = sky_mask(C)
    check("C hoàng hôn: IoU ≥ 0.88", iou(mC > 0.5, truthC) >= 0.88, f"IoU={iou(mC>0.5, truthC):.3f}")

    # D. trời có mây trắng mềm (kết cấu) — lỗ mây phải được điền
    D = blank(H, W)
    D[:120] = grad_sky(120, W, (40, 110, 210), (160, 200, 240), 120)
    yy, xx = np.mgrid[0:120, 0:W]
    for cx, cy, rx, ry in ((80, 40, 40, 14), (200, 70, 55, 18), (270, 30, 30, 10)):
        d = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2
        a = np.clip(1 - d, 0, 1)[..., None] ** 0.8
        n = rng.normal(0, 14, (120, W, 1)) * a
        D[:120] = D[:120] * (1 - a) + 250 * a + n
    D[120:] = textured_ground(120, H, W, (60, 110, 50), rng)
    D = np.clip(D, 0, 255)
    truthD = np.zeros((H, W), bool); truthD[:120] = True
    mD = sky_mask(D)
    check("D trời có mây kết cấu: IoU ≥ 0.9 (lỗ mây được điền)", iou(mD > 0.5, truthD) >= 0.9, f"IoU={iou(mD>0.5, truthD):.3f}")

    # E. không có trời (nội thất nhiều kết cấu)
    E = np.clip(rng.uniform(40, 200, (H, W, 3)), 0, 255)
    mE = sky_mask(E)
    check("E ảnh không có trời: mặt nạ ≈ 0 (< 1%)", mE.mean() < 0.01, f"{mE.mean():.4f}")

    # F. vật xanh nằm DƯỚI và không nối trời (xe xanh/tường xanh) không bị lấy
    F = A.copy()
    F[150:215, 40:150] = np.array([40, 90, 210]) + rng.normal(0, 2, (65, 110, 3))   # khối xanh phẳng, không chạm trời
    mF = sky_mask(F)
    check("F khối xanh phẳng bên dưới không bị coi là trời (< 2%)", (mF[150:215, 40:150] > 0.5).mean() < 0.02,
          f"{(mF[150:215, 40:150] > 0.5).mean():.4f}")
    check("F: vẫn lấy đúng trời phía trên (IoU ≥ 0.93)", iou(mF > 0.5, truth) >= 0.93, f"IoU={iou(mF>0.5, truth):.3f}")

    # G. tòa nhà cắt ngang trời (cao tới mép trên) — chỉ lấy phần trời còn lại
    G = A.copy()
    G[:, :120] = textured_ground(0, H, 120, (150, 140, 130), rng, amp=45)
    truthG = truth.copy(); truthG[:, :120] = False
    mG = sky_mask(G)
    check("G tòa nhà cắt trời: IoU ≥ 0.9", iou(mG > 0.5, truthG) >= 0.9, f"IoU={iou(mG>0.5, truthG):.3f}")
    check("G: phần tòa nhà không bị lấy (< 2%)", (mG[:, :110] > 0.5).mean() < 0.02, f"{(mG[:, :110] > 0.5).mean():.4f}")

    # J. cột điện thẳng đứng chia đôi trời: cả hai nửa vẫn được giữ (thành phần nào cũng đủ lớn)
    J = A.copy()
    J[:, 150:158] = np.clip(np.array([40, 35, 30]) + rng.normal(0, 25, (H, 8, 3)), 0, 255)
    truthJ = truth.copy(); truthJ[:, 150:158] = False
    mJ = sky_mask(J)
    check("J cột điện chia đôi trời: IoU ≥ 0.9 (giữ cả hai nửa)", iou(mJ > 0.5, truthJ) >= 0.9, f"IoU={iou(mJ>0.5, truthJ):.3f}")
    check("J: hai bên cột đều là trời", (mJ[40:80, 40:100] > 0.5).mean() > 0.95 and (mJ[40:80, 210:280] > 0.5).mean() > 0.95)

    # K. trời nhiễu cao (σ=6, như ảnh thiếu sáng nén JPEG)
    K = A.copy()
    K[:110] = np.clip(K[:110] + rng.normal(0, 6, (110, W, 3)), 0, 255)
    mK = sky_mask(K)
    check("K trời nhiễu σ=6: IoU ≥ 0.9", iou(mK > 0.5, truth) >= 0.9, f"IoU={iou(mK>0.5, truth):.3f}")

    # H. nhạy hơn → lấy được nhiều hơn hoặc bằng
    s_lo = (sky_mask(D, 0.1) > 0.5).sum()
    s_hi = (sky_mask(D, 0.9) > 0.5).sum()
    check("độ nhạy cao lấy ≥ vùng của độ nhạy thấp", s_hi >= s_lo, f"{s_lo} ≤ {s_hi}")

    # I. kích thước lớn hơn SIDE (shrink f>1) và không chia hết
    big = np.zeros((401, 667, 3))
    big[:180] = grad_sky(180, 667, (30, 90, 200), (170, 205, 240), 180)
    big[180:] = textured_ground(180, 401, 667, (50, 120, 45), rng)
    tb = np.zeros((401, 667), bool); tb[:180] = True
    mb = sky_mask(big)
    check("I ảnh 667×401 (không chia hết, f=3): IoU ≥ 0.93", iou(mb > 0.5, tb) >= 0.93, f"IoU={iou(mb>0.5, tb):.3f}")

    # ---- thay trời
    for name in PRESETS:
        R = replace_sky(A, name, 1.0)
        diff_ground = np.abs(R[135:] - A[135:]).max()
        check(f"thay trời '{name}': đất KHÔNG đổi (|Δ| ≤ 2)", diff_ground <= 2, f"max|Δ|={diff_ground:.1f}")
        sky_change = np.abs(R[:90] - A[:90]).mean()
        check(f"thay trời '{name}': vùng trời thay đổi rõ", sky_change > 8 or name == "blue", f"mean|Δ|={sky_change:.1f}")
    Rn = replace_sky(A, "night", 1.0)
    check("night: trời tối (độ chói trung bình < 60)", Rn[:90].mean() < 60, f"{Rn[:90].mean():.1f}")
    Rs = replace_sky(A, "sunset", 1.0)
    top_mean = Rs[:20].mean(axis=(0, 1)); bot_mean = Rs[85:100].mean(axis=(0, 1))
    check("sunset: chân trời ấm hơn thiên đỉnh (R−B tăng)", (bot_mean[0] - bot_mean[2]) > (top_mean[0] - top_mean[2]) + 60,
          f"đỉnh R−B={top_mean[0]-top_mean[2]:.0f}, chân trời={bot_mean[0]-bot_mean[2]:.0f}")
    half = replace_sky(A, "sunset", 0.5)
    full = replace_sky(A, "sunset", 1.0)
    mid = np.abs(half[:80] - A[:80]).mean()
    check("cường độ 0.5 nằm giữa 0 và 1", 0 < mid < np.abs(full[:80] - A[:80]).mean())
    check("cường độ 0 → không đổi", (replace_sky(A, "blue", 0.0) == A).all())
    check("ảnh không có trời → giữ nguyên", (replace_sky(E, "sunset", 1.0) == E).all())
    # xác định: gọi hai lần cho cùng kết quả
    check("kết quả tất định", (replace_sky(A, "dusk", 1.0) == replace_sky(A, "dusk", 1.0)).all())
    # viền: không còn viền xanh của trời cũ ngay sát đất (hàng 108..114, kênh B không vượt quá trời mới + đất)
    R = replace_sky(A, "sunset", 1.0)
    fringe = R[106:112, 20:300]
    blue_excess = (fringe[..., 2] - np.maximum(fringe[..., 0], fringe[..., 1])).clip(0).mean()
    check("viền sát đất không còn ám xanh của trời cũ (< 12)", blue_excess < 12, f"{blue_excess:.1f}")

    # ---- thay bằng ẢNH của người dùng
    # ảnh trời rộng 500x200: dải màu theo chiều dọc (đỏ trên → vàng dưới) và một cột đánh dấu xanh lục ở chính giữa ngang
    US = np.zeros((200, 500, 3))
    for y in range(200):
        US[y] = np.array([220.0, 60.0 + 0.8 * y, 80.0])
    US[:, 248:252] = np.array([0.0, 255.0, 0.0])
    R = replace_sky_image(A, US, 1.0)
    check("ảnh trời riêng: đất KHÔNG đổi (|Δ| ≤ 2)", np.abs(R[135:] - A[135:]).max() <= 2, f"{np.abs(R[135:] - A[135:]).max():.1f}")
    row = R[20, :, :]
    check("ảnh trời riêng: cột đánh dấu nằm đúng GIỮA khung (cắt giữa theo chiều ngang)",
          row[160 - 4:160 + 4, 1].max() > 200 and row[10, 1] < 150 and row[:, 1].argmax() in range(155, 165),
          f"đỉnh G ở cột {row[:, 1].argmax()} (mong đợi ~160), G giữa={row[160-4:160+4,1].max():.0f}, mép G={row[10,1]:.0f}")
    check("ảnh trời riêng: căn MÉP TRÊN (đỉnh khung ≈ đỉnh ảnh trời: R≈220, G thấp)", abs(R[1, 10, 0] - 220) < 12 and R[1, 10, 1] < 90, str(R[1, 10]))
    sky_px = R[:90, 20:140]
    check("ảnh trời riêng: vùng trời được phủ kín bằng màu ảnh (không còn xanh của trời cũ: B < 140)", sky_px[..., 2].max() < 140, f"{sky_px[..., 2].max():.0f}")
    small = np.full((8, 8, 3), 200.0)
    Rs = replace_sky_image(A, small, 1.0)
    check("ảnh trời nhỏ hơn vùng trời vẫn được phóng kín (cover), không còn lỗ", np.abs(Rs[:90, 20:300] - 200).max() <= 3, f"{np.abs(Rs[:90, 20:300] - 200).max():.1f}")
    tall = np.zeros((600, 100, 3)); tall[:] = np.array([30.0, 200.0, 90.0])
    Rt = replace_sky_image(A, tall, 1.0)
    check("ảnh trời cao hẹp (chân dung): vẫn phủ kín bề ngang", np.abs(Rt[:90, 20:300] - np.array([30.0, 200.0, 90.0])).max() <= 3)
    check("ảnh trời riêng: cường độ 0 → không đổi", (replace_sky_image(A, US, 0.0) == A).all())
    check("ảnh không có trời + ảnh trời riêng → giữ nguyên", (replace_sky_image(E, US, 1.0) == E).all())
    check("ảnh trời riêng 1x1 → bỏ qua (giữ nguyên)", (replace_sky_image(A, np.zeros((1, 1, 3)), 1.0) == A).all())
    check("ảnh trời riêng: cường độ 0.5 nằm giữa", 0 < np.abs(replace_sky_image(A, US, 0.5)[:80] - A[:80]).mean() < np.abs(R[:80] - A[:80]).mean())

    # ---- tái chiếu sáng tiền cảnh (R13)
    base = replace_sky(A, "sunset", 1.0)
    check("relight=0 → kết quả y hệt bản không relight", (replace_sky(A, "sunset", 1.0, 0.0) == base).all())
    info = {}
    rel = replace_sky(A, "sunset", 1.0, 1.0, info)
    m_full = info["mask"] > 0.99
    check("relight không đụng vùng trời (mask > 0.99 giữ nguyên)", np.abs(rel - base)[m_full].max() <= 1, f"{np.abs(rel - base)[m_full].max():.1f}")
    g0, g1 = base[140:], rel[140:]
    rb = lambda x: (x[..., 0] - x[..., 2]).mean()
    check("hoàng hôn + relight: đất ấm lên vừa phải (R−B tăng 8..90, không thành cam rực)", 8 < rb(g1) - rb(g0) < 90, f"R−B {rb(g0):.1f} → {rb(g1):.1f}")
    lum_m = lambda x: lum(x[..., 0], x[..., 1], x[..., 2]).mean()
    ratio = lum_m(g1) / lum_m(g0)
    check("độ sáng đất đổi đúng hệ số công thức (±4%)", abs(ratio - info["lum_factor"]) < 0.04, f"tỉ lệ {ratio:.3f} vs hệ số {info['lum_factor']:.3f}")
    info_n = {}
    night = replace_sky(A, "night", 1.0, 1.0, info_n)
    nr = lum_m(night[140:]) / lum_m(replace_sky(A, "night", 1.0)[140:])
    check("trời đêm + relight: đất TỐI đi rõ (tỉ lệ < 0.7)", nr < 0.7, f"{nr:.2f}")
    info_b = {}
    same = replace_sky(A, "blue", 1.0, 1.0, info_b)
    br_ = lum_m(same[140:]) / lum_m(replace_sky(A, "blue", 1.0)[140:])
    check("thay trời xanh bằng trời xanh + relight: đất gần như không đổi (độ sáng 0.9..1.15)", 0.9 <= br_ <= 1.15, f"{br_:.2f}")
    half = replace_sky(A, "sunset", 1.0, 0.5)
    e0 = np.abs(base[140:] - base[140:]).mean(); e_h = np.abs(half[140:] - base[140:]).mean(); e_f = np.abs(rel[140:] - base[140:]).mean()
    check("relight 0.5 nằm giữa 0 và 1", 0 < e_h < e_f, f"0 < {e_h:.2f} < {e_f:.2f}")
    qk = replace_sky(A, "sunset", 0.5, 1.0)
    check("cường độ thay trời 0.5 làm yếu cả relight", np.abs(qk[140:] - A[140:]).mean() < np.abs(rel[140:] - A[140:]).mean())
    check("ảnh không có trời + relight → giữ nguyên", (replace_sky(E, "sunset", 1.0, 1.0) == E).all())
    ri = replace_sky_image(A, US, 1.0, 1.0)
    check("ảnh trời riêng + relight: đất đổi nhẹ theo màu ảnh trời (R−B tăng vì ảnh trời đỏ/vàng)", rb(ri[140:]) > rb(replace_sky_image(A, US, 1.0)[140:]) + 5)
    check("ảnh trời riêng: relight=0 y hệt", (replace_sky_image(A, US, 1.0, 0.0) == replace_sky_image(A, US, 1.0)).all())

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
