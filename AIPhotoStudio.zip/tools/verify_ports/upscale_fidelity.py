#!/usr/bin/env python3
"""R51 - bản port Python của engine/UpscaleFidelity.kt (CÙNG thuật toán, CÙNG phép làm tròn số nguyên).

Hai bước chạy SAU khi Real-ESRGAN dựng xong ảnh ra (SR), với ảnh vào của model (LR) làm chuẩn:
  1) HIỆU CHỈNH NHẤT QUÁN (back-projection): thu nhỏ SR bằng trung bình ô k×k, lấy phần dư so với LR, phóng phần dư bằng song tuyến tính rồi cộng vào SR. Lặp 2 lần.
     => màu, hình khối khớp ảnh gốc; chỉ phần chi tiết nhỏ do AI sinh.
  2) THANH "ĐỘ TRUNG THỰC" alpha: trộn (1-alpha)*SR + alpha*bicubic(LR) (bicubic = Catmull-Rom a=-0.5, biên kẹp).
Giá trị 0..255 nguyên, làm tròn mỗi bước đúng như mã Kotlin (IntArray).
"""
import math
import numpy as np

ITER = 2
DEFAULT = 0.15
MAX_BLEND = 0.6


def clamp_fid(f):
    if f != f:
        return DEFAULT
    return min(max(f, 0.0), MAX_BLEND)


def ratio(out_w, out_h, lr_w, lr_h):
    if lr_w <= 0 or lr_h <= 0 or out_w % lr_w or out_h % lr_h:
        return 0
    kx, ky = out_w // lr_w, out_h // lr_h
    return kx if (kx == ky and kx >= 2) else 0


def _bil_tables(n_out, n_in, k):
    fx = (np.arange(n_out) + 0.5) / k - 0.5
    x0 = np.floor(fx).astype(np.int64)
    t = (fx - x0).astype(np.float32)
    a = np.clip(x0, 0, n_in - 1)
    b = np.clip(x0 + 1, 0, n_in - 1)
    return a, b, t


def back_project_once(out, lr, k):
    """out: (H,W,3) uint8-int; lr: (h,w,3). Trả mảng mới."""
    H, W, _ = out.shape
    h, w, _ = lr.shape
    mean = out.astype(np.float32).reshape(h, k, w, k, 3).mean(axis=(1, 3), dtype=np.float32)
    res = lr.astype(np.float32) - mean                         # (h,w,3)
    ya, yb, ty = _bil_tables(H, h, k)
    xa, xb, tx = _bil_tables(W, w, k)
    top = res[ya][:, xa] * (1 - tx)[None, :, None] + res[ya][:, xb] * tx[None, :, None]
    bot = res[yb][:, xa] * (1 - tx)[None, :, None] + res[yb][:, xb] * tx[None, :, None]
    up = top * (1 - ty)[:, None, None] + bot * ty[:, None, None]
    v = out.astype(np.float32) + up
    return np.clip(np.floor(v + 0.5), 0, 255).astype(np.int64)


def _cr_weights(t):
    t2, t3 = t * t, t * t * t
    return (-0.5 * t3 + t2 - 0.5 * t, 1.5 * t3 - 2.5 * t2 + 1.0, -1.5 * t3 + 2.0 * t2 + 0.5 * t, 0.5 * t3 - 0.5 * t2)


def bicubic(lr, k):
    h, w, _ = lr.shape
    H, W = h * k, w * k
    lrf = lr.astype(np.float32)

    def axis(n_out, n_in):
        fx = (np.arange(n_out) + 0.5) / k - 0.5
        x0 = np.floor(fx).astype(np.int64)
        t = (fx - x0).astype(np.float32)
        idx = [np.clip(x0 + d, 0, n_in - 1) for d in (-1, 0, 1, 2)]
        return idx, _cr_weights(t)

    xi, xw = axis(W, w)
    yi, yw = axis(H, h)
    hor = sum(lrf[:, xi[j]] * xw[j][None, :, None] for j in range(4))          # (h,W,3)
    ver = sum(hor[yi[j]] * yw[j][:, None, None] for j in range(4))              # (H,W,3)
    return ver


def refine(out, lr, fidelity, iterations=ITER):
    H, W, _ = out.shape
    h, w, _ = lr.shape
    k = ratio(W, H, w, h)
    if k == 0:
        return out
    x = out.astype(np.int64)
    for _ in range(iterations):
        x = back_project_once(x, lr, k)
    a = clamp_fid(fidelity)
    if a > 0:
        bic = bicubic(lr, k)
        v = (1 - a) * x.astype(np.float32) + a * bic
        x = np.clip(np.floor(v + 0.5), 0, 255).astype(np.int64)
    return x


def synth(lr_w=6, lr_h=5, k=4):
    """Ảnh thử xác định bằng công thức số nguyên (Kotlin dùng đúng công thức này)."""
    lr = np.zeros((lr_h, lr_w, 3), np.int64)
    for y in range(lr_h):
        for x in range(lr_w):
            lr[y, x, 0] = (x * 53 + y * 97 + x * y * 7) % 256
            lr[y, x, 1] = (x * 29 + y * 61 + 40) % 256
            lr[y, x, 2] = (x * 11 + y * 131 + x * y * 3 + 90) % 256
    H, W = lr_h * k, lr_w * k
    sr = np.zeros((H, W, 3), np.int64)
    for y in range(H):
        for x in range(W):
            sr[y, x, 0] = (x * 31 + y * 17 + ((x * y) % 13) * 11) % 256
            sr[y, x, 1] = (x * 7 + y * 43 + ((x + y) % 5) * 23) % 256
            sr[y, x, 2] = (x * 19 + y * 5 + ((x * 3 + y) % 7) * 17) % 256
    return lr, sr


if __name__ == "__main__":
    lr, sr = synth()
    for f in (0.0, 0.15, 0.6):
        r = refine(sr, lr, f)
        print(f"fid={f}: sum={int(r.sum())} px(0,0)={r[0,0].tolist()} px(7,9)={r[7,9].tolist()} px(19,23)={r[19,23].tolist()}")
