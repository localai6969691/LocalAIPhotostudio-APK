#!/usr/bin/env python3
"""Port Python của PHẦN luật tông/chi tiết trong RuleBasedPlanner.processClause (đoạn "Tông / chi tiết" + luật R11 mới).
Mục đích: bắt xung đột từ khóa giữa luật mới (Vùng sáng, Vibrance, Tint, Dehaze, Texture) và luật cũ (độ sáng, bão hòa, mịn da...).
Không port các preset/nền/hình học — chỉ đoạn liên quan. Lệch với Kotlin thì sửa cả hai."""
import re
import sys
import unicodedata

FAIL = []

STRONG = ["rat!", "manh!", "nhieu!", "cuc!", "very!", "strong", "much!", "heavy", "max!"]
WEAK = ["nhe!", "chut!", "hoi!", "slight", "little!", "bit!", "subtle"]


def rx(key):
    exact = key.endswith("!")
    body = re.escape(key[:-1] if exact else key)
    return re.compile(r"(?<![a-z0-9])" + body + (r"(?![a-z0-9])" if exact else ""))


class Clause:
    def __init__(self, text):
        self.text = text

    def has(self, *keys):
        return any(rx(k).search(self.text) for k in keys)

    def take(self, *keys):
        found = False
        for k in keys:
            r = rx(k)
            if r.search(self.text):
                found = True
                self.text = r.sub(" ", self.text)
        return found


def normalize(s):
    s = unicodedata.normalize("NFD", s)
    s = re.sub(r"[\u0300-\u036f]+", "", s).replace("đ", "d")
    s = re.sub(r"[^a-z0-9%:/&\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def intensity(t):
    if any(rx(k).search(t) for k in STRONG):
        return 1.6
    if any(rx(k).search(t) for k in WEAK):
        return 0.5
    return 1.0


def process_clause(t, out):
    c = Clause(t)
    k = intensity(t)
    m = re.search(r"(\d{1,3})\s*%", t)
    pct = int(m.group(1)) / 100 if m else None

    def mag(d):
        return pct if pct is not None else d * k

    def add(typ, v, arg=None):
        out.append((typ, round(v, 3), arg))

    def signed(typ, d, negative):
        add(typ, -mag(d) if negative else mag(d))

    reduce_ = c.has("giam", "bot!", "thap", "less!", "reduce", "lower", "decrease", "bo bot", "qua!", "too!", "ha!")

    # --- thay bầu trời (Kotlin: đặt trước nhóm Phông / nền, tức trước toàn bộ phần tông)
    if c.take("thay bau troi", "doi bau troi", "replace sky", "change sky", "sky replacement", "bau troi moi"):
        if c.has("hoang hon", "sunset", "binh minh", "sunrise", "cam!"):
            sky = "sunset"
        elif c.has("chang vang", "dusk", "twilight", "tim!"):
            sky = "dusk"
        elif c.has("am u", "overcast", "xam!", "may mu", "cloudy"):
            sky = "overcast"
        elif c.has("dem!", "night", "sao!", "star"):
            sky = "night"
        else:
            sky = "blue"
        add("SKY_REPLACE", 1.0, sky)
        c.take("hoang hon", "sunset", "binh minh", "sunrise", "chang vang", "dusk", "twilight", "am u", "overcast",
               "may mu", "cloudy", "dem!", "night", "sao!", "star", "xanh duong", "xanh!", "blue")
    # --- đoạn nguyên văn từ Kotlin (tông / chi tiết)
    if c.take("vung toi", "shadow", "vung bong"):
        add("SHADOWS", mag(0.5), "reduce" if reduce_ else None)
        c.take("sang", "lighten", "bright")
    # --- R13: khớp ánh sáng tiền cảnh (Kotlin: đặt ngay trước khối R12)
    if c.take("khop anh sang", "tai chieu sang", "relight", "anh sang tien canh"):
        add("SKY_RELIGHT", mag(0.6))
    # --- R12: bụi / vết xước (Kotlin: đặt ngay trước khối R11)
    if c.take("xoa bui", "loai bo bui", "sach bui", "bui ban", "bui!", "dust", "vet xuoc", "xuoc!", "scratch"):
        add("DUST", mag(0.5))
    # --- R11
    if c.take("them suong", "tao suong", "add haze", "add fog", "foggy"):
        add("DEHAZE", -mag(0.5))
    elif c.take("khu suong", "bot suong", "het suong", "xuyen suong", "mo suong", "phu suong", "mu suong", "suong mu", "suong!", "hazy", "dehaze", "de haze", "remove haze", "remove fog", "haze!", "fog!"):
        add("DEHAZE", mag(0.6))
    if c.take("chay sang", "blown", "overexposed", "cuu vung sang", "recover highlight"):
        add("HIGHLIGHTS", -mag(0.6))
    elif c.take("vung sang", "highlight", "phan sang"):
        signed("HIGHLIGHTS", 0.45, reduce_)
    if c.take("vibrance", "mau thong minh", "smart saturation", "mau tu nhien", "natural saturation"):
        signed("VIBRANCE", 0.4, reduce_)
    tint_green = c.take("green tint", "tint xanh la", "tint luc", "sac luc", "ngam luc")
    tint_magenta = c.take("magenta", "tint tim", "tint hong", "sac tim", "ngam tim", "pink tint", "purple tint")
    if tint_green or tint_magenta:
        signed("TINT", 0.35, tint_green != reduce_)
    smoothish = c.has("lam min", "min!", "smooth", "mem mai", "soft")
    if c.take("ket cau", "texture", "cau truc", "structure"):
        signed("TEXTURE", 0.4, reduce_ or smoothish)
        if smoothish and not c.has("da!", "skin", "mat!", "face"):
            c.take("lam min", "min!", "smooth", "mem mai", "soft")
    # --- tiếp luật cũ
    if c.take("tu dong", "auto", "cai thien", "enhance", "toi uu", "lam ro"):
        add("AUTO_ENHANCE", mag(0.8))
    if c.take("da min", "min da", "min!", "lam min", "smooth", "mun", "skin", "lam tron da", "tri mun"):
        add("SKIN_SMOOTH", mag(0.55), "reduce" if reduce_ else None)
    if c.take("lam net", "net hon", "sac net", "sharp", "chi tiet", "detail", "clarity", "net!", "sac!"):
        add("BLUR", mag(0.3)) if reduce_ else add("SHARPEN", mag(0.5))
    if c.take("tuong phan", "contrast"):
        signed("CONTRAST", 0.2, reduce_)
    sat_neg = c.take("nhat mau", "desaturat", "bot mau", "muted")
    sat_pos = c.take("bao hoa", "saturat", "ruc ro", "sinh dong", "vibrant", "vivid", "mau sac",
                     "colorful", "dam mau", "tuoi!", "tuoi tan", "mau!")
    if sat_neg or sat_pos:
        signed("SATURATION", 0.25, sat_neg or reduce_)
    warm_neg = c.take("lanh", "cool", "cold", "tong mat", "lam mat", "blue tone")
    warm_pos = c.take("am ap", "tong am", "am!", "warm", "golden", "hoang hon", "sunset", "nang!")
    if warm_neg or warm_pos:
        signed("WARMTH", 0.3, warm_neg or reduce_)
    dark = c.take("toi!", "dark", "dim", "darken")
    bright = c.take("sang", "bright", "lighten", "exposure")
    if dark or bright:
        negative = (not reduce_) if (dark and not bright) else reduce_
        signed("BRIGHTNESS", 0.18, negative)


def plan(prompt):
    raw = unicodedata.normalize("NFC", prompt.lower()).replace("nâng", "tăng")
    parts = re.split(r"[,;.!?\n]+|\s+(?:và|and|rồi|then|với|kèm|đồng thời|also)\s+", raw)
    ops = []
    for p in parts:
        n = normalize(p)
        if not n:
            continue
        c = Clause(n)
        # processScoped: sợi tóc lạc -> DUST trên DA và NỀN (đặt trước nhánh "tóc")
        if c.has("soi toc lac", "soi toc thua", "toc bay", "stray hair", "flyaway", "loose hair"):
            ops.append(("SCOPED_DUST_SKIN", 0.8, None)); ops.append(("SCOPED_DUST_BG", 0.8, None))
            continue
        # processScoped: nhánh "Bầu trời" — nhường cho processClause khi là "thay/đổi bầu trời"
        if c.has("bau troi", "sky!") and not c.has("thay bau troi", "doi bau troi", "replace sky", "change sky", "sky replacement", "bau troi moi"):
            ops.append(("SCOPED_SKY", 1.0, None))
            continue
        process_clause(n, ops)
    return ops


def kinds(ops):
    return [(t, round(v, 2)) for t, v, a in ops]


def expect(prompt, pred, desc):
    ops = plan(prompt)
    ok = pred(ops)
    print(("OK   " if ok else "FAIL ") + f"{prompt!r:52} -> {kinds(ops)}  [{desc}]")
    if not ok:
        FAIL.append(prompt)


def has(ops, typ, sign=None):
    for t, v, a in ops:
        if t == typ and (sign is None or (v > 0) == (sign > 0)):
            return True
    return False


def only(ops, *types):
    return {t for t, _, _ in ops} == set(types)


def main():
    # Vùng sáng
    expect("giảm vùng sáng", lambda o: has(o, "HIGHLIGHTS", -1) and not has(o, "BRIGHTNESS"), "recover, KHÔNG đụng độ sáng chung")
    expect("tăng vùng sáng", lambda o: has(o, "HIGHLIGHTS", +1) and not has(o, "BRIGHTNESS"), "dương")
    expect("recover highlights", lambda o: has(o, "HIGHLIGHTS", -1), "EN")
    expect("ảnh bị cháy sáng", lambda o: has(o, "HIGHLIGHTS", -1) and not has(o, "BRIGHTNESS"), "cháy sáng → cứu")
    expect("giảm highlight", lambda o: has(o, "HIGHLIGHTS", -1), "EN giảm")
    expect("làm sáng vùng tối", lambda o: has(o, "SHADOWS") and not has(o, "HIGHLIGHTS") and not has(o, "BRIGHTNESS"), "luật cũ vùng tối vẫn đúng")
    expect("hạ vùng sáng, nâng vùng tối", lambda o: has(o, "HIGHLIGHTS", -1) and has(o, "SHADOWS", +1) and not has(o, "WARMTH"),
           "'hạ' = giảm; 'nâng' (raise) KHÔNG được thành tông ấm (nắng)")
    expect("nâng vùng tối", lambda o: only(o, "SHADOWS"), "lỗi cũ: 'nâng' trùng 'nắng' → WARMTH")
    expect("tăng nắng", lambda o: has(o, "WARMTH", +1), "'nắng' vẫn ra tông ấm")
    expect("hạ độ sáng", lambda o: has(o, "BRIGHTNESS", -1), "'hạ' = giảm cho cả độ sáng")
    # Dehaze
    expect("khử sương mù", lambda o: has(o, "DEHAZE", +1) and len(o) == 1, "dương")
    expect("giảm sương mù", lambda o: has(o, "DEHAZE", +1), "'giảm sương mù' = khử sương (dương), không phải thêm")
    expect("thêm sương mù", lambda o: has(o, "DEHAZE", -1), "âm")
    expect("dehaze mạnh", lambda o: has(o, "DEHAZE", +1) and [v for t, v, _ in o if t == "DEHAZE"][0] > 0.8, "cường độ 'mạnh'")
    expect("remove haze", lambda o: has(o, "DEHAZE", +1), "EN")
    # Vibrance
    expect("tăng vibrance", lambda o: only(o, "VIBRANCE") and has(o, "VIBRANCE", +1), "dương, KHÔNG thành SATURATION")
    expect("màu tự nhiên hơn", lambda o: has(o, "VIBRANCE", +1) and not has(o, "SATURATION"), "mau tu nhien")
    expect("giảm vibrance", lambda o: has(o, "VIBRANCE", -1), "âm")
    expect("ảnh bị mờ sương", lambda o: only(o, "DEHAZE") and has(o, "DEHAZE", +1), "'mờ sương' → khử sương, KHÔNG làm mờ ảnh")
    expect("phủ sương mù, hơi xám", lambda o: has(o, "DEHAZE", +1), "phủ sương")
    expect("tăng bão hòa", lambda o: has(o, "SATURATION", +1) and not has(o, "VIBRANCE"), "luật cũ không bị ảnh hưởng")
    # Tint
    expect("thêm magenta", lambda o: has(o, "TINT", +1), "ngả tím")
    expect("green tint", lambda o: has(o, "TINT", -1), "ngả xanh lá")
    expect("giảm tint tím", lambda o: has(o, "TINT", -1), "giảm tím → âm")
    expect("giảm sắc lục", lambda o: has(o, "TINT", +1), "giảm lục → dương (bớt xanh lá)")
    # Texture
    expect("tăng kết cấu", lambda o: only(o, "TEXTURE") and has(o, "TEXTURE", +1), "dương")
    expect("giảm texture", lambda o: has(o, "TEXTURE", -1), "âm")
    expect("làm mịn kết cấu", lambda o: only(o, "TEXTURE") and has(o, "TEXTURE", -1), "mịn → âm, KHÔNG kèm làm mịn da")
    expect("làm mịn kết cấu da", lambda o: has(o, "TEXTURE", -1) and has(o, "SKIN_SMOOTH"), "nhắc 'da' → giữ cả hai")
    expect("tăng cấu trúc ảnh", lambda o: has(o, "TEXTURE", +1), "cấu trúc")
    expect("làm nét", lambda o: has(o, "SHARPEN") and not has(o, "TEXTURE"), "luật cũ không bị ảnh hưởng")
    # Kết hợp thực tế
    expect("ảnh phong cảnh bị mờ sương, tăng vibrance và giảm vùng sáng",
           lambda o: has(o, "DEHAZE", +1) and has(o, "VIBRANCE", +1) and has(o, "HIGHLIGHTS", -1), "3 phép")
    expect("tăng sáng, tông ấm", lambda o: has(o, "BRIGHTNESS", +1) and has(o, "WARMTH", +1) and not has(o, "HIGHLIGHTS"), "luật cũ giữ nguyên")
    expect("da mịn hơn, tăng kết cấu nền", lambda o: has(o, "SKIN_SMOOTH") and has(o, "TEXTURE", +1), "hai mệnh đề tách")

    # Thay bầu trời
    def sky_arg(o):
        return [a for t_, v, a in o if t_ == "SKY_REPLACE"]
    expect("thay bầu trời hoàng hôn", lambda o: sky_arg(o) == ["sunset"] and not has(o, "WARMTH"), "preset sunset, từ 'hoàng hôn' KHÔNG rò sang tông ấm")
    expect("đổi bầu trời đêm sao", lambda o: sky_arg(o) == ["night"] and len(o) == 1, "night")
    expect("thay bầu trời âm u", lambda o: sky_arg(o) == ["overcast"], "overcast")
    expect("thay bầu trời", lambda o: sky_arg(o) == ["blue"], "mặc định blue")
    expect("replace sky with sunset", lambda o: sky_arg(o) == ["sunset"], "EN")
    expect("thay bầu trời chạng vạng", lambda o: sky_arg(o) == ["dusk"], "dusk")
    expect("thay bầu trời xanh, tăng sáng", lambda o: sky_arg(o) == ["blue"] and has(o, "BRIGHTNESS", +1), "thêm luật khác")
    expect("bầu trời xanh hơn", lambda o: [t_ for t_, _, _ in o] == ["SCOPED_SKY"], "chỉnh màu vùng trời vẫn là scoped, KHÔNG thay trời")
    expect("làm bầu trời ấn tượng", lambda o: [t_ for t_, _, _ in o] == ["SCOPED_SKY"], "scoped")

    # Khớp ánh sáng tiền cảnh (R13)
    expect("thay bầu trời hoàng hôn và khớp ánh sáng", lambda o: sky_arg(o) == ["sunset"] and has(o, "SKY_RELIGHT", +1) and not has(o, "WARMTH") and not has(o, "BRIGHTNESS"),
           "relight đi kèm thay trời; 'ánh sáng' KHÔNG thành độ sáng")
    expect("relight tiền cảnh", lambda o: only(o, "SKY_RELIGHT"), "EN/VI không kèm gì")
    expect("tái chiếu sáng", lambda o: only(o, "SKY_RELIGHT"), "tái chiếu sáng")
    expect("làm sáng ảnh", lambda o: has(o, "BRIGHTNESS", +1) and not has(o, "SKY_RELIGHT"), "luật độ sáng cũ không bị ảnh hưởng")

    # Bụi / xước / sợi tóc lạc (R12)
    expect("xóa bụi", lambda o: only(o, "DUST") and has(o, "DUST", +1), "toàn ảnh")
    expect("xóa vết xước", lambda o: only(o, "DUST"), "xước")
    expect("remove dust and scratches", lambda o: only(o, "DUST"), "EN")
    expect("xóa sợi tóc lạc", lambda o: {t_ for t_, _, _ in o} == {"SCOPED_DUST_SKIN", "SCOPED_DUST_BG"},
           "sợi tóc lạc → DUST trên da + nền, KHÔNG kích hoạt nhánh tóc/mịn da")
    expect("xóa tóc bay quanh đầu", lambda o: "SCOPED_DUST_SKIN" in {t_ for t_, _, _ in o}, "tóc bay")
    expect("làm sáng tóc", lambda o: "SCOPED_DUST_SKIN" not in {t_ for t_, _, _ in o}, "câu về tóc khác không bị bắt nhầm")
    expect("tăng sáng, xóa bụi", lambda o: has(o, "BRIGHTNESS", +1) and has(o, "DUST"), "hai mệnh đề")
    expect("da mịn hơn", lambda o: has(o, "SKIN_SMOOTH") and not has(o, "DUST"), "luật cũ không bị ảnh hưởng")

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
