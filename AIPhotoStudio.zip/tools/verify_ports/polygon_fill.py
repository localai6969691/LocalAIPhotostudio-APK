#!/usr/bin/env python3
"""Port Python của engine/PolygonFill.kt (R12): tô đa giác even-odd, Douglas–Peucker, fromStroke. Cần numpy."""
import math
import sys
import numpy as np

FAIL = []
SUB = 4
MAX_POINTS = 2000


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


def rasterize(pts, w, h):
    out = np.zeros((h, w))
    n = len(pts)
    if n < 3 or w <= 0 or h <= 0:
        return out
    xs = [min(1.0, max(0.0, p[0])) * w for p in pts]
    ys = [min(1.0, max(0.0, p[1])) * h for p in pts]
    row_start = max(0, int(math.floor(min(ys))))
    row_end = min(h - 1, int(math.floor(max(ys))))
    for row in range(row_start, row_end + 1):
        cover = np.zeros(w)
        diff = np.zeros(w + 2)
        any_ = False
        for s in range(SUB):
            sy = row + (s + 0.5) / SUB
            inter = []
            for i in range(n):
                j = 0 if i == n - 1 else i + 1
                y0, y1 = ys[i], ys[j]
                if y0 == y1:
                    continue
                if min(y0, y1) <= sy < max(y0, y1):
                    inter.append(xs[i] + (sy - y0) * (xs[j] - xs[i]) / (y1 - y0))
            if len(inter) < 2:
                continue
            inter.sort()
            for p in range(0, len(inter) - 1, 2):
                a = min(float(w), max(0.0, inter[p]))
                b = min(float(w), max(0.0, inter[p + 1]))
                if b <= a:
                    continue
                any_ = True
                ia = min(w - 1, int(math.floor(a)))
                ib = min(w - 1, int(math.floor(b)))
                if ia == ib:
                    cover[ia] += b - a
                else:
                    cover[ia] += (ia + 1) - a
                    cover[ib] += b - ib
                    if ib > ia + 1:
                        diff[ia + 1] += 1
                        diff[ib] -= 1
        if not any_:
            continue
        run = np.cumsum(diff)[:w]
        out[row] = np.clip((cover + run) / SUB, 0, 1)
    return out


def area(pts):
    s = 0.0
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        s += a[0] * b[1] - b[0] * a[1]
    return abs(s / 2.0)


def dist_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    if l2 <= 1e-12:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = min(1.0, max(0.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def simplify(pts, eps):
    if len(pts) <= 2:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        lo, hi = stack.pop()
        if hi <= lo + 1:
            continue
        best, best_d = -1, eps
        for i in range(lo + 1, hi):
            d = dist_seg(pts[i], pts[lo], pts[hi])
            if d > best_d:
                best_d, best = d, i
        if best >= 0:
            keep[best] = True
            stack.append((lo, best))
            stack.append((best, hi))
    return [p for p, k in zip(pts, keep) if k]


def from_stroke(stroke):
    dedup = []
    for p in stroke:
        if not dedup or abs(dedup[-1][0] - p[0]) + abs(dedup[-1][1] - p[1]) > 1e-4:
            dedup.append((min(1.0, max(0.0, p[0])), min(1.0, max(0.0, p[1]))))
    if len(dedup) > 1:
        f, l = dedup[0], dedup[-1]
        if abs(f[0] - l[0]) + abs(f[1] - l[1]) <= 1e-4:
            dedup.pop()
    if len(dedup) < 3:
        return None
    eps = 0.004
    poly = simplify(dedup, eps)
    while len(poly) > MAX_POINTS and eps < 0.1:
        eps *= 1.5
        poly = simplify(dedup, eps)
    if len(poly) < 3 or area(poly) < 0.0005:
        return None
    return poly[:MAX_POINTS]


def circle(cx, cy, r, n):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def main():
    W, H = 200, 100
    sq = [(0.25, 0.25), (0.75, 0.25), (0.75, 0.75), (0.25, 0.75)]
    m = rasterize(sq, W, H)
    check("hình vuông: diện tích phủ = 0.25 ảnh (±0.002)", abs(m.mean() - 0.25) < 0.002, f"{m.mean():.4f}")
    check("hình vuông: trong = 1, ngoài = 0", m[50, 100] == 1.0 and m[5, 5] == 0.0 and m[95, 190] == 0.0)

    c = circle(0.5, 0.5, 0.3, 90)
    mc = rasterize(c, W, H)
    check("đa giác tròn: độ phủ khớp diện tích công thức dây giày (±0.002)", abs(mc.mean() - area(c)) < 0.002, f"{mc.mean():.4f} vs {area(c):.4f}")

    # hình ngôi sao 5 cánh tự cắt: even-odd → ngũ giác giữa KHÔNG được tô
    star = [(0.5 + 0.4 * math.sin(2 * math.pi * k * 2 / 5), 0.5 - 0.4 * math.cos(2 * math.pi * k * 2 / 5)) for k in range(5)]
    ms = rasterize(star, 400, 400)
    check("sao 5 cánh tự cắt (even-odd): tâm KHÔNG tô", ms[200, 200] == 0.0)
    tip = (0.5, 0.5 - 0.38)
    check("sao 5 cánh: mũi cánh được tô", ms[int(tip[1] * 400) + 6, int(tip[0] * 400)] > 0.9)

    # hình L lõm: diện tích đúng
    L = [(0.1, 0.1), (0.4, 0.1), (0.4, 0.6), (0.9, 0.6), (0.9, 0.9), (0.1, 0.9)]
    mL = rasterize(L, W, H)
    check("hình L lõm: diện tích phủ = công thức (±0.002)", abs(mL.mean() - area(L)) < 0.002, f"{mL.mean():.4f} vs {area(L):.4f}")
    check("hình L: góc lõm trống", mL[30, 150] == 0.0 and mL[30, 50] == 1.0)

    bow = [(0.1, 0.2), (0.9, 0.8), (0.9, 0.2), (0.1, 0.8)]
    mb = rasterize(bow, W, H)
    check("hình nơ (tự cắt): hai tam giác trái/phải được tô, trên/dưới trống", mb[50, 40] > 0.9 and mb[50, 160] > 0.9 and mb[25, 100] == 0.0 and mb[75, 100] == 0.0)

    # độ phủ phân số theo chiều ngang
    half = [(0.2005, 0.2), (0.8, 0.2), (0.8, 0.8), (0.2005, 0.8)]
    mh = rasterize(half, W, H)
    col = int(0.2005 * W)           # pixel 40: phủ từ x=40.1 → 0.9
    check("biên ngang chia pixel: độ phủ ≈ 0.9", abs(mh[50, col] - 0.9) < 0.02, f"{mh[50, col]:.3f}")

    # các trường hợp biên
    check("< 3 điểm → toàn 0", rasterize([(0.1, 0.1), (0.9, 0.9)], W, H).sum() == 0)
    check("đa giác suy biến (thẳng hàng) → toàn 0", rasterize([(0.1, 0.1), (0.5, 0.5), (0.9, 0.9)], W, H).sum() == 0)
    big = rasterize([(-1, -1), (2, -1), (2, 2), (-1, 2)], W, H)
    check("điểm ngoài ảnh được kẹp vào [0,1] → phủ kín ảnh", big.min() == 1.0)
    check("đa giác nằm sát mép trên/dưới không tràn chỉ số", rasterize([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)], W, H).min() == 1.0)
    check("kích thước 1x1 không lỗi", rasterize(sq, 1, 1).shape == (1, 1))
    check("độ phủ luôn trong [0,1]", mc.min() >= 0 and mc.max() <= 1 and mL.max() <= 1)

    # simplify
    line = [(i / 99.0, 0.5) for i in range(100)]
    check("simplify: 100 điểm thẳng hàng → 2 điểm đầu/cuối", simplify(line, 0.004) == [line[0], line[-1]])
    cc = circle(0.5, 0.5, 0.3, 200)
    sc = simplify(cc + [cc[0]], 0.004)[:-1]
    check("simplify: vòng tròn 200 điểm → ≤ 45 điểm", len(sc) <= 45, str(len(sc)))
    check("simplify: diện tích vòng tròn sai lệch < 2%", abs(area(sc) - area(cc)) / area(cc) < 0.02, f"{area(sc):.4f} vs {area(cc):.4f}")
    zig = [(i / 20.0, 0.5 + (0.02 if i % 2 else -0.02)) for i in range(21)]
    check("simplify: răng cưa biên độ > eps được giữ", len(simplify(zig, 0.004)) == len(zig))

    # fromStroke
    rng = np.random.default_rng(2)
    stroke = [(0.5 + 0.2 * math.cos(t) + rng.normal(0, 0.0008), 0.5 + 0.2 * math.sin(t) + rng.normal(0, 0.0008))
              for t in np.linspace(0, 2 * math.pi, 300)]
    poly = from_stroke(stroke)
    check("fromStroke: vòng kéo tay → đa giác gọn (3..80 điểm)", poly is not None and 3 <= len(poly) <= 80, str(len(poly) if poly else None))
    check("fromStroke: diện tích ≈ πr² (±6%)", poly is not None and abs(area(poly) - math.pi * 0.04) / (math.pi * 0.04) < 0.06,
          f"{area(poly):.4f} vs {math.pi*0.04:.4f}")
    check("fromStroke: nét quá nhỏ → null", from_stroke([(0.5, 0.5), (0.501, 0.5), (0.5, 0.501)]) is None)
    check("fromStroke: nét thẳng → null", from_stroke([(0.1, 0.1), (0.5, 0.5), (0.9, 0.9)]) is None)
    check("fromStroke: < 3 điểm → null", from_stroke([(0.1, 0.1), (0.2, 0.2)]) is None)
    check("fromStroke: điểm trùng liên tiếp bị gộp, điểm đóng vòng bị bỏ",
          len(from_stroke([(0.2, 0.2), (0.2, 0.2), (0.8, 0.2), (0.8, 0.8), (0.2, 0.8), (0.2, 0.2)])) == 4)
    huge = [(0.5 + 0.45 * math.cos(t) * (1 + 0.5 * math.sin(40 * t)), 0.5 + 0.45 * math.sin(t) * (1 + 0.5 * math.sin(37 * t)))
            for t in np.linspace(0, 2 * math.pi, 5000)]
    ph = from_stroke([(min(1, max(0, x)), min(1, max(0, y))) for x, y in huge])
    check("fromStroke: nét cực phức tạp bị giới hạn ≤ 2000 điểm", ph is not None and len(ph) <= MAX_POINTS, str(len(ph) if ph else None))

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
