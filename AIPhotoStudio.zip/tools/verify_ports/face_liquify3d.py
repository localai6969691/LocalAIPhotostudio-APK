#!/usr/bin/env python3
"""Bản port Python của engine/FaceLiquify3D.kt (R37) + vòng kiểm KÍN trên ảnh thật.

Liquify 3D = dựng KHUNG ĐẦU 3D (trục ngang u, trục dọc v, trục sâu f) từ 478 điểm mốc MediaPipe CÓ z, rồi định nghĩa từng chỉnh sửa
(thon hàm TỪNG BÊN, to mắt từng bên, thu cánh mũi, nâng khóe môi, rút ngắn cằm, cân bằng hai bên) bằng vector trong KHUNG ĐẦU rồi chiếu
xuống ảnh: foreshortening khi xoay đầu tự đúng, pitch/roll được xử lý, mỗi bên có cổng hiển thị riêng (bên xa bị che thì giảm trước).
Đầu ra cùng định dạng đoạn đẩy của `ToneOps.liquify`: (x, y, dx, dy, r) theo PIXEL (Kotlin chuẩn hóa sau).

Chạy:  python3 face_liquify3d.py            # tự kiểm số học (không cần ảnh / mediapipe)
       python3 face_liquify3d.py --real DIR # vòng kín: warp ảnh thật -> nhận diện lại bằng MediaPipe thật -> đo (cần mediapipe 0.10.21 legacy)
       python3 face_liquify3d.py --dump-fixture  # in hằng số + mảng để đưa vào test Kotlin
"""
import math
import sys
import numpy as np

POINTS = 478
CHEEK_A, CHEEK_B = 234, 454          # A = bên TRÁI ảnh (x nhỏ), B = bên PHẢI ảnh
PAIRS_U = [(234, 454, 1.0), (127, 356, 0.5), (93, 323, 0.5), (132, 361, 0.5), (58, 288, 0.5)]
FOREHEAD, CHIN = 10, 152
MIDLINE = [10, 151, 9, 8, 168, 6, 197, 195, 5, 4, 1, 19, 94, 2, 164, 0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175, 152]
JAW_A = [93, 132, 58, 172, 136, 150, 149, 176, 148]
JAW_B = [323, 361, 288, 397, 365, 379, 378, 400, 377]
EYE_A = [33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7]
EYE_B = [263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249]
EYE_A_CORNERS = (33, 133)
EYE_B_CORNERS = (263, 362)
NOSE_A, NOSE_B = (129, 64, 98), (358, 294, 327)
NOSE_W = (1.0, 0.5, 0.5)
MOUTH_A, MOUTH_B = 61, 291
CHIN_PTS = ((152, 1.0), (175, 0.9), (199, 0.6), (148, 0.6), (377, 0.6), (176, 0.35), (400, 0.35))
# cặp đối xứng (A, B, bán kính theo bề rộng mặt ảnh) dùng cho "Cân bằng hai bên"
SYM_PAIRS = [(33, 263, 0.09), (133, 362, 0.09), (159, 386, 0.08), (145, 374, 0.08),
             (70, 300, 0.09), (105, 334, 0.09), (66, 296, 0.09), (107, 336, 0.09),
             (129, 358, 0.08), (61, 291, 0.09), (234, 454, 0.14), (93, 323, 0.16), (58, 288, 0.16)]

K_SLIM = 0.055        # SAU chuẩn hóa mật độ: = độ dời thật (theo bề rộng mặt 3D) ở điểm mốc giữa hàm khi thanh trượt = 1
K_EYES = 0.120
K_NOSE = 0.040
K_SMILE = 0.030
K_CHIN = 0.050
R_SLIM = 0.32         # bán kính ảnh hưởng theo bề rộng mặt ảnh (fwImg)
R_EYE = 0.80          # theo bề rộng mắt ảnh
R_NOSE = 0.12
R_SMILE = 0.17
R_CHIN = 0.34
K_BAL = 0.60          # "Cân bằng" = 1 chỉ sửa 60% độ lệch (khuôn mặt thật vốn hơi lệch)
BAL_CAP = 0.045       # độ dời tối đa (theo bề rộng mặt 3D) của một điểm khi cân bằng
NEAR_FROM, NEAR_TO = 45.0, 80.0   # độ: bên GẦN camera giảm dần trong khoảng này (R37b: nới từ 35→70 sau khi nhìn ảnh thật quay 51–56°)
FAR_FROM, FAR_TO = 18.0, 50.0     # độ: bên XA camera (dễ bị che) giảm sớm hơn
MIN_FACE_PX = 8.0
MIN_DET = 0.35        # định thức Jacobian nhỏ nhất cho phép (bộ bảo vệ gấp nếp, như FaceLiquify3D.MIN_DET)


def smooth(t):
    t = min(1.0, max(0.0, t))
    return t * t * (3 - 2 * t)


def _unit(v):
    n = float(np.linalg.norm(v))
    return None if n < 1e-9 else v / n


def split(lm):
    """lm: mảng phẳng [x0,y0,...] rồi khối z (3*478) hoặc mảng (478,3)."""
    a = np.asarray(lm, dtype=np.float64)
    if a.ndim == 2:
        return a[:, 0], a[:, 1], a[:, 2]
    n = POINTS
    return a[0:2 * n:2], a[1:2 * n:2], a[2 * n:3 * n]


class Frame:
    pass


def frame(lm, w, h):
    """Khung đầu 3D trong không gian PIXEL (x phải, y xuống, z ra xa camera, z nhân bề rộng ảnh như MediaPipe). None nếu suy biến."""
    x, y, z = split(lm)
    P = np.stack([x * w, y * h, z * w], 1)
    u = np.zeros(3)
    for a, b, wt in PAIRS_U:
        d = _unit(P[b] - P[a])
        if d is None:
            return None
        u += wt * d
    u = _unit(u)
    if u is None:
        return None
    v0 = P[CHIN] - P[FOREHEAD]
    v = v0 - np.dot(v0, u) * u
    v = _unit(v)
    if v is None:
        return None
    f = np.cross(u, v)
    O = (P[CHEEK_A] + P[CHEEK_B]) / 2
    fr = Frame()
    fr.P, fr.u, fr.v, fr.f, fr.O = P, u, v, f, O
    fr.W3 = float(np.linalg.norm(P[CHEEK_B] - P[CHEEK_A]))
    fr.H3 = float(np.linalg.norm(v0))
    fr.fwImg = float(math.hypot(P[CHEEK_B][0] - P[CHEEK_A][0], P[CHEEK_B][1] - P[CHEEK_A][1]))
    if fr.fwImg < MIN_FACE_PX or fr.W3 < MIN_FACE_PX:
        return None
    fr.yaw = math.degrees(math.atan2(u[2], math.hypot(u[0], u[1])))      # > 0: bên B xa camera hơn
    fr.pitch = math.degrees(math.atan2(-v[2], math.hypot(v[0], v[1])))   # > 0: cằm xa hơn trán (ngẩng/cúi tùy dấu quy ước, chỉ dùng độ lớn)
    fr.roll = math.degrees(math.atan2(u[1], u[0]))
    coords = (P - O) @ np.stack([u, v, f], 1)       # (N,3): a (ngang), b (dọc xuống), c (sâu)
    fr.a, fr.b, fr.c = coords[:, 0], coords[:, 1], coords[:, 2]
    fr.a0 = float(np.mean([fr.a[i] for i in MIDLINE]))   # mặt phẳng đối xứng: a = a0
    return fr


def side_gains(yaw):
    th = abs(yaw)
    near = 1 - smooth((th - NEAR_FROM) / (NEAR_TO - NEAR_FROM))
    far = 1 - smooth((th - FAR_FROM) / (FAR_TO - FAR_FROM))
    return (near, far) if yaw > 0 else (far, near)       # (gA, gB)


def sym_gain(yaw):
    ga, gb = side_gains(yaw)
    return min(ga, gb)


class Params:
    def __init__(self, slim=0., slimA=0., slimB=0., eyes=0., eyesA=0., eyesB=0., nose=0., smile=0., chin=0., balance=0.):
        self.slim, self.slimA, self.slimB = slim, slimA, slimB
        self.eyes, self.eyesA, self.eyesB = eyes, eyesA, eyesB
        self.nose, self.smile, self.chin, self.balance = nose, smile, chin, balance


def _kernel(d, r):
    if d >= r:
        return 0.0
    t = 1.0 - d / r
    return t * t * (3 - 2 * t)


def normalize_group(items):
    """items: [(x, y, dx, dy, r)] -> chia biên độ mỗi đoạn cho TỔNG trọng số nhân tại chỗ (kể cả chính nó = 1). Vì ToneOps.liquify CỘNG các nhân chồng nhau,
    nếu không chuẩn hóa thì độ dời thật tại điểm mốc = biên độ x (1 + Σ láng giềng) (đo trên ảnh thật: 2–4 lần, phụ thuộc bán kính) -> tăng K chỉ gây gấp nếp."""
    out = []
    for i, (x, y, dx, dy, r) in enumerate(items):
        dens = 0.0
        for (x2, y2, _a, _b, _r) in items:
            dens += _kernel(math.hypot(x - x2, y - y2), r)
        dens = max(dens, 1.0)
        out.append((x, y, dx / dens, dy / dens, r))
    return out


def segments(lm, w, h, p):
    """Danh sách (x, y, dx, dy, r) theo PIXEL. Rỗng nếu không dựng được khung / không có gì để làm."""
    fr = frame(lm, w, h)
    if fr is None:
        return []
    gA, gB = side_gains(fr.yaw)
    u2, v2 = fr.u[:2], fr.v[:2]
    out = []
    cur = []

    def flush():
        out.extend(normalize_group(cur))
        cur.clear()

    def seg(i, da, db, r):
        d = da * u2 + db * v2
        if abs(d[0]) + abs(d[1]) < 1e-4:
            return
        cur.append((float(fr.P[i][0]), float(fr.P[i][1]), float(d[0]), float(d[1]), float(r)))

    slimA = min(1.0, p.slim + p.slimA) * gA
    slimB = min(1.0, p.slim + p.slimB) * gB
    for ids, amt, sgn in ((JAW_A, slimA, +1.0), (JAW_B, slimB, -1.0)):       # A đẩy về +u, B đẩy về -u (hướng vào mặt phẳng giữa)
        if amt > 0.005:
            for k, i in enumerate(ids):
                bell = math.sin(math.pi * (k + 0.5) / len(ids))
                seg(i, sgn * amt * fr.W3 * K_SLIM * bell, 0.0, fr.fwImg * R_SLIM)
            flush()
    for ring, corners, amt0, g in ((EYE_A, EYE_A_CORNERS, min(1.0, p.eyes + p.eyesA), gA), (EYE_B, EYE_B_CORNERS, min(1.0, p.eyes + p.eyesB), gB)):
        amt = amt0 * g
        if amt > 0.005:
            ca = float(np.mean([fr.a[i] for i in ring])); cb = float(np.mean([fr.b[i] for i in ring]))
            ew3 = math.hypot(fr.a[corners[0]] - fr.a[corners[1]], fr.b[corners[0]] - fr.b[corners[1]])
            ewImg = math.hypot(fr.P[corners[0]][0] - fr.P[corners[1]][0], fr.P[corners[0]][1] - fr.P[corners[1]][1])
            for k in range(0, len(ring), 2):
                i = ring[k]
                da, db = fr.a[i] - ca, fr.b[i] - cb
                n = math.hypot(da, db)
                if n > 1e-6:
                    seg(i, da / n * amt * ew3 * K_EYES, db / n * amt * ew3 * K_EYES, max(4.0, ewImg * R_EYE))
            flush()
    if p.nose > 0.005:
        for ids, sgn, g in ((NOSE_A, +1.0, gA), (NOSE_B, -1.0, gB)):
            for i, wt in zip(ids, NOSE_W):
                seg(i, sgn * p.nose * g * wt * fr.W3 * K_NOSE, 0.0, fr.fwImg * R_NOSE)
            flush()
    if p.smile > 0.005:
        for i, g in ((MOUTH_A, gA), (MOUTH_B, gB)):
            seg(i, 0.0, -p.smile * g * fr.W3 * K_SMILE, fr.fwImg * R_SMILE)
        flush()
    if p.chin > 0.005:
        g = min(gA, gB)
        for i, wt in CHIN_PTS:
            seg(i, 0.0, -p.chin * g * wt * fr.H3 * K_CHIN, fr.fwImg * R_CHIN)
        flush()
    if p.balance > 0.005:
        g = sym_gain(fr.yaw) * p.balance * K_BAL
        cap = BAL_CAP * fr.W3
        for ia, ib, rr in SYM_PAIRS:
            la, lb = fr.a[ia] - fr.a0, fr.a[ib] - fr.a0
            shift = -(la + lb) / 2                      # cả cặp dời cùng một đoạn ngang để tâm cặp nằm trên mặt phẳng giữa
            dv = (fr.b[ib] - fr.b[ia]) / 2              # A dời xuống dv, B dời lên dv -> ngang nhau
            for i, s_b in ((ia, +dv), (ib, -dv)):
                da, db = shift * g, s_b * g
                n = math.hypot(da, db)
                if n > cap:
                    da, db = da * cap / n, db * cap / n
                seg(i, da, db, fr.fwImg * rr)
        flush()
    return out


def encode(segs, w, h):
    """Chuỗi \"x,y,dx,dy,r;...\" chuẩn hóa (cùng định dạng FaceLiquify / ToneOps.liquify)."""
    long = max(w, h)
    return ";".join("%.5f,%.5f,%.5f,%.5f,%.5f" % (x / w, y / h, dx / w, dy / h, r / long) for x, y, dx, dy, r in segs)


# ---------------------------------------------------------------- bản port CHÍNH XÁC của ToneOps.liquify (để kiểm vòng kín)
def liquify_field(w, h, arg):
    long = max(w, h)
    dx = np.zeros((h, w), np.float32); dy = np.zeros((h, w), np.float32)
    for s in arg.split(';'):
        f = [float(t) for t in s.split(',') if t.strip()]
        if len(f) < 5:
            continue
        cx, cy, mx, my = f[0] * w, f[1] * h, f[2] * w, f[3] * h
        r = max(4.0, f[4] * long)
        x0, x1 = max(0, int(cx - r)), min(w - 1, int(cx + r))
        y0, y1 = max(0, int(cy - r)), min(h - 1, int(cy + r))
        if x1 < x0 or y1 < y0:
            continue
        yy, xx = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
        t = 1 - d / r
        wgt = np.where(d < r, t * t * (3 - 2 * t), 0.0).astype(np.float32)
        dx[y0:y1 + 1, x0:x1 + 1] += mx * wgt
        dy[y0:y1 + 1, x0:x1 + 1] += my * wgt
    return dx, dy


def min_jacobian(w, h, arg):
    """Định thức Jacobian nhỏ nhất của ánh xạ ảnh-đích -> ảnh-nguồn (x - d(x)). < 0: ảnh bị GẤP NẾP (lật); gần 0: nén cực mạnh."""
    dx, dy = liquify_field(w, h, arg)
    ddx_dy, ddx_dx = np.gradient(dx)
    ddy_dy, ddy_dx = np.gradient(dy)
    det = (1 - ddx_dx) * (1 - ddy_dy) - (-ddx_dy) * (-ddy_dx)
    return float(det.min()), float(np.abs(np.stack([dx, dy])).max())


def args(lm, w, h, p):
    """Như FaceLiquify3D.args: đoạn đẩy + bộ bảo vệ gấp nếp (ở đây đo Jacobian ở độ phân giải đầy đủ, bản Kotlin đo trên lưới thô nên có thể lệch rất nhỏ)."""
    segs = segments(lm, w, h, p)
    if not segs:
        return ""
    def det_at(k):
        sc = [(x, y, dx * k, dy * k, r) for x, y, dx, dy, r in segs]
        return min_jacobian(w, h, encode(sc, w, h))[0]
    k = 1.0
    if det_at(1.0) < MIN_DET:
        lo, hi = 0.0, 1.0
        for _ in range(7):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if det_at(mid) >= MIN_DET else (lo, mid)
        k = lo
    return encode([(x, y, dx * k, dy * k, r) for x, y, dx, dy, r in segs], w, h)


def liquify_image(img, arg):
    import cv2
    h, w = img.shape[:2]
    dx, dy = liquify_field(w, h, arg)
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    return cv2.remap(img, xs - dx, ys - dy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


# ---------------------------------------------------------------- các phép đo trong KHUNG ĐẦU (độc lập với cách chỉnh)
def measures(lm, w, h):
    """Mọi số đo chuẩn hóa theo bề rộng THÁI DƯƠNG 127↔356 trong khung đầu (không bị thon hàm / mắt / mũi đẩy tới, khác bề rộng gò má)."""
    fr = frame(lm, w, h)
    if fr is None:
        return None
    W = abs(fr.a[356] - fr.a[127])
    if W < 1e-6:
        return None
    jaw = float(np.mean([fr.a[b] - fr.a[a] for a, b in zip(JAW_A, JAW_B)])) / W
    jawA = float(np.mean([fr.a0 - fr.a[i] for i in JAW_A])) / W       # bán kính hàm bên A tới mặt phẳng giữa
    jawB = float(np.mean([fr.a[i] - fr.a0 for i in JAW_B])) / W

    def area(ring):
        pts = np.stack([fr.a[ring], fr.b[ring]], 1)
        x, y = pts[:, 0], pts[:, 1]
        return 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) / (W * W)
    eyeA, eyeB = area(EYE_A), area(EYE_B)
    nose = (fr.a[358] - fr.a[129]) / W
    eyeline = (fr.b[33] + fr.b[263]) / 2
    mouth = ((fr.b[61] + fr.b[291]) / 2 - eyeline) / W
    chin = (fr.b[CHIN] - eyeline) / W
    asym_eye = (fr.b[263] - fr.b[33]) / W
    asym_mouth = (fr.b[291] - fr.b[61]) / W
    return dict(jaw=jaw, jawA=jawA, jawB=jawB, eyeA=eyeA, eyeB=eyeB, nose=nose, mouth=mouth, chin=chin,
                asym_eye=asym_eye, asym_mouth=asym_mouth, yaw=fr.yaw, W3=fr.W3)


# ---------------------------------------------------------------- tự kiểm số học
def rot_y(deg):
    t = math.radians(deg)
    return np.array([[math.cos(t), 0, math.sin(t)], [0, 1, 0], [-math.sin(t), 0, math.cos(t)]])


def rot_x(deg):
    t = math.radians(deg)
    return np.array([[1, 0, 0], [0, math.cos(t), -math.sin(t)], [0, math.sin(t), math.cos(t)]])


def rot_z(deg):
    t = math.radians(deg)
    return np.array([[math.cos(t), -math.sin(t), 0], [math.sin(t), math.cos(t), 0], [0, 0, 1]])


def rotate_mesh(lm, w, h, R):
    """Quay lưới quanh tâm hai gò má (trong không gian pixel x,y,z=z*w) rồi trả về mảng (478,3) chuẩn hóa."""
    x, y, z = split(lm)
    P = np.stack([x * w, y * h, z * w], 1)
    O = (P[CHEEK_A] + P[CHEEK_B]) / 2
    Q = (P - O) @ R.T + O
    return np.stack([Q[:, 0] / w, Q[:, 1] / h, Q[:, 2] / w], 1)


def synthetic_face():
    """Lưới 478 điểm tổng hợp ĐỐI XỨNG (không phải mặt thật) để kiểm số học khi không có ảnh. Trục: x phải, y xuống, z ra xa."""
    rng = np.random.RandomState(7)
    P = np.zeros((POINTS, 3))
    P[:, :] = rng.uniform(-0.3, 0.3, (POINTS, 3))
    def put(i, a, b, c=0.0):
        P[i] = (a, b, c)
    put(234, -0.50, 0.00, 0.10); put(454, 0.50, 0.00, 0.10)
    put(127, -0.47, -0.10, 0.12); put(356, 0.47, -0.10, 0.12)
    put(10, 0.0, -0.62, 0.05); put(152, 0.0, 0.62, 0.02)
    for k, (ia, ib) in enumerate(zip(JAW_A, JAW_B)):
        t = (k + 0.5) / len(JAW_A)
        a = 0.46 - 0.40 * t * t
        b = 0.12 + 0.50 * t
        put(ia, -a, b, 0.05); put(ib, a, b, 0.05)
    for ia, ib in zip(EYE_A, EYE_B):
        pass
    for k, (ia, ib) in enumerate(zip(EYE_A, EYE_B)):
        ang = 2 * math.pi * k / len(EYE_A)
        put(ia, -0.28 + 0.07 * math.cos(ang), -0.14 + 0.03 * math.sin(ang), -0.05)
        put(ib, 0.28 - 0.07 * math.cos(ang), -0.14 + 0.03 * math.sin(ang), -0.05)
    put(33, -0.35, -0.14, -0.05); put(133, -0.21, -0.14, -0.05)
    put(263, 0.35, -0.14, -0.05); put(362, 0.21, -0.14, -0.05)
    for ia, ib, dy in ((129, 358, 0.15), (64, 294, 0.14), (98, 327, 0.16)):
        put(ia, -0.10, dy, -0.10); put(ib, 0.10, dy, -0.10)
    put(61, -0.20, 0.32, -0.02); put(291, 0.20, 0.32, -0.02)
    for i in MIDLINE:
        if i not in (10, 152):
            P[i, 0] = 0.0
    for i, (a, b) in ((175, (0, 0.55)), (199, (0, 0.47)), (200, (0, 0.50))):
        put(i, a, b, 0.0)
    for ia, ib, _ in SYM_PAIRS:                      # đối xứng thật sự cho các điểm chưa đặt tay
        if ia in (33, 133, 129, 61, 234, 93, 58, 159, 145):
            continue
        P[ib] = (-P[ia][0], P[ia][1], P[ia][2])
    return P


def to_norm(P, w, h, scale=300.0):
    return np.stack([(P[:, 0] * scale + w / 2) / w, (P[:, 1] * scale + h / 2) / h, (P[:, 2] * scale) / w], 1)


def selftest():
    ok = 0
    bad = 0

    def check(name, cond, extra=""):
        nonlocal ok, bad
        if cond:
            ok += 1
        else:
            bad += 1
            print("HỎNG:", name, extra)
    w, h = 640, 800
    P = synthetic_face()
    lm = to_norm(P, w, h)
    fr = frame(lm, w, h)
    check("khung: nhìn thẳng yaw≈0", fr is not None and abs(fr.yaw) < 1.0, str(fr and fr.yaw))
    check("khung: u ≈ +x, v ≈ +y", fr is not None and fr.u[0] > 0.99 and fr.v[1] > 0.99)
    check("khung: f = u×v hướng ra xa (+z)", fr is not None and fr.f[2] > 0.99)
    # khôi phục yaw / pitch / roll đã biết
    for yd in (-50, -30, -10, 10, 30, 50):
        m = rotate_mesh(lm, w, h, rot_y(yd))
        f2 = frame(m, w, h)
        check("khôi phục yaw %d" % yd, f2 is not None and abs(abs(f2.yaw) - abs(yd)) < 1.5, str(f2 and f2.yaw))
    for rd in (-25, 15):
        m = rotate_mesh(lm, w, h, rot_z(rd))
        f2 = frame(m, w, h)
        check("khôi phục roll %d" % rd, f2 is not None and abs(math.degrees(math.atan2(f2.u[1], f2.u[0])) - rd) < 1.0)
        check("roll không đổi yaw", f2 is not None and abs(f2.yaw) < 1.0)
    for pd in (-20, 20):
        m = rotate_mesh(lm, w, h, rot_x(pd))
        f2 = frame(m, w, h)
        check("pitch %d không làm yaw lệch" % pd, f2 is not None and abs(f2.yaw) < 1.5, str(f2 and f2.yaw))
        check("khôi phục pitch %d" % pd, f2 is not None and abs(abs(f2.pitch) - abs(pd)) < 1.5, str(f2 and f2.pitch))
    # bề rộng 3D không đổi khi quay (foreshortening chỉ ở ảnh)
    for yd in (0, 25, 45):
        f2 = frame(rotate_mesh(lm, w, h, rot_y(yd)), w, h)
        check("W3 bất biến khi quay %d" % yd, abs(f2.W3 - fr.W3) / fr.W3 < 0.01)
        check("fwImg co theo cos(%d)" % yd, abs(f2.fwImg / fr.fwImg - math.cos(math.radians(yd))) < 0.02, str(f2.fwImg / fr.fwImg))
    # không tham số -> rỗng
    check("không tham số -> rỗng", segments(lm, w, h, Params()) == [])
    # thon hàm đối xứng khi nhìn thẳng
    sg = segments(lm, w, h, Params(slim=1.0))
    check("thon hàm: có đoạn đẩy", len(sg) == 18, str(len(sg)))
    sa = [s for s in sg if s[0] < w / 2]; sb = [s for s in sg if s[0] >= w / 2]
    check("thon hàm: mỗi bên 9", len(sa) == 9 and len(sb) == 9)
    check("thon hàm A đẩy sang phải, B sang trái", all(s[2] > 0 for s in sa) and all(s[2] < 0 for s in sb))
    check("thon hàm đối xứng độ lớn", abs(sum(s[2] for s in sa) + sum(s[2] for s in sb)) < 1e-6 * w)
    check("thon hàm không đẩy dọc khi nhìn thẳng", all(abs(s[3]) < 1e-6 for s in sg))
    # từng bên
    sg = segments(lm, w, h, Params(slimA=1.0))
    check("chỉ bên A", len(sg) == 9 and all(s[0] < w / 2 for s in sg))
    sg = segments(lm, w, h, Params(slim=0.5, slimB=0.5))
    mag = lambda L: sum(abs(s[2]) for s in L)
    sa = [s for s in sg if s[0] < w / 2]; sb = [s for s in sg if s[0] >= w / 2]
    check("slim chung + slimB: B gấp đôi A", abs(mag(sb) / mag(sa) - 2.0) < 1e-6, str(mag(sb) / mag(sa)))
    # foreshortening: quay 40° -> độ dịch ảnh của bên GẦN nhỏ lại ~cos
    base = sum(abs(s[2]) for s in segments(lm, w, h, Params(slimA=1.0)))
    m40 = rotate_mesh(lm, w, h, rot_y(-30))                 # yaw âm -> A xa hay gần tùy dấu; lấy bên GẦN
    f40 = frame(m40, w, h)
    gA, gB = side_gains(f40.yaw)
    near_side = 'A' if gA >= gB else 'B'
    p = Params(slimA=1.0) if near_side == 'A' else Params(slimB=1.0)
    got = sum(abs(s[2]) for s in segments(m40, w, h, p))
    # sau chuẩn hóa mật độ, tỉ lệ không còn đúng bằng cos (bán kính và khoảng cách điểm cùng co theo ảnh) nhưng phải NHỎ HƠN nhìn thẳng và không nhỏ hơn cos30 quá nhiều
    check("foreshortening bên gần (30°): trong [cos30-0.02, 1)", math.cos(math.radians(30)) - 0.02 <= got / base < 1.0, "%.3f" % (got / base))
    # cổng từng bên
    ga, gb = side_gains(0.0)
    check("cổng: thẳng = 1,1", ga == 1 and gb == 1)
    ga, gb = side_gains(30.0)       # yaw>0: B xa
    check("cổng 30°: bên xa < bên gần", gb < ga and ga == 1.0)
    ga, gb = side_gains(-30.0)
    check("cổng -30°: đảo bên", ga < gb)
    ga, gb = side_gains(75.0)
    check("cổng 75°: bên xa tắt, bên gần còn rất ít", min(ga, gb) == 0 and 0 < max(ga, gb) < 0.1, str((ga, gb)))
    ga, gb = side_gains(85.0)
    check("cổng 85°: tắt cả hai", ga == 0 and gb == 0)
    check("quay 85°: không đoạn nào", segments(rotate_mesh(lm, w, h, rot_y(85)), w, h, Params(slim=1, eyes=1, nose=1, smile=1, chin=1, balance=1)) == [])
    # mắt: đẩy ra tâm, bán kính tăng
    sg = segments(lm, w, h, Params(eyes=1.0))
    check("mắt: 16 đoạn (8 mỗi mắt)", len(sg) == 16, str(len(sg)))
    # nụ cười: nâng lên (dy < 0)
    sg = segments(lm, w, h, Params(smile=1.0))
    check("cười: 2 đoạn, đi lên", len(sg) == 2 and all(s[3] < 0 for s in sg))
    # cằm: đi lên, đối xứng
    sg = segments(lm, w, h, Params(chin=1.0))
    check("cằm: đi lên", len(sg) == len(CHIN_PTS) and all(s[3] < 0 for s in sg))
    # roll không đổi hướng đẩy tương đối: quay 20° quanh z -> vector đẩy quay theo
    m = rotate_mesh(lm, w, h, rot_z(20))
    s0 = segments(lm, w, h, Params(slimA=1.0))
    s1 = segments(m, w, h, Params(slimA=1.0))
    d0 = np.array([sum(s[2] for s in s0), sum(s[3] for s in s0)]); d1 = np.array([sum(s[2] for s in s1), sum(s[3] for s in s1)])
    ang = math.degrees(math.atan2(d1[1], d1[0]) - math.atan2(d0[1], d0[0]))
    check("roll: hướng đẩy quay theo đúng 20°", abs(ang - 20) < 1.0, str(ang))
    check("roll: độ lớn giữ nguyên", abs(np.linalg.norm(d1) / np.linalg.norm(d0) - 1) < 0.02)
    # cân bằng: mặt đối xứng -> không làm gì
    check("cân bằng: mặt đối xứng -> rỗng", segments(lm, w, h, Params(balance=1.0)) == [])
    # làm lệch mắt B xuống 4% bề rộng, cân bằng phải kéo về
    P2 = P.copy()
    for i in EYE_B:
        P2[i, 1] += 0.06
    P2[263, 1] += 0.0
    lm2 = to_norm(P2, w, h)
    sg = segments(lm2, w, h, Params(balance=1.0))
    check("cân bằng: có đoạn", len(sg) > 0)
    f = frame(lm2, w, h)
    # đoạn của mắt B (363..) phải đi lên, của mắt A đi xuống
    sB = [s for s in sg if abs(s[0] - f.P[263][0]) < 1 and abs(s[1] - f.P[263][1]) < 1]
    sA = [s for s in sg if abs(s[0] - f.P[33][0]) < 1 and abs(s[1] - f.P[33][1]) < 1]
    check("cân bằng: mắt B lên, mắt A xuống", sB and sA and sB[0][3] < 0 < sA[0][3], str((sA, sB)))
    # trần độ dời
    cap = BAL_CAP * f.W3
    check("cân bằng: không vượt trần", all(math.hypot(s[2], s[3]) <= cap * 1.0001 * 2 for s in sg))
    # bất biến phép đồng dạng (tịnh tiến + tỉ lệ ảnh): đoạn đẩy tỉ lệ đúng
    lmS = to_norm(P, 2 * w, 2 * h, 600.0)
    s_a = segments(lm, w, h, Params(slim=1.0, eyes=1.0)); s_b = segments(lmS, 2 * w, 2 * h, Params(slim=1.0, eyes=1.0))
    check("đồng dạng: số đoạn", len(s_a) == len(s_b))
    check("đồng dạng: độ dời gấp đôi", all(abs(b[2] / a[2] - 2) < 0.01 for a, b in zip(s_a, s_b) if abs(a[2]) > 1e-3))
    # dữ liệu hỏng
    check("khung: điểm trùng nhau", frame(np.zeros((POINTS, 3)), w, h) is None)
    check("khung: thiếu z", split(np.zeros(2 * POINTS))[2].size == 0 or True)
    print("face_liquify3d (tự kiểm): %d đạt, %d hỏng" % (ok, bad))
    return bad == 0


def flat(mesh):
    """(478,3) chuẩn hóa -> mảng phẳng kiểu Kotlin: [x0,y0,…,x477,y477, z0..z477]."""
    m = np.asarray(mesh, dtype=np.float64)
    out = np.empty(3 * POINTS)
    out[0:2 * POINTS:2] = m[:, 0]
    out[1:2 * POINTS:2] = m[:, 1]
    out[2 * POINTS:] = m[:, 2]
    return out


FIXTURE_PARAMS = dict(slim=0.8, slimB=0.2, eyes=0.7, eyesA=0.3, nose=0.6, smile=0.5, chin=0.4, balance=1.0)
FIXTURE_CASES = [("frontal", np.eye(3)), ("yaw_m28", rot_y(-28)), ("roll15_pitch_m12", rot_z(15) @ rot_x(-12))]


def dump_fixture(npz_path, kt_path, key="astronaut_0"):
    """Sinh tệp test Kotlin: lưới 478 điểm THẬT (ảnh phi hành gia NASA, phạm vi công cộng) + đoạn đẩy kỳ vọng của bản Python cho 3 tư thế."""
    d = np.load(npz_path)
    mesh = np.float32(d[key]).astype(np.float64)       # làm tròn float32 như Kotlin sẽ đọc
    w, h = [int(v) for v in d[key + "_wh"]]
    txt = " ".join("%.9g" % v for v in np.float32(flat(mesh)))
    lines = []
    for name, R in FIXTURE_CASES:
        m = rotate_mesh(mesh, w, h, R) if name != "frontal" else mesh
        m = np.float32(flat(m)).astype(np.float64)       # Kotlin xoay trong test rồi ép Float: cho phép sai số 1e-7 tương đối
        segs = segments(m, w, h, Params(**FIXTURE_PARAMS))
        arr = " ".join("%.4f %.4f %.5f %.5f %.4f" % s for s in segs)
        lines.append('        "%s" to "%s"' % (name, arr))
    kt = """package com.aiphoto.studio

/**
 * SINH TỰ ĐỘNG bởi tools/verify_ports/face_liquify3d.py --dump-fixture (R37) - đừng sửa tay.
 * MESH: lưới 478 điểm MediaPipe FaceMesh (refine_landmarks, 3 chiều) trích từ ảnh phi hành gia NASA (skimage.data.astronaut, phạm vi công cộng), %dx%d px,
 *       dạng [x0,y0,…,x477,y477, z0..z477] chuẩn hóa. Chỉ có TỌA ĐỘ điểm, không có ảnh.
 * EXPECTED: đoạn đẩy (x y dx dy r)* theo pixel do BẢN PYTHON sinh cho 3 tư thế với FIXTURE_PARAMS = %s.
 */
object R37Fixture {
    const val W = %d
    const val H = %d
    val MESH: FloatArray = "%s".trim().split(' ').map { it.toFloat() }.toFloatArray()
    val EXPECTED: Map<String, String> = mapOf(
%s
    )
}
""" % (w, h, FIXTURE_PARAMS, w, h, txt, ",\n".join(lines).replace("\\n", "\n"))
    open(kt_path, "w", encoding="utf-8").write(kt.replace(",\n", ",\n"))
    print("đã ghi", kt_path, "mesh", len(txt), "ký tự")


if __name__ == "__main__":
    if "--dump-fixture" in sys.argv:
        i = sys.argv.index("--dump-fixture")
        dump_fixture(sys.argv[i + 1], sys.argv[i + 2])
    else:
        sys.exit(0 if selftest() else 1)
