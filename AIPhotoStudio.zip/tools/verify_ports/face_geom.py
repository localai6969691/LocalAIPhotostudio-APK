import numpy as np, math

FACE_OVAL=[10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109]
RIGHT_EYE=[33,246,161,160,159,158,157,173,133,155,154,153,145,144,163,7]
LEFT_EYE=[263,466,388,387,386,385,384,398,362,382,381,380,374,373,390,249]
LIPS_OUTER=[61,185,40,39,37,0,267,269,270,409,291,375,321,405,314,17,84,181,91,146]
LIPS_INNER=[78,191,80,81,82,13,312,311,310,415,308,324,318,402,317,14,87,178,88,95]
RIGHT_BROW=[70,63,105,66,107,46,53,52,65,55]
LEFT_BROW=[300,293,334,296,336,276,283,282,295,285]
RIGHT_LOWER=[33,7,163,144,145,153,154,155,133]
LEFT_LOWER=[263,249,390,373,374,380,381,382,362]

def fill_polygon(xs,ys,w,h,out,value=255):
    n=len(xs)
    if n<3: return
    y0=max(0,math.floor(min(ys))); y1=min(h-1,math.ceil(max(ys)))
    for y in range(y0,y1+1):
        sy=y+0.5; cr=[]; j=n-1
        for i in range(n):
            yi,yj=ys[i],ys[j]
            if (yi<=sy and yj>sy) or (yj<=sy and yi>sy):
                cr.append(xs[i]+(sy-yi)/(yj-yi)*(xs[j]-xs[i]))
            j=i
        cr.sort(); k=0
        while k+1<len(cr):
            xa=max(0,math.ceil(cr[k]-0.5)); xb=min(w-1,math.floor(cr[k+1]-0.5))
            if xb>=xa: out[y,xa:xb+1]=value
            k+=2

def hull(px,py):
    n=len(px)
    if n<3: return px,py
    idx=sorted(range(n),key=lambda i:(px[i],py[i]))
    def cross(o,a,b): return (px[a]-px[o])*(py[b]-py[o])-(py[a]-py[o])*(px[b]-px[o])
    H=[]
    for i in idx:
        while len(H)>=2 and cross(H[-2],H[-1],i)<=0: H.pop()
        H.append(i)
    lo=len(H)+1
    for t in range(n-2,-1,-1):
        i=idx[t]
        while len(H)>=lo and cross(H[-2],H[-1],i)<=0: H.pop()
        H.append(i)
    H.pop()
    return [px[i] for i in H],[py[i] for i in H]

def shoelace(xs,ys):
    s=0
    for i in range(len(xs)):
        j=(i+1)%len(xs); s+=xs[i]*ys[j]-xs[j]*ys[i]
    return abs(s)/2

def parts(faces,w,h):
    skin=np.zeros((h,w),np.uint8); eyes=np.zeros_like(skin); mouth=np.zeros_like(skin); under=np.zeros_like(skin)
    def xy(lm,ids): return [lm[2*i]*w for i in ids],[lm[2*i+1]*h for i in ids]
    def ring(lm,ids,out,v): fill_polygon(*xy(lm,ids),w,h,out,v)
    def hullfill(lm,ids,out,v):
        hx,hy=hull(*xy(lm,ids)); fill_polygon(hx,hy,w,h,out,v)
    def underfill(lm,lid,out):
        ex,ey=xy(lm,lid); n=len(lid)
        dx=(lm[2*152]-lm[2*10])*w; dy=(lm[2*152+1]-lm[2*10+1])*h
        L=math.hypot(dx,dy); dx/=L; dy/=L
        ew=math.hypot(ex[0]-ex[-1],ey[0]-ey[-1]); d=0.5*ew
        px=[0]*(2*n); py=[0]*(2*n)
        for i in range(n):
            px[i]=ex[i]; py[i]=ey[i]; px[2*n-1-i]=ex[i]+dx*d; py[2*n-1-i]=ey[i]+dy*d
        fill_polygon(px,py,w,h,out,255)
    for lm in faces: ring(lm,FACE_OVAL,skin,255)
    for lm in faces:
        ring(lm,RIGHT_EYE,skin,0); ring(lm,LEFT_EYE,skin,0); hullfill(lm,RIGHT_BROW,skin,0); hullfill(lm,LEFT_BROW,skin,0)
        ring(lm,LIPS_OUTER,skin,0); ring(lm,RIGHT_EYE,eyes,255); ring(lm,LEFT_EYE,eyes,255)
        ring(lm,LIPS_INNER,mouth,255); underfill(lm,RIGHT_LOWER,under); underfill(lm,LEFT_LOWER,under)
    return skin,eyes,mouth,under

def synth_face(cx=0.5,cy=0.5):
    lm=[cx]*956
    for i in range(478): lm[2*i]=cx; lm[2*i+1]=cy
    def place(ids,ox,oy,rx,ry,start=0.0):
        n=len(ids)
        for k,i in enumerate(ids):
            a=start+2*math.pi*k/n
            lm[2*i]=cx+ox+rx*math.cos(a); lm[2*i+1]=cy+oy+ry*math.sin(a)
    place(FACE_OVAL,0,0,0.25,0.35,-math.pi/2)        # 10 = top (forehead), idx 18 = 152 bottom (chin)
    place(RIGHT_EYE,-0.10,-0.08,0.05,0.025,math.pi)   # starts at outer corner
    place(LEFT_EYE,0.10,-0.08,0.05,0.025,0.0)
    place(LIPS_OUTER,0,0.16,0.08,0.035,math.pi)
    place(LIPS_INNER,0,0.16,0.06,0.015,math.pi)
    place(RIGHT_BROW,-0.10,-0.15,0.06,0.012,math.pi)
    place(LEFT_BROW,0.10,-0.15,0.06,0.012,0.0)
    # chin/forehead after oval placement
    return lm

if __name__=="__main__":
    # 1) polygon fill vs analytic area
    w=h=200
    for name,(xs,ys) in {"square":([20,120,120,20],[30,30,130,130]),
                         "triangle":([10,190,100],[10,10,180]),
                         "concave":([20,180,180,100,20],[20,20,180,60,180])}.items():
        out=np.zeros((h,w),np.uint8); fill_polygon(xs,ys,w,h,out)
        a=int((out>0).sum()); b=shoelace(xs,ys)
        print(f"{name}: filled={a} analytic={b:.0f} err={abs(a-b)/b*100:.2f}%")
    # hull of points with interior ones
    hx,hy=hull([0,10,10,0,5,5],[0,0,10,10,5,2]); print("hull verts:",len(hx),sorted(zip(hx,hy)))
    # 2) synthetic face parts
    W,H=400,500
    lm=synth_face()
    skin,eyes,mouth,under=parts([lm],W,H)
    print("skin",int((skin>0).sum()),"eyes",int((eyes>0).sum()),"mouth",int((mouth>0).sum()),"under",int((under>0).sum()))
    print("skin∩eyes:",int(((skin>0)&(eyes>0)).sum()),"skin∩mouth:",int(((skin>0)&(mouth>0)).sum()))
    ys_e,_=np.nonzero(eyes); ys_u,_=np.nonzero(under)
    print("eye centroid y=%.1f  under-eye centroid y=%.1f (under must be larger)"%(ys_e.mean(),ys_u.mean()))
    # tilted face: rotate the whole landmark set by 20deg about the center; under-eyes must still sit 'below' along the face axis
    th=math.radians(20); lm2=lm[:]
    for i in range(478):
        x=(lm[2*i]-0.5)*W; y=(lm[2*i+1]-0.5)*H
        lm2[2*i]=(0.5*W+x*math.cos(th)-y*math.sin(th))/W; lm2[2*i+1]=(0.5*H+x*math.sin(th)+y*math.cos(th))/H
    s2,e2,m2,u2=parts([lm2],W,H)
    ce=np.argwhere(e2>0).mean(0); cu=np.argwhere(u2>0).mean(0)
    ax=np.array([(lm2[2*152+1]-lm2[2*10+1])*H,(lm2[2*152]-lm2[2*10])*W]); ax/=np.linalg.norm(ax)
    print("tilted: projection of (under-eye - eye) on face-down axis = %.1f px (must be > 0)"%float(np.dot(cu-ce,ax)))
