#!/usr/bin/env python3
"""
R16 - Kiểm tra số học của engine/HairVolume.kt (tăng volume tóc bằng biến dạng ngược theo trường khoảng cách) bằng bản port Python.
  * port dịch từng dòng từ Kotlin, dùng float32 (như Kotlin) cho EDT / hộp mờ / lấy mẫu
  * EDT đối chiếu scipy.ndimage.distance_transform_edt; hộp mờ đối chiếu scipy.ndimage.uniform_filter(mode='nearest'); lấy mẫu song tuyến đối chiếu cv2.remap
  * tính chất: đĩa tóc phồng đúng +grow; trong tóc/ngoài dải không đổi; không NaN; vùng bảo vệ; mặt nạ răng cưa; ảnh nhỏ/lệch
  * hằng số (MAX_GROW_FRAC, BAND_FACTOR, MIN_GROW_PX) đọc TỪ HairVolume.kt để hai bên không lệch nhau
  * kiểm thử đột biến: đảo dấu hướng, bỏ vùng bảo vệ, dải sai -> phải bị bắt
Chạy: python3 tools/verify_ports/hair_volume.py
"""
import math, os, re, sys
import numpy as np
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
KT = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "aiphoto", "studio", "engine", "HairVolume.kt")
src_kt = open(KT, encoding="utf-8").read()
def const(name):
    return float(re.search(r"const val " + name + r" = ([0-9.]+)f", src_kt).group(1))
MAX_GROW_FRAC, BAND_FACTOR, MIN_GROW_PX = const("MAX_GROW_FRAC"), const("BAND_FACTOR"), const("MIN_GROW_PX")
F = np.float32
INF = F(1e20)
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok: fails.append(name)

# ------------------------------------------------------------------ bản dịch Kotlin
def grow_px(w, h, s):
    s = 0.0 if s != s else min(1.0, max(0.0, s))
    return F(s * MAX_GROW_FRAC * max(w, h))
def smooth(t):
    c = F(0) if t < 0 else (F(1) if t > 1 else F(t))
    return c * c * (F(3) - F(2) * c)
def shift_at(d, grow, band):
    return F(0) if d >= band else F(grow * (F(1) - smooth(F((d - grow) / (band - grow)))))

def box_blur(f, r):
    h, w = f.shape
    inv = F(1.0 / (2 * r + 1))
    idx = lambda k, n: np.clip(k, 0, n - 1)
    tmp = np.zeros_like(f); out = np.zeros_like(f)
    for y in range(h):                       # trượt từng hàng giống Kotlin (cộng dồn float32)
        row = f[y]; s = F(0)
        for k in range(-r, r + 1): s += row[idx(k, w)]
        for x in range(w):
            tmp[y, x] = s * inv
            s = F(s + row[idx(x + r + 1, w)] - row[idx(x - r, w)])
    for x in range(w):
        col = tmp[:, x]; s = F(0)
        for k in range(-r, r + 1): s += col[idx(k, h)]
        for y in range(h):
            out[y, x] = s * inv
            s = F(s + col[idx(y + r + 1, h)] - col[idx(y - r, h)])
    return out

def dt1d(f, n):
    d = np.zeros(n, dtype=F); v = np.zeros(n + 1, dtype=np.int64); z = np.zeros(n + 2, dtype=F)
    k = 0; v[0] = 0; z[0] = -INF; z[1] = INF
    for q in range(1, n):
        fq = F(f[q] + F(q) * F(q))
        s = F((fq - F(f[v[k]] + F(v[k]) * F(v[k]))) / F(2 * q - 2 * v[k]))
        while s <= z[k]:
            k -= 1
            s = F((fq - F(f[v[k]] + F(v[k]) * F(v[k]))) / F(2 * q - 2 * v[k]))
        k += 1; v[k] = q; z[k] = s; z[k + 1] = INF
    k = 0
    for q in range(n):
        while z[k + 1] < q: k += 1
        dx = F(q - v[k]); d[q] = F(dx * dx + f[v[k]])
    return d

def distance_to_hair(in_hair):
    h, w = in_hair.shape
    f = np.where(in_hair, F(0), INF).astype(F)
    for x in range(w): f[:, x] = dt1d(f[:, x].copy(), h)
    for y in range(h): f[y, :] = dt1d(f[y, :].copy(), w)
    return np.sqrt(f).astype(F)

def box_blur_fast(f, r):          # tương đương box_blur (đã đối chiếu scipy) nhưng nhanh: dùng cho cảnh lớn
    return ndimage.uniform_filter(f.astype(np.float64), size=2 * r + 1, mode="nearest").astype(F)
def distance_to_hair_fast(m):
    return ndimage.distance_transform_edt(~m).astype(F)

def ch(v): return 0 if v <= 0 else 255 if v >= 255 else int(v + 0.5)
def sample_rgb(img, sx, sy):
    h, w, _ = img.shape
    fx = min(max(sx, 0.0), w - 1.0); fy = min(max(sy, 0.0), h - 1.0)
    x0, y0 = int(fx), int(fy); x1 = min(x0 + 1, w - 1); y1 = min(y0 + 1, h - 1)
    tx, ty = F(fx - x0), F(fy - y0)
    out = []
    for c in range(3):
        a, b, cc, e = [F(img[yy, xx, c]) for yy, xx in ((y0, x0), (y0, x1), (y1, x0), (y1, x1))]
        top = a + (b - a) * tx; bot = cc + (e - cc) * tx
        out.append(ch(float(top + (bot - top) * ty)))
    return out

def apply(img, hair, protect, strength, _flip=False, _no_protect=False, _band_factor=None, _fast=False):
    h, w, _ = img.shape
    grow = grow_px(w, h, strength)
    if grow < MIN_GROW_PX or w < 3 or h < 3: return img.copy()
    bb = box_blur_fast if _fast else box_blur
    r = max(1, max(w, h) // 300)
    raw = (hair != 0).astype(F)
    ms = bb(bb(raw, r), r)
    in_hair = ms >= 0.5
    if not in_hair.any(): return img.copy()
    d = distance_to_hair_fast(in_hair) if _fast else distance_to_hair(in_hair)
    dsm = bb(d, 2)
    band = F(grow * F(_band_factor if _band_factor is not None else BAND_FACTOR))
    keep = None
    if protect is not None and not _no_protect:
        p = (protect != 0).astype(F); pb = bb(bb(p, r), r); keep = (F(1) - pb).astype(F)
    out = img.copy()
    for y in range(h):
        yu = y - 1 if y > 0 else y; yd = y + 1 if y < h - 1 else y
        for x in range(w):
            if in_hair[y, x]: continue
            di = d[y, x]
            if di >= band: continue
            wgt = keep[y, x] if keep is not None else F(1)
            if wgt <= 0.001: continue
            xl = x - 1 if x > 0 else x; xr = x + 1 if x < w - 1 else x
            gx = F((dsm[y, xr] - dsm[y, xl]) / F(xr - xl)); gy = F((dsm[yd, x] - dsm[yu, x]) / F(yd - yu))
            gl = F(math.sqrt(float(gx * gx + gy * gy)))
            if gl < 1e-3: continue
            sh = shift_at(di, grow, band)
            sgn = -1.0 if not _flip else 1.0
            sx = x + sgn * float(gx / gl * sh); sy = y + sgn * float(gy / gl * sh)
            c = sample_rgb(img, sx, sy)
            if wgt >= 0.999: out[y, x, :3] = c
            else: out[y, x, :3] = [ch(float(F(img[y, x, k]) + (F(c[k]) - F(img[y, x, k])) * wgt)) for k in range(3)]
    return out

# ------------------------------------------------------------------ 0) hằng số đọc từ Kotlin
check("hằng số đọc từ HairVolume.kt: MAX_GROW_FRAC=0.02, BAND_FACTOR=2.5, MIN_GROW_PX=0.75",
      (MAX_GROW_FRAC, BAND_FACTOR, MIN_GROW_PX) == (0.02, 2.5, 0.75), (MAX_GROW_FRAC, BAND_FACTOR, MIN_GROW_PX))
check("Kotlin không cấp phát mảng trong vòng nóng (intArrayOf)", "intArrayOf" not in src_kt)

# ------------------------------------------------------------------ 1) hạ tầng đối chiếu thư viện chuẩn
rng = np.random.default_rng(16)
errs = []
for trial in range(6):
    h, w = int(rng.integers(8, 41)), int(rng.integers(8, 41))
    m = rng.random((h, w)) < rng.choice([0.01, 0.05, 0.3])
    if not m.any(): m[h // 2, w // 2] = True
    ours = distance_to_hair(m)
    ref = ndimage.distance_transform_edt(~m)
    errs.append(float(np.abs(ours - ref).max()))
check("EDT (Felzenszwalb float32) == scipy distance_transform_edt (6 mặt nạ ngẫu nhiên, sai số < 1e-3)", max(errs) < 1e-3, errs)
big = np.zeros((40, 300), bool); big[20, 5] = True
check("EDT: điểm tóc đơn lẻ ở xa vẫn đúng (khoảng cách tới góc đối diện)", abs(float(distance_to_hair(big)[39, 299]) - math.hypot(19, 294)) < 1e-2)
errs = []
for r in (1, 2, 3):
    f = rng.random((17, 23)).astype(F)
    errs.append(float(np.abs(box_blur(f, r) - ndimage.uniform_filter(f.astype(np.float64), size=2 * r + 1, mode="nearest")).max()))
check("hộp mờ == scipy uniform_filter(mode='nearest') (sai số < 1e-4)", max(errs) < 1e-4, errs)
import cv2
img = rng.integers(0, 256, (20, 30, 3)).astype(np.uint8)
pts = [(float(rng.uniform(-2, 31)), float(rng.uniform(-2, 21))) for _ in range(200)]
mx = np.array([[p[0] for p in pts]], np.float32); my = np.array([[p[1] for p in pts]], np.float32)
ours = np.array([sample_rgb(img, *p) for p in pts]).astype(int)
exact = np.stack([np.floor(ndimage.map_coordinates(img[:, :, c].astype(float), [[p[1] for p in pts], [p[0] for p in pts]], order=1, mode="nearest") + 0.5)
                  for c in range(3)], 1).astype(int)
check("lấy mẫu song tuyến == scipy map_coordinates(order=1, mode='nearest') CHÍNH XÁC (lệch 0)", int(np.abs(ours - exact).max()) == 0)
cvr = cv2.remap(img, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)[0].astype(int)
check("so cv2.remap: lệch ≤ 5 mức (cv2 làm tròn toạ độ về 1/32 px nên không dùng làm tham chiếu chính xác)", int(np.abs(ours - cvr).max()) <= 5)

# bản nhanh (scipy) phải cho cùng kết quả bản port từng dòng (cảnh nhiều đốm + vùng bảo vệ)
yy, xx = np.mgrid[0:70, 0:90]
blobs = ((np.hypot(xx - 25, yy - 30) < 14) | (np.hypot(xx - 62, yy - 40) < 9)).astype(np.uint8) * 255
scene = np.stack([(xx * 2 + yy) % 256, (xx + yy * 3) % 256, (xx * 5) % 256], 2).astype(np.uint8)
protm = np.zeros((70, 90), np.uint8); protm[:, 70:] = 255
a_slow = apply(scene, blobs, protm, 1.0); a_fast = apply(scene, blobs, protm, 1.0, _fast=True)
dif = np.abs(a_slow.astype(int) - a_fast.astype(int))
check("bản nhanh (scipy) == bản port từng dòng trên cảnh nhiều đốm (≥ 99,5% điểm trùng, lệch tối đa ≤ 2 mức)",
      float((dif.max(2) == 0).mean()) >= 0.995 and int(dif.max()) <= 2, (float((dif.max(2) == 0).mean()), int(dif.max())))
check("cảnh nhiều đốm: có thay đổi thật (ít nhất 100 điểm đổi) nên phép so sánh có ý nghĩa", int((np.abs(a_slow.astype(int) - scene.astype(int)).max(2) > 0).sum()) > 100)

# ------------------------------------------------------------------ 2) đường cong dịch
g = 10.0; b = g * BAND_FACTOR
check("shiftAt = grow khi d ≤ grow; = 0 khi d ≥ band", all(abs(shift_at(F(d), F(g), F(b)) - g) < 1e-5 for d in (0, 3, 9.99, 10)) and shift_at(F(b), F(g), F(b)) == 0 and shift_at(F(b + 5), F(g), F(b)) == 0)
ds = [float(d) - float(shift_at(F(d), F(g), F(b))) for d in np.linspace(0, b + 5, 800)]
check("nguồn d - dịch(d) tăng NGHIÊM NGẶT (không gập, không nhân đôi nền)", all(ds[i + 1] > ds[i] for i in range(len(ds) - 1)))
check("mép tóc mới đúng tại d = grow (nguồn = 0) và liên tục tại d = band", abs(float(g) - float(g) - 0) < 1e-6 and abs(float(shift_at(F(g), F(g), F(b))) - g) < 1e-5 and abs(float(shift_at(F(b - 1e-3), F(g), F(b)))) < 1e-4)

# ------------------------------------------------------------------ 3) đĩa tóc: phồng đúng +grow
def disc_case(R=40, size=200, strength=0.5, tex=False):
    yy, xx = np.mgrid[0:size, 0:size]
    rr = np.hypot(xx - size / 2 + 0.5, yy - size / 2 + 0.5)
    hairm = (rr <= R)
    img = np.zeros((size, size, 3), np.uint8); img[:] = (210, 200, 190)
    img[hairm] = (30, 20, 10)
    if tex:
        img[hairm, 0] = (40 + 60 * (np.sin(xx[hairm] / 3.0) > 0)).astype(np.uint8)
    return img, (hairm * 255).astype(np.uint8), rr
img, hm, rr = disc_case()
out = apply(img, hm, None, 0.5, _fast=True)
grow = float(grow_px(200, 200, 0.5))             # 0.5 * 0.02 * 200 = 2 px
is_hair = (np.abs(out.astype(int) - np.array([30, 20, 10])).sum(2) < np.abs(out.astype(int) - np.array([210, 200, 190])).sum(2))
r_eff = math.sqrt(is_hair.sum() / math.pi)
check(f"đĩa R=40, grow={grow:.1f}px: bán kính hiệu dụng ≈ R+grow (lệch < 1 px)", abs(r_eff - (40 + grow)) < 1.0, f"{r_eff:.2f} vs {40 + grow}")
img2, hm2, rr2 = disc_case(R=40, size=300, strength=1.0)      # grow = 6 px, band = 15 px
out2 = apply(img2, hm2, None, 1.0, _fast=True)
g2 = float(grow_px(300, 300, 1.0))
is_hair2 = (np.abs(out2.astype(int) - np.array([30, 20, 10])).sum(2) < np.abs(out2.astype(int) - np.array([210, 200, 190])).sum(2))
check(f"đĩa R=40, grow={g2:.0f}px (cường độ 1): bán kính hiệu dụng ≈ R+grow (lệch < 1,2 px)", abs(math.sqrt(is_hair2.sum() / math.pi) - (40 + g2)) < 1.2, f"{math.sqrt(is_hair2.sum() / math.pi):.2f}")
inside = hm2 != 0
check("điểm ảnh TRONG tóc không đổi (nhị phân hóa mặt nạ ở 0,5 giữ nguyên đĩa)", bool((out2[inside] == img2[inside]).all()))
far = rr2 > 40 + g2 * BAND_FACTOR + 2
check("điểm ảnh NGOÀI dải ảnh hưởng không đổi", bool((out2[far] == img2[far]).all()))
check("alpha/kênh phụ giữ nguyên, không NaN, trong 0..255", out2.dtype == np.uint8 and out2.shape == img2.shape)
check("diện tích tóc tăng đúng hướng (không thu nhỏ)", is_hair2.sum() > hm2.astype(bool).sum() * 1.3)

# ------------------------------------------------------------------ 4) kết cấu tóc được kéo ra (lấy mẫu từ bên trong)
imgt, hmt, rrt = disc_case(R=40, size=300, strength=1.0, tex=True)
outt = apply(imgt, hmt, None, 1.0, _fast=True)
ring = (rrt > 41) & (rrt < 40 + g2 - 1)
red = outt[ring][:, 0].astype(int)
check("vành mới mang KẾT CẤU tóc (kênh đỏ biến thiên 40↔100 như bên trong, không phải màu nền phẳng)",
      red.min() < 70 and red.max() > 80 and (outt[ring][:, 1] < 60).mean() > 0.95, (red.min(), red.max()))

# ------------------------------------------------------------------ 5) vùng bảo vệ
img3, hm3, rr3 = disc_case(R=40, size=200, strength=1.0)
prot = np.zeros((200, 200), np.uint8); prot[:, :100] = 255        # nửa trái được bảo vệ
out3 = apply(img3, hm3, prot, 1.0, _fast=True)
g3 = float(grow_px(200, 200, 1.0))
r3 = max(1, 200 // 300)
left_far = (rr3 > 40 + 0.5) & (np.arange(200)[None, :] < 100 - (2 * r3 + 3))
check("vùng bảo vệ KHÔNG bị phủ tóc (nửa trái giữ nguyên)", bool((out3[left_far] == img3[left_far]).all()))
right = (rr3 > 40.5) & (rr3 < 40 + g3 - 0.5) & (np.arange(200)[None, :] > 100 + 2 * r3 + 3)
check("nửa phải (không bảo vệ) vẫn phồng", bool((np.abs(out3[right].astype(int) - np.array([30, 20, 10])).sum(1) < 60).mean() > 0.85))

# ------------------------------------------------------------------ 6) không làm gì / trường hợp biên
img4, hm4, _ = disc_case()
check("cường độ 0 -> không đổi", bool((apply(img4, hm4, None, 0.0) == img4).all()))
check("cường độ dưới ngưỡng (grow < 0,75 px) -> không đổi", bool((apply(img4, hm4, None, 0.1) == img4).all()))
check("mặt nạ rỗng -> không đổi", bool((apply(img4, np.zeros_like(hm4), None, 1.0) == img4).all()))
check("mặt nạ phủ kín -> không đổi", bool((apply(img4, np.full_like(hm4, 255), None, 1.0) == img4).all()))
check("cường độ NaN -> không đổi, không ném lỗi", bool((apply(img4, hm4, None, float("nan")) == img4).all()))
tiny = np.zeros((2, 2, 3), np.uint8)
check("ảnh quá nhỏ (2×2) -> không đổi, không ném lỗi", bool((apply(tiny, np.full((2, 2), 255, np.uint8), None, 1.0) == tiny).all()))
imgr, hmr = (rng.integers(0, 256, (60, 90, 3)).astype(np.uint8), np.where(rng.random((60, 90)) < 0.15, 255, 0).astype(np.uint8))
outr = apply(imgr, hmr, None, 1.0)
check("mặt nạ nhiễu ngẫu nhiên: chạy ổn, kích thước giữ nguyên, không ném lỗi", outr.shape == imgr.shape)
# mặt nạ răng cưa kiểu MediaPipe (nearest-neighbour từ ảnh nhỏ): biên gần tròn sau làm mịn
yy, xx = np.mgrid[0:240, 0:240]
small = (np.hypot(xx[::8, ::8] - 120, yy[::8, ::8] - 120) <= 40)                 # lưới thô 30×30
jag = np.kron(small, np.ones((8, 8), bool)).astype(np.uint8) * 255                # phóng nearest-neighbour
imgj = np.zeros((240, 240, 3), np.uint8); imgj[:] = (210, 200, 190); imgj[jag != 0] = (30, 20, 10)
outj = apply(imgj, jag, None, 1.0, _fast=True)
gj = float(grow_px(240, 240, 1.0))
isj = (np.abs(outj.astype(int) - np.array([30, 20, 10])).sum(2) < np.abs(outj.astype(int) - np.array([210, 200, 190])).sum(2))
check("mặt nạ răng cưa 8×8 vẫn phồng đúng hướng, diện tích tăng trong khoảng hợp lý (grow±)",
      jag.astype(bool).sum() < isj.sum() < math.pi * (40 + gj + 6) ** 2, isj.sum())

# ------------------------------------------------------------------ 7) đột biến: bộ kiểm tra phải bắt được
def disc_grows(**kw):
    o = apply(img2, hm2, None, 1.0, _fast=True, **kw)
    ih = (np.abs(o.astype(int) - np.array([30, 20, 10])).sum(2) < np.abs(o.astype(int) - np.array([210, 200, 190])).sum(2))
    return abs(math.sqrt(ih.sum() / math.pi) - (40 + g2)) < 1.2
check("đột biến: đảo dấu hướng lấy mẫu -> phép đo bán kính BỊ BẮT", not disc_grows(_flip=True))
check("đột biến: bỏ vùng bảo vệ -> kiểm tra vùng bảo vệ BỊ BẮT", not bool((apply(img3, hm3, prot, 1.0, _no_protect=True, _fast=True)[left_far] == img3[left_far]).all()))
with np.errstate(divide="ignore", invalid="ignore"):
    mutant_band = bool((apply(img2, hm2, None, 1.0, _band_factor=1.0, _fast=True) == out2).all())
check("đột biến: dải 1,0×grow (thay vì 2,5) -> kết quả KHÁC (bộ kiểm tra nhạy với độ rộng dải)", not mutant_band)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
