#!/usr/bin/env python3
"""Port Python của engine/ProTone.kt (R11): Highlights, Vibrance, Tint, Dehaze, Texture.
Kiểm các TÍNH CHẤT (đơn điệu, giữ sắc độ, giữ độ chói, khôi phục ảnh có sương mù tổng hợp...).
Lệch với Kotlin thì sửa cả hai. Cần numpy, scipy."""
import sys
import numpy as np
from scipy.ndimage import uniform_filter, minimum_filter

FAIL = []


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


def cl(v):
    return np.clip(np.floor(v + 0.5), 0, 255)


def lum(r, g, b):
    return 0.299 * r + 0.587 * g + 0.114 * b


# ---------------------------------------------------------------- Highlights (LUT giải tích)
def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def highlight_lut(a):
    v = max(-1.0, min(1.0, a))
    l = np.arange(256) / 255.0
    s_mid = smooth(0.45, 0.75, l)
    s_top = smooth(0.75, 1.0, l)
    shift = v * (0.14 * s_mid - 0.04 * s_top) if v < 0 else v * 0.12 * s_mid * (1 - s_top)
    return np.clip(l + shift, 0, 1) * 255.0


def highlights(img, a):
    if abs(a) < 0.005:
        return img
    lut = highlight_lut(a)
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    l = np.clip(np.floor(lum(r, g, b) + 0.5), 0, 255).astype(int)
    s = np.where(l > 0, lut[l] / np.maximum(l, 1), 1.0)
    mx = np.maximum(np.maximum(r, g), b) * s
    s = np.where(mx > 255, s * 255 / np.maximum(mx, 1e-9), s)
    out = np.stack([cl(r * s), cl(g * s), cl(b * s)], -1)
    return np.where((l == 0)[..., None], img, out)


# ---------------------------------------------------------------- Vibrance
def vibrance(img, a):
    if abs(a) < 0.005:
        return img
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    d = mx - mn
    ok = (mx > 0) & (d >= 1)
    dd = np.where(d > 0, d, 1)
    t_r = ((g - b) / dd)
    hue = np.where(mx == r, 60 * np.where(t_r < 0, t_r + 6, t_r),
                   np.where(mx == g, 60 * ((b - r) / dd + 2), 60 * ((r - g) / dd + 4)))
    s = np.where(mx > 0, d / np.maximum(mx, 1e-9), 0)
    if a > 0:
        dh = np.abs(hue - 25)
        dh = np.where(dh > 180, 360 - dh, dh)
        skin = 1 - smooth(10, 40, dh)
        f = a * 0.9 * (1 - s) * (1 - 0.55 * skin)
    else:
        f = a * (0.3 + 0.5 * s)
    gray = lum(r, g, b)
    k = 1 + f
    out = np.stack([cl(gray + (c - gray) * k) for c in (r, g, b)], -1)
    return np.where(ok[..., None], out, img)


# ---------------------------------------------------------------- Tint
def tint(img, a):
    if abs(a) < 0.005:
        return img
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    l = lum(r, g, b) / 255
    w = 0.6 + 0.4 * (1 - np.abs(2 * l - 1))
    d = a * 22 * w
    return np.stack([cl(r + 1.4213 * d), cl(g - d), cl(b + 1.4213 * d)], -1)


# ---------------------------------------------------------------- Dehaze
SIDE = 256
T0 = 0.25


def shrink(img):
    h, w, _ = img.shape
    f = max(1, (max(w, h) + SIDE - 1) // SIDE)
    sw, sh = max(1, w // f), max(1, h // f)
    out = img[:sh * f, :sw * f].reshape(sh, f, sw, f, 3).mean(axis=(1, 3)) / 255.0
    return out


def atmospheric_light(small_dark, small):
    n = small_dark.size
    order = np.argsort(-small_dark.reshape(-1), kind="stable")
    take = max(1, int(round(n * 0.005)))
    sel = small.reshape(-1, 3)[order[:take]].mean(axis=0)
    return np.maximum(0.55, sel)


def dehaze(img, a):
    if abs(a) < 0.005:
        return img
    h, w, _ = img.shape
    sm = shrink(img)
    sh, sw, _ = sm.shape
    dark0 = sm.min(axis=2)
    air = atmospheric_light(dark0, sm)
    if a < 0:
        k = -a * 0.55
        return cl(img * (1 - k) + air * 255 * k)
    norm = (sm / air).min(axis=2)
    rad = max(1, max(sw, sh) // 40)
    dark = minimum_filter(norm, size=2 * rad + 1, mode="nearest")
    omega = 0.95 * a
    t = np.clip(1 - omega * dark, T0, 1.0)
    t = uniform_filter(t, size=2 * max(1, rad) + 1, mode="nearest")
    ys = np.clip((np.arange(h) + 0.5) * sh / h - 0.5, 0, sh - 1)
    xs = np.clip((np.arange(w) + 0.5) * sw / w - 0.5, 0, sw - 1)
    y0 = ys.astype(int); y1 = np.minimum(sh - 1, y0 + 1); wy = (ys - y0)[:, None]
    x0 = xs.astype(int); x1 = np.minimum(sw - 1, x0 + 1); wx = (xs - x0)[None, :]
    tt = ((t[y0][:, x0] * (1 - wx) + t[y0][:, x1] * wx) * (1 - wy) +
          (t[y1][:, x0] * (1 - wx) + t[y1][:, x1] * wx) * wy)
    tc = np.maximum(T0, tt)[..., None]
    return cl(((img / 255.0 - air) / tc + air) * 255)


# ---------------------------------------------------------------- Texture
def gauss3(img, r):
    out = img.astype(np.float64)
    for _ in range(3):
        out = uniform_filter(out, size=(2 * r + 1, 2 * r + 1, 1), mode="nearest")
    return out


def texture_radius(w, h):
    return max(1, int(round(max(w, h) / 700.0)))


def texture(img, a):
    if abs(a) < 0.005:
        return img
    h, w, _ = img.shape
    bl = gauss3(img, texture_radius(w, h))
    d = lum(img[..., 0], img[..., 1], img[..., 2]) - lum(bl[..., 0], bl[..., 1], bl[..., 2])
    delta = a * 1.2 * d / (1 + np.abs(d) / 40) if a > 0 else a * 0.85 * d
    return cl(img + delta[..., None])


# ================================================================= kiểm tra
def sat_of(px):
    mx, mn = px.max(-1), px.min(-1)
    return np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-9), 0)


def main():
    rng = np.random.default_rng(7)

    # ---- Highlights
    check("highlights a=0 → LUT đồng nhất", np.allclose(highlight_lut(0.0), np.arange(256), atol=1e-9))
    for a in (-1.0, -0.5, 0.5, 1.0):
        lut = highlight_lut(a)
        check(f"highlights a={a}: LUT đơn điệu (bước ≥ 0.2)", np.diff(lut).min() >= 0.2, f"min step={np.diff(lut).min():.3f}")
        check(f"highlights a={a}: vùng tối/trung bình (≤ 0.45) giữ ĐÚNG đồng nhất",
              np.abs(lut[:115] - np.arange(115)).max() < 1e-6, f"max dev={np.abs(lut[:115]-np.arange(115)).max():.4f}")
    lo = highlight_lut(-1.0)
    check("highlights -1: đỉnh trắng hạ ~10% (255 → ~229.5)", abs(lo[255] - 229.5) < 0.5, f"lut[255]={lo[255]:.1f}")
    check("highlights -1: vùng sáng 191 hạ ≥ 30 mức", lo[191] < 191 - 30, f"lut[191]={lo[191]:.1f}")
    hi = highlight_lut(1.0)
    check("highlights +1: vùng sáng 191 sáng thêm ≥ 25 mức", hi[191] > 191 + 25, f"lut[191]={hi[191]:.1f}")
    check("highlights +1: trắng giữ 255", abs(hi[255] - 255) < 1e-6)
    check("highlights a=-0.5 nằm giữa 0 và -1", highlight_lut(-1.0)[200] < highlight_lut(-0.5)[200] < 200)

    px = np.array([[[240, 200, 160]]], dtype=np.float64)
    o = highlights(px, -1.0)[0, 0]
    rr = (px[0, 0] / px[0, 0].sum()) - (o / o.sum())
    check("highlights giữ tỉ lệ kênh (sắc độ)", np.abs(rr).max() < 0.01, f"in={px[0,0]} out={o}")
    check("highlights -1 làm tối pixel sáng", lum(*o) < lum(*px[0, 0]) - 8)
    px2 = np.array([[[255, 250, 240]]], dtype=np.float64)
    o2 = highlights(px2, 1.0)[0, 0]
    check("highlights +1 không vượt 255 và giữ thứ tự R≥G≥B", o2.max() <= 255 and o2[0] >= o2[1] >= o2[2], str(o2))
    black = np.zeros((1, 1, 3))
    check("highlights không đụng pixel đen", (highlights(black, -1.0) == 0).all())
    mid = np.array([[[100, 90, 80]]], dtype=np.float64)
    check("highlights không đụng vùng trung bình/tối", (highlights(mid, -1.0) == mid).all() and (highlights(mid, 1.0) == mid).all())

    # ---- Vibrance
    gray = np.full((1, 1, 3), 128.0)
    check("vibrance không đổi pixel xám", (vibrance(gray, 1.0) == gray).all())
    low = np.array([[[140, 130, 120]]], dtype=np.float64)       # s≈0.14, hue ~30 (cam) -> da
    low_blue = np.array([[[120, 130, 140]]], dtype=np.float64)  # s≈0.14, hue ~210
    vivid = np.array([[[220, 40, 40]]], dtype=np.float64)       # s≈0.82, hue 0
    d_low = sat_of(vibrance(low_blue, 1.0)) - sat_of(low_blue)
    d_vivid = sat_of(vibrance(vivid, 1.0)) - sat_of(vivid)
    check("vibrance +1: màu nhạt tăng bão hòa nhiều hơn màu đã rực (tỉ lệ)",
          (d_low / sat_of(low_blue)).item() > (d_vivid / sat_of(vivid)).item() * 3,
          f"nhạt +{(d_low/sat_of(low_blue)).item():.2f} rực +{(d_vivid/sat_of(vivid)).item():.2f}")
    skin_px = np.array([[[200, 150, 120]]], dtype=np.float64)   # hue ≈ 24°
    same_s = np.array([[[120, 150, 200]]], dtype=np.float64)    # cùng s, hue 215°
    ds_skin = (sat_of(vibrance(skin_px, 1.0)) - sat_of(skin_px)).item()
    ds_other = (sat_of(vibrance(same_s, 1.0)) - sat_of(same_s)).item()
    check("vibrance bảo vệ tông da (tăng ít hơn màu khác cùng bão hòa)", ds_skin < ds_other * 0.7,
          f"da +{ds_skin:.3f} khác +{ds_other:.3f}")
    for px_ in (low, low_blue, vivid, same_s):
        dl = abs(lum(*vibrance(px_, 1.0)[0, 0]) - lum(*px_[0, 0]))
        check("vibrance +1 giữ độ chói (≤ 2.5)", dl <= 2.5, f"Δ={dl:.2f}")
    neg = vibrance(vivid, -1.0)
    chroma = lambda p_: (p_.max(-1) - p_.min(-1)).item()
    ratio = chroma(neg) / chroma(vivid)   # đo chroma (HSV-S không tuyến tính vì max cũng giảm theo)
    check("vibrance -1 trên màu rực: chroma giảm mạnh nhưng KHÔNG về xám (còn 10–40%)", 0.10 <= ratio <= 0.40, f"còn {ratio:.2f}")
    check("vibrance âm giảm bão hòa", sat_of(vibrance(low_blue, -0.5)).item() < sat_of(low_blue).item())

    # ---- Tint
    mids = np.array([[[128, 128, 128]]], dtype=np.float64)
    tp = tint(mids, 1.0)[0, 0]
    check("tint +1: R,B tăng, G giảm (ngả tím)", tp[0] > 128 and tp[2] > 128 and tp[1] < 128, str(tp))
    tn = tint(mids, -1.0)[0, 0]
    check("tint -1: ngả xanh lá (G tăng, R,B giảm)", tn[1] > 128 and tn[0] < 128 and tn[2] < 128, str(tn))
    for v in (60, 128, 200):
        p_ = np.full((1, 1, 3), float(v))
        dl = abs(lum(*tint(p_, 1.0)[0, 0]) - v)
        check(f"tint giữ độ chói ở mức xám {v} (≤ 1.5)", dl <= 1.5, f"Δ={dl:.2f}")
    check("tint a=0 không đổi", (tint(mids, 0.0) == mids).all())

    # ---- Dehaze: cảnh tổng hợp (mỗi vùng cục bộ có điểm tối) bị phủ sương
    H = W = 128
    J = np.zeros((H, W, 3))
    blocks = rng.uniform(0, 1, (16, 16, 3))
    blocks[..., rng.integers(0, 3)] *= 0.1               # luôn có một kênh thấp (giả định DCP)
    for y in range(H):
        for x in range(W):
            c = blocks[y // 8, x // 8].copy()
            c[(y // 8 + x // 8) % 3] = rng.uniform(0, 0.08)   # kênh tối ở mọi khối
            J[y, x] = c
    J *= 255
    tmap = np.tile(np.linspace(0.45, 0.85, W), (H, 1))[..., None]
    A = np.array([0.86, 0.88, 0.92]) * 255
    I = cl(J * tmap + A * (1 - tmap))
    mse = lambda u, v: float(((u - v) ** 2).mean())
    e0 = mse(I, J)
    out = dehaze(I, 1.0)
    e1 = mse(out, J)
    check("dehaze +1 khôi phục ảnh có sương (MSE giảm ≥ 40%)", e1 < 0.6 * e0, f"MSE {e0:.0f} → {e1:.0f}")
    sd = lambda im: float(lum(im[..., 0], im[..., 1], im[..., 2]).std())
    check("dehaze +1 tăng tương phản", sd(out) > sd(I) * 1.15, f"std {sd(I):.1f} → {sd(out):.1f}")
    half = dehaze(I, 0.5)
    e_half = mse(half, J)
    check("dehaze: cường độ 0.5 nằm giữa 0 và 1", e1 < e_half < e0, f"{e1:.0f} < {e_half:.0f} < {e0:.0f}")
    check("dehaze a=0 không đổi", (dehaze(I, 0.0) == I).all())
    fog = dehaze(I, -1.0)
    check("dehaze âm giảm tương phản (thêm sương)", sd(fog) < sd(I) * 0.7, f"std {sd(I):.1f} → {sd(fog):.1f}")
    flat = np.full((64, 64, 3), 200.0)
    fo = dehaze(flat, 1.0)
    check("dehaze ảnh phẳng không phát nổ (trong 0..255, lệch ≤ 25)", np.isfinite(fo).all() and abs(fo.mean() - 200) <= 25,
          f"mean={fo.mean():.1f}")
    check("dehaze: độ lớn ảnh không phải bội 256 vẫn chạy", dehaze(rng.uniform(0, 255, (97, 131, 3)), 0.7).shape == (97, 131, 3))

    # ---- Texture
    noise = cl(128 + rng.normal(0, 12, (96, 96, 3)))
    hf = lambda im: float((lum(im[..., 0], im[..., 1], im[..., 2]) -
                           lum(*np.moveaxis(gauss3(im, 1), -1, 0))).std())
    t_up = texture(noise, 1.0)
    t_dn = texture(noise, -1.0)
    check("texture +1 tăng năng lượng chi tiết mịn ≥ 1.5×", hf(t_up) > hf(noise) * 1.5, f"{hf(noise):.2f} → {hf(t_up):.2f}")
    check("texture -1 giảm năng lượng chi tiết mịn ≥ 40%", hf(t_dn) < hf(noise) * 0.6, f"{hf(noise):.2f} → {hf(t_dn):.2f}")
    check("texture giữ độ sáng trung bình (≤ 1)", abs(t_up.mean() - noise.mean()) <= 1.0 and abs(t_dn.mean() - noise.mean()) <= 1.0)
    check("texture a=0 không đổi", (texture(noise, 0.0) == noise).all())
    step = np.full((32, 64, 3), 60.0)
    step[:, 32:] = 190.0          # hai mức trung bình để phép kẹp 0/255 không che mất độ lệch
    ts = texture(step, 1.0)
    delta = np.abs(ts - step).max()
    check("texture ở cạnh cứng: có tác dụng (|Δ| > 5) nhưng bị chặn quầng (|Δ| ≤ 48)", 5 < delta <= 48.5, f"max|Δ|={delta:.1f}")
    check("texture: bán kính tăng theo cỡ ảnh", texture_radius(1024, 768) == 1 and texture_radius(2048, 1536) == 3,
          f"{texture_radius(1024,768)}, {texture_radius(2048,1536)}")

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
