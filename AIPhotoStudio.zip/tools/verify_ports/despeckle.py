#!/usr/bin/env python3
"""Port Python của engine/Despeckle.kt (R12): xóa bụi / xước / sợi mảnh kiểu Dust & Scratches. Cần numpy."""
import sys
import numpy as np

FAIL = []


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


def params(w, h, strength):
    s = float(np.clip(strength, 0, 1))
    radius = min(8, max(1, int(np.floor(max(w, h) / 600.0 * (1 + 3 * s) + 0.5))))
    threshold = int(np.floor(30 - 20 * s + 0.5))
    return radius, threshold


def lum_int(img):
    r, g, b = img[..., 0].astype(int), img[..., 1].astype(int), img[..., 2].astype(int)
    return (r * 77 + g * 151 + b * 28) >> 8


def box_mean(lum, r):
    h, w = lum.shape
    pad = np.pad(lum, r, mode="edge").astype(np.int64)
    c = np.cumsum(np.cumsum(pad, 0), 1)
    c = np.pad(c, ((1, 0), (1, 0)))
    win = 2 * r + 1
    s = c[win:win + h, win:win + w] - c[0:h, win:win + w] - c[win:win + h, 0:w] + c[0:h, 0:w]
    return (s // (win * win)).astype(int)


def median_at(lum, x, y, r):
    h, w = lum.shape
    win = lum[max(0, y - r):min(h - 1, y + r) + 1, max(0, x - r):min(w - 1, x + r) + 1].ravel()
    return int(np.sort(win)[len(win) // 2])


def nearest_with_lum(lum, img, x, y, r, target):
    h, w = lum.shape
    best, best_d = None, 1 << 60
    for yy in range(max(0, y - r), min(h - 1, y + r) + 1):
        for xx in range(max(0, x - r), min(w - 1, x + r) + 1):
            d = abs(int(lum[yy, xx]) - target) * 16 + abs(xx - x) + abs(yy - y)
            if d < best_d:
                best_d, best = d, img[yy, xx]
    return best


def detect(img, radius, threshold):
    lum = lum_int(img)
    mb = box_mean(lum, radius)
    suspect = threshold // 2
    cand = np.argwhere(np.abs(lum - mb) > suspect)
    flagged = np.zeros(lum.shape, bool)
    for y, x in cand:
        if abs(int(lum[y, x]) - median_at(lum, x, y, radius)) > threshold:
            flagged[y, x] = True
    return flagged


def apply(img, strength):
    h, w, _ = img.shape
    if strength < 0.01 or w < 3 or h < 3:
        return img
    radius, threshold = params(w, h, strength)
    lum = lum_int(img)
    mb = box_mean(lum, radius)
    suspect = threshold // 2
    out = img.copy()
    for y, x in np.argwhere(np.abs(lum - mb) > suspect):
        med = median_at(lum, x, y, radius)
        if abs(int(lum[y, x]) - med) <= threshold:
            continue
        out[y, x] = nearest_with_lum(lum, img, x, y, radius, med)
    return out


def main():
    rng = np.random.default_rng(5)
    H, W = 400, 600
    yy, xx = np.mgrid[0:H, 0:W]
    # nền "da": gradient mượt + nhiễu nhẹ
    clean = np.zeros((H, W, 3))
    clean[..., 0] = 200 + 20 * np.sin(xx / 150.0)
    clean[..., 1] = 150 + 15 * np.cos(yy / 120.0)
    clean[..., 2] = 125 + 10 * np.sin((xx + yy) / 200.0)
    clean += rng.normal(0, 1.5, clean.shape)
    clean = np.clip(np.round(clean), 0, 255)

    # vùng kết cấu (lá) góc dưới trái, cạnh sắc ở giữa phải, thanh dày 9 px ở trên phải
    clean[300:390, 20:200] = np.clip(120 + rng.normal(0, 18, (90, 180, 3)), 0, 255)
    clean[150:250, 380:430] = 70
    clean[150:250, 430:480] = 180
    clean[20:120, 480:489] = 40           # thanh tối rộng 9 px (không được xóa)
    dirty = clean.copy()
    defect = np.zeros((H, W), bool)

    def paint(mask, val):
        dirty[mask] = val
        defect[mask] = True

    for (cy, cx) in ((60, 80), (100, 250), (200, 150), (120, 330), (250, 300), (40, 400)):   # 6 hạt bụi tối 2x2
        m = np.zeros((H, W), bool); m[cy:cy + 2, cx:cx + 2] = True
        paint(m, np.array([90.0, 70.0, 60.0]))
    m = np.zeros((H, W), bool); m[30:110, 300] = True                                         # vết xước sáng 1 px
    paint(m, np.array([255.0, 250.0, 245.0]))
    for x in range(40, 260):                                                                  # sợi tóc tối cong, rộng 2 px
        y = int(220 + 25 * np.sin(x / 22.0))
        m = np.zeros((H, W), bool); m[y:y + 2, x] = True
        paint(m, np.array([60.0, 45.0, 40.0]))

    near_defect = np.zeros((H, W), bool)
    for dy in range(-6, 7):
        for dx in range(-6, 7):
            near_defect |= np.roll(np.roll(defect, dy, 0), dx, 1)
    far_smooth = (~near_defect)
    far_smooth[290:395, 15:205] = False       # loại vùng kết cấu
    far_smooth[140:260, 370:490] = False      # loại cạnh sắc
    far_smooth[10:130, 470:500] = False       # loại thanh dày (góc lồi bị bo tròn là bản chất của lọc trung vị)

    def rms(a, b, m):
        return float(np.sqrt(((a[m] - b[m]) ** 2).mean()))

    e0 = rms(dirty, clean, defect)
    for s in (0.5, 1.0):
        out = apply(dirty, s)
        e1 = rms(out, clean, defect)
        check(f"strength={s}: sai số tại điểm hỏng giảm ≥ 85%", e1 < 0.15 * e0, f"RMS {e0:.1f} → {e1:.1f}  (r,thr={params(W, H, s)})")
        diff_smooth = np.abs(out - dirty)[far_smooth].mean()
        check(f"strength={s}: vùng mịn xa điểm hỏng gần như không đổi (< 0.05)", diff_smooth < 0.05, f"{diff_smooth:.4f}")
        # THÂN cạnh/thanh phải nguyên vẹn; chỉ GÓC LỒI (nhỏ hơn bán kính) được phép bị bo tròn
        edge_body = np.abs(out[165:235, 372:488] - dirty[165:235, 372:488]).max()
        check(f"strength={s}: thân cạnh sắc 70↔180 giữ nguyên tuyệt đối", edge_body == 0, f"max|Δ|={edge_body}")
        bar_body = np.abs(out[40:100, 470:500] - dirty[40:100, 470:500]).max()
        check(f"strength={s}: thân thanh dày 9 px giữ nguyên tuyệt đối", bar_body == 0, f"max|Δ|={bar_body}")
        corner_changed = (np.abs(out[10:130, 470:500] - dirty[10:130, 470:500]).max(-1) > 0).mean()
        check(f"strength={s}: thanh dày chỉ đổi ở góc (< 2% diện tích vùng)", corner_changed < 0.02, f"{corner_changed*100:.2f}%")

    # vùng kết cấu bị ảnh hưởng thế nào (ghi nhận giới hạn thật, không giấu)
    tex_before = dirty[300:390, 20:200].std()
    tex_half = apply(dirty, 0.5)[300:390, 20:200].std()
    tex_low = apply(dirty, 0.15)[300:390, 20:200].std()
    check("kết cấu σ=18 ở cường độ thấp (0.15) còn ≥ 75% độ biến thiên", tex_low >= 0.75 * tex_before, f"{tex_before:.1f} → {tex_low:.1f}")
    print(f"INFO kết cấu ở cường độ 0.5 còn {tex_half / tex_before * 100:.0f}% (xóa bụi mạnh sẽ làm mịn kết cấu → nên dùng vùng tô/phạm vi 'Da')")

    # đặc tính khác
    check("strength=0 trả nguyên ảnh", apply(dirty, 0.0) is dirty)
    check("ảnh sạch không bị đổi (strength 0.5)", (apply(clean[:200, :300].copy(), 0.5) == clean[:200, :300]).mean() > 0.999)
    check("màu thay thế là màu có thật trong ảnh (không pha trộn)",
          all(tuple(apply(dirty[40:80, 60:100], 1.0)[2, 2]) in {tuple(p) for p in dirty[40:80, 60:100].reshape(-1, 3)} for _ in (0,)))
    fl = detect(dirty, *params(W, H, 0.5))
    hit = (fl & defect).sum() / defect.sum()
    false_pos = (fl & ~near_defect & far_smooth).sum()
    check("detect: bắt ≥ 90% điểm hỏng thật", hit >= 0.9, f"{hit*100:.0f}%")
    check("detect: không báo nhầm ở vùng mịn xa điểm hỏng", false_pos == 0, str(false_pos))
    check("params: bán kính và ngưỡng đơn điệu theo cường độ", params(W, H, 0.2)[0] <= params(W, H, 1.0)[0] and params(W, H, 0.2)[1] > params(W, H, 1.0)[1])
    check("params: ảnh nhỏ vẫn có bán kính ≥ 1", params(80, 60, 1.0)[0] == 1)
    check("params: ảnh rất lớn bị chặn bán kính ≤ 8", params(12000, 9000, 1.0)[0] == 8)
    tiny = np.zeros((2, 2, 3))
    check("ảnh quá nhỏ (2x2) trả nguyên", apply(tiny, 1.0) is tiny)

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
