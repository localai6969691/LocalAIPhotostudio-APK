#!/usr/bin/env python3
"""R36 - kiểm bộ tóm tắt báo cáo Compose compiler (tools/compose_report_summary.py) trên một báo cáo GIẢ theo định dạng trong tài liệu developer.android.com,
và kiểm cấu hình Gradle / workflow cho đường đo hiệu năng. Chạy: python3 tools/verify_ports/compose_report_summary.py"""
import importlib.util, os, re, sys, tempfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
spec = importlib.util.spec_from_file_location("crs", os.path.join(ROOT, "tools", "compose_report_summary.py"))
crs = importlib.util.module_from_spec(spec); spec.loader.exec_module(crs)
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok: fails.append(name)

CSV = "package,name,composable,skippable,restartable,readonly,inline,isLambda,hasDefaults,defaultsGroup,groups,calls\n" \
      "com.x,EditorScreen,1,0,1,0,0,0,0,0,40,30\n" \
      "com.x,Panel,1,1,1,0,0,0,0,0,5,2\n" \
      "com.x,Helper,1,0,1,0,0,0,1,0,3,1\n" \
      "com.x,<anonymous>,1,0,1,0,0,1,0,0,1,0\n" \
      "com.x,notComposable,0,0,0,0,0,0,0,0,0,0\n"
TXT = 'restartable scheme("[androidx.compose.ui.UiComposable]") fun EditorScreen(\n  stable vm: MainViewModel\n  unstable st: UiState\n  unstable items: List<String>\n)\n' \
      'restartable skippable scheme("[androidx.compose.ui.UiComposable]") fun Panel(\n  stable title: String\n)\n' \
      'restartable scheme("[androidx.compose.ui.UiComposable]") fun Helper(\n  stable n: Int = @static 1\n)\n'
CLS = "unstable class UiState {\n  stable val prompt: String\n  unstable val layers: List<EditLayer>\n  unstable val before: Bitmap?\n  <runtime stability> = Unstable\n}\nstable class Point {\n  stable val x: Int\n}\n"
with tempfile.TemporaryDirectory() as d:
    for n, t in (("app_perf-composables.csv", CSV), ("app_perf-composables.txt", TXT), ("app_perf-classes.txt", CLS), ("app_perf-module.json", "{}")):
        open(os.path.join(d, n), "w", encoding="utf-8").write(t)
    out = crs.summarize(d)
    check("đếm: 3 composable (bỏ lambda và không-composable), 1 skippable, 2 không skippable", "**3**" in out and "skippable): **1**" in out and "**2**" in out, out)
    check("liệt kê EditorScreen với tham số không ổn định st và items", "`EditorScreen` — tham số không ổn định: st, items" in out, out)
    check("composable skippable (Panel) KHÔNG bị liệt kê là vấn đề", "`Panel`" not in out, out)
    check("Helper (không skippable, không tham số unstable) vẫn được nêu kèm gợi ý", "`Helper`" in out and "không có tham số 'unstable'" in out, out)
    check("lớp unstable UiState kèm trường layers / before; lớp stable không có mặt", "`UiState` — trường: layers: List<EditLayer>; before: Bitmap?" in out and "Point" not in out, out)
    check("EditorScreen xếp trước Helper (nhiều tham số unstable hơn)", out.index("`EditorScreen`") < out.index("`Helper`"))
check("thư mục không tồn tại ⇒ thông báo, không văng", "Không thấy thư mục" in crs.summarize("/không/có/thư/mục"))
with tempfile.TemporaryDirectory() as d:
    check("thư mục rỗng ⇒ thông báo, không văng", "không có tệp" in crs.summarize(d))
    open(os.path.join(d, "x-composables.csv"), "w").write("rác,rác\n1,2\n")
    open(os.path.join(d, "x-composables.txt"), "w").write("dòng lạ\n  unstable mồ côi: X\n")
    open(os.path.join(d, "x-classes.txt"), "w").write("???\n")
    check("tệp báo cáo hỏng / lạ ⇒ không văng", isinstance(crs.summarize(d), str))

# ---- cấu hình Gradle + workflow
gr = open(os.path.join(ROOT, "app", "build.gradle.kts"), encoding="utf-8").read()
wf = open(os.path.join(ROOT, ".github", "workflows", "build-apk.yml"), encoding="utf-8").read()
check('Gradle: có buildType "perf" không debuggable, ký bằng khóa debug cố định, initWith(release)',
      re.search(r'create\("perf"\)\s*\{[^}]*initWith\(getByName\("release"\)\)[^}]*isDebuggable = false[^}]*signingConfigs\.getByName\("debug"\)', gr, re.S) is not None)
check("Gradle: perf chỉ bật R8 khi -PperfMinify=true (mặc định tắt), có proguardFiles chỉ trong nhánh đó",
      'val perfMinify = project.findProperty("perfMinify") == "true"' in gr and "isMinifyEnabled = perfMinify" in gr
      and re.search(r'create\("perf"\)\s*\{[^}]*isMinifyEnabled\s*=\s*true', gr, re.S) is None
      and "if (perfMinify) proguardFiles(" in gr)
check("Có app/proguard-rules.pro với luật cho ONNX Runtime và MediaPipe, không làm rối tên",
      os.path.exists(os.path.join(ROOT, "app", "proguard-rules.pro")) and all(x in open(os.path.join(ROOT, "app", "proguard-rules.pro"), encoding="utf-8").read() for x in ("-dontobfuscate", "ai.onnxruntime.**", "com.google.mediapipe.**")))
check("Gradle: lint không chặn build biến thể không debuggable", "checkReleaseBuilds = false" in gr)
check("Gradle: cờ báo cáo Compose chỉ bật khi -PcomposeCompilerReports=true, mỗi cờ MỘT lần",
      'findProperty("composeCompilerReports") == "true"' in gr and gr.count("reportsDestination=") == 1 and gr.count("metricsDestination=") == 1)
m = re.search(r"\n  build-perf:\n(.*?)(?=\n  [a-z][a-z0-9-]*:\n|\Z)", wf, re.S)
check("Workflow: có job build-perf", m is not None)
if m:
    job = m.group(1)
    check("Workflow: build-perf KHÔNG chặn (continue-on-error) và chạy kể cả khi job khác lỗi", "continue-on-error: true" in job and "!cancelled()" in job)
    check("Workflow: build-perf dựng assemblePerf với báo cáo Compose", ":app:assemblePerf" in job and "-PcomposeCompilerReports=true" in job)
    check("Workflow: bước R8 chỉ chạy khi bật input perf_r8, không chặn, và luôn tải chẩn đoán missing_rules.txt",
          "github.event.inputs.perf_r8 == 'true'" in job and "-PperfMinify=true" in job and "perf-r8-diagnostics" in job and "missing_rules.txt" in job
          and re.search(r"id: perf_r8\s+if:[^\n]*\n\s+continue-on-error: true", job) is not None)
    check("Workflow: build-perf tải lên APK perf và báo cáo", "AIPhotoStudio-perf-apk" in job and "app/build/outputs/apk/perf/*.apk" in job and "compose-compiler-reports" in job)
    check("Workflow: build-perf ghi tóm tắt vào bước tóm tắt của run", "compose_report_summary.py" in job and "GITHUB_STEP_SUMMARY" in job)
print()
if fails:
    print(f"TỔNG: {len(fails)} KIỂM TRA HỎNG"); sys.exit(1)
print("TẤT CẢ OK")
