#!/usr/bin/env python3
"""
R18 - Kiểm tra chính sách thử NPU TRUNG LẬP theo hãng chip (ai/AcceleratorPolicy.kt + litertlmReal/*).
  * bản port quy tắc: chỉ thử NPU khi sdk ≥ 31 && có arm64-v8a && tên tệp .litertlm kết thúc bằng _<ro.soc.model viết thường>.litertlm
  * dùng ĐÚNG tên tệp trong tài liệu LiteRT-LM (09/2026): Qualcomm sm8750/sm8650/sm8550, MediaTek mt6989/mt6991, Google Tensor tensor_g6
  * mỗi tệp chỉ khớp ĐÚNG SoC của nó; model chung không bao giờ kích hoạt NPU; ngưỡng API/ABI; biên (rỗng, unknown, hoa/thường, thiếu tên model)
  * NGUYÊN TẮC "KHÔNG HARDCODE": mã (đã bỏ chú thích và chuỗi) của các tệp NPU KHÔNG được nêu tên hãng/chip nào
  * bố cục thử: NPU chỉ khi tryNpu, rồi GPU+ảnh, GPU, CPU; mỗi nấc ghi tên bộ tăng tốc
  * hằng số đọc TỪ Kotlin; đột biến phải bị bắt
Chạy: python3 tools/verify_ports/accelerator_policy.py
"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src")
POL = os.path.join(ROOT, "main", "java", "com", "aiphoto", "studio", "ai", "AcceleratorPolicy.kt")
REAL = os.path.join(ROOT, "litertlmReal", "java", "com", "aiphoto", "studio", "ai")
src = open(POL, encoding="utf-8").read()
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok: fails.append(name)

MIN_SDK = int(re.search(r"const val MIN_NPU_SDK = (\d+)", src).group(1))
NPU_ABI = re.search(r'const val NPU_ABI = "([^"]+)"', src).group(1)
EXT = re.search(r'const val EXT = "([^"]+)"', src).group(1)

# ------------------------------------------------------------------ bản dịch Kotlin
def normalize_soc(s):
    s = (s or "").strip().lower()
    return "" if s == "unknown" else s
def compiled_for(file_name, soc, _no_underscore=False, _anywhere=False):
    soc = normalize_soc(soc)
    if file_name is None or soc == "": return False
    suffix = ("" if _no_underscore else "_") + soc + EXT
    n = file_name.strip().lower()
    if _anywhere: return soc in n
    return n.endswith(suffix) and len(n) > len(suffix)
def may_use_npu(sdk, abis, file_name, soc, _skip_sdk=False):
    return (_skip_sdk or sdk >= MIN_SDK) and any(a == NPU_ABI for a in abis) and compiled_for(file_name, soc)

check("hằng số đọc từ Kotlin: API 31, arm64-v8a, .litertlm", (MIN_SDK, NPU_ABI, EXT) == (31, "arm64-v8a", ".litertlm"), (MIN_SDK, NPU_ABI, EXT))

# ------------------------------------------------------------------ tên tệp thật trong tài liệu LiteRT-LM (cập nhật 09/2026)
FILES = {   # tên tệp -> SoC (Build.SOC_MODEL / ro.soc.model) mà nó được biên dịch cho
    "Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm": "SM8750", "Gemma3-1B-IT_q4_ekv1280_sm8650.litertlm": "SM8650", "Gemma3-1B-IT_q4_ekv1280_sm8550.litertlm": "SM8550",
    "Gemma3-1B-IT_q4_ekv1280_mt6989.litertlm": "MT6989", "Gemma3-1B-IT_q4_ekv1280_mt6991.litertlm": "MT6991",
    "gemma-4-E2B-it_Google_tensor_g6.litertlm": "Tensor_G6",
}
ARM = ["arm64-v8a", "armeabi-v7a"]
ok_all = all(may_use_npu(34, ARM, f, soc) for f, soc in FILES.items())
check("mỗi tệp trong tài liệu (Qualcomm, MediaTek, Google Tensor) được thử NPU trên ĐÚNG SoC của nó", ok_all)
cross = [(f, soc2) for f, soc in FILES.items() for soc2 in FILES.values() if soc2 != soc and may_use_npu(34, ARM, f, soc2)]
check(f"không tệp nào khớp SoC KHÁC (kể cả khác hãng): {len(FILES) * (len(FILES) - 1)} cặp chéo đều bị từ chối", not cross, cross)
generic = ["gemma-4-E2B-it.litertlm", "Gemma3-1B-IT_q4_ekv1280.litertlm", "gemma-3n-E2B-it.litertlm", "model.litertlm", "llm.litertlm", "Gemma3-1B-IT_q4.litertlm"]
check("model CHUNG (không có hậu tố SoC khớp) KHÔNG bao giờ thử NPU trên mọi SoC trong danh sách",
      not any(may_use_npu(34, ARM, f, soc) for f in generic for soc in FILES.values()))

# ------------------------------------------------------------------ điều kiện nền và biên
f0, s0 = "Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm", "SM8750"
check("API < 31 -> không thử NPU (minSdk dự án là 26)", not may_use_npu(30, ARM, f0, s0) and not may_use_npu(26, ARM, f0, s0) and may_use_npu(31, ARM, f0, s0))
check("không có arm64-v8a -> không thử NPU", not may_use_npu(34, ["armeabi-v7a", "x86_64"], f0, s0) and not may_use_npu(34, [], f0, s0))
check("SoC rỗng / 'unknown' / None -> không thử NPU", not any(may_use_npu(34, ARM, f0, s) for s in ("", " ", "unknown", "UNKNOWN", None)))
check("tên tệp None / rỗng -> không thử NPU", not may_use_npu(34, ARM, None, s0) and not may_use_npu(34, ARM, "", s0))
check("không phân biệt hoa/thường và bỏ khoảng trắng thừa", may_use_npu(34, ARM, "  GEMMA3-1B-IT_Q4_EKV1280_SM8750.LITERTLM ", " sm8750 "))
check("tệp chỉ gồm '_<soc>.litertlm' (thiếu tên model) -> từ chối", not may_use_npu(34, ARM, "_sm8750.litertlm", s0))
check("thiếu dấu '_' trước SoC (xsm8750) -> từ chối", not may_use_npu(34, ARM, "Gemma3-1B-IT_xsm8750.litertlm", s0) and not may_use_npu(34, ARM, "Gemma3-1B-IT-sm8750.litertlm", s0))
# GIỚI HẠN ĐÃ BIẾT (đo thật, không che): một máy GIẢ ĐỊNH báo SoC chỉ là "g6" sẽ khớp tệp ..._tensor_g6.litertlm vì hậu tố trùng. Không xảy ra với máy thật
# (ro.soc.model là chuỗi đầy đủ, vd. Tensor_G6) và hai tệp NPU vẫn không chạy được trên chip lạ (khởi tạo NPU lỗi -> báo lỗi rõ), nên chấp nhận và ghi nhận.
check("giới hạn đã biết: SoC 'g6' (không có trong thực tế) khớp hậu tố của tệp tensor_g6; SoC đầy đủ 'Tensor_G6' khớp đúng; 'Tensor_G5' không khớp tệp G6",
      may_use_npu(34, ARM, "gemma-4-E2B-it_Google_tensor_g6.litertlm", "g6") and may_use_npu(34, ARM, "gemma-4-E2B-it_Google_tensor_g6.litertlm", "Tensor_G6")
      and not may_use_npu(34, ARM, "gemma-4-E2B-it_Google_tensor_g6.litertlm", "Tensor_G5"))
check("đuôi không phải .litertlm (.task, .bin) -> từ chối", not may_use_npu(34, ARM, "Gemma3-1B-IT_q4_ekv1280_sm8750.task", s0))
check("SoC có ký tự đặc biệt không gây lỗi / khớp nhầm kiểu regex", not may_use_npu(34, ARM, f0, "sm.*") and not may_use_npu(34, ARM, f0, "sm8750|sm8650"))

# ------------------------------------------------------------------ NGUYÊN TẮC KHÔNG HARDCODE
def strip(s):
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S)
    s = re.sub(r"//[^\n]*", " ", s)
    s = re.sub(r'"""(?:.|\n)*?"""', '""', s)
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
VENDORS = re.compile(r"qualcomm|snapdragon|qnn|hexagon|htp|mediatek|dimensity|neuropilot|exynos|samsung|google\s*tensor|tensor_g|pixel|intel|openvino", re.I)
code_files = {"AcceleratorPolicy.kt": src, **{f: open(os.path.join(REAL, f), encoding="utf-8").read() for f in ("LiteRtLmFactory.kt", "LiteRtLmTextGen.kt")}}
leaks = {n: sorted(set(m.group(0).lower() for m in VENDORS.finditer(strip(t)))) for n, t in code_files.items()}
check("MÃ (đã bỏ chú thích và chuỗi) của AcceleratorPolicy / LiteRtLmFactory / LiteRtLmTextGen KHÔNG nêu tên hãng chip nào", not any(leaks.values()), leaks)

# ------------------------------------------------------------------ bố cục các nấc thử
gen = open(os.path.join(REAL, "LiteRtLmTextGen.kt"), encoding="utf-8").read()
body = gen[gen.index("fun open("):]
order = re.findall(r"attempts\.add\(Triple\(\{ EngineConfig\(modelPath = modelPath, backend = (Backend\.\w+)\(", body)
names = re.findall(r"\}, (?:true|false), \"(\w+)\"\)\)", body)
check("thứ tự nấc: NPU (chỉ khi tryNpu) -> GPU(+ảnh) -> GPU -> CPU", order == ["Backend.NPU", "Backend.GPU", "Backend.GPU", "Backend.CPU"] and names == ["NPU", "GPU", "GPU", "CPU"], (order, names))
check("nấc NPU nằm TRONG khối `if (tryNpu)` (model chung không bao giờ vào)", re.search(r"if \(tryNpu\) \{\s*attempts\.add\(Triple\(\{ EngineConfig\(modelPath = modelPath, backend = Backend\.NPU", body) is not None)
check("factory truyền Build.VERSION.SDK_INT, Build.SUPPORTED_ABIS, tên gốc và Build.SOC_MODEL cho chính sách",
      all(k in code_files["LiteRtLmFactory.kt"] for k in ("Build.VERSION.SDK_INT", "Build.SUPPORTED_ABIS", "modelName", "Build.SOC_MODEL", "mayUseNpu")))

# ------------------------------------------------------------------ đột biến
check("đột biến: bỏ yêu cầu dấu '_' -> ca 'xsm8750/-sm8750' BỊ BẮT",
      compiled_for("Gemma3-1B-IT_xsm8750.litertlm", "SM8750", _no_underscore=True) and not compiled_for("Gemma3-1B-IT_xsm8750.litertlm", "SM8750"))
check("đột biến: khớp 'chứa SoC' thay vì 'kết thúc bằng _soc.litertlm' -> BỊ BẮT (tệp chung có chứa chuỗi SoC ở giữa tên bị khớp nhầm)",
      compiled_for("my_sm8750_notes_generic.litertlm", "sm8750", _anywhere=True) and not compiled_for("my_sm8750_notes_generic.litertlm", "sm8750"))
check("đột biến: bỏ ngưỡng API 31 -> ca API 30 BỊ BẮT", may_use_npu(30, ARM, f0, s0, _skip_sdk=True) and not may_use_npu(30, ARM, f0, s0))

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
