#!/usr/bin/env python3
"""
Kiểm tra tools/convert_models/onnx_static_qdq.py (lượng tử hóa TĨNH QDQ không cần gói `onnx`) bằng ONNX RUNTIME THẬT:
  * model nén nạp được, sai khác nhỏ trên cả mẫu hiệu chuẩn lẫn mẫu CHƯA thấy;
  * ORT thực sự fuse thành toán tử int8 (QLinearConv / QLinearMatMul) — nghĩa là định dạng QDQ đúng chuẩn, không chỉ mô phỏng;
  * trọng số int8 theo kênh, bias int32, tham số kích hoạt uint8 (khoảng luôn chứa 0, số 0 biểu diễn chính xác);
  * Conv -> Relu quantize SAU Relu (không chèn Q/DQ giữa), đầu ra cuối của đồ thị giữ float, tensor dùng chung chỉ có MỘT cặp Q/DQ;
  * đột biến: zero-point = 0, bỏ nối lại đầu vào, bias sai thang -> phải bị bắt.
Chạy: python3 tools/verify_ports/onnx_static_qdq.py   (bỏ qua có thông báo nếu thiếu onnxruntime)
"""
import os
import sys
import tempfile

import numpy as np

try:
    import onnxruntime as ort
except ImportError:
    print("BỎ QUA: chưa cài onnxruntime (pip install onnxruntime) nên không kiểm được công cụ QDQ")
    sys.exit(0)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "convert_models"))
import onnx_static_qdq as sq  # noqa: E402
import onnx_weight_quant as q  # noqa: E402

fails = []


def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)


def run(model, feeds):
    so = ort.SessionOptions()
    so.log_severity_level = 3
    return ort.InferenceSession(model, so, providers=["CPUExecutionProvider"]).run(None, feeds)[0]


rng = np.random.default_rng(5)
F = lambda a: np.asarray(a, dtype="<f4").tobytes()


def init(name, arr):
    return q.make_tensor(name, arr.shape, q.FLOAT, F(arr))


def cnn(opset=13, dyn_batch=False):
    W1 = rng.normal(0, 0.2, (32, 3, 3, 3)).astype("f4"); B1 = rng.normal(0, 0.1, 32).astype("f4")
    W2 = rng.normal(0, 0.1, (64, 32, 3, 3)).astype("f4"); B2 = rng.normal(0, 0.1, 64).astype("f4")
    W3 = rng.normal(0, 0.1, (64, 128)).astype("f4"); B3 = rng.normal(0, 0.1, 128).astype("f4")
    W4 = rng.normal(0, 0.1, (10, 128)).astype("f4"); B4 = rng.normal(0, 0.1, 10).astype("f4")
    pads = [q.make_attr_ints("pads", [1, 1, 1, 1])]
    nodes = [q.make_node("Conv", ["x", "W1", "B1"], ["c1"], "conv1", pads), q.make_node("Relu", ["c1"], ["r1"], "relu1"),
             q.make_node("Conv", ["r1", "W2", "B2"], ["c2"], "conv2", pads), q.make_node("Relu", ["c2"], ["r2"], "relu2"),
             q.make_node("GlobalAveragePool", ["r2"], ["gp"], "gap"), q.make_node("Flatten", ["gp"], ["fl"], "flat", [q.make_attr_int("axis", 1)]),
             q.make_node("MatMul", ["fl", "W3"], ["m"], "mm"), q.make_node("Add", ["m", "B3"], ["a"], "add"), q.make_node("Relu", ["a"], ["ra"], "relu3"),
             q.make_node("Gemm", ["ra", "W4", "B4"], ["y"], "gemm", [q.make_attr_int("transB", 1)])]
    inits = [init(n, v) for n, v in (("W1", W1), ("B1", B1), ("W2", W2), ("B2", B2), ("W3", W3), ("B3", B3), ("W4", W4), ("B4", B4))]
    b = "N" if dyn_batch else 1
    return q.make_model(nodes, inits, [q.make_value_info("x", q.FLOAT, [b, 3, 16, 16])], [q.make_value_info("y", q.FLOAT, [b, 10])], opset=opset)


def samples(n, batch=1, shape=(3, 16, 16), seed=1):
    r = np.random.default_rng(seed)
    return [{"x": r.random((batch,) + shape).astype("f4")} for _ in range(n)]


base = cnn()
calib = samples(16)
out, rep = sq.quantize_static(base, calib)
held = samples(10, seed=99)                    # mẫu KHÔNG nằm trong tập hiệu chuẩn
cos = [q.metrics(run(base, h), run(out, h))["cos"] for h in held]
check("QDQ tĩnh: 4 nút Conv/MatMul/Gemm được quantize, không bỏ qua nút nào", rep["targets"] == 4 and not rep["skipped"], rep["skipped"])
check("model QDQ nạp được và gần bản gốc trên 10 mẫu CHƯA thấy (cos >= 0.999)", min(cos) >= 0.999, min(cos))
check("cỡ tệp giảm >= 60 %", rep["bytes_out"] <= 0.4 * rep["bytes_in"], rep["bytes_out"] / rep["bytes_in"])
with tempfile.TemporaryDirectory() as td:
    ops = sq.fused_ops(out, td)
check("ORT fuse được toán tử int8 thật: 2 QLinearConv + >= 1 QLinearMatMul (định dạng QDQ đúng chuẩn, không chỉ mô phỏng)", ops.get("QLinearConv", 0) == 2 and ops.get("QLinearMatMul", 0) >= 1, ops)
check("đầu ra cuối của đồ thị (y) giữ float: không có cặp Q/DQ treo", out.count(b"y_quantized") == 0)
check("Conv -> Relu: Q/DQ đặt SAU Relu (r1, r2), KHÔNG đặt giữa Conv và Relu (c1, c2)", b"r1_quantized" in out and b"r2_quantized" in out and b"c1_quantized" not in out and b"c2_quantized" not in out)
check("tensor đầu vào đồ thị (x) có đúng MỘT cặp Q/DQ", out.count(b"x_QuantizeLinear") >= 1 and out.count(b"x_quantized") >= 2)

# kiểu dữ liệu: int8 theo kênh, int32 bias, uint8 kích hoạt
a = sq.analyse(out)
types = {}
for n, v in a["inits"].items():
    f = q.parse(v)
    types[n] = (q._int(f, 2), [d for fno, w, d in f if fno == 1])
check("trọng số int8 (data_type 3) theo kênh, bias int32 (6), zero-point kích hoạt uint8 (2)",
      types["W2_int8"][0] == 3 and types["W2_scale"][1] == [64] and types["B2_int32"][0] == 6 and types["x_zp"][0] == 2 and types["x_scale"][0] == 1, types.get("B2_int32"))

# tham số kích hoạt
bad = 0
for lo, hi in [(0, 1), (-1, 1), (-3.7, 0.2), (0.5, 4.0), (-5, -1), (0, 0), (1e-9, 2e-9)]:
    sc, zp = sq.act_qparams(lo, hi)
    deq0 = (np.clip(np.rint(0 / float(sc)) + zp, 0, 255) - zp) * float(sc)
    xs = np.linspace(min(lo, 0), max(hi, 0), 101)
    rt = (np.clip(np.rint(xs / float(sc)) + zp, 0, 255) - zp) * float(sc)
    if not (0 <= zp <= 255 and deq0 == 0 and np.abs(rt - xs).max() <= float(sc) / 2 + 1e-7 * max(1, abs(hi))):
        bad += 1
check("act_qparams: khoảng luôn chứa 0, zero-point trong [0,255], số 0 biểu diễn CHÍNH XÁC, sai số quay vòng <= scale/2 (7 khoảng)", bad == 0, bad)
full = []
for lo, hi in [(-0.9, 1.3), (-3.7, 0.2), (0.0, 4.0), (-5.0, 0.0)]:
    sc, zp = sq.act_qparams(lo, hi)
    qhi = int(np.clip(np.rint(hi / float(sc)) + zp, 0, 255)); qlo = int(np.clip(np.rint(lo / float(sc)) + zp, 0, 255))
    full.append(qhi == 255 and qlo == 0)
check("act_qparams dùng ĐỦ 256 mức: cận trên -> 255, cận dưới -> 0 (không phí mức)", all(full), full)
check("act_qparams: khoảng suy biến (0,0) cho scale 1, zp 0", sq.act_qparams(0, 0) == (np.float32(1.0), 0))

# hiệu chuẩn
a0 = sq.analyse(base)
tg, _ = sq.plan_targets(a0)
tens = sq.plan_tensors(a0, tg)
rng_calib = sq.calibrate(base, tens, calib)
xmax = max(c["x"].max() for c in calib)
check("hiệu chuẩn: khoảng của x bao trùm đúng min / max của mẫu", abs(rng_calib["x"][1] - xmax) < 1e-6 and rng_calib["x"][0] >= 0, rng_calib["x"])
spiky = [dict(c) for c in calib]
spiky[0] = {"x": spiky[0]["x"].copy()}
spiky[0]["x"][0, 0, 0, 0] = 500.0
r_minmax = sq.calibrate(base, ["x"], spiky)
r_pct = sq.calibrate(base, ["x"], spiky, percentile=99.0)
check("hiệu chuẩn: --percentile cắt ngoại lai (min/max bị kéo lên 500, phân vị thì không)", r_minmax["x"][1] == 500.0 and r_pct["x"][1] < 5, (r_minmax["x"], r_pct["x"]))

# giá trị ÂM: zero-point phải hoạt động (Tanh -> Conv)
Wt = rng.normal(0, 0.3, (16, 8, 3, 3)).astype("f4"); Bt = rng.normal(0, 0.1, 16).astype("f4")
Wu = rng.normal(0, 0.3, (16, 16, 3, 3)).astype("f4")
pads = [q.make_attr_ints("pads", [1, 1, 1, 1])]
neg = q.make_model([q.make_node("Conv", ["x", "Wt", "Bt"], ["c1"], "c1", pads), q.make_node("Tanh", ["c1"], ["t"], "tanh"),
                    q.make_node("Conv", ["t", "Wu"], ["y"], "c2", pads)], [init("Wt", Wt), init("Bt", Bt), init("Wu", Wu)],
                   [q.make_value_info("x", q.FLOAT, [1, 8, 8, 8])], [q.make_value_info("y", q.FLOAT, [1, 16, 8, 8])])
nc = [{"x": (rng.normal(0, 1, (1, 8, 8, 8))).astype("f4")} for _ in range(12)]
nout, nrep = sq.quantize_static(neg, nc)
nh = [{"x": (rng.normal(0, 1, (1, 8, 8, 8))).astype("f4")} for _ in range(6)]
ncos = min(q.metrics(run(neg, h), run(nout, h))["cos"] for h in nh)
check("kích hoạt có giá trị ÂM (Tanh): 2 nút quantize, kết quả vẫn gần bản gốc (cos >= 0.995)", nrep["targets"] == 2 and ncos >= 0.995, (nrep["targets"], ncos))
check("tensor có giá trị âm nhận zero-point > 0 (bất đối xứng thật sự dùng)", any(sq.act_qparams(*nrep["ranges"][t])[1] > 0 for t in nrep["ranges"] if nrep["ranges"][t][0] < 0))

# đột biến
orig_qp = sq.act_qparams
sq.act_qparams = lambda lo, hi: (orig_qp(lo, hi)[0], 0)
mut, _ = sq.quantize_static(neg, nc)
sq.act_qparams = orig_qp
mcos = min(q.metrics(run(neg, h), run(mut, h))["cos"] for h in nh)
check("đột biến: zero-point luôn 0 -> kích hoạt âm bị cắt, chất lượng tụt, BỊ BẮT", mcos < ncos - 0.002, (mcos, ncos))
orig_rw = sq._rewire
sq._rewire = lambda nb, mapping: nb
mut2, _ = sq.quantize_static(base, calib)
sq._rewire = orig_rw
with tempfile.TemporaryDirectory() as td:
    ops2 = sq.fused_ops(mut2, td)
check("đột biến: bỏ nối lại đầu vào (Q/DQ treo, toán tử vẫn đọc tensor float) -> mất toán tử int8, BỊ BẮT", ops2.get("QLinearConv", 0) == 0, ops2)

# tensor dùng chung + dư (residual)
Ws = rng.normal(0, 0.1, (8, 8, 3, 3)).astype("f4")
shared = q.make_model([q.make_node("Conv", ["x", "Ws"], ["a"], "ca", pads), q.make_node("Conv", ["x", "Ws"], ["b"], "cb", pads), q.make_node("Add", ["a", "b"], ["y"], "add")],
                      [init("Ws", Ws)], [q.make_value_info("x", q.FLOAT, [1, 8, 8, 8])], [q.make_value_info("y", q.FLOAT, [1, 8, 8, 8])])
sc_ = [{"x": rng.random((1, 8, 8, 8)).astype("f4")} for _ in range(8)]
sout, srep = sq.quantize_static(shared, sc_)
check("tensor x dùng bởi hai Conv: chỉ MỘT cặp Q/DQ cho x; hai đầu ra (a, b) đi vào Add (không phải Relu) nên được quantize riêng",
      sout.count(b"x_QuantizeLinear") == 1 and b"a_quantized" in sout and b"b_quantized" in sout, srep)
check("model dùng chung vẫn chạy và gần bản gốc", q.metrics(run(shared, sc_[0]), run(sout, sc_[0]))["cos"] >= 0.998)

# batch động: hiệu chuẩn với batch 1, chạy batch 4
dyn = cnn(dyn_batch=True)
dout, drep = sq.quantize_static(dyn, samples(8))
h4 = samples(1, batch=4, seed=7)[0]
check("batch động: hiệu chuẩn batch 1, chạy batch 4 vẫn gần bản gốc", q.metrics(run(dyn, h4), run(dout, h4))["cos"] >= 0.999)

# trường hợp biên
old = cnn(opset=11)
oo, orp = sq.quantize_static(old, calib)
check("opset < 13: không đổi gì, ghi lý do", oo == old and orp["skipped"] and "opset" in orp["skipped"][0][1])
raised = False
try:
    sq.quantize_static(base, [])
except ValueError:
    raised = True
check("thiếu mẫu hiệu chuẩn: ném ValueError rõ ràng (không âm thầm quantize bằng số ngẫu nhiên)", raised)
plain = q.make_model([q.make_node("Relu", ["x"], ["y"], "r")], [], [q.make_value_info("x", q.FLOAT, [1, 4])], [q.make_value_info("y", q.FLOAT, [1, 4])])
po, pr = sq.quantize_static(plain, [{"x": np.zeros((1, 4), "f4")}])
check("model không có Conv/MatMul/Gemm: trả nguyên bản", po == plain and pr["targets"] == 0)
raised2 = False
try:
    sq.analyse(b"khong phai onnx " * 8)
except ValueError:
    raised2 = True
check("tệp không phải ONNX: ném ValueError", raised2)

# CLI
with tempfile.TemporaryDirectory() as td:
    import contextlib
    import io
    src, dst = os.path.join(td, "a.onnx"), os.path.join(td, "b.onnx")
    open(src, "wb").write(base)
    args = []
    for i, c in enumerate(calib[:8]):
        p = os.path.join(td, "c%d.npy" % i)
        np.save(p, c["x"])
        args += ["--calib-npy", "x=" + p]
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = sq.main([src, dst, "--verify"] + args)
    text = buf.getvalue()
    check("CLI --verify: mã thoát 0, in số toán tử int8 fuse được và cos", rc == 0 and "QLinearConv" in text and "cos=" in text, text)
    buf2 = io.StringIO()
    with contextlib.redirect_stdout(buf2):
        rc2 = sq.main([src, dst])
    check("CLI không có ảnh hiệu chuẩn: mã thoát 1 và nhắc dùng ảnh THẬT", rc2 == 1 and "THẬT" in buf2.getvalue())
    buf3 = io.StringIO()
    with contextlib.redirect_stdout(buf3):
        rc3 = sq.main([src, dst, "--verify", "--min-cos", "0.9999999999"] + args)
    check("CLI: ngưỡng quá chặt -> KHÔNG ĐẠT, mã thoát 2", rc3 == 2 and "KHÔNG ĐẠT" in buf3.getvalue())
    check("tệp ra là ONNX hợp lệ nạp được", ort.InferenceSession(dst, providers=["CPUExecutionProvider"]) is not None)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
