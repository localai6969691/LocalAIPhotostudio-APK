#!/usr/bin/env python3
"""Port Python của engine/QuickSelect.kt (R12). Kiểm trên cảnh tổng hợp: vật cam có kết cấu + đồng tử tối (lỗ), vật cam thứ hai
ở xa (không liên thông), vùng cam kế bên khác màu rõ. Cần numpy, scipy."""
import math
import sys
from collections import deque
import numpy as np
from scipy.ndimage import uniform_filter

FAIL = []
SIGMA_MIN, SIGMA_MAX = 7.0, 40.0


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name + (f"  [{info}]" if info else ""))
    if not cond:
        FAIL.append(name)


def box3(ch):
    h, w = ch.shape
    pad = np.pad(ch, 1, mode="edge")
    # Kotlin chia nguyên theo số điểm thực có trong cửa sổ (mép chỉ có 4 hoặc 6 điểm) → tính theo đúng cách đó
    s = np.zeros_like(ch, dtype=np.int64)
    c = np.zeros_like(ch, dtype=np.int64)
    P = np.pad(ch.astype(np.int64), 1)
    C = np.pad(np.ones_like(ch, dtype=np.int64), 1)
    for dy in range(3):
        for dx in range(3):
            s += P[dy:dy + h, dx:dx + w]
            c += C[dy:dy + h, dx:dx + w]
    return s // c


def select(img, seeds, tol):
    h, w, _ = img.shape
    if w < 3 or h < 3:
        return np.zeros((h, w), bool)
    tol = float(np.clip(tol, 0, 1))
    B = np.stack([box3(img[..., c].astype(np.int64)) for c in range(3)], -1).astype(np.float64)
    sd = seeds.astype(bool)
    if not sd.any():
        return np.zeros((h, w), bool)
    pts = B[sd].astype(int)
    cnt = len(pts)

    def median_hist(v):
        hist = np.bincount(v, minlength=256)
        acc = np.cumsum(hist)
        return int(np.argmax(acc * 2 >= cnt))

    def mad_hist(v, med):
        dev = np.abs(v - med)
        hist = np.bincount(dev, minlength=256)
        acc = np.cumsum(hist)
        return float(np.argmax(acc * 2 >= cnt))

    meds = [median_hist(pts[:, c]) for c in range(3)]
    mu = np.array(meds, dtype=float)
    sig = np.array([min(SIGMA_MAX, max(SIGMA_MIN, 1.4826 * mad_hist(pts[:, c], meds[c]))) for c in range(3)])
    k = 1.5 + 3.5 * tol
    step_max = 20.0 + 50.0 * tol
    z = (B - mu) / sig
    near = np.sqrt((z ** 2).sum(-1) / 3.0) <= k
    sel = sd.copy()
    q = deque(map(tuple, np.argwhere(sd)))
    while q:
        y, x = q.popleft()
        for dy, dx in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            ny, nx = y + dy, x + dx
            if ny < 0 or nx < 0 or ny >= h or nx >= w or sel[ny, nx] or not near[ny, nx]:
                continue
            if np.sqrt(((B[y, x] - B[ny, nx]) ** 2).sum()) > step_max:
                continue
            sel[ny, nx] = True
            q.append((ny, nx))
    outside = np.zeros((h, w), bool)
    q = deque()

    def seed(y, x):
        if not sel[y, x] and not outside[y, x]:
            outside[y, x] = True
            q.append((y, x))

    for y in range(h):
        seed(y, 0); seed(y, w - 1)
    for x in range(w):
        seed(0, x); seed(h - 1, x)
    while q:
        y, x = q.popleft()
        for dy, dx in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            ny, nx = y + dy, x + dx
            if ny < 0 or nx < 0 or ny >= h or nx >= w or sel[ny, nx] or outside[ny, nx]:
                continue
            outside[ny, nx] = True
            q.append((ny, nx))
    # chỉ điền lỗ NHỎ (≤ 4% vùng chọn)
    hole_limit = int(0.04 * sel.sum())
    for y0 in range(h):
        for x0 in range(w):
            if sel[y0, x0] or outside[y0, x0]:
                continue
            comp = [(y0, x0)]
            outside[y0, x0] = True
            qi = 0
            while qi < len(comp):
                cy, cx = comp[qi]; qi += 1
                for dy, dx in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                    ny, nx = cy + dy, cx + dx
                    if ny < 0 or nx < 0 or ny >= h or nx >= w or sel[ny, nx] or outside[ny, nx]:
                        continue
                    outside[ny, nx] = True
                    comp.append((ny, nx))
            if len(comp) <= hole_limit:
                for cy, cx in comp:
                    sel[cy, cx] = True
    P = np.pad(sel.astype(int), 1)
    cnt = sum(P[dy:dy + h, dx:dx + w] for dy in range(3) for dx in range(3))
    out = cnt >= 5
    return out | sd


def iou(a, b):
    return np.logical_and(a, b).sum() / max(1, np.logical_or(a, b).sum())


def scene(rng):
    H, W = 300, 400
    yy, xx = np.mgrid[0:H, 0:W]
    img = np.zeros((H, W, 3))
    img[..., 0] = 90 + 25 * xx / W
    img[..., 1] = 110 + 20 * yy / H
    img[..., 2] = 130
    img += rng.normal(0, 8, img.shape)
    obj = (xx - 120) ** 2 + (yy - 150) ** 2 <= 60 ** 2
    shade = 15 * (xx - 120) / 60.0
    img[obj] = np.array([235.0, 120.0, 30.0]) + shade[obj][:, None] * np.array([1, 0.3, 0.1]) + rng.normal(0, 8, (obj.sum(), 3))
    pupil = (xx - 125) ** 2 + (yy - 150) ** 2 <= 10 ** 2
    img[pupil] = np.array([25.0, 20.0, 20.0]) + rng.normal(0, 4, (pupil.sum(), 3))
    far = (xx - 320) ** 2 + (yy - 230) ** 2 <= 40 ** 2
    img[far] = np.array([235.0, 120.0, 30.0]) + rng.normal(0, 8, (far.sum(), 3))
    # vùng cam kế bên, khác rõ (ΔR = -70, ΔG=+40) chạm vào vật
    nb = (xx >= 181) & (xx < 230) & (yy >= 130) & (yy < 170)
    img[nb] = np.array([165.0, 160.0, 30.0]) + rng.normal(0, 8, (nb.sum(), 3))
    return np.clip(np.round(img), 0, 255), obj | pupil, far, nb


def main():
    rng = np.random.default_rng(4)
    img, truth, far, nb = scene(rng)
    H, W, _ = img.shape
    seeds = np.zeros((H, W), bool)
    seeds[149:152, 95:150] = True          # nét ngang dày 3 px trong vật (bên trái đồng tử), bỏ qua tâm đồng tử
    seeds[149:152, 118:132] = False        # tránh đè lên đồng tử
    sel = select(img, seeds, 0.5)
    check("vật có kết cấu + bóng đổ: IoU ≥ 0.93 (đồng tử là lỗ được điền)", iou(sel, truth) >= 0.93, f"IoU={iou(sel, truth):.3f}")
    check("đồng tử (lỗ kín) nằm trong vùng chọn", sel[150, 125])
    check("vật cam thứ hai ở xa (không liên thông) KHÔNG bị chọn", (sel & far).sum() == 0)
    check("nền gần như không bị chọn (< 0.3% nền)", (sel & ~truth & ~nb).sum() / (~truth).sum() < 0.003, f"{(sel & ~truth).sum()} điểm")
    check("vùng kế bên khác màu rõ (ΔR=70) KHÔNG bị nuốt", (sel & nb).sum() / nb.sum() < 0.05, f"{(sel & nb).sum() / nb.sum():.3f}")

    lo = select(img, seeds, 0.1)
    hi = select(img, seeds, 0.9)
    check("dung sai thấp chọn ít hơn hoặc bằng dung sai cao", lo.sum() <= hi.sum(), f"{lo.sum()} ≤ {hi.sum()}")
    check("dung sai thấp vẫn gồm toàn bộ hạt giống", (lo & seeds).sum() == seeds.sum())

    check("không có hạt giống → rỗng", select(img, np.zeros((H, W), bool), 0.5).sum() == 0)
    seeds_bg = np.zeros((H, W), bool); seeds_bg[20:23, 20:80] = True
    sbg = select(img, seeds_bg, 0.5)
    check("tô trên nền → chọn nền (≥ 60% nền), KHÔNG chọn vật cam", sbg[~truth & ~far & ~nb].mean() > 0.6 and (sbg & truth).sum() / truth.sum() < 0.01,
          f"nền {sbg[~truth & ~far & ~nb].mean():.2f}, vật {(sbg & truth).sum()/truth.sum():.3f}")
    clean = np.zeros((H, W), bool); clean[149:152, 70:112] = True        # nét tô KHÔNG chạm đồng tử
    sc = select(img, clean, 0.5)
    check("nét tô sạch và nét tô lỡ chạm đồng tử cho kết quả gần như nhau (bền vững; IoU giữa hai ≥ 0.97)", iou(sc, sel) >= 0.97, f"IoU={iou(sc, sel):.3f}")
    check("nét tô lỡ chạm đồng tử vẫn KHÔNG nuốt vùng kế bên", (sel & nb).sum() / nb.sum() < 0.05)
    one = np.zeros((H, W), bool); one[150, 100] = True
    check("chỉ một điểm hạt giống vẫn chọn được vật (IoU ≥ 0.85)", iou(select(img, one, 0.5), truth) >= 0.85, f"IoU={iou(select(img, one, 0.5), truth):.3f}")
    check("ảnh quá nhỏ (2x2) → rỗng", select(np.zeros((2, 2, 3)), np.ones((2, 2), bool), 0.5).sum() == 0)

    # biên mượt: số điểm biên (chu vi) không phình ra so với đường tròn lý tưởng
    edge = sel & ~(np.pad(sel, 1)[:-2, 1:-1] & np.pad(sel, 1)[2:, 1:-1] & np.pad(sel, 1)[1:-1, :-2] & np.pad(sel, 1)[1:-1, 2:])
    check("biên mượt: chu vi ≤ 1.35 × chu vi đường tròn lý tưởng", edge.sum() <= 1.35 * 2 * math.pi * 60, f"{edge.sum()} vs {2*math.pi*60:.0f}")

    print()
    if FAIL:
        print("THẤT BẠI:", FAIL)
        sys.exit(1)
    print("TẤT CẢ OK")


if __name__ == "__main__":
    main()
