#!/usr/bin/env python3
"""
R15 - Kiểm tra prompt của LLM cục bộ (ai/LlmPrompts.kt) mà KHÔNG cần Gradle:
  * mọi tên phép chỉnh trong prompt (danh sách "Allowed ops" và ví dụ) PHẢI là khóa OpType hợp lệ -> chống lệch prompt <-> engine
    (nếu mô hình trả một khóa không có trong OpType, PlanJson.parseFull bỏ qua âm thầm)
  * mọi phạm vi (scope) trong prompt nằm trong Scope.ALL
  * mọi ví dụ trong prompt là JSON hợp lệ và chỉ dùng op/scope hợp lệ
  * prompt kế hoạch = bản MediaPipe trước R15 (2045 ký tự thô) + đúng một dòng hair_volume thêm ở R16
  * mô phỏng các khẳng định chuỗi của app/src/test/.../R15Test.kt (trung hòa nháy/xuống dòng, imagePlan, translate, dòng đầu của câu dịch)
  * kiểm thử đột biến: bỏ một phép khỏi OpType -> phải bị bắt
Chạy: python3 tools/verify_ports/llm_prompts.py
"""
import json, os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
AI = os.path.join(ROOT, "app", "src", "main", "java", "com", "aiphoto", "studio", "ai")
fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + detail) if detail and not ok else ""))
    if not ok: fails.append(name)

prompts_kt = open(os.path.join(AI, "LlmPrompts.kt"), encoding="utf-8").read()
models_kt = open(os.path.join(AI, "EditModels.kt"), encoding="utf-8").read()

# ---- khóa OpType và Scope.ALL từ chính mã nguồn
enum_body = models_kt[models_kt.index("enum class OpType"):models_kt.index("companion object", models_kt.index("enum class OpType"))]
op_keys = set(re.findall(r'^\s*[A-Z][A-Z0-9_]*\("([a-z0-9_]+)"', enum_body, re.M))
m = re.search(r"object Scope\b.*?ALL\s*=\s*(?:setOf|listOf)\(([^)]*)\)", models_kt, re.S)
scope_all = set(re.findall(r'(?:[A-Z_]+|"([a-z]+)")', m.group(1))) if m else set()
# Scope.ALL có thể tham chiếu hằng (TEETH, EYES...) -> lấy giá trị chuỗi của các hằng
consts = dict(re.findall(r'const val ([A-Z_]+)\s*=\s*"([a-z]+)"', models_kt))
if m:
    refs = re.findall(r"[A-Z_]{2,}", m.group(1))
    scope_all = {consts[r] for r in refs if r in consts} | {x for x in re.findall(r'"([a-z]+)"', m.group(1))}
check(f"đọc được {len(op_keys)} khóa OpType và {len(scope_all)} phạm vi từ EditModels.kt", len(op_keys) > 30 and len(scope_all) >= 5, f"{len(op_keys)} {scope_all}")

# ---- raw string của prompt kế hoạch
raw = re.search(r'"""(.*?)"""', prompts_kt, re.S).group(1)
lines = [l.strip() for l in raw.split("\n")]
ops_section = raw.split("Allowed ops:", 1)[1].split("Optional \\\"scope\\\"", 1)[0] if "Allowed ops:" in raw else ""
listed = set()
for l in ops_section.split("\n"):
    mm = re.match(r"^([a-z0-9_, ()=\-./ +]+?):\s+(?:value|\"?value)", l.strip()) or re.match(r"^([a-z0-9_, ]+):\s", l.strip())
    if mm:
        for k in re.findall(r"[a-z][a-z0-9_]*", mm.group(1).split("(")[0]):
            if k in ("value", "arg"): continue
            listed.add(k)
# bỏ các từ không phải tên op nằm trong phần chú giải (vd. "negative", "positive")
noise = {"negative", "positive", "use", "scope"}
listed -= noise
bad = sorted(k for k in listed if k not in op_keys)
check(f"mọi phép trong 'Allowed ops' ({len(listed)}) là khóa OpType hợp lệ", not bad, f"không có trong OpType: {bad}")
check("prompt liệt kê đủ nhóm phép cốt lõi (brightness, skin_smooth, bg_remove, colorize, upscale...)",
      {"brightness", "contrast", "saturation", "warmth", "skin_smooth", "bg_remove", "colorize", "upscale", "crop_ratio", "rotate"} <= listed, f"{sorted(listed)}")

# ---- ví dụ trong prompt
ex = re.findall(r"^(\{\"ops\":.*\})$", raw, re.M)
check(f"có ví dụ JSON trong prompt ({len(ex)})", len(ex) >= 6)
okj, bad_ex = True, []
for e in ex:
    try:
        j = json.loads(e)
        for o in j["ops"]:
            if o["op"] not in op_keys: bad_ex.append(("op", o["op"]))
            if "scope" in o and o["scope"] not in scope_all: bad_ex.append(("scope", o["scope"]))
    except Exception as err:
        okj = False; bad_ex.append(("json", e[:60], str(err)))
check("mọi ví dụ là JSON hợp lệ và chỉ dùng op/scope hợp lệ", okj and not bad_ex, f"{bad_ex}")
scope_line = [l for l in lines if l.startswith('Optional "scope"') or l.startswith('Optional \\"scope\\"')]
sc = set(re.findall(r"[a-z]+", scope_line[0].split(":", 1)[1].split("(")[0])) if scope_line else set()
check("mọi phạm vi nêu trong prompt nằm trong Scope.ALL", bool(sc) and sc <= scope_all, f"{sc - scope_all}")

# ---- mô phỏng khẳng định chuỗi của R15Test
def clean(s): return s.replace('"', "'").replace("\n", " ").strip()
def plan(user):
    body = raw.replace("$clean", clean(user))
    return "\n".join(l.lstrip() if False else l for l in body.split("\n"))  # trimIndent không đổi nội dung khẳng định bên dưới
check('plan chứa "Allowed ops:" và dòng Request đúng', "Allowed ops:" in raw and 'Request: "$clean"' in raw)
check("trung hòa nháy kép và xuống dòng: 'tăng \"sáng\"\\nvà ấm' -> Request: \"tăng 'sáng' và ấm\"",
      'Request: "tăng \'sáng\' và ấm"' in plan('tăng "sáng"\nvà ấm'))
check("prompt có dòng 'colorize: value 0.0..1.0' (khẳng định của R15Test)", "colorize: value 0.0..1.0" in raw)
img_intro = re.search(r'fun imagePlan.*?"(The attached photo[^"]*)"\s*\+\s*\n\s*"([^"]*)"', prompts_kt, re.S)
check("imagePlan mở đầu bằng 'The attached photo is the image to edit.' rồi nối prompt kế hoạch", bool(img_intro) and img_intro.group(1).startswith("The attached photo is the image to edit."))
tr = re.search(r'fun translate.*?return "Translate this image-editing description[^;]*', prompts_kt, re.S)
check("translate: chỉ khi có ký tự ngoài ASCII; câu có 'Stable Diffusion' và 'Text: \"...\"'",
      "text.all { it.code < 128 }) return null" in prompts_kt and "Stable Diffusion" in tr.group(0) and 'Text: \\"$clean\\"' in tr.group(0))
# dòng đầu của câu dịch (mô phỏng translateToEnglish)
def first_line(reply, orig):
    out = ([l for l in reply.strip().split("\n")] or [""])[0].strip().strip('"')
    return out if out.strip() else orig
check("translateToEnglish: lấy dòng đầu, bỏ nháy kép, rỗng thì giữ nguyên",
      first_line('  "a red hat"  \nghi chú thừa', "mũ") == "a red hat" and first_line("   ", "mũ đỏ") == "mũ đỏ")

# ---- độ dài prompt giữ nguyên như bản trước R15 (2045 ký tự thô trong raw string)
HV_LINE = 'hair_volume: value 0.0..1.0 = fuller / thicker hair (use scope \\"hair\\"; needs the hair model)\n'
OUT_LINE = 'outpaint: value 1, arg = \\"l=0.2,r=0.2,t=0,b=0\\" (add 20% on a side) or \\"ratio=1.78\\" (extend the frame to that width/height)\n'
SPLIT_LINE = 'split_tone: value 1, arg = \\"shadowHue,shadowSat,highlightHue,highlightSat\\" (hue 0-360, sat 0..1; teal shadows + orange highlights = \\"185,0.5,28,0.5\\")\n'
UNBLUR_LINE = 'unblur: value 0.0..1.0 = restore a blurry or shaky photo (no arg: the app measures the blur itself)\n'
MOIRE_LINE = 'moire: value 0.0..1.0 = remove moire stripes from a photo of a screen or fine fabric\n'
STYLE_LINE = 'style: value 0.0..1.0, arg = \\"oil\\" or \\"cartoon\\" or \\"watercolor\\" (turn the photo into that kind of painting on the device)\n'
ADDED = [HV_LINE, OUT_LINE, SPLIT_LINE, UNBLUR_LINE, MOIRE_LINE, STYLE_LINE]
base_raw = raw
for line in ADDED: base_raw = base_raw.replace(line, "")
check("prompt = bản trước R15 (2045 ký tự thô) + ĐÚNG các dòng thêm có chủ ý (hair_volume R16, outpaint + split_tone R20, unblur + moire + style R25) - ngoài đó không có gì đổi",
      all(l in raw for l in ADDED) and len(base_raw) == 2045 and len(raw) == 2045 + sum(len(l) for l in ADDED), f"{len(raw)} / {len(base_raw)}")
check("hair_volume, outpaint, split_tone, unblur, moire, style có trong prompt và là khóa OpType hợp lệ", all(k in listed and k in op_keys for k in ("hair_volume", "outpaint", "split_tone", "unblur", "moire", "style")))

# ---- đột biến: bỏ 'colorize' khỏi OpType -> kiểm tra phải bắt được
op2 = op_keys - {"colorize"}
bad2 = sorted(k for k in listed if k not in op2)
check("đột biến: bỏ 'colorize' khỏi OpType thì kiểm tra tên phép BỊ BẮT", "colorize" in bad2)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
