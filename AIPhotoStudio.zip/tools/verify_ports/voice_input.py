#!/usr/bin/env python3
"""
R35 - Kiểm tra logic NHẬP YÊU CẦU BẰNG GIỌNG NÓI (ai/VoiceInput.kt) mà KHÔNG cần Gradle / kotlinc.

Bản port Python của `normalize`, `pick`, `merge`, `languageTag` — hằng số (TAGS, MAX_CHARS, MAX_RESULTS, TRAILING) đọc THẲNG từ tệp Kotlin,
nên đổi một hằng số ở Kotlin mà quên bản test sẽ bị bắt. Kiểm:
  * mọi mã ngôn ngữ giao diện (AppLanguages.ALL) đều có thẻ BCP-47 hợp lệ, tiền tố thẻ == mã; mã lạ ⇒ en-US
  * normalize: gộp khoảng trắng / xuống dòng / NBSP, bỏ ký tự vô hình (ZWSP, WJ, BOM) nhưng GIỮ ZWJ / ZWNJ, bỏ dấu cuối câu (giữ ? !),
    cắt tối đa MAX_CHARS và không cắt đôi cặp thay thế
  * pick: ưu tiên bản đầu; bản sau chỉ thắng khi bản đầu không hiểu mà nó hiểu; chỉ xét MAX_RESULTS bản; lỗi trong `understands` = không hiểu
  * merge: ô trống thay, có chữ thì nối ", " (hoặc cách một khoảng nếu chữ cũ kết thúc bằng dấu câu), lời rỗng giữ nguyên ô, tổng <= MAX_CHARS
  * manifest KHÔNG có quyền RECORD_AUDIO (thiết kế: dùng hộp nhận dạng của hệ thống)
  * đột biến: 8 kiểu sửa cố ý bản port phải bị bộ kiểm bắt
Chạy: python3 tools/verify_ports/voice_input.py
"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
APP = os.path.join(ROOT, "app", "src", "main")
KT = os.path.join(APP, "java", "com", "aiphoto", "studio")
src = open(os.path.join(KT, "ai", "VoiceInput.kt"), encoding="utf-8").read()
langs_src = open(os.path.join(KT, "i18n", "AppLanguage.kt"), encoding="utf-8").read()
manifest = open(os.path.join(APP, "AndroidManifest.xml"), encoding="utf-8").read()

fails = []
def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)

# ---- hằng số đọc từ Kotlin
MAX_RESULTS = int(re.search(r"const val MAX_RESULTS = (\d+)", src).group(1))
MAX_CHARS = int(re.search(r"const val MAX_CHARS = (\d+)", src).group(1))
TRAILING = re.search(r'private const val TRAILING = "([^"]*)"', src).group(1)
TAGS = dict(re.findall(r'"([a-z]{2})" to "([A-Za-z\-]+)"', src[src.index("private val TAGS"):src.index("private const val TRAILING")]))
APP_CODES = re.findall(r'AppLanguage\("([a-z]{2})"', langs_src)
INVISIBLE = {"\u200b", "\u2060", "\ufeff"}  # khớp isInvisible() ở Kotlin (đã kiểm bằng chuỗi bên dưới)
check("isInvisible ở Kotlin đúng ba ký tự ZWSP / WJ / BOM (không có ZWNJ / ZWJ)",
      "c == '\\u200B' || c == '\\u2060' || c == '\\uFEFF'" in src)

class Impl:
    """Bản port; các đột biến ghi đè từng phương thức."""
    @staticmethod
    def language_tag(app_language):
        return TAGS.get(app_language.strip().lower(), "en-US")

    @staticmethod
    def cap(s):
        if len(s) <= MAX_CHARS:
            return s
        cut = MAX_CHARS
        # Kotlin: s[cut-1] là high surrogate. Python dùng điểm mã, nên mô phỏng theo UTF-16
        u16 = s.encode("utf-16-le")
        units = [int.from_bytes(u16[i:i + 2], "little") for i in range(0, len(u16), 2)]
        if 0xD800 <= units[cut - 1] <= 0xDBFF:
            cut -= 1
        out = units[:cut]
        b = b"".join(x.to_bytes(2, "little") for x in out)
        return b.decode("utf-16-le").rstrip()

    @classmethod
    def normalize(cls, raw):
        if raw is None:
            return ""
        sb = []
        pending = False
        for c in raw:
            if c in INVISIBLE:
                continue
            if c.isspace():
                pending = len(sb) > 0
            else:
                if pending:
                    sb.append(" ")
                    pending = False
                sb.append(c)
        end = len(sb)
        while end > 0 and (sb[end - 1] == " " or sb[end - 1] in TRAILING):
            end -= 1
        return cls.cap("".join(sb[:end]))

    @classmethod
    def pick(cls, candidates, understands):
        if candidates is None:
            return None
        cleaned = []
        for c in candidates:
            if len(cleaned) >= MAX_RESULTS:
                break
            n = cls.normalize(c)
            if n and n not in cleaned:
                cleaned.append(n)
        if not cleaned:
            return None
        for n in cleaned:
            try:
                ok = understands(n)
            except Exception:
                ok = False
            if ok:
                return n
        return cleaned[0]

    @classmethod
    def merge(cls, existing, spoken):
        add = cls.normalize(spoken)
        if not add:
            return existing
        base = existing.rstrip()
        if not base:
            return add
        sep = " " if base[-1] in ",;.!?" else ", "
        return cls.cap(base + sep + add)

def u16len(s):
    return len(s.encode("utf-16-le")) // 2

def suite(I, label, quiet=True):
    """Trả về danh sách tên kiểm tra HỎNG của một bản cài đặt."""
    bad = []
    def t(name, ok):
        if not ok:
            bad.append(name)
    # thẻ ngôn ngữ
    t("tag vi", I.language_tag("vi") == "vi-VN")
    t("tag hoa/thường + khoảng trắng", I.language_tag(" VI ") == "vi-VN")
    t("tag lạ ⇒ en-US", I.language_tag("xx") == "en-US" and I.language_tag("") == "en-US")
    # normalize
    n = I.normalize
    t("None", n(None) == "")
    t("gộp khoảng trắng + bỏ dấu chấm cuối", n("  làm sáng   ảnh.  ") == "làm sáng ảnh")
    t("gộp xuống dòng + tab", n("tăng\nsáng\t\tvà ấm ...") == "tăng sáng và ấm")
    t("chỉ dấu câu ⇒ rỗng", n("...") == "" and n(" . , ") == "")
    t("giữ dấu hỏi", n("Làm sáng ảnh?") == "Làm sáng ảnh?")
    t("dấu cách trước dấu chấm cuối", n("mịn da , ") == "mịn da")
    t("ký tự vô hình bị bỏ", n("a\u200bb\ufeffc\u2060d") == "abcd")
    t("ZWJ giữ nguyên", n("क\u200dष") == "क\u200dष")
    t("NBSP gộp", n("a\u00a0\u00a0b") == "a b")
    t("dấu CJK cuối câu", n("明るくして。") == "明るくして" and n("明るくして…") == "明るくして")
    t("cắt tối đa", u16len(n("a" * (MAX_CHARS + 100))) == MAX_CHARS)
    t("không cắt đôi cặp thay thế", n("a" * (MAX_CHARS - 1) + "😀😀") == "a" * (MAX_CHARS - 1))
    # pick
    p = I.pick
    t("pick None / rỗng", p(None, lambda s: True) is None and p([], lambda s: True) is None and p(["", "..."], lambda s: True) is None)
    t("không hiểu bản nào ⇒ bản đầu (đã làm sạch)", p(["làm sáng ảnh."], lambda s: False) == "làm sáng ảnh")
    t("bản sau hiểu, bản đầu không", p(["làm sáng anh", "làm sáng ảnh"], lambda s: s == "làm sáng ảnh") == "làm sáng ảnh")
    t("bản đầu hiểu thì thắng", p(["a b", "c d"], lambda s: True) == "a b")
    t("trùng sau làm sạch", p(["x y.", "x y", "z"], lambda s: s == "z") == "z")
    t("chỉ xét MAX_RESULTS bản", p(["1 a", "2 b", "3 c", "4 d"], lambda s: s == "4 d") == "1 a")
    def boom(s):
        raise ValueError("lỗi bộ hiểu")
    t("understands ném lỗi = không hiểu", p(["x", "y"], boom) == "x")
    t("bỏ qua bản rỗng ở đầu", p(["", "  ", "mờ phông"], lambda s: False) == "mờ phông")
    # merge
    m = I.merge
    t("ô trống thay", m("", "tông ấm") == "tông ấm" and m("   ", "tông ấm") == "tông ấm")
    t("nối bằng dấu phẩy", m("da mịn", "tông ấm") == "da mịn, tông ấm")
    t("chữ cũ kết thúc dấu câu", m("da mịn.", "tông ấm") == "da mịn. tông ấm" and m("da mịn,", "x") == "da mịn, x")
    t("bỏ khoảng trắng cuối chữ cũ", m("da mịn   ", "x") == "da mịn, x")
    t("lời rỗng giữ nguyên ô", m("abc ", "") == "abc " and m("abc", "...") == "abc")
    t("tổng không quá MAX_CHARS", u16len(m("a" * (MAX_CHARS - 10), "b" * 50)) <= MAX_CHARS)
    return bad

# ---- 1. dữ liệu thật từ Kotlin
check(f"đọc được {len(APP_CODES)} mã ngôn ngữ giao diện và {len(TAGS)} thẻ nhận dạng", len(APP_CODES) == 13 and len(TAGS) == 13, f"{APP_CODES} {TAGS}")
check("mọi mã giao diện đều có thẻ nhận dạng", set(APP_CODES) == set(TAGS), f"thiếu {set(APP_CODES) - set(TAGS)} thừa {set(TAGS) - set(APP_CODES)}")
check("thẻ có dạng ll-RR và tiền tố trùng mã", all(re.fullmatch(r"[a-z]{2}-[A-Z]{2}", v) and v.split("-")[0] == k for k, v in TAGS.items()), TAGS)
check("MAX_RESULTS / MAX_CHARS hợp lý", 1 <= MAX_RESULTS <= 5 and 100 <= MAX_CHARS <= 2000, (MAX_RESULTS, MAX_CHARS))
check("dấu cuối câu KHÔNG chứa ? !", "?" not in TRAILING and "!" not in TRAILING and "." in TRAILING, TRAILING)

# ---- 2. bản port đạt
bad = suite(Impl, "port")
check(f"bản port đạt toàn bộ ca ({len(bad)} hỏng)", not bad, bad)

# ---- 3. đột biến: mỗi kiểu PHẢI làm hỏng ít nhất một ca
def mutant(name, **over):
    class M(Impl):
        pass
    for k, v in over.items():
        setattr(M, k, v)
    b = suite(M, name)
    check(f"đột biến '{name}' bị bắt", len(b) > 0)

mutant("không gộp khoảng trắng", normalize=classmethod(lambda cls, raw: "" if raw is None else raw.strip().rstrip(TRAILING)))
mutant("pick luôn lấy bản cuối", pick=classmethod(lambda cls, c, u: None if not c else (cls.normalize(c[-1]) or None)))
mutant("pick bỏ qua understands", pick=classmethod(lambda cls, c, u: next((cls.normalize(x) for x in (c or []) if cls.normalize(x)), None)))
mutant("merge nối bằng khoảng trắng", merge=classmethod(lambda cls, e, s: (e.rstrip() + " " + cls.normalize(s)) if cls.normalize(s) and e.strip() else (cls.normalize(s) or e)))
mutant("merge thay thế luôn", merge=classmethod(lambda cls, e, s: cls.normalize(s) or e))
mutant("tag mặc định sai", language_tag=staticmethod(lambda a: TAGS.get(a.strip().lower(), "vi-VN")))
mutant("không cắt MAX_CHARS", cap=staticmethod(lambda s: s))
def bad_invisible(raw):
    return Impl.normalize(None if raw is None else raw.replace("\u200d", ""))
mutant("bỏ cả ZWJ", normalize=classmethod(lambda cls, raw: Impl.normalize(None if raw is None else raw.replace("\u200d", ""))))


# ---- 5. vạch rung của thanh trượt (util/SliderTicks.kt)
import math
st_src = open(os.path.join(KT, "util", "SliderTicks.kt"), encoding="utf-8").read()
DIV = int(re.search(r"const val DIVISIONS = (\d+)", st_src).group(1))
check("DIVISIONS hợp lý (4..20)", 4 <= DIV <= 20, DIV)
def notch(v, a, b, div=DIV, clamp=True):
    span = b - a
    if not (span > 0):
        return 0
    if v != v:  # NaN: coerceIn của Kotlin trả NaN, toInt() của NaN = 0
        return 0
    t = (v - a) / span
    if clamp:
        t = min(1.0, max(0.0, t))
    return int(t * div)
def crossed(o, n, a, b, **kw):
    return notch(o, a, b, **kw) != notch(n, a, b, **kw)
def tick_suite(nt, cr):
    bad = []
    def t(name, ok):
        if not ok: bad.append(name)
    t("đầu / cuối / giữa", nt(0, 0, 1) == 0 and nt(1, 0, 1) == DIV and nt(0.5, 0, 1) == DIV // 2)
    t("thang đối xứng", nt(0, -1, 1) == DIV // 2)
    t("ngoài thang bị kẹp", nt(-5, 0, 1) == 0 and nt(9, 0, 1) == DIV)
    t("thang suy biến", nt(0.5, 1, 1) == 0 and nt(0.5, 1, 0) == 0)
    t("NaN an toàn", nt(float("nan"), 0, 1) == 0)
    t("chỉ rung khi qua vạch", (not cr(0.51, 0.58, 0, 1)) and cr(0.51, 0.62, 0, 1) and cr(0.62, 0.51, 0, 1) and not cr(0.3, 0.3, 0, 1))
    ticks, prev = 0, 0.0
    for i in range(1, 1001):
        v = i / 1000
        if cr(prev, v, 0, 1): ticks += 1
        prev = v
    t("quét hết thang = đúng DIVISIONS nhịp", ticks == DIV)
    return bad
check("SliderTicks: bản port đạt toàn bộ ca", not tick_suite(notch, crossed), tick_suite(notch, crossed))
for name, kw in (("không kẹp", dict(clamp=False)),):
    nt2 = lambda v, a, b, kw=kw: notch(v, a, b, **kw)
    cr2 = lambda o, n, a, b, kw=kw: crossed(o, n, a, b, **kw)
    check(f"SliderTicks đột biến '{name}' bị bắt", len(tick_suite(nt2, cr2)) > 0)
check("SliderTicks đột biến 'luôn rung' bị bắt", len(tick_suite(notch, lambda o, n, a, b: True)) > 0)
check("SliderTicks đột biến 'chỉ vạch đầu' bị bắt", len(tick_suite(lambda v, a, b: 0 if v < b else DIV, crossed)) > 0)
check("ParamSlider gọi SliderTicks.crossed", "SliderTicks.crossed(" in open(os.path.join(KT, "ui", "Widgets.kt"), encoding="utf-8").read())

# ---- 4. thiết kế: không xin quyền micro
check("manifest KHÔNG có RECORD_AUDIO (dùng hộp nhận dạng của hệ thống)", "RECORD_AUDIO" not in manifest)

print()
if fails:
    print(f"TỔNG: {len(fails)} KIỂM TRA HỎNG: {fails}")
    sys.exit(1)
print("TẤT CẢ OK")
