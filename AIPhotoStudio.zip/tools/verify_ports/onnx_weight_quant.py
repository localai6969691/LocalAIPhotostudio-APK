#!/usr/bin/env python3
"""
Kiểm tra công cụ tools/convert_models/onnx_weight_quant.py (nén trọng số ONNX không cần gói `onnx`).
Dựng model ONNX nhỏ bằng chính bộ ghi protobuf của công cụ, nén, rồi so kết quả với bản gốc bằng ONNX RUNTIME THẬT (không phải tự so với tự):
  * đọc / ghi protobuf giữ nguyên trường lạ; model nén nạp được và chạy ra kết quả gần bản gốc;
  * int8 theo kênh: sai số lượng tử hóa từng trọng số <= scale/2, trục đúng cho Conv / ConvTranspose / MatMul / Gemm(transB 0 và 1);
  * cỡ tệp giảm đúng mức kỳ vọng; fp16 giảm ~50 %;
  * trường hợp biên: opset < 13, trọng số < min-elements, trọng số cũng là input đồ thị, trọng số dùng chung, external data, tệp rác;
  * đột biến: cắt cụt thay vì làm tròn, sai trục -> phải bị bắt.
Chạy: python3 tools/verify_ports/onnx_weight_quant.py
"""
import os
import struct
import sys
import tempfile

import numpy as np

try:
    import onnxruntime as ort
except ImportError:                       # máy không có onnxruntime: bỏ qua có thông báo, KHÔNG làm đỏ run_all.sh / CI
    print("BỎ QUA: chưa cài onnxruntime (pip install onnxruntime) nên không kiểm được công cụ nén ONNX")
    sys.exit(0)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "convert_models"))
import onnx_weight_quant as q  # noqa: E402

fails = []


def check(name, ok, detail=""):
    print(("OK   " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail and not ok else ""))
    if not ok:
        fails.append(name)


def f32(a):
    return np.asarray(a, dtype="<f4").tobytes()


def init(name, arr):
    return q.make_tensor(name, arr.shape, q.FLOAT, f32(arr))


def run(model_bytes, feeds):
    so = ort.SessionOptions()
    so.log_severity_level = 3
    s = ort.InferenceSession(model_bytes, so, providers=["CPUExecutionProvider"])
    return s.run(None, feeds)


rng = np.random.default_rng(3)


def cnn(opset=13, ir=8, dyn_batch=False, w_as_input=False):
    W1 = rng.normal(0, 0.2, (32, 3, 3, 3)).astype("f4")
    B1 = rng.normal(0, 0.1, 32).astype("f4")
    W2 = rng.normal(0, 0.1, (64, 32, 3, 3)).astype("f4")
    B2 = rng.normal(0, 0.1, 64).astype("f4")
    W3 = rng.normal(0, 0.1, (64, 128)).astype("f4")          # MatMul: B [K,N] -> trục 1
    B3 = rng.normal(0, 0.1, 128).astype("f4")
    W4 = rng.normal(0, 0.1, (10, 128)).astype("f4")          # Gemm transB=1: B [N,K] -> trục 0
    B4 = rng.normal(0, 0.1, 10).astype("f4")
    nodes = [
        q.make_node("Conv", ["x", "W1", "B1"], ["c1"], "conv1", [q.make_attr_ints("pads", [1, 1, 1, 1])]),
        q.make_node("Relu", ["c1"], ["r1"], "relu1"),
        q.make_node("Conv", ["r1", "W2", "B2"], ["c2"], "conv2", [q.make_attr_ints("pads", [1, 1, 1, 1])]),
        q.make_node("Relu", ["c2"], ["r2"], "relu2"),
        q.make_node("GlobalAveragePool", ["r2"], ["gp"], "gap"),
        q.make_node("Flatten", ["gp"], ["fl"], "flat", [q.make_attr_int("axis", 1)]),
        q.make_node("MatMul", ["fl", "W3"], ["m"], "mm"),
        q.make_node("Add", ["m", "B3"], ["a"], "add"),
        q.make_node("Relu", ["a"], ["ra"], "relu3"),
        q.make_node("Gemm", ["ra", "W4", "B4"], ["y"], "gemm", [q.make_attr_int("transB", 1)]),
    ]
    inits = [init("W1", W1), init("B1", B1), init("W2", W2), init("B2", B2), init("W3", W3), init("B3", B3), init("W4", W4), init("B4", B4)]
    batch = "N" if dyn_batch else 1
    inputs = [q.make_value_info("x", q.FLOAT, [batch, 3, 16, 16])]
    if w_as_input:
        inputs.append(q.make_value_info("W2", q.FLOAT, [64, 32, 3, 3]))
    outputs = [q.make_value_info("y", q.FLOAT, [batch, 10])]
    return q.make_model(nodes, inits, inputs, outputs, opset=opset, ir_version=ir), dict(W1=W1, W2=W2, W3=W3, W4=W4)


X = rng.random((1, 3, 16, 16)).astype("f4")
base, weights = cnn()
ref = run(base, {"x": X})[0]

# ------------------------------------------------------------------ protobuf round-trip
fields = q.parse(base)
check("parse -> emit giữ nguyên từng byte", q.emit(fields) == base)
extra = base + q.emit([(99, 2, b"truong-la"), (98, 0, 12345)])
out_extra, rep_extra = q.quantize_model(extra, "int8", 1000)
check("trường lạ ở mức model được giữ nguyên sau khi nén", b"truong-la" in out_extra and len(rep_extra["converted"]) > 0)
check("varint âm (thuộc tính axis = -1) mã hóa 10 byte đúng", q.parse(q.make_attr_int("axis", -1))[1][2] == (1 << 64) - 1)

# ------------------------------------------------------------------ int8 theo kênh
out8, rep8 = q.quantize_model(base, "int8", 4096)
names = sorted(c[0] for c in rep8["converted"])
check("int8: nén Conv W2 (18432), MatMul W3 (8192); W1 (864) và W4 (1280) dưới ngưỡng 4096 thì giữ nguyên", names == ["W2", "W3"], names)
y8 = run(out8, {"x": X})[0]
m8 = q.metrics(ref, y8)
check("int8: model nén nạp được bằng onnxruntime và ra kết quả gần bản gốc (cos >= 0.9995, L2 tđ <= 0.03)", m8["cos"] >= 0.9995 and m8["rel_l2"] <= 0.03, m8)
check("int8: cỡ tệp giảm ≥ 55 % (trọng số lớn chiếm đa số)", rep8["bytes_out"] <= 0.45 * rep8["bytes_in"], rep8["bytes_out"] / rep8["bytes_in"])
out8all, rep8all = q.quantize_model(base, "int8", 1)
check("int8 --min-elements 1: nén đủ 4 trọng số Conv / MatMul / Gemm", sorted(c[0] for c in rep8all["converted"]) == ["W1", "W2", "W3", "W4"], rep8all["converted"])
yall = run(out8all, {"x": X})[0]
check("int8 đủ 4 trọng số: vẫn gần bản gốc, kể cả trục Gemm transB=1 (trục 0) và MatMul (trục 1)", q.metrics(ref, yall)["cos"] >= 0.999, q.metrics(ref, yall))
axes = {c[0]: c[2] for c in rep8all["converted"]}
check("đúng TRỤC KÊNH ĐẦU RA cho từng toán tử: Conv W1, W2 -> axis=0; MatMul W3 [K,N] -> axis=1; Gemm transB=1 W4 [N,K] -> axis=0", axes == {"W1": "axis=0", "W2": "axis=0", "W3": "axis=1", "W4": "axis=0"}, axes)
# chọn đúng trục là vấn đề CHẤT LƯỢNG (trục sai vẫn nạp được): cột có biên độ rất khác nhau, theo cột phải chính xác hơn hẳn theo hàng
Wcol = (rng.normal(0, 1, (64, 128)) * np.logspace(-2, 1, 128)[None, :]).astype("f4")
err_col = np.abs(q.dequantize_per_axis(*q.quantize_per_axis(Wcol, 1), 1) - Wcol).mean()
err_row = np.abs(q.dequantize_per_axis(*q.quantize_per_axis(Wcol, 0), 0) - Wcol).mean()
check("lý do chọn trục đầu ra: với cột biên độ chênh lệch, theo cột sai số nhỏ hơn theo hàng ≥ 3 lần", err_row > 3 * err_col, (err_col, err_row))
check("bias (B1..B4) KHÔNG bị nén ở chế độ int8", all(not c[0].startswith("B") for c in rep8all["converted"]))
check("int8: sai số từng trọng số <= scale/2 + epsilon (thuộc tính của làm tròn đúng)", all(c[3] <= np.abs(weights[c[0]]).max() / 127 / 2 + 1e-6 for c in rep8all["converted"]), [(c[0], c[3]) for c in rep8all["converted"]])
# thuộc tính chính xác trên một tenxơ
W = rng.normal(0, 1, (6, 5, 3)).astype("f4")
for ax in (0, 1, 2):
    qa, sc = q.quantize_per_axis(W, ax)
    deq = q.dequantize_per_axis(qa, sc, ax)
    shp = [1] * 3
    shp[ax] = -1
    bound = sc.reshape(shp) / 2 + 1e-6
    check(f"quantize_per_axis trục {ax}: |dequant - w| <= scale/2 ở MỌI phần tử, int8 trong [-127,127], scale có {W.shape[ax]} phần tử",
          np.all(np.abs(deq - W) <= bound) and qa.dtype == np.int8 and qa.min() >= -127 and qa.max() <= 127 and sc.shape == (W.shape[ax],))
qz, sz = q.quantize_per_axis(np.zeros((4, 3), "f4"), 0)
check("kênh toàn số 0: scale = 1 (không chia cho 0), q = 0", np.all(sz == 1) and np.all(qz == 0))

# đột biến: cắt cụt thay vì làm tròn
amax = np.abs(W.reshape(6, -1)).max(axis=1) / 127
trunc = np.clip(np.trunc(W.reshape(6, -1) / amax[:, None]), -127, 127) * amax[:, None]
check("đột biến: cắt cụt thay vì làm tròn -> vi phạm cận scale/2, BỊ BẮT", np.abs(trunc - W.reshape(6, -1)).max() > (amax.max() / 2) * 1.2)

# trục sai -> onnxruntime từ chối (scale sai kích thước)
bad_nodes_ok = False
try:
    wbad = weights["W3"]
    qb, sb = q.quantize_per_axis(wbad, 0)         # MatMul phải là trục 1; cố tình dùng trục 0
    nodes = [q.make_node("DequantizeLinear", ["Wq", "Ws"], ["W"], "dq", [q.make_attr_int("axis", 1)]), q.make_node("MatMul", ["x", "W"], ["y"], "mm")]
    model = q.make_model(nodes, [q.make_tensor("Wq", wbad.shape, q.INT8, qb.tobytes()), q.make_tensor("Ws", [len(sb)], q.FLOAT, f32(sb))],
                         [q.make_value_info("x", q.FLOAT, [1, 64])], [q.make_value_info("y", q.FLOAT, [1, 128])])
    run(model, {"x": np.zeros((1, 64), "f4")})
except Exception:
    bad_nodes_ok = True
check("đột biến: sai trục (scale theo trục 0 nhưng khai báo axis=1) -> onnxruntime từ chối, BỊ BẮT", bad_nodes_ok)

# ------------------------------------------------------------------ fp16
out16, rep16 = q.quantize_model(base, "fp16", 1000)
y16 = run(out16, {"x": X})[0]
check("fp16: nén mọi hằng số >= 1000 phần tử (W2, W3, W4), W1 (864) và bias nhỏ giữ nguyên", sorted(c[0] for c in rep16["converted"]) == ["W2", "W3", "W4"], rep16["converted"])
check("fp16: gần như không đổi kết quả (cos >= 0.99999)", q.metrics(ref, y16)["cos"] >= 0.99999, q.metrics(ref, y16))
check("fp16: cỡ tệp giảm ≥ 35 % (W1 và bias còn float32)", rep16["bytes_out"] <= 0.65 * rep16["bytes_in"], rep16["bytes_out"] / rep16["bytes_in"])
huge = base
big = (rng.normal(0, 1, (70, 70)) * 1e5).astype("f4")
mm = q.make_model([q.make_node("MatMul", ["x", "Wb"], ["y"], "mm")], [init("Wb", big)], [q.make_value_info("x", q.FLOAT, [1, 70])], [q.make_value_info("y", q.FLOAT, [1, 70])])
_, rep_big = q.quantize_model(mm, "fp16", 100)
check("fp16: trọng số biên độ > 65000 bị bỏ qua (tránh tràn thành Inf) kèm lý do", not rep_big["converted"] and any("float16" in why for _, why in rep_big["skipped"]), rep_big)

# ------------------------------------------------------------------ ConvTranspose, Gemm transB=0
Wt = rng.normal(0, 0.1, (8, 16, 4, 4)).astype("f4")           # [Cin, Cout, kH, kW] -> trục 1
ct = q.make_model([q.make_node("ConvTranspose", ["x", "Wt"], ["y"], "ct", [q.make_attr_ints("strides", [2, 2]), q.make_attr_ints("pads", [1, 1, 1, 1])])],
                  [init("Wt", Wt)], [q.make_value_info("x", q.FLOAT, [1, 8, 6, 6])], [q.make_value_info("y", q.FLOAT, [1, 16, 12, 12])])
xt = rng.random((1, 8, 6, 6)).astype("f4")
oct_, rct = q.quantize_model(ct, "int8", 1000)
check("ConvTranspose(group=1): nén theo trục 1 và kết quả gần bản gốc (cos >= 0.999)",
      rct["converted"] and rct["converted"][0][2] == "axis=1" and q.metrics(run(ct, {"x": xt})[0], run(oct_, {"x": xt})[0])["cos"] >= 0.999)
Wg = rng.normal(0, 0.1, (50, 40)).astype("f4")                 # Gemm transB=0: B [K,N] -> trục 1
gm = q.make_model([q.make_node("Gemm", ["x", "Wg"], ["y"], "g")], [init("Wg", Wg)], [q.make_value_info("x", q.FLOAT, [3, 50])], [q.make_value_info("y", q.FLOAT, [3, 40])])
xg = rng.random((3, 50)).astype("f4")
ogm, rgm = q.quantize_model(gm, "int8", 1000)
check("Gemm transB=0: nén theo trục 1 và kết quả gần bản gốc", rgm["converted"][0][2] == "axis=1" and q.metrics(run(gm, {"x": xg})[0], run(ogm, {"x": xg})[0])["cos"] >= 0.999)

# ------------------------------------------------------------------ trường hợp biên
old, _ = cnn(opset=11, ir=6)
o11, r11 = q.quantize_model(old, "int8", 1)
check("opset < 13: int8 từ chối (trả nguyên bản, ghi lý do), không làm hỏng model", o11 == old and r11["skipped"] and "opset" in r11["skipped"][0][1])
o11b, r11b = q.quantize_model(old, "fp16", 1000)
check("opset < 13: fp16 vẫn làm được (chỉ cần Cast) và model chạy đúng", len(r11b["converted"]) > 0 and q.metrics(run(old, {"x": X})[0], run(o11b, {"x": X})[0])["cos"] >= 0.99999)
asin, _ = cnn(ir=3, w_as_input=True)
oas, ras = q.quantize_model(asin, "int8", 1000)
check("trọng số cũng là input đồ thị (IR cũ): bỏ qua trọng số đó (ghi lý do), vẫn nén phần còn lại (W3, W4 >= 1000 phần tử), model chạy được và gần bản gốc",
      any(n == "W2" and "input" in why for n, why in ras["skipped"]) and sorted(c[0] for c in ras["converted"]) == ["W3", "W4"]
      and q.metrics(run(asin, {"x": X})[0], run(oas, {"x": X})[0])["cos"] >= 0.999)
dyn, _ = cnn(dyn_batch=True)
odyn, _ = q.quantize_model(dyn, "int8", 1000)
X3 = rng.random((3, 3, 16, 16)).astype("f4")
check("batch động (chiều tên 'N'): model nén chạy với batch 3 và gần bản gốc", q.metrics(run(dyn, {"x": X3})[0], run(odyn, {"x": X3})[0])["cos"] >= 0.9995)
# trọng số dùng chung hai Conv
Ws = rng.normal(0, 0.1, (16, 16, 3, 3)).astype("f4")
sh = q.make_model([q.make_node("Conv", ["x", "Ws"], ["a"], "c1", [q.make_attr_ints("pads", [1, 1, 1, 1])]),
                   q.make_node("Conv", ["a", "Ws"], ["y"], "c2", [q.make_attr_ints("pads", [1, 1, 1, 1])])],
                  [init("Ws", Ws)], [q.make_value_info("x", q.FLOAT, [1, 16, 8, 8])], [q.make_value_info("y", q.FLOAT, [1, 16, 8, 8])])
xs = rng.random((1, 16, 8, 8)).astype("f4")
osh, rsh = q.quantize_model(sh, "int8", 100)
check("trọng số dùng chung bởi hai Conv: chỉ nén MỘT lần, cả hai nút đều chạy đúng", len(rsh["converted"]) == 1 and q.metrics(run(sh, {"x": xs})[0], run(osh, {"x": xs})[0])["cos"] >= 0.999)
# external data
ext = q.emit([(1, 0, 64), (2, 0, q.FLOAT), (8, 2, b"Wext"), (13, 2, q.emit([(1, 2, b"location"), (2, 2, b"w.bin")]))])
mext = q.make_model([q.make_node("MatMul", ["x", "Wext"], ["y"], "mm")], [ext], [q.make_value_info("x", q.FLOAT, [1, 8])], [q.make_value_info("y", q.FLOAT, [1, 8])])
oe, re_ = q.quantize_model(mext, "int8", 1)
check("external data: bỏ qua kèm lý do, không ném lỗi", oe == mext and any("external" in why for _, why in re_["skipped"]), re_)
# tệp rác
raised = False
try:
    q.quantize_model(b"\xff\xff\xff\xff day khong phai onnx" * 3, "int8", 1)
except ValueError:
    raised = True
check("tệp không phải ONNX: ném ValueError rõ ràng", raised)
raised2 = False
try:
    q.quantize_model(base[:200], "int8", 1)
except ValueError:
    raised2 = True
check("tệp bị cắt cụt: ném ValueError (không treo, không ghi rác)", raised2)
# idempotent
again, rag = q.quantize_model(out8, "int8", 4096)
check("chạy lại trên model đã nén int8: không nén thêm (không còn float32 Conv/MatMul đủ lớn ngoài các hằng số đã đổi)", not rag["converted"] or len(rag["converted"]) == 0, rag["converted"])

# ------------------------------------------------------------------ giao diện dòng lệnh + verify bằng ORT
with tempfile.TemporaryDirectory() as td:
    src, dst = os.path.join(td, "a.onnx"), os.path.join(td, "b.onnx")
    open(src, "wb").write(base)
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = q.main([src, dst, "--mode", "int8", "--verify"])
    text = buf.getvalue()
    check("CLI --verify: mã thoát 0, in cos / cỡ tệp và NÓI RÕ chỉ là nén cỡ tệp + đầu vào ngẫu nhiên không thay cho ảnh thật",
          rc == 0 and "cos=" in text and "nén cỡ tệp" in text and "ảnh thật" in text, text)
    xnpy = os.path.join(td, "x.npy")
    np.save(xnpy, X)
    buf2 = io.StringIO()
    with contextlib.redirect_stdout(buf2):
        rc2 = q.main([src, dst, "--mode", "fp16", "--min-elements", "1000", "--verify", "--input-npy", "x=" + xnpy])
    check("CLI với --input-npy (ảnh thật): đạt", rc2 == 0 and "ĐẠT" in buf2.getvalue(), buf2.getvalue())
    buf3 = io.StringIO()
    with contextlib.redirect_stdout(buf3):
        rc3 = q.main([src, dst, "--mode", "int8", "--verify", "--min-cos", "0.9999999999"])
    check("CLI: ngưỡng cos quá chặt -> KHÔNG ĐẠT, mã thoát 2 (cổng chất lượng hoạt động)", rc3 == 2 and "KHÔNG ĐẠT" in buf3.getvalue(), buf3.getvalue())
    check("CLI: tệp ra là ONNX hợp lệ nạp được", ort.InferenceSession(dst, providers=["CPUExecutionProvider"]) is not None)

print("\n" + ("TẤT CẢ OK" if not fails else f"CÓ {len(fails)} LỖI: {fails}"))
sys.exit(1 if fails else 0)
