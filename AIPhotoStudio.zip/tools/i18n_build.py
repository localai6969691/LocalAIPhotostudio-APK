#!/usr/bin/env python3
"""Quản lý gói dịch của app (R33): gán mã cố định cho chuỗi, kiểm tra, xây `assets/i18n/*.json` và `assets/help/*.json`.

NGUỒN SỰ THẬT
  tools/i18n/ids.json          danh sách khóa (chuỗi tiếng Việt nguồn); MÃ = vị trí trong danh sách, CHỈ THÊM CUỐI, không bao giờ đổi chỗ / xóa
                               (nhờ vậy các tệp dịch tham chiếu theo mã không lệch khi mã nguồn thêm chuỗi mới). `core` = số khóa đầu là giao diện
                               chính (mọi ngôn ngữ phải dịch đủ); `ui` = số khóa đầu thuộc màn hình giao diện (tiếng Anh phải dịch đủ).
  tools/i18n/src/<mã>.txt      mỗi dòng  `mã|bản dịch`  (dòng trống và dòng bắt đầu bằng # bị bỏ qua). Chỗ trống {0},{1} phải giữ nguyên.
  tools/i18n/help/<mã>.json|.txt  nội dung Trợ giúp (cùng cấu trúc ở mọi ngôn ngữ, lấy tiếng Việt làm chuẩn); .txt là dạng gọn `= nhóm` / `- mục | nội dung`.
SẢN PHẨM (được commit, app đọc lúc chạy)
  app/src/main/assets/i18n/<mã>.json   {khóa tiếng Việt: bản dịch}      app/src/main/assets/i18n/index.json  {keys, packs{mã: số mục}}
  app/src/main/assets/help/<mã>.json   chép từ tools/i18n/help/

LỆNH   python tools/i18n_build.py --assign   thêm khóa mới (từ mã nguồn) vào ids.json
       python tools/i18n_build.py --check    kiểm tra mọi gói + Trợ giúp, in độ phủ (mã thoát 1 nếu có LỖI)
       python tools/i18n_build.py --build    kiểm tra rồi ghi assets
       python tools/i18n_build.py --verify   kiểm tra + đối chiếu assets trên đĩa với nguồn (mã thoát 1 nếu cũ)
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import i18n_extract as X  # noqa: E402

IDS = os.path.join(HERE, "i18n", "ids.json")
SRC = os.path.join(HERE, "i18n", "src")
HELP = os.path.join(HERE, "i18n", "help")
ASSETS = os.path.join(PROJ, "app", "src", "main", "assets")
LANGS = ["en", "zh", "es", "hi", "ar", "pt", "ru", "ja", "ko", "fr", "de", "id"]  # khớp AppLanguages.ALL (trừ vi)
PH = re.compile(r"\{(\d+)\}")
# chữ cái RIÊNG của tiếng Việt (ă đ ơ ư và các chữ có dấu thanh): gói dịch Latin (en, es, pt, fr, de, id) không được lẫn vào
VI_ONLY = re.compile(r"[ăđơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹĂĐƠƯẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼẾỀỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸ]")  # không gồm â ê ô (có trong tiếng Bồ Đào Nha, Pháp)
SCRIPT = {
    "zh": re.compile(r"[\u4e00-\u9fff]"), "ja": re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]"), "ko": re.compile(r"[\uac00-\ud7af]"),
    "ar": re.compile(r"[\u0600-\u06ff]"), "hi": re.compile(r"[\u0900-\u097f]"), "ru": re.compile(r"[\u0400-\u04ff]"),
}
SYMS = "×÷→←↑↓↔±°%✓▲▼●+★☆…"


def load_ids():
    with open(IDS, encoding="utf-8") as f:
        return json.load(f)


def assign():
    keys = X.collect()
    if os.path.exists(IDS):
        d = load_ids()
        have = set(d["keys"])
        add = [k for k in keys if k not in have]
        d["keys"] += add
        print(f"Thêm {len(add)} khóa mới (tổng {len(d['keys'])}).")
    else:
        ui = [k for k, w in keys.items() if w[0].startswith("ui/")]
        newui = [k for k in ui if keys[k][0].startswith("ui/HelpDialog.kt")]
        core = newui + [k for k in ui if k not in newui and len(k) <= 22]
        rest_ui = [k for k in ui if k not in core]
        others = [k for k in keys if k not in set(ui)]
        d = {"core": len(core), "ui": len(core) + len(rest_ui), "keys": core + rest_ui + others}
        print(f"Tạo mới: core {d['core']}, ui {d['ui']}, tổng {len(d['keys'])}.")
    os.makedirs(os.path.dirname(IDS), exist_ok=True)
    with open(IDS, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=0)
        f.write("\n")


def read_src(code, ids):
    """Trả ({mã: bản_dịch}, [lỗi], [cảnh_báo])."""
    path = os.path.join(SRC, code + ".txt")
    out, errs, warns = {}, [], []
    if not os.path.exists(path):
        return out, [f"{code}: thiếu {os.path.relpath(path, PROJ)}"], warns
    n = len(ids["keys"])
    for ln, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        m = re.match(r"^(\d+)\|(.*)$", line)
        if not m:
            errs.append(f"{code}:{ln}: dòng không đúng dạng `mã|bản dịch`")
            continue
        i, tr = int(m.group(1)), m.group(2).strip()
        if i >= n:
            errs.append(f"{code}:{ln}: mã {i} không tồn tại (ids.json có {n} khóa)")
            continue
        if i in out:
            errs.append(f"{code}:{ln}: mã {i} bị dịch hai lần")
            continue
        key = ids["keys"][i]
        if not tr:
            errs.append(f"{code}:{ln}: mã {i} bản dịch rỗng")
            continue
        if sorted(PH.findall(key)) != sorted(PH.findall(tr)):
            errs.append(f"{code}:{ln}: mã {i} chỗ trống không khớp: khóa {sorted(PH.findall(key))} ≠ dịch {sorted(PH.findall(tr))} ({key!r} → {tr!r})")
        kd = sorted(re.findall(r"\d", PH.sub("", key)))
        td = sorted(re.findall(r"\d", PH.sub("", tr)))
        if kd != td:
            errs.append(f"{code}:{ln}: mã {i} chữ số không khớp: {key!r} → {tr!r}")
        for ch in SYMS:
            alt = {"→": "←", "←": "→"}.get(ch) if code == "ar" else None  # tiếng Ả Rập viết phải→trái: được phép phản chiếu mũi tên
            if ch in key and ch not in tr and not (alt and alt in tr):
                errs.append(f"{code}:{ln}: mã {i} thiếu ký hiệu {ch!r} của khóa: {key!r} → {tr!r}")
        if code in SCRIPT:
            if not SCRIPT[code].search(tr):
                warns.append(f"{code}:{ln}: mã {i} không có chữ của ngôn ngữ ({key!r} → {tr!r})")
        elif VI_ONLY.search(tr):
            errs.append(f"{code}:{ln}: mã {i} còn chữ tiếng Việt trong bản dịch: {tr!r}")
        out[i] = tr
    return out, errs, warns


def parse_help_txt(path):
    """Dạng gọn để viết bản dịch:  `= Tiêu đề nhóm`  rồi các dòng  `- Tiêu đề mục | Nội dung`  (dòng trống và # bị bỏ qua)."""
    secs = []
    for ln, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line.startswith("= "):
            secs.append({"title": line[2:].strip(), "items": []})
        elif line.startswith("- ") and secs:
            if " | " not in line:
                raise ValueError(f"dòng {ln}: thiếu ' | ' giữa tiêu đề và nội dung")
            t, b = line[2:].split(" | ", 1)
            secs[-1]["items"].append({"t": t.strip(), "b": b.strip()})
        else:
            raise ValueError(f"dòng {ln}: không đúng dạng")
    return {"sections": secs}


def check_help(code, base):
    path = os.path.join(HELP, code + ".json")
    txt = os.path.join(HELP, code + ".txt")
    if not os.path.exists(path) and not os.path.exists(txt):
        return None, [f"help/{code}: thiếu {os.path.relpath(path, PROJ)} (hoặc .txt)"]
    errs = []
    try:
        d = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else parse_help_txt(txt)
    except ValueError as e:
        return None, [f"help/{code}: nguồn hỏng: {e}"]
    secs = d.get("sections")
    if not isinstance(secs, list):
        return None, [f"help/{code}: thiếu sections"]
    shape = [len(s.get("items", [])) for s in secs]
    if base is not None and shape != base:
        errs.append(f"help/{code}: cấu trúc {shape} khác tiếng Việt {base}")
    for si, s in enumerate(secs):
        if not str(s.get("title", "")).strip():
            errs.append(f"help/{code}: nhóm {si} thiếu tiêu đề")
        for ii, it in enumerate(s.get("items", [])):
            t, b = str(it.get("t", "")).strip(), str(it.get("b", "")).strip()
            if not t or not b:
                errs.append(f"help/{code}: nhóm {si} mục {ii} thiếu tiêu đề/nội dung")
            if code in SCRIPT and not SCRIPT[code].search(t + b):
                errs.append(f"help/{code}: nhóm {si} mục {ii} không có chữ của ngôn ngữ")
            if code not in SCRIPT and code != "vi" and VI_ONLY.search(t + b):
                errs.append(f"help/{code}: nhóm {si} mục {ii} còn chữ tiếng Việt")
    return d, errs


def run(build, verify=False):
    ids = load_ids()
    n = len(ids["keys"])
    allerr, allwarn, packs = [], [], {}
    base = None
    hv, e = check_help("vi", None)
    allerr += e
    if hv:
        base = [len(s["items"]) for s in hv["sections"]]
    helps = {"vi": hv}
    for code in LANGS:
        out, errs, warns = read_src(code, ids)
        allerr += errs
        allwarn += warns
        packs[code] = out
        miss_core = [i for i in range(ids["core"]) if i not in out]
        if miss_core:
            allerr.append(f"{code}: thiếu {len(miss_core)} khóa CORE (ví dụ mã {miss_core[:6]})")
        if code == "en":
            miss_ui = [i for i in range(ids["ui"]) if i not in out]
            if miss_ui:
                allerr.append(f"en: thiếu {len(miss_ui)} khóa giao diện (ví dụ mã {miss_ui[:6]})")
        h, e = check_help(code, base)
        allerr += e
        helps[code] = h
    print(f"Khóa: {n} (core {ids['core']}, giao diện {ids['ui']}, còn lại {n - ids['ui']})")
    for code in LANGS:
        print(f"  {code}: {len(packs[code]):4d} mục = {100 * len(packs[code]) // n:3d}%   Trợ giúp: {'có' if helps.get(code) else 'THIẾU'}")
    for w in allwarn[:15]:
        print("  cảnh báo:", w)
    if len(allwarn) > 15:
        print(f"  … và {len(allwarn) - 15} cảnh báo nữa")
    for e in allerr:
        print("LỖI:", e)
    if allerr:
        return 1
    # sản phẩm dự kiến (đường dẫn → nội dung) để vừa ghi (--build) vừa đối chiếu với đĩa (--verify)
    outputs = {}
    for code in LANGS:
        outputs[os.path.join(ASSETS, "i18n", code + ".json")] = json.dumps({ids["keys"][i]: packs[code][i] for i in sorted(packs[code])}, ensure_ascii=False, indent=0) + "\n"
    outputs[os.path.join(ASSETS, "i18n", "index.json")] = json.dumps({"keys": n, "packs": {c: len(packs[c]) for c in LANGS}}, ensure_ascii=False) + "\n"
    for code in ["vi"] + LANGS:
        outputs[os.path.join(ASSETS, "help", code + ".json")] = json.dumps(helps[code], ensure_ascii=False, indent=0) + "\n"
    if verify:
        stale = [os.path.relpath(p, PROJ) for p, txt in outputs.items() if not os.path.exists(p) or open(p, encoding="utf-8").read() != txt]
        for p in stale:
            print("LỖI: assets cũ so với nguồn dịch:", p, "(chạy python tools/i18n_build.py --build)")
        return 1 if stale else 0
    if build:
        for p, txt in outputs.items():
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(txt)
        print("Đã ghi assets/i18n/* và assets/help/*")
    return 0


if __name__ == "__main__":
    a = sys.argv[1:]
    if "--assign" in a:
        assign()
    elif "--build" in a:
        sys.exit(run(True))
    elif "--verify" in a:
        sys.exit(run(False, True))
    else:
        sys.exit(run(False))
