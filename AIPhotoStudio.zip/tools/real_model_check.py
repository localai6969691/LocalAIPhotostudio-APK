#!/usr/bin/env python3
"""Kiểm HỢP ĐỒNG vào/ra của model ONNX THẬT với cách mã Kotlin tiền xử lý (R37/R37b) — cần mạng tới github.com, KHÔNG nằm trong static_check / CI.

Vì sao: các hợp đồng ở DepthEstimator.kt / OnnxSegmenter.kt / SamSegmenter.kt / MiganInpainter.kt trước đây chỉ "tra cứu từ tài liệu". Ở đây chạy model thật bằng ONNX Runtime
(Python) với đúng công thức tiền xử lý của Kotlin (chép lại từng dòng) rồi kiểm tên/shape đầu vào, số đầu ra, thang giá trị và CHIỀU của kết quả.
Nguồn trọng số — đều là GitHub Releases, tải được trong sandbox (HuggingFace / Maven / storage.googleapis.com bị chặn):
  U²-Net-P      github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx                    4,6 MB   Apache-2.0
  IS-Net        github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx         178 MB   Apache-2.0
  Depth Anything V2 Small  github.com/fabio-sim/Depth-Anything-ONNX/releases/download/v2.0.0/depth_anything_v2_vits.onnx  99 MB  Apache-2.0
  MobileSAM     github.com/palavido-dev/gratis-gis/releases/download/models-mobilesam-v1/mobilesam-{encoder,decoder}.onnx  28 MB + 16,5 MB  Apache-2.0 (xuất từ checkpoint chính thức)
  MI-GAN        github.com/son-engr-kr/pickapicka/releases/download/models-0.2.0/migan_pipeline_v2.onnx   28 MB  MIT  (SHA-256 công bố bên dưới)
Chưa có nguồn GitHub: LaMa ONNX (chỉ HuggingFace), Real-ESRGAN ONNX.
Chạy:  python3 tools/real_model_check.py ẢNH_CHÂN_DUNG.jpg [thư_mục_model=/tmp/models] [--skip-big]   (--skip-big bỏ IS-Net 178 MB)
"""
import hashlib
import os
import sys
import urllib.request

import cv2
import numpy as np
import onnxruntime as ort

GH = "https://github.com/"
MODELS = {
    "u2netp.onnx": (GH + "danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx", None),
    "isnet-general-use.onnx": (GH + "danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx", None),
    "depth_anything_v2_vits.onnx": (GH + "fabio-sim/Depth-Anything-ONNX/releases/download/v2.0.0/depth_anything_v2_vits.onnx", None),
    "mobilesam-encoder.onnx": (GH + "palavido-dev/gratis-gis/releases/download/models-mobilesam-v1/mobilesam-encoder.onnx", None),
    "mobilesam-decoder.onnx": (GH + "palavido-dev/gratis-gis/releases/download/models-mobilesam-v1/mobilesam-decoder.onnx", None),
    "migan_pipeline_v2.onnx": (GH + "son-engr-kr/pickapicka/releases/download/models-0.2.0/migan_pipeline_v2.onnx",
                               "6f1f3530a1a2324b19752018ce756088b07973cda8d7d890034ace5c8a48c40b"),
}
MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)


def fetch(d, name):
    path = os.path.join(d, name)
    if not os.path.exists(path):
        os.makedirs(d, exist_ok=True)
        print("tải", name, "…")
        urllib.request.urlretrieve(MODELS[name][0], path)
    want = MODELS[name][1]
    if want:
        got = hashlib.sha256(open(path, "rb").read()).hexdigest()
        assert got == want, "SHA-256 %s khác công bố: %s" % (name, got)
    return ort.InferenceSession(path, providers=["CPUExecutionProvider"])


def box(m, y0, y1, x0, x1):
    h, w = m.shape
    return float(m[int(y0 * h):int(y1 * h), int(x0 * w):int(x1 * w)].mean())


def check_depth(sess, rgb):
    """DepthEstimator.kt + DepthProfile: vào [1,3,H,W] (H,W cố định theo model), (điểm/255 - mean)/std ImageNet; ra nghịch đảo độ sâu, LỚN = GẦN."""
    inp = sess.get_inputs()[0]
    shp = inp.shape
    assert len(shp) == 4 and shp[1] == 3, "không phải model ảnh [batch,3,H,W]: %s" % (shp,)
    H, W = int(shp[2]), int(shp[3])
    x = (cv2.resize(rgb, (W, H), interpolation=cv2.INTER_LINEAR).astype(np.float32) / 255 - MEAN) / STD
    out = sess.run(None, {inp.name: np.transpose(x, (2, 0, 1))[None].astype(np.float32)})[0]
    d = np.squeeze(out)                                              # DepthEstimator.collectRows: mọi hạng tensor đều được làm phẳng thành hàng
    assert d.ndim == 2, "đầu ra không đưa về 2 chiều được: %s" % (out.shape,)
    face = box(d, .15, .55, .30, .70)
    border = (box(d, 0, .2, 0, .15) + box(d, 0, .2, .85, 1)) / 2
    print("Depth Anything V2: vào %s %s, ra %s, giữa %.2f vs viền %.2f -> %s" % (inp.name, shp, out.shape, face, border, "đúng chiều (lớn = gần)" if face > border else "NGƯỢC CHIỀU"))
    return face > border


def check_seg(sess, rgb, size, std, label):
    """OnnxSegmenter.kt: ảnh VUÔNG size, chia cho giá trị lớn nhất, trừ mean ImageNet, chia std (U²-Net: ImageNet; IS-Net: 1); lấy đầu ra[0], kéo min-max về 0..1."""
    inp = sess.get_inputs()[0]
    small = cv2.resize(rgb, (size, size), interpolation=cv2.INTER_LINEAR).astype(np.float32)
    x = (small / max(float(small.max()), 1e-6) - MEAN) / std
    outs = sess.run(None, {inp.name: np.transpose(x, (2, 0, 1))[None].astype(np.float32)})
    o = outs[0][0, 0]
    mn, mx = float(o.min()), float(o.max())
    m = (o - mn) / (mx - mn + 1e-8)
    fg = box(m, .15, .7, .3, .7)
    bg = (box(m, 0, .15, 0, .12) + box(m, 0, .15, .88, 1)) / 2
    print("%s: vào %s %s, %d đầu ra, đầu ra[0] %s thô [%.3f..%.3f], matte giữa %.2f vs viền %.2f -> %s" % (label, inp.name, inp.shape, len(outs), outs[0].shape, mn, mx, fg, bg, "đúng" if fg > bg + 0.3 else "SAI"))
    return fg > bg + 0.3


def check_sam(enc, dec, rgb):
    """SamSegmenter.kt: cạnh dài = 1024, mean/std SAM theo thang 0..255, đệm 0 sau chuẩn hóa; decoder [image_embeddings, point_coords, point_labels(+điểm đệm -1), mask_input, has_mask_input, orig_im_size]; masks [1,1,H,W] logit, > 0 = vật thể."""
    h, w = rgb.shape[:2]
    sc = 1024 / max(w, h)
    nw, nh = min(1024, max(1, int(w * sc + .5))), min(1024, max(1, int(h * sc + .5)))
    mean = np.array([123.675, 116.28, 103.53], np.float32)
    std = np.array([58.395, 57.12, 57.375], np.float32)
    data = np.zeros((3, 1024, 1024), np.float32)
    data[:, :nh, :nw] = np.transpose((cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_LINEAR).astype(np.float32) - mean) / std, (2, 0, 1))
    emb = enc.run(None, {enc.get_inputs()[0].name: data[None]})[0]
    px, py = 0.5, 0.25                                   # chạm vào giữa phần trên (mặt / đầu chủ thể chân dung)
    coords = np.array([[px * w * sc, py * h * sc], [0, 0]], np.float32)[None]
    labels = np.array([[1, -1]], np.float32)
    names = [i.name for i in dec.get_inputs()]
    assert names == ["image_embeddings", "point_coords", "point_labels", "mask_input", "has_mask_input", "orig_im_size"], names
    m = dec.run(None, {"image_embeddings": emb, "point_coords": coords, "point_labels": labels, "mask_input": np.zeros((1, 1, 256, 256), np.float32),
                       "has_mask_input": np.zeros(1, np.float32), "orig_im_size": np.array([h, w], np.float32)})[0]
    ok = m.size == h * w and bool((m.reshape(h, w)[int(py * h), int(px * w)] > 0))
    print("MobileSAM: embeddings %s, masks %s (đủ h*w: %s), điểm chạm nằm trong mask: %s, mask phủ %.0f%% ảnh -> %s" % (emb.shape, m.shape, m.size == h * w, m.reshape(h, w)[int(py * h), int(px * w)] > 0, 100 * (m > 0).mean(), "đúng" if ok else "SAI"))
    return ok


def check_migan(sess, rgb):
    """MiganInpainter.kt: image uint8 [1,3,H,W] RGB, mask uint8 [1,1,H,W] với 0 = vùng cần điền, 255 = giữ; output uint8 [1,3,H,W] đã ghép sẵn; ngoài vùng xóa phải KHÔNG đổi."""
    h, w = rgb.shape[:2]
    mask = np.full((h, w), 255, np.uint8)
    cv2.circle(mask, (int(.5 * w), int(.62 * h)), int(.06 * w), 0, -1)
    out = sess.run(None, {"image": np.transpose(rgb, (2, 0, 1))[None].astype(np.uint8), "mask": mask[None, None]})[0]
    res = np.transpose(out[0], (1, 2, 0))
    far = cv2.erode((mask == 255).astype(np.uint8), np.ones((31, 31), np.uint8)) == 1
    d = np.abs(res.astype(int) - rgb.astype(int)).max(axis=2)
    ok = out.shape == (1, 3, h, w) and out.dtype == np.uint8 and d[far].max() == 0 and d[mask == 0].mean() > 5
    print("MI-GAN: ra %s %s, ngoài vùng xóa lệch lớn nhất %d (phải 0), trong vùng xóa lệch TB %.1f -> %s" % (out.shape, out.dtype, d[far].max(), d[mask == 0].mean(), "đúng" if ok else "SAI"))
    return ok


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    img = args[0]
    mdir = args[1] if len(args) > 1 else "/tmp/models"
    rgb = cv2.cvtColor(cv2.imread(img), cv2.COLOR_BGR2RGB)
    ok = True
    ok &= check_depth(fetch(mdir, "depth_anything_v2_vits.onnx"), rgb)
    ok &= check_seg(fetch(mdir, "u2netp.onnx"), rgb, 320, STD, "U²-Net-P")
    if "--skip-big" not in sys.argv:
        ok &= check_seg(fetch(mdir, "isnet-general-use.onnx"), rgb, 1024, np.ones(3, np.float32), "IS-Net")
    ok &= check_sam(fetch(mdir, "mobilesam-encoder.onnx"), fetch(mdir, "mobilesam-decoder.onnx"), rgb)
    ok &= check_migan(fetch(mdir, "migan_pipeline_v2.onnx"), rgb)
    print("TẤT CẢ ĐÚNG" if ok else "CÓ CHỖ SAI")
    sys.exit(0 if ok else 1)
