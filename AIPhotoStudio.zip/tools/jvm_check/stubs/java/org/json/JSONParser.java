package org.json;
final class JSONParser {
    private final String in; private int pos;
    JSONParser(String s) { in = s == null ? "" : s; }
    private JSONException err(String m) { return new JSONException(m + " at character " + pos + " of " + in); }
    private void ws() { while (pos < in.length() && Character.isWhitespace(in.charAt(pos))) pos++; }
    Object readValue() throws JSONException {
        ws();
        if (pos >= in.length()) throw err("End of input");
        char c = in.charAt(pos);
        Object r;
        if (c == '{') r = readObject();
        else if (c == '[') r = readArray();
        else if (c == '"' || c == '\'') r = readString(c);
        else r = readLiteral();
        return r;
    }
    private JSONObject readObject() throws JSONException {
        JSONObject o = new JSONObject(); pos++; ws();
        if (pos < in.length() && in.charAt(pos) == '}') { pos++; return o; }
        while (true) {
            ws(); if (pos >= in.length()) throw err("Unterminated object");
            char c = in.charAt(pos);
            String name;
            if (c == '"' || c == '\'') name = readString(c); else throw err("Names must be strings");
            ws(); if (pos >= in.length() || in.charAt(pos) != ':') throw err("Expected ':'"); pos++;
            Object v = readValue();
            o.put(name, v);
            ws(); if (pos >= in.length()) throw err("Unterminated object");
            char d = in.charAt(pos++);
            if (d == '}') return o;
            if (d != ',' && d != ';') throw err("Unterminated object");
        }
    }
    private JSONArray readArray() throws JSONException {
        JSONArray a = new JSONArray(); pos++; ws();
        if (pos < in.length() && in.charAt(pos) == ']') { pos++; return a; }
        while (true) {
            Object v = readValue(); a.put(v);
            ws(); if (pos >= in.length()) throw err("Unterminated array");
            char d = in.charAt(pos++);
            if (d == ']') return a;
            if (d != ',' && d != ';') throw err("Unterminated array");
        }
    }
    private String readString(char q) throws JSONException {
        pos++; StringBuilder sb = new StringBuilder();
        while (pos < in.length()) {
            char c = in.charAt(pos++);
            if (c == q) return sb.toString();
            if (c == '\\') {
                if (pos >= in.length()) throw err("Unterminated escape");
                char e = in.charAt(pos++);
                switch (e) {
                    case 'u': if (pos + 4 > in.length()) throw err("Unterminated escape"); sb.append((char) Integer.parseInt(in.substring(pos, pos + 4), 16)); pos += 4; break;
                    case 't': sb.append('\t'); break; case 'b': sb.append('\b'); break; case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break; case 'f': sb.append('\f'); break;
                    default: sb.append(e);
                }
            } else sb.append(c);
        }
        throw err("Unterminated string");
    }
    private Object readLiteral() throws JSONException {
        int s = pos;
        while (pos < in.length() && ",:]}/\\\"[{;=# \t\r\n".indexOf(in.charAt(pos)) == -1) pos++;
        String lit = in.substring(s, pos);
        if (lit.isEmpty()) throw err("Expected literal value");
        if (lit.equalsIgnoreCase("null")) return JSONObject.NULL;
        if (lit.equalsIgnoreCase("true")) return Boolean.TRUE;
        if (lit.equalsIgnoreCase("false")) return Boolean.FALSE;
        try {
            if (lit.indexOf('.') == -1 && lit.indexOf('e') == -1 && lit.indexOf('E') == -1) {
                long l = Long.parseLong(lit);
                if (l == (int) l) return (int) l; return l;
            }
            return Double.valueOf(lit);
        } catch (NumberFormatException e) { return lit; }
    }
}
