package org.json;
import java.util.*;
final class JSONWriter {
    static void write(Object v, StringBuilder sb) throws JSONException {
        if (v == null || v == JSONObject.NULL) { sb.append("null"); }
        else if (v instanceof JSONObject) {
            JSONObject o = (JSONObject) v; sb.append('{'); boolean first = true;
            for (String k : o.keySet()) { if (!first) sb.append(','); first = false; sb.append(quote(k)).append(':'); write(o.opt(k), sb); }
            sb.append('}');
        } else if (v instanceof JSONArray) {
            JSONArray a = (JSONArray) v; sb.append('[');
            for (int i = 0; i < a.length(); i++) { if (i > 0) sb.append(','); write(a.opt(i), sb); }
            sb.append(']');
        } else if (v instanceof Number) sb.append(JSON.numberToString((Number) v));
        else if (v instanceof Boolean) sb.append(v);
        else sb.append(quote(String.valueOf(v)));
    }
    static String quote(String s) {
        if (s == null) return "\"\"";
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': case '\\': out.append('\\').append(c); break;
                case '/': out.append("\\/"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\f': out.append("\\f"); break;
                default: if (c <= 0x1F) out.append(String.format("\\u%04x", (int) c)); else out.append(c);
            }
        }
        return out.append('"').toString();
    }
}
