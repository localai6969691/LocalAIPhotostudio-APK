package org.json;
import java.util.*;
public class JSONArray {
    private final List<Object> values;
    public JSONArray() { values = new ArrayList<>(); }
    public JSONArray(Collection copyFrom) { this(); for (Object o : copyFrom) values.add(JSONObject.wrap(o)); }
    public JSONArray(String json) throws JSONException {
        Object v = new JSONParser(json).readValue();
        if (!(v instanceof JSONArray)) throw new JSONException("Value " + v + " cannot be converted to JSONArray");
        values = ((JSONArray) v).values;
    }
    public int length() { return values.size(); }
    public JSONArray put(boolean value) { values.add(value); return this; }
    public JSONArray put(double value) throws JSONException { values.add(JSON.checkDouble(value)); return this; }
    public JSONArray put(int value) { values.add(value); return this; }
    public JSONArray put(long value) { values.add(value); return this; }
    public JSONArray put(Object value) { values.add(value); return this; }
    public JSONArray put(int index, Object value) throws JSONException {
        if (value instanceof Number) JSON.checkDouble(((Number) value).doubleValue());
        while (values.size() <= index) values.add(null);
        values.set(index, value); return this;
    }
    public boolean isNull(int index) { Object v = opt(index); return v == null || v == JSONObject.NULL; }
    public Object get(int index) throws JSONException {
        try { Object v = values.get(index); if (v == null) throw new JSONException("Value at " + index + " is null."); return v; }
        catch (IndexOutOfBoundsException e) { throw new JSONException("Index " + index + " out of range [0.." + values.size() + ")", e); }
    }
    public Object opt(int index) { if (index < 0 || index >= values.size()) return null; return values.get(index); }
    public Object remove(int index) { if (index < 0 || index >= values.size()) return null; return values.remove(index); }
    public boolean getBoolean(int i) throws JSONException { Object o = get(i); Boolean r = JSON.toBoolean(o); if (r == null) throw JSON.typeMismatch(i, o, "boolean"); return r; }
    public boolean optBoolean(int i) { return optBoolean(i, false); }
    public boolean optBoolean(int i, boolean f) { Boolean r = JSON.toBoolean(opt(i)); return r != null ? r : f; }
    public double getDouble(int i) throws JSONException { Object o = get(i); Double r = JSON.toDouble(o); if (r == null) throw JSON.typeMismatch(i, o, "double"); return r; }
    public double optDouble(int i) { return optDouble(i, Double.NaN); }
    public double optDouble(int i, double f) { Double r = JSON.toDouble(opt(i)); return r != null ? r : f; }
    public int getInt(int i) throws JSONException { Object o = get(i); Integer r = JSON.toInteger(o); if (r == null) throw JSON.typeMismatch(i, o, "int"); return r; }
    public int optInt(int i) { return optInt(i, 0); }
    public int optInt(int i, int f) { Integer r = JSON.toInteger(opt(i)); return r != null ? r : f; }
    public long getLong(int i) throws JSONException { Object o = get(i); Long r = JSON.toLong(o); if (r == null) throw JSON.typeMismatch(i, o, "long"); return r; }
    public long optLong(int i) { return optLong(i, 0L); }
    public long optLong(int i, long f) { Long r = JSON.toLong(opt(i)); return r != null ? r : f; }
    public String getString(int i) throws JSONException { Object o = get(i); String r = JSON.toString(o); if (r == null) throw JSON.typeMismatch(i, o, "String"); return r; }
    public String optString(int i) { return optString(i, ""); }
    public String optString(int i, String f) { String r = JSON.toString(opt(i)); return r != null ? r : f; }
    public JSONArray getJSONArray(int i) throws JSONException { Object o = get(i); if (o instanceof JSONArray) return (JSONArray) o; throw JSON.typeMismatch(i, o, "JSONArray"); }
    public JSONArray optJSONArray(int i) { Object o = opt(i); return o instanceof JSONArray ? (JSONArray) o : null; }
    public JSONObject getJSONObject(int i) throws JSONException { Object o = get(i); if (o instanceof JSONObject) return (JSONObject) o; throw JSON.typeMismatch(i, o, "JSONObject"); }
    public JSONObject optJSONObject(int i) { Object o = opt(i); return o instanceof JSONObject ? (JSONObject) o : null; }
    @Override public String toString() {
        try { StringBuilder sb = new StringBuilder(); JSONWriter.write(this, sb); return sb.toString(); }
        catch (JSONException e) { return null; }
    }
    public String toString(int indentSpaces) throws JSONException { return toString(); }
}
