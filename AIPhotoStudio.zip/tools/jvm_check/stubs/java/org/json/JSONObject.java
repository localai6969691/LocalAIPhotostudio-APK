package org.json;
import java.util.*;
public class JSONObject {
    public static final Object NULL = new Object() {
        @Override public boolean equals(Object o) { return o == this || o == null; }
        @Override public int hashCode() { return Objects.hashCode(null); }
        @Override public String toString() { return "null"; }
    };
    private final LinkedHashMap<String, Object> nameValuePairs = new LinkedHashMap<>();
    public JSONObject() {}
    public JSONObject(Map copyFrom) {
        for (Object e : copyFrom.entrySet()) {
            Map.Entry en = (Map.Entry) e;
            nameValuePairs.put((String) en.getKey(), wrap(en.getValue()));
        }
    }
    public JSONObject(String json) throws JSONException {
        Object v = new JSONParser(json).readValue();
        if (!(v instanceof JSONObject)) throw new JSONException("Value " + v + " of type " + (v == null ? "null" : v.getClass().getName()) + " cannot be converted to JSONObject");
        nameValuePairs.putAll(((JSONObject) v).nameValuePairs);
    }
    static Object wrap(Object o) {
        if (o == null) return NULL;
        if (o instanceof JSONArray || o instanceof JSONObject || o == NULL) return o;
        if (o instanceof Collection) return new JSONArray((Collection) o);
        if (o instanceof Map) return new JSONObject((Map) o);
        return o;
    }
    public int length() { return nameValuePairs.size(); }
    public JSONObject put(String name, boolean value) throws JSONException { nameValuePairs.put(checkName(name), value); return this; }
    public JSONObject put(String name, double value) throws JSONException { nameValuePairs.put(checkName(name), JSON.checkDouble(value)); return this; }
    public JSONObject put(String name, int value) throws JSONException { nameValuePairs.put(checkName(name), value); return this; }
    public JSONObject put(String name, long value) throws JSONException { nameValuePairs.put(checkName(name), value); return this; }
    public JSONObject put(String name, Object value) throws JSONException {
        if (value == null) { nameValuePairs.remove(name); return this; }
        if (value instanceof Number) JSON.checkDouble(((Number) value).doubleValue());
        nameValuePairs.put(checkName(name), value);
        return this;
    }
    public JSONObject putOpt(String name, Object value) throws JSONException {
        if (name == null || value == null) return this;
        return put(name, value);
    }
    String checkName(String name) throws JSONException { if (name == null) throw new JSONException("Names must be non-null"); return name; }
    public Object remove(String name) { return nameValuePairs.remove(name); }
    public boolean isNull(String name) { Object v = nameValuePairs.get(name); return v == null || v == NULL; }
    public boolean has(String name) { return nameValuePairs.containsKey(name); }
    public Object get(String name) throws JSONException {
        Object result = nameValuePairs.get(name);
        if (result == null) throw new JSONException("No value for " + name);
        return result;
    }
    public Object opt(String name) { return nameValuePairs.get(name); }
    public boolean getBoolean(String name) throws JSONException {
        Object o = get(name); Boolean r = JSON.toBoolean(o);
        if (r == null) throw JSON.typeMismatch(name, o, "boolean"); return r;
    }
    public boolean optBoolean(String name) { return optBoolean(name, false); }
    public boolean optBoolean(String name, boolean fallback) { Boolean r = JSON.toBoolean(opt(name)); return r != null ? r : fallback; }
    public double getDouble(String name) throws JSONException {
        Object o = get(name); Double r = JSON.toDouble(o);
        if (r == null) throw JSON.typeMismatch(name, o, "double"); return r;
    }
    public double optDouble(String name) { return optDouble(name, Double.NaN); }
    public double optDouble(String name, double fallback) { Double r = JSON.toDouble(opt(name)); return r != null ? r : fallback; }
    public int getInt(String name) throws JSONException {
        Object o = get(name); Integer r = JSON.toInteger(o);
        if (r == null) throw JSON.typeMismatch(name, o, "int"); return r;
    }
    public int optInt(String name) { return optInt(name, 0); }
    public int optInt(String name, int fallback) { Integer r = JSON.toInteger(opt(name)); return r != null ? r : fallback; }
    public long getLong(String name) throws JSONException {
        Object o = get(name); Long r = JSON.toLong(o);
        if (r == null) throw JSON.typeMismatch(name, o, "long"); return r;
    }
    public long optLong(String name) { return optLong(name, 0L); }
    public long optLong(String name, long fallback) { Long r = JSON.toLong(opt(name)); return r != null ? r : fallback; }
    public String getString(String name) throws JSONException {
        Object o = get(name); String r = JSON.toString(o);
        if (r == null) throw JSON.typeMismatch(name, o, "String"); return r;
    }
    public String optString(String name) { return optString(name, ""); }
    public String optString(String name, String fallback) { Object o = opt(name); String r = JSON.toString(o); return r != null ? r : fallback; }
    public JSONArray getJSONArray(String name) throws JSONException {
        Object o = get(name); if (o instanceof JSONArray) return (JSONArray) o; throw JSON.typeMismatch(name, o, "JSONArray");
    }
    public JSONArray optJSONArray(String name) { Object o = opt(name); return o instanceof JSONArray ? (JSONArray) o : null; }
    public JSONObject getJSONObject(String name) throws JSONException {
        Object o = get(name); if (o instanceof JSONObject) return (JSONObject) o; throw JSON.typeMismatch(name, o, "JSONObject");
    }
    public JSONObject optJSONObject(String name) { Object o = opt(name); return o instanceof JSONObject ? (JSONObject) o : null; }
    public JSONArray names() { return nameValuePairs.isEmpty() ? null : new JSONArray(new ArrayList<Object>(nameValuePairs.keySet())); }
    public Iterator<String> keys() { return nameValuePairs.keySet().iterator(); }
    public Set<String> keySet() { return nameValuePairs.keySet(); }
    @Override public String toString() {
        try { StringBuilder sb = new StringBuilder(); JSONWriter.write(this, sb); return sb.toString(); }
        catch (JSONException e) { return null; }
    }
    public String toString(int indentSpaces) throws JSONException { return toString(); }
    public static String quote(String data) { return JSONWriter.quote(data); }
    public static String numberToString(Number number) throws JSONException { return JSON.numberToString(number); }
}
