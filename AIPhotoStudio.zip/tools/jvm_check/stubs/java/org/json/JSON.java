package org.json;
/** Bản sao hành vi của org.json trên Android (chuyển kiểu, định dạng số) — chỉ dùng cho kiểm thử JVM. */
final class JSON {
    private JSON() {}
    static double checkDouble(double d) throws JSONException {
        if (Double.isInfinite(d) || Double.isNaN(d)) throw new JSONException("Forbidden numeric value: " + d);
        return d;
    }
    static Boolean toBoolean(Object value) {
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof String) {
            String s = (String) value;
            if ("true".equalsIgnoreCase(s)) return true;
            if ("false".equalsIgnoreCase(s)) return false;
        }
        return null;
    }
    static Double toDouble(Object value) {
        if (value instanceof Double) return (Double) value;
        if (value instanceof Number) return ((Number) value).doubleValue();
        if (value instanceof String) {
            try { return Double.valueOf((String) value); } catch (NumberFormatException ignored) {}
        }
        return null;
    }
    static Integer toInteger(Object value) {
        if (value instanceof Integer) return (Integer) value;
        if (value instanceof Number) return ((Number) value).intValue();
        if (value instanceof String) {
            try { return (int) (long) Double.parseDouble((String) value); } catch (NumberFormatException ignored) {}
        }
        return null;
    }
    static Long toLong(Object value) {
        if (value instanceof Long) return (Long) value;
        if (value instanceof Number) return ((Number) value).longValue();
        if (value instanceof String) {
            try { return (long) Double.parseDouble((String) value); } catch (NumberFormatException ignored) {}
        }
        return null;
    }
    static String toString(Object value) {
        if (value instanceof String) return (String) value;
        if (value != null) return String.valueOf(value);
        return null;
    }
    static JSONException typeMismatch(Object indexOrName, Object actual, String requiredType) throws JSONException {
        if (actual == null) throw new JSONException("Value at " + indexOrName + " is null.");
        throw new JSONException("Value " + actual + " at " + indexOrName + " of type " + actual.getClass().getName()
                + " cannot be converted to " + requiredType);
    }
    static String numberToString(Number number) throws JSONException {
        double doubleValue = number.doubleValue();
        checkDouble(doubleValue);
        if (number.equals(Double.valueOf(-0.0))) return "-0";
        long longValue = number.longValue();
        if (doubleValue == (double) longValue) return Long.toString(longValue);
        return number.toString();
    }
}
