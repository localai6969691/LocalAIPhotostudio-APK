package android.security.keystore;
public class KeyProperties { public static final int PURPOSE_ENCRYPT = 1, PURPOSE_DECRYPT = 2; public static final String KEY_ALGORITHM_AES = "AES", BLOCK_MODE_GCM = "GCM", ENCRYPTION_PADDING_NONE = "NoPadding"; }
