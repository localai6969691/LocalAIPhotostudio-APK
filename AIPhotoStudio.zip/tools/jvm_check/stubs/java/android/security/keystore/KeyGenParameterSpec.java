package android.security.keystore;
public final class KeyGenParameterSpec implements java.security.spec.AlgorithmParameterSpec {
    public static final class Builder {
        public Builder(String keystoreAlias, int purposes) {}
        public Builder setBlockModes(String... modes) { return this; } public Builder setEncryptionPaddings(String... p) { return this; }
        public Builder setKeySize(int keySize) { return this; } public Builder setRandomizedEncryptionRequired(boolean b) { return this; }
        public KeyGenParameterSpec build() { return new KeyGenParameterSpec(); }
    }
}
