package android.os;
public class Build {
    public static final String HARDWARE = "stub", SOC_MODEL = "unknown", MODEL = "stub", MANUFACTURER = "stub", BRAND = "stub", DEVICE = "stub", BOARD = "stub";
    public static final String[] SUPPORTED_ABIS = new String[] { "arm64-v8a" };
    public static class VERSION { public static final int SDK_INT = 34; public static final String RELEASE = "14"; }
    public static class VERSION_CODES { public static final int O = 26, P = 28, Q = 29, R = 30, S = 31, TIRAMISU = 33; }
}
