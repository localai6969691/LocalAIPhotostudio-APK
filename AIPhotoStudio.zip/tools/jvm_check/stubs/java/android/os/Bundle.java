package android.os;
public final class Bundle { public Bundle() {} public Object get(String key) { return null; } }
