package android.os;
// Chữ ký chép từ tài liệu android.os.Debug (R32)
public final class Debug {
    private Debug() {}
    public static class MemoryInfo { public MemoryInfo() {} public int getTotalPss() { return 0; } }
    public static void getMemoryInfo(MemoryInfo outInfo) {}
}
