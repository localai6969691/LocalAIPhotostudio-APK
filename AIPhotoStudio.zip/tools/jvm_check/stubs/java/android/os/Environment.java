package android.os;
public class Environment { public static final String DIRECTORY_PICTURES = "Pictures", DIRECTORY_DOWNLOADS = "Download", DIRECTORY_DCIM = "DCIM";
  public static java.io.File getExternalStoragePublicDirectory(String type) { throw new RuntimeException("stub"); } }
