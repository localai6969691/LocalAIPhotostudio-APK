package android.database;
public interface Cursor extends java.io.Closeable { boolean moveToFirst(); boolean moveToNext(); int getColumnIndex(String name); int getColumnIndexOrThrow(String name); String getString(int i); int getInt(int i); long getLong(int i); boolean isNull(int i); int getCount(); void close(); }
