package android.content;
import android.net.Uri;
/** Stub (R42): phần của android.content.ClipData mà kéo-thả ảnh dùng. */
public class ClipData {
    public int getItemCount() { return 0; }
    public Item getItemAt(int index) { return null; }
    public static class Item { public Uri getUri() { return null; } }
}
