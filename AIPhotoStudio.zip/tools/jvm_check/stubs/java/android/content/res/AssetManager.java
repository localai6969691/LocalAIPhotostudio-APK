package android.content.res;
import java.io.*;
public final class AssetManager { public final InputStream open(String fileName) throws IOException { throw new RuntimeException("stub"); } public String[] list(String path) throws IOException { return new String[0]; } }
