package android.content.res;
/** R39: stub tối thiểu của android.content.res.Configuration (chỉ phần EditorScreen dùng để chọn bố cục rộng). */
public final class Configuration {
    public static final int ORIENTATION_UNDEFINED = 0, ORIENTATION_PORTRAIT = 1, ORIENTATION_LANDSCAPE = 2;
    public int screenWidthDp = 360, screenHeightDp = 800, smallestScreenWidthDp = 360, orientation = ORIENTATION_PORTRAIT;
}
