package android.content;
/** Stub (R42): phần của android.content.ClipDescription mà kéo-thả ảnh dùng. */
public class ClipDescription {
    public int getMimeTypeCount() { return 0; }
    public String getMimeType(int index) { return null; }
}
