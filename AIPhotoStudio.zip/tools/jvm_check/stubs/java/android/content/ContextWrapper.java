package android.content;
import android.content.res.AssetManager; import android.content.pm.ApplicationInfo; import java.io.File;
public class ContextWrapper extends Context {
    public File getFilesDir() { throw new RuntimeException("stub"); } public File getCacheDir() { throw new RuntimeException("stub"); } public File getExternalFilesDir(String t) { return null; }
    public SharedPreferences getSharedPreferences(String n, int m) { throw new RuntimeException("stub"); }
    public ContentResolver getContentResolver() { throw new RuntimeException("stub"); } public AssetManager getAssets() { throw new RuntimeException("stub"); }
    public Object getSystemService(String n) { return null; } public Context getApplicationContext() { return this; }
    public ApplicationInfo getApplicationInfo() { throw new RuntimeException("stub"); } public String getPackageName() { return "stub"; }
    public String getString(int r) { return ""; } public void startActivity(Intent i) {}
}
