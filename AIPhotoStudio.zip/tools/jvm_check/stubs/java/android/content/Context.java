package android.content;
import android.content.res.AssetManager; import android.content.pm.ApplicationInfo; import android.content.pm.PackageManager; import java.io.File;
public abstract class Context {
    public static final int MODE_PRIVATE = 0; public static final String ACTIVITY_SERVICE = "activity"; public static final String DISPLAY_SERVICE = "display"; public static final String CONNECTIVITY_SERVICE = "connectivity"; public static final String NOTIFICATION_SERVICE = "notification";
    public abstract File getFilesDir(); public abstract File getCacheDir(); public abstract File getExternalFilesDir(String type);
    public abstract SharedPreferences getSharedPreferences(String name, int mode);
    public abstract ContentResolver getContentResolver(); public abstract AssetManager getAssets();
    public abstract Object getSystemService(String name); public <T> T getSystemService(Class<T> c) { return null; }
    public abstract Context getApplicationContext(); public abstract ApplicationInfo getApplicationInfo(); public abstract String getPackageName();
    public PackageManager getPackageManager() { return null; }
    public ComponentName startService(Intent service) { return null; } public ComponentName startForegroundService(Intent service) { return null; } public boolean stopService(Intent name) { return false; }
    public int checkSelfPermission(String permission) { return 0; }
    public abstract String getString(int resId); public abstract void startActivity(Intent intent);
}
