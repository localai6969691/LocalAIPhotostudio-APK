package android.content;
import android.net.Uri; import android.os.Parcelable;
public class Intent {
    public static final String ACTION_SEND = "android.intent.action.SEND", ACTION_VIEW = "android.intent.action.VIEW", EXTRA_STREAM = "android.intent.extra.STREAM", EXTRA_TEXT = "android.intent.extra.TEXT", EXTRA_SUBJECT = "android.intent.extra.SUBJECT";
    public static final int FLAG_GRANT_READ_URI_PERMISSION = 1, FLAG_ACTIVITY_NEW_TASK = 0x10000000;
    public Intent() {} public Intent(String action) {}
    public Intent setType(String type) { return this; } public String getType() { return null; } public String getAction() { return null; } public Intent putExtra(String name, Parcelable value) { return this; } public Intent putExtra(String name, String value) { return this; }
    public Intent addFlags(int flags) { return this; } public Intent setFlags(int flags) { return this; } public Intent setAction(String a) { return this; }
    public static Intent createChooser(Intent target, CharSequence title) { return new Intent(); }
}
