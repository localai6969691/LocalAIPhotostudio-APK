package android.content;
import android.net.Uri; import android.database.Cursor; import java.io.*;
public abstract class ContentResolver {
    public final InputStream openInputStream(Uri uri) throws FileNotFoundException { throw new RuntimeException("stub"); }
    public final OutputStream openOutputStream(Uri uri) throws FileNotFoundException { throw new RuntimeException("stub"); }
    public final OutputStream openOutputStream(Uri uri, String mode) throws FileNotFoundException { throw new RuntimeException("stub"); }
    public final Uri insert(Uri url, ContentValues values) { throw new RuntimeException("stub"); }
    public final int update(Uri uri, ContentValues values, String where, String[] selectionArgs) { throw new RuntimeException("stub"); }
    public final int delete(Uri url, String where, String[] selectionArgs) { throw new RuntimeException("stub"); }
    public final Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { throw new RuntimeException("stub"); }
    public String getType(Uri uri) { return null; }
    public void takePersistableUriPermission(Uri uri, int modeFlags) {}
}
