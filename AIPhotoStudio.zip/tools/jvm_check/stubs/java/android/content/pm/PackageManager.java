package android.content.pm;
public abstract class PackageManager {
    public static final int GET_META_DATA = 128;
    public ApplicationInfo getApplicationInfo(String packageName, int flags) throws NameNotFoundException { return new ApplicationInfo(); }
    public PackageInfo getPackageInfo(String packageName, int flags) throws NameNotFoundException { return new PackageInfo(); }
    public android.content.Intent getLaunchIntentForPackage(String packageName) { return null; }
    public static final int PERMISSION_GRANTED = 0;
    public static class NameNotFoundException extends Exception { public NameNotFoundException() {} }
}
