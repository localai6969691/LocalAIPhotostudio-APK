package android.content.pm;
public abstract class PackageManager {
    public static final int GET_META_DATA = 128;
    public ApplicationInfo getApplicationInfo(String packageName, int flags) throws NameNotFoundException { return new ApplicationInfo(); }
    public PackageInfo getPackageInfo(String packageName, int flags) throws NameNotFoundException { return new PackageInfo(); }
    public static class NameNotFoundException extends Exception { public NameNotFoundException() {} }
}
