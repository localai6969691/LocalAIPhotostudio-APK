package android.content.pm;
public abstract class PackageManager {
    public PackageInfo getPackageInfo(String packageName, int flags) throws NameNotFoundException { return new PackageInfo(); }
    public static class NameNotFoundException extends Exception { public NameNotFoundException() {} }
}
