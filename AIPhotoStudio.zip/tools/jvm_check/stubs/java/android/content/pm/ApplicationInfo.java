package android.content.pm;
public class ApplicationInfo { public String nativeLibraryDir; public String sourceDir; public int flags; }
