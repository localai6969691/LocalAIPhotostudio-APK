package android.content.pm;
public class PackageInfo {
    public String versionName = "stub"; public int versionCode = 1;
    public long getLongVersionCode() { return (long) versionCode; }
}
