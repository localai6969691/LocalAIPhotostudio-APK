package android.media;
import java.io.*;
public class ExifInterface {
    public static final String TAG_ORIENTATION = "Orientation";
    public static final int ORIENTATION_UNDEFINED = 0, ORIENTATION_NORMAL = 1, ORIENTATION_FLIP_HORIZONTAL = 2, ORIENTATION_ROTATE_180 = 3, ORIENTATION_FLIP_VERTICAL = 4,
        ORIENTATION_TRANSPOSE = 5, ORIENTATION_ROTATE_90 = 6, ORIENTATION_TRANSVERSE = 7, ORIENTATION_ROTATE_270 = 8;
    public ExifInterface(String filename) throws IOException {} public ExifInterface(InputStream is) throws IOException {}
    public int getAttributeInt(String tag, int defaultValue) { return defaultValue; } public String getAttribute(String tag) { return null; }
}
