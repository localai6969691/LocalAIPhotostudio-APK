package android;
/** Stub: các tài nguyên khung android.R.drawable dùng cho thông báo tải (R44). */
public final class R {
    public static final class drawable {
        public static final int stat_sys_download = 0x0108008a, stat_sys_download_done = 0x0108008b, ic_menu_close_clear_cancel = 0x01080038;
    }
}
