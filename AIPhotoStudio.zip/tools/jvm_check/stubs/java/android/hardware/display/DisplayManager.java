package android.hardware.display;
import android.view.Display;
public final class DisplayManager { public Display getDisplay(int displayId) { return new Display(); } }
