package android.util;
public class Base64 {
    public static final int DEFAULT = 0, NO_PADDING = 1, NO_WRAP = 2, CRLF = 4, URL_SAFE = 8;
    public static String encodeToString(byte[] input, int flags) {
        String s = java.util.Base64.getEncoder().encodeToString(input);
        if ((flags & NO_PADDING) != 0) s = s.replace("=", "");
        if ((flags & NO_WRAP) == 0) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < s.length(); i += 76) { sb.append(s, i, Math.min(s.length(), i + 76)).append('\n'); } return sb.toString(); }
        return s;
    }
    public static byte[] decode(String str, int flags) { return java.util.Base64.getMimeDecoder().decode(str); }
    public static byte[] decode(byte[] input, int flags) { return java.util.Base64.getMimeDecoder().decode(input); }
    public static byte[] encode(byte[] input, int flags) { return encodeToString(input, flags).getBytes(); }
}
