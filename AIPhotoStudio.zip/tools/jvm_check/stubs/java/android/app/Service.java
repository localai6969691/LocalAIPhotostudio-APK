package android.app;
import android.content.Context; import android.content.ContextWrapper; import android.content.Intent; import android.os.IBinder;
/** Stub: chữ ký chép từ tài liệu android.app.Service (R44). */
public abstract class Service extends ContextWrapper {
    public static final int START_NOT_STICKY = 2, START_STICKY = 1, START_REDELIVER_INTENT = 3, STOP_FOREGROUND_REMOVE = 1, STOP_FOREGROUND_DETACH = 2;
    public Service() {}
    public void onCreate() {}
    public abstract IBinder onBind(Intent intent);
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    public void onDestroy() {}
    public final void startForeground(int id, Notification notification) {}
    public final void startForeground(int id, Notification notification, int foregroundServiceType) {}
    public final void stopForeground(int flags) {}
    public final void stopSelf() {}
}
