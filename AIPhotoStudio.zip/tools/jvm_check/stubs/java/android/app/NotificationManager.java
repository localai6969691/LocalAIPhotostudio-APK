package android.app;
public class NotificationManager {
    public static final int IMPORTANCE_LOW = 2, IMPORTANCE_DEFAULT = 3;
    public void createNotificationChannel(NotificationChannel channel) {}
    public void notify(int id, Notification notification) {}
    public void cancel(int id) {}
    public boolean areNotificationsEnabled() { return true; }
}
