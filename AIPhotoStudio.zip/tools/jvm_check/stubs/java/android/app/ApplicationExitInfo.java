package android.app;
public final class ApplicationExitInfo {
    public static final int REASON_UNKNOWN = 0, REASON_EXIT_SELF = 1, REASON_SIGNALED = 2, REASON_LOW_MEMORY = 3, REASON_CRASH = 4, REASON_CRASH_NATIVE = 5, REASON_ANR = 6;
    public int getReason() { return 0; } public int getImportance() { return 0; } public long getTimestamp() { return 0L; }
    public long getPss() { return 0L; } public long getRss() { return 0L; } public String getDescription() { return null; } public int getStatus() { return 0; }
}
