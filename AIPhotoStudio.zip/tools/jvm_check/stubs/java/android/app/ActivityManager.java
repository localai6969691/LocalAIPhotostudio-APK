package android.app;
public class ActivityManager {
    public static class MemoryInfo { public long availMem; public long totalMem; public long threshold; public boolean lowMemory; public MemoryInfo() {} }
    public void getMemoryInfo(MemoryInfo outInfo) {}
    public int getMemoryClass() { return 0; } public int getLargeMemoryClass() { return 0; }
    public boolean isLowRamDevice() { return false; }
    public java.util.List<ApplicationExitInfo> getHistoricalProcessExitReasons(String packageName, int pid, int maxNum) { return new java.util.ArrayList<ApplicationExitInfo>(); }
}
