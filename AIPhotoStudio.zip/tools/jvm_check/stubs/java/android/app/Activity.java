package android.app;
public class Activity extends android.content.ContextWrapper {
    public static final int RESULT_CANCELED = 0, RESULT_OK = -1;
    public Activity() {}
    protected void onStart() {}
    protected void onStop() {}
    public android.view.DragAndDropPermissions requestDragAndDropPermissions(android.view.DragEvent event) { return null; }
}
