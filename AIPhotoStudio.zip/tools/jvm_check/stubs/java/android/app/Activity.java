package android.app;
public class Activity extends android.content.ContextWrapper { public Activity() {} }
