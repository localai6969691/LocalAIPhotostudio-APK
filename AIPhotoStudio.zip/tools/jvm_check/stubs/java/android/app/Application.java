package android.app;
public class Application extends android.content.ContextWrapper { public Application() {} public void onCreate() {} }
