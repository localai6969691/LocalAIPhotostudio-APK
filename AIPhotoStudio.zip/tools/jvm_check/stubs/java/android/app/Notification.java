package android.app;
import android.content.Context;
/** Stub: chữ ký chép từ tài liệu android.app.Notification / Notification.Builder (R44). */
public class Notification {
    public static class Builder {
        public Builder(Context context, String channelId) {}
        public Builder setContentTitle(CharSequence title) { return this; }
        public Builder setContentText(CharSequence text) { return this; }
        public Builder setSmallIcon(int icon) { return this; }
        public Builder setOngoing(boolean ongoing) { return this; }
        public Builder setOnlyAlertOnce(boolean onlyAlertOnce) { return this; }
        public Builder setAutoCancel(boolean autoCancel) { return this; }
        public Builder setProgress(int max, int progress, boolean indeterminate) { return this; }
        public Builder setContentIntent(PendingIntent intent) { return this; }
        public Builder addAction(int icon, CharSequence title, PendingIntent intent) { return this; }
        public Notification build() { return new Notification(); }
    }
}
