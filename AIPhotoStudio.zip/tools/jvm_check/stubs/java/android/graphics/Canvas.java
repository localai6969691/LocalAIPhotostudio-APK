package android.graphics;
public class Canvas {
    private Bitmap target;
    public Canvas() {} public Canvas(Bitmap bitmap) { target = bitmap; }
    public int getWidth() { return target == null ? 0 : target.getWidth(); } public int getHeight() { return target == null ? 0 : target.getHeight(); }
    public void setBitmap(Bitmap b) { target = b; }
    /** Chạy thật: chép [bitmap] vào đích tại (left, top) theo "src-over", qua ColorMatrixColorFilter của [paint] nếu có. Dịch số nguyên. */
    public void drawBitmap(Bitmap bitmap, float left, float top, Paint paint) {
        if (target == null) throw new IllegalStateException("Canvas has no bitmap");
        int ox = Math.round(left), oy = Math.round(top);
        ColorFilter f = paint == null ? null : paint.getColorFilter();
        if (f != null && !(f instanceof ColorMatrixColorFilter)) throw new RuntimeException("stub: only ColorMatrixColorFilter supported");
        for (int y = 0; y < bitmap.getHeight(); y++) {
            int ty = y + oy; if (ty < 0 || ty >= target.getHeight()) continue;
            for (int x = 0; x < bitmap.getWidth(); x++) {
                int tx = x + ox; if (tx < 0 || tx >= target.getWidth()) continue;
                int s = bitmap.getPixel(x, y);
                if (f != null) s = ((ColorMatrixColorFilter) f).apply(s);
                target.setPixel(tx, ty, over(s, target.getPixel(tx, ty)));
            }
        }
    }
    private static int over(int s, int d) {
        int sa = s >>> 24;
        if (sa == 255 || (d >>> 24) == 0) return s;
        if (sa == 0) return d;
        int da = d >>> 24;
        float fs = sa / 255f, fd = da / 255f * (1 - fs), oa = fs + fd;
        int r = Math.round((((s >> 16) & 255) * fs + ((d >> 16) & 255) * fd) / oa);
        int g = Math.round((((s >> 8) & 255) * fs + ((d >> 8) & 255) * fd) / oa);
        int b = Math.round(((s & 255) * fs + (d & 255) * fd) / oa);
        return (Math.round(oa * 255) << 24) | (r << 16) | (g << 8) | b;
    }
    public void drawBitmap(Bitmap bitmap, Rect src, Rect dst, Paint paint) {}
    public void drawBitmap(Bitmap bitmap, Rect src, RectF dst, Paint paint) {}
    public void drawBitmap(Bitmap bitmap, Matrix matrix, Paint paint) { throw new RuntimeException("stub: drawBitmap with Matrix not supported"); }
    public void drawBitmap(int[] colors, int offset, int stride, float x, float y, int width, int height, boolean hasAlpha, Paint paint) {}
    public void drawText(String text, float x, float y, Paint paint) {}
    public void drawRect(float l, float t, float r, float b, Paint p) {} public void drawRect(RectF r, Paint p) {} public void drawRect(Rect r, Paint p) {}
    public void drawOval(RectF oval, Paint p) {} public void drawOval(float l, float t, float r, float b, Paint p) {} public void drawRoundRect(RectF r, float rx, float ry, Paint p) {}
    public void drawCircle(float cx, float cy, float radius, Paint p) {}
    public void drawLine(float sx, float sy, float ex, float ey, Paint p) {}
    public void drawPath(Path path, Paint p) {}
    public void drawColor(int color) {} public void drawColor(int color, PorterDuff.Mode mode) {}
    public void drawARGB(int a, int r, int g, int b) {}
    public int save() { return 0; } public void restore() {}
    public void translate(float dx, float dy) {} public void scale(float sx, float sy) {} public void scale(float sx, float sy, float px, float py) {}
    public void rotate(float degrees) {} public void rotate(float degrees, float px, float py) {}
    public void concat(Matrix m) {} public void setMatrix(Matrix m) {}
    public boolean clipRect(float l, float t, float r, float b) { return true; } public boolean clipRect(RectF r) { return true; } public boolean clipRect(Rect r) { return true; }
}
