package android.graphics;
public class Paint {
    public static final int ANTI_ALIAS_FLAG = 1, FILTER_BITMAP_FLAG = 2, DITHER_FLAG = 4;
    public enum Style { FILL, STROKE, FILL_AND_STROKE }
    public enum Align { LEFT, CENTER, RIGHT }
    public enum Join { MITER, ROUND, BEVEL }
    public enum Cap { BUTT, ROUND, SQUARE }
    public static class FontMetrics { public float top, ascent, descent, bottom, leading; }
    private ColorFilter filter;
    public Paint() {} public Paint(int flags) {} public Paint(Paint src) { filter = src.filter; }
    public void setColor(int color) {} public int getColor() { return 0; }
    public void setAlpha(int a) {} public int getAlpha() { return 255; }
    public Xfermode setXfermode(Xfermode x) { return x; } public Xfermode getXfermode() { return null; }
    public ColorFilter setColorFilter(ColorFilter f) { filter = f; return f; } public ColorFilter getColorFilter() { return filter; }
    public void setFilterBitmap(boolean b) {} public boolean isFilterBitmap() { return false; } public void setAntiAlias(boolean b) {} public boolean isAntiAlias() { return false; } public void setDither(boolean b) {} public boolean isDither() { return false; }
    public void setStyle(Style s) {} public Style getStyle() { return Style.FILL; } public void setStrokeWidth(float w) {} public float getStrokeWidth() { return 0; } public void setStrokeJoin(Join j) {} public Join getStrokeJoin() { return Join.MITER; } public void setStrokeCap(Cap c) {} public Cap getStrokeCap() { return Cap.BUTT; }
    public void setTextSize(float s) {} public float getTextSize() { return 0; }
    public Typeface setTypeface(Typeface t) { return t; } public Typeface getTypeface() { return null; }
    public void setTextAlign(Align a) {} public Align getTextAlign() { return Align.LEFT; } public void setFakeBoldText(boolean b) {}
    public float measureText(String text) { return 0; } public float measureText(String text, int start, int end) { return 0; }
    public float getFontSpacing() { return 0; }
    public float ascent() { return 0; } public float descent() { return 0; }
    public float getFontMetrics(FontMetrics fm) { return 0; } public FontMetrics getFontMetrics() { return new FontMetrics(); }
    public void getTextBounds(String text, int start, int end, Rect bounds) {}
    public void setShadowLayer(float radius, float dx, float dy, int shadowColor) {}
    public void clearShadowLayer() {}
}
