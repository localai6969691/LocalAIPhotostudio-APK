package android.graphics;
public class ColorMatrixColorFilter extends ColorFilter {
    final float[] m = new float[20];
    public ColorMatrixColorFilter(ColorMatrix matrix) { System.arraycopy(matrix.getArray(), 0, m, 0, 20); }
    public ColorMatrixColorFilter(float[] array) { System.arraycopy(array, 0, m, 0, 20); }
    /** Áp ma trận lên một điểm ARGB không premultiply (giá trị 0..255, kẹp kết quả). */
    int apply(int p) {
        float A = (p >>> 24) & 255, R = (p >> 16) & 255, G = (p >> 8) & 255, B = p & 255;
        int a = clamp(m[15] * R + m[16] * G + m[17] * B + m[18] * A + m[19]);
        int r = clamp(m[0] * R + m[1] * G + m[2] * B + m[3] * A + m[4]);
        int g = clamp(m[5] * R + m[6] * G + m[7] * B + m[8] * A + m[9]);
        int b = clamp(m[10] * R + m[11] * G + m[12] * B + m[13] * A + m[14]);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    private static int clamp(float v) { int i = Math.round(v); return i < 0 ? 0 : Math.min(i, 255); }
}
