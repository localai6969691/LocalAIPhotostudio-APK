package android.graphics;
public class Typeface {
    public static final Typeface DEFAULT = new Typeface(), DEFAULT_BOLD = new Typeface(), SANS_SERIF = new Typeface(), SERIF = new Typeface(), MONOSPACE = new Typeface();
    public static final int NORMAL = 0, BOLD = 1, ITALIC = 2, BOLD_ITALIC = 3;
    public static Typeface create(Typeface family, int style) { return new Typeface(); }
    public static Typeface create(String familyName, int style) { return new Typeface(); }
}
