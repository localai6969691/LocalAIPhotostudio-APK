package android.graphics;
public class Matrix {
    public Matrix() {} public Matrix(Matrix src) {}
    public void reset() {} public void set(Matrix src) {}
    public void setTranslate(float dx, float dy) {} public void setScale(float sx, float sy) {} public void setScale(float sx, float sy, float px, float py) {}
    public void setRotate(float degrees) {} public void setRotate(float degrees, float px, float py) {}
    public boolean preTranslate(float dx, float dy) { return true; } public boolean preScale(float sx, float sy) { return true; } public boolean preScale(float sx, float sy, float px, float py) { return true; }
    public boolean preRotate(float d) { return true; } public boolean preRotate(float d, float px, float py) { return true; }
    public boolean postTranslate(float dx, float dy) { return true; } public boolean postScale(float sx, float sy) { return true; } public boolean postScale(float sx, float sy, float px, float py) { return true; }
    public boolean postRotate(float d) { return true; } public boolean postRotate(float d, float px, float py) { return true; }
    public boolean postConcat(Matrix other) { return true; } public boolean preConcat(Matrix other) { return true; }
    public boolean invert(Matrix inverse) { return true; }
    public void mapPoints(float[] pts) {} public void mapPoints(float[] dst, float[] src) {}
    public boolean mapRect(RectF rect) { return true; } public boolean mapRect(RectF dst, RectF src) { return true; }
    public float mapRadius(float radius) { return radius; }
    public void getValues(float[] values) {} public void setValues(float[] values) {}
    public boolean isIdentity() { return true; }
    public boolean setPolyToPoly(float[] src, int srcIndex, float[] dst, int dstIndex, int pointCount) { return true; }
}
