package android.graphics;
import java.io.OutputStream;
import java.nio.Buffer;

/**
 * Stub CÓ HÀNH VI (lưu điểm ảnh ARGB trong mảng int, không premultiply, không đồ họa): đủ để chạy thật các đường xử lý thuần điểm ảnh
 * của ImageEngine / Layers / Compositor trên JVM. KHÔNG phải Bitmap của Android: không có mã hóa ảnh, Canvas, Matrix, nội suy khi co giãn (lấy điểm gần nhất).
 */
public final class Bitmap {
    public enum Config { ALPHA_8, RGB_565, ARGB_4444, ARGB_8888, RGBA_F16, HARDWARE }
    public enum CompressFormat { JPEG, PNG, WEBP, WEBP_LOSSY, WEBP_LOSSLESS }

    private final int w, h;
    private final int[] px;
    private final Config config;
    private boolean alpha = true, recycled = false;

    private Bitmap(int w, int h, int[] px, Config c) {
        if (w <= 0 || h <= 0) throw new IllegalArgumentException("width and height must be > 0");
        this.w = w; this.h = h; this.px = px; this.config = c;
    }
    public int getWidth() { return w; }
    public int getHeight() { return h; }
    public Config getConfig() { return config; }
    public boolean hasAlpha() { return alpha; }
    public void setHasAlpha(boolean b) { alpha = b; }
    public boolean isMutable() { return true; }
    public boolean isRecycled() { return recycled; }
    public void recycle() { recycled = true; }
    public int getByteCount() { return w * h * 4; }
    public int getRowBytes() { return w * 4; }
    public int getPixel(int x, int y) { check(x, y); return px[y * w + x]; }
    public void setPixel(int x, int y, int color) { check(x, y); px[y * w + x] = color; }
    private void check(int x, int y) { if (x < 0 || y < 0 || x >= w || y >= h) throw new IllegalArgumentException("x/y must be within the bitmap's dimensions"); }
    public void getPixels(int[] pixels, int offset, int stride, int x, int y, int width, int height) {
        if (x < 0 || y < 0 || x + width > w || y + height > h) throw new IllegalArgumentException("rectangle is outside the bitmap");
        for (int r = 0; r < height; r++) System.arraycopy(px, (y + r) * w + x, pixels, offset + r * stride, width);
    }
    public void setPixels(int[] pixels, int offset, int stride, int x, int y, int width, int height) {
        if (x < 0 || y < 0 || x + width > w || y + height > h) throw new IllegalArgumentException("rectangle is outside the bitmap");
        for (int r = 0; r < height; r++) System.arraycopy(pixels, offset + r * stride, px, (y + r) * w + x, width);
    }
    public void eraseColor(int c) { java.util.Arrays.fill(px, c); }
    public Bitmap copy(Config config, boolean isMutable) { return new Bitmap(w, h, px.clone(), config); }
    public boolean compress(CompressFormat format, int quality, OutputStream stream) { throw new RuntimeException("stub: no image encoder"); }
    public void copyPixelsToBuffer(Buffer dst) {}
    public void copyPixelsFromBuffer(Buffer src) {}
    public void setPremultiplied(boolean b) {}
    public boolean isPremultiplied() { return true; }
    public Bitmap extractAlpha() {
        int[] a = new int[w * h];
        for (int i = 0; i < a.length; i++) a[i] = px[i] >>> 24;
        return new Bitmap(w, h, a, Config.ALPHA_8);
    }
    public int getDensity() { return 0; }
    public static Bitmap createBitmap(int width, int height, Config config) { return new Bitmap(width, height, new int[width * height], config); }
    public static Bitmap createBitmap(Bitmap source) { return source.copy(source.config, true); }
    public static Bitmap createBitmap(Bitmap source, int x, int y, int width, int height) {
        int[] out = new int[width * height];
        source.getPixels(out, 0, width, x, y, width, height);
        return new Bitmap(width, height, out, source.config);
    }
    public static Bitmap createBitmap(Bitmap source, int x, int y, int width, int height, Matrix m, boolean filter) {
        if (m != null) throw new RuntimeException("stub: Matrix transforms not supported");
        return createBitmap(source, x, y, width, height);
    }
    public static Bitmap createBitmap(int[] colors, int width, int height, Config config) { return createBitmap(colors, 0, width, width, height, config); }
    public static Bitmap createBitmap(int[] colors, int offset, int stride, int width, int height, Config config) {
        int[] out = new int[width * height];
        for (int r = 0; r < height; r++) System.arraycopy(colors, offset + r * stride, out, r * width, width);
        return new Bitmap(width, height, out, config);
    }
    public static Bitmap createScaledBitmap(Bitmap src, int dstWidth, int dstHeight, boolean filter) {
        int[] out = new int[dstWidth * dstHeight];
        for (int y = 0; y < dstHeight; y++) {
            int sy = Math.min(src.h - 1, (int) ((y + 0.5) * src.h / dstHeight));
            for (int x = 0; x < dstWidth; x++) out[y * dstWidth + x] = src.px[sy * src.w + Math.min(src.w - 1, (int) ((x + 0.5) * src.w / dstWidth))];
        }
        return new Bitmap(dstWidth, dstHeight, out, src.config);
    }
}
