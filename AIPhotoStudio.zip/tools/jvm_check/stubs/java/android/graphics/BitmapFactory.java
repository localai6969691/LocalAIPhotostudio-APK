package android.graphics;
import java.io.InputStream;
public class BitmapFactory {
    public static class Options {
        public boolean inJustDecodeBounds; public int inSampleSize; public int outWidth; public int outHeight;
        public Bitmap.Config inPreferredConfig; public boolean inMutable; public String outMimeType; public int inDensity; public int inTargetDensity; public boolean inScaled;
    }
    public static Bitmap decodeFile(String pathName) { throw new RuntimeException("stub"); }
    public static Bitmap decodeFile(String pathName, Options opts) { throw new RuntimeException("stub"); }
    public static Bitmap decodeStream(InputStream is) { throw new RuntimeException("stub"); }
    public static Bitmap decodeStream(InputStream is, Rect outPadding, Options opts) { throw new RuntimeException("stub"); }
    public static Bitmap decodeByteArray(byte[] data, int offset, int length) { throw new RuntimeException("stub"); }
    public static Bitmap decodeByteArray(byte[] data, int offset, int length, Options opts) { throw new RuntimeException("stub"); }
}
