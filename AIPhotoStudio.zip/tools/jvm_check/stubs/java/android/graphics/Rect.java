package android.graphics;
public class Rect {
    public int left, top, right, bottom;
    public Rect() {}
    public Rect(int left, int top, int right, int bottom) { this.left = left; this.top = top; this.right = right; this.bottom = bottom; }
    public final int width() { return right - left; }
    public final int height() { return bottom - top; }
    public final int centerX() { return (left + right) >> 1; }
    public final int centerY() { return (top + bottom) >> 1; }
    public final boolean isEmpty() { return left >= right || top >= bottom; }
    public void set(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; }
    public boolean contains(int x, int y) { return left < right && top < bottom && x >= left && x < right && y >= top && y < bottom; }
    public void inset(int dx, int dy) { left += dx; top += dy; right -= dx; bottom -= dy; }
    public void offset(int dx, int dy) { left += dx; top += dy; right += dx; bottom += dy; }
    public boolean intersect(int l, int t, int r, int b) { throw new RuntimeException("stub"); }
    public void union(int l, int t, int r, int b) { throw new RuntimeException("stub"); }
}
