package android.graphics;
public class Path {
    public Path() {}
    public void moveTo(float x, float y) {} public void lineTo(float x, float y) {} public void close() {} public void reset() {}
    public void quadTo(float x1, float y1, float x2, float y2) {} public void rewind() {}
    public enum FillType { WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD }
    public void setFillType(FillType ft) {}
}
