package android.graphics;
/** Stub CÓ HÀNH VI theo tài liệu Android: ma trận 4×5 hàng-chính [R' = a0·R + a1·G + a2·B + a3·A + a4 ...], giá trị 0..255. */
public class ColorMatrix {
    private final float[] a = new float[20];
    public ColorMatrix() { reset(); }
    public ColorMatrix(float[] src) { set(src); }
    public ColorMatrix(ColorMatrix src) { System.arraycopy(src.a, 0, a, 0, 20); }
    public float[] getArray() { return a; }
    public void reset() { java.util.Arrays.fill(a, 0f); a[0] = a[6] = a[12] = a[18] = 1f; }
    public void set(ColorMatrix src) { System.arraycopy(src.a, 0, a, 0, 20); }
    public void set(float[] src) { if (src.length < 20) throw new ArrayIndexOutOfBoundsException(); System.arraycopy(src, 0, a, 0, 20); }
    public void setScale(float rScale, float gScale, float bScale, float aScale) {
        java.util.Arrays.fill(a, 0f); a[0] = rScale; a[6] = gScale; a[12] = bScale; a[18] = aScale;
    }
    public void setSaturation(float sat) {
        reset();
        float inv = 1 - sat, r = 0.213f * inv, g = 0.715f * inv, b = 0.072f * inv;
        a[0] = r + sat; a[1] = g; a[2] = b;
        a[5] = r; a[6] = g + sat; a[7] = b;
        a[10] = r; a[11] = g; a[12] = b + sat;
    }
    public void setRotate(int axis, float degrees) { throw new RuntimeException("stub: setRotate not supported"); }
    public void setConcat(ColorMatrix matA, ColorMatrix matB) {
        float[] r = new float[20], x = matA.a, y = matB.a;
        for (int i = 0; i < 4; i++) for (int j = 0; j < 5; j++) {
            float s = 0f;
            for (int k = 0; k < 4; k++) s += x[i * 5 + k] * y[k * 5 + j];
            if (j == 4) s += x[i * 5 + 4];
            r[i * 5 + j] = s;
        }
        System.arraycopy(r, 0, a, 0, 20);
    }
    public void preConcat(ColorMatrix prematrix) { setConcat(this, prematrix); }
    public void postConcat(ColorMatrix postmatrix) { setConcat(postmatrix, this); }
}
