package android.provider;
import android.net.Uri;
public final class MediaStore {
    public interface MediaColumns { String DISPLAY_NAME = "_display_name"; String MIME_TYPE = "mime_type"; String RELATIVE_PATH = "relative_path"; String IS_PENDING = "is_pending"; String DATA = "_data"; }
    public static final class Images { public static final class Media implements MediaColumns { public static final Uri EXTERNAL_CONTENT_URI = null; } }
}
