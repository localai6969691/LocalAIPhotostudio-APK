package android.net;
import android.os.Parcelable;
public abstract class Uri implements Parcelable {
    public static Uri parse(String uriString) { throw new RuntimeException("stub"); }
    public static Uri fromFile(java.io.File file) { throw new RuntimeException("stub"); }
    public abstract String getLastPathSegment(); public abstract String getPath(); public abstract String getScheme(); public abstract String toString();
}
