package android.net;
public final class NetworkCapabilities {
    public static final int NET_CAPABILITY_NOT_METERED = 11, NET_CAPABILITY_INTERNET = 12;
    public boolean hasCapability(int capability) { return true; }
}
