package android.net;
public class ConnectivityManager {
    public static class NetworkCallback {
        public NetworkCallback() {}
        public void onAvailable(Network network) {}
        public void onLost(Network network) {}
        public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {}
    }
    public Network getActiveNetwork() { return null; }
    public NetworkCapabilities getNetworkCapabilities(Network network) { return null; }
    public boolean isActiveNetworkMetered() { return false; }
    public void registerDefaultNetworkCallback(NetworkCallback networkCallback) {}
    public void unregisterNetworkCallback(NetworkCallback networkCallback) {}
}
