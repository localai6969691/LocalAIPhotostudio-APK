package android.view;
public final class Display { public static final int DEFAULT_DISPLAY = 0; public float getRefreshRate() { return 60f; } }
