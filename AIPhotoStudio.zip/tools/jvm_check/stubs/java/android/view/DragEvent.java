package android.view;
import android.content.ClipData;
import android.content.ClipDescription;
/** Stub (R42): hằng số và getter theo android.view.DragEvent (API 11). */
public class DragEvent {
    public static final int ACTION_DRAG_STARTED = 1, ACTION_DRAG_LOCATION = 2, ACTION_DROP = 3, ACTION_DRAG_ENDED = 4, ACTION_DRAG_ENTERED = 5, ACTION_DRAG_EXITED = 6;
    public int getAction() { return 0; }
    public ClipData getClipData() { return null; }
    public ClipDescription getClipDescription() { return null; }
}
