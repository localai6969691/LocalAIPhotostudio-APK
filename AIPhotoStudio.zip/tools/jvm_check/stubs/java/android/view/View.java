package android.view;
/** Stub (R36): chỉ chữ ký performHapticFeedback(int) của android.view.View (API 1), dùng cho LocalView ở ParamSlider. */
public class View {
    public View() {}
    public boolean performHapticFeedback(int feedbackConstant) { return false; }
}
