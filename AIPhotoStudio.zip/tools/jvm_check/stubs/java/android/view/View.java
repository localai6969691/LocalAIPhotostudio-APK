package android.view;
/** Stub (R36, mở rộng R42): performHapticFeedback(int) cho LocalView ở ParamSlider; getRootView / setOnDragListener / OnDragListener cho kéo-thả ảnh (API 11). */
public class View {
    public View() {}
    public boolean performHapticFeedback(int feedbackConstant) { return false; }
    public interface OnDragListener { boolean onDrag(View v, DragEvent event); }
    public void setOnDragListener(OnDragListener l) {}
    public View getRootView() { return this; }
}
