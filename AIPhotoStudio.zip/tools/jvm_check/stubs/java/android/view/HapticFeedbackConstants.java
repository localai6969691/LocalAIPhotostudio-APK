package android.view;
/** Stub (R36): hằng số chép từ tài liệu android.view.HapticFeedbackConstants. */
public class HapticFeedbackConstants {
    public static final int LONG_PRESS = 0;
    public static final int VIRTUAL_KEY = 1;
    public static final int KEYBOARD_TAP = 3;
    public static final int CLOCK_TICK = 4;
    public static final int TEXT_HANDLE_MOVE = 9;
}
