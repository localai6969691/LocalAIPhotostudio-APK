package android.view;
/** Stub (R42): android.view.DragAndDropPermissions (API 24). */
public final class DragAndDropPermissions {
    public void release() {}
}
