package ai.onnxruntime;
public class TensorInfo implements ValueInfo { public final long[] shape = new long[0]; public final OnnxJavaType type = OnnxJavaType.FLOAT; public long[] getShape() { return shape; } public long getNumElements() { return 0; } }
