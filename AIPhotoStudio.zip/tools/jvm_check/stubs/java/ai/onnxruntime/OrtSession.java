package ai.onnxruntime;
import java.util.*;
import ai.onnxruntime.providers.NNAPIFlags;
public class OrtSession implements AutoCloseable {
    public Set<String> getInputNames() { return new HashSet<>(); } public Set<String> getOutputNames() { return new HashSet<>(); }
    public Map<String, NodeInfo> getInputInfo() throws OrtException { return new HashMap<>(); } public Map<String, NodeInfo> getOutputInfo() throws OrtException { return new HashMap<>(); }
    public Result run(Map<String, ? extends OnnxTensorLike> inputs) throws OrtException { throw new OrtException("stub"); }
    public void close() {}
    public static class Result implements AutoCloseable, Iterable<Map.Entry<String, OnnxValue>> {
        public OnnxValue get(int index) { throw new RuntimeException("stub"); } public Optional<OnnxValue> get(String name) { return Optional.empty(); }
        public int size() { return 0; } public void close() {}
        public Iterator<Map.Entry<String, OnnxValue>> iterator() { return new ArrayList<Map.Entry<String, OnnxValue>>().iterator(); }
    }
    public static class SessionOptions implements AutoCloseable {
        public enum OptLevel { NO_OPT, BASIC_OPT, EXTENDED_OPT, ALL_OPT }
        public enum ExecutionMode { SEQUENTIAL, PARALLEL }
        public SessionOptions() {}
        public void setIntraOpNumThreads(int n) throws OrtException {} public void setInterOpNumThreads(int n) throws OrtException {}
        public void setOptimizationLevel(OptLevel l) throws OrtException {} public void setExecutionMode(ExecutionMode m) throws OrtException {}
        public void setMemoryPatternOptimization(boolean b) throws OrtException {} public void setCPUArenaAllocator(boolean b) throws OrtException {}
        public void addNnapi() throws OrtException {} public void addNnapi(EnumSet<NNAPIFlags> flags) throws OrtException {}
        public void addXnnpack(Map<String, String> options) throws OrtException {} public void addCPU(boolean useArena) throws OrtException {}
        public void close() {}
    }
}
