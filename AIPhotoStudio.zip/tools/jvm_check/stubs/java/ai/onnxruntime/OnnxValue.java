package ai.onnxruntime;
public interface OnnxValue extends AutoCloseable { Object getValue() throws OrtException; ValueInfo getInfo(); void close(); }
