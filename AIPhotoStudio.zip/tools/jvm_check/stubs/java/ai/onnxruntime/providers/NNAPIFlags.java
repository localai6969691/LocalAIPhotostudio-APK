package ai.onnxruntime.providers;
public enum NNAPIFlags { USE_FP16, USE_NCHW, CPU_DISABLED, CPU_ONLY }
