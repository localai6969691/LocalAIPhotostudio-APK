package ai.onnxruntime;
public class OrtEnvironment implements AutoCloseable {
    public static OrtEnvironment getEnvironment() { return new OrtEnvironment(); }
    public static OrtEnvironment getEnvironment(String name) { return new OrtEnvironment(); }
    public OrtSession createSession(String modelPath, OrtSession.SessionOptions options) throws OrtException { throw new OrtException("stub"); }
    public OrtSession createSession(String modelPath) throws OrtException { throw new OrtException("stub"); }
    public OrtSession createSession(byte[] modelArray, OrtSession.SessionOptions options) throws OrtException { throw new OrtException("stub"); }
    public void close() {}
}
