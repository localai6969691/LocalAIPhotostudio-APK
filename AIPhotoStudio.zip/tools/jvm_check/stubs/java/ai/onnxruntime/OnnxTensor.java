package ai.onnxruntime;
import java.nio.*;
public class OnnxTensor implements OnnxTensorLike {
    public static OnnxTensor createTensor(OrtEnvironment env, Object data) throws OrtException { throw new OrtException("stub"); }
    public static OnnxTensor createTensor(OrtEnvironment env, FloatBuffer data, long[] shape) throws OrtException { throw new OrtException("stub"); }
    public static OnnxTensor createTensor(OrtEnvironment env, IntBuffer data, long[] shape) throws OrtException { throw new OrtException("stub"); }
    public static OnnxTensor createTensor(OrtEnvironment env, LongBuffer data, long[] shape) throws OrtException { throw new OrtException("stub"); }
    public static OnnxTensor createTensor(OrtEnvironment env, ByteBuffer data, long[] shape) throws OrtException { throw new OrtException("stub"); }
    public static OnnxTensor createTensor(OrtEnvironment env, ByteBuffer data, long[] shape, OnnxJavaType type) throws OrtException { throw new OrtException("stub"); }
    public FloatBuffer getFloatBuffer() { throw new RuntimeException("stub"); } public ByteBuffer getByteBuffer() { throw new RuntimeException("stub"); }
    public IntBuffer getIntBuffer() { throw new RuntimeException("stub"); } public LongBuffer getLongBuffer() { throw new RuntimeException("stub"); }
    public Object getValue() throws OrtException { throw new OrtException("stub"); }
    public TensorInfo getInfo() { return new TensorInfo(); }
    public void close() {}
}
