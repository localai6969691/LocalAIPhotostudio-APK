package ai.onnxruntime;
public class NodeInfo { public String getName() { return ""; } public ValueInfo getInfo() { return null; } }
