package ai.onnxruntime;
public enum OnnxJavaType { FLOAT, DOUBLE, INT8, INT16, INT32, INT64, BOOL, STRING, UINT8, FLOAT16, BFLOAT16, UNKNOWN }
