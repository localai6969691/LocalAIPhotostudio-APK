package ai.onnxruntime;
public interface OnnxTensorLike extends OnnxValue {}
