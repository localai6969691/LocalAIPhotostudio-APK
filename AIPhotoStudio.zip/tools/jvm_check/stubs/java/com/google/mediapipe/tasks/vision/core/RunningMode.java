package com.google.mediapipe.tasks.vision.core;
public enum RunningMode { IMAGE, VIDEO, LIVE_STREAM }
