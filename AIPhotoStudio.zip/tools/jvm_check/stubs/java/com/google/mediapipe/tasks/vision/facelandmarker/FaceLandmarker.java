package com.google.mediapipe.tasks.vision.facelandmarker;
import com.google.mediapipe.framework.image.MPImage; import com.google.mediapipe.tasks.core.BaseOptions; import com.google.mediapipe.tasks.vision.core.RunningMode;
public class FaceLandmarker implements AutoCloseable {
    public static FaceLandmarker createFromOptions(android.content.Context context, FaceLandmarkerOptions options) { throw new RuntimeException("stub"); }
    public FaceLandmarkerResult detect(MPImage image) { throw new RuntimeException("stub"); }
    public void close() {}
    public static class FaceLandmarkerOptions {
        public static Builder builder() { return new Builder(); }
        public static class Builder {
            public Builder setBaseOptions(BaseOptions o) { return this; } public Builder setRunningMode(RunningMode m) { return this; } public Builder setNumFaces(Integer n) { return this; }
            public Builder setMinFaceDetectionConfidence(Float f) { return this; } public Builder setMinFacePresenceConfidence(Float f) { return this; } public Builder setMinTrackingConfidence(Float f) { return this; }
            public Builder setOutputFaceBlendshapes(Boolean b) { return this; } public Builder setOutputFacialTransformationMatrixes(Boolean b) { return this; }
            public FaceLandmarkerOptions build() { return new FaceLandmarkerOptions(); }
        }
    }
}
