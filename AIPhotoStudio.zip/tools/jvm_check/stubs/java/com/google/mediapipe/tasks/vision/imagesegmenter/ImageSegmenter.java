package com.google.mediapipe.tasks.vision.imagesegmenter;
import com.google.mediapipe.framework.image.MPImage; import com.google.mediapipe.tasks.core.BaseOptions; import com.google.mediapipe.tasks.vision.core.RunningMode;
public class ImageSegmenter implements AutoCloseable {
    public static ImageSegmenter createFromOptions(android.content.Context context, ImageSegmenterOptions options) { throw new RuntimeException("stub"); }
    public ImageSegmenterResult segment(MPImage image) { throw new RuntimeException("stub"); }
    public void close() {}
    public static class ImageSegmenterOptions {
        public static Builder builder() { return new Builder(); }
        public static class Builder {
            public Builder setBaseOptions(BaseOptions o) { return this; } public Builder setRunningMode(RunningMode m) { return this; }
            public Builder setOutputCategoryMask(Boolean b) { return this; } public Builder setOutputConfidenceMasks(Boolean b) { return this; }
            public ImageSegmenterOptions build() { return new ImageSegmenterOptions(); }
        }
    }
}
