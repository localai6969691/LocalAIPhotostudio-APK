package com.google.mediapipe.tasks.components.containers;
import android.graphics.RectF; import java.util.List;
public class Detection {
    private final List<Category> cats; private final RectF box;
    public Detection(List<Category> cats, RectF box) { this.cats = cats; this.box = box; }
    public List<Category> categories() { return cats; } public RectF boundingBox() { return box; }
}
