package com.google.mediapipe.tasks.vision.objectdetector;
import com.google.mediapipe.framework.image.MPImage; import com.google.mediapipe.tasks.core.BaseOptions; import com.google.mediapipe.tasks.vision.core.RunningMode; import java.util.List;
public class ObjectDetector implements AutoCloseable {
    public static ObjectDetector createFromOptions(android.content.Context context, ObjectDetectorOptions options) { throw new RuntimeException("stub"); }
    public ObjectDetectorResult detect(MPImage image) { throw new RuntimeException("stub"); }
    public void close() {}
    public static class ObjectDetectorOptions {
        public static Builder builder() { return new Builder(); }
        public static class Builder {
            public Builder setBaseOptions(BaseOptions o) { return this; } public Builder setRunningMode(RunningMode m) { return this; } public Builder setDisplayNamesLocale(String s) { return this; }
            public Builder setMaxResults(Integer n) { return this; } public Builder setScoreThreshold(Float f) { return this; }
            public Builder setCategoryAllowlist(List<String> l) { return this; } public Builder setCategoryDenylist(List<String> l) { return this; }
            public ObjectDetectorOptions build() { return new ObjectDetectorOptions(); }
        }
    }
}
