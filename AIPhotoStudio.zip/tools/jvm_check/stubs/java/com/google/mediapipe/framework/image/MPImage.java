package com.google.mediapipe.framework.image;
public class MPImage { public int getWidth() { return 0; } public int getHeight() { return 0; } public void close() {} }
