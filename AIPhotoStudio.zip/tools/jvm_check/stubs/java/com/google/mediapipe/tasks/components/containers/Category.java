package com.google.mediapipe.tasks.components.containers;
public class Category {
    private final float score; private final String name;
    public Category(float score, String name) { this.score = score; this.name = name; }
    public float score() { return score; } public String categoryName() { return name; } public int index() { return 0; } public String displayName() { return name; }
}
