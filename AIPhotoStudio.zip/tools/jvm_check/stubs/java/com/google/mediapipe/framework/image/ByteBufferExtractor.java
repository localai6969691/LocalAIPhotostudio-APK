package com.google.mediapipe.framework.image;
public class ByteBufferExtractor { public static java.nio.ByteBuffer extract(MPImage image) { throw new RuntimeException("stub"); } }
