package com.google.mediapipe.tasks.genai.llminference;
public class LlmInference implements AutoCloseable {
    public static LlmInference createFromOptions(android.content.Context context, LlmInferenceOptions options) { throw new RuntimeException("stub"); }
    public String generateResponse(String inputText) { throw new RuntimeException("stub"); }
    public void close() {}
    public static class LlmInferenceOptions {
        public static Builder builder() { return new Builder(); }
        public static class Builder {
            public Builder setModelPath(String p) { return this; } public Builder setMaxTokens(int n) { return this; } public Builder setTopK(int k) { return this; }
            public Builder setTemperature(float t) { return this; } public Builder setRandomSeed(int s) { return this; }
            public LlmInferenceOptions build() { return new LlmInferenceOptions(); }
        }
    }
}
