package com.google.mediapipe.tasks.core;
public class BaseOptions {
    public static Builder builder() { return new Builder(); }
    public static class Builder { public Builder setModelAssetPath(String p) { return this; } public Builder setModelAssetBuffer(java.nio.ByteBuffer b) { return this; } public BaseOptions build() { return new BaseOptions(); } }
}
