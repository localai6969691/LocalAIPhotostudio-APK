package com.google.mediapipe.tasks.vision.imagesegmenter;
import java.util.*; import com.google.mediapipe.framework.image.MPImage;
public class ImageSegmenterResult { public Optional<MPImage> categoryMask() { return Optional.empty(); } public Optional<List<MPImage>> confidenceMasks() { return Optional.empty(); } }
