package com.google.mediapipe.tasks.components.containers;
public class NormalizedLandmark { public float x() { return 0; } public float y() { return 0; } public float z() { return 0; } }
