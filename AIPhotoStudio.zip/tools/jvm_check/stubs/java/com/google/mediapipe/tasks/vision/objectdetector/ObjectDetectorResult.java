package com.google.mediapipe.tasks.vision.objectdetector;
import java.util.*; import com.google.mediapipe.tasks.components.containers.Detection;
public class ObjectDetectorResult { public List<Detection> detections() { return new ArrayList<>(); } public long timestampMs() { return 0; } }
