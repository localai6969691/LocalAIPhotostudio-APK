package com.google.mediapipe.tasks.vision.facelandmarker;
import java.util.*; import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
public class FaceLandmarkerResult { public List<List<NormalizedLandmark>> faceLandmarks() { return new ArrayList<>(); } }
