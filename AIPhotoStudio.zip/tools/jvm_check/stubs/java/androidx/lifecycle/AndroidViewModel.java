package androidx.lifecycle;
import android.app.Application;
public class AndroidViewModel extends ViewModel {
    private Application mApplication;
    public AndroidViewModel(Application application) { mApplication = application; }
    @SuppressWarnings("unchecked") public <T extends Application> T getApplication() { return (T) mApplication; }
}
