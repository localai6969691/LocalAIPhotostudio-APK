package androidx.activity.result;
/** Stub (R35): chữ ký chép từ tài liệu androidx.activity (getResultCode / getData). */
public final class ActivityResult {
    public int getResultCode() { return 0; }
    public android.content.Intent getData() { return null; }
}
