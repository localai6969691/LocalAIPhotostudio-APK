package androidx.activity;
public class ComponentActivity extends android.app.Activity { public ComponentActivity() {} protected void onCreate(android.os.Bundle savedInstanceState) {} }
