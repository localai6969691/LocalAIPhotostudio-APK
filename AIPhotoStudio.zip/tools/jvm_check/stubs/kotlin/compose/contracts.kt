package androidx.activity.result.contract
import android.net.Uri
import androidx.activity.result.PickVisualMediaRequest
abstract class ActivityResultContract<I, O>
class ActivityResultContracts private constructor() {
    class GetContent : ActivityResultContract<String, Uri?>()
    class GetMultipleContents : ActivityResultContract<String, List<Uri>>()
    class OpenDocument : ActivityResultContract<Array<String>, Uri?>()
    open class PickVisualMedia : ActivityResultContract<PickVisualMediaRequest, Uri?>() {
        sealed interface VisualMediaType
        object ImageOnly : VisualMediaType
        object ImageAndVideo : VisualMediaType
    }
    class PickMultipleVisualMedia(maxItems: Int = 100) : ActivityResultContract<PickVisualMediaRequest, List<Uri>>()
}
