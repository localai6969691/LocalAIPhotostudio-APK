package androidx.compose.ui.hapticfeedback
@JvmInline value class HapticFeedbackType(val value: Int) { companion object { val LongPress = HapticFeedbackType(0); val TextHandleMove = HapticFeedbackType(1) } }
interface HapticFeedback { fun performHapticFeedback(hapticFeedbackType: HapticFeedbackType) }
