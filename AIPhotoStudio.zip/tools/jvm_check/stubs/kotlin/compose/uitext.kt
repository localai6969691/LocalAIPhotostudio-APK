package androidx.compose.ui.text.input
@JvmInline value class KeyboardType(val v: Int) { companion object { val Text = KeyboardType(1); val Number = KeyboardType(2); val Uri = KeyboardType(3); val Password = KeyboardType(4); val Decimal = KeyboardType(5) } }
interface VisualTransformation
class PasswordVisualTransformation(val mask: Char = '•') : VisualTransformation
