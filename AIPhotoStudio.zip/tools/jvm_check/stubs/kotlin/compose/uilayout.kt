package androidx.compose.ui.layout
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntSize
fun Modifier.onSizeChanged(onSizeChanged: (IntSize) -> Unit): Modifier = this
interface ContentScale { companion object { val Fit: ContentScale = object : ContentScale {}; val Fill: ContentScale = object : ContentScale {}; val Crop: ContentScale = object : ContentScale {}; val Inside: ContentScale = object : ContentScale {} } }
