package androidx.compose.ui.platform
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ProvidedValue
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.unit.LayoutDirection
class ProvidableLocal<T>(private val v: T?) { @get:Composable val current: T get() = v!!; infix fun provides(value: T): ProvidedValue<T> = ProvidedValue(value) }
val LocalLayoutDirection = ProvidableLocal<LayoutDirection>(LayoutDirection.Ltr) // R33
val LocalContext = ProvidableLocal<android.content.Context>(null)
val LocalHapticFeedback = ProvidableLocal<HapticFeedback>(null)
