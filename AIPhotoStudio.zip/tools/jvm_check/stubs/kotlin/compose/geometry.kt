package androidx.compose.ui.geometry
data class Offset(val x: Float, val y: Float) {
    operator fun plus(o: Offset) = Offset(x + o.x, y + o.y); operator fun minus(o: Offset) = Offset(x - o.x, y - o.y)
    operator fun times(f: Float) = Offset(x * f, y * f); operator fun div(f: Float) = Offset(x / f, y / f)
    fun getDistance(): Float = kotlin.math.sqrt(x * x + y * y)
    companion object { val Zero = Offset(0f, 0f); val Unspecified = Offset(Float.NaN, Float.NaN) }
}
data class Size(val width: Float, val height: Float) { val minDimension: Float get() = minOf(width, height); val maxDimension: Float get() = maxOf(width, height) }
