package androidx.compose.ui.graphics.drawscope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.Dp
sealed class DrawStyle
object Fill : DrawStyle()
class Stroke(val width: Float = 0f, val miter: Float = 4f, val cap: StrokeCap = StrokeCap.Butt, val join: StrokeJoin = StrokeJoin.Miter, val pathEffect: Any? = null) : DrawStyle() {
    companion object { const val HairlineWidth: Float = 0f; val DefaultCap = StrokeCap.Butt; val DefaultJoin = StrokeJoin.Miter }
}
interface DrawScope {
    val size: Size
    val center: Offset
    val density: Float
    fun Dp.toPx(): Float
    fun Dp.toDp(): Dp = this
    fun drawLine(color: Color, start: Offset, end: Offset, strokeWidth: Float = Stroke.HairlineWidth, cap: StrokeCap = Stroke.DefaultCap, pathEffect: Any? = null, alpha: Float = 1.0f, colorFilter: ColorFilter? = null)
    fun drawCircle(color: Color, radius: Float = size.minDimension / 2.0f, center: Offset = this.center, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null)
    fun drawRect(color: Color, topLeft: Offset = Offset.Zero, size: Size = this.size, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null)
    fun drawPath(path: Path, color: Color, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null)
}
