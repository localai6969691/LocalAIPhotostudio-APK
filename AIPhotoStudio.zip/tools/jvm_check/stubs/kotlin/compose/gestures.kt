package androidx.compose.foundation.gestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.*
interface PressGestureScope { suspend fun tryAwaitRelease(): Boolean }
suspend fun PointerInputScope.detectTapGestures(onDoubleTap: ((Offset) -> Unit)? = null, onLongPress: ((Offset) -> Unit)? = null, onPress: suspend PressGestureScope.(Offset) -> Unit = {}, onTap: ((Offset) -> Unit)? = null) {}
suspend fun PointerInputScope.detectDragGestures(onDragStart: (Offset) -> Unit = {}, onDragEnd: () -> Unit = {}, onDragCancel: () -> Unit = {}, onDrag: (change: PointerInputChange, dragAmount: Offset) -> Unit) {}
suspend fun PointerInputScope.awaitEachGesture(block: suspend AwaitPointerEventScope.() -> Unit) {}
suspend fun AwaitPointerEventScope.awaitFirstDown(requireUnconsumed: Boolean = true, pass: PointerEventPass = PointerEventPass.Main): PointerInputChange = PointerInputChange()
fun PointerEvent.calculatePan(): Offset = Offset.Zero
fun PointerEvent.calculateZoom(): Float = 1f
fun PointerEvent.calculateRotation(): Float = 0f
