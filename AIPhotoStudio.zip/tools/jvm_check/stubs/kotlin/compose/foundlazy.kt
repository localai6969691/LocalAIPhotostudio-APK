package androidx.compose.foundation.lazy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
interface LazyItemScope
interface LazyListScope { fun item(key: Any? = null, content: @Composable LazyItemScope.() -> Unit) }
inline fun <T> LazyListScope.items(items: List<T>, noinline key: ((item: T) -> Any)? = null, crossinline itemContent: @Composable LazyItemScope.(item: T) -> Unit) {}
@Composable fun LazyRow(modifier: Modifier = Modifier, contentPadding: PaddingValues = PaddingValues(), reverseLayout: Boolean = false, horizontalArrangement: Arrangement.Horizontal = Arrangement.Start, verticalAlignment: Alignment.Vertical = Alignment.Top, userScrollEnabled: Boolean = true, content: LazyListScope.() -> Unit) {}
