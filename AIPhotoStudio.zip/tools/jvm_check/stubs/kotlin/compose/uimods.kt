package androidx.compose.ui.draw
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
fun Modifier.clip(shape: Shape): Modifier = this
fun Modifier.drawBehind(onDraw: DrawScope.() -> Unit): Modifier = this
