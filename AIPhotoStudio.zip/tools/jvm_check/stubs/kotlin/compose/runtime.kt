package androidx.compose.runtime
import kotlin.reflect.KProperty
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE, AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY_GETTER)
annotation class Composable
@Target(AnnotationTarget.CLASS, AnnotationTarget.PROPERTY, AnnotationTarget.FUNCTION) annotation class Stable
@Target(AnnotationTarget.CLASS) annotation class Immutable

interface State<out T> { val value: T }
interface MutableState<T> : State<T> { override var value: T }
fun <T> mutableStateOf(value: T): MutableState<T> = object : MutableState<T> { override var value: T = value }
inline operator fun <T> State<T>.getValue(thisObj: Any?, property: KProperty<*>): T = value
inline operator fun <T> MutableState<T>.setValue(thisObj: Any?, property: KProperty<*>, value: T) { this.value = value }
@Composable inline fun <T> remember(calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(key1: Any?, calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(key1: Any?, key2: Any?, calculation: () -> T): T = calculation()
@Composable fun <T> rememberUpdatedState(newValue: T): State<T> = mutableStateOf(newValue)
@Composable fun <T> StateFlow<T>.collectAsState(context: CoroutineContext = EmptyCoroutineContext): State<T> = mutableStateOf(value)
@Composable fun LaunchedEffect(key1: Any?, block: suspend CoroutineScope.() -> Unit) {}
@Composable fun DisposableEffect(key1: Any?, effect: () -> Unit) {}
@Composable fun rememberCoroutineScope(): CoroutineScope = throw NotImplementedError()
fun <T> derivedStateOf(calculation: () -> T): State<T> = mutableStateOf(calculation())
class ProvidedValue<T>(val value: T) // R33
@Composable fun CompositionLocalProvider(vararg values: ProvidedValue<*>, content: @Composable () -> Unit) { content() }
