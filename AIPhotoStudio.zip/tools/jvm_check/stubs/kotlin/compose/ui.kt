package androidx.compose.ui
import androidx.compose.runtime.Composable
interface Modifier {
    companion object : Modifier
    infix fun then(other: Modifier): Modifier = this
}
interface Alignment {
    interface Horizontal; interface Vertical
    companion object {
        val TopStart: Alignment = object : Alignment {}; val TopCenter: Alignment = object : Alignment {}; val TopEnd: Alignment = object : Alignment {}
        val CenterStart: Alignment = object : Alignment {}; val Center: Alignment = object : Alignment {}; val CenterEnd: Alignment = object : Alignment {}
        val BottomStart: Alignment = object : Alignment {}; val BottomCenter: Alignment = object : Alignment {}; val BottomEnd: Alignment = object : Alignment {}
        val Top: Vertical = object : Vertical {}; val CenterVertically: Vertical = object : Vertical {}; val Bottom: Vertical = object : Vertical {}
        val Start: Horizontal = object : Horizontal {}; val CenterHorizontally: Horizontal = object : Horizontal {}; val End: Horizontal = object : Horizontal {}
    }
}
