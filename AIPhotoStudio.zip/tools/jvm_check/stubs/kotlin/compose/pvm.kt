package androidx.activity.result
import androidx.activity.result.contract.ActivityResultContracts
class PickVisualMediaRequest internal constructor()
fun PickVisualMediaRequest(mediaType: ActivityResultContracts.PickVisualMedia.VisualMediaType = ActivityResultContracts.PickVisualMedia.ImageAndVideo): PickVisualMediaRequest = PickVisualMediaRequest()
