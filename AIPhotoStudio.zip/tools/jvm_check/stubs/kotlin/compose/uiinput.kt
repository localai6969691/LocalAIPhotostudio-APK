package androidx.compose.ui.input.pointer
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
interface PointerInputScope { val size: androidx.compose.ui.unit.IntSize }
class PointerInputChange { val position: Offset = Offset.Zero; val previousPosition: Offset = Offset.Zero; val pressed: Boolean = false; val previousPressed: Boolean = false; fun consume() {} ; val isConsumed: Boolean = false }
fun PointerInputChange.positionChanged(): Boolean = true
class PointerEvent { val changes: List<PointerInputChange> = emptyList() }
interface AwaitPointerEventScope { suspend fun awaitPointerEvent(pass: PointerEventPass = PointerEventPass.Main): PointerEvent }
enum class PointerEventPass { Initial, Main, Final }
fun Modifier.pointerInput(key1: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = this
fun Modifier.pointerInput(key1: Any?, key2: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = this
fun Modifier.pointerInput(vararg keys: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = this
