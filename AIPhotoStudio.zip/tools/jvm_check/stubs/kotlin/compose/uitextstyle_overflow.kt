package androidx.compose.ui.text.style

/** Stub (R45): androidx.compose.ui.text.style.TextOverflow — chỉ cần `Clip` và `Ellipsis`. */
@JvmInline value class TextOverflow private constructor(private val value: Int) {
    companion object {
        val Clip = TextOverflow(1)
        val Ellipsis = TextOverflow(2)
    }
}
