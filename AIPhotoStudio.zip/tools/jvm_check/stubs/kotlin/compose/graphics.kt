package androidx.compose.ui.graphics
import androidx.compose.ui.geometry.Offset
class Color internal constructor(private val tag: String) {
    fun copy(alpha: Float = 1f, red: Float = 0f, green: Float = 0f, blue: Float = 0f): Color = this
    companion object { val Black = Color("Black"); val White = Color("White"); val Red = Color("Red"); val Green = Color("Green"); val Blue = Color("Blue"); val Yellow = Color("Yellow"); val Cyan = Color("Cyan"); val Magenta = Color("Magenta"); val Gray = Color("Gray"); val Transparent = Color("Transparent"); val Unspecified = Color("Unspecified") }
}
fun Color(color: Long): Color = Color.Black
fun Color(color: Int): Color = Color.Black
fun Color(red: Int, green: Int, blue: Int, alpha: Int = 0xFF): Color = Color.Black
fun Color(red: Float, green: Float, blue: Float, alpha: Float = 1f): Color = Color.Black
interface Shape
class Path { fun moveTo(x: Float, y: Float) {} fun lineTo(x: Float, y: Float) {} fun close() {} fun reset() {} fun quadraticBezierTo(x1: Float, y1: Float, x2: Float, y2: Float) {} }
enum class StrokeCap { Butt, Round, Square }
enum class StrokeJoin { Miter, Round, Bevel }
interface ImageBitmap { val width: Int; val height: Int }
fun android.graphics.Bitmap.asImageBitmap(): ImageBitmap = throw NotImplementedError()
class ColorFilter
val RectangleShape: Shape = object : Shape {}
