package androidx.activity
// Chữ ký chép từ androidx.activity 1.9 (androidx.activity.EdgeToEdge.kt / SystemBarStyle.kt) — R31
class SystemBarStyle private constructor() {
    companion object {
        @JvmStatic fun dark(scrim: Int): SystemBarStyle = SystemBarStyle()
        @JvmStatic fun light(scrim: Int, darkScrim: Int): SystemBarStyle = SystemBarStyle()
        @JvmStatic fun auto(lightScrim: Int, darkScrim: Int): SystemBarStyle = SystemBarStyle() // bản thật còn tham số detectDarkMode (Resources) -> Boolean
    }
}
fun ComponentActivity.enableEdgeToEdge(
    statusBarStyle: SystemBarStyle = SystemBarStyle.auto(0, 0),
    navigationBarStyle: SystemBarStyle = SystemBarStyle.auto(0, 0)
) {}
