package androidx.compose.foundation.layout
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
interface ColumnScope { fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier = this; fun Modifier.align(alignment: Alignment.Horizontal): Modifier = this }
interface RowScope { fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier = this; fun Modifier.align(alignment: Alignment.Vertical): Modifier = this }
interface BoxScope { fun Modifier.align(alignment: Alignment): Modifier = this }
object Arrangement {
    interface Horizontal; interface Vertical; interface HorizontalOrVertical : Horizontal, Vertical
    val Top: Vertical = object : Vertical {}; val Bottom: Vertical = object : Vertical {}; val Start: Horizontal = object : Horizontal {}; val End: Horizontal = object : Horizontal {}
    val Center: HorizontalOrVertical = object : HorizontalOrVertical {}; val SpaceBetween: HorizontalOrVertical = object : HorizontalOrVertical {}
    val SpaceEvenly: HorizontalOrVertical = object : HorizontalOrVertical {}; val SpaceAround: HorizontalOrVertical = object : HorizontalOrVertical {}
    fun spacedBy(space: Dp): HorizontalOrVertical = object : HorizontalOrVertical {}
    fun spacedBy(space: Dp, alignment: Alignment.Horizontal): Horizontal = object : Horizontal {}
    fun spacedBy(space: Dp, alignment: Alignment.Vertical): Vertical = object : Vertical {}
}
class PaddingValues(val all: Dp = Dp(0f)) { constructor(horizontal: Dp = Dp(0f), vertical: Dp = Dp(0f)) : this(Dp(0f)); constructor(start: Dp = Dp(0f), top: Dp = Dp(0f), end: Dp = Dp(0f), bottom: Dp = Dp(0f)) : this(Dp(0f)) }
@Composable inline fun Column(modifier: Modifier = Modifier, verticalArrangement: Arrangement.Vertical = Arrangement.Top, horizontalAlignment: Alignment.Horizontal = Alignment.Start, content: @Composable ColumnScope.() -> Unit) {}
@Composable inline fun Row(modifier: Modifier = Modifier, horizontalArrangement: Arrangement.Horizontal = Arrangement.Start, verticalAlignment: Alignment.Vertical = Alignment.Top, content: @Composable RowScope.() -> Unit) {}
@Composable inline fun Box(modifier: Modifier = Modifier, contentAlignment: Alignment = Alignment.TopStart, propagateMinConstraints: Boolean = false, content: @Composable BoxScope.() -> Unit) {}
@Composable fun Box(modifier: Modifier) {}
@Composable fun Spacer(modifier: Modifier) {}
fun Modifier.padding(all: Dp): Modifier = this
fun Modifier.padding(horizontal: Dp = Dp(0f), vertical: Dp = Dp(0f)): Modifier = this
fun Modifier.padding(start: Dp = Dp(0f), top: Dp = Dp(0f), end: Dp = Dp(0f), bottom: Dp = Dp(0f)): Modifier = this
fun Modifier.padding(paddingValues: PaddingValues): Modifier = this
fun Modifier.fillMaxWidth(fraction: Float = 1f): Modifier = this
fun Modifier.fillMaxHeight(fraction: Float = 1f): Modifier = this
fun Modifier.fillMaxSize(fraction: Float = 1f): Modifier = this
fun Modifier.safeDrawingPadding(): Modifier = this // R31 (compose.foundation.layout 1.6, ổn định)
fun Modifier.width(width: Dp): Modifier = this
fun Modifier.height(height: Dp): Modifier = this
fun Modifier.size(size: Dp): Modifier = this
fun Modifier.size(width: Dp, height: Dp): Modifier = this
fun Modifier.heightIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = this
fun Modifier.widthIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = this
