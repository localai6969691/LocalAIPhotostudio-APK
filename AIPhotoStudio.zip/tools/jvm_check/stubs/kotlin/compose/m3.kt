package androidx.compose.material3
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle   // R34f: thật sự nằm ở ui.text (bản cũ đặt nhầm trong material3 nên `import androidx.compose.ui.text.TextStyle` của i18n/Text.kt không phân giải được)
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp

@RequiresOptIn(level = RequiresOptIn.Level.ERROR) annotation class ExperimentalMaterial3Api
object LocalTextStyle { val current: TextStyle @Composable get() = TextStyle() } // R33
class Typography { val bodySmall = TextStyle(); val bodyMedium = TextStyle(); val bodyLarge = TextStyle(); val titleSmall = TextStyle(); val titleMedium = TextStyle(); val titleLarge = TextStyle(); val labelSmall = TextStyle(); val labelMedium = TextStyle(); val labelLarge = TextStyle() }
class ColorScheme { val primary = Color.Black; val onPrimary = Color.Black; val surface = Color.Black; val onSurface = Color.Black; val onSurfaceVariant = Color.Black; val background = Color.Black; val onBackground = Color.Black; val error = Color.Black; val secondary = Color.Black; val outline = Color.Black; val surfaceVariant = Color.Black }
fun darkColorScheme(): ColorScheme = ColorScheme()
object MaterialTheme {
    val colorScheme: ColorScheme @Composable get() = ColorScheme()
    val typography: Typography @Composable get() = Typography()
}
@Composable fun MaterialTheme(colorScheme: ColorScheme = MaterialTheme.colorScheme, typography: Typography = MaterialTheme.typography, content: @Composable () -> Unit) {}
@Composable fun Surface(modifier: Modifier = Modifier, shape: Shape = androidx.compose.ui.graphics.RectangleShape, color: Color = Color.Black, contentColor: Color = Color.Black, content: @Composable () -> Unit) {}
@Composable fun Text(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified, maxLines: Int = Int.MAX_VALUE, style: TextStyle = TextStyle()) {}
@Composable fun Button(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = androidx.compose.ui.graphics.RectangleShape, contentPadding: PaddingValues = PaddingValues(), content: @Composable RowScope.() -> Unit) {}
@Composable fun OutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = androidx.compose.ui.graphics.RectangleShape, contentPadding: PaddingValues = PaddingValues(), content: @Composable RowScope.() -> Unit) {}
@Composable fun TextButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = androidx.compose.ui.graphics.RectangleShape, contentPadding: PaddingValues = PaddingValues(), content: @Composable RowScope.() -> Unit) {}
@ExperimentalMaterial3Api
@Composable fun AssistChip(onClick: () -> Unit, label: @Composable () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, leadingIcon: @Composable (() -> Unit)? = null, trailingIcon: @Composable (() -> Unit)? = null, shape: Shape = androidx.compose.ui.graphics.RectangleShape) {}
@ExperimentalMaterial3Api
@Composable fun FilterChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, leadingIcon: @Composable (() -> Unit)? = null, trailingIcon: @Composable (() -> Unit)? = null, shape: Shape = androidx.compose.ui.graphics.RectangleShape) {}
@Composable fun Slider(value: Float, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, valueRange: ClosedFloatingPointRange<Float> = 0f..1f, steps: Int = 0, onValueChangeFinished: (() -> Unit)? = null) {}
@Composable fun OutlinedTextField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, readOnly: Boolean = false, textStyle: TextStyle = TextStyle(), label: @Composable (() -> Unit)? = null, placeholder: @Composable (() -> Unit)? = null, leadingIcon: @Composable (() -> Unit)? = null, trailingIcon: @Composable (() -> Unit)? = null, supportingText: @Composable (() -> Unit)? = null, isError: Boolean = false, visualTransformation: VisualTransformation = object : VisualTransformation {}, keyboardOptions: KeyboardOptions = KeyboardOptions.Default, singleLine: Boolean = false, maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE, minLines: Int = 1) {}
@Composable fun AlertDialog(onDismissRequest: () -> Unit, confirmButton: @Composable () -> Unit, modifier: Modifier = Modifier, dismissButton: @Composable (() -> Unit)? = null, icon: @Composable (() -> Unit)? = null, title: @Composable (() -> Unit)? = null, text: @Composable (() -> Unit)? = null) {}
@Composable fun LinearProgressIndicator(modifier: Modifier = Modifier) {}
@Composable fun LinearProgressIndicator(progress: Float, modifier: Modifier = Modifier) {}
@Composable fun Card(modifier: Modifier = Modifier, shape: Shape = androidx.compose.ui.graphics.RectangleShape, content: @Composable ColumnScope.() -> Unit) {}
@Composable fun DropdownMenu(expanded: Boolean, onDismissRequest: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {}
@Composable fun DropdownMenuItem(text: @Composable () -> Unit, onClick: () -> Unit, modifier: Modifier = Modifier, leadingIcon: @Composable (() -> Unit)? = null, trailingIcon: @Composable (() -> Unit)? = null, enabled: Boolean = true) {}
