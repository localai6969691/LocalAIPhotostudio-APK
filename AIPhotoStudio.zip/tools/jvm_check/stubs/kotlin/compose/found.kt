package androidx.compose.foundation
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
class ScrollState
@Composable fun rememberScrollState(initial: Int = 0): ScrollState = ScrollState()
fun Modifier.verticalScroll(state: ScrollState, enabled: Boolean = true, reverseScrolling: Boolean = false): Modifier = this
fun Modifier.horizontalScroll(state: ScrollState, enabled: Boolean = true, reverseScrolling: Boolean = false): Modifier = this
fun Modifier.background(color: Color, shape: Shape = RectangleShape): Modifier = this
fun Modifier.border(width: Dp, color: Color, shape: Shape = RectangleShape): Modifier = this
fun Modifier.clickable(enabled: Boolean = true, onClickLabel: String? = null, onClick: () -> Unit): Modifier = this
@Composable fun Image(bitmap: ImageBitmap, contentDescription: String?, modifier: Modifier = Modifier, alignment: Alignment = Alignment.Center, contentScale: ContentScale = ContentScale.Fit, alpha: Float = 1f, colorFilter: ColorFilter? = null) {}
@Composable fun Canvas(modifier: Modifier, onDraw: DrawScope.() -> Unit) {}
