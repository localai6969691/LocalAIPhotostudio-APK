package androidx.compose.ui.unit
@JvmInline value class Dp(val value: Float) : Comparable<Dp> {
    override fun compareTo(other: Dp): Int = value.compareTo(other.value)
    operator fun plus(other: Dp) = Dp(value + other.value)
    operator fun minus(other: Dp) = Dp(value - other.value)
    operator fun times(other: Float) = Dp(value * other)
    operator fun times(other: Int) = Dp(value * other)
    operator fun div(other: Float) = Dp(value / other)
    operator fun unaryMinus() = Dp(-value)
    companion object { val Hairline = Dp(0f); val Unspecified = Dp(Float.NaN); val Infinity = Dp(Float.POSITIVE_INFINITY) }
}
val Int.dp: Dp get() = Dp(this.toFloat())
val Float.dp: Dp get() = Dp(this)
val Double.dp: Dp get() = Dp(this.toFloat())
enum class LayoutDirection { Ltr, Rtl } // R33
data class IntSize(val width: Int, val height: Int) { companion object { val Zero = IntSize(0, 0) } }
