package kotlinx.coroutines.flow

// R37: jar coroutines đi kèm kotlin-compiler-1.9.24.zip là bản 1.5.0 (2021) — chưa có `MutableStateFlow.update` (thêm ở 1.5.1; dự án dùng 1.8.1).
// Chữ ký + ngữ nghĩa chép từ thư viện thật (vòng lặp compareAndSet). Xóa tệp này nếu GRADLE_LIB có coroutines >= 1.5.1.
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) {
    while (true) {
        val prevValue = value
        val nextValue = function(prevValue)
        if (compareAndSet(prevValue, nextValue)) return
    }
}
