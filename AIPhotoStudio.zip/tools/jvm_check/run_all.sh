#!/bin/bash
# Chạy trọn bộ kiểm tra không cần Android SDK / mạng: (1) biên dịch thật 3 biến thể build, (2) JUnit, (3) static_check, (4) test backend, (5) bản port Python.
# Thoát khác 0 nếu có bước hỏng. Mất vài phút lần đầu (kotlinc).
source "$(dirname "${BASH_SOURCE[0]}")/env.sh" || exit 1
fail=0
step() { echo; echo "=== $*"; }
step "1/5 biên dịch Kotlin (mặc định)";           "$JC/build.sh" || fail=1
step "1b/5 biên dịch biến thể billing + litertlm + integrity"; "$JC/build.sh" billing litertlm integrity || fail=1
step "2/5 JUnit";  out=$("$JC/runtests.sh" 2>&1); echo "$out" | grep -E -A3 "^[0-9]+\) " | head -150; echo "$out" | tail -5; echo "$out" | grep -q "^OK (" || fail=1   # R34f: in tên + lý do từng test hỏng (trước chỉ in 5 dòng cuối nên dán log không biết test nào)
step "3/5 static_check.py"; out=$(cd "$P" && python3 tools/static_check.py); echo "$out" | tail -2; echo "$out" | grep -q "0 lỗi, 0 cảnh báo" || fail=1
step "4/5 backend"; if [ -f "$P/backend/test_server.py" ]; then out=$(cd "$P/backend" && python3 test_server.py); echo "$out" | tail -2; echo "$out" | grep -q "TỔNG: \([0-9]*\)/\1 đạt" || fail=1; else echo "BỎ QUA: repo không có backend/test_server.py (tải thư mục backend/ lên)"; fi
step "5/5 bản port Python"; for f in "$P"/tools/verify_ports/*.py; do python3 "$f" > /dev/null 2>&1 || { echo "HỎNG: $f"; fail=1; }; done
echo; [ $fail = 0 ] && echo "TẤT CẢ ĐẠT" || echo "CÓ BƯỚC HỎNG"
exit $fail
