#!/bin/bash
# R40: biên dịch tích hợp LiteRT-LM của app (app/src/litertlmReal) với MÃ NGUỒN KOTLIN THẬT của google-ai-edge/LiteRT-LM (GitHub, Apache-2.0)
# thay cho stub tự đoán (`stubs_litertlm`, từng đoán sai Message.text ở R34e). Maven Google bị chặn trong sandbox nhưng github.com mở.
# Cách dùng:  check_real_litertlm.sh [tag]      (mặc định v0.19.1)   — cần: git, javac, kotlinc của jvm_check (env.sh), apt-get (lấy gson)
# Việc làm: (1) sparse-clone thư mục kotlin/ ở tag đó; (2) lấy gson (apt-get download libgoogle-gson-java); (3) kotlinc biên dịch
# toàn bộ mã nguồn thư viện (trừ example/) + TextGen + AcceleratorPolicy + litertlmReal + RealLiteRtLmCheck.kt; (4) chạy RealLiteRtLmCheck.
source "$(dirname "${BASH_SOURCE[0]}")/../env.sh" || exit 1
TAG="${1:-v0.19.1}"; W="${REAL_LLM_WORK:-/tmp/real_litertlm}"; mkdir -p "$W"
if [ ! -d "$W/src/kotlin" ]; then
  rm -rf "$W/src"; git clone -q --depth 1 --branch "$TAG" --filter=blob:none --sparse https://github.com/google-ai-edge/LiteRT-LM.git "$W/src" || exit 2
  (cd "$W/src" && git sparse-checkout set kotlin) || exit 2
fi
GSON="$(ls "$W"/gson/usr/share/java/gson-*.jar 2>/dev/null | head -1)"
if [ -z "$GSON" ]; then
  mkdir -p "$W/gson" && (cd "$W/gson" && apt-get download libgoogle-gson-java >/dev/null 2>&1; dpkg-deb -x libgoogle-gson-java_*.deb . ) || exit 2
  GSON="$(ls "$W"/gson/usr/share/java/gson-*.jar | head -1)"
fi
STUBC="$W/stubs"; CLS="$W/classes"; rm -rf "$STUBC" "$CLS"; mkdir -p "$STUBC"
javac -nowarn -d "$STUBC" $(find "$JC/stubs/java/android" -name '*.java') 2>&1 | grep -v '^Note:'
LIB=$(find "$W/src/kotlin" -name '*.kt' -not -path '*/example/*')
APP="$P/app/src/main/java/com/aiphoto/studio/ai/TextGen.kt $P/app/src/main/java/com/aiphoto/studio/ai/AcceleratorPolicy.kt $(find "$P/app/src/litertlmReal" -name '*.kt')"
echo "LiteRT-LM $TAG ($(grep -E '^VERSION' "$W/src/version.bzl")): $(echo "$LIB" | wc -w) tệp thư viện + $(echo "$APP" | wc -w) tệp app"
"$JC/kc.sh" "$CLS" "$STUBC:$GSON:$GRADLE_LIB/kotlin-reflect-$KVER.jar" $LIB $APP "$JC/real_litertlm/RealLiteRtLmCheck.kt" > "$W/build.log" 2>&1
rc=$?; errs=$(grep -c ' error: ' "$W/build.log"); echo "kotlinc exit=$rc errors=$errs (log: $W/build.log)"; grep ' error: ' "$W/build.log" | head -30
[ "$rc" = 0 ] && [ "$errs" = 0 ] || exit 1
G="$GRADLE_LIB"
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$CLS:$STUBC:$GSON:$G/kotlin-reflect-$KVER.jar:$G/kotlin-stdlib-$KVER.jar:$(ls "$G"/kotlinx-coroutines-core-jvm-*.jar | head -1)" com.aiphoto.studio.ai.RealLiteRtLmCheckKt
