package com.aiphoto.studio.ai

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig

// R40: chạy trên lớp THẬT của google-ai-edge/LiteRT-LM (không phải stub). Không có thư viện native nên không khởi tạo được Engine;
// kiểm các phần thuần Kotlin mà tích hợp của app phụ thuộc: hợp đồng dữ liệu (Message/Contents/Content), kiểm tra tham số
// (SamplerConfig/EngineConfig), và hàm LiteRtLmTextGen.replyText (lấy văn bản từ phản hồi).
private var fails = 0
private fun check(name: String, ok: Boolean) { println((if (ok) "  ĐẠT   " else "  HỎNG  ") + name); if (!ok) fails++ }

fun main() {
    // 1) replyText trên Message THẬT do thư viện tạo (factory công khai Message.model)
    val json = "{\"ops\":[{\"type\":\"brightness\",\"value\":0.2}]}"
    check("replyText: Message.model(Contents.of(text)) -> đúng văn bản", LiteRtLmTextGen.replyText(Message.model(Contents.of(json))) == json)
    check("replyText: nhiều Content.Text được nối", LiteRtLmTextGen.replyText(Message.model(Contents.of(Content.Text("ab"), Content.Text("cd")))) == "abcd")
    check("replyText: lẫn ImageFile -> chỉ lấy chữ", LiteRtLmTextGen.replyText(Message.model(Contents.of(Content.ImageFile("/x.jpg"), Content.Text("ok")))) == "ok")
    check("replyText: tiếng Việt có dấu giữ nguyên", LiteRtLmTextGen.replyText(Message.model(Contents.of("Làm sáng ảnh, da mịn hơn"))) == "Làm sáng ảnh, da mịn hơn")
    check("replyText: null -> rỗng", LiteRtLmTextGen.replyText(null) == "")
    check("replyText: Message không nội dung -> chuỗi rỗng, không văng", LiteRtLmTextGen.replyText(Message.model()) == "")

    // 2) toString() của Message (đường dự phòng của replyText) khớp chữ
    check("Message.toString() = văn bản", Message.model(Contents.of(json)).toString() == json)

    // 3) cấu hình đúng như tích hợp dùng: dựng được, và tham số vi phạm bị từ chối bằng IllegalArgumentException
    val sampler = SamplerConfig(topK = 10, topP = 0.95, temperature = 0.2)
    val cc = ConversationConfig(samplerConfig = sampler)
    check("ConversationConfig(samplerConfig=...) dựng được", cc.samplerConfig?.topK == 10)
    val npu = EngineConfig(modelPath = "m.litertlm", backend = Backend.NPU(nativeLibraryDir = "/lib"), cacheDir = "/c")
    val gpuV = EngineConfig(modelPath = "m.litertlm", backend = Backend.GPU(), visionBackend = Backend.GPU(), cacheDir = "/c")
    val cpu = EngineConfig(modelPath = "m.litertlm", backend = Backend.CPU(), cacheDir = "/c")
    check("EngineConfig NPU/GPU+vision/CPU dựng được", npu.backend.name == "NPU" && gpuV.visionBackend != null && cpu.backend.name == "CPU")
    check("Backend.NPU mang nativeLibraryDir", (npu.backend as Backend.NPU).nativeLibraryDir == "/lib")
    val bad = try { SamplerConfig(topK = 0, topP = 0.95, temperature = 0.2); false } catch (e: IllegalArgumentException) { true }
    check("SamplerConfig topK=0 bị từ chối", bad)
    check("Contents.of(Text, ImageFile) giữ thứ tự (ảnh trước chữ như tích hợp gửi)", Contents.of(Content.ImageFile("/a.jpg"), Content.Text("p")).contents.let { it[0] is Content.ImageFile && it[1] is Content.Text })

    println(if (fails == 0) "RealLiteRtLmCheck: TẤT CẢ ĐẠT" else "RealLiteRtLmCheck: $fails HỎNG")
    if (fails != 0) kotlin.system.exitProcess(1)
}
