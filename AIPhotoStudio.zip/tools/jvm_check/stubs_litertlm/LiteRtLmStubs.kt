package com.google.ai.edge.litertlm

// Stub theo trang "Get Started with LiteRT-LM on Android" (chữ ký như A89). Chỉ để trình biên dịch kiểm tra mã gọi.
sealed class Backend {
    class CPU(val numOfThreads: Int? = null) : Backend()
    class GPU : Backend()
    class NPU(val nativeLibraryDir: String = "") : Backend()
}

class EngineConfig(
    val modelPath: String,
    val backend: Backend = Backend.CPU(),
    val visionBackend: Backend? = null,
    val audioBackend: Backend? = null,
    val maxNumTokens: Int? = null,
    val cacheDir: String? = null
)

class SamplerConfig(val topK: Int, val topP: Double, val temperature: Double, val seed: Int = 0)

class ConversationConfig(
    val systemInstruction: Contents? = null,
    val samplerConfig: SamplerConfig? = null
)

sealed class Content {
    class Text(val text: String) : Content()
    class ImageFile(val absolutePath: String) : Content()
    class ImageBytes(val bytes: ByteArray) : Content()
}

class Contents private constructor(val contents: List<Content>) {
    companion object {
        fun of(vararg contents: Content): Contents = Contents(contents.toList())
        fun of(text: String): Contents = Contents(listOf(Content.Text(text)))
    }
}

class Message(val text: String?)

class Conversation : AutoCloseable {
    fun sendMessage(contents: Contents): Message = Message("")
    fun sendMessage(text: String): Message = Message("")
    override fun close() {}
}

class Engine(val config: EngineConfig) : AutoCloseable {
    fun initialize() {}
    fun createConversation(config: ConversationConfig = ConversationConfig()): Conversation = Conversation()
    override fun close() {}
}
