package com.google.ai.edge.litertlm

// Stub theo trang "Get Started with LiteRT-LM on Android" (chữ ký như A89). Chỉ để trình biên dịch kiểm tra mã gọi.
// CẢNH BÁO (R34e): stub là SUY ĐOÁN — lần này đoán `Message.text` sai và CI mới lộ. Chữ ký nào chưa có chứng cứ từ biên dịch thật thì coi là chưa kiểm.
sealed class Backend {
    class CPU(val numOfThreads: Int? = null) : Backend()
    class GPU : Backend()
    class NPU(val nativeLibraryDir: String = "") : Backend()
}

class EngineConfig(
    val modelPath: String,
    val backend: Backend = Backend.CPU(),
    val visionBackend: Backend? = null,
    val audioBackend: Backend? = null,
    val maxNumTokens: Int? = null,
    val cacheDir: String? = null
)

class SamplerConfig(val topK: Int, val topP: Double, val temperature: Double, val seed: Int = 0)

class ConversationConfig(
    val systemInstruction: Contents? = null,
    val samplerConfig: SamplerConfig? = null
)

sealed class Content {
    class Text(val text: String) : Content()
    class ImageFile(val absolutePath: String) : Content()
    class ImageBytes(val bytes: ByteArray) : Content()
}

class Contents private constructor(val contents: List<Content>) {
    companion object {
        fun of(vararg contents: Content): Contents = Contents(contents.toList())
        fun of(text: String): Contents = Contents(listOf(Content.Text(text)))
    }
}

// R34e: API thật — Message có `contents` (và toolCalls/channels…), KHÔNG có `text` (CI Build APK #7: "Unresolved reference: text"). Văn bản lấy qua toString()/contents.
class Message(val contents: Contents) {
    override fun toString(): String = contents.contents.filterIsInstance<Content.Text>().joinToString("") { it.text }
}

class Conversation : AutoCloseable {
    fun sendMessage(contents: Contents): Message = Message(contents)
    fun sendMessage(text: String): Message = Message(Contents.of(text))
    override fun close() {}
}

class Engine(val config: EngineConfig) : AutoCloseable {
    fun initialize() {}
    fun createConversation(config: ConversationConfig = ConversationConfig()): Conversation = Conversation()
    override fun close() {}
}
