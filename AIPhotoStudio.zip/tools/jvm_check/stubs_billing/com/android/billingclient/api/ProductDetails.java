package com.android.billingclient.api;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;
public final class ProductDetails {
    @NonNull public String getProductId() { return ""; }
    @NonNull public String getName() { return ""; }
    @NonNull public String getProductType() { return ""; }
    @Nullable public OneTimePurchaseOfferDetails getOneTimePurchaseOfferDetails() { return null; }
    @Nullable public List<SubscriptionOfferDetails> getSubscriptionOfferDetails() { return null; }
    public static final class OneTimePurchaseOfferDetails {
        @NonNull public String getFormattedPrice() { return ""; }
        public long getPriceAmountMicros() { return 0; }
        @NonNull public String getPriceCurrencyCode() { return ""; }
    }
    public static final class SubscriptionOfferDetails {
        @Nullable public String getOfferId() { return null; }
        @NonNull public String getOfferToken() { return ""; }
        @NonNull public String getBasePlanId() { return ""; }
        @NonNull public PricingPhases getPricingPhases() { return new PricingPhases(); }
    }
    public static final class PricingPhases {
        @NonNull public List<PricingPhase> getPricingPhaseList() { throw new RuntimeException("stub"); }
    }
    public static final class PricingPhase {
        @NonNull public String getFormattedPrice() { return ""; }
        public long getPriceAmountMicros() { return 0; }
        @NonNull public String getPriceCurrencyCode() { return ""; }
        @NonNull public String getBillingPeriod() { return ""; }
    }
}
