package com.android.billingclient.api;
import androidx.annotation.NonNull;
public final class QueryPurchasesParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static class Builder {
        @NonNull public Builder setProductType(@NonNull String type) { return this; }
        @NonNull public QueryPurchasesParams build() { return new QueryPurchasesParams(); }
    }
}
