package com.android.billingclient.api;
import androidx.annotation.NonNull;
import java.util.List;
public final class QueryProductDetailsResult {
    @NonNull public List<ProductDetails> getProductDetailsList() { throw new RuntimeException("stub"); }
    @NonNull public List<UnfetchedProduct> getUnfetchedProductList() { throw new RuntimeException("stub"); }
}
