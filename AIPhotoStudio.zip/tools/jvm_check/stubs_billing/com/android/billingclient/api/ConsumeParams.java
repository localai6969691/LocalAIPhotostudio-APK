package com.android.billingclient.api;
import androidx.annotation.NonNull;
public final class ConsumeParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static final class Builder {
        @NonNull public Builder setPurchaseToken(@NonNull String token) { return this; }
        @NonNull public ConsumeParams build() { return new ConsumeParams(); }
    }
}
