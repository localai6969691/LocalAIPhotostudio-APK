package com.android.billingclient.api;
import androidx.annotation.NonNull;
public final class AcknowledgePurchaseParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static final class Builder {
        @NonNull public Builder setPurchaseToken(@NonNull String token) { return this; }
        @NonNull public AcknowledgePurchaseParams build() { return new AcknowledgePurchaseParams(); }
    }
}
