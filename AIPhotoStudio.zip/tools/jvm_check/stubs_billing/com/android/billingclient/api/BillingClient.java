package com.android.billingclient.api;
import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
/** Stub theo Play Billing Library 8.x (chữ ký từ tài liệu chính thức). */
public abstract class BillingClient {
    public static final class BillingResponseCode {
        public static final int SERVICE_TIMEOUT = -3, FEATURE_NOT_SUPPORTED = -2, SERVICE_DISCONNECTED = -1, OK = 0,
            USER_CANCELED = 1, SERVICE_UNAVAILABLE = 2, BILLING_UNAVAILABLE = 3, ITEM_UNAVAILABLE = 4,
            DEVELOPER_ERROR = 5, ERROR = 6, ITEM_ALREADY_OWNED = 7, ITEM_NOT_OWNED = 8, NETWORK_ERROR = 12;
    }
    public static final class ProductType { public static final String INAPP = "inapp", SUBS = "subs"; }
    public abstract boolean isReady();
    public abstract void startConnection(@NonNull BillingClientStateListener listener);
    public abstract void endConnection();
    public abstract void queryProductDetailsAsync(@NonNull QueryProductDetailsParams params, @NonNull ProductDetailsResponseListener listener);
    @NonNull public abstract BillingResult launchBillingFlow(@NonNull Activity activity, @NonNull BillingFlowParams params);
    public abstract void queryPurchasesAsync(@NonNull QueryPurchasesParams params, @NonNull PurchasesResponseListener listener);
    public abstract void consumeAsync(@NonNull ConsumeParams params, @NonNull ConsumeResponseListener listener);
    public abstract void acknowledgePurchase(@NonNull AcknowledgePurchaseParams params, @NonNull AcknowledgePurchaseResponseListener listener);
    @NonNull public static Builder newBuilder(@NonNull Context context) { throw new RuntimeException("stub"); }
    public static final class Builder {
        @NonNull public Builder setListener(@NonNull PurchasesUpdatedListener listener) { return this; }
        @NonNull public Builder enablePendingPurchases(@NonNull PendingPurchasesParams params) { return this; }
        @NonNull public Builder enableAutoServiceReconnection() { return this; }
        @NonNull public BillingClient build() { throw new RuntimeException("stub"); }
    }
}
