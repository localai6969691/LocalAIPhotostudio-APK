package com.android.billingclient.api;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;
public interface PurchasesUpdatedListener {
    void onPurchasesUpdated(@NonNull BillingResult result, @Nullable List<Purchase> purchases);
}
