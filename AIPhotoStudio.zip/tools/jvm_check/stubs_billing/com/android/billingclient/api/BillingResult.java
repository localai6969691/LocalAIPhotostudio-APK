package com.android.billingclient.api;
import androidx.annotation.NonNull;
public final class BillingResult {
    public int getResponseCode() { return 0; }
    @NonNull public String getDebugMessage() { return ""; }
}
