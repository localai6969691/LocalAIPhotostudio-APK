package com.android.billingclient.api;
import androidx.annotation.NonNull;
public interface ConsumeResponseListener {
    void onConsumeResponse(@NonNull BillingResult result, @NonNull String purchaseToken);
}
