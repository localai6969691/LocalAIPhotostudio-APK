package com.android.billingclient.api;
import androidx.annotation.NonNull;
import java.util.List;
public final class BillingFlowParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static class Builder {
        @NonNull public Builder setProductDetailsParamsList(@NonNull List<ProductDetailsParams> list) { return this; }
        @NonNull public Builder setObfuscatedAccountId(@NonNull String id) { return this; }
        @NonNull public BillingFlowParams build() { return new BillingFlowParams(); }
    }
    public static final class ProductDetailsParams {
        @NonNull public static Builder newBuilder() { return new Builder(); }
        public static class Builder {
            @NonNull public Builder setProductDetails(@NonNull ProductDetails pd) { return this; }
            @NonNull public Builder setOfferToken(@NonNull String token) { return this; }
            @NonNull public ProductDetailsParams build() { return new ProductDetailsParams(); }
        }
    }
}
