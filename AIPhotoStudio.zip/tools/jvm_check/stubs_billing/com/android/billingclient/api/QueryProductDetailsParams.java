package com.android.billingclient.api;
import androidx.annotation.NonNull;
import java.util.List;
public final class QueryProductDetailsParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static class Builder {
        @NonNull public Builder setProductList(@NonNull List<Product> list) { return this; }
        @NonNull public QueryProductDetailsParams build() { return new QueryProductDetailsParams(); }
    }
    public static class Product {
        @NonNull public static Builder newBuilder() { return new Builder(); }
        public static class Builder {
            @NonNull public Builder setProductId(@NonNull String id) { return this; }
            @NonNull public Builder setProductType(@NonNull String type) { return this; }
            @NonNull public Product build() { return new Product(); }
        }
    }
}
