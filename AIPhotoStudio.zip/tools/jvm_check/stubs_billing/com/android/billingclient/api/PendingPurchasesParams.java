package com.android.billingclient.api;
import androidx.annotation.NonNull;
public final class PendingPurchasesParams {
    @NonNull public static Builder newBuilder() { return new Builder(); }
    public static class Builder {
        @NonNull public Builder enableOneTimeProducts() { return this; }
        @NonNull public Builder enablePrepaidPlans() { return this; }
        @NonNull public PendingPurchasesParams build() { return new PendingPurchasesParams(); }
    }
}
