package com.android.billingclient.api;
import androidx.annotation.NonNull;
import java.util.List;
public class Purchase {
    public static final class PurchaseState { public static final int UNSPECIFIED_STATE = 0, PURCHASED = 1, PENDING = 2; }
    @NonNull public List<String> getProducts() { throw new RuntimeException("stub"); }
    @NonNull public String getPurchaseToken() { return ""; }
    public int getPurchaseState() { return 0; }
    public boolean isAcknowledged() { return false; }
}
