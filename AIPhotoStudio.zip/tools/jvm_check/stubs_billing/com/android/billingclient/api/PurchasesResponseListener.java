package com.android.billingclient.api;
import androidx.annotation.NonNull;
import java.util.List;
public interface PurchasesResponseListener {
    void onQueryPurchasesResponse(@NonNull BillingResult result, @NonNull List<Purchase> purchases);
}
