package com.android.billingclient.api;
import androidx.annotation.NonNull;
public interface ProductDetailsResponseListener {
    void onProductDetailsResponse(@NonNull BillingResult result, @NonNull QueryProductDetailsResult queryResult);
}
