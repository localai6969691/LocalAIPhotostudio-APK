#!/bin/bash
# R36: tự dựng "thư mục lib kiểu Gradle" cho jvm_check khi máy KHÔNG có Gradle (sandbox của Claude không có kotlinc / Gradle / mạng trong cuộc trò chuyện cũ).
# In ra STDOUT đúng một dòng: đường dẫn thư mục lib dùng được (tiến trình / lỗi in ra STDERR). env.sh tự gọi script này khi chưa có GRADLE_LIB.
# Thứ tự thử (dừng ở cách đầu tiên cho đủ bộ jar):
#   1. gradle-*-bin.zip đã tải lên (UPLOADS, mặc định /mnt/user-data/uploads) — lấy gradle-*/lib/*.jar (có kotlin-compiler-embeddable, stdlib, coroutines…)
#   2. kotlin-compiler-*.zip đã tải lên, hoặc TẢI VỀ từ GitHub Releases nếu có mạng (cần github.com + release-assets.githubusercontent.com)
#   3. junit-4*.jar + hamcrest-core-*.jar đã tải lên, hoặc `apt-get download junit4 libhamcrest-java` nếu có mạng (cần archive.ubuntu.com)
# R37: cách 2 + 3 ĐÃ CHẠY THẬT (kotlin-compiler-1.9.24.zip từ GitHub Releases + junit4/libhamcrest-java từ archive.ubuntu.com) — cách 1 là cách đã dùng ở R19.
set -u
TC="${JVM_CHECK_TOOLCHAIN:-$HOME/.cache/jvm_check_toolchain}"
UP="${UPLOADS:-/mnt/user-data/uploads}"
KV="${KOTLIN_VERSION:-1.9.24}"
LIBD="$TC/lib"
mkdir -p "$LIBD" "$TC"
say() { echo "get_toolchain: $*" >&2; }
has_kotlin() { ls "$LIBD"/kotlin-compiler-embeddable-*.jar >/dev/null 2>&1; }
has_junit()  { ls "$LIBD"/junit-4*.jar >/dev/null 2>&1 && ls "$LIBD"/hamcrest-core-*.jar >/dev/null 2>&1; }

# 1. Gradle
if ! has_kotlin; then
  gz="$(ls "$UP"/gradle-*-bin.zip 2>/dev/null | sort -V | tail -1)"
  if [ -n "$gz" ]; then
    say "dùng $gz"
    tmp="$(mktemp -d)"
    if unzip -q -o "$gz" 'gradle-*/lib/*.jar' -d "$tmp" 2>/dev/null; then cp "$tmp"/gradle-*/lib/*.jar "$LIBD"/; fi
    rm -rf "$tmp"
  fi
fi

# 2. kotlin-compiler zip
if ! has_kotlin; then
  kz="$(ls "$UP"/kotlin-compiler-*.zip 2>/dev/null | sort -V | tail -1)"
  if [ -z "$kz" ]; then
    kz="$TC/kotlin-compiler-$KV.zip"
    say "tải kotlin-compiler-$KV.zip từ GitHub (cần mạng)"
    curl -fsSL --max-time 300 -o "$kz" "https://github.com/JetBrains/kotlin/releases/download/v$KV/kotlin-compiler-$KV.zip" 2>/dev/null || { rm -f "$kz"; kz=""; }
  fi
  if [ -n "$kz" ]; then
    say "dùng $kz"
    v="$(basename "$kz" | sed -E 's/^kotlin-compiler-([0-9][0-9.]*)\.zip$/\1/')"; [ -n "$v" ] || v="$KV"
    tmp="$(mktemp -d)"
    if unzip -q -o "$kz" -d "$tmp" 2>/dev/null && [ -f "$tmp/kotlinc/lib/kotlin-compiler.jar" ]; then
      L="$tmp/kotlinc/lib"
      cp "$L/kotlin-compiler.jar" "$LIBD/kotlin-compiler-embeddable-$v.jar"   # bản đầy đủ chứa K2JVMCompiler; kc.sh chỉ cần lớp này trong classpath
      for n in kotlin-stdlib kotlin-script-runtime kotlin-reflect; do [ -f "$L/$n.jar" ] && cp "$L/$n.jar" "$LIBD/$n-$v.jar"; done
      [ -f "$L/kotlin-daemon.jar" ] && cp "$L/kotlin-daemon.jar" "$LIBD/kotlin-daemon-embeddable-$v.jar"
      [ -f "$L/trove4j.jar" ] && cp "$L/trove4j.jar" "$LIBD/trove4j.jar"
      ls "$L"/annotations-*.jar >/dev/null 2>&1 && cp "$L"/annotations-*.jar "$LIBD"/
      [ -f "$L/kotlinx-coroutines-core-jvm.jar" ] && cp "$L/kotlinx-coroutines-core-jvm.jar" "$LIBD/kotlinx-coroutines-core-jvm-1.0.jar"
    fi
    rm -rf "$tmp"
  fi
fi

# 3. JUnit + Hamcrest
if ! has_junit; then
  j="$(ls "$UP"/junit-4*.jar 2>/dev/null | sort -V | tail -1)"; h="$(ls "$UP"/hamcrest-core-*.jar 2>/dev/null | sort -V | tail -1)"
  if [ -n "$j" ] && [ -n "$h" ]; then cp "$j" "$h" "$LIBD"/
  else
    say "thử apt-get download junit4 libhamcrest-java (cần mạng)"
    tmp="$(mktemp -d)"
    # R37: sandbox mới chưa có danh sách gói ⇒ `apt-get download` lần đầu báo lỗi; chạy `apt-get update` rồi thử lại (đã kiểm với mạng thật)
    ( cd "$tmp" && { apt-get download junit4 libhamcrest-java >/dev/null 2>&1 || { apt-get update >/dev/null 2>&1; apt-get download junit4 libhamcrest-java >/dev/null 2>&1; }; } && for d in *.deb; do dpkg -x "$d" x; done ) 2>/dev/null
    [ -f "$tmp/x/usr/share/java/junit4.jar" ] && cp -L "$tmp/x/usr/share/java/junit4.jar" "$LIBD/junit-4.13.2.jar"
    [ -f "$tmp/x/usr/share/java/hamcrest-core.jar" ] && cp -L "$tmp/x/usr/share/java/hamcrest-core.jar" "$LIBD/hamcrest-core-1.3.jar"
    rm -rf "$tmp"
  fi
fi

if has_kotlin && has_junit; then echo "$LIBD"; exit 0; fi
{
  echo "get_toolchain: CHƯA đủ bộ công cụ. Thiếu:$(has_kotlin || echo ' [trình biên dịch Kotlin]')$(has_junit || echo ' [JUnit + Hamcrest]')"
  echo "  Cách dễ nhất: mở một cuộc trò chuyện MỚI (sandbox ở đó có mạng) rồi chạy lại; hoặc tải các tệp sau và up vào $UP:"
  echo "    * Cách A (một tệp, đã dùng ở R19): https://services.gradle.org/distributions/gradle-8.14.3-bin.zip"
  echo "    * Cách B (nhẹ hơn, ba tệp): https://github.com/JetBrains/kotlin/releases/download/v$KV/kotlin-compiler-$KV.zip"
  echo "                                https://repo1.maven.org/maven2/junit/junit/4.13.2/junit-4.13.2.jar"
  echo "                                https://repo1.maven.org/maven2/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar"
} >&2
exit 1
