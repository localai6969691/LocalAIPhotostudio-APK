#!/bin/bash
# R38 - dựng ONNX Runtime Java API THẬT (cùng phiên bản app dùng) trong sandbox, từ GitHub: mã Java + JNI (git sparse-checkout) và libonnxruntime.so (release tgz).
# Kết quả:  $ORT_WORK/classes  (ai.onnxruntime.*)  và  $ORT_WORK/lib  (libonnxruntime.so + libonnxruntime4j_jni.so).  Cần: git, gcc, JDK (javac), mạng tới github.com.
# Dùng:  build_real_ort.sh [thư_mục_làm_việc=/tmp/ortwork]      (đã chạy được ở R38 với ORT 1.27.0, ~1 phút)
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
V="$(grep -o 'ortVersion *= *"[0-9.]*"' "$ROOT/app/build.gradle.kts" | head -1 | grep -o '[0-9][0-9.]*')"
W="${1:-/tmp/ortwork}"; mkdir -p "$W"; cd "$W"
JH="$(dirname "$(dirname "$(readlink -f "$(which javac)")")")"
echo "ORT $V -> $W (JDK $JH)"
[ -d src ] || { git clone --depth 1 --branch "v$V" --filter=blob:none --sparse https://github.com/microsoft/onnxruntime src >/dev/null 2>&1
  (cd src && git sparse-checkout set java include/onnxruntime/core/session include/onnxruntime/core/providers >/dev/null 2>&1); }
[ -d "bin/onnxruntime-linux-x64-$V" ] || { mkdir -p bin; curl -sL -o bin/ort.tgz "https://github.com/microsoft/onnxruntime/releases/download/v$V/onnxruntime-linux-x64-$V.tgz"; tar xzf bin/ort.tgz -C bin; }
ORT="$W/bin/onnxruntime-linux-x64-$V"
rm -rf classes h obj inc lib; mkdir -p classes h obj lib inc/onnxruntime/core/providers/cpu
# 1) Java (biến thể JVM) + tiêu đề JNI
javac -nowarn -h h -d classes $(find src/java/src/main/java src/java/src/main/jvm -name '*.java') 2>&1 | grep -v '^Note:' || true
# 2) JNI C: onnxruntime_config.h do CMake sinh (chỉ cần ORT_VERSION); bỏ phần training (cần header riêng)
echo "#define ORT_VERSION \"$V\"" > inc/onnxruntime_config.h
cp "$ORT/include/cpu_provider_factory.h" inc/onnxruntime/core/providers/cpu/
for f in src/java/src/main/native/*.c; do
  case "$f" in *Training*) continue;; esac
  gcc -c -fPIC -O2 -w -I"$JH/include" -I"$JH/include/linux" -I"$W/src/include" -I"$W/src/include/onnxruntime/core/session" -I"$W/h" -I"$W/inc" -I"$W/src/java/src/main/native" \
      -o "obj/$(basename "${f%.c}").o" "$f"
done
cp "$ORT/lib/libonnxruntime.so.$V" lib/; ln -sf "libonnxruntime.so.$V" lib/libonnxruntime.so; ln -sf "libonnxruntime.so.$V" lib/libonnxruntime.so.1
cp "$ORT/lib/libonnxruntime_providers_shared.so" lib/
gcc -shared -o lib/libonnxruntime4j_jni.so obj/*.o -Llib -lonnxruntime -Wl,-rpath,"$W/lib"
echo "xong: $(nm -D lib/libonnxruntime4j_jni.so | grep -c Java_ai_onnxruntime) hàm JNI; classes: $W/classes"
