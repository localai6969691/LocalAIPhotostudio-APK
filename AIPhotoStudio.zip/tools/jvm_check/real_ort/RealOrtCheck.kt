package com.aiphoto.studio.realort

import android.graphics.Bitmap
import com.aiphoto.studio.engine.DepthEstimator
import com.aiphoto.studio.engine.FaceLiquify3D
import com.aiphoto.studio.engine.LamaInpainter
import com.aiphoto.studio.engine.OnnxUpscaler
import com.aiphoto.studio.engine.ToneOps
import com.aiphoto.studio.engine.MiganInpainter
import com.aiphoto.studio.engine.OnnxSegmenter
import com.aiphoto.studio.engine.Pt
import com.aiphoto.studio.engine.SamSegmenter
import com.aiphoto.studio.engine.SegProfile
import java.io.File
import javax.imageio.ImageIO
import kotlin.system.exitProcess

/**
 * R38 - chạy CHÍNH các lớp engine Kotlin của ứng dụng (đã biên dịch bằng kotlinc thật) với ONNX Runtime Java API THẬT (1.27.0, dựng từ mã nguồn GitHub — xem build_real_ort.sh)
 * và trọng số THẬT, trong JVM của sandbox. Khác tools/real_model_check.py (Python chép lại công thức): ở đây là mã Kotlin của app, nên kiểm được cả việc stub ORT có khớp
 * chữ ký thật hay không (NoSuchMethodError nếu lệch) lẫn tiền / hậu xử lý thật của app. Bitmap vẫn là stub (mảng int ARGB).
 * Tham số dòng lệnh: ẢNH_CHÂN_DUNG THƯ_MỤC_MODEL
 */
private var failures = 0

private fun check(name: String, ok: Boolean, detail: String) {
    println((if (ok) "ĐẠT " else "HỎNG") + " | " + name + " | " + detail)
    if (!ok) failures++
}

fun loadBitmap(path: String): Bitmap {
    val im = ImageIO.read(File(path))
    val w = im.width
    val h = im.height
    val px = IntArray(w * h)
    im.getRGB(0, 0, w, h, px, 0, w)
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, w, 0, 0, w, h)
    return b
}

fun pixelsOf(b: Bitmap): IntArray {
    val px = IntArray(b.width * b.height)
    b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
    return px
}

private fun box(v: FloatArray, w: Int, h: Int, y0: Double, y1: Double, x0: Double, x1: Double): Double {
    var s = 0.0
    var n = 0
    for (y in (y0 * h).toInt() until (y1 * h).toInt()) for (x in (x0 * w).toInt() until (x1 * w).toInt()) { s += v[y * w + x]; n++ }
    return s / n
}

fun main(args: Array<String>) {
    val img = args[0]
    val md = args[1]
    val bmp = loadBitmap(img)
    val w = bmp.width
    val h = bmp.height
    println("ảnh ${w}x$h (ORT thật nạp từ classpath: " + ai.onnxruntime.OrtEnvironment::class.java.protectionDomain.codeSource?.location + ")")

    // 1) U²-Net-P và IS-Net qua OnnxSegmenter (Kotlin của app)
    for ((label, file, profile) in listOf(Triple("U²-Net-P", "u2netp.onnx", SegProfile.U2NET), Triple("IS-Net", "isnet-general-use.onnx", SegProfile.ISNET))) {
        val f = File(md, file)
        if (!f.exists()) { println("BỎ QUA $label (không có $file)"); continue }
        OnnxSegmenter(f.path, profile).use { seg ->
            val t = System.currentTimeMillis()
            val m = seg.foregroundMask(bmp)
            val fg = box(m, w, h, .15, .7, .3, .7)
            val bg = (box(m, w, h, 0.0, .15, 0.0, .12) + box(m, w, h, 0.0, .15, .88, 1.0)) / 2
            check("OnnxSegmenter $label", m.size == w * h && fg > bg + 0.3, "mặt nạ ${m.size} (= w*h ${w * h}), chủ thể %.2f nền %.2f, %d ms".format(fg, bg, System.currentTimeMillis() - t))
        }
    }

    // 2) Depth Anything V2 qua DepthEstimator
    File(md, "depth_anything_v2_vits.onnx").takeIf { it.exists() }?.let { f ->
        DepthEstimator(f.path).use { d ->
            val t = System.currentTimeMillis()
            val fld = d.estimate(bmp)
            val face = box(fld.v, fld.w, fld.h, .15, .55, .30, .70)
            val border = (box(fld.v, fld.w, fld.h, 0.0, .2, 0.0, .15) + box(fld.v, fld.w, fld.h, 0.0, .2, .85, 1.0)) / 2
            check("DepthEstimator Depth Anything V2", fld.v.size == fld.w * fld.h && face > border, "trường ${fld.w}x${fld.h}, giữa %.3f vs viền %.3f, %d ms".format(face, border, System.currentTimeMillis() - t))
        }
    }

    // 3) MobileSAM qua SamSegmenter: chạm một điểm vào chủ thể
    val enc = File(md, "mobilesam-encoder.onnx")
    val dec = File(md, "mobilesam-decoder.onnx")
    if (enc.exists() && dec.exists()) {
        SamSegmenter(enc.path, dec.path).use { sam ->
            val t = System.currentTimeMillis()
            val px = 0.5f
            val py = 0.9f
            val m = sam.select(bmp, listOf(Pt(px, py)))
            val inside = m != null && m[(py * h).toInt() * w + (px * w).toInt()].toInt() != 0
            val cover = if (m == null) 0.0 else m.count { it.toInt() != 0 }.toDouble() / m.size
            check("SamSegmenter MobileSAM", m != null && m.size == w * h && inside && cover in 0.2..0.9, "mặt nạ ${m?.size}, điểm chạm trong mặt nạ=$inside, phủ %.0f%%, %d ms".format(cover * 100, System.currentTimeMillis() - t))
        }
    }

    // 4) MI-GAN qua MiganInpainter: xóa một vòng tròn; chế độ chính xác phải giữ NGUYÊN từng bit ngoài mặt nạ
    File(md, "migan_pipeline_v2.onnx").takeIf { it.exists() }?.let { f ->
        MiganInpainter(f.path).use { mg ->
            val mask = ByteArray(w * h)
            val cx = (0.5 * w).toInt(); val cy = (0.62 * h).toInt(); val r = (0.06 * w).toInt()
            for (y in 0 until h) for (x in 0 until w) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) mask[y * w + x] = 1
            val src = pixelsOf(bmp)
            val t = System.currentTimeMillis()
            val out = mg.inpaintExact(bmp, mask)
            val res = pixelsOf(out)
            var diffOutside = 0
            var diffInside = 0L
            var nIn = 0
            for (i in 0 until w * h) {
                if (mask[i].toInt() == 0) { if (res[i] != src[i]) diffOutside++ }
                else {
                    nIn++
                    val a = src[i]; val b = res[i]
                    diffInside += Math.abs(((a shr 16) and 255) - ((b shr 16) and 255)) + Math.abs(((a shr 8) and 255) - ((b shr 8) and 255)) + Math.abs((a and 255) - (b and 255))
                }
            }
            val meanIn = diffInside / 3.0 / nIn
            check("MiganInpainter MI-GAN (inpaintExact)", out.width == w && out.height == h && diffOutside == 0 && meanIn > 5, "ngoài mặt nạ: $diffOutside điểm khác (phải 0), trong mặt nạ lệch TB %.1f, %d ms".format(meanIn, System.currentTimeMillis() - t))
        }
    }

    // 7) LaMa qua LamaInpainter bằng model ĐẠI DIỆN đúng hợp đồng đã công bố (lama_standin.onnx: tools/make_lama_standin_onnx.py) — kiểm tiền xử lý, chiều mặt nạ (1 = lấp), thang 0..255, ghép lại
    File(md, "lama_standin.onnx").takeIf { it.exists() }?.let { f ->
        LamaInpainter(f.path).use { lm ->
            val mask = ByteArray(w * h)
            val cx = (0.5 * w).toInt(); val cy = (0.62 * h).toInt(); val r = (0.06 * w).toInt()
            for (y in 0 until h) for (x in 0 until w) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) mask[y * w + x] = 1
            val src = pixelsOf(bmp)
            val out = lm.inpaintExact(bmp, mask)
            val res = pixelsOf(out)
            var outside = 0
            var gSum = 0.0; var gN = 0
            for (i in 0 until w * h) {
                if (mask[i].toInt() == 0) { if (res[i] != src[i]) outside++ }
                else {
                    val y = i / w; val x = i % w
                    if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= (r / 2) * (r / 2)) { gSum += ((res[i] shr 16) and 255) + ((res[i] shr 8) and 255) + (res[i] and 255); gN += 3 }
                }
            }
            val gMean = gSum / gN
            check("LamaInpainter (model đại diện)", out.width == w && out.height == h && outside == 0 && gMean in 120.0..135.0, "ngoài mặt nạ: $outside điểm khác (phải 0), giữa vùng lấp TB %.1f (phải ≈127,5)".format(gMean))
        }
    }

    // 5) Real-ESRGAN x4v3 qua OnnxUpscaler: cắt 512x512 -> thu 4x (trung bình vùng) -> phóng 4x bằng model -> so với bản gốc
    File(md, "realesr-general-x4v3.onnx").takeIf { it.exists() }?.let { f ->
        OnnxUpscaler(f.path).use { up ->
            val x0 = minOf(170, w - 512); val y0 = minOf(60, h - 512)
            val gt = IntArray(512 * 512)
            bmp.getPixels(gt, 0, 512, x0, y0, 512, 512)
            val lr = IntArray(128 * 128)
            for (y in 0 until 128) for (x in 0 until 128) {
                var r = 0; var g = 0; var b = 0
                for (dy in 0 until 4) for (dx in 0 until 4) { val p = gt[(y * 4 + dy) * 512 + x * 4 + dx]; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255 }
                lr[y * 128 + x] = (255 shl 24) or ((r / 16) shl 16) or ((g / 16) shl 8) or (b / 16)
            }
            val src = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
            src.setPixels(lr, 0, 128, 0, 0, 128, 128)
            val t = System.currentTimeMillis()
            val out = up.upscale(src, 4)
            val res = pixelsOf(out)
            var se = 0.0
            if (out.width == 512 && out.height == 512) for (i in 0 until 512 * 512) for (sh in intArrayOf(16, 8, 0)) { val d = ((res[i] shr sh) and 255) - ((gt[i] shr sh) and 255); se += d * d }
            val psnr = 10 * Math.log10(255.0 * 255.0 / (se / (512.0 * 512 * 3)))
            check("OnnxUpscaler Real-ESRGAN x4v3", out.width == 512 && out.height == 512 && psnr > 24.0, "ra ${out.width}x${out.height}, PSNR so với ảnh gốc %.2f dB (bản Python cùng trọng số: 26,5 dB), %d ms".format(psnr, System.currentTimeMillis() - t))
        }
    }

    // 6) Liquify 3D đầu-cuối bằng mã Kotlin thật: lưới 478 điểm thật (model thật, ảnh Obama) -> FaceLiquify3D.args -> ToneOps.liquify; so với bản Python (cv2.remap)
    File("/tmp/real/obama_mesh.txt").takeIf { it.exists() && File("/tmp/real/obama_py_liquify.png").exists() }?.let { mf ->
        val lm = mf.readText().trim().split(' ').map { it.toFloat() }.toFloatArray()
        val par = FaceLiquify3D.ShapeParams(slim = 0.8f, eyes = 0.7f, nose = 0.6f, smile = 0.5f, chin = 0.4f, balance = 1.0f)
        val arg = FaceLiquify3D.args(lm, w, h, par)
        val t = System.currentTimeMillis()
        val out = ToneOps.liquify(bmp, arg)
        val k = pixelsOf(out)
        val py = pixelsOf(loadBitmap("/tmp/real/obama_py_liquify.png"))
        val orig = pixelsOf(bmp)
        var sum = 0L; var mx = 0; var changed = 0L; var n = 0L
        for (i in 0 until w * h) for (sh in intArrayOf(16, 8, 0)) {
            val d = Math.abs(((k[i] shr sh) and 255) - ((py[i] shr sh) and 255)); sum += d; if (d > mx) mx = d
            val c = Math.abs(((k[i] shr sh) and 255) - ((orig[i] shr sh) and 255)); changed += c; n++
        }
        val meanDiff = sum.toDouble() / n
        val meanChange = changed.toDouble() / n
        val pyArg = File("/tmp/real/obama_py_arg.txt").readText().trim()
        check("Liquify 3D Kotlin (args + ToneOps.liquify) so với Python", arg.isNotBlank() && meanDiff < 1.0 && meanChange > 0.3,
            "${arg.split(';').size} đoạn (Python ${pyArg.split(';').size}), lệch TB Kotlin-Python %.3f mức xám (lớn nhất %d), thay đổi so với ảnh gốc TB %.2f, %d ms".format(meanDiff, mx, meanChange, System.currentTimeMillis() - t))
        val im = java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_RGB)
        im.setRGB(0, 0, w, h, k, 0, w)
        ImageIO.write(im, "png", File("/tmp/real/obama_kotlin_liquify.png"))
    }
    println(if (failures == 0) "TẤT CẢ ĐẠT" else "$failures MỤC HỎNG")
    exitProcess(if (failures == 0) 0 else 1)
}
