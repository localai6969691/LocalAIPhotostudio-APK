#!/usr/bin/env bash
# R48 - dựng lớp Java + JNI của ONNX Runtime THẬT khi kho microsoft/onnxruntime không tải được (sandbox: GitHub trả 404 ở R46, R48).
# Nguồn thay thế (đều trong danh sách host mở của sandbox):
#   - mã Java/JNI + header v1.22.0 từ kho fork github.com/ROCm/onnxruntime (codeload.github.com);
#   - thư viện native libonnxruntime.so từ gói PyPI `onnxruntime` (pip install onnxruntime; wheel Linux có kèm libonnxruntime.so.<ver>).
# API C của ORT tương thích ngược: JNI dựng với header 1.22 chạy được với lib mới hơn (R48: lib 1.31.0). Đây KHÔNG phải đúng bản 1.27.0 của app.
# Dùng:  bash tools/jvm_check/real_ort/build_real_ort_alt.sh [thư mục ra, mặc định /tmp/ortwork]
#        ORT_TGZ=/đường/dẫn/rocm.tgz  -> dùng lại tệp đã tải (241 MB). Cần: JDK (javac), gcc, python3 có onnxruntime, curl, tar.
# Kết quả: <ra>/classes (lớp Java), <ra>/lib (libonnxruntime*.so + libonnxruntime4j_jni.so) - dùng như build_real_ort.sh.
set -euo pipefail
OUT="${1:-/tmp/ortwork}"; V=1.22.0
mkdir -p "$OUT/src"; cd "$OUT"
TGZ="${ORT_TGZ:-$OUT/rocm.tgz}"
if [ ! -s "$TGZ" ]; then curl -fsSL --retry 3 -o "$TGZ" "https://codeload.github.com/ROCm/onnxruntime/tar.gz/refs/tags/v$V"; fi
tar xzf "$TGZ" -C src --strip-components=1 --wildcards "onnxruntime-$V/java/*" "onnxruntime-$V/include/onnxruntime/core/session/*" "onnxruntime-$V/include/onnxruntime/core/providers/*"
JH="$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")"
rm -rf classes h obj inc lib; mkdir -p classes h obj lib inc/onnxruntime/core/providers/cpu
javac -nowarn -h h -d classes $(find src/java/src/main/java src/java/src/main/jvm -name '*.java') 2>&1 | grep -v '^Note:' || true
echo "#define ORT_VERSION \"$V\"" > inc/onnxruntime_config.h
cp src/include/onnxruntime/core/providers/cpu/cpu_provider_factory.h inc/onnxruntime/core/providers/cpu/
for f in src/java/src/main/native/*.c; do
  case "$f" in *Training*) continue;; esac
  gcc -c -fPIC -O2 -w -I"$JH/include" -I"$JH/include/linux" -I"$OUT/src/include" -I"$OUT/src/include/onnxruntime/core/session" -I"$OUT/h" -I"$OUT/inc" -I"$OUT/src/java/src/main/native" -o "obj/$(basename "${f%.c}").o" "$f"
done
CAPI="$(python3 -c 'import onnxruntime,os;print(os.path.join(os.path.dirname(onnxruntime.__file__),"capi"))')"
SO="$(ls "$CAPI"/libonnxruntime.so.* | head -n1)"
cp "$SO" lib/; B="$(basename "$SO")"
ln -sf "$B" lib/libonnxruntime.so; ln -sf "$B" lib/libonnxruntime.so.1
[ -f "$CAPI/libonnxruntime_providers_shared.so" ] && cp "$CAPI/libonnxruntime_providers_shared.so" lib/
gcc -shared -o lib/libonnxruntime4j_jni.so obj/*.o -Llib -lonnxruntime -Wl,-rpath,"$OUT/lib"
echo "build_real_ort_alt: $(find classes -name '*.class' | wc -l) lớp Java, $(nm -D lib/libonnxruntime4j_jni.so | grep -c Java_ai_onnxruntime) hàm JNI, lib $B (header/JNI $V)"
