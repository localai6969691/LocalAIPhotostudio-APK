// R46 - phép kiểm OnnxUpscaler (tiến độ, hủy, chạy lại, trần thấp) với ONNX Runtime THẬT và model Real-ESRGAN thật.
// R48: ĐÃ CHẠY - đạt 7/7 (Java/JNI 1.22.0 từ kho fork ROCm + libonnxruntime 1.31.0 từ wheel PyPI, CPU sandbox; chưa phải ORT 1.27.0 Android / máy thật).
// Cách chạy (kho microsoft/onnxruntime tải được thì dùng build_real_ort.sh thay build_real_ort_alt.sh):
//   bash tools/jvm_check/real_ort/build_real_ort_alt.sh /tmp/ortwork
//   REAL_ORT_CLASSES=/tmp/ortwork/classes bash tools/jvm_check/build.sh realort
//   (biên dịch tệp này bằng tools/jvm_check/kc.sh với classpath classes_realort + stubs_realort + /tmp/ortwork/classes, rồi chạy với đối số:
//    app/src/main/assets/models/realesr-general-x4v3.onnx  <ảnh 512x512.jpg>  - thêm -Donnxruntime.native.path=/tmp/ortwork/lib -Djava.library.path=/tmp/ortwork/lib
//    và -Dfile.encoding=UTF-8 để tiếng Việt không bị ?? trên màn hình)
package com.aiphoto.studio.realup

import android.graphics.Bitmap
import com.aiphoto.studio.engine.OnnxUpscaler
import com.aiphoto.studio.engine.Upscale
import com.aiphoto.studio.engine.UpscaleCancelled
import java.io.File
import javax.imageio.ImageIO
import kotlin.system.exitProcess

private var failures = 0
private fun check(name: String, ok: Boolean, detail: String) {
    println((if (ok) "ĐẠT " else "HỎNG") + " | " + name + " | " + detail)
    if (!ok) failures++
}

private fun load(path: String): Bitmap {
    val im = ImageIO.read(File(path))
    val px = IntArray(im.width * im.height)
    im.getRGB(0, 0, im.width, im.height, px, 0, im.width)
    val b = Bitmap.createBitmap(im.width, im.height, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, im.width, 0, 0, im.width, im.height)
    return b
}

fun main(args: Array<String>) {
    val model = args[0]
    val img = load(args[1])
    println("ảnh ${img.width}x${img.height}")
    OnnxUpscaler(model).use { up ->
        // 1) ×2 trên ảnh 512x512: số lần báo tiến độ phải đúng bằng số ô mà Upscale.tileCount dự đoán
        val calls = ArrayList<Pair<Int, Int>>()
        val t0 = System.currentTimeMillis()
        val out = up.upscale(img, 2, 4096, onProgress = { d, t -> calls.add(d to t) })
        val dt = System.currentTimeMillis() - t0
        val expectTiles = Upscale.tileCount(img.width, img.height, 2f)
        check("kích thước ra ×2", out.width == img.width * 2 && out.height == img.height * 2, "${out.width}x${out.height}")
        check("tiến độ: số lần báo = số ô dự đoán", calls.size == expectTiles && calls.last() == (expectTiles to expectTiles), "báo ${calls.size} lần, dự đoán $expectTiles ô, ${dt} ms")
        check("tiến độ đơn điệu 1..N", calls.map { it.first } == (1..calls.size).toList(), "đầu ${calls.first()} cuối ${calls.last()}")
        val eta = Upscale.etaSeconds(1, calls.size, dt / calls.size)
        check("ETA sau ô đầu hợp lý (0..dt)", eta in 0..(dt / 1000 + 1).toInt(), "ETA ${eta}s, tổng ${dt / 1000.0}s")

        // 2) Hủy giữa chừng: ném UpscaleCancelled, không trả ảnh dở
        var cancelledAfter = -1
        var done = 0
        val threw = try {
            up.upscale(img, 2, 4096, onProgress = { d, _ -> done = d }, isCancelled = { done >= 3 })
            false
        } catch (e: UpscaleCancelled) {
            cancelledAfter = done
            true
        }
        check("Hủy: ném UpscaleCancelled sau ô thứ 3", threw && cancelledAfter == 3, "đã xong $cancelledAfter ô")

        // 3) sau khi hủy vẫn chạy lại được bình thường (phiên ORT không hỏng)
        val again = up.upscale(img, 2, 4096)
        check("chạy lại sau khi hủy", again.width == img.width * 2, "${again.width}x${again.height}")

        // 4) hệ số 1,1 (< MIN_FACTOR) trả nguyên ảnh — đúng với Upscale.canRun=false
        val same = up.upscale(img, 2, (img.width * 1.1f).toInt())
        check("trần thấp ⇒ trả nguyên ảnh", same.width == img.width && same.height == img.height, "${same.width}x${same.height}")
    }
    println(if (failures == 0) "RealUpscaleCheck: TẤT CẢ ĐẠT" else "RealUpscaleCheck: $failures LỖI")
    exitProcess(if (failures == 0) 0 else 1)
}
