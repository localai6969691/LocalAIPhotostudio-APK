#!/bin/bash
# R38 - CHẠY chính các lớp engine Kotlin của app (OnnxSegmenter, DepthEstimator, SamSegmenter, MiganInpainter, LamaInpainter, OnnxUpscaler, FaceLiquify3D + ToneOps.liquify)
# với ONNX Runtime Java API THẬT và model THẬT, trong JVM của sandbox.
# Chuẩn bị (một lần): (1) tools/jvm_check/get_toolchain.sh + JDK;  (2) tools/jvm_check/real_ort/build_real_ort.sh;  (3) tải model vào $MODELS (xem tools/real_model_check.py, tools/export_realesrgan_onnx.py,
#   tools/make_lama_standin_onnx.py);  (4) /tmp/real/obama_mesh.txt + obama_py_liquify.png (tools/real_face_check.py sinh — tùy chọn, bỏ qua mục Liquify nếu thiếu).
# Dùng:  run_real_ort.sh ẢNH_CHÂN_DUNG.jpg [MODELS=/tmp/models] [ORT_WORK=/tmp/ortwork]
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"; JC="$ROOT/tools/jvm_check"; source "$JC/env.sh"
IMG="$1"; MODELS="${2:-/tmp/models}"; W="${3:-/tmp/ortwork}"
export REAL_ORT_CLASSES="$W/classes"
[ -d "$OUT/classes_realort" ] || "$JC/build.sh" realort          # biên dịch CẢ APP với ORT thật (bắt lệch chữ ký stub/thật)
rm -rf /tmp/realort_out; "$JC/kc.sh" /tmp/realort_out "$OUT/classes_realort:$OUT/stubs_realort:$W/classes" "$JC/real_ort/RealOrtCheck.kt" 2>&1 | grep ' error: ' && exit 1
LIB="$HOME/.cache/jvm_check_toolchain/lib"
exec java -Xmx2500m -Donnxruntime.native.path="$W/lib" -Djava.library.path="$W/lib" \
  -cp "/tmp/realort_out:$OUT/classes_realort:$OUT/stubs_realort:$W/classes:$LIB/kotlin-stdlib-1.9.24.jar:$LIB/kotlinx-coroutines-core-jvm-1.0.jar" \
  com.aiphoto.studio.realort.RealOrtCheckKt "$IMG" "$MODELS"
