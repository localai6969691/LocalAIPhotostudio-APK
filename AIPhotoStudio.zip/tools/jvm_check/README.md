# tools/jvm_check — biên dịch Kotlin THẬT và chạy JUnit mà không cần Android SDK / mạng

**Vì sao có thư mục này.** Suốt nhiều phiên mã Android chưa từng qua compiler vì "môi trường không có Gradle/SDK/Maven". Nhưng thư mục `lib/` của
**bản phân phối Gradle** đã chứa sẵn `kotlin-compiler-embeddable`, `kotlin-stdlib`, `kotlinx-coroutines-core-jvm`, JUnit 4 và hamcrest. Chỉ cần
thay những thứ thuộc nền tảng (Android SDK, Compose, ONNX Runtime, MediaPipe, Play Billing, LiteRT-LM) bằng **stub** viết tay là biên dịch được toàn bộ dự án
và chạy được mọi bài test thuần JVM.

## Dùng
```
tools/jvm_check/run_all.sh          # tất cả: biên dịch 2 biến thể + JUnit + static_check + backend + bản port Python (~3 phút)
tools/jvm_check/build.sh            # biên dịch biến thể mặc định (billingStub + litertlmStub) + test
tools/jvm_check/build.sh billing litertlm   # biến thể -PuseBilling=true -PuseLiteRtLm=true (billingReal + litertlmReal)
tools/jvm_check/runtests.sh [com.aiphoto.studio.R19Test ...]   # mặc định chạy mọi lớp có @Test trong app/src/test
```
Cần `gradle` trong `PATH` (hoặc `GRADLE_LIB=<thư mục gradle>/lib`) và `java` 17+. Sản phẩm biên dịch nằm ở `build/jvm_check/` (đã nằm trong `.gitignore`).
Chế độ ngôn ngữ mặc định `-language-version 1.9 -api-version 1.9` (dự án dùng Kotlin 1.9.24; compiler đi kèm là 2.0.x) — đổi bằng `KLANG`, `KAPI`.

## Kiểm được gì — và KHÔNG kiểm được gì (đọc kỹ)
| Kiểm được | Không kiểm được |
|---|---|
| Cú pháp, tên chưa định nghĩa (`Unresolved reference`), sai kiểu, `when` thiếu nhánh, thiếu `override`, import thiếu — trên **toàn bộ** mã kể cả giao diện | Chữ ký THẬT của Compose / Material3 / androidx / ORT / MediaPipe / Billing / LiteRT-LM: compiler chỉ kiểm với stub do mình viết (từ tài liệu), nên lệch với thư viện thật là không thấy |
| Mọi `@Test` thuần JVM chạy thật (số học ảnh, planner, backend client, routing, mặt nạ, lưới, phiên…) | Plugin Compose compiler (lỗi ngữ cảnh `@Composable`, quy tắc ổn định), AGP, R8, tài nguyên Android, manifest |
| Biến thể build Billing và LiteRT-LM (với stub của chúng) | Mọi thứ dùng `Bitmap`/`Canvas` THẬT của Android: từ R20 stub `Bitmap` lưu điểm ảnh, `ColorMatrix`/`ColorMatrixColorFilter`/`Paint.setColorFilter`/`Canvas.drawBitmap(bitmap, left, top, paint)` có hành vi theo tài liệu Android (nên `ImageEngine.process` chạy được, xem `R20EngineTest`) — nhưng không premultiply, không giải mã/mã hóa ảnh, không `Matrix`/hình học (các lệnh đó **ném lỗi** thay vì im lặng trả ảnh trống) |

Vì vậy kết quả "0 lỗi" ở đây **không thay** cho build thật trên Actions (P0-1) — nó chỉ loại trước phần lớn lỗi vặt.

## Thêm / sửa stub
- Compiler báo `Unresolved reference: X` ở mã dự án với một API nền tảng ⇒ thêm chữ ký tối thiểu vào `stubs/java/...` (Java, ưu tiên — ít vướng quy tắc Kotlin) hoặc
  `stubs/kotlin/...` (khi cần hàm cấp cao/`inline`/tham số mặc định/`@Composable`). **Chép chữ ký từ tài liệu chính thức**, không tự chế để cho vừa mã dự án.
- Đừng sửa mã dự án cho vừa stub; nếu stub sai so với thư viện thật thì sửa stub.
- Stub MediaPipe `ObjectDetector`/`ObjectDetectorResult`/`Detection`/`Category` (R21) chỉ có CHỮ KÝ chép từ mã nguồn MediaPipe trên GitHub — compile được `PersonDetectorEngine`, nhưng không chạy được model; phần logic (`StrangerMask`) được test độc lập bằng hộp/mặt tổng hợp.
- Stub `org.json` là bản chạy được theo ngữ nghĩa Android (`opt*` trả mặc định, số nguyên/thực), vì test dùng thật để mã hóa/giải mã phiên và công thức.

## Đột biến nhanh cho một tệp `engine/` (R23)
Biên dịch cả bộ ~100 giây/lần là quá chậm để thử hàng chục đột biến. Cách nhanh (~10 giây/lần): sau một lần `build.sh`, biên dịch **chỉ vài tệp cùng module** (tệp đang đột biến + các tệp mà test dùng, ví dụ `Monetization.kt` + `ProxyBackend.kt` + `TeamInfo.kt` + test) vào một thư mục riêng với `classes_default:stubs_default` làm classpath, rồi chạy JUnit với thư mục đó đứng TRƯỚC `classes_default`. Phải biên dịch cùng lúc các tệp có hàm `internal` mà test gọi (nếu không: "cannot access ... internal"). Luôn sao lưu tệp trước và khôi phục sau (`cp`), rồi `cmp` để chắc chắn.

## Đột biến an toàn (R24) — đừng để tệp nguồn thật ở lại trạng thái đã đột biến
Hai lần trong R24 tập lệnh đột biến bị giết giữa chừng (hết thời gian lệnh nền) và để `Panels.kt`/`AutoFrameIntent.kt` ở trạng thái đã sửa — suýt vào zip giao. Quy tắc: (1) lưu bản `.good` của MỌI tệp sắp đột biến trước khi chạy; (2) tập lệnh đặt `trap 'restore_all' EXIT` và `trap 'restore_all; exit 143' TERM INT`; (3) mỗi đợt < 2 phút (chia nhóm đột biến); (4) sau đợt, `cmp tệp_thật tệp.good` rồi mới làm việc tiếp; (5) báo mỗi kiểu là BẮT ĐƯỢC / SỐNG SÓT / LỖI BIÊN DỊCH — lỗi biên dịch không phải "bắt được". Với tệp trong `util/` (như `Diagnostics.kt`) không có phụ thuộc `internal`, biên dịch riêng tệp + test là đủ (~15 giây/kiểu).
