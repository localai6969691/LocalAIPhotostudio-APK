# Nạp biến môi trường chung cho các script jvm_check (được `source`, không chạy riêng).
# JC = thư mục này; P = gốc dự án; OUT = nơi đặt sản phẩm biên dịch (mặc định build/jvm_check, đã nằm ngoài mã nguồn)
JC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
P="$(cd "$JC/../.." && pwd)"
OUT="${JVM_CHECK_OUT:-$P/build/jvm_check}"
mkdir -p "$OUT"
unset JAVA_TOOL_OPTIONS
# Thư mục lib của Gradle (chứa kotlin-compiler-embeddable, kotlin-stdlib, kotlinx-coroutines-core-jvm, junit, hamcrest). Đặt GRADLE_LIB để chỉ định tay.
if [ -z "${GRADLE_LIB:-}" ]; then
  gbin="$(command -v gradle || true)"
  [ -n "$gbin" ] && GRADLE_LIB="$(dirname "$(dirname "$(readlink -f "$gbin")")")/lib"
fi
if ! ls "${GRADLE_LIB:-/nonexistent}"/kotlin-compiler-embeddable-*.jar >/dev/null 2>&1; then
  echo "jvm_check: không tìm thấy kotlin-compiler-embeddable trong GRADLE_LIB='${GRADLE_LIB:-}' (cần Gradle 8.x đã cài; đặt GRADLE_LIB=<thư mục gradle>/lib)" >&2
  return 1 2>/dev/null || exit 1
fi
KC_JAR="$(ls "$GRADLE_LIB"/kotlin-compiler-embeddable-*.jar | head -1)"
KVER="$(basename "$KC_JAR" .jar | sed 's/kotlin-compiler-embeddable-//')"
export JC P OUT GRADLE_LIB KC_JAR KVER
