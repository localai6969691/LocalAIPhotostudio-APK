#!/bin/bash
# Chạy JUnit 4 các bài test JVM (mọi lớp có @Test trong app/src/test) trên bản biên dịch của build.sh (biến thể mặc định).
# Dùng: runtests.sh [TênLớpĐầyĐủ ...]
source "$(dirname "${BASH_SOURCE[0]}")/env.sh" || exit 1
TAG="${JVM_CHECK_TAG:-default}"
G="$GRADLE_LIB"
CP="$OUT/classes_$TAG:$OUT/stubs_$TAG:$G/kotlin-stdlib-$KVER.jar:$(ls "$G"/kotlinx-coroutines-core-jvm-*.jar | head -1):$(ls "$G"/junit-4*.jar | head -1):$(ls "$G"/hamcrest-core-*.jar | head -1)"
if [ $# -gt 0 ]; then CLASSES="$*"; else
  CLASSES=$(cd "$P/app/src/test/java" && grep -rl "@Test" --include=*.kt . | sort | while read -r f; do
    pkg=$(grep -m1 '^package ' "$f" | sed 's/package //'); echo "$pkg.$(basename "$f" .kt)"; done | tr '\n' ' ')
fi
java -Xmx2g -cp "$CP" org.junit.runner.JUnitCore $CLASSES 2>&1
