#!/bin/bash
# Usage: kc.sh <outdir> <classpath-extra> <sources...>  — chạy trình biên dịch Kotlin đi kèm Gradle (K2JVMCompiler).
# Chế độ ngôn ngữ mặc định 1.9 (khớp Kotlin 1.9.24 của dự án); đổi bằng KLANG / KAPI.
source "$(dirname "${BASH_SOURCE[0]}")/env.sh" || exit 1
G="$GRADLE_LIB"
CP="$KC_JAR:$G/kotlin-stdlib-$KVER.jar:$G/kotlin-script-runtime-$KVER.jar:$G/kotlin-reflect-$KVER.jar:$G/kotlin-daemon-embeddable-$KVER.jar:$(ls "$G"/trove4j*.jar "$G"/annotations-*.jar "$G"/kotlinx-coroutines-core-jvm-*.jar 2>/dev/null | tr '\n' ':')"
OUTDIR=$1; EXTRA=$2; shift 2
mkdir -p "$OUTDIR"
exec java -Xmx2g -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
  -no-stdlib -no-reflect -nowarn \
  -language-version "${KLANG:-1.9}" -api-version "${KAPI:-1.9}" -jvm-target 17 \
  -cp "$G/kotlin-stdlib-$KVER.jar:$(ls "$G"/kotlinx-coroutines-core-jvm-*.jar | head -1):$(ls "$G"/junit-4*.jar | head -1):$(ls "$G"/hamcrest-core-*.jar | head -1)${EXTRA:+:$EXTRA}" \
  -d "$OUTDIR" "$@"
