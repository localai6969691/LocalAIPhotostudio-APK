#!/bin/bash
# R41: biên dịch TOÀN BỘ dự án với AAR THẬT của Play Billing / Play Integrity / LiteRT-LM (thay stub) — phép kiểm nhanh (~vài phút, không cần Gradle/Android SDK),
# báo sớm lỗi chữ ký thật trước khi chờ cả lượt Build APK. Cần mạng tới dl.google.com + repo1.maven.org (GitHub Actions có; sandbox của Claude KHÔNG).
# REAL_AAR_SKIP_FETCH=1: dùng sẵn $REAL_AAR_OUT/jars/*.jar (để thử logic offline). Thoát: 0 = đạt; 1 = lỗi biên dịch với thư viện thật; 3 = không lấy được thư viện nào.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; JC="$(dirname "$HERE")"
export REAL_AAR_OUT="${REAL_AAR_OUT:-/tmp/real_aars}"
[ "${REAL_AAR_SKIP_FETCH:-}" = 1 ] || bash "$HERE/fetch_real_aars.sh"
for n in billing integrity litertlm; do [ -f "$REAL_AAR_OUT/jars/$n.jar" ] && V="$V real$n"; done
V="${V# }"; V="${V/reallitertlm/reallitertlm}"
export REAL_BILLING_JAR="$REAL_AAR_OUT/jars/billing.jar" REAL_INTEGRITY_JAR="$REAL_AAR_OUT/jars/integrity.jar" REAL_LITERTLM_JAR="$REAL_AAR_OUT/jars/litertlm.jar"
G="$(source "$JC/env.sh" >/dev/null 2>&1; echo "$GRADLE_LIB")"
GSON="$REAL_AAR_OUT/jars/gson.jar"; [ -f "$GSON" ] || GSON="$(ls /usr/share/java/gson*.jar 2>/dev/null | head -1)"; [ -n "$GSON" ] && export REAL_LITERTLM_EXTRA_CP="$GSON:$G/kotlin-reflect-$(source "$JC/env.sh" >/dev/null 2>&1; echo "$KVER").jar"
[ -n "$V" ] || { echo "Không lấy được AAR nào ⇒ không có gì để kiểm (mã 3)"; exit 3; }
echo "Biên dịch với thư viện THẬT: $V"
bash "$JC/build.sh" $V; rc=$?
[ $rc = 0 ] && echo "AAR THẬT: biên dịch đạt ($V). Phiên bản: $(tr '\n' ' ' < "$REAL_AAR_OUT/versions.txt" 2>/dev/null)" || echo "AAR THẬT: LỖI biên dịch ($V) — xem dòng ' error: ' ở trên"
exit $rc
