#!/usr/bin/env python3
"""R41: in phiên bản Kotlin metadata (`mv`) của các lớp Kotlin trong một JAR — để biết trước nguy cơ "incompatible version of Kotlin metadata"
(trình biên dịch Kotlin 1.9.24 của dự án chỉ đọc được metadata tới ~2.0). Cách dùng: kotlin_mv.py <jar> [tiền_tố_gói]. Không cần javap."""
import struct, sys, zipfile, collections

def u2(d, p): return struct.unpack('>H', d[p:p+2])[0]
def u4(d, p): return struct.unpack('>I', d[p:p+4])[0]

def class_mv(d):
    if d[:4] != b'\xca\xfe\xba\xbe': return None
    n = u2(d, 8); p = 10; cp = [None]*n; i = 1
    while i < n:
        t = d[p]; p += 1
        if t == 1: l = u2(d, p); cp[i] = ('u', d[p+2:p+2+l].decode('utf-8', 'replace')); p += 2 + l
        elif t == 3: cp[i] = ('i', struct.unpack('>i', d[p:p+4])[0]); p += 4
        elif t == 4: p += 4
        elif t in (5, 6): p += 8; i += 1
        elif t in (7, 8, 16, 19, 20): p += 2
        elif t in (9, 10, 11, 12, 17, 18): p += 4
        elif t == 15: p += 3
        else: return None
        i += 1
    p += 6; p += 2 + 2*u2(d, p)
    def skip(p):
        c = u2(d, p); p += 2
        for _ in range(c):
            p += 6; ac = u2(d, p); p += 2
            for _ in range(ac): p += 6 + u4(d, p+2)
        return p
    p = skip(p); p = skip(p)
    def ev(b, q):                                   # element_value -> (giá trị, vị trí mới)
        tag = chr(b[q]); q += 1
        if tag in 'BCDFIJSZs': return ((cp[u2(b, q)] or (None, None))[1], q + 2) if tag == 'I' else (None, q + 2)
        if tag == 'e': return (None, q + 4)
        if tag == 'c': return (None, q + 2)
        if tag == '@': return ann(b, q)[1:]
        if tag == '[':
            c = u2(b, q); q += 2; out = []
            for _ in range(c): v, q = ev(b, q); out.append(v)
            return (out, q)
        return (None, q)
    def ann(b, q):
        ti = u2(b, q); q += 2; ne = u2(b, q); q += 2; vals = {}
        for _ in range(ne):
            nm = cp[u2(b, q)][1]; q += 2; v, q = ev(b, q); vals[nm] = v
        return (cp[ti][1], vals, q)
    na = u2(d, p); p += 2
    for _ in range(na):
        name = cp[u2(d, p)]; ln = u4(d, p+2); body = d[p+6:p+6+ln]; p += 6 + ln
        if name == ('u', 'RuntimeVisibleAnnotations'):
            q = 2
            for _ in range(u2(body, 0)):
                t, vals, q = ann(body, q)
                if t == 'Lkotlin/Metadata;': return vals.get('mv')
    return None

if __name__ == '__main__':
    jar = sys.argv[1]; pref = (sys.argv[2] if len(sys.argv) > 2 else '').replace('.', '/')
    cnt = collections.Counter(); total = 0
    with zipfile.ZipFile(jar) as z:
        for n in z.namelist():
            if n.endswith('.class') and n.startswith(pref):
                total += 1
                mv = class_mv(z.read(n))
                if mv: cnt['.'.join(map(str, mv))] += 1
    print(f"{jar}: {total} lớp; lớp Kotlin theo mv = {dict(cnt) or 'không có (Java thuần)'}")
