#!/bin/bash
# R41: tải AAR THẬT -> classes.jar. Sandbox của Claude chặn Maven nên bước này chỉ chạy được ở nơi có mạng (GitHub Actions, máy bạn).
# Biến: BILLING_VERSION (mặc định 8.3.0) INTEGRITY_VERSION (1.6.0) LITERTLM_VERSION (rỗng = bản mới nhất theo maven-metadata.xml) REAL_AAR_OUT (/tmp/real_aars)
# Kết quả: $OUT/jars/{billing,integrity,litertlm}.jar và $OUT/paths.env (export REAL_*_JAR). Mỗi thư viện lỗi tải thì bỏ qua, không dừng cả bước.
OUT="${REAL_AAR_OUT:-/tmp/real_aars}"; mkdir -p "$OUT/jars"; : > "$OUT/paths.env"
GM=https://dl.google.com/dl/android/maven2; MC=https://repo1.maven.org/maven2
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
latest() { curl -fsSL --retry 2 --max-time 60 "$1/maven-metadata.xml" 2>/dev/null | python3 -c "
import sys,re;x=sys.stdin.read();r=re.search(r'<release>([^<]+)</release>',x);v=re.findall(r'<version>([^<]+)</version>',x)
print(r.group(1) if r else (v[-1] if v else ''))"; }
# fetch <tên> <biến-env-jar> <phiên-bản|''> <đường dẫn nhóm/artifact> <repo...>
fetch() {
  local name=$1 var=$2 ver=$3 ga=$4; shift 4; local repo v f
  for repo in "$@"; do
    v="$ver"; [ -n "$v" ] || v=$(latest "$repo/$ga"); [ -n "$v" ] || continue
    f="$OUT/$name-$v.aar"
    curl -fsSL --retry 2 --max-time 180 -o "$f" "$repo/$ga/$v/$(basename "$ga")-$v.aar" 2>/dev/null || { rm -f "$f"; continue; }
    (cd "$OUT" && rm -rf "x_$name" && mkdir "x_$name" && cd "x_$name" && unzip -q -o "$f" 'classes.jar' 'jni/*' 2>/dev/null)
    [ -f "$OUT/x_$name/classes.jar" ] || { echo "  $name $v: AAR không có classes.jar"; continue; }
    cp "$OUT/x_$name/classes.jar" "$OUT/jars/$name.jar"
    echo "export $var=$OUT/jars/$name.jar" >> "$OUT/paths.env"
    echo "OK  $name $v  ($repo)  $(stat -c %s "$f") byte; ABI native: $(ls "$OUT/x_$name/jni" 2>/dev/null | tr '\n' ' ' | sed 's/ $//' || true)"
    python3 "$HERE/kotlin_mv.py" "$OUT/jars/$name.jar" | sed 's/^/    /'
    echo "$name=$v" >> "$OUT/versions.txt"; return 0
  done
  echo "KHÔNG tải được $name (phiên bản '${ver:-mới nhất}') từ: $*"; return 1
}
: > "$OUT/versions.txt"; rc=0
fetch billing   REAL_BILLING_JAR   "${BILLING_VERSION:-8.3.0}"   com/android/billingclient/billing        "$GM" "$MC" || rc=1
fetch integrity REAL_INTEGRITY_JAR "${INTEGRITY_VERSION:-1.6.0}" com/google/android/play/integrity         "$GM" "$MC" || rc=1
fetch litertlm  REAL_LITERTLM_JAR  "${LITERTLM_VERSION:-}"       com/google/ai/edge/litertlm/litertlm-android "$MC" "$GM" || rc=1
curl -fsSL --retry 2 --max-time 120 -o "$OUT/jars/gson.jar" "$MC/com/google/code/gson/gson/2.11.0/gson-2.11.0.jar" 2>/dev/null || rm -f "$OUT/jars/gson.jar"
exit $rc
