package com.google.android.play.core.integrity;
import com.google.android.gms.tasks.Task;
public interface StandardIntegrityManager {
    Task<StandardIntegrityTokenProvider> prepareIntegrityToken(PrepareIntegrityTokenRequest request);

    abstract class PrepareIntegrityTokenRequest {
        public static Builder builder() { return null; }
        public abstract static class Builder {
            public abstract Builder setCloudProjectNumber(long cloudProjectNumber);
            public abstract PrepareIntegrityTokenRequest build();
        }
    }
    interface StandardIntegrityTokenProvider {
        Task<StandardIntegrityToken> request(StandardIntegrityTokenRequest request);
    }
    abstract class StandardIntegrityToken {
        public abstract String token();
    }
    abstract class StandardIntegrityTokenRequest {
        public static Builder builder() { return null; }
        public abstract static class Builder {
            public abstract Builder setRequestHash(String requestHash);
            public abstract StandardIntegrityTokenRequest build();
        }
    }
}
