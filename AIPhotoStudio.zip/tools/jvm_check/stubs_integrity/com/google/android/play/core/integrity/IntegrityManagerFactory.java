package com.google.android.play.core.integrity;
// Chữ ký theo developer.android.com/google/play/integrity/standard (R32)
public final class IntegrityManagerFactory {
    private IntegrityManagerFactory() {}
    public static StandardIntegrityManager createStandard(android.content.Context context) { return null; }
}
