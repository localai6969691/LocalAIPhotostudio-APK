package com.google.android.gms.tasks;
// Chữ ký chép từ play-services-tasks (R32)
public abstract class Task<TResult> {
    public abstract Task<TResult> addOnSuccessListener(OnSuccessListener<? super TResult> listener);
    public abstract Task<TResult> addOnFailureListener(OnFailureListener listener);
}
