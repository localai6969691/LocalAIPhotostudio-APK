#!/bin/bash
# R43: chạy ModelDownloader / ModelHub THẬT với GitHub THẬT (cần mạng tới github.com, release-assets.githubusercontent.com, raw.githubusercontent.com).
# Cần đã chạy tools/jvm_check/run_all.sh (hoặc build.sh) để có build/jvm_check/classes_default. Dùng: bash tools/jvm_check/real_dl/check_real_download.sh
source "$(dirname "${BASH_SOURCE[0]}")/../env.sh" || exit 1
CLS_MAIN="$P/build/jvm_check/classes_default"; STUBS="$P/build/jvm_check/stubs_default"
[ -d "$CLS_MAIN" ] || { echo "thiếu $CLS_MAIN — chạy tools/jvm_check/run_all.sh trước"; exit 2; }
OUT="${REAL_DL_WORK:-/tmp/real_dl}"; rm -rf "$OUT"; mkdir -p "$OUT"
COR="$(ls "$GRADLE_LIB"/kotlinx-coroutines-core-jvm-*.jar | head -1)"
"$JC/kc.sh" "$OUT/classes" "$CLS_MAIN:$STUBS:$COR" "$JC/real_dl/RealDownloadCheck.kt" > "$OUT/build.log" 2>&1
rc=$?; errs=$(grep -c ' error: ' "$OUT/build.log"); echo "kotlinc exit=$rc errors=$errs (log: $OUT/build.log)"; grep ' error: ' "$OUT/build.log" | head -10
[ "$rc" = 0 ] && [ "$errs" = 0 ] || exit 1
cd "$P" && java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$OUT/classes:$CLS_MAIN:$STUBS:$GRADLE_LIB/kotlin-stdlib-$KVER.jar:$COR" com.aiphoto.studio.models.RealDownloadCheckKt "app/src/main/assets/model_catalog.json"
