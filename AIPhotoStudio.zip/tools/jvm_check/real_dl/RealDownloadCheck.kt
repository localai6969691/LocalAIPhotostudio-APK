package com.aiphoto.studio.models

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.io.File
import java.nio.file.Files

// R43: chạy lớp ModelDownloader / ModelHub THẬT với GitHub THẬT (HTTPS, chuyển hướng 302 sang release-assets.githubusercontent.com, Range / 206):
//   1) tải u2netp.onnx (4,6 MB) từ rembg, HỦY sau vài chục KB, rồi TIẾP TỤC từ .part — chứng minh header Range được giữ qua chuyển hướng;
//   2) SHA-256 sai ⇒ bị từ chối và không để lại tệp; 3) danh mục có sẵn trong app (đã thay __REPO__ bằng kho không tồn tại ⇒ địa chỉ Release trả 404)
//   ⇒ ModelHub tự lùi sang địa chỉ gốc và nạp tệp qua hàm install.
private var fails = 0
private fun check(name: String, ok: Boolean) { println((if (ok) "  ĐẠT   " else "  HỎNG  ") + name); if (!ok) fails++ }

fun main(args: Array<String>) {
    val catalogPath = args.firstOrNull() ?: "app/src/main/assets/model_catalog.json"
    val dir = Files.createTempDirectory("realdl").toFile()
    try {
        val cat = ModelCatalogs.parse(File(catalogPath).readText().replace(ModelCatalogs.REPO_PLACEHOLDER, "khong-ton-tai-xyz/khong-co-kho"), "bundled")
        val e = cat.models.first { it.id == "seg_u2netp" }
        val upstream = e.urls.first { it.startsWith("https://github.com/danielgatis/") }
        val dl = ModelDownloader()

        // 1) hủy giữa chừng rồi tiếp tục
        val dest = File(dir, "u2netp.onnx")
        var cancel = false
        val r1 = dl.download(listOf(upstream), dest, e.sizeBytes, e.sha256, isCancelled = { cancel }, onProgress = { _, _ -> cancel = true })
        val part = File(dest.path + ".part")
        check("hủy giữa chừng ⇒ CANCELLED và giữ .part (${if (part.exists()) part.length() else -1} / ${e.sizeBytes} byte)",
            r1.err == ModelDownloader.Err.CANCELLED && part.exists() && part.length() in 1 until e.sizeBytes)
        val partLen = part.length()
        val r2 = dl.download(listOf(upstream), dest, e.sizeBytes, e.sha256)
        check("tiếp tục từ .part (từ byte $partLen) qua chuyển hướng GitHub ⇒ đủ tệp, đúng SHA-256 ${e.sha256.take(12)}…", r2.ok && dest.length() == e.sizeBytes && ModelDownloader.sha256(dest) == e.sha256)
        check("không còn .part sau khi xong", !part.exists())

        // 2) SHA-256 sai
        val d2 = File(dir, "wrong.onnx")
        val r3 = dl.download(listOf(upstream), d2, e.sizeBytes, "0".repeat(64))
        check("SHA-256 sai ⇒ SHA256 và không để lại tệp", r3.err == ModelDownloader.Err.SHA256 && !d2.exists() && !File(d2.path + ".part").exists())

        // 3) địa chỉ 404 ⇒ lùi sang địa chỉ kế tiếp
        val d3 = File(dir, "fallback.onnx")
        val r4 = dl.download(listOf("https://github.com/khong-ton-tai-xyz/khong-co-kho/releases/download/models-v1/u2netp.onnx", upstream), d3, e.sizeBytes, e.sha256)
        check("địa chỉ Release 404 ⇒ lùi sang nguồn gốc và tải được", r4.ok)

        // 4) ModelHub nguyên chuỗi với danh mục có sẵn trong app
        val said = ArrayList<String>()
        var installedSlot: String? = null
        var installedOk = false
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val hub = ModelHub(
            scope = scope, workDir = File(dir, "work"), consentFile = File(dir, "licenses.txt"), catalogCache = File(dir, "cache.json"),
            bundledJson = { File(catalogPath).readText().replace(ModelCatalogs.REPO_PLACEHOLDER, "khong-ton-tai-xyz/khong-co-kho") },
            slotFile = { File(dir, "models/$it.onnx") },
            install = { slot, f -> installedSlot = slot; installedOk = ModelDownloader.sha256(f) == e.sha256 },
            say = { synchronized(said) { said.add(it) } }
        )
        check("danh mục có sẵn: ${hub.state.value.entries.size} mục hiện ra", hub.state.value.entries.size >= 7)
        hub.request("seg_u2netp"); hub.confirm("seg_u2netp")
        val end = System.currentTimeMillis() + 60_000
        while (System.currentTimeMillis() < end && installedSlot == null) Thread.sleep(100)
        check("ModelHub tải qua địa chỉ Release (404) rồi nguồn gốc và gọi install(seg) với tệp đúng SHA-256", installedSlot == "seg" && installedOk)
        check("hộp thoại điều khoản đã được ghi nhận", File(dir, "licenses.txt").readText().contains("seg_u2netp"))
        scope.cancel()

        // 5) tải danh mục văn bản qua HTTPS thật
        val txt = ModelHub.httpGetText("https://raw.githubusercontent.com/google-ai-edge/LiteRT-LM/main/README.md")
        check("httpGetText lấy được một tệp văn bản HTTPS (${txt?.length ?: -1} ký tự)", txt != null && txt.length > 100)
        check("httpGetText trả null khi 404", ModelHub.httpGetText("https://github.com/khong-ton-tai-xyz/khong-co-kho/releases/download/x/y.json") == null)
    } finally {
        dir.deleteRecursively()
    }
    println(if (fails == 0) "RealDownloadCheck: TẤT CẢ ĐẠT" else "RealDownloadCheck: $fails HỎNG")
    if (fails != 0) kotlin.system.exitProcess(1)
}
