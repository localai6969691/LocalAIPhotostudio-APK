#!/bin/bash
# Biên dịch thật toàn bộ mã dự án (kể cả giao diện Compose) + test, so với stub Java/Kotlin cho android.*, androidx.*, Compose, ONNX Runtime, MediaPipe.
# Biến thể build (Play Billing / LiteRT-LM / Play Integrity thật):  build.sh billing | litertlm | integrity | billing litertlm integrity   (không đối số = biến thể mặc định, dùng bản stub trong dự án)
source "$(dirname "${BASH_SOURCE[0]}")/env.sh" || exit 1
WANT="$*"
BILL=billingStub; LLM=litertlmStub; INT=integrityStub; EXTRA_J=""; EXTRA_K=""
case " $WANT " in *" billing "*) BILL=billingReal; EXTRA_J="$(find "$JC/stubs_billing" -name '*.java')";; esac
case " $WANT " in *" integrity "*) INT=integrityReal; EXTRA_J="$EXTRA_J $(find "$JC/stubs_integrity" -name '*.java')";; esac
case " $WANT " in *" litertlm "*) LLM=litertlmReal; EXTRA_K="$(find "$JC/stubs_litertlm" -name '*.kt')";; esac
# R38: biến thể `realort` — biên dịch app với ONNX Runtime Java API THẬT (dựng bởi real_ort/build_real_ort.sh) thay cho stub ai.onnxruntime.*; bắt lệch chữ ký stub/thật
# và cho phép CHẠY engine Kotlin với model thật (real_ort/run_real_ort.sh). Dùng được riêng hoặc ghép: build.sh realort | build.sh realort billing litertlm integrity
JAVA_STUBS="$(find "$JC/stubs/java" -name '*.java')"; REALCP=""
case " $WANT " in *" realort "*) REALCP=":${REAL_ORT_CLASSES:-/tmp/ortbuild/classes}"; JAVA_STUBS="$(find "$JC/stubs/java" -name '*.java' -not -path '*/ai/onnxruntime/*')"; [ -d "${REAL_ORT_CLASSES:-/tmp/ortbuild/classes}/ai/onnxruntime" ] || { echo "build.sh realort: chưa có ORT thật — chạy real_ort/build_real_ort.sh trước"; exit 2; };; esac
# R41: biến thể dùng AAR/JAR THẬT (lấy bởi real_aar/fetch_real_aars.sh) thay cho stub: realbilling | realintegrity | reallitertlm (ghép được).
# Cần biến REAL_BILLING_JAR / REAL_INTEGRITY_JAR / REAL_LITERTLM_JAR = đường dẫn classes.jar. Vẫn dùng stub cho phần KHÔNG thuộc thư viện đó
# (annotation androidx; gms.tasks của play-services-tasks); LiteRT-LM bật -Xskip-metadata-version-check như app/build.gradle.kts khi -PuseLiteRtLm=true.
need_jar() { [ -f "${!1}" ] || { echo "build.sh: thiếu $1 (đường dẫn classes.jar)"; exit 2; }; }
case " $WANT " in *" realbilling "*) need_jar REAL_BILLING_JAR; BILL=billingReal; EXTRA_J="$EXTRA_J $(find "$JC/stubs_billing/androidx" -name '*.java')"; REALCP="$REALCP:$REAL_BILLING_JAR";; esac
case " $WANT " in *" realintegrity "*) need_jar REAL_INTEGRITY_JAR; INT=integrityReal; EXTRA_J="$EXTRA_J $(find "$JC/stubs_integrity/com/google/android/gms" -name '*.java')"; REALCP="$REALCP:$REAL_INTEGRITY_JAR";; esac
case " $WANT " in *" reallitertlm "*) need_jar REAL_LITERTLM_JAR; LLM=litertlmReal; REALCP="$REALCP:$REAL_LITERTLM_JAR${REAL_LITERTLM_EXTRA_CP:+:$REAL_LITERTLM_EXTRA_CP}"; export KEXTRA="-Xskip-metadata-version-check";; esac
TAG="${WANT:-default}"; TAG="${TAG// /_}"
STUBC="$OUT/stubs_$TAG"; CLS="$OUT/classes_$TAG"
rm -rf "$STUBC" "$CLS"; mkdir -p "$STUBC"
javac -nowarn -d "$STUBC" $JAVA_STUBS $EXTRA_J 2>&1 | grep -v "^Note:"
MAIN=$(cd "$P" && find app/src/main app/src/$BILL app/src/$LLM app/src/$INT -name '*.kt' | sort | sed "s#^#$P/#")
TEST=$(find "$P/app/src/test" -name '*.kt' | sort)
KT_STUB=$(find "$JC/stubs/kotlin" -name '*.kt')
"$JC/kc.sh" "$CLS" "$STUBC$REALCP" $MAIN $TEST $KT_STUB $EXTRA_K > "$OUT/build_$TAG.log" 2>&1
rc=$?
errs=$(grep -c ' error: ' "$OUT/build_$TAG.log")
echo "jvm_check[$TAG]: kotlinc exit=$rc  errors=$errs  (log: $OUT/build_$TAG.log)"
grep ' error: ' "$OUT/build_$TAG.log" | head -30
echo "$TAG" > "$OUT/last_tag"
[ "$rc" = 0 ] && [ "$errs" = 0 ]
