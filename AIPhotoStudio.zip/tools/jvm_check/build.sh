#!/bin/bash
# Biên dịch thật toàn bộ mã dự án (kể cả giao diện Compose) + test, so với stub Java/Kotlin cho android.*, androidx.*, Compose, ONNX Runtime, MediaPipe.
# Biến thể build (Play Billing / LiteRT-LM / Play Integrity thật):  build.sh billing | litertlm | integrity | billing litertlm integrity   (không đối số = biến thể mặc định, dùng bản stub trong dự án)
source "$(dirname "${BASH_SOURCE[0]}")/env.sh" || exit 1
WANT="$*"
BILL=billingStub; LLM=litertlmStub; INT=integrityStub; EXTRA_J=""; EXTRA_K=""
case " $WANT " in *" billing "*) BILL=billingReal; EXTRA_J="$(find "$JC/stubs_billing" -name '*.java')";; esac
case " $WANT " in *" integrity "*) INT=integrityReal; EXTRA_J="$EXTRA_J $(find "$JC/stubs_integrity" -name '*.java')";; esac
case " $WANT " in *" litertlm "*) LLM=litertlmReal; EXTRA_K="$(find "$JC/stubs_litertlm" -name '*.kt')";; esac
TAG="${WANT:-default}"; TAG="${TAG// /_}"
STUBC="$OUT/stubs_$TAG"; CLS="$OUT/classes_$TAG"
rm -rf "$STUBC" "$CLS"; mkdir -p "$STUBC"
javac -nowarn -d "$STUBC" $(find "$JC/stubs/java" -name '*.java') $EXTRA_J 2>&1 | grep -v "^Note:"
MAIN=$(cd "$P" && find app/src/main app/src/$BILL app/src/$LLM app/src/$INT -name '*.kt' | sort | sed "s#^#$P/#")
TEST=$(find "$P/app/src/test" -name '*.kt' | sort)
KT_STUB=$(find "$JC/stubs/kotlin" -name '*.kt')
"$JC/kc.sh" "$CLS" "$STUBC" $MAIN $TEST $KT_STUB $EXTRA_K > "$OUT/build_$TAG.log" 2>&1
rc=$?
errs=$(grep -c ' error: ' "$OUT/build_$TAG.log")
echo "jvm_check[$TAG]: kotlinc exit=$rc  errors=$errs  (log: $OUT/build_$TAG.log)"
grep ' error: ' "$OUT/build_$TAG.log" | head -30
echo "$TAG" > "$OUT/last_tag"
[ "$rc" = 0 ] && [ "$errs" = 0 ]
