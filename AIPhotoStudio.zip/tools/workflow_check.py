#!/usr/bin/env python3
"""R48 - kiểm workflow CI bằng văn bản thuần (không cần PyYAML), chạy trong static_check mục [37].
Bắt hai lỗi đã gặp thật:
  (a) Build APK #35: bước `sed ... model_catalog.json` đứng TRƯỚC bước giải nén AIPhotoStudio.zip (repo chỉ có zip ở gốc ⇒ chưa có tệp).
      Quy tắc: trong job có bước "Giải nén gói zip", mọi bước đứng trước nó không được đụng tới mã dự án (app/, tools/, backend/, model_catalog).
      mirror-models.yml: job chạy mirror_models.py bắt buộc có bước giải nén (lỗi ngầm cùng loại).
  (b) giá trị `name:` không đặt trong ngoặc kép mà chứa ": " ⇒ YAML hỏng (lỗi mình tự vấp khi sửa R48).
Dùng:  python3 tools/workflow_check.py [tệp.yml ...]   (không đối số = các workflow trong .github/workflows của dự án)"""
import os, re, sys

PROJ_PATHS = ("app/", "tools/", "backend/", "model_catalog", "gradle")


def _jobs(text):
    m = re.search(r"(?m)^jobs:\s*$", text)
    if not m:
        return {}
    out = {}
    for p in re.split(r"(?m)^(?=  [A-Za-z_][\w-]*:\s*$)", text[m.end():]):
        mm = re.match(r"  ([A-Za-z_][\w-]*):\s*\n", p)
        if mm:
            out[mm.group(1)] = p
    return out


def _steps(job):
    res = []
    for c in re.split(r"(?m)^(?=      - )", job)[1:]:
        first = c.split("\n", 1)[0]
        nm = re.match(r"      - (?:name:\s*(.*?)|uses:\s*(.*?))\s*$", first)
        name = ((nm.group(1) or nm.group(2) or "") if nm else "").strip()
        res.append((name, c))
    return res


def _run_text(step_text):
    m = re.search(r"(?m)^        run:(.*)$", step_text, re.S)
    return m.group(1) if m else ""


def check_text(label, text):
    errs = []
    # (b) tên bước dính ": " không ngoặc kép
    for i, line in enumerate(text.split("\n"), 1):
        m = re.match(r"\s*(?:-\s+)?name:\s+(.*)$", line)
        if not m:
            continue
        val = re.split(r"\s+#", m.group(1))[0].strip()
        if val and val[0] not in "'\"|>" and ": " in val:
            errs.append(f"{label}:{i}: `name:` chứa \": \" mà không đặt trong ngoặc kép ⇒ YAML hỏng — bỏ dấu hai chấm hoặc bọc cả giá trị trong \"...\"")
    # (a) thứ tự bước
    for jname, job in _jobs(text).items():
        steps = _steps(job)
        uz = next((i for i, (n, _) in enumerate(steps) if n.startswith("Giải nén gói zip")), None)
        if uz is None:
            if label.endswith("mirror-models.yml") and "mirror_models.py" in job:
                errs.append(f"{label}: job `{jname}` chạy mirror_models.py nhưng KHÔNG có bước \"Giải nén gói zip\" (repo chỉ có zip ở gốc ⇒ không có tools/models/)")
            continue
        for n, body in steps[:uz]:
            run = _run_text(body)
            hit = [p for p in PROJ_PATHS if p in run]
            if hit:
                errs.append(f"{label}: job `{jname}`: bước \"{n[:60]}\" nằm TRƯỚC bước giải nén zip nhưng đụng tới {hit} — chuyển xuống sau bước giải nén (Build APK #35)")
    return errs


def check(proj, files=None):
    if files is None:
        d = os.path.join(proj, ".github", "workflows")
        files = sorted(os.path.join(d, f) for f in os.listdir(d) if f.endswith((".yml", ".yaml"))) if os.path.isdir(d) else []
    errs = []
    for f in files:
        errs += check_text(os.path.basename(f), open(f, encoding="utf-8").read())
    return errs


if __name__ == "__main__":
    root = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    es = check(root, sys.argv[1:] or None)
    for e in es:
        print("LỖI:", e)
    print(f"workflow_check: {len(es)} lỗi")
    sys.exit(1 if es else 0)
