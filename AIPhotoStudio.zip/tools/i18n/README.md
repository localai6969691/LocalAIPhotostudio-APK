# Gói dịch và Trợ giúp (R33)

App dịch giao diện bằng một lớp chạy lúc hiển thị: `Text(...)` của dự án (`i18n/Text.kt`) tra chuỗi tiếng Việt sắp vẽ trong gói dịch của ngôn ngữ đang chọn;
thiếu thì rơi về gói **tiếng Anh**, thiếu nữa thì giữ tiếng Việt. Chuỗi có nội suy (`"Credits còn lại: ${n}"`) được khớp bằng **mẫu** `Credits còn lại: {0}`.

| Thư mục / tệp | Nội dung |
|---|---|
| `ids.json` | danh sách khóa; **mã = vị trí**, chỉ thêm cuối, không đổi chỗ / xóa. `core` = giao diện chính (mọi ngôn ngữ phải dịch đủ), `ui` = màn hình giao diện (tiếng Anh phải đủ) |
| `src/<mã>.txt` | bản dịch, mỗi dòng `mã|bản dịch` (giữ nguyên `{0}` `{1}`, chữ số và ký hiệu như `→ × ° %`) |
| `help/<mã>.json` hoặc `.txt` | nội dung Trợ giúp; `.txt` dạng gọn: `= Tên nhóm` rồi các dòng `- Tiêu đề mục \| Nội dung`. Mọi ngôn ngữ phải CÙNG cấu trúc với `vi.json` |
| `../../app/src/main/assets/i18n`, `.../help` | sản phẩm do `i18n_build.py --build` sinh ra (được commit, app đọc lúc chạy) |

## Thêm / sửa bản dịch
1. Viết chuỗi tiếng Việt mới trong mã như bình thường (trong `Text(...)`, thông báo của `MainViewModel`…).
2. `python tools/i18n_build.py --assign` — gán mã cho chuỗi mới (nối vào cuối `ids.json`).
3. Thêm dòng `mã|bản dịch` vào `src/<mã>.txt` (tiếng Anh trước; mã in ra bằng `python tools/i18n_build.py --check`).
4. `python tools/i18n_build.py --build` — kiểm tra + sinh assets. `static_check.py` mục [34] sẽ báo nếu assets cũ hơn nguồn hoặc còn chuỗi chưa có mã.

## Thêm một ngôn ngữ mới
1. Thêm `AppLanguage("xx", "Tên bản địa", rtl = false)` vào `AppLanguages.ALL` (`i18n/AppLanguage.kt`) và mã `xx` vào `LANGS` trong `tools/i18n_build.py`.
2. Tạo `src/xx.txt` (phải đủ các mã `core`, hiện là 0–287) và `help/xx.txt` (cùng cấu trúc `vi.json`), rồi `--build`.
3. Ngôn ngữ viết phải sang trái (Ả Rập, Do Thái…) đặt `rtl = true` để bố cục tự đảo.

## Độ phủ hiện tại
`python tools/i18n_build.py --check` in độ phủ từng ngôn ngữ. Tiếng Việt 100% (nguồn); tiếng Anh gần đầy đủ; các ngôn ngữ còn lại có giao diện chính + toàn bộ Trợ giúp,
phần chưa dịch hiện bằng tiếng Anh. Màn hình chọn ngôn ngữ hiển thị tỉ lệ này cạnh tên ngôn ngữ.

## Giới hạn đã biết
* Bản dịch do AI soạn, **chưa có người bản ngữ rà soát** — mong tester góp ý (sửa thẳng `src/<mã>.txt`).
* Chỉ `Text(...)` được dịch. Chuỗi ghép động bằng `+` với giá trị chạy lúc đó (ví dụ trong khu cài đặt model), `contentDescription`, hộp chia sẻ hệ thống, thông báo kỹ thuật (`DiagLog`) vẫn tiếng Việt.
* Đổi ngôn ngữ giao diện **không** đổi cách app hiểu câu lệnh gõ vào (bộ quy tắc offline hiểu tiếng Việt và tiếng Anh).

## Mẹo khi dịch / sửa bản dịch (R34)

- Trình kiểm so **chữ số** của khóa tiếng Việt với bản dịch. Khóa viết bằng chữ ("hai ngón", "một vùng", "ít nhất một") thì tiếng Nhật / Trung / Hàn phải viết bằng chữ (二本指, ひとつの, 한 영역…), không dùng số 1/2 — nếu không `--check` báo lỗi.
- Giữ nguyên mọi `{0}`, `{1}`…, `%`, `×`, `→`, `+`, `…` (một ký tự U+2026) và `°` có trong bản tiếng Anh; ở dòng có `…` thì bản dịch cũng phải kết thúc bằng `…`.
- Tên thương hiệu / thuật ngữ không có từ chuẩn giữ nguyên: Kodak, Portra, Ektar, Ilford, Matrix, Best Take, Reframe 2.5D, LUT, CMYK, Seed, Focus Area, Look.
- Tên nút được nhắc trong thông báo ("Áp dụng", "Chọn nguồn", "Vẽ thành ảnh", "Tạo lớp cục bộ", "Khôi phục giao dịch mua"…) phải khớp nhãn nút đã dịch ở cùng ngôn ngữ.
- Sau khi sửa: `python tools/i18n_build.py --check` → `--build` → `--verify`; rồi `python tools/static_check.py`.
