#!/usr/bin/env python3
"""R38 - tạo ONNX "đại diện" cho LaMa đúng HỢP ĐỒNG đã công bố của lama_fp32.onnx (Carve/LaMa-ONNX; bản thật chỉ có trên HuggingFace nên không tải được ở sandbox):
    input  `image` float32 [1,3,512,512] RGB 0..1;  input `mask` float32 [1,1,512,512] (1 = vùng cần lấp);  output `output` float32 [1,3,512,512] RGB 0..255.
Model này KHÔNG phải LaMa: nó lấp vùng mặt nạ bằng màu xám giữa (127,5) và giữ nguyên ảnh ngoài mặt nạ — chỉ để kiểm đường LaMaInpainter.kt (tiền xử lý, chiều mặt nạ, thang 0..255,
ghép lại) bằng ONNX Runtime THẬT. Chất lượng điền của LaMa thật vẫn chưa kiểm được ở đây (A208).
Chạy:  python3 tools/make_lama_standin_onnx.py out.onnx   (cần: pip install onnx numpy)"""
import sys

import numpy as np
import onnx
from onnx import TensorProto, helper, numpy_helper

one = numpy_helper.from_array(np.array([1.0], np.float32), "one")
half = numpy_helper.from_array(np.array([0.5], np.float32), "half")
k255 = numpy_helper.from_array(np.array([255.0], np.float32), "k255")
nodes = [
    helper.make_node("Sub", ["one", "mask"], ["keep"]),
    helper.make_node("Mul", ["image", "keep"], ["kept"]),
    helper.make_node("Mul", ["mask", "half"], ["fill"]),
    helper.make_node("Add", ["kept", "fill"], ["mix"]),
    helper.make_node("Mul", ["mix", "k255"], ["output"]),
]
g = helper.make_graph(nodes, "lama_standin",
                      [helper.make_tensor_value_info("image", TensorProto.FLOAT, [1, 3, 512, 512]),
                       helper.make_tensor_value_info("mask", TensorProto.FLOAT, [1, 1, 512, 512])],
                      [helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 3, 512, 512])], [one, half, k255])
m = helper.make_model(g, opset_imports=[helper.make_opsetid("", 17)])
m.ir_version = 8
onnx.checker.check_model(m)
onnx.save(m, sys.argv[1])
print("đã ghi", sys.argv[1])
