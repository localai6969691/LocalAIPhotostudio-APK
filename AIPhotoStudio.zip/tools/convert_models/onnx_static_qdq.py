#!/usr/bin/env python3
"""
Lượng tử hóa TĨNH dạng QDQ cho model ONNX (kích hoạt uint8 theo tensor + trọng số int8 theo kênh + bias int32), KHÔNG cần gói `onnx`.
Cần numpy + onnxruntime (để chạy ảnh hiệu chuẩn). Dựa trên bộ đọc / ghi protobuf của onnx_weight_quant.py.

Dùng:
  python3 onnx_static_qdq.py vao.onnx ra.onnx --calib-npy x=anh1.npy --calib-npy x=anh2.npy ... --verify
  (mỗi --calib-npy là MỘT mẫu đúng hình input, nên 20–200 ảnh THẬT đại diện; dùng --calib-dir thư_mục để nạp mọi .npy, tên input = tên tệp trước dấu `__`)

Định dạng sinh ra (chuẩn QDQ của ONNX Runtime, ORT QNN / NNAPI / CPU đều nhận):
  tensor kích hoạt  --QuantizeLinear(uint8)--> --DequantizeLinear--> toán tử
  trọng số int8 theo kênh --DequantizeLinear(axis)--> Conv / MatMul / Gemm ; bias int32 (scale = scale_x * scale_w theo kênh) --DequantizeLinear-->
  Conv/Gemm/MatMul được quantize: các tensor ĐẦU VÀO kích hoạt và ĐẦU RA (đầu ra của Conv đi thẳng vào một Relu thì quantize sau Relu — đúng cách ORT fuse Conv+Relu).

THÀNH THẬT:
  * Định dạng QDQ là điều kiện CẦN để NPU (ORT QNN / NNAPI) chạy int8 và để ORT CPU fuse thành QLinearConv; tốc độ / RAM thật chỉ biết khi chạy trên MÁY ĐÍCH. Script `--verify`
    in cả số toán tử int8 mà ORT fuse được trên máy đang chạy và thời gian float vs QDQ, nhưng đó là CPU của máy bạn, KHÔNG phải NPU điện thoại.
  * Độ chính xác phụ thuộc ảnh hiệu chuẩn: dùng ảnh THẬT, cùng phân phối với lúc chạy. Số ngẫu nhiên chỉ để thử đường ống.
  * Chỉ Conv / MatMul / Gemm (trọng số float32 hằng số); các toán tử khác giữ float. Không hỗ trợ opset < 13, external data, đồ thị con.
"""
import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import onnx_weight_quant as wq  # noqa: E402
from onnx_weight_quant import (FLOAT, INT8, emit, make_attr_int, make_node, make_tensor, node_info, parse, quantize_per_axis, read_tensor, weight_axis,  # noqa: E402
                               _int, _str)

UINT8, INT32 = 2, 6
TARGET_OPS = ("Conv", "MatMul", "Gemm")


def act_qparams(lo, hi):
    """uint8 bất đối xứng theo tensor; ép khoảng chứa số 0 (bắt buộc để số 0 biểu diễn chính xác). Trả (scale float32, zero_point 0..255)."""
    lo, hi = min(float(lo), 0.0), max(float(hi), 0.0)
    if hi - lo < 1e-12:
        return np.float32(1.0), 0
    scale = np.float32((hi - lo) / 255.0)
    zp = int(np.clip(np.rint(-lo / float(scale)), 0, 255))
    return scale, zp


def _scalar(name, dtype, value):
    arr = np.asarray(value, dtype={FLOAT: "<f4", UINT8: "u1", INT8: "i1", INT32: "<i4"}[dtype])
    return make_tensor(name, [], dtype, arr.tobytes())


def _vec(name, dtype, arr):
    return make_tensor(name, [len(arr)], dtype, np.asarray(arr, dtype={FLOAT: "<f4", INT8: "i1", INT32: "<i4"}[dtype]).tobytes())


def _rewire(node_bytes, mapping):
    """Thay tên đầu vào theo mapping; giữ nguyên mọi trường khác."""
    f = parse(node_bytes)
    out, changed = [], False
    for fno, w, v in f:
        if fno == 1 and w == 2:
            nm = bytes(v).decode()
            if nm in mapping:
                out.append((1, 2, mapping[nm].encode()))
                changed = True
                continue
        out.append((fno, w, v))
    return emit(out) if changed else node_bytes


def _unique(base, used):
    nm = base
    while nm in used:
        nm += "_"
    used.add(nm)
    return nm


def analyse(data, min_elements=1):
    """Đọc đồ thị: trả dict gồm nút, initializer, mục tiêu và tập tensor cần quantize (chưa có thang đo)."""
    top = parse(data)
    gi = next((i for i, (f, w, v) in enumerate(top) if f == 7 and w == 2), None)
    if gi is None:
        raise ValueError("không thấy graph — tệp không phải model ONNX")
    opset = 1
    for f, w, v in top:
        if f == 8 and w == 2:
            of = parse(v)
            if _str(of, 1) in ("", "ai.onnx"):
                opset = _int(of, 2, 1)
    graph = parse(top[gi][2])
    nodes = [(i, v) for i, (f, w, v) in enumerate(graph) if f == 1 and w == 2]
    inits = {_str(parse(v), 8): v for f, w, v in graph if f == 5 and w == 2}
    g_inputs = {_str(parse(v), 1) for f, w, v in graph if f == 11 and w == 2}
    g_outputs = {_str(parse(v), 1) for f, w, v in graph if f == 12 and w == 2}
    info = []
    for _, nb in nodes:
        f = parse(nb)
        op, dom, ins, attrs = node_info(nb)
        outs = [bytes(v).decode() for fno, w, v in f if fno == 2 and w == 2]
        info.append({"bytes": nb, "op": op, "dom": dom, "ins": ins, "outs": outs, "attrs": attrs})
    return {"top": top, "gi": gi, "graph": graph, "opset": opset, "info": info, "inits": inits, "g_inputs": g_inputs, "g_outputs": g_outputs}


def plan_targets(a, min_elements=1):
    """Chọn nút Conv / MatMul / Gemm đủ điều kiện, trả (danh sách mục tiêu, danh sách bị bỏ qua + lý do)."""
    targets, skipped = [], []
    inits = a["inits"]
    for idx, n in enumerate(a["info"]):
        if n["dom"] not in ("", "ai.onnx") or n["op"] not in TARGET_OPS or len(n["ins"]) < 2:
            continue
        x, w = n["ins"][0], n["ins"][1]
        nm = n["outs"][0] if n["outs"] else "?"
        if x in inits or x == "":
            skipped.append((nm, "đầu vào kích hoạt là hằng số"))
            continue
        if w not in inits:
            skipped.append((nm, "trọng số không phải hằng số"))
            continue
        _, dims, _, arr, why = read_tensor(parse(inits[w]))
        if arr is None:
            skipped.append((nm, why or "không đọc được trọng số"))
            continue
        if arr.size < min_elements:
            skipped.append((nm, "trọng số quá nhỏ"))
            continue
        ax = weight_axis(n["op"], n["attrs"], dims)
        if ax is None or n["op"] == "ConvTranspose":
            skipped.append((nm, "%s hình %s chưa hỗ trợ" % (n["op"], dims)))
            continue
        if n["op"] == "Gemm" and (n["attrs"].get("transA", 0) != 0):
            skipped.append((nm, "Gemm transA chưa hỗ trợ"))
            continue
        bias = n["ins"][2] if len(n["ins"]) > 2 and n["ins"][2] != "" else None
        if bias is not None:
            _, bd, _, barr, bwhy = read_tensor(parse(inits[bias])) if bias in inits else (None, None, None, None, "bias không phải hằng số")
            if barr is None:
                skipped.append((nm, bwhy or "bias không đọc được"))
                continue
        targets.append({"idx": idx, "w": w, "axis": ax, "bias": bias, "x": x, "y": n["outs"][0], "op": n["op"]})
    return targets, skipped


def plan_tensors(a, targets):
    """Tập tensor kích hoạt cần quantize: đầu vào mục tiêu + đầu ra mục tiêu (nếu đầu ra chỉ đi vào đúng một Relu thì thay bằng đầu ra của Relu)."""
    info = a["info"]
    consumers = {}
    for i, n in enumerate(info):
        for t in n["ins"]:
            consumers.setdefault(t, []).append(i)
    tensors = []
    for t in targets:
        if t["x"] not in tensors:
            tensors.append(t["x"])
        y = t["y"]
        users = consumers.get(y, [])
        out_t = y
        if len(users) == 1 and info[users[0]]["op"] == "Relu" and info[users[0]]["dom"] in ("", "ai.onnx") and y not in a["g_outputs"]:
            out_t = info[users[0]]["outs"][0]
        t["out_t"] = out_t
        if out_t not in tensors and consumers.get(out_t):          # đầu ra không ai dùng (đầu ra cuối của đồ thị) giữ float: chính xác hơn và không thêm Q/DQ thừa
            tensors.append(out_t)
    return [t for t in tensors if t not in a["inits"]]


def calibrate(data, tensors, feeds_list, percentile=None):
    """Chạy model gốc bằng onnxruntime với các tensor trung gian làm đầu ra phụ; trả {tensor: (min, max)}."""
    import onnxruntime as ort
    top = parse(data)
    gi = next(i for i, (f, w, v) in enumerate(top) if f == 7 and w == 2)
    graph = parse(top[gi][2])
    existing = {_str(parse(v), 1) for f, w, v in graph if f == 12 and w == 2}
    extra = []
    for t in tensors:
        if t not in existing:
            tt = emit([(1, 0, FLOAT)])                                  # tensor_type{elem_type=FLOAT}, không khai shape
            extra.append((12, 2, emit([(1, 2, t.encode()), (2, 2, emit([(1, 2, tt)]))])))
    top2 = list(top)
    top2[gi] = (7, 2, emit(graph + extra))
    so = ort.SessionOptions()
    so.log_severity_level = 3
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    sess = ort.InferenceSession(emit(top2), so, providers=["CPUExecutionProvider"])
    names = [o.name for o in sess.get_outputs()]
    rng = {t: [np.inf, -np.inf] for t in tensors}
    for feeds in feeds_list:
        outs = dict(zip(names, sess.run(None, feeds)))
        for t in tensors:
            v = np.asarray(outs[t], dtype=np.float32)
            if percentile is not None and v.size > 100:
                lo, hi = np.percentile(v, [100 - percentile, percentile])
            else:
                lo, hi = v.min(), v.max()
            rng[t][0] = min(rng[t][0], float(lo))
            rng[t][1] = max(rng[t][1], float(hi))
    return {t: tuple(r) for t, r in rng.items()}


def quantize_static(data, feeds_list, min_elements=1, percentile=None):
    """Trả (bytes mới, báo cáo). feeds_list: danh sách dict {tên_input: mảng numpy} dùng làm ảnh hiệu chuẩn."""
    a = analyse(data)
    report = {"opset": a["opset"], "targets": 0, "tensors": 0, "skipped": [], "bytes_in": len(data), "bytes_out": len(data), "ranges": {}}
    if a["opset"] < 13:
        report["skipped"].append(("*", "opset %d < 13: chưa hỗ trợ QDQ theo kênh — không đổi gì" % a["opset"]))
        return data, report
    if not feeds_list:
        raise ValueError("cần ít nhất một mẫu hiệu chuẩn")
    targets, skipped = plan_targets(a, min_elements)
    report["skipped"] += skipped
    if not targets:
        return data, report
    tensors = plan_tensors(a, targets)
    rng = calibrate(data, tensors, feeds_list, percentile)
    qp = {t: act_qparams(*rng[t]) for t in tensors}
    report["ranges"] = rng
    used = set(a["inits"]) | {t for n in a["info"] for t in n["ins"] + n["outs"]}
    inits_new, pre_nodes, drop = [], [], set()
    q_after = {}                                  # tensor -> [nút Q, nút DQ] chèn ngay sau nút sinh ra tensor
    rewire = {}
    for t in tensors:
        sc, zp = qp[t]
        s_n, z_n = _unique(t + "_scale", used), _unique(t + "_zp", used)
        q_n, dq_n = _unique(t + "_quantized", used), _unique(t + "_dequantized", used)
        inits_new += [_scalar(s_n, FLOAT, sc), _scalar(z_n, UINT8, zp)]
        nodes = [make_node("QuantizeLinear", [t, s_n, z_n], [q_n], _unique(t + "_QuantizeLinear", used)),
                 make_node("DequantizeLinear", [q_n, s_n, z_n], [dq_n], _unique(t + "_DequantizeLinear", used))]
        q_after[t] = nodes
        rewire[t] = dq_n
    ok_targets = []
    w_done, b_done = {}, {}                       # trọng số / bias dùng chung giữa nhiều nút chỉ được nén MỘT lần (tên đầu ra DequantizeLinear phải duy nhất)
    for tg in targets:
        x_scale = float(qp[tg["x"]][0])
        wn, bn = tg["w"], tg["bias"]
        if wn in w_done and w_done[wn][0] != tg["axis"]:
            report["skipped"].append((tg["y"], "trọng số %s dùng chung với nút cần trục khác" % wn))
            continue
        if bn is not None and bn in b_done and abs(b_done[bn] - x_scale) > 1e-12 * max(1.0, abs(x_scale)):
            report["skipped"].append((tg["y"], "bias %s dùng chung với nút có scale đầu vào khác" % bn))
            continue
        _, dims, _, w, _ = read_tensor(parse(a["inits"][wn]))
        if wn in w_done:
            w_scale = w_done[wn][1]
        else:
            q, w_scale = quantize_per_axis(w, tg["axis"])
            w_q, w_s, w_z = _unique(wn + "_int8", used), _unique(wn + "_scale", used), _unique(wn + "_zp", used)
            inits_new += [make_tensor(w_q, dims, INT8, q.tobytes()), _vec(w_s, FLOAT, w_scale), _vec(w_z, INT8, np.zeros(len(w_scale), np.int8))]
            pre_nodes.append(make_node("DequantizeLinear", [w_q, w_s, w_z], [wn], _unique(wn + "_dq", used), [make_attr_int("axis", tg["axis"])]))
            drop.add(wn)
            w_done[wn] = (tg["axis"], w_scale)
        if bn is not None and bn not in b_done:
            _, bd, _, b, _ = read_tensor(parse(a["inits"][bn]))
            b_scale = (x_scale * w_scale).astype(np.float32)
            if len(b_scale) != b.size:
                report["skipped"].append((tg["y"], "độ dài bias %d không khớp số kênh %d" % (b.size, len(b_scale))))
                continue
            bq = np.clip(np.rint(b.astype(np.float64) / b_scale.astype(np.float64)), -(2 ** 31), 2 ** 31 - 1).astype(np.int32)
            b_q, b_s = _unique(bn + "_int32", used), _unique(bn + "_scale", used)
            inits_new += [make_tensor(b_q, bd, INT32, bq.tobytes()), _vec(b_s, FLOAT, b_scale)]
            pre_nodes.append(make_node("DequantizeLinear", [b_q, b_s], [bn], _unique(bn + "_dq", used), [make_attr_int("axis", 0)]))
            drop.add(bn)
            b_done[bn] = x_scale
        ok_targets.append(tg)
    # dựng lại danh sách nút: DQ của trọng số / bias ở đầu, Q/DQ của tensor đầu vào đồ thị ngay sau, rồi từng nút gốc (đã nối lại) + Q/DQ của đầu ra của nó
    produced = {t for n in a["info"] for t in n["outs"]}
    new_nodes = list(pre_nodes)
    for t in tensors:
        if t not in produced:                                      # input của đồ thị
            new_nodes += q_after[t]
    for n in a["info"]:
        mapping = {t: dq for t, dq in rewire.items() if t in n["ins"]}
        new_nodes.append(_rewire(n["bytes"], mapping) if mapping else n["bytes"])
        for o in n["outs"]:
            if o in q_after:
                new_nodes += q_after[o]
    out_fields, placed = [], False
    for f, w, v in a["graph"]:
        if f == 1 and w == 2:
            if not placed:
                out_fields += [(1, 2, nb) for nb in new_nodes]
                placed = True
            continue
        if f == 5 and w == 2 and _str(parse(v), 8) in drop:
            continue
        out_fields.append((f, w, v))
    if not placed:
        out_fields += [(1, 2, nb) for nb in new_nodes]
    out_fields += [(5, 2, t) for t in inits_new]
    top = list(a["top"])
    top[a["gi"]] = (7, 2, emit(out_fields))
    result = emit(top)
    report.update({"targets": len(ok_targets), "tensors": len(tensors), "bytes_out": len(result)})
    return result, report


# ------------------------------------------------------------------ kiểm tra
def fused_ops(model_bytes, tmpdir):
    """Cho ORT tối ưu rồi đọc lại danh sách toán tử: đếm toán tử int8 đã fuse (QLinearConv / QLinearMatMul / MatMulInteger / ConvInteger) và Q/DQ còn sót."""
    import onnxruntime as ort
    src = os.path.join(tmpdir, "in.onnx")
    dst = os.path.join(tmpdir, "opt.onnx")
    open(src, "wb").write(model_bytes)
    so = ort.SessionOptions()
    so.log_severity_level = 3
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.optimized_model_filepath = dst
    ort.InferenceSession(src, so, providers=["CPUExecutionProvider"])
    a = analyse(open(dst, "rb").read())
    ops = {}
    for n in a["info"]:
        ops[n["op"]] = ops.get(n["op"], 0) + 1
    return ops


def timeit(model_bytes, feeds, runs=20):
    import onnxruntime as ort
    so = ort.SessionOptions()
    so.log_severity_level = 3
    s = ort.InferenceSession(model_bytes, so, providers=["CPUExecutionProvider"])
    s.run(None, feeds)
    t0 = time.perf_counter()
    for _ in range(runs):
        s.run(None, feeds)
    return (time.perf_counter() - t0) / runs * 1000


def main(argv=None):
    ap = argparse.ArgumentParser(description="Lượng tử hóa tĩnh QDQ (uint8 kích hoạt, int8 trọng số theo kênh, int32 bias) không cần gói onnx")
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--calib-npy", action="append", default=[], metavar="TÊN=FILE.npy", help="một mẫu hiệu chuẩn (lặp lại nhiều lần); nhiều input thì cùng thứ tự các lần lặp")
    ap.add_argument("--calib-dir", help="thư mục .npy; tên tệp dạng <input>__<bất kỳ>.npy")
    ap.add_argument("--percentile", type=float, default=None, help="cắt ngoại lai: dùng phân vị này (vd 99.99) thay min/max")
    ap.add_argument("--min-elements", type=int, default=1)
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--min-cos", type=float, default=0.99)
    ap.add_argument("--max-rel-l2", type=float, default=0.15)
    a = ap.parse_args(argv)
    feeds = []
    by_idx = {}
    for item in a.calib_npy:
        k, _, p = item.partition("=")
        by_idx.setdefault(k, []).append(np.load(p))
    if by_idx:
        n = max(len(v) for v in by_idx.values())
        feeds = [{k: v[i] for k, v in by_idx.items() if i < len(v)} for i in range(n)]
    if a.calib_dir:
        groups = {}
        for fn in sorted(os.listdir(a.calib_dir)):
            if fn.endswith(".npy") and "__" in fn:
                groups.setdefault(fn.split("__")[0], []).append(np.load(os.path.join(a.calib_dir, fn)))
        if groups:
            n = max(len(v) for v in groups.values())
            feeds += [{k: v[i] for k, v in groups.items() if i < len(v)} for i in range(n)]
    data = open(a.src, "rb").read()
    if not feeds:
        print("THIẾU ảnh hiệu chuẩn (--calib-npy / --calib-dir). Dùng ảnh THẬT; ví dụ: --calib-npy x=a.npy --calib-npy x=b.npy")
        return 1
    out, rep = quantize_static(data, feeds, a.min_elements, a.percentile)
    open(a.dst, "wb").write(out)
    print("Model: %s -> %s (QDQ tĩnh, opset %d, %d mẫu hiệu chuẩn)" % (a.src, a.dst, rep["opset"], len(feeds)))
    print("Đã quantize %d nút Conv/MatMul/Gemm, %d tensor kích hoạt; bỏ qua %d." % (rep["targets"], rep["tensors"], len(rep["skipped"])))
    for nm, why in rep["skipped"][:20]:
        print("  bỏ qua %s: %s" % (nm, why))
    print("Cỡ tệp: %.2f MB -> %.2f MB (giảm %.1f %%)." % (rep["bytes_in"] / 1e6, rep["bytes_out"] / 1e6, 100.0 * (1 - rep["bytes_out"] / rep["bytes_in"])))
    if not a.verify:
        return 0
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        ops = fused_ops(out, td)
    fused = {k: v for k, v in ops.items() if k in ("QLinearConv", "QLinearMatMul", "MatMulInteger", "ConvInteger", "QGemm", "QLinearAdd")}
    print("ORT trên máy này fuse được: %s; còn lại QuantizeLinear=%d DequantizeLinear=%d" % (fused or "không có toán tử int8 nào (chạy float với Q/DQ mô phỏng)", ops.get("QuantizeLinear", 0), ops.get("DequantizeLinear", 0)))
    res = wq.verify(a.src, a.dst, feeds[0] if feeds else None)
    bad = 0
    for m in res:
        good = m["cos"] >= a.min_cos and m["rel_l2"] <= a.max_rel_l2
        bad += 0 if good else 1
        print("  %-24s cos=%.6f  L2tđ=%.4f  PSNR=%.1f dB  %s" % (m["output"], m["cos"], m["rel_l2"], m["psnr_db"], "ĐẠT" if good else "KHÔNG ĐẠT"))
    print("  (đo bằng chính mẫu hiệu chuẩn đầu tiên — NÊN thử thêm ảnh KHÔNG nằm trong tập hiệu chuẩn)")
    return 2 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
