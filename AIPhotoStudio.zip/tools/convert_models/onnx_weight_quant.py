#!/usr/bin/env python3
"""
Nén TRỌNG SỐ model ONNX (INT8 theo kênh hoặc FP16) KHÔNG cần gói `onnx` — chỉ numpy (+ onnxruntime nếu muốn --verify).
ONNX thực chất là protobuf nên công cụ tự đọc / ghi dây protobuf, giữ NGUYÊN mọi trường không đụng tới (kể cả trường lạ).

Dùng:
  python3 onnx_weight_quant.py vao.onnx ra.onnx --mode int8 --verify
  python3 onnx_weight_quant.py vao.onnx ra.onnx --mode fp16 --verify --input-npy x=anh_mau.npy
  --mode int8 : trọng số Conv / ConvTranspose(group=1) / MatMul / Gemm (hằng số float32 >= --min-elements phần tử) -> int8 đối xứng THEO KÊNH
                + nút DequantizeLinear (opset >= 13). Bias, norm và mọi thứ khác giữ nguyên float32.
  --mode fp16 : mọi hằng số float32 >= --min-elements phần tử (biên độ < 65000) -> float16 + nút Cast về float32.

THÀNH THẬT về lợi ích (đọc trước khi tin con số 68 % của tài liệu PDF):
  * Đây chủ yếu là nén CỠ TỆP (tải về / lưu trữ): int8 ~ -70..75 % cỡ trọng số, fp16 ~ -50 %.
  * KHÔNG làm model chạy nhanh hơn. ĐO THẬT (ORT 1.24.4 CPU, 1 nhân, CNN 8 lớp Conv): DequantizeLinear của trọng số KHÔNG bị ORT gập lúc nạp, mỗi lần chạy phải giải
    lượng tử nên CHẬM hơn float (~76 ms so với ~54 ms); đổi lại bộ nhớ thường trú thấp hơn (RSS nạp +6 MB so với +16 MB, đo thô một lần). EP / phiên bản ORT khác (Android,
    QNN, NNAPI) có thể khác — đo trên MÁY ĐÍCH. Muốn chạy NHANH hơn dùng onnx_static_qdq.py (QDQ tĩnh có ảnh hiệu chuẩn: ORT fuse thành QLinearConv, đo ~3× nhanh hơn float
    trên CPU thử), còn công cụ này phù hợp khi mục tiêu chỉ là tệp nhỏ.
  * Độ chính xác KHÔNG được đảm bảo chung: luôn chạy --verify trên ảnh THẬT (--input-npy) trước khi dùng; ngưỡng mặc định cos >= 0.999, sai số L2 tương đối <= 5 %.
Không hỗ trợ: model có dữ liệu ngoài (external data, > 2 GB), opset < 13 với int8, trọng số nằm trong đồ thị con (If / Loop) — những thứ đó được bỏ qua và ghi vào báo cáo.
"""
import argparse
import os
import sys

import numpy as np

# ------------------------------------------------------------------ dây protobuf tối thiểu
FLOAT, INT8, FLOAT16 = 1, 3, 10          # TensorProto.DataType
A_FLOAT, A_INT, A_INTS = 1, 2, 7         # AttributeProto.AttributeType


def _varint(mv, pos):
    shift = 0
    val = 0
    while True:
        b = mv[pos]
        pos += 1
        val |= (b & 0x7F) << shift
        if not b & 0x80:
            return val, pos
        shift += 7
        if shift > 70:
            raise ValueError("varint quá dài (tệp không phải protobuf hợp lệ)")


def parse(buf):
    """Tách một message protobuf thành [(số_trường, loại_dây, giá_trị)], GIỮ MỌI trường (kể cả trường lạ) theo đúng thứ tự để ghi lại."""
    mv = memoryview(buf)
    pos, n, out = 0, len(mv), []
    while pos < n:
        key, pos = _varint(mv, pos)
        fno, wt = key >> 3, key & 7
        if fno == 0:
            raise ValueError("số trường 0 (tệp không phải protobuf hợp lệ)")
        if wt == 0:
            v, pos = _varint(mv, pos)
        elif wt == 1:
            v = bytes(mv[pos:pos + 8])
            pos += 8
        elif wt == 2:
            ln, pos = _varint(mv, pos)
            v = mv[pos:pos + ln]
            if len(v) != ln:
                raise ValueError("message bị cắt cụt")
            pos += ln
        elif wt == 5:
            v = bytes(mv[pos:pos + 4])
            pos += 4
        else:
            raise ValueError("wire type %d không hỗ trợ" % wt)
        out.append((fno, wt, v))
    return out


def enc_varint(v):
    v &= (1 << 64) - 1                    # số âm: bù hai 64 bit như protobuf
    out = bytearray()
    while True:
        b = v & 0x7F
        v >>= 7
        if v:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def emit(fields):
    out = bytearray()
    for fno, wt, v in fields:
        out += enc_varint((fno << 3) | wt)
        if wt == 0:
            out += enc_varint(v)
        elif wt == 2:
            out += enc_varint(len(v))
            out += v
        else:
            out += v
    return bytes(out)


def _str(fields, fno, default=""):
    for f, w, v in fields:
        if f == fno and w == 2:
            return bytes(v).decode("utf-8", "replace")
    return default


def _int(fields, fno, default=0):
    for f, w, v in fields:
        if f == fno and w == 0:
            return v
    return default


# ------------------------------------------------------------------ dựng các message ONNX (dùng cả cho bài kiểm)
def make_tensor(name, dims, dtype, raw):
    return emit([(1, 0, int(d)) for d in dims] + [(2, 0, dtype), (8, 2, name.encode()), (9, 2, raw)])


def make_attr_int(name, i):
    return emit([(1, 2, name.encode()), (3, 0, int(i)), (20, 0, A_INT)])


def make_attr_ints(name, ints):
    return emit([(1, 2, name.encode())] + [(8, 0, int(i)) for i in ints] + [(20, 0, A_INTS)])


def make_node(op, inputs, outputs, name="", attrs=()):
    f = [(1, 2, s.encode()) for s in inputs] + [(2, 2, s.encode()) for s in outputs] + [(3, 2, name.encode()), (4, 2, op.encode())]
    return emit(f + [(5, 2, a) for a in attrs])


def make_value_info(name, elem_type, dims):
    """dims: số nguyên hoặc chuỗi (tên chiều động)."""
    dim_msgs = [emit([(1, 0, d)] if isinstance(d, int) else [(2, 2, str(d).encode())]) for d in dims]
    shape = emit([(1, 2, d) for d in dim_msgs])
    tensor_type = emit([(1, 0, elem_type), (2, 2, shape)])
    return emit([(1, 2, name.encode()), (2, 2, emit([(1, 2, tensor_type)]))])


def make_model(nodes, initializers, inputs, outputs, opset=13, ir_version=8, graph_name="g"):
    graph = emit([(1, 2, n) for n in nodes] + [(2, 2, graph_name.encode())] + [(5, 2, t) for t in initializers]
                 + [(11, 2, i) for i in inputs] + [(12, 2, o) for o in outputs])
    return emit([(1, 0, ir_version), (8, 2, emit([(2, 0, opset)])), (7, 2, graph)])


# ------------------------------------------------------------------ đọc tensor / tính toán
def read_tensor(fields):
    """Trả (tên, dims, dtype, mảng numpy float32 hoặc None, lý do bỏ qua hoặc None)."""
    name = _str(fields, 8)
    dims = []
    for f, w, v in fields:
        if f == 1:
            if w == 0:
                dims.append(v)
            elif w == 2:                                   # dims dạng packed
                mv, pos = v, 0
                while pos < len(mv):
                    d, pos = _varint(mv, pos)
                    dims.append(d)
    dtype = _int(fields, 2)
    if any(f in (13,) for f, w, v in fields) or _int(fields, 14) == 1:
        return name, dims, dtype, None, "dữ liệu nằm ngoài tệp (external data) — không hỗ trợ"
    if dtype != FLOAT:
        return name, dims, dtype, None, "không phải float32"
    raw = next((v for f, w, v in fields if f == 9 and w == 2), None)
    if raw is not None:
        arr = np.frombuffer(raw, dtype="<f4")
    else:
        packed = next((v for f, w, v in fields if f == 4 and w == 2), None)
        if packed is None:
            return name, dims, dtype, None, "không có raw_data / float_data dạng packed"
        arr = np.frombuffer(packed, dtype="<f4")
    if int(np.prod(dims, dtype=np.int64)) != arr.size:
        return name, dims, dtype, None, "số phần tử không khớp dims"
    return name, dims, dtype, arr.reshape(dims) if dims else arr, None


def quantize_per_axis(w, axis):
    """INT8 đối xứng THEO KÊNH dọc `axis`: scale_c = max|w_c| / 127, q = round(w / scale) kẹp [-127, 127]. Trả (q int8 cùng hình, scale float32[C])."""
    c = w.shape[axis]
    wm = np.moveaxis(w, axis, 0).reshape(c, -1)
    amax = np.abs(wm).max(axis=1)
    scale = np.where(amax > 0, amax / 127.0, 1.0).astype(np.float32)
    q = np.clip(np.rint(wm / scale[:, None]), -127, 127).astype(np.int8)
    rest = [s for i, s in enumerate(w.shape) if i != axis]
    return np.ascontiguousarray(np.moveaxis(q.reshape([c] + rest), 0, axis)), scale


def dequantize_per_axis(q, scale, axis):
    shape = [1] * q.ndim
    shape[axis] = -1
    return q.astype(np.float32) * scale.reshape(shape)


def weight_axis(op, attrs, shape):
    """Trục KÊNH ĐẦU RA của trọng số (nơi chia scale theo kênh); None = không hỗ trợ."""
    r = len(shape)
    if op == "Conv":
        return 0 if r >= 3 else None
    if op == "ConvTranspose":
        return 1 if (attrs.get("group", 1) == 1 and r >= 3) else None
    if op == "MatMul":
        return r - 1 if r >= 2 else None
    if op == "Gemm":
        if r != 2:
            return None
        return 0 if attrs.get("transB", 0) else 1
    return None


def node_info(node_bytes):
    f = parse(node_bytes)
    inputs = [bytes(v).decode() for fno, w, v in f if fno == 1 and w == 2]
    attrs = {}
    for fno, w, v in f:
        if fno == 5 and w == 2:
            af = parse(v)
            if _int(af, 20) == A_INT:
                i = _int(af, 3)
                attrs[_str(af, 1)] = i - (1 << 64) if i >= (1 << 63) else i
    return _str(f, 4), _str(f, 7), inputs, attrs


# ------------------------------------------------------------------ lõi
def quantize_model(data, mode="int8", min_elements=4096):
    """Trả (bytes mới, báo cáo dict). Không ném lỗi khi gặp thứ không hỗ trợ — bỏ qua và ghi lý do; chỉ ném ValueError nếu tệp không phải ONNX."""
    if mode not in ("int8", "fp16"):
        raise ValueError("mode phải là int8 hoặc fp16")
    top = parse(data)
    gi = next((i for i, (f, w, v) in enumerate(top) if f == 7 and w == 2), None)
    if gi is None:
        raise ValueError("không thấy graph — tệp không phải model ONNX")
    opset = 1
    for f, w, v in top:
        if f == 8 and w == 2:
            of = parse(v)
            if _str(of, 1) in ("", "ai.onnx"):
                opset = _int(of, 2, 1)
    report = {"mode": mode, "opset": opset, "converted": [], "skipped": [], "bytes_in": len(data), "bytes_out": len(data)}
    if mode == "int8" and opset < 13:
        report["skipped"].append(("*", "opset %d < 13: DequantizeLinear theo kênh chưa có — không đổi gì" % opset))
        return data, report

    graph = parse(top[gi][2])
    inits, used_names = {}, set()
    for f, w, v in graph:
        if f == 5 and w == 2:
            inits[_str(parse(v), 8)] = v
        if f == 1 and w == 2:
            nf = parse(v)
            used_names.update(bytes(x).decode() for fno, ww, x in nf if fno in (1, 2) and ww == 2)
    graph_inputs = {_str(parse(v), 1) for f, w, v in graph if f == 11 and w == 2}
    graph_outputs = {_str(parse(v), 1) for f, w, v in graph if f == 12 and w == 2}
    used_names.update(inits)

    # ứng viên và trục
    plan = {}                               # tên -> trục (int8) hoặc None (fp16)
    if mode == "int8":
        want, conflict = {}, set()
        for f, w, v in graph:
            if f != 1 or w != 2:
                continue
            op, dom, ins, attrs = node_info(v)
            if dom not in ("", "ai.onnx") or len(ins) < 2 or op not in ("Conv", "ConvTranspose", "MatMul", "Gemm"):
                continue
            nm = ins[1]
            if nm not in inits:
                continue
            _, dims, _, arr, why = read_tensor(parse(inits[nm]))
            if arr is None:
                if why and not why.startswith("không phải float32") and (nm, why) not in report["skipped"]:
                    report["skipped"].append((nm, why))
                continue
            ax = weight_axis(op, attrs, dims)
            if ax is None:
                report["skipped"].append((nm, "%s với hình %s chưa hỗ trợ" % (op, dims)))
                continue
            if nm in want and want[nm] != ax:
                conflict.add(nm)
            want[nm] = ax
        for nm in conflict:
            want.pop(nm, None)
            report["skipped"].append((nm, "dùng cho nhiều toán tử cần trục khác nhau"))
        plan = want
    else:
        for nm in inits:
            plan[nm] = None

    new_nodes, new_inits, drop = [], [], set()
    for nm in sorted(plan):
        if nm in graph_inputs or nm in graph_outputs:
            report["skipped"].append((nm, "đồng thời là input / output của đồ thị (IR cũ) — bỏ qua"))
            continue
        _, dims, _, arr, why = read_tensor(parse(inits[nm]))
        if arr is None:
            if why and not why.startswith("không phải float32") and (nm, why) not in report["skipped"]:
                report["skipped"].append((nm, why))
            continue
        if arr.size < min_elements:
            continue
        if not np.all(np.isfinite(arr)):
            report["skipped"].append((nm, "có NaN / Inf"))
            continue
        base = nm
        for suf in ("_int8", "_scale", "_dq", "_fp16", "_cast"):
            while base + suf in used_names:
                base += "_"
        if mode == "int8":
            ax = plan[nm]
            q, scale = quantize_per_axis(arr, ax)
            err = float(np.abs(dequantize_per_axis(q, scale, ax) - arr).max())
            new_inits.append(make_tensor(base + "_int8", dims, INT8, q.tobytes()))
            new_inits.append(make_tensor(base + "_scale", [len(scale)], FLOAT, scale.astype("<f4").tobytes()))
            new_nodes.append(make_node("DequantizeLinear", [base + "_int8", base + "_scale"], [nm], base + "_dq", [make_attr_int("axis", ax)]))
            report["converted"].append((nm, list(dims), "axis=%d" % ax, err))
        else:
            amax = float(np.abs(arr).max()) if arr.size else 0.0
            if amax >= 65000:
                report["skipped"].append((nm, "biên độ %.0f vượt giới hạn float16" % amax))
                continue
            new_inits.append(make_tensor(base + "_fp16", dims, FLOAT16, arr.astype("<f2").tobytes()))
            new_nodes.append(make_node("Cast", [base + "_fp16"], [nm], base + "_cast", [make_attr_int("to", FLOAT)]))
            report["converted"].append((nm, list(dims), "fp16", float(np.abs(arr.astype("<f2").astype(np.float32) - arr).max())))
        drop.add(nm)

    if not drop:
        return data, report
    out_fields, inserted = [], False
    for f, w, v in graph:
        if f == 5 and w == 2 and _str(parse(v), 8) in drop:
            continue
        if f == 1 and w == 2 and not inserted:
            out_fields += [(1, 2, nb) for nb in new_nodes]
            inserted = True
        out_fields.append((f, w, v))
    if not inserted:
        out_fields += [(1, 2, nb) for nb in new_nodes]
    out_fields += [(5, 2, t) for t in new_inits]
    top = list(top)
    top[gi] = (7, 2, emit(out_fields))
    result = emit(top)
    report["bytes_out"] = len(result)
    return result, report


# ------------------------------------------------------------------ kiểm tra độ chính xác bằng onnxruntime
def metrics(ref, got):
    a = np.asarray(ref, dtype=np.float64).ravel()
    b = np.asarray(got, dtype=np.float64).ravel()
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    cos = float(a @ b / (na * nb)) if na > 0 and nb > 0 else (1.0 if na == nb else 0.0)
    rel = float(np.linalg.norm(a - b) / na) if na > 0 else float(np.linalg.norm(a - b))
    rmse = float(np.sqrt(np.mean((a - b) ** 2)))
    rng = float(a.max() - a.min()) if a.size else 0.0
    psnr = float("inf") if rmse == 0 else (20 * np.log10(rng / rmse) if rng > 0 else float("-inf"))
    return {"cos": cos, "rel_l2": rel, "max_abs": float(np.abs(a - b).max()), "psnr_db": float(psnr)}


def verify(path_a, path_b, samples=None, seed=0, runs=3, dyn_default=64):
    """Chạy hai model bằng onnxruntime (CPU) trên cùng đầu vào, trả danh sách số đo theo từng đầu ra. `samples`: {tên_input: mảng numpy} (nên là ảnh THẬT)."""
    import onnxruntime as ort
    so = ort.SessionOptions()
    so.log_severity_level = 3
    sa = ort.InferenceSession(path_a, so, providers=["CPUExecutionProvider"])
    sb = ort.InferenceSession(path_b, so, providers=["CPUExecutionProvider"])
    rng = np.random.default_rng(seed)
    results = []
    for r in range(1 if samples else runs):
        feeds = {}
        for i in sa.get_inputs():
            if samples and i.name in samples:
                feeds[i.name] = samples[i.name]
                continue
            shape = [d if isinstance(d, int) and d > 0 else (1 if k == 0 else dyn_default) for k, d in enumerate(i.shape)]
            if "float" in i.type:
                feeds[i.name] = rng.random(shape).astype(np.float16 if "16" in i.type else np.float32)
            else:
                feeds[i.name] = rng.integers(0, 8, shape).astype(np.int64 if "64" in i.type else np.int32)
        for oa, ob, meta in zip(sa.run(None, feeds), sb.run(None, feeds), sa.get_outputs()):
            m = metrics(oa, ob)
            m["output"] = meta.name
            results.append(m)
    return results


def main(argv=None):
    ap = argparse.ArgumentParser(description="Nén trọng số ONNX (int8 theo kênh / fp16) không cần gói onnx")
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--mode", choices=("int8", "fp16"), default="int8")
    ap.add_argument("--min-elements", type=int, default=4096, help="chỉ nén hằng số có ít nhất ngần này phần tử (mặc định 4096)")
    ap.add_argument("--verify", action="store_true", help="chạy cả hai model bằng onnxruntime và đo sai khác")
    ap.add_argument("--input-npy", action="append", default=[], metavar="TÊN=FILE.npy", help="dùng ảnh THẬT làm đầu vào kiểm (nên dùng)")
    ap.add_argument("--min-cos", type=float, default=0.999)
    ap.add_argument("--max-rel-l2", type=float, default=0.05)
    a = ap.parse_args(argv)
    with open(a.src, "rb") as fh:
        data = fh.read()
    out, rep = quantize_model(data, a.mode, a.min_elements)
    print("Model: %s -> %s (%s, opset %d)" % (a.src, a.dst, a.mode, rep["opset"]))
    print("Đã nén %d hằng số, bỏ qua %d." % (len(rep["converted"]), len(rep["skipped"])))
    for nm, why in rep["skipped"][:20]:
        print("  bỏ qua %s: %s" % (nm, why))
    if rep["converted"]:
        print("  sai số lớn nhất của một trọng số: %.3g" % max(c[3] for c in rep["converted"]))
    saved = 100.0 * (1 - rep["bytes_out"] / rep["bytes_in"]) if rep["bytes_in"] else 0.0
    print("Cỡ tệp: %.2f MB -> %.2f MB (giảm %.1f %%). LƯU Ý: đây chủ yếu là nén cỡ tệp; trên ORT CPU đã đo thì model chạy CHẬM hơn float (giải lượng tử mỗi lần chạy) — muốn nhanh dùng onnx_static_qdq.py." % (rep["bytes_in"] / 1e6, rep["bytes_out"] / 1e6, saved))
    with open(a.dst, "wb") as fh:
        fh.write(out)
    if not a.verify:
        print("Chưa kiểm độ chính xác — hãy chạy lại với --verify (tốt nhất kèm --input-npy ảnh thật).")
        return 0
    samples = {}
    for item in a.input_npy:
        k, _, p = item.partition("=")
        samples[k] = np.load(p)
    res = verify(a.src, a.dst, samples or None)
    bad = 0
    for m in res:
        good = m["cos"] >= a.min_cos and m["rel_l2"] <= a.max_rel_l2
        bad += 0 if good else 1
        print("  %-24s cos=%.6f  L2tđ=%.4f  maxabs=%.4g  PSNR=%.1f dB  %s" % (m["output"], m["cos"], m["rel_l2"], m["max_abs"], m["psnr_db"], "ĐẠT" if good else "KHÔNG ĐẠT"))
    if not samples:
        print("  (đầu vào là số ngẫu nhiên — chỉ chứng minh model chạy được và sai khác nhỏ, KHÔNG thay cho thử trên ảnh thật)")
    return 2 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
