# Công cụ nén model ONNX (R30c / R30e)

Cả hai công cụ chạy **không cần gói `onnx`** (chỉ numpy; thêm onnxruntime cho `--verify` và hiệu chuẩn). ONNX là protobuf nên công cụ tự đọc / ghi dây protobuf, giữ nguyên mọi trường không đụng tới.

## 1. `onnx_weight_quant.py` — chỉ nén TRỌNG SỐ (int8 theo kênh / fp16)
```
python3 tools/convert_models/onnx_weight_quant.py vao.onnx ra.onnx --mode int8 --verify --input-npy x=anh_that.npy
```
- Mục tiêu: **tệp nhỏ** (int8 ≈ −70 %, fp16 ≈ −50 % phần trọng số). **Không nhanh hơn**: đo trên ORT 1.24 CPU thì chạy CHẬM hơn float ~40 % vì DequantizeLinear của trọng số không bị gập; đổi lại RSS thường trú thấp hơn (đo thô một lần: +6 MB so với +16 MB). Máy đích có thể khác — đo lại.

## 2. `onnx_static_qdq.py` — lượng tử hóa TĨNH QDQ (kích hoạt uint8 + trọng số int8 theo kênh + bias int32)
```
python3 tools/convert_models/onnx_static_qdq.py vao.onnx ra.onnx --calib-npy x=a.npy --calib-npy x=b.npy ... --verify
```
- Cần **ảnh hiệu chuẩn THẬT** (20–200 mẫu cùng phân phối với lúc chạy; `--percentile 99.99` để cắt ngoại lai). Số ngẫu nhiên chỉ thử đường ống.
- Định dạng QDQ chuẩn ONNX Runtime — là định dạng QNN / NNAPI cần để chạy int8 trên NPU. Trên ORT CPU thử: Conv / MatMul được **fuse thành QLinearConv / QLinearMatMul** (`--verify` in số toán tử fuse được) và chạy nhanh hơn float ~3× trên CNN 8 lớp (CPU 1 nhân của sandbox, KHÔNG phải điện thoại).
- Chỉ Conv / MatMul / Gemm có trọng số float32 hằng số; Conv đi thẳng vào Relu được quantize sau Relu; đầu ra cuối của đồ thị giữ float. Không hỗ trợ opset < 13, external data, đồ thị con, ConvTranspose.
- `--verify` đo bằng chính mẫu hiệu chuẩn đầu tiên — **hãy thử thêm ảnh KHÔNG nằm trong tập hiệu chuẩn** và nhìn đầu ra bằng mắt.

## Kiểm thử
`python3 tools/verify_ports/onnx_weight_quant.py` và `python3 tools/verify_ports/onnx_static_qdq.py` (model dựng tay + ONNX Runtime thật; đột biến đều bị bắt). **Chưa chạy trên model thật** (U²-Net, MI-GAN, LaMa, IS-Net, Real-ESRGAN…) — chất lượng thật chỉ biết sau T131 / T133.
