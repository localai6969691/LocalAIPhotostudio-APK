#!/usr/bin/env python3
"""R41: sinh cấu hình định tuyến "an toàn giấy phép dữ liệu" từ app/src/main/assets/routing_default.json (không bị lệch khi default đổi).
Bỏ khỏi `inpaint_remove` các engine dùng trọng số huấn luyện trên Places2 (LaMa `lama_onnx`, MI-GAN `migan_onnx`); còn PatchMatch + thuật toán cổ điển
(không cần trọng số). Dùng: python3 tools/make_routing_variant.py  -> tools/routing_samples/routing_commercial_safe.json
Cách áp dụng trong app: nhập tệp này làm cấu hình định tuyến (filesDir/routing.json, hoặc tải từ URL https — xem routing/Routing.kt)."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'app/src/main/assets/routing_default.json')
DST = os.path.join(ROOT, 'tools/routing_samples/routing_commercial_safe.json')
BLOCK = {'lama_onnx', 'migan_onnx'}
cfg = json.load(open(SRC, encoding='utf-8'))
removed = []
def walk(o):
    if isinstance(o, dict):
        if isinstance(o.get('providers'), list):
            keep = []
            for p in o['providers']:
                (removed if p.get('kind') in BLOCK else keep).append(p.get('id') if p.get('kind') in BLOCK else p)
            o['providers'] = keep
        for v in o.values(): walk(v)
    elif isinstance(o, list):
        for v in o: walk(v)
walk(cfg)
# kiểm: inpaint_remove vẫn có đường lùi không cần model
caps = cfg['tasks']
inp = caps['inpaint_remove']['providers']
assert inp and all(not p.get('needs') for p in inp), 'inpaint_remove còn provider cần tệp: ' + str(inp)
assert inp[-1]['kind'] == 'classic_fill', 'đường lùi cuối phải là classic_fill'
assert not [p for c in caps.values() if isinstance(c, dict) for p in c.get('providers', []) if p.get('kind') in BLOCK]
cfg['_note'] = 'Sinh bởi tools/make_routing_variant.py từ routing_default.json; đã bỏ: ' + ', '.join(removed) + ' (trọng số huấn luyện trên Places2). Chất lượng xóa vật thể lớn thấp hơn.'
os.makedirs(os.path.dirname(DST), exist_ok=True)
json.dump(cfg, open(DST, 'w', encoding='utf-8'), ensure_ascii=False, indent=2); open(DST, 'a').write('\n')
print('đã bỏ:', removed, '| inpaint_remove còn:', [p['id'] for p in inp], '->', os.path.relpath(DST, ROOT))
