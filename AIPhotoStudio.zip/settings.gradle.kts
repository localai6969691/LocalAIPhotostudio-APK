pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    // R31: bản nhắm API 36 (Google Play bắt buộc từ 31/8/2026) cần Android Gradle Plugin >= 8.9.1 (bảng "Minimum versions of tools for Android API
    // level" ở developer.android.com/studio/releases) và AGP 8.9 cần Gradle >= 8.11.1. Mặc định (bản tester) GIỮ nguyên AGP 8.5.2; chỉ khi
    // workflow bật `play_release` (biến môi trường PLAY_RELEASE=true; trong khối pluginManagement chỉ đọc được biến môi trường, không đọc được -P)
    // thì nâng lên 8.9.1 ở đây — một chỗ duy nhất, không động tới bản tester.
    resolutionStrategy {
        eachPlugin {
            if (requested.id.id == "com.android.application" && System.getenv("PLAY_RELEASE") == "true") {
                useVersion("8.9.1")
            }
        }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AIPhotoStudio"
include(":app")
