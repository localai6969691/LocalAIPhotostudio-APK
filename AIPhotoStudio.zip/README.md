# AI Photo Studio

> Tiến độ, việc tồn đọng, kỹ thuật đã chọn/đã lỗi: xem **[PROJECT_STATUS.md](PROJECT_STATUS.md)** (đọc trước khi tiếp tục dự án).

Ứng dụng Android chỉnh sửa / làm đẹp ảnh **bằng prompt** thay vì dùng công cụ thủ công kiểu Photoshop.
Chỉnh màu, retouch, xóa vật thể, tách nền, chọn vùng chạy **cục bộ trên điện thoại**; riêng **thêm/thay vật thể** đi qua đường định tuyến
(máy chủ của bạn → Gemini → SD LAN, hoặc stable-diffusion.cpp chạy ngay trên máy nếu đã cài) — chỉ phần ảnh quanh vùng tô được gửi đi.

```
Prompt ──► [LLM cục bộ (tùy chọn) | Bộ quy tắc offline] ──► Kế hoạch chỉnh sửa (JSON)
                                                                │
Ảnh ◄── ImageEngine (màu, da, nét, vignette, tách nền ONNX…) ◄──┘
```

> **Tester:** đọc **[TESTER_GUIDE.md](TESTER_GUIDE.md)** (chuẩn bị khóa/model, cách gửi thông tin lỗi ngay trong app: *Cài đặt → Gửi thông tin lỗi*).

## 1. Build APK trên GitHub

1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions** → workflow **Build APK** tự chạy (hoặc bấm *Run workflow*).
3. Chạy xong, mở lần chạy đó → mục **Artifacts** → tải `AIPhotoStudio-debug-apk` → giải nén ra `app-debug.apk` → cài lên máy.

**Cách nhanh nhất trên điện thoại — chỉ up file zip (R34d):** trong repo chỉ cần có (1) `.github/workflows/build-apk.yml` (GitHub chỉ chạy workflow nằm trong chính repo) và (2) file zip dự án (vd `AIPhotoStudio.zip`) ở **gốc repo**. Mỗi job của Actions tự giải nén zip vào workspace (ghi đè, chịu được zip có/không có thư mục bọc) rồi build — không cần giải nén hay đẩy từng thư mục. Có bản mới: up đè zip cùng tên; nếu workflow có đổi thì thay luôn `build-apk.yml` (bước đầu của run báo *notice* khi workflow trong repo khác bản trong zip). Chỉ giữ MỘT zip dự án trong repo (nhiều zip thì zip tên "lớn" nhất theo `sort -V` thắng).

Workflow dùng `gradle/actions/setup-gradle` (cache dependencies + build cache) và chỉ build ABI `arm64-v8a`
để rút ngắn thời gian. Lần build đầu chậm nhất; các lần sau nhanh hơn rõ rệt.
Không cần `gradlew`/`gradle-wrapper.jar` vì CI cài sẵn Gradle 8.7.
(Muốn build local: cài Gradle 8.7 rồi `gradle :app:assembleDebug`.)

**Cài đè bản mới (R24):** bản debug được ký bằng khóa **cố định** `app/debug.keystore` (khóa công khai, mật khẩu `android`), nên bản build sau cài ĐÈ lên bản trước được mà không phải gỡ app và không mất model đã nạp. Khóa này chỉ dành cho bản thử — **bản bán phải ký bằng khóa release riêng**. (Chưa kiểm với Android Gradle Plugin thật: nếu cài đè vẫn báo xung đột chữ ký, xem `signingConfigs` trong `app/build.gradle.kts`.)

## 2. Cách dùng

1. **Mở ảnh** → gõ yêu cầu (hoặc bấm chip gợi ý) → **Chỉnh**.
2. App hiện *kế hoạch* (các bước AI hiểu được) + bản xem trước. Kéo thanh **Cường độ** để tăng/giảm toàn bộ hiệu ứng.
3. **Giữ ngón tay** lên ảnh để xem ảnh gốc. **Áp dụng** để chốt, rồi tiếp tục gõ yêu cầu khác. **Hoàn tác/Làm lại** có sẵn.
4. **Lưu** → ảnh vào `Pictures/AIPhotoStudio` (PNG nếu có nền trong suốt, còn lại JPEG).

Ví dụ prompt (tiếng Việt hoặc tiếng Anh, có thể ghép bằng dấu phẩy / "và"):

- `làm đẹp tự nhiên` · `làm da mịn hơn, sáng hơn, tông ấm`
- `tăng tương phản 30%, giảm bão hòa màu` · `rất nhiều chi tiết, làm nét`
- `tông điện ảnh` · `vintage` · `đen trắng` · `ảnh thiếu sáng`
- `xóa nền, nền trắng` · `ảnh thẻ nền xanh` · `mờ phông` *(cần model tách nền)*
- `xoay phải 90 độ` · `lật ngang` · `cắt vuông` · `cắt 16:9` · `phóng to 2x`


## 2b. Thêm / xóa vật thể (tạo sinh)

1. Bấm **Tô vùng**, tô lên vật thể cần xóa hoặc vùng muốn thêm vật thể (chỉnh cỡ cọ bằng thanh trượt).
2. **Xóa:** để trống prompt hoặc gõ "xóa" → chạy **LaMa trên máy** (cần nạp `lama.onnx` trong *Model AI*).
3. **Thêm/thay:** gõ mô tả ("thêm một con mèo", "đổi thành áo đỏ") → **Cloud (Gemini)** hoặc **Máy chủ SD (LAN)**, chọn trong *Model AI*. Máy chỉ gửi phần ảnh quanh vùng tô, rồi dán kết quả về đúng vùng đó nên phần còn lại giữ nguyên.
4. Xem kết quả → **Áp dụng** / **Tạo lại** / **Bỏ**. Không tô vùng nhưng nêu vị trí ("thêm con mèo bên phải") cũng được: app tự tạo vùng elip gần đúng.
5. **Xóa đúng vùng tô (R21):** mặc định engine nới và làm mờ viền vùng tô vài điểm ảnh để lấp tự nhiên (PatchMatch ≈ 4 px, thuật toán cổ điển ≈ 8 px, LaMa/MI-GAN nới theo cỡ ảnh). Muốn **ngoài nét tô không đổi một điểm ảnh** → bật chip **"Xóa đúng vùng tô"** hoặc gõ "xóa chính xác" / "đúng vùng tô" / "exactly". Vùng bên trong nét tô vẫn là nội dung được SINH ra (không phải khôi phục ảnh gốc). Nếu nét tô không phủ hết viền vật thể, phần viền còn lại sẽ còn nguyên.
6. **Xóa người lạ (R20/R21):** gõ "xóa người lạ" (không cần tô) → app giữ người lớn nhất/nhóm người cùng cỡ, xóa người nhỏ/xa hơn. Cần `face_landmarker.task`; muốn nhận cả **người quay lưng / mặt quá nhỏ** thì nạp thêm `efficientdet_lite0.tflite` (Cài đặt → Phát hiện người, tùy chọn). Người còn sót → tô tay.


## 2c. Chỉnh ảnh không phá hủy (lớp, mặt nạ, công cụ chuyên nghiệp)

- Mọi chỉnh sửa (thanh trượt, Looks, AI) là một **lớp** riêng: ẩn/hiện, đổi độ mờ, chế độ hòa trộn, sắp xếp, xóa; ảnh gốc không đổi. Mở thẻ **Lớp** để quản lý.
- **Công cụ → Nâng cao:** Levels, **Curves** (kéo thả, từng kênh), **HSL** theo 8 dải màu. **Chi tiết:** Clarity, Retouch da (tách tần số), Hạt film…
- **Công cụ → Cục bộ:** chỉnh riêng một vùng bằng mặt nạ: vùng sáng/tối, bầu trời, chủ thể (AI), tâm ảnh, gradient, tô tay, Dodge/Burn.
- **Looks:** **80 look dựng sẵn** + ô **"Tìm look"** (không phân biệt dấu/hoa thường); một chạm, kéo Cường độ; lưu công thức của bạn và áp dụng **hàng loạt** cho nhiều ảnh.
- **Cắt / Xoay:** xoay, lật, cắt tỉ lệ, phóng to, tách nền (các thao tác này gộp lớp vào ảnh, vẫn hoàn tác được).
- **Cài đặt → Định tuyến model:** thứ tự model/dịch vụ cho từng tác vụ nằm trong tệp JSON (có thể cập nhật từ URL https hoặc tệp), tự rơi sang phương án kế tiếp khi lỗi hoặc thiếu model.


## 2c-bis. Công cụ chuyên nghiệp bổ sung (R11)

- **Công cụ → Ánh sáng / Màu / Chi tiết:** **Vùng sáng** (kéo âm để cứu vùng cháy sáng, vùng tối/trung bình không đổi), **Khử sương mù**, **Vibrance** (tăng màu nhạt, bảo vệ da), **Xanh lá ↔ Tím** (sửa ám màu đèn), **Kết cấu (Texture)**. Gõ thẳng: `giảm vùng sáng`, `khử sương mù`, `tăng vibrance`, `thêm magenta`, `làm mịn kết cấu`.
- **Looks → "+ Nhập LUT (.cube)":** nhập LUT 3D (17³–65³) từ DaVinci Resolve / Lightroom; mỗi LUT thành một lớp, kéo **Cường độ** để chỉnh. LUT 1D chưa hỗ trợ (có báo lỗi rõ).
- **Hiệu ứng → Thay bầu trời:** tự nhận bầu trời nối với mép trên ảnh (không cần model) rồi thay bằng trời xanh / hoàng hôn / chạng vạng / âm u / đêm sao. Gõ `thay bầu trời hoàng hôn`. Phạm vi "Chỉ trời" cũng dùng bộ nhận diện này.
- **Lớp → "+ Chữ", "+ Phơi sáng kép", "+ Ảnh phủ":** chữ nhiều dòng (màu, đậm, viền, xoay), phơi sáng kép (ảnh phủ chế độ Screen), ảnh phủ; đều là lớp không phá hủy, chỉnh lại bất cứ lúc nào.
- **AI Brush → "Quick Selection" và "Lasso (vòng)":** *Quick Selection* — tô một nét ngắn bên trong vật, vùng chọn tự lan theo màu và dừng ở cạnh (chỉnh thanh **Dung sai**; tô thêm để mở rộng). *Lasso* — vẽ một vòng khép kín, tạo ngay lớp cục bộ có mặt nạ vector (sắc nét ở mọi độ phân giải, lưu được trong công thức).
- **Công cụ → Chi tiết → "Xóa bụi & xước":** xóa bụi, vết xước, sợi mảnh (kiểu Dust & Scratches). Gõ `xóa bụi`, `xóa vết xước`, `xóa sợi tóc lạc` (chỉ tác động lên da và nền, không đụng tóc thật / lông mi). Cường độ cao sẽ làm mịn kết cấu thật nên nên dùng vừa phải.
- **Hiệu ứng → Thay bầu trời → "+ Ảnh trời của tôi":** dùng chính ảnh trời của bạn (nhập một lần, dùng lại cho mọi ảnh).
- **Lớp:** chạm lớp chữ/ảnh phủ rồi **kéo trên ảnh để di chuyển, hai ngón để phóng to/xoay**; nút **"↳ Cắt theo lớp dưới"** (clipping mask) để một lớp chỉ tác dụng trong phạm vi của lớp ngay bên dưới (vd. màu chỉ lên phần chữ); nút **"Lịch sử"** liệt kê từng bước — chạm để quay về bước đó.
- **Phiên làm việc tự lưu:** sau mỗi lần chỉnh, app tự lưu ảnh nền + toàn bộ lớp. Lần sau mở app, ở màn hình chưa có ảnh bấm **Khôi phục phiên trước** để tiếp tục chỉnh sửa đúng từng thông số. Nút **↗** trên thanh trên để chia sẻ ảnh (Android 10+).

## 2d. Chạm chọn, xóa nhẹ, phóng to AI, chế độ thương mại

- **Chạm chọn:** nạp 2 tệp MobileSAM (encoder + decoder, ONNX) → thẻ AI → *Chạm chọn* → chạm lên vật thể (chạm thêm để mở rộng) → *Chỉnh* (trống = xóa, hoặc mô tả để thay) hoặc *Tạo lớp cục bộ*.
- **Xóa vật thể:** tự chọn engine theo máy: LaMa (RAM ≥ 6 GB) → MI-GAN (nhẹ) → thuật toán cổ điển không cần model.
- **Phóng to AI:** nạp Real-ESRGAN-General-x4v3 (ONNX) → Cắt/Xoay → *Phóng to ×2* hoặc *Phóng to ×4* (R30). Cạnh dài ảnh sau phóng tối đa 4096 điểm để máy không hết bộ nhớ — ảnh lớn xin ×4 sẽ chỉ được hệ số nhỏ hơn và app báo con số thực tế; chưa nạp model thì phóng bằng nội suy + làm nét (mềm hơn).
- **Mượt trên mọi máy:** app đo RAM để chọn kích thước ảnh/xem trước/số luồng; khi kéo thanh trượt chỉ tính lại lớp đang sửa và hiển thị bản xem trước thấp, thả tay thì nét lại.
- **Bản thương mại:** chạy `backend/server.py` (xem `backend/README.md`), trong app nhập địa chỉ máy chủ → Đăng ký → Đồng bộ cấu hình. Khóa AI nằm ở máy chủ, mỗi lần tạo ảnh trừ credits.


## 2e. Tạo ảnh NGAY TRÊN MÁY (thử nghiệm)

Dùng stable-diffusion.cpp (MIT) chạy `sd-server` cục bộ: không cần mạng, không tốn credits. Điều kiện: APK có `libsd_server.so` (job CI `build-sd-server`), máy RAM ≥ 6 GB, và bạn nạp model **inpainting SD 1.5** trong Cài đặt (tùy chọn thêm LoRA LCM để tạo ảnh chỉ ~6 bước). Lần tạo đầu chậm vì phải nạp model; nếu lỗi/quá chậm app tự chuyển sang máy chủ của bạn hoặc Gemini. Chưa đo tốc độ trên máy thật.


## 2f. Công cụ nâng cao thêm sau

- **Select-and-Do:** chạm chọn vật thể → chọn việc: Xóa / Làm mờ / Mờ nền / Sáng / Tối / Tăng màu / Đen trắng / Nền đen trắng.
- **Retouch:** *Clone Stamp* và *Heal Brush* (Công cụ → Cục bộ), *Liquify* đẩy/biến dạng không phá hủy, *Chỉnh thẳng* (Cắt/Xoay) tự cắt viền trống.
- **Màu & hiệu ứng:** Cân bằng màu (bóng/giữa/sáng), Khớp màu với ảnh mẫu (Looks), Khử nhiễu, Mờ chuyển động / xuyên tâm.
- **Thông minh:** chip gợi ý theo nội dung ảnh (thiếu sáng, thiếu tương phản, chân dung, ảnh mờ…), Nhanh/Chất lượng + Nâng cao (seed, prompt phủ định, độ thay đổi), "Phong cách của tôi" học từ cách bạn chỉnh.
- **Chỉnh sửa theo chỉ dẫn trên máy:** FLUX.2 [klein] 4B (Apache-2.0) qua `sd-server` — cần 3 tệp (diffusion `.gguf`, LLM Qwen3 `.gguf`, VAE); chậm trên điện thoại, nên dùng máy chủ GPU tự host (`UPSTREAM=openai_edits`) cho chất lượng cao.

## 2g. Retouch theo khuôn mặt, kế hoạch theo vùng, Refine Edge (R9)

- **Khuôn mặt:** nạp `face_landmarker.task` (MediaPipe, Cài đặt) → *Công cụ → Cục bộ* → **Da mặt / Mắt / Răng / Quầng thâm** (mỗi nút tạo một lớp có mặt nạ ôm đúng vùng, kéo thanh trượt để chỉnh). Chưa nạp model thì *Da mặt* dùng nhận diện màu da; các vùng còn lại cần model.
- **Gõ yêu cầu theo vùng:** `làm trắng răng`, `làm sáng mắt`, `xóa quầng thâm`, `bầu trời xanh hơn` / `ấn tượng hơn` / `hoàng hôn`, `làm tối nền`, `làm nổi bật chủ thể` → mỗi vùng thành một lớp riêng. Có thể ghép: `da mịn, răng trắng, bầu trời xanh hơn`. *(Viết \"mắt\" có dấu — không dấu thì trùng với \"mặt\".)*
- **Chạm chọn không cần SAM:** chưa nạp MobileSAM thì app dùng *đũa thần* (chọn vùng liền kề cùng màu); có SAM thì chọn theo vật thể.
- **Tách nền chất lượng cao:** nạp thêm IS-Net (`isnet-general-use.onnx`, máy RAM ≥ 4 GB) — app tự ưu tiên nó trước U²-Net-P. Khi tách nền, viền được **khử màu nền cũ**.
- **Mặt nạ:** tab *Lớp* có *Làm mềm biên* và **Dịch biên (co ↔ nở)**.
- **Cắt/Xoay → Phối cảnh dọc/ngang:** sửa đường thẳng đứng hội tụ (không để lại viền trống).
- **Dodge & Burn tự động:** gõ `làm nổi khối` (hoặc `contour`, `dodge burn`) hoặc bấm *Nổi khối* trong *Cục bộ* → hai lớp: nâng vùng sáng, đào sâu vùng tối của da mặt.
- **Màu chọn lọc (CMYK theo 9 dải màu)** trong *Công cụ → Màu*, chế độ Tương đối/Tuyệt đối như Photoshop (mô phỏng, không trùng từng điểm ảnh); thêm **Sắc độ** và **Lens flare** (tab Chi tiết).
- **Chạm chọn vật thể → Đổi màu / Xóa / Làm mờ…** trên thanh hành động.
- **Công thức & chỉnh hàng loạt giờ mang theo cả điều chỉnh cục bộ:** lớp theo vùng (răng, mắt, bầu trời, chủ thể…) được dựng lại mặt nạ RIÊNG cho từng ảnh; mặt nạ tô tay không chuyển sang ảnh khác được nên bị bỏ (app báo rõ).
- **Khóa API và token** lưu mã hóa bằng Android Keystore.

## 2h. Filter Gallery, tóc, Warp, Liquify khuôn mặt, gói Free/Pro, Agent AI (R10)

- **Hiệu ứng mới** (*Công cụ → Hiệu ứng*): Phát sáng (Orton), Matte, Phác họa bút chì, Emboss, Posterize, Pixel hóa, Lệch màu (Chromatic), Duotone (4 preset). Gõ `phác họa`, `pixel hóa`, `phát sáng`, `matte`, `posterize`… cũng được.
- **Tóc:** nạp `hair_segmenter.tflite` (MediaPipe, *Cài đặt*) → *Cục bộ → Tóc*: **Nhuộm** Đen/Nâu/Vàng/Đỏ/Cam/Hồng/Tím/Xanh/Bạc hoặc **Tóc bóng mượt**; hoặc gõ `nhuộm tóc màu nâu`, `tóc bóng mượt`, `hair blue`. Chưa có: xóa sợi tóc lạc, tăng volume.
- **Dáng khuôn mặt** (cần model khuôn mặt): 4 thanh trượt *Thon hàm / To mắt / Thu cánh mũi / Nâng khóe môi* (Liquify sinh từ 478 điểm, tinh chỉnh tiếp bằng cọ Liquify).
- **Warp lưới / Free Transform:** *Cục bộ → Warp lưới* → kéo các điểm trắng (4 góc = co giãn/nghiêng). **Patch:** tô khuyết điểm → *Chọn nguồn* → chạm vùng sạch.
- **Mặt nạ theo kênh màu** (R/G/B, bão hòa, tối, sáng Lab, hồng-đỏ, vàng) và **Vùng nét / Vùng mờ (Focus Area)** trong *Cục bộ*; **AI Brush:** khi tô mặt nạ chọn *Chỉ da / tóc / chủ thể / trời / nền* để nét tô chỉ nhận trong vùng đó.
- **Faves + vuốt để chỉnh:** bấm ☆ cạnh thanh trượt để ghim vào tab *★ Faves*; khi tab Công cụ mở, **vuốt ngang trên ảnh** để chỉnh thông số đang chọn, **vuốt dọc** để đổi thông số.
- **Bản thương mại — gói Free/Pro:** gói Free có watermark khi xuất ảnh và không dùng chất lượng cao; gói Pro (mua "30 ngày"/"365 ngày") bỏ giới hạn. *Chỉ áp dụng khi dùng máy chủ của bạn*; chế độ cá nhân (không máy chủ) không có watermark. **Agent AI nhìn ảnh:** bật chip trong thẻ AI → máy chủ gửi ảnh thu nhỏ cho Gemini để lập kế hoạch chỉnh (Pro miễn phí, Free 1 credit/lần). Mua hàng cần build với `-PuseBilling=true` (xem PROJECT_STATUS 11).

## 2i. Cắt theo chủ thể, di chuyển vật thể, gửi thông tin lỗi (R24)

- **Auto Frame (cắt theo chủ thể):** *Cắt/Xoay* → chip **"Auto: siết khung"** (giữ tỉ lệ ảnh, ôm sát chủ thể) hoặc **"Auto 1:1 / 4:5 / …"**; hoặc gõ `cắt 4:5 theo chủ thể`, `auto frame`, `cắt thông minh`. App giữ trọn khuôn mặt, chừa lề, đặt chủ thể gần điểm 1/3 và chỉ phóng tối đa 2×. Dùng độ nổi bật màu (không cần model); nếu đã nạp model tách nền/khuôn mặt thì dùng thêm. Ảnh đã vừa khung thì app chỉ báo, không đổi gì. Hoàn tác một lần.
- **Di chuyển vật thể:** *Chạm chọn* một vật → chip **"Di chuyển"** → vật được tách thành lớp ảnh trong suốt đặt đúng chỗ cũ, chỗ cũ được lấp bằng engine xóa sẵn có; thẻ *Lớp* mở sẵn để **kéo / chụm / xoay** vật sang chỗ mới. Hoàn tác một lần trả cả hai lớp. Viền là mặt nạ làm mềm (không phải tách tóc chuyên nghiệp), độ đẹp chỗ lấp phụ thuộc engine xóa đang dùng.
- **Gửi thông tin lỗi:** *Cài đặt → Gửi thông tin lỗi* → xem trước (thông số máy, model đã nạp, vài lệnh cuối, nhật ký; khóa/token/email/đường dẫn ảnh bị ẩn) → thêm ghi chú → chia sẻ qua hộp hệ thống. **App không tự gửi gì.** Nếu lần trước app đóng đột ngột hoặc bị hệ thống tắt (hết bộ nhớ, treo, lỗi native; cần Android 11+ cho phần "bị hệ thống tắt"), lần mở sau app tự hỏi có muốn gửi kèm báo cáo không.

## 2j. Làm nét lại, khử moiré, phong cách tranh, xóa phản chiếu/bóng đổ, hòa màu (R25)

- **Làm nét lại (khử nhòe):** gõ `khử nhòe`, `làm nét lại`, `ảnh bị mờ`, `rung tay`, `remove motion blur`. App tự ước lượng ảnh nhòe do rung tay hay do mất nét (từ độ rộng cạnh), rồi khôi phục — **không dùng model, không tạo chi tiết mới**. Ảnh đã nét thì báo "không đổi". Chạy một lần khi áp (phép "bake").
- **Khử moiré:** gõ `khử moiré`, `xóa sọc màn hình`. Phân tích phổ tần số từng kênh màu, tìm vân lặp rồi trừ đi; không thấy vân thì giữ nguyên ảnh.
- **Phong cách tranh (miễn phí, chạy trên máy):** `tranh sơn dầu`, `hoạt hình`, `màu nước` (kèm `60%` để giảm bớt); `biến ảnh thành tranh sơn dầu` cũng được. Muốn kiểu phức tạp (anime, Ghibli, Van Gogh, tranh sơn mài…) thì gõ tên kiểu — việc này dùng AI đám mây (cần khóa Gemini của bạn hoặc máy chủ), hoặc thêm "bằng AI" để dùng AI cho cả ba kiểu trên.
- **Xóa phản chiếu / bóng đổ (AI):** `xóa phản chiếu`, `khử chói kính`, `xóa bóng đổ`. Mặc định xử lý cả ảnh; tô vùng trước thì chỉ đổi vùng đó. Kết quả vào lớp chờ *Áp dụng* (hoàn tác được). **Chỉ chạy với Gemini hoặc máy chủ của bạn**; model Stable Diffusion cục bộ không hiểu lệnh "xóa X" nên bị bỏ qua có ghi chú.
- **Phác thảo → ảnh (R26):** chip **"Phác thảo → ảnh"** → chọn màu, vẽ nét lên chỗ muốn thêm vật (hình + màu gần đúng), gõ mô tả (vd `cây sồi cao`), bấm **"Vẽ thành ảnh"**. AI thay nét phác bằng vật thật; ngoài vùng nét ảnh giữ nguyên; kết quả vào lớp chờ *Áp dụng*. Cần khóa Gemini của bạn, máy chủ của bạn hoặc SD; chất lượng do dịch vụ quyết định, nét quá mơ hồ cho vật không như ý.
- **Kiểm Kotlin không cần trình biên dịch (R30h, cho người build):** `python3 tools/kt_import_check.py` (và mục [30] của `tools/static_check.py`) bắt thiếu import, tham chiếu tới thành viên không tồn tại và sai số đối số trên toàn bộ mã Kotlin — KHÔNG thay cho biên dịch thật (`tools/jvm_check/run_all.sh`).
- **Công cụ nén model (R30c, cho người build — không nằm trong app):** hai công cụ không cần gói `onnx`, kèm `--verify` bằng ONNX Runtime: `onnx_weight_quant.py` (chỉ nén TRỌNG SỐ int8 theo kênh / fp16 — chủ yếu để tệp nhỏ, trên ORT CPU đã đo thì chạy chậm hơn float) và `onnx_static_qdq.py` (lượng tử hóa TĨNH QDQ có ảnh hiệu chuẩn: ORT fuse thành toán tử int8, đo ~3× nhanh hơn float trên CPU thử; là định dạng QNN / NNAPI cần cho NPU). Luôn kiểm bằng ẢNH THẬT trước khi dùng — xem `tools/convert_models/README.md`. Chính sách chọn model theo giấy phép: `PROJECT_STATUS.md` mục 8.13 (không dùng trọng số CC BY-NC trong bản thu phí).
- **Agent AI + ảnh mẫu phong cách (R30):** bật Agent AI → *Ảnh mẫu phong cách (tùy chọn)* → chọn một ảnh có gu màu bạn thích → nhập yêu cầu (vd. "chỉnh theo phong cách ảnh mẫu"). Ảnh mẫu (thu nhỏ ≤ 512 px, chỉ giữ trong bộ nhớ) được gửi lên máy chủ AI cùng ảnh thu nhỏ của bạn; lời nhắn của bạn vẫn được ưu tiên. Chỉ dùng khi Agent chạy ở máy chủ (Agent chạy trên máy bằng model đa phương thức cục bộ không dùng ảnh mẫu). Cần backend R30 (đã sửa lỗi khiến mọi lần gọi Gemini thật thất bại).
- **Reframe 2.5D (R29):** tab AI → chip *Reframe 2.5D: đổi góc nhìn* → kéo *Xoay ngang* / *Xoay dọc* (và *Độ sâu*) → *Áp dụng góc nhìn*: nền trượt quanh chủ thể như khi máy ảnh đi ngang, chỗ lộ ra sau chủ thể được lấp bằng màu nền, ảnh phóng nhẹ để che viền (lớp vá chờ *Áp dụng*, hoàn tác được). Chạy cục bộ, không tốn hạn mức AI; có model tách nền thì xoay quanh chủ thể, không có thì chỉ dựa trời + vị trí trong ảnh. Độ sâu là ĐOÁN nên chỉ để cho đẹp (tốt nhất với phong cảnh có trời + đất); chỗ lộ ra được lấp mờ. **R30:** nạp thêm `depth.onnx` (Cài đặt → *Chọn model độ sâu*) thì độ sâu được ĐO bằng model (tương đối, kể cả ảnh trong nhà); model hỏng hoặc ảnh quá phẳng thì tự quay về độ sâu đoán và có ghi chú. Kotlin của R30 chưa được biên dịch ở phiên viết ra nó — chạy `tools/jvm_check/run_all.sh` trước.
- **Best Take (R28):** tab AI → *Best Take: thêm ảnh cùng cảnh* (chọn tới 8 ảnh chụp liền nhau, CÙNG khung hình — tốt nhất chụp bằng chân máy) → *Chọn mặt đẹp nhất*. Với từng người, máy so mắt mở / nụ cười / độ nét ở mọi ảnh rồi ghép khuôn mặt đẹp nhất vào ảnh hiện tại (lớp vá chờ *Áp dụng*, hoàn tác được; ghi chú nói rõ mặt nào lấy từ ảnh nào). Cần model `face_landmarker.task`. Chỉ chọn trong những gì đã chụp (không tạo nụ cười mới) và chỉ ghép trong viền mặt (không tóc / tai / cổ) nên đầu nghiêng khác nhau có thể lộ mối ghép; nên chạy TRƯỚC khi chỉnh màu.
- **Giữ nguyên vùng (R27):** thêm vào lệnh chỉnh cụm `giữ nguyên khuôn mặt`, `trừ bầu trời`, `không động vào tóc`, `except the hair`, `don't touch the face`… (vd. `làm sáng ảnh nhưng giữ nguyên khuôn mặt`, `tông ấm, trừ bầu trời`). Phần chỉnh chỉ áp NGOÀI các vùng đó (da mặt, mắt, răng, tóc, bầu trời, nền, chủ thể; nối bằng *và* / dấu phẩy). Không nhận ra vùng (vd. `giữ nguyên logo`) thì lệnh chạy như cũ; không dựng được vùng cần giữ (thiếu model, không thấy mặt) thì máy báo và KHÔNG chỉnh gì. "Khuôn mặt" chỉ gồm da mặt — muốn giữ cả tóc, mắt thì nói thêm.
- **Hòa màu với nền:** chọn lớp ảnh phủ (hoặc vật vừa *Di chuyển*) → kéo thanh **"Hòa màu với nền"** để khớp màu và độ sáng của vật với ánh sáng xung quanh nó. Chỉ khớp màu/độ sáng toàn cục, không tạo bóng đổ.

## 3. Nạp model AI (không bắt buộc, nhưng khuyến nghị)

Bấm **Model AI** ở góc trên.

| Model | Tác dụng | Gợi ý |
|---|---|---|
| **LLM** (`.task` / `.bin` của MediaPipe) | Hiểu prompt tự do, linh hoạt hơn bộ quy tắc | Gemma 3 1B IT int4 (`.task`) trên Hugging Face (nhóm `litert-community`, cần đồng ý license), ~500–600 MB |
| **Tách nền** (`.onnx`, họ U²-Net) | Xóa nền, đổi nền, làm mờ phông chuẩn | `u2netp.onnx` (~4.7 MB, từ dự án rembg) |
| **Tách nền chất lượng cao** (`.onnx`, IS-Net) | Viền tóc/lông tốt hơn; chọn chủ thể | `isnet-general-use.onnx` (rembg); kiểm tra giấy phép trước khi bán |
| **Tách nền chân dung** (`.onnx`, MODNet, Apache-2.0) | Tóc/viền chân dung chi tiết hơn; chỉ dùng khi ảnh có mặt (cần model khuôn mặt) | MODNet ONNX xuất từ kho chính thức (input `[batch,3,H,W]`, output `[batch,1,H,W]`) |
| **Khuôn mặt** (`face_landmarker.task`) | Retouch da/mắt/răng/quầng thâm theo 478 điểm | Tải từ kho `mediapipe-models` của MediaPipe (xác nhận giấy phép trước khi bán) |
| **Phát hiện người** (`efficientdet_lite0.tflite`, MediaPipe ObjectDetector, tùy chọn) | "Xóa người lạ" nhận cả người quay lưng / không thấy mặt | Kho `mediapipe-models` (EfficientDet-Lite0, COCO); **xác nhận giấy phép model và dữ liệu COCO trước khi bán** |
| **Độ sâu** (`depth.onnx`, Depth Anything V2 **Small**, tùy chọn, R30) | Reframe 2.5D dùng độ sâu ĐO thật (tương đối) thay độ sâu giả; không nạp thì chạy như cũ | Bản ONNX của Depth Anything V2 Small, **Apache-2.0**; **đừng nạp bản Base/Large (CC-BY-NC, cấm thương mại)**; input `pixel_values [1,3,H,W]` (H, W bội của 14), output `predicted_depth [1,H,W]` kiểu nghịch đảo độ sâu (lớn = gần); kiểm kỹ giấy phép / hợp đồng I/O của đúng bản bạn tải |
| **Tóc** (`hair_segmenter.tflite`, MediaPipe) | Nhuộm màu / bóng mượt / giới hạn cọ trong vùng tóc | Kho `mediapipe-models` (HairSegmenter 512×512); **đọc điều khoản giấy phép của file model trước khi bán** |

- Không có model: app vẫn chạy bằng bộ quy tắc offline (`RuleBasedPlanner`). Riêng *mờ phông* sẽ dùng mặt nạ elip tạm; *xóa nền* bị bỏ qua và có thông báo.
- Model được sao chép vào bộ nhớ riêng của app, lần sau tự nạp lại.
- LLM dùng template chat của Gemma. Dùng model khác thì sửa `wrapChat()` trong `LlmPlanner.kt`.

## 4. Cấu trúc code

Xem sơ đồ đầy đủ ở **PROJECT_STATUS.md mục 2.2**. Tóm tắt:

```
app/src/main/java/com/aiphoto/studio/
├── MainActivity.kt · MainViewModel.kt   Trạng thái, luồng xử lý, nạp model, chạy nền
├── ai/       Hiểu prompt (luật VI/EN + LLM) → kế hoạch (toàn ảnh + theo vùng), GenIntent, Refine
├── doc/      Tài liệu không phá hủy: lớp, mặt nạ, blend, compositor, công thức
├── engine/   Xử lý ảnh + model: ImageEngine, ToneOps, FilterFx, MeshWarp, MaskMath, Face*, Hair, MagicWand, EdgeOps, Keystone, ONNX (tách nền, LaMa, MI-GAN, SAM, ESRGAN)
├── routing/  Cấu hình định tuyến model (JSON, có version) + hồ sơ hiệu năng theo hạng máy
├── billing/  Cổng thanh toán (bản stub mặc định; bản Play Billing thật ở app/src/billingReal, bật bằng -PuseBilling=true)
├── ui/       Giao diện Compose (EditorScreen, Panels, Widgets)
└── util/     Đọc/lưu ảnh, SecretStore (Keystore)
backend/      Máy chủ trung gian: credits, proxy AI, định tuyến, xác minh giao dịch Google Play (test_server.py)
tools/        static_check.py — kiểm tra tĩnh Kotlin; verify_ports/*.py — bản port Python kiểm số học/luật (đều chạy trong CI); jvm_check/ — biên dịch Kotlin THẬT + 202 test JVM không cần Android SDK (`tools/jvm_check/run_all.sh`, xem README trong thư mục)
```

## 5. Giới hạn hiện tại (nói thẳng)

- **Chưa có APK, chưa chạy trên máy thật.** Từ R19 mã Kotlin đã được kotlinc thật biên dịch và chạy JUnit với stub (`tools/jvm_check/run_all.sh`), nhưng stub không thay cho build Android thật. Lượt build đầu trên GitHub Actions có thể báo lỗi biên dịch cần sửa — danh sách điểm nghi ngờ ở PROJECT_STATUS.md mục 9.
- Thêm/thay vật thể cần mạng (máy chủ của bạn/Gemini) hoặc sd-server chạy trên máy (chưa đo tốc độ thật).
- **Auto Frame, Di chuyển vật thể, Gửi thông tin lỗi (R24):** đã biên dịch và kiểm bằng 63 test JVM trên ảnh tổng hợp (cộng đột biến mã), **chưa chạy trên máy thật**. Hằng số Auto Frame do mình chỉnh trên bản đồ tổng hợp; viền Di chuyển không phải matting thật; quy tắc ẩn dữ liệu nhạy cảm trong báo cáo là heuristic (nên đọc phần xem trước trước khi gửi). Chi tiết: `PROJECT_STATUS.md` mục 9 (A135–A140).
- **Làm nét lại, Khử moiré, Phong cách tranh, Hòa màu (R25):** đã biên dịch và kiểm bằng 58 test JVM trên ảnh tổng hợp (cộng đột biến mã), **chưa chạy trên ảnh/máy thật**; hằng số do mình chỉnh trên ảnh tổng hợp. Làm nét lại chỉ tốt với nhòe đồng đều và không tạo chi tiết mới; khử moiré có thể trừ thiếu với vân méo/lẫn màu; phong cách tranh là bộ lọc kiểu (không hiểu nội dung). Xóa phản chiếu/bóng đổ và đổi phong cách kiểu anime/Ghibli phụ thuộc dịch vụ AI bạn dùng (chưa thử với dịch vụ thật). Một câu ghép như "xóa phản chiếu và làm sáng ảnh" hiện chỉ chạy phần AI — hãy gõ từng yêu cầu. **Phác thảo → ảnh (R26)** chưa thử với dịch vụ AI thật; **Giữ nguyên vùng (R27)** chưa thử trên máy thật, chỉ áp cho phần chỉnh toàn cục (phép cắt/xoay/làm nét lại bị bỏ có báo). **Best Take (R28)** chưa thử trên mặt / máy thật: ngưỡng mắt mở / nụ cười là ước đoán tay. **Reframe 2.5D (R29)** chưa thử ảnh thật / máy thật: độ sâu là đoán, vùng lấp mờ, RAM / thời gian ở máy yếu chưa đo. **Chưa có:** phóng ×4 tùy chọn.
- Retouch khuôn mặt cần nạp `face_landmarker.task`; ngưỡng răng/quầng thâm chưa chỉnh trên ảnh thật.
- Mua credits / gói Pro qua Google Play: **máy chủ đã xác minh giao dịch**, **app đã có client Play Billing nhưng mặc định tắt** (build `-PuseBilling=true`, chưa biên dịch/chạy thử; cần tạo sản phẩm trong Play Console). **Đăng ký định kỳ (R14):** máy chủ đã xác minh `subscriptionsv2` + nhận RTDN + acknowledge (đã test với Google giả lập), app có nút "Đăng ký" sau cờ `-PuseBilling` — chưa thử với Play Console thật.
- **Dùng thử miễn phí cho tester (R23, mặc định BẬT, chủ app KHÔNG trả tiền AI):** mọi người dùng dùng đủ tính năng, không watermark, không trừ credits; giao diện tiền (credits/gói/bảng giá/Nhóm) bị ẩn bằng `Monetization.ENABLED=false`; máy chủ `OPEN_BETA=1` mặc định KHÔNG dùng khóa AI của chủ app (`BETA_OWNER_PAYS=0`) — tester dùng khóa Gemini của chính họ (gọi thẳng tới Google) hoặc model chạy trên máy; `BETA_OWNER_PAYS=1` mới bật AI máy chủ kèm hai trần dùng/24 giờ. Module tính phí còn nguyên; bật lại bằng cách đổi CẢ HAI công tắc (xem `PROJECT_STATUS.md` mục 10).
- **Gói Team/Enterprise (R22, mặc định TẮT):** máy chủ hỗ trợ nhóm nhiều ghế dùng chung quỹ credits và gói Pro, vào bằng mã mời; app có khối **"Nhóm"** trong Cài đặt. Bật bằng `TEAM_ENABLED=1` (xem `backend/README.md`); giá/ghế/credits là cấu hình hoặc lệnh vận hành, không nằm trong mã. Chưa có: quyết định giá/hạn mức theo người, gói Team đăng ký định kỳ, thử với Google Play thật, giao diện chưa chạy trên máy.
- Ảnh làm việc giới hạn theo hạng máy (1536–2560 px cạnh dài) để tránh tràn RAM.
- Gradle/AGP/Compose được ghim: AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00, MediaPipe `tasks-genai:0.10.27` + `tasks-vision:0.10.28`, ONNX Runtime `1.27.0` (R31: nâng từ 1.18.0 vì bản cũ không căn chỉnh 16 KB — Google Play chặn bản cập nhật từ 01/02/2027). Bản `play_release` dùng AGP 8.9.1 + `targetSdk` 36.
  MediaPipe LLM Inference đã ở chế độ bảo trì.
- **LLM cục bộ (R15):** hai backend chọn theo đuôi tệp model — `.task` (MediaPipe LLM Inference, Gemma 3 1B, chỉ văn bản, mặc định) và `.litertlm` (**LiteRT-LM**, Gemma 3n / Gemma 4 (Apache-2.0), GPU, **hiểu cả ảnh ngay trên máy** cho Agent AI). LiteRT-LM mặc định tắt (bản stub); bật bằng `-PuseLiteRtLm=true` (ghim phiên bản bằng `-PlitertlmVersion=x.y.z`; CI `workflow_dispatch` có đầu vào tương ứng). **Chưa biên dịch/chạy thử** — xem PROJECT_STATUS.md mục 8.9 và A89–A93.
- **Tóc phồng (R16):** nói "tóc phồng hơn / tóc dày hơn / tăng volume tóc" hoặc bấm chip trong Panels "Tóc": mép tóc được đẩy ra tối đa 2% cạnh dài bằng thuật toán cổ điển (mặt nạ tóc MediaPipe → khoảng cách → biến dạng ngược, không cần model sinh ảnh), da mặt được bảo vệ. Là phép gộp lớp (hoàn tác được); cần nạp `hair_segmenter.tflite`. Mới kiểm bằng bản port Python, **chưa biên dịch/chưa xem trên ảnh thật** (PROJECT_STATUS.md A94–A97).
- **Chỉnh dáng mặt khi quay đầu (R17):** nếu model Face Landmarker trả chiều sâu, mức Liquify (thon hàm, to mắt, thu mũi, cười) tự giảm mượt khi mặt quay nghiêng quá ~20° và tắt hẳn ở ~55° để không bị méo; app báo rõ trên thanh trạng thái. Chưa có hiệu chỉnh từng bên (cần ảnh thật). **Chưa biên dịch/chưa thử trên ảnh thật** (PROJECT_STATUS.md A98–A101).
- **NPU trung lập theo hãng chip (R18):** mã không nêu hãng nào; LiteRT dùng một API cho Qualcomm/MediaTek/Tensor/Samsung. App chỉ thử NPU khi API ≥ 31, máy arm64 và tên tệp model `.litertlm` kết thúc bằng `_<SoC của máy>.litertlm` (bản biên dịch sẵn cho chính chip đó); model chung luôn chạy GPU rồi CPU. Cài đặt hiện bộ tăng tốc đang chạy. **Chưa đóng gói thư viện NPU runtime và chưa thử trên máy nào** (PROJECT_STATUS.md 8.10, P1-16).

## 5b. Đưa lên Google Play (R31)

Bản tester (APK debug cài tay) **không bị** các yêu cầu này, nhưng bản bán trên Google Play thì có — đã tra cứu 11/2026 (nguồn ở `PROJECT_STATUS.md` mục 8.15):

- **Target SDK:** từ 31/8/2026 Play chỉ nhận ứng dụng mới / bản cập nhật nhắm **Android 16 (API 36)**. Bản mặc định vẫn nhắm 34. Muốn bản sẵn sàng cho Play: chạy workflow **Build APK** bằng tay và bật ô **`play_release`** (dùng AGP 8.9.1 + Gradle 8.14.3 + `compileSdk/targetSdk` 36; `versionCode` tự tăng theo số lần chạy).
- **Trang bộ nhớ 16 KB:** từ 01/02/2027 Play chặn bản cập nhật có thư viện native chưa căn chỉnh 16 KB. Đã nâng ONNX Runtime lên 1.27.0 và thêm cờ liên kết cho `sd-server`; sau mỗi build, mở **Summary** của workflow xem bước *Kiểm tra căn chỉnh 16 KB* (hoặc chạy `python tools/check_16kb.py app/build/outputs/apk/debug/*.apk`).
- **Giao diện tràn viền (edge-to-edge)** là bắt buộc từ API 35: `MainActivity` đã bật và đệm nội dung theo thanh hệ thống/bàn phím — cần nhìn thử trên máy thật.
- Chưa có trong repo: chính sách quyền riêng tư, khai báo Data safety, khóa ký bản release.


## 5c. Trợ giúp trong app và ngôn ngữ giao diện (R33)

* **Trợ giúp:** nút **?** ở thanh trên (và ⚙ → Trợ giúp) mở hướng dẫn đầy đủ chức năng, có ô tìm kiếm (không phân biệt hoa thường và dấu), bấm tiêu đề để mở / gập. Nội dung ở `app/src/main/assets/help/<ngôn ngữ>.json`.
* **Ngôn ngữ:** lần đầu mở app có hộp thoại chào (nói rõ đây là bản dùng thử miễn phí cho tester); ⚙ → Ngôn ngữ để đổi bất cứ lúc nào, đổi ngay không cần khởi động lại. Hỗ trợ 13 ngôn ngữ: Tiếng Việt, English, 简体中文, Español, हिन्दी, العربية (bố cục phải→trái), Português (Brasil), Русский, 日本語, 한국어, Français, Deutsch, Bahasa Indonesia, hoặc "Tự động" theo hệ thống.
* **Độ phủ:** tiếng Việt đầy đủ; tiếng Anh gần đầy đủ; 11 ngôn ngữ còn lại có giao diện chính + toàn bộ Trợ giúp, phần chưa dịch hiện bằng tiếng Anh (màn chọn ngôn ngữ ghi tỉ lệ cạnh tên). Cách thêm / sửa bản dịch: `tools/i18n/README.md`.

## 6. Hướng mở rộng

- Thêm phép chỉnh: `OpType` → hàm trong `ImageEngine`/`ToneOps` → luật trong `RuleBasedPlanner` → mô tả trong prompt `LlmPlanner` → thanh trượt trong `Panels.kt`.
- Thêm vùng cho kế hoạch AI: khai báo trong `Scope`, dựng mặt nạ trong `maskForScope` (ViewModel), thêm luật trong `RuleBasedPlanner.processScoped`.
- Thêm model/nhà cung cấp: lớp provider → `Routing.KNOWN_KINDS` → nhánh trong ViewModel → JSON định tuyến (**nhớ tăng `version`**).
- Chưa làm (đối chiếu đầy đủ với PDF ở PROJECT_STATUS.md mục 4b): vector/clipping mask, xóa sợi tóc lạc/tăng volume, Liquify 3D, Filter Gallery 80+, MLLM chạy trên máy. **Việc quyết định tiếp theo: build lần đầu + chạy thử trên máy thật.**
- Đã tra cứu và **không** dùng: ORT GenAI (chưa có gói Maven chính thức), AOT-GAN (checkpoint khuôn mặt, giấy phép riêng), DreamLite (trọng số CC BY-NC — cấm thương mại).
