plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// R31 — yêu cầu của Google Play (tra cứu 11/2026, support.google.com/googleplay/android-developer/answer/11926878):
// từ 31/8/2026 ứng dụng MỚI và BẢN CẬP NHẬT phải nhắm Android 16 (API 36) mới được tải lên Play. Bản tester (APK debug cài tay) chưa cần.
// Mặc định giữ 34 để luồng build hiện tại không đổi; muốn bản sẵn sàng cho Play: -PplayRelease=true (workflow có ô `play_release`).
// API 36 cần AGP >= 8.9.1 + Gradle >= 8.11.1: workflow đặt PLAY_RELEASE=true và gradle 8.14.3, settings.gradle.kts nâng AGP lên 8.9.1 (bản tester vẫn 8.5.2 + Gradle 8.7).
val playRelease = project.findProperty("playRelease") == "true"
val sdkLevel = if (playRelease) 36 else 34

// R31 — ONNX Runtime: bản 1.18.0 (05/2024) KHÔNG căn chỉnh 16 KB; từ 1.22.0 trở đi thư viện native đã căn chỉnh 16 KB (Google Play bắt buộc với
// ứng dụng nhắm Android 15+, bản cập nhật không đạt sẽ bị chặn từ 1/2/2027). 1.27.0 (30/06/2026) là bản mới nhất trên Maven Central, cả
// `onnxruntime-android` lẫn `onnxruntime-android-qnn` đều có bản này. Một số duy nhất cho cả hai biến thể để không lệch nhau.
val ortVersion = "1.27.0"

android {
    namespace = "com.aiphoto.studio"
    compileSdk = sdkLevel

    sourceSets {
        getByName("main") {
            java.srcDir(if (project.findProperty("useBilling") == "true") "src/billingReal/java" else "src/billingStub/java")
            java.srcDir(if (project.findProperty("useLiteRtLm") == "true") "src/litertlmReal/java" else "src/litertlmStub/java")
            // R32: Play Integrity (chứng thực thiết bị/ứng dụng với máy chủ). Mặc định bản stub; bật bằng -PuseIntegrity=true -PintegrityCloudProject=<số dự án Cloud>
            java.srcDir(if (project.findProperty("useIntegrity") == "true") "src/integrityReal/java" else "src/integrityStub/java")
        }
    }

    defaultConfig {
        applicationId = "com.aiphoto.studio"
        minSdk = 26
        targetSdk = sdkLevel
        // R32: số dự án Google Cloud cho Play Integrity (meta-data `integrity.cloud_project` trong manifest); 0 = chưa cấu hình
        manifestPlaceholders["integrityCloudProject"] = project.findProperty("integrityCloudProject")?.toString() ?: "0"
        // Play yêu cầu versionCode TĂNG ở mỗi lần tải lên: CI truyền -PversionCode=<số lần chạy>; không truyền thì giữ 1.
        versionCode = project.findProperty("versionCode")?.toString()?.toIntOrNull() ?: 1
        versionName = "1.0"

        // Chỉ build arm64 (hầu hết điện thoại hiện nay) -> APK nhỏ hơn, build nhanh hơn.
        // Muốn chạy trên máy ảo x86_64 thì thêm "x86_64".
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    // R24: khóa ký CỐ ĐỊNH cho bản debug (khóa debug không phải bí mật, chỉ để tester cài đè bản mới lên bản cũ mà không mất model/phiên đã lưu).
    // Nếu không có tệp này, mỗi lần CI build sẽ sinh khóa debug mới -> Android báo "xung đột chữ ký" khi cài đè, tester phải gỡ app và mất dữ liệu.
    // Bản bán thật (release) phải dùng khóa riêng của chủ app, KHÔNG dùng khóa này.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // LiteRT-LM (khi bật -PuseLiteRtLm=true) có thể được build bằng Kotlin MỚI HƠN 1.9.24 của dự án -> "incompatible version of Kotlin metadata"
        // (đúng bài học billing-ktx). Cờ này bỏ qua kiểm tra phiên bản metadata; cách bền hơn là nâng Kotlin lên 2.x (xem A90).
        if (project.findProperty("useLiteRtLm") == "true") freeCompilerArgs += "-Xskip-metadata-version-check"
    }

    buildFeatures {
        compose = true
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // sd-server (tiến trình con) phải nằm trên đĩa dưới dạng tệp thực thi -> giải nén thư viện native khi cài
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Kiểm thử logic thuần trên JVM (chạy trong CI: gradle :app:testDebugUnitTest)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")

    // LLM chạy cục bộ để hiểu prompt (MediaPipe LLM Inference)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // MediaPipe Face Landmarker (478 điểm khuôn mặt) cho retouch da / mắt / răng / quầng thâm. 0.10.28 có trên Maven Central
    // (tasks-vision không phát hành bản 0.10.27 nên không cùng số với tasks-genai). Model face_landmarker.task do người dùng nạp.
    implementation("com.google.mediapipe:tasks-vision:0.10.28")

    // Google Play Billing (bán credits / gói Pro). Mặc định TẮT (bản stub, không thêm thư viện) để không làm hỏng bản build chưa từng chạy thử;
    // bật bằng  -PuseBilling=true  (dùng artifact Java "billing", KHÔNG dùng billing-ktx vì từ 8.1 nó build bằng Kotlin 2.2 còn dự án dùng 1.9.24).
    if (project.findProperty("useBilling") == "true") {
        implementation("com.android.billingclient:billing:8.3.0")
    }

    // Play Integrity (R32). Số 1.6.0 lấy từ trang "Native setup" chính thức (trang "Setup" cũ hơn ghi 1.4.0); ghim lại bằng -PintegrityVersion=x.y.z nếu cần.
    // Thư viện là Java (không phải Kotlin) nên không dính lỗi "incompatible version of Kotlin metadata" như billing-ktx.
    if (project.findProperty("useIntegrity") == "true") {
        implementation("com.google.android.play:integrity:${project.findProperty("integrityVersion") ?: "1.6.0"}")
    }

    // LiteRT-LM (R15): thay MediaPipe LLM Inference (bảo trì) cho model .litertlm - Gemma 3n / Gemma 4 (Apache-2.0), GPU, nhận ảnh.
    // Mặc định TẮT (bản stub, không thêm thư viện). Bật bằng  -PuseLiteRtLm=true ; ghim phiên bản bằng  -PlitertlmVersion=x.y.z
    // (mặc định "latest.release" theo tài liệu chính thức - KHÔNG tái lập được, hãy ghim khi đã build thử OK).
    if (project.findProperty("useLiteRtLm") == "true") {
        implementation("com.google.ai.edge.litertlm:litertlm-android:${project.findProperty("litertlmVersion") ?: "latest.release"}")
    }

    // ONNX Runtime: chạy model tách nền (U2Net / u2netp ...) cục bộ
    // ONNX Runtime. Muốn thử NPU Qualcomm (QNN) cho một số dòng máy: build với  -PuseQnn=true  (gói onnxruntime-android-qnn
    // đã xác minh tồn tại trên Maven Central, kèm thư viện QNN; mặc định tắt vì APK lớn hơn và HTP có báo cáo lỗi khởi tạo ở vài máy).
    if (project.findProperty("useQnn") == "true") {
        implementation("com.microsoft.onnxruntime:onnxruntime-android-qnn:$ortVersion")
    } else {
        implementation("com.microsoft.onnxruntime:onnxruntime-android:$ortVersion")
    }
}
