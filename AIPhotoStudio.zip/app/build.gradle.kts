plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// R31 — yêu cầu của Google Play (tra cứu 11/2026, support.google.com/googleplay/android-developer/answer/11926878):
// từ 31/8/2026 ứng dụng MỚI và BẢN CẬP NHẬT phải nhắm Android 16 (API 36) mới được tải lên Play. Bản tester (APK debug cài tay) chưa cần.
// Mặc định giữ 34 để luồng build hiện tại không đổi; muốn bản sẵn sàng cho Play: -PplayRelease=true (workflow có ô `play_release`).
// API 36 cần AGP >= 8.9.1 + Gradle >= 8.11.1: workflow đặt PLAY_RELEASE=true và gradle 8.14.3, settings.gradle.kts nâng AGP lên 8.9.1 (bản tester vẫn 8.5.2 + Gradle 8.7).
val playRelease = project.findProperty("playRelease") == "true"
val sdkLevel = if (playRelease) 36 else 34

// R31 — ONNX Runtime: bản 1.18.0 (05/2024) KHÔNG căn chỉnh 16 KB; từ 1.22.0 trở đi thư viện native đã căn chỉnh 16 KB (Google Play bắt buộc với
// ứng dụng nhắm Android 15+, bản cập nhật không đạt sẽ bị chặn từ 1/2/2027). 1.27.0 (30/06/2026) là bản mới nhất trên Maven Central, cả
// `onnxruntime-android` lẫn `onnxruntime-android-qnn` đều có bản này. Một số duy nhất cho cả hai biến thể để không lệch nhau.
val ortVersion = "1.27.0"

// R47 — bản dựng có thư viện TÙY CHỌN (Billing / LiteRT-LM / Integrity / QNN) từng đỏ ở `checkDebugAarMetadata` (CI "Build APK #31", use_all): một thư viện
// kéo theo androidx BẢN MỚI (Compose ui 1.9.0 + runtime-saveable, lifecycle-*-compose 2.10.0, core / core-ktx 1.15.0) mà bản tester (compileSdk 34, AGP 8.5.2)
// không chấp nhận (cần compileSdk 35 + AGP 8.6). Nâng toolchain KHÔNG đủ: Gradle chỉ nâng riêng nhóm ui/lifecycle/core còn foundation + material3 ở
// 1.6.x / 1.2.x của BOM ⇒ Compose lệch phiên bản ⇒ dễ sập lúc chạy. Cách làm: kéo các nhóm đó VỀ đúng bản app được viết và kiểm với (BOM 2024.06.00,
// lifecycle 2.8.3, core 1.13.1). Thư viện tùy chọn không phải thư viện giao diện nên không cần Compose mới; nếu nó thật sự cần, lỗi sẽ hiện ở bước
// "Chẩn đoán" của CI (dependencyInsight). Chỉ bật khi có cờ tùy chọn ⇒ bản mặc định (đã chạy ổn) giữ NGUYÊN.
// Tên có hậu tố `-android` (biến thể KMP của bản mới) được đổi về module gốc cùng tên vì bản cũ không có tệp `-android`.
// R50 — Build APK #43 (use_all) VẪN đỏ cùng một lỗi sau R49: `compileDebugKotlin` → NPE `makeComposableAnnotation` ở MainActivity.kt (46,72) = plugin Compose không tìm
// thấy `androidx.compose.runtime.Composable` dù `runtime` đã được khai báo tường minh. ⇒ nguyên nhân KHÔNG phải "thiếu runtime" như R49 giả định. Biện pháp R47 (đổi tên từng
// artifact Compose bằng `useTarget`) là nghi phạm còn lại duy nhất do mình tự thêm vào (bản mặc định không có nó và build xanh) ⇒ R50 làm khác, theo cách chuẩn của Gradle:
//   (1) KHÔNG đổi tên artifact Compose nữa; dùng `enforcedPlatform(BOM)` — mọi artifact Compose (kể cả bản bị kéo gián tiếp) buộc về đúng bản BOM 2024.06.00 (1.6.8);
//   (2) cắt từ GỐC: bốn thư viện tùy chọn (Billing / Integrity / LiteRT-LM / QNN) bị `exclude` toàn bộ nhóm androidx giao diện (compose, lifecycle, core, activity, savedstate,
//       navigation) — app đã tự khai báo các nhóm này nên không mất gì, còn thư viện tùy chọn không thể nâng phiên bản của chúng nữa;
//   (3) giữ ghim lifecycle 2.8.3 / core 1.13.1 (đã được xác nhận ở #39 và #43: `checkDebugAarMetadata` qua) và loại `runtime-annotation*` (R49).
// Nếu vẫn đỏ: bước CI "Bisect" (mới, R50) tự dựng từng cờ riêng và ghi vào Summary cờ nào gây lỗi + danh sách classpath biên dịch.
val optionalLibs = listOf("useBilling", "useLiteRtLm", "useIntegrity", "useQnn").any { project.findProperty(it) == "true" }
val androidxUiGroups = listOf(
    "androidx.compose.ui", "androidx.compose.runtime", "androidx.compose.foundation", "androidx.compose.material3", "androidx.compose.material",
    "androidx.compose.animation", "androidx.lifecycle", "androidx.core", "androidx.activity", "androidx.savedstate", "androidx.navigation"
)
fun ExternalModuleDependency.keepAndroidxUiOut() { androidxUiGroups.forEach { exclude(group = it) } }
if (optionalLibs) {
    configurations.all {
        // R49: runtime-annotation* của Compose mới (Kotlin 2.x) không được lọt vào classpath cùng runtime 1.6.8 (đã chứa @Composable/@Stable...).
        exclude(group = "androidx.compose.runtime", module = "runtime-annotation")
        exclude(group = "androidx.compose.runtime", module = "runtime-annotation-android")
        exclude(group = "androidx.compose.runtime", module = "runtime-annotation-jvm")
        resolutionStrategy.eachDependency {
            val group = requested.group
            val base = requested.name.removeSuffix("-android")
            when {
                group == "androidx.lifecycle" -> useTarget("$group:$base:2.8.3")
                group == "androidx.core" && (base == "core" || base == "core-ktx") -> useTarget("$group:$base:1.13.1")
            }
        }
    }
}

android {
    namespace = "com.aiphoto.studio"
    compileSdk = sdkLevel

    sourceSets {
        getByName("main") {
            java.srcDir(if (project.findProperty("useBilling") == "true") "src/billingReal/java" else "src/billingStub/java")
            java.srcDir(if (project.findProperty("useLiteRtLm") == "true") "src/litertlmReal/java" else "src/litertlmStub/java")
            // R32: Play Integrity (chứng thực thiết bị/ứng dụng với máy chủ). Mặc định bản stub; bật bằng -PuseIntegrity=true -PintegrityCloudProject=<số dự án Cloud>
            java.srcDir(if (project.findProperty("useIntegrity") == "true") "src/integrityReal/java" else "src/integrityStub/java")
        }
    }

    defaultConfig {
        applicationId = "com.aiphoto.studio"
        minSdk = 26
        targetSdk = sdkLevel
        // R32: số dự án Google Cloud cho Play Integrity (meta-data `integrity.cloud_project` trong manifest); 0 = chưa cấu hình
        manifestPlaceholders["integrityCloudProject"] = project.findProperty("integrityCloudProject")?.toString() ?: "0"
        // Play yêu cầu versionCode TĂNG ở mỗi lần tải lên: CI truyền -PversionCode=<số lần chạy>; không truyền thì giữ 1.
        versionCode = project.findProperty("versionCode")?.toString()?.toIntOrNull() ?: 1
        versionName = "1.0"

        // Chỉ build arm64 (hầu hết điện thoại hiện nay) -> APK nhỏ hơn, build nhanh hơn.
        // Muốn chạy trên máy ảo x86_64 thì thêm "x86_64".
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    // R24: khóa ký CỐ ĐỊNH cho bản debug (khóa debug không phải bí mật, chỉ để tester cài đè bản mới lên bản cũ mà không mất model/phiên đã lưu).
    // Nếu không có tệp này, mỗi lần CI build sẽ sinh khóa debug mới -> Android báo "xung đột chữ ký" khi cài đè, tester phải gỡ app và mất dữ liệu.
    // Bản bán thật (release) phải dùng khóa riêng của chủ app, KHÔNG dùng khóa này.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        // R36: bản ĐO HIỆU NĂNG. Bản tester là assembleDebug: Compose ở bản debug CHẬM hơn đáng kể (debuggable, không R8, không hồ sơ baseline của thư viện Compose),
        // nên giật lag cảm nhận trên máy có thể phần lớn là do build debug chứ không phải do mã. Bản `perf` = như release (không debuggable) nhưng ký bằng khóa debug cố định
        // ⇒ cài ĐÈ được lên bản tester, cùng applicationId. Chưa bật R8 (chưa có tệp luật proguard và chưa thử trên máy; thử R8 SAU khi có số đo của bản này).
        // Dựng bằng `gradle :app:assemblePerf`; job `build-perf` trong .github/workflows/build-apk.yml làm việc đó mỗi lần chạy (không chặn bản tester).
        create("perf") {
            initWith(getByName("release"))
            isDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
            matchingFallbacks += listOf("release")
            // Thử nghiệm R8 (mặc định TẮT): -PperfMinify=true bật thu nhỏ + tối ưu mã với app/proguard-rules.pro (giữ tên, không làm rối). Chỉ thử SAU khi bản perf thường đã đo xong.
            val perfMinify = project.findProperty("perfMinify") == "true"
            isMinifyEnabled = perfMinify
            if (perfMinify) proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    // Biến thể `perf` không debuggable nên AGP chạy thêm lintVital (có thể làm hỏng build vì lỗi lint không liên quan tới việc đo) ⇒ tắt, giống cách bản debug không chạy lint khi build.
    lint {
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // LiteRT-LM (khi bật -PuseLiteRtLm=true) có thể được build bằng Kotlin MỚI HƠN 1.9.24 của dự án -> "incompatible version of Kotlin metadata"
        // (đúng bài học billing-ktx). Cờ này bỏ qua kiểm tra phiên bản metadata; cách bền hơn là nâng Kotlin lên 2.x (xem A90).
        if (project.findProperty("useLiteRtLm") == "true") freeCompilerArgs += "-Xskip-metadata-version-check"
        // R36: báo cáo của Compose compiler (composable nào KHÔNG bỏ qua được khi tái vẽ, tham số nào "không ổn định") — bằng chứng để quyết định có tách EditorScreen hay không
        // mà không cần máy thật. Chỉ bật khi truyền -PcomposeCompilerReports=true (job build-perf làm vậy); bản thường không bị ảnh hưởng. Cờ theo tài liệu developer.android.com
        // (mỗi cờ chỉ được khai báo MỘT lần).
        if (project.findProperty("composeCompilerReports") == "true") {
            val composeReportDir = project.layout.buildDirectory.dir("compose_compiler").get().asFile.absolutePath
            freeCompilerArgs += listOf(
                "-P", "plugin:androidx.compose.compiler.plugins.kotlin:reportsDestination=$composeReportDir",
                "-P", "plugin:androidx.compose.compiler.plugins.kotlin:metricsDestination=$composeReportDir"
            )
        }
    }

    buildFeatures {
        compose = true
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // sd-server (tiến trình con) phải nằm trên đĩa dưới dạng tệp thực thi -> giải nén thư viện native khi cài
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    if (optionalLibs) implementation(enforcedPlatform("androidx.compose:compose-bom:2024.06.00")) else implementation(platform("androidx.compose:compose-bom:2024.06.00"))   // R50: bản có thư viện tùy chọn buộc ĐÚNG phiên bản BOM
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    // R49: bảo đảm Compose runtime (BOM 1.6.8) CÓ trên classpath biên dịch khi bật thư viện tùy chọn (R47 ghim lại phiên bản của nhóm ui/runtime; bản mặc định giữ nguyên).
    if (optionalLibs) implementation("androidx.compose.runtime:runtime")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Kiểm thử logic thuần trên JVM (chạy trong CI: gradle :app:testDebugUnitTest)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")

    // LLM chạy cục bộ để hiểu prompt (MediaPipe LLM Inference)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // MediaPipe Face Landmarker (478 điểm khuôn mặt) cho retouch da / mắt / răng / quầng thâm. 0.10.28 có trên Maven Central
    // (tasks-vision không phát hành bản 0.10.27 nên không cùng số với tasks-genai). Model face_landmarker.task do người dùng nạp.
    implementation("com.google.mediapipe:tasks-vision:0.10.28")

    // Google Play Billing (bán credits / gói Pro). Mặc định TẮT (bản stub, không thêm thư viện) để không làm hỏng bản build chưa từng chạy thử;
    // bật bằng  -PuseBilling=true  (dùng artifact Java "billing", KHÔNG dùng billing-ktx vì từ 8.1 nó build bằng Kotlin 2.2 còn dự án dùng 1.9.24).
    if (project.findProperty("useBilling") == "true") {
        implementation("com.android.billingclient:billing:${project.findProperty("billingVersion") ?: "8.3.0"}") { keepAndroidxUiOut() }  // R40b: ghim bằng -PbillingVersion=x.y.z (vd. 9.1.0)
    }

    // Play Integrity (R32). Số 1.6.0 lấy từ trang "Native setup" chính thức (trang "Setup" cũ hơn ghi 1.4.0); ghim lại bằng -PintegrityVersion=x.y.z nếu cần.
    // Thư viện là Java (không phải Kotlin) nên không dính lỗi "incompatible version of Kotlin metadata" như billing-ktx.
    if (project.findProperty("useIntegrity") == "true") {
        implementation("com.google.android.play:integrity:${project.findProperty("integrityVersion") ?: "1.6.0"}") { keepAndroidxUiOut() }
    }

    // LiteRT-LM (R15): thay MediaPipe LLM Inference (bảo trì) cho model .litertlm - Gemma 3n / Gemma 4 (Apache-2.0), GPU, nhận ảnh.
    // Mặc định TẮT (bản stub, không thêm thư viện). Bật bằng  -PuseLiteRtLm=true ; ghim phiên bản bằng  -PlitertlmVersion=x.y.z
    // (mặc định "latest.release" theo tài liệu chính thức - KHÔNG tái lập được, hãy ghim khi đã build thử OK).
    if (project.findProperty("useLiteRtLm") == "true") {
        // R49: KHÔNG dùng latest.release nữa. Build APK #39 (use_all) đỏ vì litertlm-android 0.20.0 (23/11/2026) chứa bytecode Java 25 (class major 69) mà D8 của AGP 8.5.2
        // không đọc ("Unsupported class file major version 69"). Mặc định 0.18.1 = bản Google AI Edge Gallery đang dùng; mã app đã biên dịch + qua RealLiteRtLmCheck với
        // mã nguồn thật v0.18.1 / v0.19.1 / v0.20.0. CI (bước "Chọn phiên bản LiteRT-LM", tools/pick_litertlm_version.py) tự chọn bản mới nhất D8 đọc được và truyền qua
        // ORG_GRADLE_PROJECT_litertlmVersion; -PlitertlmVersion=x.y.z trên dòng lệnh vẫn thắng.
        implementation("com.google.ai.edge.litertlm:litertlm-android:${project.findProperty("litertlmVersion") ?: "0.18.1"}") { keepAndroidxUiOut() }
    }

    // ONNX Runtime: chạy model tách nền (U2Net / u2netp ...) cục bộ
    // ONNX Runtime. Muốn thử NPU Qualcomm (QNN) cho một số dòng máy: build với  -PuseQnn=true  (gói onnxruntime-android-qnn
    // đã xác minh tồn tại trên Maven Central, kèm thư viện QNN; mặc định tắt vì APK lớn hơn và HTP có báo cáo lỗi khởi tạo ở vài máy).
    if (project.findProperty("useQnn") == "true") {
        implementation("com.microsoft.onnxruntime:onnxruntime-android-qnn:$ortVersion") { keepAndroidxUiOut() }
    } else {
        implementation("com.microsoft.onnxruntime:onnxruntime-android:$ortVersion")
    }
}

// R49: in classpath BIÊN DỊCH của bản debug (tên tệp từng thư viện) để biết androidx.compose.runtime có mặt không - bước "Chẩn đoán" của CI gọi khi build đỏ.
// Chạy tay: gradle :app:printCompileClasspath [các -P giống bản đỏ]
tasks.register("printCompileClasspath") {
    doLast {
        println("== debugCompileClasspath ==")
        configurations.getByName("debugCompileClasspath").files.map { it.name }.sorted().forEach { println(it) }
    }
}
