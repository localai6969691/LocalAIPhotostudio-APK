# R36: luật R8 cho bản `perf` thử nghiệm (-PperfMinify=true, xem app/build.gradle.kts). KHÔNG dùng cho bản tester / debug.
# Chiến lược thận trọng vì chưa từng chạy R8 với dự án này: KHÔNG làm rối tên (-dontobfuscate) để giảm rủi ro phản chiếu / JNI gọi theo tên,
# nhưng vẫn thu nhỏ + tối ưu mã (phần quyết định tốc độ). Lần chạy đầu có thể lỗi "Missing classes detected while running R8": AGP ghi sẵn các dòng
# -dontwarn cần thêm vào app/build/outputs/mapping/perf/missing_rules.txt (job build-perf tải tệp đó lên) — dán nội dung vào cuối tệp này.
-dontobfuscate
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions,RuntimeVisibleAnnotations

# ONNX Runtime: lớp Java được thư viện native gọi ngược theo tên (JNI)
-keep class ai.onnxruntime.** { *; }

# MediaPipe tasks (genai + vision): JNI + protobuf-lite dựa vào phản chiếu
-keep class com.google.mediapipe.** { *; }
-keep class * extends com.google.protobuf.GeneratedMessageLite { *; }
-dontwarn com.google.mediapipe.**
-dontwarn com.google.auto.value.**
-dontwarn javax.annotation.**
-dontwarn javax.lang.model.**

# LiteRT / LiteRT-LM (chỉ có khi build với -PuseLiteRtLm=true)
-keep class com.google.ai.edge.** { *; }
-keep class org.tensorflow.lite.** { *; }
-dontwarn com.google.ai.edge.**

# Play Billing / Play Integrity (chỉ có khi bật bằng -PuseBilling / -PuseIntegrity)
-keep class com.android.billingclient.** { *; }
-keep class com.google.android.play.core.integrity.** { *; }
-dontwarn com.android.billingclient.**
-dontwarn com.google.android.play.**

# Kotlin coroutines (đã có luật đi kèm thư viện; giữ tên dịch vụ để chắc)
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Mã của app: nhiều chỗ đọc / ghi JSON và enum theo tên (OpType.key, LayerPreset...) — giữ nguyên để khỏi phải dò từng chỗ
-keep class com.aiphoto.studio.** { *; }
