package com.aiphoto.studio

import com.aiphoto.studio.ai.LlmPlanner
import com.aiphoto.studio.ai.LlmPrompts
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.TextGen
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R15: tách TextGen khỏi LlmPlanner (MediaPipe <-> LiteRT-LM) và đường Agent nhìn ảnh ngay trên máy. */
class R15Test {

    /** TextGen giả: ghi lại prompt/ảnh nhận được, trả về câu trả lời định sẵn. */
    private class FakeGen(override val supportsImage: Boolean, private val reply: String, private val failClose: Boolean = false) : TextGen {
        val prompts = ArrayList<String>()
        val images = ArrayList<String?>()
        var closed = 0
        override fun generate(prompt: String, imagePath: String?): String {
            prompts.add(prompt); images.add(imagePath); return reply
        }
        override fun close() { closed++; if (failClose) throw IllegalStateException("đóng lỗi") }
    }

    private val brightnessJson = """{"ops":[{"op":"brightness","value":0.2}]}"""

    // ------------------------------------------------------------------ LlmPrompts
    @Test fun planPromptHasSpecAndRequest() {
        val p = LlmPrompts.plan("làm da mịn")
        assertTrue(p.contains("Allowed ops:"))
        assertTrue(p.contains("Request: \"làm da mịn\""))
        assertTrue(p.endsWith("\n"))
        assertTrue(p.contains("colorize: value 0.0..1.0"))               // phép mới nhất của bản MediaPipe vẫn còn trong prompt
    }

    @Test fun planPromptNeutralisesQuotesAndNewlines() {
        val p = LlmPrompts.plan("tăng \"sáng\"\nvà ấm")
        assertTrue(p.contains("Request: \"tăng 'sáng' và ấm\""))        // nháy kép -> nháy đơn, xuống dòng -> dấu cách (chống phá JSON/prompt)
    }

    @Test fun imagePlanReusesPlanPromptAfterVisionIntro() {
        val p = LlmPrompts.imagePlan("làm ảnh ấm hơn")
        assertTrue(p.startsWith("The attached photo is the image to edit."))
        assertTrue(p.endsWith(LlmPrompts.plan("làm ảnh ấm hơn")))
    }

    @Test fun translatePromptOnlyForNonAscii() {
        assertNull(LlmPrompts.translate("a red hat"))
        val t = LlmPrompts.translate("một chiếc mũ đỏ")
        assertNotNull(t)
        assertTrue(t!!.contains("Stable Diffusion") && t.contains("Text: \"một chiếc mũ đỏ\""))
    }

    // ------------------------------------------------------------------ LlmPlanner qua TextGen giả
    @Test fun planFullParsesOpsAndScopes() {
        val g = FakeGen(false, """{"ops":[{"op":"brightness","value":0.2},{"op":"saturation","value":0.35,"scope":"sky"}]}""")
        val parsed = LlmPlanner(g).planFull("sáng hơn, trời xanh hơn")
        assertNotNull(parsed)
        assertEquals(OpType.BRIGHTNESS, parsed!!.ops[0].type)
        assertEquals(0.2f, parsed.ops[0].value, 1e-6f)
        assertEquals("sky", parsed.scoped[0].scope)
        assertEquals(listOf<String?>(null), g.images)                        // đường văn bản không gửi ảnh
        assertEquals(LlmPrompts.plan("sáng hơn, trời xanh hơn"), g.prompts[0])
    }

    @Test fun planFullReturnsNullOnGarbage() {
        assertNull(LlmPlanner(FakeGen(false, "xin lỗi, tôi không hiểu")).planFull("x"))
        assertNull(LlmPlanner(FakeGen(false, """{"ops":[]}""")).planFull("x"))
        assertNull(LlmPlanner(FakeGen(false, """{"ops":[{"op":"khong_co","value":1}]}""")).plan("x"))
    }

    @Test fun planFromImageNeedsMultimodalBackend() {
        val textOnly = FakeGen(false, brightnessJson)
        assertTrue(!LlmPlanner(textOnly).supportsImage)
        assertNull(LlmPlanner(textOnly).planFromImage("/tmp/a.jpg", "sáng hơn"))
        assertTrue(textOnly.prompts.isEmpty())                               // không gọi model khi không hỗ trợ ảnh (không tốn thời gian)

        val vision = FakeGen(true, brightnessJson)
        val planner = LlmPlanner(vision)
        assertTrue(planner.supportsImage)
        val parsed = planner.planFromImage("/tmp/a.jpg", "sáng hơn")
        assertEquals(OpType.BRIGHTNESS, parsed!!.ops[0].type)
        assertEquals(listOf<String?>("/tmp/a.jpg"), vision.images)
        assertEquals(LlmPrompts.imagePlan("sáng hơn"), vision.prompts[0])
    }

    @Test fun planFromImageGarbageReturnsNull() {
        assertNull(LlmPlanner(FakeGen(true, "tôi thấy một bức ảnh đẹp")).planFromImage("/tmp/a.jpg", "x"))
    }

    @Test fun translateToEnglishBehaviour() {
        val ascii = FakeGen(false, "không dùng")
        assertEquals("a red hat", LlmPlanner(ascii).translateToEnglish("a red hat"))
        assertTrue(ascii.prompts.isEmpty())                                  // đã là ASCII: không gọi model

        assertEquals("a red hat", LlmPlanner(FakeGen(false, "  \"a red hat\"  \nghi chú thừa")).translateToEnglish("một chiếc mũ đỏ"))
        assertEquals("một chiếc mũ đỏ", LlmPlanner(FakeGen(false, "   ")).translateToEnglish("một chiếc mũ đỏ"))   // rỗng -> giữ nguyên
    }

    @Test fun closeDelegatesAndSwallowsErrors() {
        val ok = FakeGen(false, brightnessJson)
        LlmPlanner(ok).close()
        assertEquals(1, ok.closed)
        val bad = FakeGen(false, brightnessJson, failClose = true)
        LlmPlanner(bad).close()                                              // không ném lỗi ra ngoài
        assertEquals(1, bad.closed)
    }
}
