package com.aiphoto.studio

import com.aiphoto.studio.engine.BuiltInModels
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.Upscale
import com.aiphoto.studio.engine.UpscaleTarget
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** R46: tính năng Phóng to (Upscale) — kế hoạch theo mục tiêu, giới hạn bộ nhớ, số ô, ETA, và model AI đi kèm trong assets. */
class R46UpscaleTest {
    private fun asset(rel: String): File =
        listOf("app/src/main/assets/$rel", "src/main/assets/$rel").map { File(it) }.firstOrNull { it.exists() } ?: throw AssertionError("không thấy assets/$rel")

    // ------------------------------------------------------------ hệ số cần xin

    @Test fun fixedFactorTargetsAskForExactlyThatFactor() {
        assertEquals(2, Upscale.wantFactor(UpscaleTarget.X2, 1000, 800))
        assertEquals(3, Upscale.wantFactor(UpscaleTarget.X3, 1000, 800))
        assertEquals(4, Upscale.wantFactor(UpscaleTarget.X4, 1000, 800))
    }

    @Test fun longSideTargetsPickTheSmallestFactorThatReachesIt() {
        assertEquals(2, Upscale.wantFactor(UpscaleTarget.FHD, 1000, 600))    // 1000·2 = 2000 ≥ 1920
        assertEquals(4, Upscale.wantFactor(UpscaleTarget.FHD, 600, 400))     // 600·3 = 1800 < 1920 ⇒ ×4
        assertEquals(2, Upscale.wantFactor(UpscaleTarget.QHD, 1080, 2400))   // cạnh dài 2400 < 2560 ⇒ ×2
        assertEquals(2, Upscale.wantFactor(UpscaleTarget.UHD, 1080, 2400))   // ceil(1,6) = 2
        assertEquals(3, Upscale.wantFactor(UpscaleTarget.UHD, 1600, 900))    // ceil(2,4) = 3
    }

    @Test fun imagesAlreadyLargeEnoughNeedNoUpscale() {
        assertEquals(0, Upscale.wantFactor(UpscaleTarget.FHD, 1920, 1080))
        assertEquals(0, Upscale.wantFactor(UpscaleTarget.UHD, 4000, 3000))
        assertFalse(Upscale.plan(UpscaleTarget.FHD, 2000, 1000, 4096).needed)
        assertFalse(Upscale.plan(UpscaleTarget.FHD, 2000, 1000, 4096).canRun)
    }

    @Test fun invalidSizesAreRejected() {
        assertEquals(0, Upscale.wantFactor(UpscaleTarget.X2, 0, 800))
        assertEquals(0, Upscale.wantFactor(UpscaleTarget.X4, 800, -1))
        assertFalse(Upscale.plan(UpscaleTarget.X2, 0, 0, 4096).needed)
    }

    // ------------------------------------------------------------ kế hoạch + giới hạn

    @Test fun planWithPlentyOfMemoryReachesTheRequestedSize() {
        val p = Upscale.plan(UpscaleTarget.X4, 1000, 800, ImageEngine.UPSCALE_MAX_SIDE)
        assertEquals(4, p.wantFactor)
        assertEquals(4000, p.outW)
        assertEquals(3200, p.outH)
        assertFalse(p.limited)
        assertTrue(p.canRun)
        assertEquals(12.8, p.megapixels, 0.001)
    }

    @Test fun planIsLimitedByTheLongSideCapAndSaysSo() {
        val p = Upscale.plan(UpscaleTarget.X4, 1536, 1024, ImageEngine.UPSCALE_MAX_SIDE)   // 1536·4 = 6144 > 4096
        assertTrue(p.limited)
        assertEquals(4096, p.outW)
        assertEquals(2731, p.outH)
        assertEquals(4096f / 1536f, p.factor, 0.0001f)
        assertTrue(p.canRun)
    }

    @Test fun phoneScreenshotCannotReachTimesTwoWithTheHardCap() {
        // ảnh trong lỗi thực tế: 1080×2400, ×2 ⇒ 4800 > 4096 ⇒ chỉ được ≈ ×1,71 — kế hoạch phải nói trước chứ không im lặng
        val p = Upscale.plan(UpscaleTarget.X2, 1080, 2400, ImageEngine.UPSCALE_MAX_SIDE)
        assertTrue(p.limited)
        assertEquals(4096, p.outH)
        assertEquals(1843, p.outW)
        assertTrue(p.canRun)
    }

    @Test fun veryLowMemoryMeansNoUpscale() {
        // cạnh dài tối đa chỉ hơn ảnh vào 2% ⇒ hệ số < ×1,25 ⇒ OnnxUpscaler trả nguyên ảnh ⇒ không chạy
        val p = Upscale.plan(UpscaleTarget.X2, 4000, 3000, 4080)
        assertTrue(p.needed)
        assertTrue(p.limited)
        assertFalse(p.canRun)
        val none = Upscale.plan(UpscaleTarget.X2, 4000, 3000, 4000)       // trần = chính ảnh ⇒ hệ số 1
        assertEquals(1f, none.factor, 0f)
        assertFalse(none.canRun)
    }

    @Test fun minimumFactorMatchesWhatTheEngineWillActuallyRun() {
        assertEquals(1.25f, Upscale.MIN_FACTOR, 0f)
    }

    // ------------------------------------------------------------ số ô và thời gian còn lại

    @Test fun tileCountMatchesTheEngineTiling() {
        // 1080×2400 ×2: ảnh vào = 540×1200 (chia 4 vì model ×4), lõi ô = 128 − 20 = 108 ⇒ 5 × 12 = 60 ô
        assertEquals(60, Upscale.tileCount(1080, 2400, 2f))
        // ×4: ảnh vào = 1080×2400 ⇒ 10 × 23 = 230 ô
        assertEquals(230, Upscale.tileCount(1080, 2400, 4f))
        // ảnh nhỏ: một ô
        assertEquals(1, Upscale.tileCount(100, 100, 2f))
    }

    @Test fun tileCountIsZeroWhenNothingWillRun() {
        assertEquals(0, Upscale.tileCount(1080, 2400, 1.1f))
        assertEquals(0, Upscale.tileCount(0, 100, 2f))
    }

    @Test fun etaFromAverageTileTime() {
        assertEquals(18, Upscale.etaSeconds(done = 1, total = 10, elapsedMs = 2000))    // 2 s/ô × 9 ô còn lại
        assertEquals(0, Upscale.etaSeconds(10, 10, 20_000))
        assertEquals(-1, Upscale.etaSeconds(0, 10, 0))
        assertEquals(-1, Upscale.etaSeconds(0, 0, 0))
        assertEquals(30, Upscale.etaSeconds(5, 10, 30_000))
    }

    // ------------------------------------------------------------ model đi kèm trong assets

    @Test fun bundledModelFileIsTheExactOneWeVerified() {
        val f = asset("${BuiltInModels.ASSET_DIR}/${BuiltInModels.ESRGAN_ASSET}")
        assertEquals(BuiltInModels.ESRGAN_BYTES, f.length())
        assertEquals(BuiltInModels.ESRGAN_SHA256, BuiltInModels.sha256Hex(f))
    }

    @Test fun bundledModelIsAnOnnxGraphWithTheInputAndOutputTheEngineExpects() {
        val bytes = asset("${BuiltInModels.ASSET_DIR}/${BuiltInModels.ESRGAN_ASSET}").readBytes()
        val text = String(bytes, Charsets.ISO_8859_1)
        // tên đầu vào/đầu ra của đồ thị do tools/export_realesrgan_onnx.py đặt; OnnxUpscaler lấy tên đầu vào đầu tiên và đọc kích thước ô từ shape
        assertTrue(text.contains("input"))
        assertTrue(text.contains("output"))
        assertTrue("phải có toán tử Conv và DepthToSpace của SRVGGNetCompact", text.contains("Conv") && text.contains("DepthToSpace"))
        assertTrue("phải có PRelu", text.contains("PRelu"))
    }

    @Test fun bundledModelShipsWithItsBsdLicense() {
        val t = asset(BuiltInModels.ESRGAN_LICENSE_ASSET).readText(Charsets.UTF_8)
        assertTrue(t.contains("BSD 3-Clause License"))
        assertTrue(t.contains("Xintao Wang"))
        assertTrue("điều 2: bản nhị phân phải kèm thông báo bản quyền", t.contains("Redistributions in binary form must reproduce"))
    }

    @Test fun everyTargetHasAUsableLabelAndExactlyOneKindOfGoal() {
        for (t in UpscaleTarget.values()) {
            assertTrue(t.label.isNotBlank())
            assertTrue("mỗi mục tiêu hoặc là hệ số cố định hoặc là cạnh dài", (t.factor > 0) != (t.longSide > 0))
        }
        assertEquals(6, UpscaleTarget.values().size)
    }
}
