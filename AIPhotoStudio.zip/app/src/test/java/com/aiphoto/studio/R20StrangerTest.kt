package com.aiphoto.studio

import com.aiphoto.studio.ai.StrangerIntent
import com.aiphoto.studio.engine.StrangerMask
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

/** R20: "Xóa người lạ" — chọn ai giữ / ai xóa theo cỡ mặt, dựng mặt nạ cả người, bảo vệ chủ thể. */
class R20StrangerTest {

    private val W = 400
    private val H = 600

    /** Giả lập 478 điểm mốc (chuẩn hóa 0..1): elip quanh (cx,cy) rộng fw cao fh; điểm 10 = trán, 152 = cằm (nghiêng [tiltDeg] độ). */
    private fun face(cx: Float, cy: Float, fw: Float, fh: Float, tiltDeg: Double = 0.0): FloatArray {
        val a = FloatArray(2 * 478)
        for (i in 0 until 478) {
            val t = 2.0 * Math.PI * i / 478
            a[2 * i] = ((cx + fw / 2 * cos(t)) / W).toFloat()
            a[2 * i + 1] = ((cy + fh / 2 * sin(t)) / H).toFloat()
        }
        val r = Math.toRadians(tiltDeg)
        // trục thân nghiêng: cằm lệch sang +x khi tilt > 0
        val ux = sin(r).toFloat()
        val uy = cos(r).toFloat()
        a[2 * 10] = (cx - ux * fh / 2) / W; a[2 * 10 + 1] = (cy - uy * fh / 2) / H
        a[2 * 152] = (cx + ux * fh / 2) / W; a[2 * 152 + 1] = (cy + uy * fh / 2) / H
        return a
    }

    private fun m(res: StrangerMask.Result, x: Int, y: Int) = res.mask[y * W + x].toInt() != 0

    // chủ thể: mặt 50×62 ở (140,170) → vai rộng ≈ 80 → thân chiếm x≈50..230; người lạ nhỏ hơn hẳn ở bên phải
    private val main = face(140f, 170f, 50f, 62f)
    private val stranger = face(330f, 300f, 24f, 30f)

    // ---------------------------------------------------------------- hình học cơ bản
    @Test fun faceBoxesMatchTheLandmarks() {
        val b = StrangerMask.faceBoxes(listOf(main, stranger), W, H)
        assertEquals(2, b.size)
        assertEquals(50f, b[0].fw, 1.5f); assertEquals(62f, b[0].fh, 1.5f)
        assertEquals(140f, b[0].cx, 1.5f); assertEquals(170f, b[0].cy, 1.5f)
        assertEquals(0f, b[0].ax, 0.02f); assertEquals(1f, b[0].ay, 0.02f)
        assertEquals(24f, b[1].fw, 1f)
    }

    @Test fun bodyAxisFollowsTheHeadTiltButIsClamped() {
        val t20 = StrangerMask.faceBoxes(listOf(face(200f, 150f, 80f, 100f, 20.0)), W, H)[0]
        assertEquals(Math.sin(Math.toRadians(20.0)).toFloat(), t20.ax, 0.03f)
        val t70 = StrangerMask.faceBoxes(listOf(face(200f, 150f, 80f, 100f, 70.0)), W, H)[0]
        assertEquals("nghiêng quá → kẹp ở 30°", Math.sin(Math.toRadians(30.0)).toFloat(), t70.ax, 0.01f)
        val tNeg = StrangerMask.faceBoxes(listOf(face(200f, 150f, 80f, 100f, -20.0)), W, H)[0]
        assertTrue(tNeg.ax < -0.3f)
    }

    @Test fun degenerateFacesAreIgnored() {
        assertTrue(StrangerMask.faceBoxes(listOf(FloatArray(0), FloatArray(4)), W, H).isEmpty())
        val dot = FloatArray(2 * 478) { 0.5f }
        assertTrue(StrangerMask.faceBoxes(listOf(dot), W, H).isEmpty())
    }

    // ---------------------------------------------------------------- ai giữ, ai xóa
    @Test fun splitKeepsComparableFacesAndDropsTheSmallOnes() {
        fun f(side: Float) = StrangerMask.Face(0f, 0f, side, side, 0f, 1f)
        val (keep, drop) = StrangerMask.split(listOf(f(100f), f(80f), f(40f), f(20f)))
        assertEquals(2, keep.size)          // 100 và 80 (diện tích 64% ≥ 45%)
        assertEquals(2, drop.size)          // 40 (16%) và 20 (4%)
        // ảnh nhóm: mặt gần bằng nhau → không ai là người lạ
        val (k2, d2) = StrangerMask.split(listOf(f(90f), f(100f), f(95f)))
        assertEquals(3, k2.size); assertTrue(d2.isEmpty())
        // ranh giới: 67% cạnh = 45% diện tích → giữ; nhỏ hơn chút → xóa
        assertTrue(StrangerMask.split(listOf(f(100f), f(67.5f))).second.isEmpty())
        assertTrue(StrangerMask.split(listOf(f(100f), f(67f))).second.isNotEmpty())
        assertTrue(StrangerMask.split(listOf(f(100f), f(68f))).second.isEmpty())
        assertEquals(Pair(emptyList<StrangerMask.Face>(), emptyList<StrangerMask.Face>()), StrangerMask.split(emptyList()))
    }

    @Test fun nothingToRemoveWhenEveryoneIsPartOfTheSubject() {
        assertNull(StrangerMask.build(listOf(main), W, H))                                  // một người
        assertNull(StrangerMask.build(listOf(main, face(300f, 180f, 46f, 58f)), W, H))       // hai người cùng cỡ
        assertNull(StrangerMask.build(emptyList(), W, H))
    }

    // ---------------------------------------------------------------- mặt nạ
    @Test fun strangerIsMaskedFromHeadToToeAndTheSubjectIsNot() {
        val res = StrangerMask.build(listOf(main, stranger), W, H)
        assertNotNull(res); res!!
        assertEquals(1, res.kept); assertEquals(1, res.removed)
        // đầu, thân, chân của người lạ
        assertTrue("đầu", m(res, 330, 300))
        assertTrue("cổ/ngực", m(res, 330, 300 + 45))
        assertTrue("thân", m(res, 330, 300 + 3 * 30))
        assertTrue("chân", m(res, 330 - 10, 300 + 6 * 30))
        // chủ thể: mặt và thân hoàn toàn không bị đụng
        for ((x, y) in listOf(140 to 170, 110 to 160, 170 to 180, 140 to 260, 140 to 300, 100 to 280)) assertFalse("chủ thể ($x,$y)", m(res, x, y))
        // cảnh xa người lạ không bị xóa
        assertFalse(m(res, 20, 20)); assertFalse(m(res, 60, 550))
        assertTrue("diện tích hợp lý ${res.coverage}", res.coverage in 0.005f..0.12f)
    }

    @Test fun mostOfTheTemplateBodyIsCovered() {
        val res = StrangerMask.build(listOf(main, stranger), W, H)!!
        // khối thân (vai → hông): ≥ 85% điểm nằm trong mặt nạ
        var tot = 0; var hit = 0
        for (y in 300 + 40..300 + 4 * 30 - 6) for (x in 330 - 30..330 + 30) { tot++; if (m(res, x, y)) hit++ }
        assertTrue("thân phủ ${hit * 100 / tot}%", hit * 100 / tot >= 85)
    }

    @Test fun protectedSubjectWinsWhenTheStrangerStandsBehindIt() {
        // người lạ nhỏ đứng ngay sau thân chủ thể: vùng chồng lấn thuộc về chủ thể, phần lộ ra vẫn bị xóa
        val behind = face(200f, 300f, 24f, 30f)
        val res = StrangerMask.build(listOf(main, behind), W, H)!!
        val removed = res.mask.count { it.toInt() != 0 }
        assertTrue("vẫn có vùng xóa ($removed)", removed > 200)
        assertTrue("phần thân lộ ra bên phải chủ thể", m(res, 232, 380))
        val hx = 34; val hy = 46     // bán kính elip đầu chủ thể (0,68·fw và 0,74·fh)
        for (y in 100..420) for (x in 50..230) {
            val inHead = ((x - 140.0) / hx).let { it * it } + ((y - 162.0) / hy).let { it * it } <= 1.0
            val inTorso = y in 240..420 && kotlin.math.abs(x - 140) <= 50
            if (inHead || inTorso) assertFalse("lõi chủ thể bị xóa nhầm ($x,$y)", m(res, x, y))
        }
    }

    @Test fun tiltedStrangerHasTiltedBody() {
        val straight = StrangerMask.build(listOf(main, face(300f, 200f, 24f, 30f, 0.0)), W, H)!!
        val tilted = StrangerMask.build(listOf(main, face(300f, 200f, 24f, 30f, 28.0)), W, H)!!
        fun cx(res: StrangerMask.Result): Double {
            var s = 0.0; var n = 0
            for (y in 300..480) for (x in 0 until W) if (m(res, x, y)) { s += x; n++ }
            return s / n
        }
        val shift = cx(tilted) - cx(straight)
        assertTrue("thân nghiêng theo đầu: dịch ${"%.1f".format(shift)} px sang phải", shift > 12.0)
    }

    @Test fun strangerNearTheFrameEdgeIsClippedNotCrashing() {
        val edge = face(385f, 565f, 30f, 36f)          // sát góc dưới phải, thân ra ngoài khung
        val res = StrangerMask.build(listOf(main, edge), W, H)!!
        assertEquals(W * H, res.mask.size)
        assertTrue(m(res, 385, 565))
    }

    @Test fun segmentationRefinesTheTemplateToTheRealBody() {
        val plain = StrangerMask.build(listOf(main, stranger), W, H)!!
        // người thật gọn hơn khuôn mẫu: dải rộng 40 quanh trục thân; chủ thể chính cũng nằm trong fg
        val fg = FloatArray(W * H)
        for (y in 0 until H) for (x in 0 until W) {
            if (x in 310..350 && y in 285..470) fg[y * W + x] = 1f                         // người lạ
            if (x in 90..190 && y in 100..330) fg[y * W + x] = 1f                          // chủ thể chính
        }
        val refined = StrangerMask.build(listOf(main, stranger), W, H, fg)!!
        assertTrue("mặt nạ bám cơ thể nên nhỏ hơn khuôn mẫu: ${refined.coverage} < 0,8·${plain.coverage}", refined.coverage < plain.coverage * 0.8f)
        // vẫn phủ phần cơ thể thật (trừ viền ngoài cùng) và cả đầu
        for (y in 310..450 step 7) for (x in 316..344 step 4) assertTrue("thân thật ($x,$y)", m(refined, x, y))
        assertTrue(m(refined, 330, 292))
        // chủ thể chính vẫn được bảo vệ dù nằm trong fg
        assertFalse(m(refined, 140, 200))
    }

    @Test fun uselessSegmentationFallsBackToTheTemplate() {
        val plain = StrangerMask.build(listOf(main, stranger), W, H)!!
        val empty = StrangerMask.build(listOf(main, stranger), W, H, FloatArray(W * H))!!       // model không thấy gì
        assertEquals(plain.coverage, empty.coverage, 1e-6f)
        val wrongSize = StrangerMask.build(listOf(main, stranger), W, H, FloatArray(10))!!      // sai kích thước → bỏ qua
        assertEquals(plain.coverage, wrongSize.coverage, 1e-6f)
    }

    @Test fun manyStrangersAreAllRemoved() {
        val crowd = listOf(main, face(350f, 230f, 22f, 28f), face(300f, 330f, 20f, 26f), face(360f, 430f, 22f, 28f), face(290f, 520f, 20f, 26f))
        val res = StrangerMask.build(crowd, W, H)!!
        assertEquals(1, res.kept); assertEquals(4, res.removed)
        for ((x, y) in listOf(350 to 230, 300 to 330, 360 to 430, 290 to 520)) assertTrue("($x,$y)", m(res, x, y))
        assertFalse(m(res, 140, 170))
    }

    // ---------------------------------------------------------------- hiểu câu lệnh
    @Test fun strangerRemovalPromptsAreRecognised() {
        for (p in listOf(
            "Xóa người lạ", "xóa những người qua đường ở phía sau", "xoá người lạ trong ảnh", "loại bỏ khách du lịch", "bỏ đi đám đông phía sau",
            "xóa người phía sau", "remove the strangers", "remove tourists from the background", "erase bystanders", "get rid of the people in the background",
            "delete other people", "xóa người thừa"
        )) assertTrue("\"$p\"", StrangerIntent.isStrangerRemoval(p))
    }

    @Test fun otherPromptsAreNotStrangerRemoval() {
        for (p in listOf(
            "xóa người", "xóa mụn", "xóa nền", "thêm người lạ", "tăng sáng", "xóa mọi người", "xóa người bên trái", "làm mịn da", "", "người lạ",
            "remove the background", "add a stranger"
        )) assertFalse("\"$p\"", StrangerIntent.isStrangerRemoval(p))
    }
}
