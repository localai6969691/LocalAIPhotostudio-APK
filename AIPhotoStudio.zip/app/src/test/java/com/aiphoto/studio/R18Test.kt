package com.aiphoto.studio

import com.aiphoto.studio.ai.AcceleratorPolicy
import com.aiphoto.studio.ai.LlmBackends
import com.aiphoto.studio.ai.LlmPlanner
import com.aiphoto.studio.ai.TextGen
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R18: chính sách thử NPU trung lập theo hãng chip. Tên tệp lấy từ tài liệu LiteRT-LM (cập nhật 09/2026). */
class R18Test {

    private val arm = listOf("arm64-v8a", "armeabi-v7a")

    /** tên tệp trong tài liệu -> SoC (Build.SOC_MODEL) mà nó được biên dịch cho (Qualcomm, MediaTek, Google Tensor). */
    private val files = mapOf(
        "Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm" to "SM8750",
        "Gemma3-1B-IT_q4_ekv1280_sm8650.litertlm" to "SM8650",
        "Gemma3-1B-IT_q4_ekv1280_sm8550.litertlm" to "SM8550",
        "Gemma3-1B-IT_q4_ekv1280_mt6989.litertlm" to "MT6989",
        "Gemma3-1B-IT_q4_ekv1280_mt6991.litertlm" to "MT6991",
        "gemma-4-E2B-it_Google_tensor_g6.litertlm" to "Tensor_G6"
    )

    @Test fun eachNpuFileMatchesOnlyItsOwnSoc() {
        for ((f, soc) in files) assertTrue("$f trên $soc", AcceleratorPolicy.mayUseNpu(34, arm, f, soc))
        for ((f, soc) in files) for (other in files.values) {
            if (other != soc) assertFalse("$f không được khớp $other", AcceleratorPolicy.mayUseNpu(34, arm, f, other))
        }
    }

    @Test fun genericModelsNeverTriggerNpu() {
        val generic = listOf("gemma-4-E2B-it.litertlm", "Gemma3-1B-IT_q4_ekv1280.litertlm", "gemma-3n-E2B-it.litertlm", "model.litertlm", "llm.litertlm")
        for (f in generic) for (soc in files.values) assertFalse("$f trên $soc", AcceleratorPolicy.mayUseNpu(34, arm, f, soc))
    }

    @Test fun platformGates() {
        val f = "Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm"
        assertTrue(AcceleratorPolicy.mayUseNpu(31, arm, f, "SM8750"))
        assertFalse(AcceleratorPolicy.mayUseNpu(30, arm, f, "SM8750"))            // minSdk của dự án là 26: phải chặn lúc chạy
        assertFalse(AcceleratorPolicy.mayUseNpu(26, arm, f, "SM8750"))
        assertFalse(AcceleratorPolicy.mayUseNpu(34, listOf("armeabi-v7a", "x86_64"), f, "SM8750"))
        assertFalse(AcceleratorPolicy.mayUseNpu(34, emptyList(), f, "SM8750"))
    }

    @Test fun edgeCases() {
        val f = "Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm"
        for (soc in listOf("", " ", "unknown", "UNKNOWN", null)) assertFalse("soc=$soc", AcceleratorPolicy.mayUseNpu(34, arm, f, soc))
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, null, "SM8750"))
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, "", "SM8750"))
        assertTrue(AcceleratorPolicy.mayUseNpu(34, arm, "  GEMMA3-1B-IT_Q4_EKV1280_SM8750.LITERTLM ", " sm8750 "))   // hoa/thường, khoảng trắng
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, "_sm8750.litertlm", "SM8750"))                             // thiếu tên model
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, "Gemma3-1B-IT_xsm8750.litertlm", "SM8750"))                // thiếu '_' trước SoC
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, "Gemma3-1B-IT_q4_ekv1280_sm8750.task", "SM8750"))          // sai đuôi
        assertFalse(AcceleratorPolicy.mayUseNpu(34, arm, f, "sm.*"))                                                // không phải regex
        assertEquals("", AcceleratorPolicy.normalizeSoc("unknown"))
        assertEquals("tensor_g6", AcceleratorPolicy.normalizeSoc(" Tensor_G6 "))
    }

    // ------------------------------------------------------------------ tên tệp gốc lưu cạnh model
    @Test fun originalNameSidecarRoundTrip() {
        val dir = java.nio.file.Files.createTempDirectory("r18").toFile()
        try {
            val model = File(dir, "llm.litertlm").absolutePath
            assertNull(LlmBackends.originalName(model))                                  // chưa có
            LlmBackends.writeOriginalName(model, "  Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm \n")
            assertEquals("Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm", LlmBackends.originalName(model))
            LlmBackends.writeOriginalName(model, "gemma-4-E2B-it.litertlm")             // ghi đè
            assertEquals("gemma-4-E2B-it.litertlm", LlmBackends.originalName(model))
            LlmBackends.writeOriginalName(model, null)                                   // xoá
            assertNull(LlmBackends.originalName(model))
            LlmBackends.writeOriginalName(model, "   ")                                  // rỗng cũng xoá, không ném lỗi
            assertNull(LlmBackends.originalName(model))
            assertTrue(LlmBackends.isLiteRtLm("/x/llm.LITERTLM") && !LlmBackends.isLiteRtLm("/x/llm.task"))
        } finally {
            dir.deleteRecursively()
        }
    }

    // ------------------------------------------------------------------ backendName được chuyển tiếp
    private class NamedGen(private val name: String?) : TextGen {
        override val supportsImage = false
        override val backendName: String get() = name ?: super.backendName
        override fun generate(prompt: String, imagePath: String?) = "{}"
        override fun close() {}
    }

    private class DefaultGen : TextGen {
        override val supportsImage = false
        override fun generate(prompt: String, imagePath: String?) = "{}"
        override fun close() {}
    }

    @Test fun backendNameIsForwardedAndDefaultsToQuestionMark() {
        assertEquals("NPU", LlmPlanner(NamedGen("NPU")).backendName)
        assertEquals("GPU", LlmPlanner(NamedGen("GPU")).backendName)
        assertEquals("?", LlmPlanner(DefaultGen()).backendName)
    }
}
