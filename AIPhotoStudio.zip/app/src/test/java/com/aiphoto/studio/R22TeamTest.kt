package com.aiphoto.studio

import com.aiphoto.studio.engine.ProxyBackend
import com.aiphoto.studio.engine.TeamInfo
import com.aiphoto.studio.engine.TeamText
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R22: phía app của gói Team/Enterprise. Dữ liệu mẫu là phản hồi THẬT chụp từ backend/server.py (đã chạy bằng backend/test_server.py), nên
 * test này giữ cho hai phía khớp nhau: máy chủ đổi dạng phản hồi mà app không đổi theo thì test đỏ.
 */
class R22TeamTest {
    // ---- phản hồi thật của máy chủ (json.dumps mặc định: tiếng Việt thành \uXXXX)
    private val ACCOUNT_MEMBER = """{"plan": "pro", "plan_until": 1795317753, "credits": 12, "credits_personal": 2, "credits_team": 10, "limits": {"high_quality": true, "watermark": false}, "subscription": null, "team": {"team_id": "7b309292a356fd7f", "name": "Studio Ánh Sáng", "role": "member", "seats": 3, "members": 2, "credits": 10, "plan_until": 1795317753, "you": "a91d85b1f0191ee82fb909e1e44876ae"}}"""
    private val ACCOUNT_SOLO = """{"plan": "free", "plan_until": 0, "credits": 2, "credits_personal": 2, "credits_team": 0, "limits": {"high_quality": false, "watermark": true}, "subscription": null, "team": null}"""
    private val TEAM_ADMIN = """{"team": {"team_id": "7b309292a356fd7f", "name": "Studio Ánh Sáng", "role": "admin", "seats": 3, "members": 2, "credits": 10, "plan_until": 1795317753, "you": "887cd3abdbca6ebf0bc1a5572fa2c40c", "member_list": [{"member_id": "887cd3abdbca6ebf0bc1a5572fa2c40c", "role": "admin", "joined": 1792725753}, {"member_id": "a91d85b1f0191ee82fb909e1e44876ae", "role": "member", "joined": 1792725753}]}}"""
    private val TEAM_MEMBER = """{"team": {"team_id": "7b309292a356fd7f", "name": "Studio Ánh Sáng", "role": "member", "seats": 3, "members": 2, "credits": 10, "plan_until": 1795317753, "you": "a91d85b1f0191ee82fb909e1e44876ae"}}"""
    private val ERR_WRONG_CODE = """{"error": "mã mời không đúng"}"""
    private val ERR_ADMIN_LEAVE = """{"error": "quản trị viên cần chuyển quyền hoặc xóa hết thành viên trước khi rời"}"""
    private val ERR_DISABLED = """{"error": "gói Team chưa được bật trên máy chủ"}"""

    private fun team(json: String) = TeamInfo.fromJson(JSONObject(json).optJSONObject("team"))

    @Test fun memberAccountCarriesTeamPoolAndInheritedPro() {
        val a = ProxyBackend.parseAccount(JSONObject(ACCOUNT_MEMBER))
        assertEquals("pro", a.plan); assertTrue(a.isPro)
        assertEquals(12, a.credits); assertEquals(2, a.creditsPersonal); assertEquals(10, a.creditsTeam)
        assertFalse(a.watermark); assertTrue(a.highQuality)
        val t = a.team!!
        assertEquals("Studio Ánh Sáng", t.name)               // Á -> Á: giải mã đúng
        assertEquals("7b309292a356fd7f", t.teamId)
        assertEquals("member", t.role); assertFalse(t.isAdmin)
        assertEquals(3, t.seats); assertEquals(2, t.members); assertEquals(1, t.seatsLeft)
        assertEquals(10, t.credits); assertEquals(1795317753L, t.planUntil)
        assertTrue(t.memberList.isEmpty())                    // thành viên thường không nhận danh sách
    }

    @Test fun soloAccountHasNoTeamAndNothingChanges() {
        val a = ProxyBackend.parseAccount(JSONObject(ACCOUNT_SOLO))
        assertNull(a.team)
        assertEquals(2, a.credits); assertEquals(2, a.creditsPersonal); assertEquals(0, a.creditsTeam)
        assertFalse(a.isPro); assertTrue(a.watermark)
    }

    @Test fun oldServerWithoutTeamFieldsStillParses() {
        val a = ProxyBackend.parseAccount(JSONObject("""{"plan":"free","plan_until":0,"credits":5,"limits":{"high_quality":false,"watermark":true}}"""))
        assertNull(a.team); assertEquals(5, a.credits); assertEquals(-1, a.creditsPersonal); assertEquals(0, a.creditsTeam)
    }

    @Test fun adminViewListsMembersAndMarksYou() {
        val t = team(TEAM_ADMIN)!!
        assertTrue(t.isAdmin)
        assertEquals(2, t.memberList.size)
        val me = t.memberList.single { it.isYou }
        assertEquals("887cd3abdbca6ebf0bc1a5572fa2c40c", me.memberId); assertTrue(me.isAdmin)
        val other = t.memberList.single { !it.isYou }
        assertEquals("a91d85b1f0191ee82fb909e1e44876ae", other.memberId); assertFalse(other.isAdmin)
        assertEquals(1792725753L, other.joined)
    }

    @Test fun memberViewHasNoList() {
        val t = team(TEAM_MEMBER)!!
        assertFalse(t.isAdmin); assertTrue(t.memberList.isEmpty())
    }

    @Test fun missingOrMalformedTeamIsNullNotACrash() {
        assertNull(TeamInfo.fromJson(null))
        assertNull(team("""{"team": null}"""))
        assertNull(team("""{"team": {}}"""))
        assertNull(team("""{"team": {"team_id": ""}}"""))
        assertNull(team("""{}"""))
        // thành viên hỏng bị bỏ qua, phần còn lại vẫn đọc được; thiếu role -> thành viên thường
        val t = team("""{"team": {"team_id": "x", "name": "N", "seats": 2, "members": 1, "credits": 0, "plan_until": 0, "you": "m1",
            "member_list": [{"role": "admin"}, {"member_id": "m1", "role": "admin", "joined": 5}, "rác", {"member_id": "m2"}]}}""")!!
        assertEquals("member", t.role)
        assertEquals(listOf("m1", "m2"), t.memberList.map { it.memberId })
        assertEquals("member", t.memberList[1].role)
        assertTrue(t.memberList[0].isYou); assertFalse(t.memberList[1].isYou)
    }

    @Test fun noYouFieldMeansNobodyIsMarkedAsYou() {
        val t = team("""{"team": {"team_id": "x", "name": "N", "role": "admin", "seats": 2, "members": 1, "credits": 0, "plan_until": 0,
            "member_list": [{"member_id": "m1", "role": "admin", "joined": 5}]}}""")!!
        assertFalse(t.memberList[0].isYou)
    }

    @Test fun planIsOnlyActiveWhenInTheFuture() {
        val t = team(TEAM_MEMBER)!!
        assertTrue(t.hasPlan(1795317752L)); assertFalse(t.hasPlan(1795317753L)); assertFalse(t.hasPlan(1795317754L))
        assertFalse(team("""{"team": {"team_id": "x", "plan_until": 0}}""")!!.hasPlan(1L))
    }

    @Test fun seatsLeftNeverNegative() {
        val t = team("""{"team": {"team_id": "x", "seats": 2, "members": 5}}""")!!
        assertEquals(0, t.seatsLeft)
    }

    // ---- câu lỗi đọc được: đúng thông điệp máy chủ, kể cả khi thân bị CẮT hoặc không phải JSON
    private fun err(code: Int, body: String) = "Máy chủ trả mã $code: $body"

    @Test fun serverErrorsAreShownAsTheServerSaidThemInVietnamese() {
        assertEquals("mã mời không đúng", TeamText.friendlyError(err(403, ERR_WRONG_CODE)))
        assertEquals("quản trị viên cần chuyển quyền hoặc xóa hết thành viên trước khi rời", TeamText.friendlyError(err(409, ERR_ADMIN_LEAVE)))
        assertEquals("gói Team chưa được bật trên máy chủ", TeamText.friendlyError(err(503, ERR_DISABLED)))
    }

    @Test fun truncatedBodiesDoNotCrashAndKeepTheReadablePart() {
        // ProxyBackend.call cắt thân theo số ký tự: cắt giữa chừng, kể cả giữa một dãy \uXXXX
        val cut = ERR_ADMIN_LEAVE.substring(0, 60)
        val s = TeamText.friendlyError(err(409, cut))
        assertTrue("nên là chữ tiếng Việt đã giải mã, không còn \\u: $s", s.isNotBlank() && !s.contains("\\u"))
        assertTrue(s.startsWith("quản trị viên"))
        for (n in 0..ERR_ADMIN_LEAVE.length step 7) TeamText.friendlyError(err(409, ERR_ADMIN_LEAVE.substring(0, n)))   // không ném lỗi ở mọi điểm cắt
    }

    @Test fun errorFieldIsExtractedWithoutNeedingAWholeJsonBody() {
        // nhánh dự phòng khi JSONObject không đọc được (thân bị cắt): kiểm THẲNG, không qua bộ đọc JSON của nền tảng
        assertEquals("mã mời không đúng", TeamText.extractErrorField(ERR_WRONG_CODE))
        // thiếu cả dấu ngoặc đóng lẫn dấu nháy đóng
        assertEquals("mã mời không đúng", TeamText.extractErrorField("""{"error": "m\u00e3 m\u1eddi kh\u00f4ng \u0111\u00fang"""))
        assertEquals("mã mời không đúng", TeamText.extractErrorField("""{"error": "m\u00e3 m\u1eddi kh\u00f4ng \u0111\u00fang"""" + "}"))
        // cắt giữa một dãy \uXXXX: dấu thoát dở dang bị bỏ, KHÔNG để rác như "\u1e"
        assertEquals("mã m", TeamText.extractErrorField("""{"error": "m\u00e3 m\u1e"""))
        assertEquals("mã m", TeamText.extractErrorField("""{"error": "m\u00e3 m\u"""))
        assertEquals("mã m", TeamText.extractErrorField("""{"error": "m\u00e3 m\u1"""))
        assertEquals("ab", TeamText.extractErrorField("""{"error": "ab\"""))               // dấu \ cuối bị cắt
        assertEquals("ab", TeamText.extractErrorField("""{"error": "ab\uZZZZ"""))          // \u không phải số hex
        // các dấu thoát thường gặp
        assertEquals("a\"b\\c\nd/e", TeamText.extractErrorField("""{"error":"a\"b\\c\nd\/e"}"""))
        assertEquals("x", TeamText.extractErrorField("""{"ok": false, "error" :   "x", "more": 1}"""))
        // không có / rỗng / không phải JSON
        assertNull(TeamText.extractErrorField("""{"ok": true}"""))
        assertNull(TeamText.extractErrorField("""{"error": ""}"""))
        assertNull(TeamText.extractErrorField("""{"error": "   "}"""))
        assertNull(TeamText.extractErrorField("không phải JSON"))
    }

    @Test fun unescapeHandlesTruncatedAndUnusualEscapes() {
        // gọi thẳng (regex của extractErrorField không bao giờ chuyển cho nó một dấu \ lẻ ở cuối, nhưng hàm phải tự an toàn nếu regex đổi)
        assertEquals("ab", TeamText.unescape("ab\\"))
        assertEquals("", TeamText.unescape("\\"))
        assertEquals("ab", TeamText.unescape("ab\\u12"))
        assertEquals("ab", TeamText.unescape("ab\\u"))
        assertEquals("ab", TeamText.unescape("ab\\uXYZW"))
        assertEquals("Á", TeamText.unescape("\\u00c1"))
        assertEquals("ÁB", TeamText.unescape("\\u00C1B"))
        assertEquals("a\tb\rc\u0008d\u000Ce", TeamText.unescape("a\\tb\\rc\\bd\\fe"))
        assertEquals("plain text", TeamText.unescape("plain text"))
        assertEquals("q\"/\\", TeamText.unescape("q\\\"\\/\\\\"))
    }

    @Test fun nonJsonAndEmptyErrorsFallBackSensibly() {
        assertEquals("Không thực hiện được.", TeamText.friendlyError(null))
        assertEquals("Không thực hiện được.", TeamText.friendlyError("   "))
        assertEquals("Máy chủ báo lỗi (mã 502).", TeamText.friendlyError(err(502, "<html>Bad gateway</html>")))
        assertEquals("Thử quá nhiều lần, hãy đợi một lúc.", TeamText.friendlyError(err(429, "")))
        assertEquals("Chưa đăng nhập máy chủ.", TeamText.friendlyError(err(401, "")))
        assertEquals("Máy chủ chưa bật gói Team.", TeamText.friendlyError(err(503, "")))
        assertEquals("timeout", TeamText.friendlyError("timeout"))
        assertEquals("Lỗi \"lạ\"", TeamText.friendlyError(err(400, """{"error": "Lỗi \"lạ\""}""")))
    }

    // ---- mã mời
    @Test fun inviteCodeNormalizationMatchesTheServer() {
        assertEquals("ABCDEFGHJK", TeamText.normalizeCode("  abcde-fg hjk "))
        assertTrue(TeamText.isPlausibleCode("abcde-fghjk"))
        assertTrue(TeamText.isPlausibleCode("ABCDEFGHJK"))
        assertFalse(TeamText.isPlausibleCode("ABCDE-FGHJ"))          // thiếu ký tự
        assertFalse(TeamText.isPlausibleCode("ABCDE-FGHJKL"))        // thừa
        assertFalse(TeamText.isPlausibleCode("ABCD0-FGHJK"))         // 0 / O / 1 / I không có trong bảng chữ cái của máy chủ
        assertFalse(TeamText.isPlausibleCode("ABCDO-FGHJK"))
        assertFalse(TeamText.isPlausibleCode("ABCD1-FGHJK"))
        assertFalse(TeamText.isPlausibleCode("ABCDI-FGHJK"))
        assertEquals("ABCDE-FGHJK", TeamText.displayCode("abcdefghjk"))
        assertEquals("ABC", TeamText.displayCode("abc"))
        // mọi ký tự máy chủ có thể phát ra (bảng chữ cái của server.py) đều được nhận
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        for (i in 0..alphabet.length - 10) assertTrue(TeamText.isPlausibleCode(alphabet.substring(i, i + 10)))
    }

    @Test fun summaryMentionsNameRoleSeatsPoolAndPlan() {
        val t = team(TEAM_ADMIN)!!
        val s = TeamText.summary(t, 1792725753L)
        assertTrue(s, s.contains("Studio Ánh Sáng") && s.contains("quản trị viên") && s.contains("2/3") && s.contains("10 credits") && s.contains("Pro đến"))
        val none = TeamText.summary(team("""{"team": {"team_id": "x", "name": "N", "role": "member", "seats": 1, "members": 1, "credits": 0, "plan_until": 0}}""")!!, 1L)
        assertTrue(none, none.contains("thành viên") && none.contains("không có Pro") && none.contains("0 credits"))
        assertEquals("quản trị viên", TeamText.roleLabel("admin")); assertEquals("thành viên", TeamText.roleLabel("member"))
        assertNotNull(s)
    }
}
