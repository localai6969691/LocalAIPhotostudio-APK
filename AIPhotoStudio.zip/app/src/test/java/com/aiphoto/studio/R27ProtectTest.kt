package com.aiphoto.studio

import com.aiphoto.studio.ai.AutoFrameIntent
import com.aiphoto.studio.ai.BackgroundScene
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.ProtectIntent
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.ScopedOps
import com.aiphoto.studio.ai.StrangerIntent
import com.aiphoto.studio.ai.WholeEditIntent
import com.aiphoto.studio.ai.normalizeScoped
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.ProjectCodec
import com.aiphoto.studio.doc.RecipeCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** R27 "Giữ nguyên X": tách cụm bảo vệ khỏi lệnh, nhận đúng vùng, không cắt nhầm, và cú pháp vùng `not:` an toàn. */
class R27ProtectTest {

    private fun split(p: String) = ProtectIntent.split(p)
    private fun check(p: String, rest: String, vararg scopes: String) {
        val r = split(p)
        assertEquals("rest của \"$p\"", rest, r.rest)
        assertEquals("vùng của \"$p\"", scopes.toList(), r.protect)
    }

    @Test fun vietnameseKeepFaceAfterTheCommand() {
        check("làm sáng ảnh nhưng giữ nguyên khuôn mặt", "làm sáng ảnh", Scope.SKIN)
        check("làm sáng ảnh, giữ nguyên khuôn mặt", "làm sáng ảnh", Scope.SKIN)
        check("làm sáng nền nhưng giữ nguyên khuôn mặt", "làm sáng nền", Scope.SKIN)       // nền là ĐÍCH chỉnh, không phải vùng giữ
        check("làm sáng 40% nhưng giữ nguyên mặt", "làm sáng 40%", Scope.SKIN)              // giữ nguyên số % cho planner
        check("giữ nguyên khuôn mặt, làm sáng ảnh", "làm sáng ảnh", Scope.SKIN)
        check("GIỮ NGUYÊN KHUÔN MẶT làm ấm ảnh", "làm ấm ảnh", Scope.SKIN)
    }

    @Test fun listsOfProtectedAreas() {
        check("giữ nguyên khuôn mặt và tóc, làm sáng ảnh", "làm sáng ảnh", Scope.SKIN, Scope.HAIR)
        check("giữ nguyên mặt, tóc và nền, tăng tương phản", "tăng tương phản", Scope.SKIN, Scope.HAIR, Scope.BACKGROUND)
        check("làm ấm ảnh, giữ nguyên da và tóc, trừ bầu trời", "làm ấm ảnh", Scope.SKIN, Scope.HAIR, Scope.SKY)
        check("tăng tương phản nhưng giữ nguyên mắt và răng", "tăng tương phản", Scope.EYES, Scope.TEETH)
        check("giữ nguyên chủ thể và nhân vật, làm tối ảnh", "làm tối ảnh", Scope.SUBJECT)           // không trùng
    }

    @Test fun commaDoesNotSwallowTheNextCommand() {
        // "nền sáng hơn" là lệnh mới chứ không phải thêm nền vào danh sách giữ nguyên
        check("giữ nguyên mặt, nền sáng hơn", "nền sáng hơn", Scope.SKIN)
        check("giữ nguyên mặt, làm sáng nền", "làm sáng nền", Scope.SKIN)
    }

    @Test fun sentenceAndListBoundaries() {
        check("giữ nguyên mặt. Nền sáng hơn", "Nền sáng hơn", Scope.SKIN)                      // dấu chấm kết thúc cụm: "Nền" là lệnh mới
        check("làm sáng ảnh, giữ nguyên mặt, tóc", "làm sáng ảnh", Scope.SKIN, Scope.HAIR)     // danh sách phẩy chạy tới hết câu
        check("giữ nguyên mặt nhưng làm sáng ảnh", "làm sáng ảnh", Scope.SKIN)                 // từ nối đứng đầu phần còn lại bị bỏ
        check("làm sáng ảnh giữ mặt", "làm sáng ảnh", Scope.SKIN)                              // "giữ" trần cũng là cụm bảo vệ khi theo sau là vùng
        check("giữ nguyên mặt và tóc nhưng nền thì sáng lên", "nền thì sáng lên", Scope.SKIN, Scope.HAIR)
        check("brighten it, keep the face and the hair untouched", "brighten it", Scope.SKIN, Scope.HAIR)
        check("giu nguyen mat nhung nen thi sang len", "nen thi sang len", Scope.SKIN)       // không dấu: "nhung" sau vùng = "nhưng"
        check("giữ nguyên mặt, nhưng nền sáng hơn", "nền sáng hơn", Scope.SKIN)
        check("giữ nguyên những vùng da, làm sáng ảnh", "làm sáng ảnh", Scope.SKIN)           // "những" trước vùng là từ đệm
    }

    @Test fun listEndsAreJudgedByPunctuationAndConnectives() {
        // vùng đứng ngay trước "và" / dấu phẩy là mục của danh sách, kể cả khi sau đó là một lệnh mới
        check("giữ nguyên mặt, tóc và làm sáng ảnh", "làm sáng ảnh", Scope.SKIN, Scope.HAIR)
        check("giữ nguyên mặt, tóc, làm sáng ảnh", "làm sáng ảnh", Scope.SKIN, Scope.HAIR)
        check("giữ nguyên mặt, và nền, làm ấm", "làm ấm", Scope.SKIN, Scope.BACKGROUND)
        // từ đệm kết câu thuộc cụm bảo vệ; vùng ở câu sau là lệnh khác
        check("giữ nguyên mặt, tóc của ảnh. Nền sáng hơn", "Nền sáng hơn", Scope.SKIN, Scope.HAIR)
        check("giữ nguyên mặt, ảnh. Nền sáng hơn", "Nền sáng hơn", Scope.SKIN)
        // "nhưng" mở lệnh mới: vùng sau nó không thuộc danh sách, kể cả khi đứng cuối câu
        check("giữ nguyên mặt, nhưng nền.", "nền.", Scope.SKIN)
        // "unchanged / untouched / as is / nguyên" theo sau vùng bị cắt cùng với cụm bảo vệ ở MỌI cụm kích hoạt, không riêng "keep"
        check("add contrast, preserve the skin untouched", "add contrast", Scope.SKIN)
        check("add contrast, protect the skin as is", "add contrast", Scope.SKIN)
        check("làm sáng ảnh, giữ khuôn mặt nguyên", "làm sáng ảnh", Scope.SKIN)
    }

    @Test fun diacriticVariantsOfFaceAndLookalikes() {
        check("làm sáng ảnh, giữ nguyên khuôn mạt", "làm sáng ảnh", Scope.SKIN)           // gõ nhầm dấu sau "khuôn" vẫn là khuôn mặt
        assertTrue(split("giữ nguyên mất").protect.isEmpty())                              // "mất" / "mật" không phải mặt, mắt
        assertTrue(split("giữ nguyên mật").protect.isEmpty())
    }

    @Test fun exceptStyleTriggers() {
        check("tông ấm, trừ bầu trời", "tông ấm", Scope.SKY)
        check("tông lạnh ngoại trừ khuôn mặt", "tông lạnh", Scope.SKIN)
        check("làm sáng ảnh không đổi phần tóc", "làm sáng ảnh", Scope.HAIR)
        check("làm tối ảnh đừng chỉnh bầu trời", "làm tối ảnh", Scope.SKY)
        check("tăng bão hòa không động vào da", "tăng bão hòa", Scope.SKIN)
    }

    @Test fun englishPhrases() {
        check("brighten the photo but keep the face unchanged", "brighten the photo", Scope.SKIN)
        check("make it warmer, except for the background and the sky", "make it warmer", Scope.BACKGROUND, Scope.SKY)
        check("increase contrast except the hair", "increase contrast", Scope.HAIR)
        check("brighten it, don't touch the face", "brighten it", Scope.SKIN)
        check("add contrast and protect the skin", "add contrast", Scope.SKIN)
        check("warm tone but keep the sky as is", "warm tone", Scope.SKY)
        check("darken, keep the person intact", "darken", Scope.SUBJECT)
    }

    @Test fun keepAloneIsAColorCommandNotAProtection() {
        for (p in listOf("keep the sky blue", "keep the face warm", "keep the hair dark", "keep it natural")) {
            val r = split(p)
            assertSame("\"$p\" không bị cắt", p, r.rest)
            assertTrue("\"$p\"", r.protect.isEmpty())
        }
    }

    @Test fun unknownObjectsAndPlainCommandsAreLeftAlone() {
        for (p in listOf("giữ nguyên logo", "làm sáng ảnh", "giữ ấm cho ảnh", "nên làm sáng nền", "giữ nguyên", "tăng sáng, giữ nguyên phong cách",
            "make it brighter", "tông ấm", "giữ nguyên đã đẹp rồi", "tôi nói rằng ảnh tối")) {
            val r = split(p)
            assertSame("\"$p\" không bị cắt", p, r.rest)
            assertTrue("\"$p\" không có vùng bảo vệ", r.protect.isEmpty())
        }
        assertTrue(split("").protect.isEmpty())
        assertTrue(split("   ").protect.isEmpty())
        assertEquals("   ", split("   ").rest)                                              // chuỗi trắng trả nguyên
        val padded = " giữ nguyên logo "
        assertSame(padded, split(padded).rest)                                             // không cắt gì ⇒ đúng nguyên chuỗi, kể cả khoảng trắng hai đầu
    }

    @Test fun accentsDistinguishFaceFromEyesAndBackgroundFromShould() {
        check("làm sáng ảnh giữ nguyên mắt", "làm sáng ảnh", Scope.EYES)
        check("làm sáng ảnh giữ nguyên mặt", "làm sáng ảnh", Scope.SKIN)
        check("giữ nguyên nền, làm sáng ảnh", "làm sáng ảnh", Scope.BACKGROUND)
        // "nên" (should) không phải nền, "rằng" không phải răng, "đã" không phải da
        assertTrue(split("làm sáng ảnh, giữ nguyên nên").protect.isEmpty())
        assertTrue(split("giữ nguyên rằng").protect.isEmpty())
        assertTrue(split("giữ nguyên đã").protect.isEmpty())
    }

    @Test fun unaccentedVietnameseIsUnderstoodToo() {
        check("giu nguyen khuon mat, lam sang anh", "lam sang anh", Scope.SKIN)
        check("lam sang anh tru bau troi", "lam sang anh", Scope.SKY)
        check("lam sang anh nhung giu nguyen mat", "lam sang anh", Scope.SKIN)
        check("tang tuong phan giu nguyen nen", "tang tuong phan", Scope.BACKGROUND)
        check("lam am anh giu nguyen toc va rang", "lam am anh", Scope.HAIR, Scope.TEETH)
    }

    @Test fun onlyProtectionLeavesAnEmptyCommand() {
        val r = split("giữ nguyên khuôn mặt")
        assertEquals("", r.rest)
        assertEquals(listOf(Scope.SKIN), r.protect)
        assertTrue(r.any)
        assertEquals("", split("ngoại trừ bầu trời").rest)
    }

    @Test fun restFeedsThePlannerAndDoesNotTriggerFaceOrGenerativePaths() {
        val r = split("làm sáng ảnh nhưng giữ nguyên khuôn mặt")
        val plan = RuleBasedPlanner.plan(r.rest)
        assertTrue("planner vẫn thấy lệnh làm sáng", plan.ops.any { it.type == OpType.BRIGHTNESS && it.value > 0f })
        assertNull(GenIntent.detect(r.rest, false))
        assertNull(WholeEditIntent.detect(r.rest))
        // cụm bị cắt không làm planner sinh phép chỉnh da / mặt
        assertTrue(plan.scoped.isEmpty())
        assertTrue(plan.ops.none { it.type == OpType.SKIN_SMOOTH || it.type == OpType.FREQ_SEP })
    }

    @Test fun fullPromptsAreNotClaimedByEarlierIntentBranches() {
        // run() thử các nhánh hiểu ý đặc biệt TRƯỚC runClassic: câu "chỉnh ảnh nhưng giữ nguyên X" phải rơi xuống runClassic
        val prompts = listOf(
            "làm sáng ảnh nhưng giữ nguyên khuôn mặt", "làm ấm ảnh, giữ nguyên da và tóc, trừ bầu trời", "tăng tương phản trừ bầu trời",
            "brighten the photo but keep the face unchanged", "make it warmer, except for the background and the sky",
            "tăng bão hòa không động vào da", "giữ nguyên mặt, nền sáng hơn"
        )
        for (p in prompts) {
            assertNull("GenIntent \"$p\"", GenIntent.detect(p, false))
            assertNull("AutoFrame \"$p\"", AutoFrameIntent.detect(p))
            assertNull("WholeEdit \"$p\"", WholeEditIntent.detect(p))
            assertFalse("Stranger \"$p\"", StrangerIntent.isStrangerRemoval(p))
            assertNull("Scene \"$p\"", BackgroundScene.extract(p))
        }
    }

    // ------------------------------------------------------------------ cú pháp vùng bảo vệ
    @Test fun protectScopeStringsAreBuiltValidatedAndLabelled() {
        assertEquals("not:skin", Scope.protect(listOf(Scope.SKIN)))
        assertEquals("not:skin+hair", Scope.protect(listOf(Scope.SKIN, Scope.HAIR, Scope.SKIN)))
        assertEquals("not:sky", Scope.protect(listOf("bogus", Scope.SKY)))
        assertNull(Scope.protect(emptyList()))
        assertNull(Scope.protect(listOf("bogus")))
        assertTrue(Scope.isProtect("not:skin"))
        assertFalse(Scope.isProtect("skin"))
        assertEquals(listOf(Scope.SKIN, Scope.HAIR), Scope.protectedOf("not:skin+hair"))
        assertEquals(listOf(Scope.SKIN), Scope.protectedOf("not:skin+skin"))       // chuỗi do LLM/công thức cũ viết có thể lặp vùng
        assertTrue(Scope.protectedOf("not:skin+bogus").isEmpty())
        assertTrue(Scope.protectedOf("not:").isEmpty())
        assertTrue(Scope.protectedOf("skin").isEmpty())
        assertTrue(Scope.valid("not:sky+background"))
        assertTrue(Scope.valid(Scope.SKY))
        assertFalse(Scope.valid("not:nonsense"))
        assertFalse(Scope.valid("nonsense"))
        assertEquals("Trừ da mặt, tóc", Scope.label("not:skin+hair"))
        assertEquals("Trừ bầu trời", Scope.label("not:sky"))
        assertEquals("not:xyz", Scope.label("not:xyz"))                 // không hợp lệ: trả nguyên chuỗi
        assertTrue(Scope.needsFace("not:skin"))
        assertTrue(Scope.needsFace("not:sky+eyes"))
        assertFalse(Scope.needsFace("not:sky+background"))
    }

    @Test fun normalizeScopedAcceptsProtectScopesAndDropsBrokenOnes() {
        val out = normalizeScoped(
            listOf(
                ScopedOps("not:skin", listOf(EditOp(OpType.BRIGHTNESS, 0.3f))),
                ScopedOps("not:bogus", listOf(EditOp(OpType.BRIGHTNESS, 0.3f))),
                ScopedOps("bogus", listOf(EditOp(OpType.BRIGHTNESS, 0.3f)))
            )
        )
        assertEquals(listOf("not:skin"), out.map { it.scope })
    }

    @Test fun protectLayerSurvivesSaveAndLoad() {
        val layer = AdjustmentLayer(
            5L, "AI: làm sáng ảnh", listOf(EditOp(OpType.BRIGHTNESS, 0.4f)),
            mask = LayerMask(MaskSpec.Sky(0.5f), invert = true, feather = 0.01f), kind = "ai", scope = "not:sky"
        )
        val json = ProjectCodec.encode(
            ProjectCodec.Meta(1L, 200, 100, "bg.png", 9L), listOf(layer),
            patchFile = { error("không có lớp vá") }, maskFile = { _, _ -> error("không có mặt nạ tô tay") }, imageFile = { error("không có ảnh") }
        )
        val back = ProjectCodec.decode(json, 200, 100, loadPatch = { null }, loadMask = { _, _, _ -> null }).layers.single() as AdjustmentLayer
        assertEquals("not:sky", back.scope)
        assertTrue(back.mask!!.invert)
        assertEquals(MaskSpec.Sky(0.5f), back.mask!!.spec)
    }

    @Test fun protectLayerIsPortableInRecipesAndRebuildsItsMaskPerPhoto() {
        // lớp "giữ nguyên" tô tay (hợp nhiều vùng) gắn với một ảnh, nhưng vì có scope nên được lưu chỉ bằng TÊN vùng và dựng lại cho ảnh khác
        val painted = LayerMask(MaskSpec.Painted(ByteArray(4) { 9 }, 2, 2), invert = true)
        val layer = AdjustmentLayer(7L, "AI: làm sáng", listOf(EditOp(OpType.BRIGHTNESS, 0.4f)), mask = painted, kind = "ai", scope = "not:skin+hair")
        assertTrue(RecipeCodec.portable(layer))
        val arr = RecipeCodec.encode(listOf(layer))
        assertEquals(1, arr.length())
        assertFalse("không lưu mặt nạ của ảnh cũ", arr.getJSONObject(0).has("mask"))
        val back = RecipeCodec.decode(arr).single()
        assertEquals("not:skin+hair", back.scope)
        assertNull(back.mask)
        assertEquals(OpType.BRIGHTNESS, back.ops.single().type)
        // cùng lớp nhưng KHÔNG có scope thì mặt nạ tô tay không chuyển giao được
        assertFalse(RecipeCodec.portable(layer.copy(scope = null)))
    }
}
