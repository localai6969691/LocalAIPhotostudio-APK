package com.aiphoto.studio

import android.graphics.Bitmap
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.doc.Looks
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.makeBitmap
import com.aiphoto.studio.engine.readPixels
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * R20: chạy THẬT ImageEngine.process (qua Bitmap giả có lưu điểm ảnh của tools/jvm_check) trên ảnh tổng hợp:
 * chia tông, mọi Look dựng sẵn, và đường "prompt → kế hoạch → engine" cho các câu mơ hồ.
 * Lưu ý: đây là kiểm tra logic điểm ảnh; không thay cho chạy trên thiết bị thật.
 */
class R20EngineTest {

    private val W = 96
    private val H = 64

    /** Ảnh thử: độ chói tăng dần theo x (tối → sáng), màu thay đổi theo y, một mảng da ở giữa. */
    private fun testImage(): Bitmap {
        val px = IntArray(W * H) { i ->
            val x = i % W; val y = i / W
            val l = 20 + 215 * x / (W - 1)
            val r = (l + (y - H / 2) * 0.6f).toInt().coerceIn(0, 255)
            val g = l.coerceIn(0, 255)
            val b = (l - (y - H / 2) * 0.6f).toInt().coerceIn(0, 255)
            (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
        for (y in 22..42) for (x in 38..58) px[y * W + x] = (255 shl 24) or (224 shl 16) or (172 shl 8) or 150
        return makeBitmap(px, W, H)
    }

    private fun run(ops: List<EditOp>): IntArray {
        val out = ImageEngine.process(testImage(), ops, null, false, ArrayList())
        assertEquals(W, out.width); assertEquals(H, out.height)
        return readPixels(out)
    }

    private fun meanDiff(a: IntArray, b: IntArray): Double {
        var s = 0.0
        for (i in a.indices) {
            s += abs(((a[i] shr 16) and 255) - ((b[i] shr 16) and 255)) + abs(((a[i] shr 8) and 255) - ((b[i] shr 8) and 255)) + abs((a[i] and 255) - (b[i] and 255))
        }
        return s / (3.0 * a.size)
    }

    private fun lum(p: Int) = 0.2126 * ((p shr 16) and 255) + 0.7152 * ((p shr 8) and 255) + 0.0722 * (p and 255)

    @Test fun engineRunsOnTheStubBitmapAndNeutralOpsChangeNothing() {
        val src = readPixels(testImage())
        val same = run(emptyList())
        assertEquals(0.0, meanDiff(src, same), 0.0)
        // phép trung tính (giá trị 0) cũng không đổi gì
        assertEquals(0.0, meanDiff(src, run(listOf(EditOp(OpType.BRIGHTNESS, 0f)))), 0.0)
    }

    @Test fun splitToneTintsShadowsAndHighlightsOppositely() {
        val src = readPixels(testImage())
        // bóng tối → xanh ngọc (185°), vùng sáng → cam (28°)
        val out = run(listOf(EditOp(OpType.SPLIT_TONE, 1f, "185.0,0.400,28.0,0.400,0.000")))
        fun px(a: IntArray, x: Int, y: Int) = a[y * W + x]
        fun br(p: Int) = (p and 255) - ((p shr 16) and 255)            // xanh dương − đỏ: dương = nghiêng lạnh
        val dark = 14; val bright = W - 7
        assertTrue("bóng tối nghiêng lạnh: ${br(px(src, dark, 5))} → ${br(px(out, dark, 5))}", br(px(out, dark, 5)) > br(px(src, dark, 5)) + 3)
        assertTrue("vùng sáng nghiêng ấm: ${br(px(src, bright, 5))} → ${br(px(out, bright, 5))}", br(px(out, bright, 5)) < br(px(src, bright, 5)) - 3)
        // độ chói tổng thể giữ gần nguyên (chia tông bảo toàn chói)
        assertEquals(lum(px(src, dark, 5)), lum(px(out, dark, 5)), 5.0)
        assertEquals(lum(px(src, bright, 5)), lum(px(out, bright, 5)), 5.0)
        // alpha giữ nguyên
        for (p in out) assertEquals(255, p ushr 24)
    }

    @Test fun splitToneWithZeroSaturationIsIdentity() {
        val src = readPixels(testImage())
        assertEquals(0.0, meanDiff(src, run(listOf(EditOp(OpType.SPLIT_TONE, 1f, "185.0,0.000,28.0,0.000,0.000")))), 0.0)
    }

    @Test fun everyBuiltInLookRunsAndVisiblyChangesTheImageWithoutBlowingOut() {
        val src = readPixels(testImage())
        for ((name, ops) in Looks.all) {
            val out = run(ops)
            val d = meanDiff(src, out)
            assertTrue("look \"$name\" phải đổi ảnh (độ lệch $d)", d > 0.8)
            assertTrue("look \"$name\" không được phá ảnh (độ lệch $d)", d < 70.0)
            for (p in out) assertEquals("look \"$name\" giữ alpha", 255, p ushr 24)
            var clipped = 0
            for (p in out) if (((p shr 16) and 255) == 255 && ((p shr 8) and 255) == 255 && (p and 255) == 255) clipped++
            assertTrue("look \"$name\": quá nhiều điểm cháy trắng $clipped", clipped < W * H * 0.25)
        }
    }

    @Test fun vaguePromptsRunEndToEnd() {
        val src = readPixels(testImage())
        for (p in listOf("Làm cho bức ảnh này trông chuyên nghiệp hơn, da đẹp tự nhiên, màu ấm áp", "make it pop", "make this photo look better", "da đẹp tự nhiên")) {
            val plan = RuleBasedPlanner.plan(p)
            val out = run(plan.ops)
            val d = meanDiff(src, out)
            assertTrue("\"$p\" phải đổi ảnh ($d)", d > 0.8)
            assertTrue("\"$p\" không được phá ảnh ($d)", d < 60.0)
        }
        // "màu ấm áp" làm ảnh ấm lên (đỏ tăng so với lam), không chỉ đậm màu hơn
        val warm = run(RuleBasedPlanner.plan("màu ấm áp").ops)
        fun rb(a: IntArray): Double { var s = 0.0; for (p in a) s += ((p shr 16) and 255) - (p and 255); return s / a.size }
        assertTrue("ấm lên: ${rb(src)} → ${rb(warm)}", rb(warm) > rb(src) + 2)
    }

    // ---------------------------------------------------------------- chiều hướng đúng của các phép tông màu cơ bản (lưới an toàn cho mọi lần sửa engine)
    private fun meanLum(a: IntArray) = a.map { lum(it) }.average()
    private fun stdLum(a: IntArray): Double { val m = meanLum(a); return Math.sqrt(a.map { (lum(it) - m) * (lum(it) - m) }.average()) }
    private fun chroma(p: Int) = maxOf((p shr 16) and 255, (p shr 8) and 255, p and 255) - minOf((p shr 16) and 255, (p shr 8) and 255, p and 255)

    @Test fun basicToneOpsMoveInTheRightDirection() {
        val src = readPixels(testImage())
        assertTrue(meanLum(run(listOf(EditOp(OpType.BRIGHTNESS, 0.3f)))) > meanLum(src) + 10)
        assertTrue(meanLum(run(listOf(EditOp(OpType.BRIGHTNESS, -0.3f)))) < meanLum(src) - 10)
        assertTrue(stdLum(run(listOf(EditOp(OpType.CONTRAST, 0.4f)))) > stdLum(src) * 1.2)
        assertTrue(stdLum(run(listOf(EditOp(OpType.CONTRAST, -0.4f)))) < stdLum(src) * 0.8)
        val gray = run(listOf(EditOp(OpType.GRAYSCALE, 1f)))
        for (p in gray) assertTrue("xám: chroma=${chroma(p)}", chroma(p) <= 2)
        assertTrue(src.sumOf { chroma(it) } > gray.sumOf { chroma(it) } + 100)
        val desat = run(listOf(EditOp(OpType.SATURATION, -1f)))
        for (p in desat) assertTrue(chroma(p) <= 2)
        assertTrue(run(listOf(EditOp(OpType.SATURATION, 0.5f))).sumOf { chroma(it) } > src.sumOf { chroma(it) })
        val warm = run(listOf(EditOp(OpType.WARMTH, 0.5f)))
        val cool = run(listOf(EditOp(OpType.WARMTH, -0.5f)))
        fun rb(a: IntArray) = a.sumOf { ((it shr 16) and 255) - (it and 255) }
        assertTrue(rb(warm) > rb(src) && rb(cool) < rb(src))
    }

    @Test fun planOrderDoesNotMatterBecauseTheEngineHasAFixedPipeline() {
        val ops = RuleBasedPlanner.plan("trông chuyên nghiệp hơn, da đẹp tự nhiên, màu ấm áp").ops
        val a = run(ops)
        val b = run(ops.reversed())
        assertEquals(0.0, meanDiff(a, b), 0.01)
    }

    @Test fun lookCatalogIsLargeAndEveryLookIsDistinct() {
        assertTrue("catalog ${Looks.all.size}", Looks.all.size >= 80)
        val src = readPixels(testImage())
        val outs = Looks.all.map { it.first to run(it.second) }
        for (i in outs.indices) for (j in i + 1 until outs.size) {
            val d = meanDiff(outs[i].second, outs[j].second)
            assertTrue("\"${outs[i].first}\" và \"${outs[j].first}\" gần như trùng nhau (độ lệch $d)", d > 2.0)
        }
        // tên hiển thị không trùng, không rỗng
        assertEquals(Looks.all.size, Looks.all.map { it.first }.toSet().size)
        assertTrue(Looks.all.all { it.first.isNotBlank() })
        assertTrue(meanDiff(src, outs[0].second) > 0)
    }
}
