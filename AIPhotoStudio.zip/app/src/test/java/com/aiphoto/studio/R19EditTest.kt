package com.aiphoto.studio

import com.aiphoto.studio.engine.PolygonEdit
import com.aiphoto.studio.engine.PolygonFill
import com.aiphoto.studio.engine.Pt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** R19: sửa điểm lasso (PolygonEdit) — chọn / kéo / chèn / xóa điểm, và ảnh hưởng thật lên mặt nạ dựng ra. */
class R19EditTest {

    private val square = listOf(Pt(0.2f, 0.2f), Pt(0.8f, 0.2f), Pt(0.8f, 0.8f), Pt(0.2f, 0.8f))

    private fun coverage(pts: List<Pt>, w: Int = 100, h: Int = 100): Double = PolygonFill.rasterize(pts, w, h).sum() / (w * h).toDouble()

    @Test fun nearestVertexRespectsRadius() {
        assertEquals(2, PolygonEdit.nearestVertex(square, Pt(0.79f, 0.82f), 0.05f))
        assertEquals(-1, PolygonEdit.nearestVertex(square, Pt(0.5f, 0.5f), 0.05f))
        // hai điểm cùng nằm trong bán kính: lấy điểm gần hơn
        val close = listOf(Pt(0.5f, 0.5f), Pt(0.52f, 0.5f), Pt(0.9f, 0.9f))
        assertEquals(1, PolygonEdit.nearestVertex(close, Pt(0.53f, 0.5f), 0.1f))
    }

    @Test fun hitRadiusIsRoundOnWideImages() {
        // ảnh rộng gấp đôi cao: lệch 0.04 theo x (= 0.08 chiều cao) phải xa hơn lệch 0.04 theo y
        val pts = listOf(Pt(0.5f, 0.5f), Pt(0.9f, 0.9f), Pt(0.1f, 0.9f))
        assertEquals(0, PolygonEdit.nearestVertex(pts, Pt(0.5f, 0.54f), 0.05f, aspect = 2f))
        assertEquals(-1, PolygonEdit.nearestVertex(pts, Pt(0.54f, 0.5f), 0.05f, aspect = 2f))
    }

    @Test fun nearestEdgeProjectsOntoTheEdge() {
        val hit = PolygonEdit.nearestEdge(square, Pt(0.5f, 0.23f), 0.05f)
        assertNotNull(hit)
        assertEquals(0, hit!!.edge)            // cạnh trên: (0.2,0.2) → (0.8,0.2)
        assertEquals(0.5f, hit.at.x, 1e-4f)
        assertEquals(0.2f, hit.at.y, 1e-4f)
        assertNull(PolygonEdit.nearestEdge(square, Pt(0.5f, 0.5f), 0.05f))
        // cạnh đóng vòng: từ điểm cuối về điểm đầu (cạnh trái)
        val left = PolygonEdit.nearestEdge(square, Pt(0.17f, 0.5f), 0.05f)!!
        assertEquals(3, left.edge)
        assertEquals(0.2f, left.at.x, 1e-4f)
    }

    @Test fun insertThenDragReshapesTheMask() {
        val before = coverage(square)
        assertEquals(0.36, before, 0.01)
        val hit = PolygonEdit.nearestEdge(square, Pt(0.5f, 0.2f), 0.05f)!!
        val withMid = PolygonEdit.inserted(square, hit.edge, hit.at)
        assertEquals(5, withMid.size)
        assertEquals(0.5f, withMid[1].x, 1e-4f)             // điểm mới nằm giữa điểm 0 và 1 cũ
        assertEquals(before, coverage(withMid), 0.002)      // chèn lên cạnh chưa đổi hình
        val pulled = PolygonEdit.moved(withMid, 1, Pt(0.5f, 0.05f))   // kéo điểm mới lên trên: thêm một "mũi" tam giác
        assertTrue(coverage(pulled) > before + 0.02)
        assertEquals(0.36 + 0.5 * 0.6 * 0.15, coverage(pulled), 0.01)
    }

    @Test fun moveIsClampedToImage() {
        val m = PolygonEdit.moved(square, 0, Pt(-0.3f, 1.4f))
        assertEquals(0f, m[0].x, 0f)
        assertEquals(1f, m[0].y, 0f)
        assertEquals(square.size, m.size)
        assertEquals(square, PolygonEdit.moved(square, 9, Pt(0f, 0f)))   // chỉ số sai -> giữ nguyên
    }

    @Test fun removeKeepsAtLeastThreePoints() {
        val tri = PolygonEdit.removed(square, 1)
        assertNotNull(tri)
        assertEquals(3, tri!!.size)
        assertNull(PolygonEdit.removed(tri, 0))            // còn 3 điểm: không cho xóa nữa
        assertNull(PolygonEdit.removed(square, 7))
    }

    @Test fun editsDoNotMutateTheInput() {
        val copy = ArrayList(square)
        PolygonEdit.moved(square, 0, Pt(0.5f, 0.5f))
        PolygonEdit.inserted(square, 0, Pt(0.5f, 0.2f))
        PolygonEdit.removed(square, 0)
        assertEquals(copy, square)
    }

    @Test fun insertIsCappedAtMaxPoints() {
        val many = List(PolygonFill.MAX_POINTS) { Pt(0.5f + (it % 7) * 0.01f, 0.3f + (it % 11) * 0.01f) }
        assertEquals(many.size, PolygonEdit.inserted(many, 0, Pt(0.5f, 0.5f)).size)
    }
}
