package com.aiphoto.studio

import com.aiphoto.studio.doc.OverlayLayer
import com.aiphoto.studio.doc.ProjectCodec
import com.aiphoto.studio.engine.Harmonize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.sqrt

/** R25 Hòa vật thể vào nền: chuyển đổi Lab, kéo màu/độ sáng vật về ánh sáng vành nền, giữ alpha + tương phản nội tại + an toàn khi thiếu dữ liệu. */
class R25HarmonizeTest {

    private fun argb(r: Int, g: Int, b: Int, a: Int = 255) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private val W = 200
    private val H = 160

    /** Nền cam ấm có nhiễu nhẹ. */
    private fun warmBase(): IntArray {
        val rnd = java.util.Random(3)
        return IntArray(W * H) {
            argb(
                (200 + rnd.nextGaussian() * 6).toInt().coerceIn(0, 255),
                (140 + rnd.nextGaussian() * 6).toInt().coerceIn(0, 255),
                (80 + rnd.nextGaussian() * 6).toInt().coerceIn(0, 255)
            )
        }
    }

    /** Đĩa xanh lam bán kính [r] tại (cx, cy), alpha mềm 3 điểm ảnh ở rìa. */
    private fun blueDisk(cx: Int, cy: Int, r: Float, color: Int = argb(60, 90, 200)): IntArray = IntArray(W * H) {
        val x = it % W; val y = it / W
        val d = sqrt(((x - cx) * (x - cx) + (y - cy) * (y - cy)).toFloat())
        val a = ((r + 1.5f - d) / 3f).coerceIn(0f, 1f)
        if (a <= 0f) 0 else (color and 0xFFFFFF) or ((a * 255).toInt() shl 24)
    }

    private fun lab(p: Int): FloatArray { val o = FloatArray(3); Harmonize.toLab(p, o); return o }
    private fun meanLab(px: IntArray, sel: (Int) -> Boolean): FloatArray {
        val s = DoubleArray(3); var n = 0
        for (i in px.indices) if (sel(i)) { val l = lab(px[i]); for (c in 0 until 3) s[c] += l[c].toDouble(); n++ }
        return FloatArray(3) { (s[it] / n).toFloat() }
    }
    private fun dE(a: FloatArray, b: FloatArray) =
        sqrt(((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2])).toDouble())
    private fun ringOf(cx: Int, cy: Int, d0: Float, d1: Float): (Int) -> Boolean = { i ->
        val x = i % W; val y = i / W
        val d = sqrt(((x - cx) * (x - cx) + (y - cy) * (y - cy)).toFloat())
        d in d0..d1
    }

    @Test fun labConversionRoundTripsAndKnownPoints() {
        val l = lab(argb(255, 255, 255)); assertEquals(100f, l[0], 0.2f); assertEquals(0f, l[1], 0.3f); assertEquals(0f, l[2], 0.3f)
        assertEquals(0f, lab(argb(0, 0, 0))[0], 0.2f)
        assertEquals(53.6f, lab(argb(128, 128, 128))[0], 0.6f)
        val red = lab(argb(255, 0, 0)); assertTrue(red[1] > 70f && red[2] > 50f)
        val blue = lab(argb(0, 0, 255)); assertTrue(blue[2] < -80f)
        val rnd = java.util.Random(1)
        repeat(500) {
            val p = argb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256), 200)
            val o = lab(p)
            val q = Harmonize.fromLab(o[0], o[1], o[2], 200)
            for (sh in intArrayOf(16, 8, 0)) assertTrue("kênh $sh: ${(p shr sh) and 255} vs ${(q shr sh) and 255}", abs(((p shr sh) and 255) - ((q shr sh) and 255)) <= 1)
            assertEquals(200, q ushr 24)
        }
    }

    @Test fun objectColourMovesTowardsTheSurroundingLight() {
        val base = warmBase()
        val top = blueDisk(100, 80, 30f)
        val ringMean = meanLab(base, ringOf(100, 80, 34f, 60f))
        val before = dE(meanLab(top) { (top[it] ushr 24) == 255 }, ringMean)
        val full = Harmonize.match(top, base, W, H, 1f)
        val half = Harmonize.match(top, base, W, H, 0.5f)
        val afterFull = dE(meanLab(full) { (top[it] ushr 24) == 255 }, ringMean)
        val afterHalf = dE(meanLab(half) { (top[it] ushr 24) == 255 }, ringMean)
        assertTrue("ΔE tới vành: $before → nửa $afterHalf → đủ $afterFull", afterFull < before * 0.4 && afterHalf < before * 0.8 && afterHalf > afterFull)
    }

    @Test fun alphaAndTransparentPixelsAreUntouched() {
        val base = warmBase()
        val top = blueDisk(100, 80, 30f)
        val out = Harmonize.match(top, base, W, H, 1f)
        assertNotSame(top, out)
        for (i in top.indices) {
            assertEquals("alpha tại $i", top[i] ushr 24, out[i] ushr 24)
            if ((top[i] ushr 24) == 0) assertEquals(top[i], out[i])
        }
    }

    @Test fun degenerateInputsReturnTheSameArray() {
        val base = warmBase()
        val top = blueDisk(100, 80, 30f)
        assertSame(top, Harmonize.match(top, base, W, H, 0f))
        assertSame(top, Harmonize.match(top, base, W, H, 0.004f))
        val empty = IntArray(W * H)
        assertSame(empty, Harmonize.match(empty, base, W, H, 1f))
        val speck = blueDisk(100, 80, 2f)                                   // vài điểm ảnh: dưới ngưỡng tối thiểu
        assertSame(speck, Harmonize.match(speck, base, W, H, 1f))
        assertSame(top, Harmonize.match(top, IntArray(10), W, H, 1f))
        // vật phủ gần hết khung → vành quá ít điểm ảnh
        val huge = IntArray(W * H) { argb(10, 20, 30) }
        assertSame(huge, Harmonize.match(huge, base, W, H, 1f))
    }

    @Test fun internalContrastOfTheObjectIsMostlyKept() {
        val base = warmBase()
        // vật 2 nửa: trái sáng, phải tối (cùng xanh lam)
        val top = IntArray(W * H) {
            val x = it % W; val y = it / W
            if (x in 70..129 && y in 50..109) (if (x < 100) argb(120, 160, 255) else argb(10, 30, 110)) else 0
        }
        val out = Harmonize.match(top, base, W, H, 1f)
        val l0 = lab(top[80 * W + 80])[0] - lab(top[80 * W + 120])[0]
        val l1 = lab(out[80 * W + 80])[0] - lab(out[80 * W + 120])[0]
        assertTrue("tương phản L $l0 → $l1", l1 > l0 * 0.5f && l1 > 5f)
        assertTrue("phần sáng vẫn sáng hơn phần tối", lab(out[80 * W + 80])[0] > lab(out[80 * W + 120])[0])
    }

    @Test fun semiTransparentFringeIsPulledToTheSurroundings() {
        val base = warmBase()
        // lõi đã cùng màu nền (chuyển thống kê ≈ đồng nhất), rìa alpha ~100 mang màu lam của nền cũ
        val top = IntArray(W * H) {
            val x = it % W; val y = it / W
            val d = sqrt(((x - 100) * (x - 100) + (y - 80) * (y - 80)).toFloat())
            when {
                d <= 30f -> argb(200, 140, 80)
                d <= 33f -> argb(60, 90, 200, 100)
                else -> 0
            }
        }
        val out = Harmonize.match(top, base, W, H, 1f)
        val ringMean = meanLab(base, ringOf(100, 80, 37f, 60f))
        var before = 0.0; var after = 0.0; var n = 0
        for (i in top.indices) if ((top[i] ushr 24) == 100) { before += dE(lab(top[i]), ringMean); after += dE(lab(out[i]), ringMean); n++ }
        assertTrue(n > 20)
        assertTrue("khoảng cách rìa tới vành $before → $after (cần giảm ≥ 20%)", after < before * 0.8)
    }

    // ------------------------------------------------------------------ nối vào lớp phủ + lưu phiên
    private fun roundTrip(l: OverlayLayer, edit: ((org.json.JSONObject) -> Unit)? = null): OverlayLayer {
        val json = ProjectCodec.encode(
            ProjectCodec.Meta(1L, 200, 100, "bg.png", 9L), listOf(l),
            patchFile = { error("không có lớp vá") }, maskFile = { _, _ -> error("không có mặt nạ") }, imageFile = { error("không có ảnh") }
        )
        edit?.invoke(json.getJSONArray("layers").getJSONObject(0))
        val dec = ProjectCodec.decode(json, 200, 100, loadPatch = { null }, loadMask = { _, _, _ -> null })
        return dec.layers.single() as OverlayLayer
    }

    @Test fun harmonizeParamIsClampedAndSurvivesSaveAndLoad() {
        assertEquals(0f, OverlayLayer(1L, "n", "text", text = "x").harmonize, 0f)
        assertEquals(1f, OverlayLayer.clampParams(OverlayLayer(1L, "n", "text", text = "x", harmonize = 5f)).harmonize, 0f)
        assertEquals(0f, OverlayLayer.clampParams(OverlayLayer(1L, "n", "text", text = "x", harmonize = -2f)).harmonize, 0f)
        assertEquals(0f, OverlayLayer.clampParams(OverlayLayer(1L, "n", "text", text = "x", harmonize = Float.NaN)).harmonize, 0f)
        assertEquals(0.7f, roundTrip(OverlayLayer(1L, "n", "text", text = "x", harmonize = 0.7f)).harmonize, 1e-6f)
        assertEquals("giá trị hỏng trong tệp bị kẹp", 1f, roundTrip(OverlayLayer(1L, "n", "text", text = "x")) { it.put("harmonize", 9.0) }.harmonize, 0f)
        assertEquals("phiên cũ không có trường này", 0f, roundTrip(OverlayLayer(1L, "n", "text", text = "x")) { it.remove("harmonize") }.harmonize, 0f)
        // update() của giao diện giữ nguyên harmonize
        assertEquals(0.4f, OverlayLayer(1L, "n", "text", text = "x", harmonize = 0.4f).update(opacity = 0.5f).let { (it as OverlayLayer).harmonize }, 1e-6f)
    }
}
