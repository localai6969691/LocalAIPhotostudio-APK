package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.Deblur
import com.aiphoto.studio.engine.Fft
import com.aiphoto.studio.engine.Moire
import com.aiphoto.studio.engine.Resample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * R25: Làm nét lại (Deblur: ước lượng nhân mờ + Richardson–Lucy), Khử moiré (FFT lọc khuyết), tiện ích FFT / lấy mẫu lại,
 * cùng việc nối chúng vào OpType / sanitized / describe / bộ hiểu prompt. Toàn bộ trên ảnh tổng hợp (không cần ảnh thật, không cần Android).
 */
class R25DeblurMoireTest {

    // ------------------------------------------------------------------ ảnh tổng hợp + làm mờ độc lập với mã đang thử
    /** Cảnh có khối chữ nhật/elip, đường mảnh, nền dốc và chút nhiễu: có cạnh mọi hướng, cạnh nét thật. Giá trị 0..1. */
    private fun scene(w: Int, h: Int, seed: Long): FloatArray {
        val rnd = java.util.Random(seed)
        val a = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) a[y * w + x] = 0.35f + 0.2f * (x.toFloat() / w) + 0.1f * (y.toFloat() / h)
        repeat(40) {
            val v = rnd.nextFloat()
            val cx = rnd.nextInt(w); val cy = rnd.nextInt(h)
            val rw = 8 + rnd.nextInt(70); val rh = 8 + rnd.nextInt(70)
            if (rnd.nextBoolean()) {
                for (y in max(0, cy - rh)..min(h - 1, cy + rh)) for (x in max(0, cx - rw)..min(w - 1, cx + rw)) a[y * w + x] = v
            } else {
                for (y in max(0, cy - rh)..min(h - 1, cy + rh)) for (x in max(0, cx - rw)..min(w - 1, cx + rw)) {
                    val dx = (x - cx).toFloat() / rw; val dy = (y - cy).toFloat() / rh
                    if (dx * dx + dy * dy <= 1f) a[y * w + x] = v
                }
            }
        }
        repeat(25) {
            val x0 = rnd.nextInt(w); val y0 = rnd.nextInt(h); val ang = rnd.nextDouble() * PI; val len = 30 + rnd.nextInt(80)
            val v = rnd.nextFloat()
            for (t in 0 until len) {
                val x = (x0 + t * cos(ang)).toInt(); val y = (y0 + t * sin(ang)).toInt()
                if (x in 0 until w && y in 0 until h) a[y * w + x] = v
            }
        }
        for (i in a.indices) a[i] = (a[i] + rnd.nextGaussian().toFloat() * 0.01f).coerceIn(0f, 1f)
        return a
    }

    private fun gaussBlur(src: FloatArray, w: Int, h: Int, sigma: Double): FloatArray {
        val r = ceil(3 * sigma).toInt()
        val g = DoubleArray(2 * r + 1) { exp(-((it - r) * (it - r)) / (2 * sigma * sigma)) }
        val s = g.sum()
        for (i in g.indices) g[i] /= s
        val t = FloatArray(w * h)
        val o = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var acc = 0.0
            for (i in -r..r) acc += g[i + r] * src[y * w + (x + i).coerceIn(0, w - 1)]
            t[y * w + x] = acc.toFloat()
        }
        for (y in 0 until h) for (x in 0 until w) {
            var acc = 0.0
            for (i in -r..r) acc += g[i + r] * t[(y + i).coerceIn(0, h - 1) * w + x]
            o[y * w + x] = acc.toFloat()
        }
        return o
    }

    private fun bil(a: FloatArray, w: Int, h: Int, x: Double, y: Double): Double {
        val cx = x.coerceIn(0.0, w - 1.0); val cy = y.coerceIn(0.0, h - 1.0)
        val x0 = cx.toInt(); val y0 = cy.toInt(); val x1 = min(w - 1, x0 + 1); val y1 = min(h - 1, y0 + 1)
        val fx = cx - x0; val fy = cy - y0
        return (a[y0 * w + x0] * (1 - fx) + a[y0 * w + x1] * fx) * (1 - fy) + (a[y1 * w + x0] * (1 - fx) + a[y1 * w + x1] * fx) * fy
    }

    private fun motionBlur(src: FloatArray, w: Int, h: Int, len: Double, angDeg: Double): FloatArray {
        val a = Math.toRadians(angDeg)
        val n = ceil(len * 4).toInt() + 1
        val o = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var acc = 0.0
            for (i in 0 until n) {
                val t = (i.toDouble() / (n - 1) - 0.5) * len
                acc += bil(src, w, h, x + t * cos(a), y + t * sin(a))
            }
            o[y * w + x] = (acc / n).toFloat()
        }
        return o
    }

    /** PSNR (dB) của hai ảnh độ chói 0..1, bỏ viền [m] điểm ảnh. */
    private fun psnr(a: FloatArray, b: FloatArray, w: Int, h: Int, m: Int = 12): Double {
        var s = 0.0
        var c = 0
        for (y in m until h - m) for (x in m until w - m) { val d = a[y * w + x] - b[y * w + x]; s += d * d; c++ }
        return 10 * log10(1.0 / max(1e-12, s / c))
    }

    private fun gray(l: FloatArray): IntArray = IntArray(l.size) {
        val v = (l[it] * 255 + 0.5f).toInt().coerceIn(0, 255)
        (255 shl 24) or (v shl 16) or (v shl 8) or v
    }

    private fun sizeOf(arg: String?, longSide: Int): Float = (Deblur.parse(arg)?.size ?: Float.NaN) * longSide

    // ------------------------------------------------------------------ Deblur: mô tả nhân
    @Test fun psfStringsRoundTripAndRejectGarbage() {
        assertEquals("g:0.00300", Deblur.canonical("g:0.003"))
        assertEquals("m:0.01000,30.0", Deblur.canonical("m:0.01,30"))
        assertEquals(150f, Deblur.parse("m:0.01,-30")!!.angle, 1e-3f)           // góc chuẩn hóa về [0,180)
        assertEquals(10f, Deblur.parse("m:0.01,190")!!.angle, 1e-3f)
        for (bad in listOf(null, "", "garbage", "g:", "g:0", "g:-1", "g:0.2", "m:0,10", "m:0.5,10", "m:abc", "x:1")) assertNull("\"$bad\"", Deblur.parse(bad))
        val p = Deblur.Psf(false, 0.0125f, 77f)
        val back = Deblur.parse(Deblur.format(p))!!
        assertEquals(p.size, back.size, 1e-5f)
        assertEquals(p.angle, back.angle, 0.06f)
    }

    @Test fun kernelsAreNormalisedAndScaleWithImageSize() {
        val g = Deblur.gaussKernel(2f)
        assertEquals(1f, g.sep!!.sum(), 1e-4f)
        val m = Deblur.motionKernel(9f, 33f)
        assertEquals(1f, m.wt.sum(), 1e-4f)
        assertTrue(m.radius >= 4)
        // cùng một mô tả → nhân to gấp đôi khi ảnh to gấp đôi
        val p = Deblur.parse("g:0.003")!!
        val small = Deblur.kernelFor(p, 500, 400)
        val big = Deblur.kernelFor(p, 1000, 800)
        assertNotNull(big)
        assertTrue("bán kính ${big!!.radius} phải lớn hơn ${small?.radius}", small == null || big.radius > small.radius)
        // mờ vô nghĩa ở độ phân giải nhỏ → không dựng nhân
        assertNull(Deblur.kernelFor(Deblur.parse("g:0.0005")!!, 400, 300))
    }

    // ------------------------------------------------------------------ Deblur: ước lượng
    @Test fun estimatesGaussianBlurSize() {
        val w = 640; val h = 480
        val sharp = scene(w, h, 5)
        for (sigma in doubleArrayOf(1.5, 2.0, 3.0)) {
            val e = Deblur.estimate(gaussBlur(sharp, w, h, sigma), w, h)
            assertNotNull("σ=$sigma phải nhận ra mờ: ${e.note}", e.arg)
            assertTrue("σ=$sigma phải ra họ Gauss: ${e.arg}", Deblur.parse(e.arg)!!.gauss)
            val got = sizeOf(e.arg, max(w, h))
            assertTrue("σ=$sigma ước lượng $got px", got > sigma * 0.55 && got < sigma * 1.4)
        }
    }

    @Test fun estimatesMotionLengthAndAngle() {
        val w = 640; val h = 480
        val sharp = scene(w, h, 5)
        for ((len, ang) in listOf(8.0 to 0.0, 12.0 to 35.0, 18.0 to 120.0)) {
            val e = Deblur.estimate(motionBlur(sharp, w, h, len, ang), w, h)
            val p = Deblur.parse(e.arg)
            assertNotNull("nhòe $len@$ang phải nhận ra: ${e.note}", p)
            assertFalse("phải ra họ chuyển động: ${e.arg}", p!!.gauss)
            var dAng = abs(p.angle - ang.toFloat()); if (dAng > 90f) dAng = 180f - dAng
            assertTrue("góc ${p.angle} lệch $dAng° so với $ang°", dAng <= 8f)
            val got = p.size * max(w, h)
            assertTrue("độ dài ước lượng $got px so với $len", got > len * 0.6 && got < len * 1.3)
        }
    }

    @Test fun sharpImageIsNotMistakenForBlurred() {
        val w = 640; val h = 480
        for (seed in longArrayOf(5, 23, 77)) {
            val e = Deblur.estimate(scene(w, h, seed), w, h)
            assertNull("ảnh nét (seed $seed) bị cho là mờ: ${e.arg}", e.arg)
        }
    }

    /** Độ mềm quang học nhẹ của ống kính (σ ≈ 1 px ở 640 px) không phải mờ đáng sửa: tránh "làm nét lại" ảnh vốn đã đạt. */
    @Test fun mildOpticalSoftnessIsNotTreatedAsBlur() {
        val w = 640; val h = 480
        for (seed in longArrayOf(5, 23, 77)) {
            val soft = gaussBlur(scene(w, h, seed), w, h, 1.0)
            val e = Deblur.estimate(soft, w, h)
            assertNull("σ=1,0 (seed $seed) bị cho là mờ: ${e.arg} / ${e.note}", e.arg)
            val px = gray(soft)
            assertSame("apply phải trả nguyên mảng khi không thấy mờ đáng sửa", px, Deblur.apply(px, w, h, 1f, null))
        }
    }

    @Test fun tooSmallOrFeaturelessImagesGiveNoEstimate() {
        assertNull(Deblur.estimate(FloatArray(40 * 40) { 0.5f }, 40, 40).arg)
        assertNull(Deblur.estimate(FloatArray(300 * 200) { 0.5f }, 300, 200).arg)       // ảnh phẳng không có cạnh
    }

    // ------------------------------------------------------------------ Deblur: áp dụng
    @Test fun applyImprovesBlurredImages() {
        val w = 640; val h = 480
        val sharp = scene(w, h, 5)
        val cases = listOf("gauss2" to gaussBlur(sharp, w, h, 2.0), "motion8" to motionBlur(sharp, w, h, 8.0, 0.0), "motion12@35" to motionBlur(sharp, w, h, 12.0, 35.0))
        val minGain = mapOf("gauss2" to 1.0, "motion8" to 1.8, "motion12@35" to 1.5)
        for ((name, blurred) in cases) {
            val before = psnr(blurred, sharp, w, h)
            val out = Deblur.apply(gray(blurred), w, h, 1f, null)
            val after = psnr(Deblur.lumaOf(out), sharp, w, h)
            assertTrue("$name: PSNR $before → $after (cần tăng ≥ ${minGain[name]} dB)", after - before >= minGain[name]!!)
        }
    }

    @Test fun strengthBlendsBetweenInputAndFullRestore() {
        val w = 640; val h = 480
        val sharp = scene(w, h, 5)
        val blurred = motionBlur(sharp, w, h, 8.0, 0.0)
        val px = gray(blurred)
        val full = psnr(Deblur.lumaOf(Deblur.apply(px, w, h, 1f, null)), sharp, w, h)
        val half = psnr(Deblur.lumaOf(Deblur.apply(px, w, h, 0.5f, null)), sharp, w, h)
        val none = psnr(Deblur.lumaOf(px), sharp, w, h)
        assertTrue("none=$none < half=$half < full=$full", none < half && half < full)
        assertSame(px, Deblur.apply(px, w, h, 0f, null))                         // cường độ 0 → trả nguyên mảng
        assertSame(px, Deblur.apply(px, w, h, 0.005f, null))
    }

    @Test fun sharpImageIsReturnedUntouchedAndExplicitArgSkipsEstimation() {
        val w = 640; val h = 480
        val sharp = scene(w, h, 5)
        val px = gray(sharp)
        assertSame("ảnh nét phải trả lại đúng mảng đầu vào", px, Deblur.apply(px, w, h, 1f, null))
        // có arg rõ ràng thì làm theo arg, không cần ước lượng
        val blurred = gaussBlur(sharp, w, h, 2.0)
        val bp = gray(blurred)
        val out = Deblur.apply(bp, w, h, 1f, "g:0.0031")
        assertTrue(psnr(Deblur.lumaOf(out), sharp, w, h) - psnr(blurred, sharp, w, h) >= 1.0)
        // arg hỏng → rơi về tự ước lượng (không ném lỗi)
        val out2 = Deblur.apply(bp, w, h, 1f, "rác")
        assertTrue(psnr(Deblur.lumaOf(out2), sharp, w, h) - psnr(blurred, sharp, w, h) >= 1.0)
    }

    @Test fun alphaIsPreservedAndColourOnlyShiftsByTheSameLumaDelta() {
        val w = 320; val h = 240
        val sharp = scene(w, h, 9)
        val blurred = gaussBlur(sharp, w, h, 2.0)
        val px = IntArray(w * h) {
            val v = 40 + (blurred[it] * 170f)
            val r = v.toInt().coerceIn(0, 255); val g = (v * 0.8f + 10f).toInt().coerceIn(0, 255); val b = (v * 0.6f + 30f).toInt().coerceIn(0, 255)
            (0x80 shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Deblur.apply(px, w, h, 1f, "g:0.0062")
        assertTrue(out !== px)
        var changed = 0
        for (i in px.indices) {
            assertEquals("alpha phải giữ nguyên", 0x80, (out[i] ushr 24) and 255)
            val dr = ((out[i] shr 16) and 255) - ((px[i] shr 16) and 255)
            val dg = ((out[i] shr 8) and 255) - ((px[i] shr 8) and 255)
            val db = (out[i] and 255) - (px[i] and 255)
            if (dr != 0) changed++
            // cùng một độ chênh chói cho R,G,B (chỉ lệch do làm tròn / kẹp 0..255)
            val unclamped = ((px[i] shr 16) and 255) in 2..253 && ((px[i] shr 8) and 255) in 2..253 && (px[i] and 255) in 2..253
            if (unclamped) assertTrue("chênh R/G/B lệch nhau: $dr,$dg,$db", abs(dr - dg) <= 1 && abs(dr - db) <= 1)
        }
        assertTrue("phải có điểm ảnh thay đổi", changed > px.size / 20)
    }

    @Test fun largeImagesAreDeblurredAtCapAndDeltaTransferred() {
        val w = 1800; val h = 1350                                   // > Deblur.CAP: đi đường thu nhỏ + cộng chênh
        val sharp = scene(w, h, 12)
        val blurred = gaussBlur(sharp, w, h, 3.0)
        val out = Deblur.apply(gray(blurred), w, h, 1f, null)
        assertEquals(w * h, out.size)
        val gain = psnr(Deblur.lumaOf(out), sharp, w, h) - psnr(blurred, sharp, w, h)
        assertTrue("PSNR chỉ tăng $gain dB", gain >= 0.8)
    }

    // ------------------------------------------------------------------ Resample
    @Test fun resampleBasics() {
        val c = FloatArray(30 * 20) { 0.37f }
        assertTrue(Resample.area(c, 30, 20, 7, 5).all { abs(it - 0.37f) < 1e-5f })
        val src = FloatArray(8 * 4) { (it % 8 + (it / 8) * 10).toFloat() }
        val half = Resample.area(src, 8, 4, 4, 2)
        assertEquals((0 + 1 + 10 + 11) / 4f, half[0], 1e-5f)
        assertEquals((6 + 7 + 16 + 17) / 4f, half[3], 1e-5f)
        assertEquals((20 + 21 + 30 + 31) / 4f, half[4], 1e-5f)
        // cùng kích thước → bản sao, không phải chính mảng đó
        val same = Resample.area(src, 8, 4, 8, 4)
        assertTrue(same !== src && same.contentEquals(src))
        // bảo toàn trung bình khi thu nhỏ tỉ lệ không nguyên
        val big = scene(97, 61, 3)
        val small = Resample.area(big, 97, 61, 40, 25)
        assertEquals(big.average(), small.average(), 0.01)
        assertEquals(Pair(1000, 500), Resample.capped(1000, 500, 1280))
        assertEquals(Pair(1280, 640), Resample.capped(2560, 1280, 1280))
        assertEquals(Pair(1, 1280), Resample.capped(1, 5000, 1280))
    }

    @Test fun areaMapMatchesAreaAndBilinearAtMatchesBilinear() {
        val w = 53; val h = 41
        val l = scene(w, h, 4)
        val px = gray(l)
        val viaMap = Resample.areaMap(px, w, h, 20, 15) { ((it and 255) / 255f) }
        val viaArea = Resample.area(FloatArray(w * h) { (px[it] and 255) / 255f }, w, h, 20, 15)
        for (i in viaMap.indices) assertEquals(viaArea[i], viaMap[i], 1e-4f)
        val up = Resample.bilinear(viaMap, 20, 15, 70, 50)
        for (y in 0 until 50 step 7) for (x in 0 until 70 step 5) assertEquals(up[y * 70 + x], Resample.bilinearAt(viaMap, 20, 15, 70, 50, x, y), 1e-5f)
    }

    // ------------------------------------------------------------------ FFT
    @Test fun fftRoundTripAndKnownSpectra() {
        val w = 64; val h = 32
        val re = FloatArray(w * h) { ((it * 31) % 17).toFloat() }
        val im = FloatArray(w * h)
        val r0 = re.copyOf()
        Fft.transform2d(re, im, w, h, false)
        Fft.transform2d(re, im, w, h, true)
        for (i in re.indices) { assertEquals(r0[i], re[i], 1e-3f); assertEquals(0f, im[i], 1e-3f) }

        // xung đơn vị → phổ phẳng bằng 1
        val n = 16
        val xr = FloatArray(n); val xi = FloatArray(n); xr[0] = 1f
        Fft.transform(xr, xi, 0, n, false)
        for (k in 0 until n) { assertEquals(1f, xr[k], 1e-5f); assertEquals(0f, xi[k], 1e-5f) }

        // cos(2π·5n/64) → hai đỉnh biên độ 32 tại bin 5 và 59, nơi khác ≈ 0
        val m = 64
        val cr = FloatArray(m) { cos(2.0 * PI * 5 * it / m).toFloat() }
        val ci = FloatArray(m)
        Fft.transform(cr, ci, 0, m, false)
        for (k in 0 until m) {
            val mag = sqrt(cr[k] * cr[k] + ci[k] * ci[k])
            if (k == 5 || k == 59) assertEquals(32f, mag, 1e-3f) else assertTrue("bin $k = $mag", mag < 1e-3f)
        }
        // quy ước dấu: thuận dùng e^(−i…) nên sin(2π·5n/64) → X[5] = −32i (đảo dấu = lọc ngược pha, test cos ở trên không thấy)
        val sr = FloatArray(m) { sin(2.0 * PI * 5 * it / m).toFloat() }
        val si = FloatArray(m)
        Fft.transform(sr, si, 0, m, false)
        assertEquals(-32f, si[5], 1e-3f); assertEquals(32f, si[59], 1e-3f); assertEquals(0f, sr[5], 1e-3f)
        // Parseval: Σ|x|² = (1/N)·Σ|X|²
        val pr = FloatArray(m) { sin(it * 0.37).toFloat() + (it % 5) }
        val pi2 = FloatArray(m)
        val e0 = pr.sumOf { (it * it).toDouble() }
        Fft.transform(pr, pi2, 0, m, false)
        var e1 = 0.0
        for (k in 0 until m) e1 += (pr[k] * pr[k] + pi2[k] * pi2[k]).toDouble()
        assertEquals(e0, e1 / m, e0 * 1e-4)
    }

    @Test fun fftRejectsNonPowerOfTwoAndHelpers() {
        assertTrue(Fft.isPow2(1) && Fft.isPow2(1024) && !Fft.isPow2(0) && !Fft.isPow2(96) && !Fft.isPow2(-8))
        assertEquals(1, Fft.nextPow2(1)); assertEquals(128, Fft.nextPow2(100)); assertEquals(1024, Fft.nextPow2(1024)); assertEquals(2048, Fft.nextPow2(1025))
        var threw = false
        try { Fft.transform(FloatArray(12), FloatArray(12), 0, 12, false) } catch (e: IllegalArgumentException) { threw = true }
        assertTrue(threw)
    }

    // ------------------------------------------------------------------ Moire
    private fun colourScene(w: Int, h: Int, seed: Long): IntArray {
        val b = scene(w, h, seed)
        return IntArray(w * h) {
            val v = b[it]
            val r = (v * 255 + 0.5f).toInt().coerceIn(0, 255)
            val g = ((v * 0.9f + 0.05f) * 255 + 0.5f).toInt().coerceIn(0, 255)
            val bl = ((0.6f * v + 0.2f) * 255 + 0.5f).toInt().coerceIn(0, 255)
            (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
    }

    private fun mse(a: IntArray, b: IntArray): Double {
        var s = 0.0
        for (i in a.indices) for (sh in intArrayOf(16, 8, 0)) { val d = ((a[i] shr sh) and 255) - ((b[i] shr sh) and 255); s += d * d }
        return s / (a.size * 3.0)
    }

    /** Thêm vân sin vào độ chói (ampY, tần số fx,fy chu kỳ/điểm ảnh) và/hoặc màu Cr (ampC). */
    private fun addMoire(
        clean: IntArray, w: Int, ampY: Double, fy1: Pair<Double, Double>, ampC: Double = 0.0, fc: Pair<Double, Double> = 0.17 to -0.11,
        ampCb: Double = 0.0, fcb: Pair<Double, Double> = -0.13 to 0.09
    ): IntArray =
        IntArray(clean.size) {
            val x = it % w; val y = it / w
            val a = ampY * sin(2 * PI * (fy1.first * x + fy1.second * y))
            val c = ampC * sin(2 * PI * (fc.first * x + fc.second * y) + 2.0)            // Cr: đỏ ↔ lục
            val cb = ampCb * sin(2 * PI * (fcb.first * x + fcb.second * y) + 0.7)         // Cb: lam ↔ vàng
            val p = clean[it]
            val r = (((p shr 16) and 255) + a + 1.402 * c).toInt().coerceIn(0, 255)
            val g = (((p shr 8) and 255) + a - 0.714 * c - 0.344 * cb).toInt().coerceIn(0, 255)
            val b = ((p and 255) + a + 1.772 * cb).toInt().coerceIn(0, 255)
            (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

    @Test fun removesLumaMoireAcrossFrequencies() {
        val w = 512; val h = 384
        val clean = colourScene(w, h, 7)
        for ((fx, fy) in listOf(0.06 to 0.04, 0.12 to -0.1, 0.21 to 0.13, 0.33 to 0.2, -0.07 to 0.31)) {
            val moire = addMoire(clean, w, 12.0, fx to fy)
            val rep = Moire.applyReport(moire, w, h, 1f, 1024)
            val before = mse(moire, clean); val after = mse(rep.out, clean)
            assertTrue("f=($fx,$fy): mse $before → $after (cần giảm ≥ 94%)", after < before * 0.06)
            assertTrue("phải bắt được đỉnh ở độ chói: ${rep.peaksY}", rep.peaksY >= 1)
        }
    }

    @Test fun removesChromaOnlyMoire() {
        val w = 512; val h = 384
        val clean = colourScene(w, h, 11)
        val moire = addMoire(clean, w, 0.0, 0.0 to 0.0, ampC = 14.0, fc = 0.17 to -0.11)
        val rep = Moire.applyReport(moire, w, h, 1f, 1024)
        val before = mse(moire, clean); val after = mse(rep.out, clean)
        assertTrue("mse $before → $after (cần giảm ≥ 70%)", after < before * 0.3)
        assertTrue("phải bắt đỉnh ở kênh màu: Cb=${rep.peaksCb} Cr=${rep.peaksCr}", rep.peaksCb + rep.peaksCr >= 1)
        assertEquals("không có vân ở độ chói", 0, rep.peaksY)
    }

    @Test fun removesBlueYellowMoireToo() {
        val w = 512; val h = 384
        val clean = colourScene(w, h, 13)
        val moire = addMoire(clean, w, 0.0, 0.0 to 0.0, ampCb = 14.0, fcb = -0.13 to 0.09)
        val rep = Moire.applyReport(moire, w, h, 1f, 1024)
        val before = mse(moire, clean); val after = mse(rep.out, clean)
        assertTrue("mse $before → $after (cần giảm ≥ 70%)", after < before * 0.3)
        assertTrue("phải bắt đỉnh ở kênh Cb: ${rep.peaksCb}", rep.peaksCb >= 1)
    }

    @Test fun mixedMoireIsRemovedAndDetailIsKept() {
        val w = 640; val h = 480
        val clean = colourScene(w, h, 7)
        val moire = addMoire(clean, w, 12.0, 0.21 to 0.13, ampC = 9.0, fc = 0.17 to -0.11)
        val rep = Moire.applyReport(moire, w, h, 1f, 1024)
        val before = mse(moire, clean); val after = mse(rep.out, clean)
        assertTrue("mse $before → $after", after < before * 0.15)
        assertTrue("tổng đỉnh ${rep.total}", rep.total in 2..40)
        // chi tiết thật không bị làm mờ: lọc ảnh SẠCH thì giữ nguyên tuyệt đối
        assertSame(clean, Moire.applyReport(clean, w, h, 1f, 1024).out)
    }

    /**
     * Ảnh KHÔNG có moiré phải trả lại đúng mảng đầu vào. Cảnh tổng hợp có khối chữ nhật sắc cạnh + đường mảnh (cạnh thẳng dài tạo "sống"
     * trong phổ, từng bị bắt nhầm thành đỉnh và xóa mất nội dung - xem PROJECT_STATUS §8.1 R25) nên đây là phép thử khó cho bộ dò đỉnh.
     */
    @Test fun cleanPhotosAreNeverTouched() {
        var runs = 0
        for (seed in 1L..8L) for ((w, h) in listOf(512 to 384, 640 to 480, 333 to 257)) {
            val clean = colourScene(w, h, seed)
            val rep = Moire.applyReport(clean, w, h, 1f, 1024)
            assertEquals("ảnh sạch seed $seed ${w}x$h bị cho là có moiré (${rep.peaksY}/${rep.peaksCb}/${rep.peaksCr})", 0, rep.total)
            assertSame(clean, rep.out)
            runs++
        }
        assertEquals(24, runs)
    }

    @Test fun tinyOrInvalidInputIsReturnedAsIs() {
        val tiny = IntArray(10 * 10) { 0xFF808080.toInt() }
        assertSame(tiny, Moire.applyReport(tiny, 10, 10, 1f).out)
        val px = colourScene(64, 64, 1)
        assertSame(px, Moire.applyReport(px, 64, 64, 0f).out)
        assertSame(px, Moire.applyReport(px, 64, 63, 1f).out)                  // kích thước không khớp mảng
    }

    @Test fun strengthScalesTheRemoval() {
        val w = 512; val h = 384
        val clean = colourScene(w, h, 7)
        val moire = addMoire(clean, w, 12.0, 0.21 to 0.13)
        val full = mse(Moire.applyReport(moire, w, h, 1f, 1024).out, clean)
        val half = mse(Moire.applyReport(moire, w, h, 0.5f, 1024).out, clean)
        val none = mse(moire, clean)
        assertTrue("none=$none > half=$half > full=$full", none > half && half > full)
        assertTrue("nửa cường độ phải giảm khoảng 3/4 sai số: half=$half none=$none", half < none * 0.5 && half > none * 0.1)
    }

    @Test fun faintStripesBelowVisibilityAreIgnored() {
        val w = 512; val h = 384
        val clean = colourScene(w, h, 7)
        val faint = addMoire(clean, w, 0.8, 0.21 to 0.13)
        val rep = Moire.applyReport(faint, w, h, 1f, 1024)
        assertEquals(0, rep.total)
        assertSame(faint, rep.out)
    }

    @Test fun suppressedComponentMatchesTheInjectedSinusoid() {
        val n = 256
        val sine = FloatArray(n * n) { 10f * sin(2 * PI * (0.18 * (it % n) + 0.07 * (it / n))).toFloat() }
        val base = FloatArray(n * n) { 100f + 20f * sin(0.01 * (it % n)).toFloat() }
        val ch = FloatArray(n * n) { base[it] + sine[it] }
        val res = Moire.suppress(ch, n, n, Moire.LUMA)
        assertTrue(res.peaks >= 1)
        var dot = 0.0; var nr = 0.0; var ns = 0.0
        for (i in ch.indices) { dot += res.removed[i] * sine[i]; nr += res.removed[i] * res.removed[i]; ns += sine[i] * sine[i] }
        val corr = dot / sqrt(nr * ns)
        assertTrue("tương quan $corr", corr > 0.95)
        assertTrue("biên độ tách ra phải ≈ biên độ thật: ${sqrt(nr / ns)}", sqrt(nr / ns) in 0.75..1.15)
    }

    @Test fun capLimitsFineMoireOnBigImagesAndHigherCapRestoresIt() {
        val w = 1500; val h = 1100
        val clean = colourScene(w, h, 7)
        val coarse = addMoire(clean, w, 12.0, 0.06 * cos(0.6) to 0.06 * sin(0.6))            // chu kỳ ~17 px: thấy được ở cap 1024
        val fine = addMoire(clean, w, 12.0, 0.33 * cos(0.6) to 0.33 * sin(0.6))              // chu kỳ ~3 px: mất khi thu nhỏ về 1024
        val c1024 = mse(Moire.applyReport(coarse, w, h, 1f, 1024).out, clean) / mse(coarse, clean)
        assertTrue("vân thô ở cap 1024 chỉ giảm còn $c1024", c1024 < 0.2)
        val f1024 = mse(Moire.applyReport(fine, w, h, 1f, 1024).out, clean) / mse(fine, clean)
        val f2048 = mse(Moire.applyReport(fine, w, h, 1f, 2048).out, clean) / mse(fine, clean)
        assertTrue("vân mịn: cap 1024 còn $f1024 (giới hạn đã nêu), cap 2048 còn $f2048", f1024 > 0.5 && f2048 < 0.25)
    }

    @Test fun capDefaultFollowsMemoryTier() {
        assertEquals(Moire.CAP, Moire.capFor(true))
        assertEquals(Moire.MAX_CAP, Moire.capFor(false))
        assertTrue(Moire.CAP < Moire.MAX_CAP)
        assertEquals(Moire.CAP, Moire.capDefault)
    }

    // ------------------------------------------------------------------ nối vào OpType / sanitized / describe / planner
    @Test fun opTypesAreRegisteredScalableAndSanitised() {
        assertEquals(OpType.UNBLUR, OpType.fromKey("unblur"))
        assertEquals(OpType.MOIRE, OpType.fromKey("Moire"))
        assertTrue(OpType.UNBLUR.scalable && OpType.MOIRE.scalable)
        val u = EditOp(OpType.UNBLUR, 1.7f, "g:0.003").sanitized()!!
        assertEquals(1f, u.value, 1e-6f)
        assertEquals("g:0.00300", u.arg)
        assertNull("arg hỏng → tự ước lượng", EditOp(OpType.UNBLUR, 0.5f, "garbage").sanitized()!!.arg)
        assertNull("arg rỗng → tự ước lượng", EditOp(OpType.UNBLUR, 0.5f, null).sanitized()!!.arg)
        assertNull(EditOp(OpType.UNBLUR, 0.001f).sanitized())
        assertEquals(0.4f, EditOp(OpType.MOIRE, 0.4f).sanitized()!!.value, 1e-6f)
        assertEquals(1f, EditOp(OpType.MOIRE, 5f).sanitized()!!.value, 1e-6f)
        assertNull(EditOp(OpType.MOIRE, 0f).sanitized())
        assertEquals(0.3f, EditOp(OpType.UNBLUR, 0.6f).scaled(0.5f).value, 1e-6f)
    }

    @Test fun describeNamesTheOperation() {
        assertEquals("Làm nét lại (khử nhòe) 80%", EditOp(OpType.UNBLUR, 0.8f).describe())
        val d = EditOp(OpType.UNBLUR, 1f, "m:0.01000,35.0").describe()
        assertTrue(d, d.startsWith("Làm nét lại (khử nhòe) 100% (nhòe chuyển động góc 35°"))
        assertTrue(EditOp(OpType.UNBLUR, 1f, "g:0.003").describe().contains("mờ lấy nét"))
        assertEquals("Khử moiré 100%", EditOp(OpType.MOIRE, 1f).describe())
    }

    private fun ops(prompt: String): List<EditOp> = RuleBasedPlanner.plan(prompt).ops
    private fun has(prompt: String, t: OpType) = ops(prompt).any { it.type == t }

    @Test fun plannerRoutesDeblurRequests() {
        for (p in listOf("khử mờ ảnh này", "làm nét lại ảnh bị rung", "ảnh bị nhòe, sửa giúp", "unblur", "deblur the photo", "remove motion blur",
            "ảnh bị rung tay", "phục hồi độ nét", "fix blur", "Khử nhòe cho ảnh")) {
            val o = ops(p)
            assertTrue("\"$p\" phải ra UNBLUR: $o", o.any { it.type == OpType.UNBLUR })
            assertFalse("\"$p\" không được ra BLUR/MOTION_BLUR/SHARPEN: $o", o.any { it.type == OpType.BLUR || it.type == OpType.MOTION_BLUR || it.type == OpType.SHARPEN })
        }
        assertEquals(0.6f, ops("unblur 60%").first { it.type == OpType.UNBLUR }.value, 1e-4f)
        assertTrue(ops("khử mờ rất mạnh").first { it.type == OpType.UNBLUR }.value > ops("khử mờ").first { it.type == OpType.UNBLUR }.value)
    }

    @Test fun plannerRoutesMoireRequests() {
        for (p in listOf("khử moiré", "khử moire ảnh chụp màn hình", "xóa sọc màn hình", "ảnh bị vân màn hình", "remove moire")) {
            val o = ops(p)
            assertTrue("\"$p\" phải ra MOIRE: $o", o.any { it.type == OpType.MOIRE })
            assertFalse("\"$p\" không được ra BLUR/DENOISE: $o", o.any { it.type == OpType.BLUR || it.type == OpType.DENOISE })
        }
    }

    @Test fun plannerKeepsOldMeaningsOfBlurAndSharpen() {
        for (p in listOf("làm mờ ảnh", "làm ảnh mờ đi", "blur the photo", "mờ phông", "làm mờ nền", "mở rộng ảnh", "khử mồ hôi")) assertFalse("\"$p\" bị nhầm UNBLUR", has(p, OpType.UNBLUR))
        assertTrue(has("làm mờ ảnh", OpType.BLUR))
        assertTrue(has("làm nét ảnh", OpType.SHARPEN))
        assertFalse(has("làm nét ảnh", OpType.UNBLUR))
        assertTrue(has("làm ảnh bớt mờ", OpType.SHARPEN))
        assertTrue(has("motion blur", OpType.MOTION_BLUR))
        assertFalse(has("motion blur", OpType.UNBLUR))
    }
}
