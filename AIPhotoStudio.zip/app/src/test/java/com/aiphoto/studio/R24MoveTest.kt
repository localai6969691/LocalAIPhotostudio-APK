package com.aiphoto.studio

import com.aiphoto.studio.engine.MoveObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** R24 Di chuyển vật thể: phần thuần (hộp bao, tách có viền mềm, nới vùng xóa chỗ cũ, tham số lớp phủ đặt đúng tại chỗ cũ). */
class R24MoveTest {
    private fun rectMask(w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, v: Int = 255): ByteArray {
        val m = ByteArray(w * h)
        for (y in y0 until y1) for (x in x0 until x1) m[y * w + x] = v.toByte()
        return m
    }

    private fun gradientImage(w: Int, h: Int) = IntArray(w * h) { i -> (0xFF shl 24) or (((i % w) * 2 and 255) shl 16) or (((i / w) * 3 and 255) shl 8) or 0x40 }

    // ------------------------------------------------------------ hộp bao / phủ
    @Test fun bboxAndCoverageOfARectangle() {
        val m = rectMask(100, 80, 30, 20, 60, 50)
        assertEquals(listOf(30, 20, 60, 50), MoveObject.bbox(m, 100, 80)!!.toList())
        assertEquals(30.0 * 30 / 8000, MoveObject.coverage(m), 1e-9)
        assertNull(MoveObject.bbox(ByteArray(8000), 100, 80))
        assertNull(MoveObject.bbox(m, 99, 80))                       // sai kích thước
        assertEquals(0.0, MoveObject.coverage(ByteArray(0)), 0.0)
    }

    @Test fun softMaskValuesCountAsSelected() {
        val m = rectMask(50, 50, 10, 10, 20, 20, v = 1)
        assertEquals(listOf(10, 10, 20, 20), MoveObject.bbox(m, 50, 50)!!.toList())
        assertEquals(100.0 / 2500, MoveObject.coverage(m), 1e-9)
    }

    // ------------------------------------------------------------ tách vật thể
    @Test fun cutoutIsPaddedBoxWithOpaqueCoreAndTransparentMargin() {
        val w = 100; val h = 80
        val img = gradientImage(w, h)
        val c = MoveObject.cutout(img, w, h, rectMask(w, h, 30, 20, 60, 50))!!
        assertEquals(30 - MoveObject.PAD, c.x); assertEquals(20 - MoveObject.PAD, c.y)
        assertEquals(30 + 2 * MoveObject.PAD, c.w); assertEquals(30 + 2 * MoveObject.PAD, c.h)
        assertEquals(c.w * c.h, c.pixels.size)
        fun at(x: Int, y: Int) = c.pixels[(y - c.y) * c.w + (x - c.x)]
        assertEquals(255, at(45, 35) ushr 24)                                   // lõi đặc
        assertEquals(img[35 * w + 45] and 0xFFFFFF, at(45, 35) and 0xFFFFFF)     // giữ nguyên màu gốc
        assertEquals(0, at(c.x, c.y) ushr 24)                                    // góc lề trong suốt
        assertEquals(0, at(c.x + c.w - 1, c.y + c.h - 1) ushr 24)
        // viền: co 1 điểm rồi làm mềm -> điểm mép ngoài cùng của mặt nạ chỉ còn ~1/3, điểm kế bên ~2/3, từ điểm thứ ba trở vào đặc hẳn
        assertEquals(85, at(30, 35) ushr 24)
        assertEquals(170, at(31, 35) ushr 24)
        assertEquals(255, at(32, 35) ushr 24)
        assertEquals(255, at(57, 35) ushr 24)                                    // mặt nạ chiếm x = 30..59: đối xứng ở mép phải
        assertEquals(170, at(58, 35) ushr 24)
        assertEquals(85, at(59, 35) ushr 24)
    }

    @Test fun edgeIsSoftNotAStaircase() {
        val w = 120; val h = 100
        val c = MoveObject.cutout(gradientImage(w, h), w, h, rectMask(w, h, 30, 30, 90, 70))!!
        val row = (50 - c.y) * c.w
        val alphas = (0 until c.w).map { c.pixels[row + it] ushr 24 }
        assertTrue("phải có mức trung gian ở mép: $alphas", alphas.any { it in 1..254 })
        assertEquals(255, alphas[c.w / 2])
    }

    @Test fun tinyObjectIsNotErasedByTheEdgeShrink() {
        val w = 60; val h = 60
        val c = MoveObject.cutout(gradientImage(w, h), w, h, rectMask(w, h, 20, 20, 23, 23))!!   // 3×3, nhỏ hơn 12 điểm: chỉ làm mềm, không co
        assertTrue("vật thể nhỏ vẫn phải còn điểm đặc/gần đặc", c.pixels.any { (it ushr 24) >= 100 })
        assertEquals(255, c.pixels[(21 - c.y) * c.w + (21 - c.x)] ushr 24)
    }

    @Test fun cutoutAtTheImageBorderStaysInsideTheImage() {
        val w = 80; val h = 60
        val c = MoveObject.cutout(gradientImage(w, h), w, h, rectMask(w, h, 0, 0, 20, 15))!!
        assertEquals(0, c.x); assertEquals(0, c.y)
        assertEquals(20 + MoveObject.PAD, c.w); assertEquals(15 + MoveObject.PAD, c.h)
        val d = MoveObject.cutout(gradientImage(w, h), w, h, rectMask(w, h, 60, 45, 80, 60))!!
        assertEquals(w, d.x + d.w); assertEquals(h, d.y + d.h)
    }

    @Test fun overlayParametersPutTheObjectExactlyWhereItWas() {
        for ((w, h) in listOf(100 to 80, 1000 to 750, 640 to 1137)) for (r in listOf(intArrayOf(10, 12, 40, 50), intArrayOf(0, 0, 30, 30), intArrayOf(w - 25, h - 31, w, h))) {
            val c = MoveObject.cutout(gradientImage(w, h), w, h, rectMask(w, h, r[0], r[1], r[2], r[3]))!!
            // OverlayRenderer: rộng = size*w, cao theo tỉ lệ ảnh, tâm (cx*w, cy*h)
            val dw = c.size * w
            val dh = dw * c.h / c.w
            assertEquals("trái $w x $h ${r.toList()}", c.x.toFloat(), c.cx * w - dw / 2f, 0.01f)
            assertEquals("trên $w x $h ${r.toList()}", c.y.toFloat(), c.cy * h - dh / 2f, 0.01f)
            assertEquals(c.h.toFloat(), dh, 0.01f)
        }
    }

    @Test fun rejectsEmptyTooSmallTooLargeAndMismatchedMasks() {
        val w = 100; val h = 80
        val img = gradientImage(w, h)
        assertNull(MoveObject.cutout(img, w, h, ByteArray(w * h)))                              // rỗng
        assertNull(MoveObject.cutout(img, w, h, rectMask(w, h, 5, 5, 6, 6)))                    // 1 điểm = 0,0125% < 0,05%
        assertNull(MoveObject.cutout(img, w, h, rectMask(w, h, 0, 0, 100, 80)))                 // cả ảnh
        assertNull(MoveObject.cutout(img, w, h, rectMask(w, h, 0, 0, 100, 70)))                 // 87,5% > 85%
        assertNotNull(MoveObject.cutout(img, w, h, rectMask(w, h, 0, 0, 100, 60)))              // 75% còn nhận
        assertNull(MoveObject.cutout(img, w, h, ByteArray(10)))
        assertNull(MoveObject.cutout(IntArray(10), w, h, rectMask(w, h, 5, 5, 40, 40)))
        assertNotNull(MoveObject.cutout(img, w, h, rectMask(w, h, 5, 5, 8, 8)))                 // 9 điểm = 0,1125% ≥ 0,05%
    }

    // ------------------------------------------------------------ nới vùng xóa chỗ cũ
    @Test fun dilateGrowsASquareByRadiusInEveryDirectionAndClampsAtBorders() {
        val w = 21; val h = 21
        val one = ByteArray(w * h).also { it[10 * w + 10] = 1 }
        val d = MoveObject.dilate(one, w, h, 3)
        for (y in 0 until h) for (x in 0 until w) {
            val inSq = abs(x - 10) <= 3 && abs(y - 10) <= 3
            assertEquals("($x,$y)", if (inSq) 255 else 0, d[y * w + x].toInt() and 255)
        }
        val corner = ByteArray(w * h).also { it[0] = 255.toByte() }
        val dc = MoveObject.dilate(corner, w, h, 2)
        assertEquals(9, dc.count { it.toInt() != 0 })                                          // chỉ phần nằm trong ảnh (3×3)
    }

    @Test fun dilateRadiusZeroNormalizesWithoutChangingTheShapeAndNeverMutatesInput() {
        val m = rectMask(20, 20, 5, 5, 9, 9, v = 7)
        val before = m.copyOf()
        val d = MoveObject.dilate(m, 20, 20, 0)
        assertEquals(16, d.count { it.toInt() != 0 }); assertTrue(d.all { (it.toInt() and 255) == 0 || (it.toInt() and 255) == 255 })
        MoveObject.dilate(m, 20, 20, 4)
        assertEquals(before.toList(), m.toList())
        assertEquals(0, MoveObject.dilate(ByteArray(50), 10, 5, 2).count { it.toInt() != 0 })
    }

    @Test fun growRadiusScalesWithImageSizeAndHasAFloor() {
        assertEquals(2, MoveObject.growFor(300, 200))                                            // sàn 2 điểm cho ảnh nhỏ
        assertEquals(2, MoveObject.growFor(640, 480))
        assertEquals(2, MoveObject.growFor(800, 600))
        assertEquals(5, MoveObject.growFor(2048, 1536))
        assertTrue(MoveObject.growFor(4000, 3000) > MoveObject.growFor(2048, 1536))
    }
}
