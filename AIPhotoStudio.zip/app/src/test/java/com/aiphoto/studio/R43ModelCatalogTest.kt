package com.aiphoto.studio

import com.aiphoto.studio.models.ModelCatalogs
import com.aiphoto.studio.models.ModelSlots
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

/** R43: danh mục model cho trình tải trong app — danh mục CÓ SẴN trong app phải hợp lệ; trình phân tích phải từ chối dữ liệu hỏng. */
class R43ModelCatalogTest {
    private fun bundledText(): String {
        val f = listOf("app/src/main/assets/model_catalog.json", "src/main/assets/model_catalog.json").map { File(it) }.firstOrNull { it.exists() }
            ?: throw AssertionError("không thấy assets/model_catalog.json")
        return f.readText()
    }

    private fun one(sha: String = "a".repeat(64), size: Long = 1000, urls: String = "[\"{release}/x.onnx\"]", id: String = "m1", extra: String = "") =
        """{"version":1,"models":[{"id":"$id","slot":"seg","sizeBytes":$size,"sha256":"$sha","urls":$urls$extra}]}"""

    @Test fun bundledCatalogIsValid() {
        val c = ModelCatalogs.parse(bundledText(), "bundled")
        assertTrue("danh mục có sẵn phải có ít nhất 7 mục", c.models.size >= 7)
        assertEquals("id không trùng", c.models.size, c.models.map { it.id }.toSet().size)
        for (m in c.models) {
            assertTrue("slot ${m.slot} của ${m.id} phải là slot app biết nạp", m.slot in ModelSlots.ALL)
            assertTrue(m.sizeBytes > 0)
            assertTrue(m.sha256.matches(Regex("[0-9a-f]{64}")))
            assertTrue("${m.id} phải có địa chỉ dự phòng ngoài {release}", m.urls.any { it.startsWith("https://") })
            assertTrue("${m.id} phải có giấy phép", m.license.isNotBlank() && m.licenseUrl.startsWith("https://"))
            assertTrue("${m.id} phải có mô tả tiếng Việt và tiếng Anh", m.descVi.isNotBlank() && m.descEn.isNotBlank())
        }
        assertTrue("MI-GAN có trong danh mục", c.models.any { it.id == "migan" && it.sha256 == "6f1f3530a1a2324b19752018ce756088b07973cda8d7d890034ace5c8a48c40b" })
    }

    @Test fun bundledPlaceholderMeansNoServerYetUntilCiFillsIt() {
        val c = ModelCatalogs.parse(bundledText(), "bundled")
        val seg = c.models.first { it.slot == "seg" }
        val urls = ModelCatalogs.resolveUrls(seg, c.releaseBase)
        assertTrue("luôn còn địa chỉ gốc https, không còn __REPO__", urls.isNotEmpty() && urls.none { it.contains(ModelCatalogs.REPO_PLACEHOLDER) })
        if (c.catalogUrl.contains(ModelCatalogs.REPO_PLACEHOLDER)) {
            assertNull("chưa thay __REPO__ ⇒ không có địa chỉ máy chủ", ModelCatalogs.remoteUrl(c))
        } else {
            // đã chạy sau bước CI thay __REPO__ bằng chủ/kho thật
            assertTrue(ModelCatalogs.remoteUrl(c)!!.startsWith("https://github.com/"))
        }
    }

    @Test fun placeholderReplacedByCiGivesReleaseUrlFirst() {
        val text = bundledText().replace(ModelCatalogs.REPO_PLACEHOLDER, "chu/kho")
        val c = ModelCatalogs.parse(text, "bundled")
        assertEquals("https://github.com/chu/kho/releases/download/models-v1/catalog.json", ModelCatalogs.remoteUrl(c))
        val seg = c.models.first { it.slot == "seg" }
        assertEquals("https://github.com/chu/kho/releases/download/models-v1/u2netp.onnx", ModelCatalogs.resolveUrls(seg, c.releaseBase).first())
    }

    @Test fun resolveKeepsOnlyHttpsUnlessAllowed() {
        val c = ModelCatalogs.parse(one(urls = "[\"{release}/a\",\"http://x/b\",\"ftp://x/c\",\"https://x/d\"]"), "t")
        val e = c.models[0]
        assertEquals(listOf("https://h/a", "https://x/d"), ModelCatalogs.resolveUrls(e, "https://h/"))
        assertEquals(listOf("https://h/a", "http://x/b", "https://x/d"), ModelCatalogs.resolveUrls(e, "https://h", allowHttp = true))
        assertEquals(listOf("https://x/d"), ModelCatalogs.resolveUrls(e, ""))
    }

    @Test fun parseRejectsBrokenData() {
        val h64 = "b".repeat(64)
        val dup = """{"version":1,"models":[{"id":"a","sizeBytes":1,"sha256":"$h64","urls":["https://x"]},{"id":"a","sizeBytes":1,"sha256":"$h64","urls":["https://x"]}]}"""
        val bad = listOf(
            "không phải json", "{}", """{"version":1}""", """{"version":1,"models":[]}""",
            one(sha = "xyz"), one(sha = "A".repeat(63)), one(size = 0), one(urls = "[]"), one(id = "Có Dấu"), dup
        )
        for (t in bad) {
            try { ModelCatalogs.parse(t, "t"); fail("phải từ chối: " + t.take(60)) } catch (e: ModelCatalogs.Invalid) { assertTrue(e.message!!.isNotBlank()) }
        }
    }

    @Test fun sizeMbRoundsAndLanguageFallback() {
        val c = ModelCatalogs.parse(one(size = 4_574_861, extra = ",\"vi\":\"VN\",\"en\":\"EN\",\"riskVi\":\"rv\",\"riskEn\":\"\""), "t")
        val e = c.models[0]
        assertEquals(4, e.sizeMb)
        assertEquals("VN", e.desc("vi")); assertEquals("EN", e.desc("ja"))
        assertEquals("rv", e.risk("vi")); assertEquals("rv", e.risk("fr"))
        assertEquals(1, ModelCatalogs.parse(one(size = 10), "t").models[0].sizeMb)
        assertFalse(e.recommended)
    }
}
