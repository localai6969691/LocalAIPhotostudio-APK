package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.makeBitmap
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * R30: "Phóng to ×4" (tùy chọn) — hệ số THỰC TẾ phải bị giới hạn bởi cạnh dài tối đa chung ([ImageEngine.UPSCALE_MAX_SIDE]) để máy yếu không hết bộ nhớ,
 * và [ImageEngine.process] phải ra đúng cỡ đó (đường nội suy; đường AI dùng cùng hàm [ImageEngine.upscaleFactor]-tương đương qua `maxLongSide`).
 */
class R30UpscaleTest {

    @Test fun capIsFourThousandNinetySix() {
        assertEquals(4096, ImageEngine.UPSCALE_MAX_SIDE)
    }

    @Test fun factorIsTheWantedOneWhenItFits() {
        assertEquals(4f, ImageEngine.upscaleFactor(1000, 800, 4f), 1e-6f)
        assertEquals("đúng bằng trần vẫn được nguyên hệ số", 4f, ImageEngine.upscaleFactor(1024, 768, 4f), 1e-6f)
        assertEquals(2f, ImageEngine.upscaleFactor(1000, 800, 2f), 1e-6f)
        assertEquals(1.5f, ImageEngine.upscaleFactor(200, 100, 1.5f), 1e-6f)
    }

    @Test fun factorIsReducedSoTheLongSideStaysUnderTheCap() {
        assertEquals("ảnh 1536 xin ×4 chỉ được ×2,67", 4096f / 1536f, ImageEngine.upscaleFactor(1536, 1152, 4f), 1e-4f)
        assertEquals(4096f / 2048f, ImageEngine.upscaleFactor(1500, 2048, 4f), 1e-4f)
        assertEquals("cạnh dài tính theo chiều lớn hơn, dù là dọc hay ngang", ImageEngine.upscaleFactor(2000, 3000, 4f), ImageEngine.upscaleFactor(3000, 2000, 4f), 1e-6f)
        assertEquals(4096f / 4000f, ImageEngine.upscaleFactor(4000, 3000, 2f), 1e-4f)
    }

    @Test fun nearlyNoGainCountsAsNoUpscale() {
        assertEquals("đã chạm trần", 1f, ImageEngine.upscaleFactor(4096, 3000, 2f), 0f)
        assertEquals("còn dưới 1,01×", 1f, ImageEngine.upscaleFactor(4060, 3000, 2f), 0f)
        assertTrue("trên 1,01× thì vẫn phóng", ImageEngine.upscaleFactor(4050, 3000, 2f) > 1.01f)
    }

    @Test fun invalidInputsReturnOne() {
        assertEquals(1f, ImageEngine.upscaleFactor(0, 0, 4f), 0f)
        assertEquals(1f, ImageEngine.upscaleFactor(100, 100, 4f, 0), 0f)
        assertEquals(1f, ImageEngine.upscaleFactor(100, 100, 4f, -5), 0f)
    }

    @Test fun factorNeverExceedsWantNorBreaksTheCap() {
        val rnd = Random(11)
        repeat(500) {
            val w = 1 + rnd.nextInt(9000)
            val h = 1 + rnd.nextInt(9000)
            val want = 1f + 3f * rnd.nextFloat()
            val f = ImageEngine.upscaleFactor(w, h, want)
            assertTrue("f=$f want=$want", f <= want + 1e-4f)
            assertTrue("f=$f ≥ 1", f >= 1f)
            if (f > 1f) assertTrue("cạnh dài ${maxOf(w, h) * f} vượt trần", maxOf(w, h) * f <= ImageEngine.UPSCALE_MAX_SIDE * 1.0001f)
        }
    }

    private fun image(w: Int, h: Int) = makeBitmap(IntArray(w * h) { (255 shl 24) or ((it % w) % 256 shl 16) or (((it / w) % 256) shl 8) or 90 }, w, h)

    @Test fun engineUpscalesToTheExactRequestedSizeWhenItFits() {
        withHeadroom(8L * 1024 * 1024 * 1024) {
            val out = ImageEngine.process(image(40, 30), listOf(EditOp(OpType.UPSCALE, 4f)), null, false, ArrayList())
            assertEquals(160, out.width)
            assertEquals(120, out.height)
            val out2 = ImageEngine.process(image(40, 30), listOf(EditOp(OpType.UPSCALE, 2f)), null, false, ArrayList())
            assertEquals(80, out2.width)
            assertEquals(60, out2.height)
        }
    }

    private fun withHeadroom(bytes: Long, body: () -> Unit) {
        val saved = ImageEngine.heapHeadroom
        ImageEngine.heapHeadroom = { bytes }
        try { body() } finally { ImageEngine.heapHeadroom = saved }
    }

    @Test fun engineClampsTheOutputToTheHardCapWhenMemoryIsPlentiful() {
        withHeadroom(8L * 1024 * 1024 * 1024) {
            val out = ImageEngine.process(image(2000, 100), listOf(EditOp(OpType.UPSCALE, 4f)), null, false, ArrayList())
            assertEquals("cạnh dài bị kẹp ở trần cứng", ImageEngine.UPSCALE_MAX_SIDE, out.width)
            assertEquals("giữ tỉ lệ khung", Math.round(100 * 4096f / 2000f), out.height)
        }
    }

    @Test fun engineCapShrinksWithLessFreeMemory() {
        // 40 MB heap trống: điểm ảnh tối đa = 40·2^20·0,6 / 20 ≈ 1,26 triệu; ảnh 400x300 (tỉ lệ 4:3) -> cạnh dài tối đa ≈ 1295
        withHeadroom(40L * 1024 * 1024) {
            val out = ImageEngine.process(image(400, 300), listOf(EditOp(OpType.UPSCALE, 4f)), null, false, ArrayList())
            val want = ImageEngine.upscaleMaxSide(400, 300, 40L * 1024 * 1024)
            assertTrue("cạnh dài ${out.width} phải ≈ trần theo heap $want, nhỏ hơn ×4 (1600)", out.width in (want - 2)..(want + 2) && out.width < 1600)
        }
        withHeadroom(1L * 1024 * 1024) {
            val out = ImageEngine.process(image(400, 300), listOf(EditOp(OpType.UPSCALE, 4f)), null, false, ArrayList())
            assertEquals("thiếu bộ nhớ thì KHÔNG phóng (không sinh OOM)", 400, out.width)
        }
    }

    @Test fun upscaleMaxSideIsDerivedFromHeadroom() {
        val mb = 1024L * 1024
        assertEquals(4096, ImageEngine.upscaleMaxSide(1536, 1152, 1L shl 40))
        assertEquals("heap 0: không nhỏ hơn ảnh vào", 1536, ImageEngine.upscaleMaxSide(1536, 1152, 0L))
        assertEquals("heap âm coi như 0", 1536, ImageEngine.upscaleMaxSide(1536, 1152, -5L))
        val s150 = ImageEngine.upscaleMaxSide(1536, 1152, 150 * mb)
        assertTrue("150 MB trống, 1536x1152 -> ≈ 2449, không còn 4096 cứng: $s150", s150 in 2390..2510)
        var prev = 0
        for (m in 0..1200 step 25) {
            val v = ImageEngine.upscaleMaxSide(1536, 1152, m * mb)
            assertTrue("đơn điệu theo heap", v >= prev)
            prev = v
        }
        // số điểm ảnh × 20 byte không vượt heap × hệ số an toàn khi thật sự cho phóng
        for ((w, h) in listOf(Pair(1536, 1152), Pair(1152, 1536), Pair(2000, 100), Pair(100, 2000), Pair(1000, 1000))) {
            for (m in listOf(16, 48, 96, 150, 256, 512)) {
                val side = ImageEngine.upscaleMaxSide(w, h, m * mb)
                val long = maxOf(w, h)
                val short = minOf(w, h)
                assertTrue(side in long..ImageEngine.UPSCALE_MAX_SIDE)
                if (side > long) {
                    val pixels = side.toDouble() * (short.toDouble() * side / long)
                    assertTrue("${w}x$h heap $m MB: ${pixels * ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL / mb} MB", pixels * ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL <= m * mb * ImageEngine.UPSCALE_HEAP_SAFETY * 1.002)
                }
            }
        }
        assertEquals("20 byte = 5 mảng Int", 5 * 4, ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL)
    }

    @Test fun previewDoesNotUpscale() {
        val out = ImageEngine.process(image(40, 30), listOf(EditOp(OpType.UPSCALE, 4f)), null, true, ArrayList())
        assertEquals(40, out.width)
        assertEquals(30, out.height)
    }
}
