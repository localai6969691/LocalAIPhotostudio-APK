package com.aiphoto.studio

import com.aiphoto.studio.util.SliderTicks
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** R35: vạch rung của thanh trượt (PDF: "rung nhẹ khi chạm và kéo"). Cùng ca với phần 5 của tools/verify_ports/voice_input.py. */
class R35SliderTicksTest {
    @Test fun notchRangesFromZeroToDivisions() {
        assertEquals(0, SliderTicks.notch(0f, 0f, 1f))
        assertEquals(SliderTicks.DIVISIONS, SliderTicks.notch(1f, 0f, 1f))
        assertEquals(5, SliderTicks.notch(0.5f, 0f, 1f))
        assertEquals(5, SliderTicks.notch(0f, -1f, 1f))       // thang đối xứng: điểm giữa là vạch 5
    }

    @Test fun outOfRangeAndDegenerateScalesAreSafe() {
        assertEquals(0, SliderTicks.notch(-5f, 0f, 1f))
        assertEquals(SliderTicks.DIVISIONS, SliderTicks.notch(9f, 0f, 1f))
        assertEquals(0, SliderTicks.notch(0.5f, 1f, 1f))
        assertEquals(0, SliderTicks.notch(0.5f, 1f, 0f))
        assertEquals(0, SliderTicks.notch(Float.NaN, 0f, 1f))
    }

    @Test fun crossedOnlyWhenPassingANotch() {
        assertFalse(SliderTicks.crossed(0.51f, 0.58f, 0f, 1f))   // cùng khoảng 0,5–0,6
        assertTrue(SliderTicks.crossed(0.51f, 0.62f, 0f, 1f))
        assertTrue(SliderTicks.crossed(0.62f, 0.51f, 0f, 1f))    // kéo ngược cũng rung
        assertFalse(SliderTicks.crossed(0.3f, 0.3f, 0f, 1f))
    }

    @Test fun fullSweepProducesAtMostDivisionsTicks() {
        var ticks = 0
        var prev = 0f
        for (i in 1..1000) {
            val v = i / 1000f
            if (SliderTicks.crossed(prev, v, 0f, 1f)) ticks++
            prev = v
        }
        assertEquals(SliderTicks.DIVISIONS, ticks)
    }
}
