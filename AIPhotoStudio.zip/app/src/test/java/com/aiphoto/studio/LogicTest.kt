package com.aiphoto.studio

import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.Refine
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.doc.Blend
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.ModelPool
import com.aiphoto.studio.engine.ToneOps
import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.PerfProfile
import com.aiphoto.studio.routing.Routing
import com.aiphoto.studio.routing.Tier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử logic thuần (không cần thiết bị) - chạy bằng `gradle :app:testDebugUnitTest`. */
class LogicTest {

    private fun ops(p: String) = RuleBasedPlanner.plan(p).ops
    private fun value(p: String, t: OpType) = ops(p).first { it.type == t }.value

    // ---------------------------------------------------------------- planner luật VI/EN
    @Test fun skinBrightWarm() {
        val o = ops("làm da mịn hơn, sáng hơn, tông ấm")
        assertTrue(o.any { it.type == OpType.SKIN_SMOOTH })
        assertTrue(value("làm da mịn hơn, sáng hơn, tông ấm", OpType.BRIGHTNESS) > 0f)
        assertTrue(value("làm da mịn hơn, sáng hơn, tông ấm", OpType.WARMTH) > 0f)
    }

    @Test fun tooMuchMeansReduce() {
        assertEquals("reduce", ops("da mịn quá, giảm bớt").first { it.type == OpType.SKIN_SMOOTH }.arg)
        assertTrue(value("sáng quá", OpType.BRIGHTNESS) < 0f)
    }

    @Test fun grainIsNotVintage() {
        val o = ops("hạt film")
        assertTrue(o.any { it.type == OpType.GRAIN })
        assertFalse(o.any { it.type == OpType.SEPIA })
    }

    @Test fun coolTone() = assertTrue(value("làm mát ảnh", OpType.WARMTH) < 0f)

    @Test fun brightenShadowsOnly() {
        val o = ops("làm sáng vùng tối")
        assertTrue(o.any { it.type == OpType.SHADOWS })
        assertFalse(o.any { it.type == OpType.BRIGHTNESS })
    }

    @Test fun backgroundWhiteWins() =
        assertEquals("#FFFFFF", ops("xóa nền, nền trắng").last { it.type == OpType.BG_REMOVE }.arg)

    @Test fun idPhotoBlue() {
        val o = ops("ảnh thẻ nền xanh")
        assertEquals("#2D6CDF", o.first { it.type == OpType.BG_REMOVE }.arg)
        assertEquals(0.75f, o.first { it.type == OpType.CROP_RATIO }.value, 1e-4f)
    }

    @Test fun percentAndGeometry() {
        assertEquals(0.3f, value("tăng độ sáng 30%", OpType.BRIGHTNESS), 1e-4f)
        assertEquals(90f, value("xoay phải 90 độ", OpType.ROTATE), 0f)
        assertEquals(16f / 9f, value("cắt 16:9", OpType.CROP_RATIO), 1e-3f)
        assertEquals(1f, value("cắt vuông", OpType.CROP_RATIO), 1e-4f)
    }

    @Test fun reduceSharpenBecomesBlur() = assertTrue(ops("giảm độ nét").any { it.type == OpType.BLUR })

    @Test fun contrastUpSaturationDown() {
        val p = "tăng tương phản và giảm độ bão hòa"
        assertTrue(value(p, OpType.CONTRAST) > 0f)
        assertTrue(value(p, OpType.SATURATION) < 0f)
    }

    @Test fun refinePhrasesProduceNoOps() {
        assertTrue(ops("nhẹ hơn").isEmpty())
        assertEquals(0.6f, Refine.factor("nhẹ hơn")!!, 0f)
        assertEquals(1.4f, Refine.factor("mạnh hơn")!!, 0f)
        assertNull(Refine.factor("làm da mịn hơn, sáng hơn tông ấm và tăng tương phản"))
    }

    // ---------------------------------------------------------------- phân loại tạo sinh
    @Test fun genIntent() {
        assertEquals(GenKind.REMOVE, GenIntent.detect("xóa người bên phải", false))
        assertEquals(GenKind.FILL, GenIntent.detect("thêm một con mèo bên phải", false))
        assertNull(GenIntent.detect("xoay phải 90 độ", false))
        assertNull(GenIntent.detect("xóa nền", true))
        assertNull(GenIntent.detect("xóa mụn", false))
        assertEquals(GenKind.REMOVE, GenIntent.detect("", true))
        assertEquals(GenKind.FILL, GenIntent.detect("đổi thành áo đỏ", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("remove the car", false))
    }

    @Test fun regionHint() {
        val h = GenIntent.regionHint("thêm con mèo bên phải")!!
        assertEquals(0.75f, h.first, 1e-4f)
        assertNull(GenIntent.regionHint("thêm một con mèo"))
    }

    // ---------------------------------------------------------------- Curves / Blend
    @Test fun curveIdentityAndMonotone() {
        val id = ToneOps.curveLut(listOf(Pair(0f, 0f), Pair(1f, 1f)))
        for (i in 0..255) assertEquals(i.toFloat(), id[i].toFloat(), 1f)
        val lift = ToneOps.curveLut(listOf(Pair(0f, 0f), Pair(0.5f, 0.7f), Pair(1f, 1f)))
        assertTrue(lift[128] > 128)
        for (i in 1..255) assertTrue(lift[i] >= lift[i - 1])
        assertTrue(ToneOps.isIdentityCurves("m:0,0;1,1"))
        assertFalse(ToneOps.isIdentityCurves("m:0,0;0.5,0.7;1,1"))
    }

    @Test fun multiplyBlend() {
        val out = Blend.blend(intArrayOf(0xFF808080.toInt()), intArrayOf(0xFF404040.toInt()), BlendMode.MULTIPLY, 1f, null)
        assertEquals(32f, ((out[0] shr 16) and 255).toFloat(), 1f)
        val half = Blend.blend(intArrayOf(0xFF808080.toInt()), intArrayOf(0xFF404040.toInt()), BlendMode.NORMAL, 0.5f, null)
        assertEquals(96f, ((half[0] shr 16) and 255).toFloat(), 1f)
    }

    // ---------------------------------------------------------------- định tuyến + hồ sơ hiệu năng
    private val json = """
        {"version":2,"perf":{"low":{"maxSide":"1280"}},"tasks":{"inpaint_remove":{"providers":[
          {"id":"lama","kind":"lama_onnx","needs":["file:lama.onnx"],"minRamMb":6000},
          {"id":"migan","kind":"migan_onnx","needs":["file:migan.onnx"]},
          {"id":"future","kind":"khong_ton_tai","needs":[]},
          {"id":"classic","kind":"classic_fill","needs":[]}]}}}
    """.trimIndent()

    @Test fun routingFiltersByRamNeedsAndKnownKinds() {
        val cfg = Routing.parse(json)
        val dev = DeviceInfo(4000, "", 30, 4)
        val ids = Routing.chain(cfg, "inpaint_remove", dev, "pro") { it == "file:migan.onnx" }.map { it.id }
        assertEquals(listOf("migan", "classic"), ids)
        val big = Routing.chain(cfg, "inpaint_remove", DeviceInfo(8000, "", 30, 4), "pro") { true }.map { it.id }
        assertEquals(listOf("lama", "migan", "classic"), big)
    }

    @Test fun perfTiersAndOverrides() {
        val cfg = Routing.parse(json)
        val low = PerfProfile.from(DeviceInfo(2000, "", 30, 8), cfg.perf)
        assertEquals(Tier.LOW, low.tier)
        assertEquals(1280, low.maxSide)       // ghi đè từ cấu hình
        assertEquals(3, low.threads)
        val high = PerfProfile.from(DeviceInfo(12000, "", 34, 8), emptyMap())
        assertEquals(Tier.HIGH, high.tier)
        assertEquals(4, high.threads)
    }

    // ---------------------------------------------------------------- phép mới + hồ model
    @Test fun denoiseAndBlurKinds() {
        assertTrue(ops("khử nhiễu").any { it.type == OpType.DENOISE })
        assertTrue(ops("giảm nhiễu ảnh").any { it.type == OpType.DENOISE })
        val m = ops("mờ chuyển động").first { it.type == OpType.MOTION_BLUR }
        assertEquals("0", m.arg)
        assertTrue(ops("mờ xuyên tâm").any { it.type == OpType.RADIAL_BLUR })
        assertTrue(ops("làm mờ ảnh").any { it.type == OpType.BLUR })
    }

    @Test fun straightenKeepsAspectAndShrinks() {
        val (w0, h0) = ImageEngine.largestRotatedRect(1000, 800, 0.0)
        assertEquals(1000, w0)
        assertEquals(800, h0)
        val (w1, h1) = ImageEngine.largestRotatedRect(1000, 800, Math.toRadians(3.0))
        assertTrue(w1 < 1000 && h1 < 800 && w1 > 900 && h1 > 700)
        assertEquals(1.25, w1.toDouble() / h1, 0.02)
    }

    @Test fun modelPoolEvictsLeastRecentlyUsed() {
        val unloaded = ArrayList<String>()
        val pool = ModelPool { 3 }
        pool.register("a", 2) { unloaded.add("a") }
        pool.register("b", 1) { unloaded.add("b") }
        pool.register("c", 2) { unloaded.add("c") }   // tổng 5 > 3 -> bỏ a (ít dùng nhất)
        assertEquals(listOf("a"), unloaded)
        pool.register("b", 1) { unloaded.add("b") }   // làm mới b
        pool.register("d", 2) { unloaded.add("d") }   // c là LRU -> bỏ c
        assertEquals(listOf("a", "c"), unloaded)
        assertEquals(listOf("b", "d"), pool.loaded())
    }

    @Test fun lowTierHasSmallPool() {
        assertEquals(2, PerfProfile.from(DeviceInfo(2000, "", 30, 4), emptyMap()).poolCapacity)
        assertEquals(6, PerfProfile.from(DeviceInfo(12000, "", 34, 8), emptyMap()).poolCapacity)
    }
}
