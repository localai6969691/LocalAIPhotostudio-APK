package com.aiphoto.studio

import com.aiphoto.studio.engine.FaceLiquify
import com.aiphoto.studio.engine.HeadPose
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.tan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R17: ước lượng yaw từ điểm mốc có z + cổng giảm Liquify khi mặt quay nghiêng (đối chiếu tools/verify_ports/head_pose.py). */
class R17Test {

    private val W = 1000
    private val H = 600

    /**
     * Mảng điểm mốc 3×478: mọi điểm ở (0.5, 0.5, 0); trán/cằm/gò má đặt đúng chỗ. Hai gò má cách nhau [facePx] pixel TRONG MẶT PHẲNG ẢNH
     * (xoay [rollDeg] trong ảnh) và lệch chiều sâu để trục ngang nghiêng khỏi mặt phẳng ảnh đúng [yawDeg] độ.
     */
    private fun lm(yawDeg: Float, rollDeg: Float = 0f, facePx: Float = 400f, withDepth: Boolean = true): FloatArray {
        val n = HeadPose.POINTS
        val a = FloatArray(if (withDepth) 3 * n else 2 * n)
        for (i in 0 until n) { a[2 * i] = 0.5f; a[2 * i + 1] = 0.5f }
        val roll = rollDeg * PI.toFloat() / 180f
        val hx = facePx / 2f * cos(roll)
        val hy = facePx / 2f * sin(roll)
        a[2 * HeadPose.CHEEK_R] = 0.5f - hx / W; a[2 * HeadPose.CHEEK_R + 1] = 0.5f - hy / H
        a[2 * HeadPose.CHEEK_L] = 0.5f + hx / W; a[2 * HeadPose.CHEEK_L + 1] = 0.5f + hy / H
        // trán, cằm theo trục dọc của mặt (vuông góc trục ngang trong mặt phẳng ảnh)
        val fx = 0.5f + (-sin(roll)) * 0.15f * H / W; val fy = 0.5f - cos(roll) * 0.15f
        a[2 * 10] = fx; a[2 * 10 + 1] = fy
        a[2 * 152] = 1f - fx; a[2 * 152 + 1] = 1f - fy
        if (withDepth) {
            // |Δz| / độ dài trong mặt phẳng = tan(yaw)  =>  Δz(px) = facePx * tan(yaw); chuẩn hóa theo chiều rộng ảnh
            val dz = facePx * tan(yawDeg * PI.toFloat() / 180f)
            a[2 * n + HeadPose.CHEEK_L] = (dz / 2f) / W
            a[2 * n + HeadPose.CHEEK_R] = -(dz / 2f) / W
        }
        return a
    }

    // ------------------------------------------------------------------ HeadPose
    @Test fun yawIsRecoveredOnNonSquareImage() {
        for (yaw in listOf(0f, 10f, 30f, 45f, 60f, 80f)) {
            val est = HeadPose.yawAbsDeg(lm(yaw), W, H)
            assertNotNull(est)
            assertEquals("yaw $yaw", yaw, est!!, 0.1f)
        }
    }

    @Test fun rollDoesNotChangeYaw() {
        for (roll in listOf(-60f, -25f, 25f, 60f)) assertEquals(30f, HeadPose.yawAbsDeg(lm(30f, roll), W, H)!!, 0.1f)
    }

    @Test fun nullWhenNoDepthOrDegenerate() {
        assertTrue(HeadPose.hasDepth(lm(0f)))
        assertTrue(!HeadPose.hasDepth(lm(0f, withDepth = false)))
        assertNull(HeadPose.yawAbsDeg(lm(40f, withDepth = false), W, H))        // mảng cũ chỉ x,y
        assertNull(HeadPose.yawAbsDeg(lm(40f, facePx = 3f), W, H))              // mặt quá nhỏ
        assertNull(HeadPose.yawAbsDeg(lm(40f), 0, H))
        assertNull(HeadPose.yawAbsDeg(lm(40f), W, 0))
        assertNull(HeadPose.yawAbsDeg(FloatArray(10), W, H))
        val flat = FloatArray(3 * HeadPose.POINTS) { 0.5f }
        assertNull(HeadPose.yawAbsDeg(flat, W, H))                               // mọi điểm trùng nhau
    }

    @Test fun gainCurve() {
        assertEquals(1f, HeadPose.liquifyGain(null), 0f)                         // không biết góc -> giữ nguyên
        for (y in listOf(0f, 10f, 20f)) assertEquals(1f, HeadPose.liquifyGain(y), 0f)
        for (y in listOf(55f, 70f, 90f)) assertEquals(0f, HeadPose.liquifyGain(y), 0f)
        assertEquals(0.5f, HeadPose.liquifyGain(37.5f), 1e-5f)
        var prev = 2f
        var y = 0f
        while (y <= 90f) {                                                       // đơn điệu không tăng, liên tục
            val g = HeadPose.liquifyGain(y)
            assertTrue("gain tăng tại $y", g <= prev + 1e-6f)
            assertTrue("nhảy bậc tại $y", prev == 2f || prev - g < 0.03f)
            prev = g; y += 0.1f
        }
    }

    // ------------------------------------------------------------------ FaceLiquify: cổng áp đúng hệ số
    private fun segment(args: String, index: Int): List<Float> = args.split(';')[index].split(',').map { it.toFloat() }

    private fun magnitudePx(args: String, index: Int): Float {
        val s = segment(args, index)
        return hypot(s[2] * W, s[3] * H)
    }

    @Test fun faceLiquifyIsGatedByYaw() {
        val frontal = FaceLiquify.args(lm(0f), W, H, 1f, 0f, 0f, 0f)
        assertTrue(frontal.isNotBlank())
        val noDepth = FaceLiquify.args(lm(0f, withDepth = false), W, H, 1f, 0f, 0f, 0f)
        assertEquals(frontal, noDepth)                                           // thiếu z: y như trước R17

        // đoạn đẩy thứ 5 của hàm (bell = 1): độ lớn phải nhân đúng bằng gain
        val base = magnitudePx(frontal, 4)
        for (yaw in listOf(10f, 30f, 40f)) {                                     // độ dời còn ≥ 5 px nên sai số làm tròn %.5f < 0,1%
            val turned = FaceLiquify.args(lm(yaw), W, H, 1f, 0f, 0f, 0f)
            assertEquals("yaw $yaw", HeadPose.liquifyGain(yaw), magnitudePx(turned, 4) / base, 3e-3f)
        }
        val nearProfile = FaceLiquify.args(lm(50f), W, H, 1f, 0f, 0f, 0f)         // gain 0,055: còn rất nhẹ nhưng chưa tắt
        assertTrue(nearProfile.isNotBlank() && magnitudePx(nearProfile, 4) < base * 0.1f)
        assertEquals("", FaceLiquify.args(lm(60f), W, H, 1f, 1f, 1f, 1f))        // gần nghiêng hẳn: tắt hết
        assertEquals("", FaceLiquify.args(lm(0f), W, H, 0f, 0f, 0f, 0f))         // 0 tham số -> rỗng như cũ
    }
}
