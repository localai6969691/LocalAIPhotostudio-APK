package com.aiphoto.studio

import com.aiphoto.studio.ui.isWideLayout
import com.aiphoto.studio.ui.sidePanelWidthDp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** R39: quy tắc bố cục rộng (máy tính bảng / nằm ngang / màn gập). Kích thước thật là dp của các máy phổ biến. */
class R39Test {
    @Test
    fun phonesHeldUprightKeepTheSingleColumn() {
        assertFalse("điện thoại 360x800", isWideLayout(360, 800))
        assertFalse("điện thoại lớn 412x915", isWideLayout(412, 915))
        assertFalse("Fold gập 344x882", isWideLayout(344, 882))
        assertFalse("cửa sổ chia đôi hẹp 360x400", isWideLayout(360, 400))
    }

    @Test
    fun phonesInLandscapeGetTwoPanes() {
        assertTrue("điện thoại nằm ngang 800x360", isWideLayout(800, 360))
        assertTrue("điện thoại lớn nằm ngang 915x412", isWideLayout(915, 412))
        assertTrue("ngưỡng ngang 600x300", isWideLayout(600, 300))
        assertFalse("ngang nhưng hẹp 560x300 (ảnh sẽ quá nhỏ)", isWideLayout(560, 300))
    }

    @Test
    fun tabletsAndUnfoldedScreensAreWideInAnyOrientation() {
        assertTrue("máy tính bảng 10 inch dọc 840x1280", isWideLayout(840, 1280))
        assertTrue("máy tính bảng nằm ngang 1280x800", isWideLayout(1280, 800))
        assertTrue("Fold mở ra 673x841 nằm dọc... rộng 673 < 840 nhưng chưa ngang", !isWideLayout(673, 841))
        assertTrue("Fold mở ra nằm ngang 841x673", isWideLayout(841, 673))
        assertTrue("cửa sổ máy tính 1920x1080", isWideLayout(1920, 1080))
    }

    @Test
    fun invalidSizesFallBackToTheSafePhoneLayout() {
        assertFalse(isWideLayout(0, 0))
        assertFalse(isWideLayout(-1, 800))
        assertFalse(isWideLayout(1000, 0))
    }

    @Test
    fun sidePanelWidthIsClampedAndLeavesRoomForThePhoto() {
        assertEquals(300, sidePanelWidthDp(600))       // 36% = 216 -> kẹp dưới 300
        assertEquals(300, sidePanelWidthDp(800))       // 288 -> 300
        assertEquals(PANEL_AT_915, sidePanelWidthDp(915))
        assertEquals(460, sidePanelWidthDp(1280))      // 460,8 -> 460
        assertEquals(460, sidePanelWidthDp(2000))
        for (w in 600..2400 step 7) {
            if (!isWideLayout(w, 400) && !isWideLayout(w, 3000)) continue
            val photo = w - 20 - 10 - sidePanelWidthDp(w)   // trừ lề 2x10 và khoảng cách 10
            assertTrue("rộng $w: ảnh còn $photo dp (cần >= 270)", photo >= 270)
        }
    }

    private companion object { const val PANEL_AT_915 = 329 }
}
