package com.aiphoto.studio

import com.aiphoto.studio.engine.FaceLiquify3D
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Kiểm thử R37: Liquify 3D theo khung đầu. Dữ liệu là lưới 478 điểm THẬT (R37Fixture, từ ảnh phi hành gia NASA) nên không phải khuôn mặt tổng hợp;
 * kỳ vọng so khớp CHÉO với bản Python (tools/verify_ports/face_liquify3d.py), bản này đã được hiệu chuẩn bằng vòng kín trên ảnh thật.
 */
class R37Test {
    private val W = R37Fixture.W
    private val H = R37Fixture.H
    private val N = FaceLiquify3D.POINTS

    private fun mesh(): FloatArray = R37Fixture.MESH.copyOf()

    /** Quay lưới quanh tâm hai gò má trong không gian pixel (x, y, z*W) - cùng công thức rotate_mesh của bản Python. R là ma trận 3x3 theo hàng. */
    private fun rotate(lm: FloatArray, r: Array<DoubleArray>): FloatArray {
        val out = lm.copyOf()
        val ox = ((lm[2 * 234] + lm[2 * 454]) / 2.0) * W
        val oy = ((lm[2 * 234 + 1] + lm[2 * 454 + 1]) / 2.0) * H
        val oz = ((lm[2 * N + 234] + lm[2 * N + 454]) / 2.0) * W
        for (i in 0 until N) {
            val x = lm[2 * i] * W - ox; val y = lm[2 * i + 1] * H - oy; val z = lm[2 * N + i] * W - oz
            val qx = r[0][0] * x + r[0][1] * y + r[0][2] * z + ox
            val qy = r[1][0] * x + r[1][1] * y + r[1][2] * z + oy
            val qz = r[2][0] * x + r[2][1] * y + r[2][2] * z + oz
            out[2 * i] = (qx / W).toFloat(); out[2 * i + 1] = (qy / H).toFloat(); out[2 * N + i] = (qz / W).toFloat()
        }
        return out
    }

    private fun rotY(deg: Double): Array<DoubleArray> {
        val t = deg * PI / 180
        return arrayOf(doubleArrayOf(cos(t), 0.0, sin(t)), doubleArrayOf(0.0, 1.0, 0.0), doubleArrayOf(-sin(t), 0.0, cos(t)))
    }

    private fun rotX(deg: Double): Array<DoubleArray> {
        val t = deg * PI / 180
        return arrayOf(doubleArrayOf(1.0, 0.0, 0.0), doubleArrayOf(0.0, cos(t), -sin(t)), doubleArrayOf(0.0, sin(t), cos(t)))
    }

    private fun rotZ(deg: Double): Array<DoubleArray> {
        val t = deg * PI / 180
        return arrayOf(doubleArrayOf(cos(t), -sin(t), 0.0), doubleArrayOf(sin(t), cos(t), 0.0), doubleArrayOf(0.0, 0.0, 1.0))
    }

    private fun mul(a: Array<DoubleArray>, b: Array<DoubleArray>): Array<DoubleArray> =
        Array(3) { i -> DoubleArray(3) { j -> a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j] } }

    private val fixtureParams = FaceLiquify3D.ShapeParams(slim = 0.8f, slimB = 0.2f, eyes = 0.7f, eyesA = 0.3f, nose = 0.6f, smile = 0.5f, chin = 0.4f, balance = 1.0f)

    private fun poseFor(name: String): FloatArray = when (name) {
        "frontal" -> mesh()
        "yaw_m28" -> rotate(mesh(), rotY(-28.0))
        else -> rotate(mesh(), mul(rotZ(15.0), rotX(-12.0)))
    }

    // ------------------------------------------------------------------ so khớp chéo với Python trên lưới thật
    @Test
    fun crossCheckWithPythonOnRealMesh() {
        for ((name, expectedTxt) in R37Fixture.EXPECTED) {
            val exp = expectedTxt.trim().split(' ').map { it.toDouble() }
            val segs = FaceLiquify3D.segments(poseFor(name), W, H, fixtureParams)
            assertEquals("$name: số đoạn", exp.size / 5, segs.size)
            for ((k, s) in segs.withIndex()) {
                val e = exp.subList(5 * k, 5 * k + 5)
                assertEquals("$name[$k].x", e[0], s.x, 0.02)
                assertEquals("$name[$k].y", e[1], s.y, 0.02)
                assertEquals("$name[$k].dx", e[2], s.dx, 0.02)
                assertEquals("$name[$k].dy", e[3], s.dy, 0.02)
                assertEquals("$name[$k].r", e[4], s.r, 0.02)
            }
        }
    }

    // ------------------------------------------------------------------ khung đầu
    @Test
    fun frameOnRealMeshIsOrthonormalAndSane() {
        val fr = FaceLiquify3D.frame(mesh(), W, H)
        assertNotNull(fr)
        fr!!
        fun dot(a: DoubleArray, b: DoubleArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
        assertEquals(1.0, dot(fr.u, fr.u), 1e-9); assertEquals(1.0, dot(fr.v, fr.v), 1e-9); assertEquals(1.0, dot(fr.f, fr.f), 1e-9)
        assertEquals(0.0, dot(fr.u, fr.v), 1e-9); assertEquals(0.0, dot(fr.u, fr.f), 1e-9); assertEquals(0.0, dot(fr.v, fr.f), 1e-9)
        assertTrue("u hướng sang phải ảnh", fr.u[0] > 0.9)
        assertTrue("v hướng xuống", fr.v[1] > 0.9)
        assertTrue("mặt gần như nhìn thẳng (yaw ${fr.yawDeg})", abs(fr.yawDeg) < 12.0)
        assertTrue("bề rộng 3D >= bề rộng ảnh", fr.w3 >= fr.fwImg - 1e-6)
        assertTrue("khuôn mặt lớn hơn 60px", fr.w3 > 60.0)
    }

    @Test
    fun recoversRotationsAppliedToTheRealMesh() {
        val base = FaceLiquify3D.frame(mesh(), W, H)!!
        for (d in listOf(-45.0, -25.0, 15.0, 35.0)) {
            val f = FaceLiquify3D.frame(rotate(mesh(), rotY(d)), W, H)!!
            assertEquals("yaw $d", abs(d), abs(f.yawDeg - base.yawDeg), 2.0)
            assertEquals("W3 bất biến khi quay $d", base.w3, f.w3, base.w3 * 0.02)
        }
        for (d in listOf(-20.0, 25.0)) {
            val f = FaceLiquify3D.frame(rotate(mesh(), rotZ(d)), W, H)!!
            assertEquals("roll $d", d, f.rollDeg - base.rollDeg, 1.0)
            assertEquals("roll không đổi yaw", base.yawDeg, f.yawDeg, 1.0)
        }
        for (d in listOf(-15.0, 15.0)) {
            val f = FaceLiquify3D.frame(rotate(mesh(), rotX(d)), W, H)!!
            assertEquals("pitch $d không làm lệch yaw", base.yawDeg, f.yawDeg, 2.0)
        }
    }

    @Test
    fun frameRejectsBadInput() {
        assertNull(FaceLiquify3D.frame(FloatArray(2 * N), W, H))                 // thiếu z
        assertNull(FaceLiquify3D.frame(mesh(), 0, H))
        assertNull(FaceLiquify3D.frame(FloatArray(3 * N) { 0.5f }, W, H))        // mọi điểm trùng nhau
        assertNull(FaceLiquify3D.frame(FloatArray(10), W, H))
        val tiny = mesh()
        for (i in 0 until N) { tiny[2 * i] = 0.5f + (tiny[2 * i] - 0.5f) * 0.01f; tiny[2 * i + 1] = 0.5f + (tiny[2 * i + 1] - 0.5f) * 0.01f }
        assertNull("mặt quá nhỏ", FaceLiquify3D.frame(tiny, W, H))
        val nan = mesh(); nan[7] = Float.NaN
        assertNull("NaN", FaceLiquify3D.frame(nan, W, H))
        assertEquals("", FaceLiquify3D.args(FloatArray(2 * N), W, H, FaceLiquify3D.ShapeParams(slim = 1f)))
        assertEquals("", FaceLiquify3D.args(mesh(), W, H, FaceLiquify3D.ShapeParams()))              // 0 tham số
        assertTrue(FaceLiquify3D.ShapeParams().isIdentity)
    }

    // ------------------------------------------------------------------ từng bên
    @Test
    fun slimAffectsOnlyTheChosenSide() {
        val lm = mesh()
        val mid = lm[2 * 168] * W
        val a = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(slimA = 1f))
        assertEquals(9, a.size)
        assertTrue("chỉ bên trái ảnh", a.all { it.x < mid })
        assertTrue("bên A đẩy vào trong (sang phải)", a.all { it.dx > 0 })
        val b = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(slimB = 1f))
        assertEquals(9, b.size)
        assertTrue("chỉ bên phải ảnh", b.all { it.x > mid })
        assertTrue(b.all { it.dx < 0 })
        val both = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(slim = 1f))
        assertEquals(18, both.size)
        val mixed = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(slim = 0.5f, slimB = 0.5f))
        val magA = mixed.filter { it.x < mid }.sumOf { abs(it.dx) }
        val magB = mixed.filter { it.x > mid }.sumOf { abs(it.dx) }
        assertEquals("slim chung + slimB: bên B gấp đôi (lưới thật không đối xứng hoàn hảo)", 2.0, magB / magA, 0.02)
        val eyesA = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(eyesA = 1f))
        assertEquals(8, eyesA.size)
        assertTrue(eyesA.all { it.x < mid })
        assertEquals(16, FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(eyes = 1f)).size)
    }

    @Test
    fun featuresPushInTheExpectedDirection() {
        val lm = mesh()
        val smile = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(smile = 1f))
        assertEquals(2, smile.size)
        assertTrue("khóe môi đi lên", smile.all { it.dy < 0 })
        val chin = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(chin = 1f))
        assertEquals(7, chin.size)
        assertTrue("cằm đi lên (rút ngắn)", chin.all { it.dy < 0 })
        val nose = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(nose = 1f))
        assertEquals(6, nose.size)
        val mid = lm[2 * 168] * W
        assertTrue("cánh mũi dồn về giữa", nose.all { if (it.x < mid) it.dx > 0 else it.dx < 0 })
        val eyes = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(eyes = 1f))
        // mỗi đoạn đẩy mắt hướng RA XA tâm vòng mắt: tích vô hướng với vector tâm->điểm > 0
        val fr = FaceLiquify3D.frame(lm, W, H)!!
        val ringA = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
        val cx = ringA.sumOf { fr.px[it] } / ringA.size
        val cy = ringA.sumOf { fr.py[it] } / ringA.size
        val onA = eyes.filter { s -> ringA.any { abs(fr.px[it] - s.x) < 0.5 && abs(fr.py[it] - s.y) < 0.5 } }
        assertEquals(8, onA.size)
        assertTrue("mắt nở ra", onA.all { (it.x - cx) * it.dx + (it.y - cy) * it.dy > 0 })
    }

    // ------------------------------------------------------------------ foreshortening / roll / đồng dạng
    @Test
    fun rollRotatesPushDirectionAndKeepsMagnitude() {
        val p = FaceLiquify3D.ShapeParams(slimA = 1f)
        val s0 = FaceLiquify3D.segments(mesh(), W, H, p)
        val s1 = FaceLiquify3D.segments(rotate(mesh(), rotZ(20.0)), W, H, p)
        val d0x = s0.sumOf { it.dx }; val d0y = s0.sumOf { it.dy }
        val d1x = s1.sumOf { it.dx }; val d1y = s1.sumOf { it.dy }
        val ang = (atan2(d1y, d1x) - atan2(d0y, d0x)) * 180 / PI
        assertEquals("hướng đẩy quay theo roll", 20.0, ang, 1.5)
        assertEquals("độ lớn giữ nguyên", 1.0, hypot(d1x, d1y) / hypot(d0x, d0y), 0.03)
    }

    @Test
    fun turnedHeadShrinksNearSidePushAndGatesTheFarSide() {
        val base = FaceLiquify3D.segments(mesh(), W, H, FaceLiquify3D.ShapeParams(slim = 1f)).sumOf { abs(it.dx) }
        val m = rotate(mesh(), rotY(-30.0))
        val g = FaceLiquify3D.gateInfo(m, W, H)!!
        val nearIsA = g[0] >= g[1]
        assertEquals("bên gần giữ nguyên hệ số", 1.0, max(g[0], g[1]), 1e-9)
        assertTrue("bên xa bị giảm", minOf(g[0], g[1]) < 0.999)
        val segs = FaceLiquify3D.segments(m, W, H, if (nearIsA) FaceLiquify3D.ShapeParams(slimA = 1f) else FaceLiquify3D.ShapeParams(slimB = 1f))
        val near = segs.sumOf { abs(it.dx) }
        val half = base / 2                                  // một bên nhìn thẳng
        // sau chuẩn hóa mật độ, khoảng cách giữa các điểm hàm trong ảnh đổi theo góc (do chiều sâu) nên không đúng bằng cos; chỉ yêu cầu cùng bậc với một bên nhìn thẳng
        assertTrue("bên gần không biến mất cũng không phình ($near vs $half)", near < half * 1.3 && near > half * 0.6)
        val far = FaceLiquify3D.segments(m, W, H, if (nearIsA) FaceLiquify3D.ShapeParams(slimB = 1f) else FaceLiquify3D.ShapeParams(slimA = 1f)).sumOf { abs(it.dx) }
        assertTrue("bên xa nhẹ hơn bên gần ($far < $near)", far < near)
    }

    @Test
    fun sideGainsCurve() {
        var g = FaceLiquify3D.sideGains(0.0)
        assertEquals(1.0, g[0], 0.0); assertEquals(1.0, g[1], 0.0)
        g = FaceLiquify3D.sideGains(30.0)                    // yaw > 0: bên B xa
        assertEquals(1.0, g[0], 0.0); assertTrue(g[1] < 1.0 && g[1] > 0.0)
        val h = FaceLiquify3D.sideGains(-30.0)
        assertEquals(g[1], h[0], 1e-12); assertEquals(g[0], h[1], 1e-12)
        g = FaceLiquify3D.sideGains(75.0)                    // bên xa tắt, bên gần còn rất ít
        assertEquals(0.0, minOf(g[0], g[1]), 0.0); assertTrue(maxOf(g[0], g[1]) in 0.0001..0.1)
        g = FaceLiquify3D.sideGains(85.0)
        assertEquals(0.0, g[0], 0.0); assertEquals(0.0, g[1], 0.0)
        var prev = 2.0
        for (d in 0..90 step 3) {
            val far = FaceLiquify3D.sideGains(d.toDouble())[1]
            assertTrue("bên xa không tăng khi quay thêm", far <= prev + 1e-12); prev = far
        }
        // mặt gần nghiêng hẳn: không còn gì để làm
        val profile = rotate(mesh(), rotY(-85.0))
        assertTrue(FaceLiquify3D.segments(profile, W, H, FaceLiquify3D.ShapeParams(slim = 1f, eyes = 1f, nose = 1f, smile = 1f, chin = 1f, balance = 1f)).isEmpty())
    }

    @Test
    fun similarityInvariance() {
        val p = FaceLiquify3D.ShapeParams(slim = 1f, eyes = 1f, chin = 1f)
        val s1 = FaceLiquify3D.segments(mesh(), W, H, p)
        val s2 = FaceLiquify3D.segments(mesh(), 2 * W, 2 * H, p)         // cùng tọa độ chuẩn hóa nhưng ảnh to gấp đôi => mặt to gấp đôi
        assertEquals(s1.size, s2.size)
        for (k in s1.indices) {
            assertEquals(2.0, s2[k].dx / s1[k].dx, 0.01)
            assertEquals(2.0, s2[k].r / s1[k].r, 0.01)
        }
    }

    // ------------------------------------------------------------------ cân bằng hai bên
    @Test
    fun balancePullsMisalignedPairsTogetherAndIsCapped() {
        val lm = mesh()
        val fr0 = FaceLiquify3D.frame(lm, W, H)!!
        val bad = lm.copyOf()
        val ringB = intArrayOf(263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249)
        for (i in ringB) bad[2 * i + 1] += 8f / H                               // mắt bên B tụt xuống 8 px
        val segs = FaceLiquify3D.segments(bad, W, H, FaceLiquify3D.ShapeParams(balance = 1f))
        val fr = FaceLiquify3D.frame(bad, W, H)!!
        fun segAt(i: Int) = segs.firstOrNull { abs(it.x - fr.px[i]) < 0.5 && abs(it.y - fr.py[i]) < 0.5 }
        val sB = segAt(263); val sA = segAt(33)
        assertNotNull(sB); assertNotNull(sA)
        assertTrue("mắt B (đang thấp) được kéo lên", sB!!.dy < 0)
        assertTrue("mắt A được kéo xuống", sA!!.dy > 0)
        val cap = FaceLiquify3D.BAL_CAP * fr.w3
        assertTrue("không vượt trần", segs.all { hypot(it.dx, it.dy) <= cap * 1.0001 + 1e-9 })
        // gốc: lưới thật vốn hơi lệch -> cân bằng nhẹ vẫn chỉ tạo độ dời nhỏ so với khuôn mặt
        val orig = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(balance = 1f))
        assertTrue("độ dời nhỏ so với bề rộng mặt", orig.all { hypot(it.dx, it.dy) < 0.05 * fr0.w3 })
    }

    // ------------------------------------------------------------------ bộ bảo vệ gấp nếp
    @Test
    fun foldGuardKeepsEveryPoseAndEverySliderSafe() {
        val cases = listOf(
            FaceLiquify3D.ShapeParams(slim = 1f), FaceLiquify3D.ShapeParams(eyes = 1f), FaceLiquify3D.ShapeParams(nose = 1f), FaceLiquify3D.ShapeParams(smile = 1f), FaceLiquify3D.ShapeParams(chin = 1f), FaceLiquify3D.ShapeParams(balance = 1f),
            FaceLiquify3D.ShapeParams(slim = 1f, slimA = 1f, slimB = 1f, eyes = 1f, eyesA = 1f, eyesB = 1f, nose = 1f, smile = 1f, chin = 1f, balance = 1f)
        )
        for (name in listOf("frontal", "yaw_m28", "roll15_pitch_m12")) {
            val lm = poseFor(name)
            for (p in cases) {
                val segs = FaceLiquify3D.segments(lm, W, H, p)
                if (segs.isEmpty()) continue
                val s = FaceLiquify3D.foldGuardScale(segs, W, H)
                val det = FaceLiquify3D.minJacobian(segs, W, H, s)
                assertTrue("$name: sau bảo vệ det=$det >= ${FaceLiquify3D.MIN_DET}", det >= FaceLiquify3D.MIN_DET - 1e-6)
                assertTrue(s > 0.0 && s <= 1.0)
            }
        }
        // hiệu chuẩn: một thanh trượt tại 1.0 trên mặt thật KHÔNG cần bảo vệ (bảo vệ chỉ là lưới an toàn)
        for (p in cases.take(6)) {
            val segs = FaceLiquify3D.segments(mesh(), W, H, p)
            assertEquals("hằng số hiệu chuẩn phải nằm trong vùng an toàn", 1.0, FaceLiquify3D.foldGuardScale(segs, W, H), 0.0)
        }
    }

    @Test
    fun foldGuardScalesDownAnExtremeField() {
        // hai đoạn cực mạnh, gần nhau, ngược chiều -> chắc chắn gấp nếp
        val segs = listOf(
            FaceLiquify3D.Seg(200.0, 200.0, 60.0, 0.0, 40.0),
            FaceLiquify3D.Seg(230.0, 200.0, -60.0, 0.0, 40.0)
        )
        assertTrue("trường thô bị gấp nếp", FaceLiquify3D.minJacobian(segs, 400, 400, 1.0) < 0.0)
        val s = FaceLiquify3D.foldGuardScale(segs, 400, 400)
        assertTrue("phải giảm biên độ ($s)", s < 0.6)
        assertTrue(FaceLiquify3D.minJacobian(segs, 400, 400, s) >= FaceLiquify3D.MIN_DET - 1e-6)
        assertEquals(1.0, FaceLiquify3D.foldGuardScale(emptyList(), 400, 400), 0.0)
    }

    @Test
    fun fieldAtJawLandmarksMatchesIntendedDisplacement() {
        // dựng lại trường cộng nhân như ToneOps.liquify rồi đo tại điểm mốc hàm: sau chuẩn hóa mật độ phải ≈ giá trị ý định (đo thật: 92-95%)
        val lm = mesh()
        val fr = FaceLiquify3D.frame(lm, W, H)!!
        val segs = FaceLiquify3D.segments(lm, W, H, FaceLiquify3D.ShapeParams(slim = 1f))
        fun smooth(d: Double, r: Double): Double { if (d >= r) return 0.0; val t = 1 - d / r; return t * t * (3 - 2 * t) }
        val ids = intArrayOf(93, 132, 58, 172, 136, 150, 149, 176, 148)
        val k = 4                                                           // giữa hàm: bell = 1
        val px = fr.px[ids[k]]; val py = fr.py[ids[k]]
        var fx = 0.0
        for (s in segs) fx += s.dx * smooth(hypot(px - s.x, py - s.y), s.r)
        val intended = FaceLiquify3D.K_SLIM * fr.w3 * fr.u[0]
        val ratio = fx / intended
        assertTrue("tỉ lệ trường/ý định = $ratio", ratio in 0.8..1.05)
    }

    // ------------------------------------------------------------------ đầu ra
    @Test
    fun argsFormatMatchesLiquifyOpContract() {
        val arg = FaceLiquify3D.args(mesh(), W, H, fixtureParams)
        assertTrue(arg.isNotBlank())
        val re = Regex("^(-?\\d+\\.\\d{5},){4}-?\\d+\\.\\d{5}(;(-?\\d+\\.\\d{5},){4}-?\\d+\\.\\d{5})*$")
        assertTrue("định dạng x,y,dx,dy,r;…", re.matches(arg))
        val rows = arg.split(';').map { r -> r.split(',').map { it.toDouble() } }
        assertTrue("tâm nằm trong ảnh", rows.all { it[0] in 0.0..1.0 && it[1] in 0.0..1.0 })
        assertTrue("độ dời nhỏ hơn 10% bề rộng ảnh", rows.all { abs(it[2]) < 0.1 && abs(it[3]) < 0.1 })
        assertTrue("bán kính dương", rows.all { it[4] > 0.0 })
        val n = FaceLiquify3D.segments(mesh(), W, H, fixtureParams).size
        assertEquals(n, rows.size)
        assertEquals("", FaceLiquify3D.args(mesh(), W, H, FaceLiquify3D.ShapeParams(slim = 0.002f)))
    }
}
