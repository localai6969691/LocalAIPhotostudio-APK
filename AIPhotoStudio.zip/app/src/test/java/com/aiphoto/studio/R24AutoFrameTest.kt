package com.aiphoto.studio

import com.aiphoto.studio.ai.AutoFrameIntent
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.AutoFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * R24 Auto Frame: thuật toán gợi ý khung cắt trên bản đồ quan trọng tổng hợp (không cần ảnh thật), hình học cắt dùng chung,
 * arg "cx,cy,scale" và nhận biết yêu cầu bằng lời.
 */
class R24AutoFrameTest {
    private fun blob(gw: Int, gh: Int, x0: Float, y0: Float, x1: Float, y1: Float, v: Float = 1f): FloatArray {
        val a = FloatArray(gw * gh)
        for (y in 0 until gh) for (x in 0 until gw) {
            val cx = (x + 0.5f) / gw
            val cy = (y + 0.5f) / gh
            if (cx in x0..x1 && cy in y0..y1) a[y * gw + x] = v
        }
        return a
    }

    private fun inside(f: AutoFrame.Frame, x0: Float, y0: Float, x1: Float, y1: Float) =
        f.x0 <= x0 + 1e-3f && f.y0 <= y0 + 1e-3f && f.x1 >= x1 - 1e-3f && f.y1 >= y1 - 1e-3f

    // ------------------------------------------------------------ gợi ý khung
    @Test fun subjectOnTheLeftPullsTheSquareFrameLeftAndStaysInside() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.08f, 0.30f, 0.30f, 0.70f)), 400, 300, 1f)
        assertTrue("khung phải dạt trái, x0=${f.x0}", f.cx < 0.45f)
        assertTrue("chủ thể phải nằm trọn trong khung: ${f.x0},${f.y0},${f.x1},${f.y1}", inside(f, 0.08f, 0.30f, 0.30f, 0.70f))
        val r = AutoFrame.cropRect(400, 300, 1f, f.cx, f.cy, f.scale)
        assertTrue("khung vuông: ${r[2]}x${r[3]}", abs(r[2] - r[3]) <= 1)
        assertTrue(r[0] >= 0 && r[1] >= 0 && r[0] + r[2] <= 400 && r[1] + r[3] <= 300)
    }

    @Test fun subjectOnTheRightPullsTheFrameRight() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.70f, 0.30f, 0.92f, 0.70f)), 400, 300, 1f)
        assertTrue("cx=${f.cx}", f.cx > 0.55f)
        assertTrue(inside(f, 0.70f, 0.30f, 0.92f, 0.70f))
    }

    @Test fun facesAreNeverCutEvenWhenAnotherSubjectOutweighsThem() {
        val gw = 64; val gh = 36
        val faces = blob(gw, gh, 0.82f, 0.30f, 0.92f, 0.62f)
        val big = blob(gw, gh, 0.06f, 0.10f, 0.30f, 0.90f)          // chủ thể lớn hơn nhiều ở bên trái, cách xa mặt
        val m = AutoFrame.Maps(gw, gh, AutoFrame.combine(big, null, faces), faces)
        val f = AutoFrame.suggest(m, 640, 360, 1f)
        assertTrue("phải giữ trọn mặt: ${f.x0}..${f.x1}", inside(f, 0.82f, 0.30f, 0.92f, 0.62f))
    }

    @Test fun noSubjectKeepsTheCenteredLargestFrameLikeTheOldCrop() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, FloatArray(1200)), 400, 300, 1f)
        assertEquals(0.5f, f.cx, 1e-4f); assertEquals(0.5f, f.cy, 1e-4f); assertEquals(1f, f.scale, 1e-4f)
        assertTrue(f.note, f.note.contains("giữ khung ở giữa"))
        assertFalse(f.coversAll)   // vuông trên ảnh 4:3 vẫn phải cắt bớt hai bên
    }

    @Test fun smallSubjectZoomsInButNeverBeyondTwiceAndStaysInside() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.44f, 0.42f, 0.56f, 0.58f)), 400, 300, 4f / 3f)
        assertTrue("scale=${f.scale}", f.scale < 0.95f && f.scale >= AutoFrame.MIN_SCALE - 1e-4f)
        assertTrue(inside(f, 0.44f, 0.42f, 0.56f, 0.58f))
        val r = AutoFrame.cropRect(400, 300, 4f / 3f, f.cx, f.cy, f.scale)
        assertTrue(r[2] >= 200 && r[3] >= 150)   // không nhỏ hơn nửa chiều ảnh
    }

    @Test fun subjectFillingTheImageNeedsNoCropWhenRatioMatches() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.02f, 0.02f, 0.98f, 0.98f)), 400, 300, 4f / 3f)
        assertTrue("scale=${f.scale}", f.coversAll)
        assertTrue(f.note, f.note.contains("đã hợp"))
    }

    @Test fun subjectIsPlacedOffCenterNearAThirdWhenThereIsSlack() {
        // ảnh siêu rộng 21:9, chủ thể nhỏ đúng giữa, cắt vuông: còn dư chỗ trượt ngang -> đặt chủ thể gần 1/3 hoặc 2/3 chứ không chính giữa khung
        val gw = 84; val gh = 36
        val f = AutoFrame.suggest(AutoFrame.Maps(gw, gh, blob(gw, gh, 0.48f, 0.40f, 0.52f, 0.60f)), 2100, 900, 1f)
        val wn = f.x1 - f.x0
        val u = (0.5f - f.x0) / wn
        assertTrue("u=$u scale=${f.scale}", abs(u - 0.5f) > 0.08f && u in 0.2f..0.8f)
        assertTrue(inside(f, 0.48f, 0.40f, 0.52f, 0.60f))
    }

    @Test fun heavierSubjectWinsOverALighterOneCloserToTheCenter() {
        val gw = 84; val gh = 36
        val big = blob(gw, gh, 0.02f, 0.15f, 0.20f, 0.85f, 1f)         // khối lượng lớn sát mép trái
        val small = blob(gw, gh, 0.52f, 0.40f, 0.57f, 0.60f, 1f)       // nhỏ, gần giữa
        val imp = FloatArray(gw * gh) { big[it] + small[it] }
        val f = AutoFrame.suggest(AutoFrame.Maps(gw, gh, imp), 2100, 900, 1f)
        assertTrue("cx=${f.cx} x0=${f.x0} x1=${f.x1}", f.cx < 0.35f && f.x0 <= 0.05f && f.x1 >= 0.20f)
    }

    @Test fun subjectAlreadyAtAThirdPointStillZoomsBecauseOfEmptyFrame() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.30f, 0.30f, 0.36f, 0.36f)), 400, 300, 4f / 3f)
        assertTrue("scale=${f.scale}", f.scale < 0.95f)
        assertTrue(inside(f, 0.30f, 0.30f, 0.36f, 0.36f))
    }

    @Test fun faintBackgroundNoiseDoesNotHideTheSubject() {
        val gw = 40; val gh = 30
        val b = blob(gw, gh, 0.44f, 0.42f, 0.56f, 0.58f, 0.8f)
        val imp = FloatArray(gw * gh) { 0.2f + b[it] }                  // nền đều 0.2 (nhiễu), chủ thể nhỏ 1.0 ở giữa
        val f = AutoFrame.suggest(AutoFrame.Maps(gw, gh, imp), 400, 300, 4f / 3f)
        assertTrue("nền đều không được che mất chủ thể: scale=${f.scale}", f.scale < 0.95f)
        assertTrue(inside(f, 0.44f, 0.42f, 0.56f, 0.58f))
    }

    @Test fun faceIsKeptWholeAndAnnouncedEvenNextToAMoreSalientObject() {
        val gw = 84; val gh = 36
        val faces = blob(gw, gh, 0.46f, 0.35f, 0.50f, 0.55f)
        val other = blob(gw, gh, 0.55f, 0.30f, 0.64f, 0.70f)           // vật khác nổi bật hơn nằm bên phải mặt
        val m = AutoFrame.Maps(gw, gh, AutoFrame.combine(other, null, faces), faces)
        val f = AutoFrame.suggest(m, 2100, 900, 1f)
        assertTrue(inside(f, 0.46f, 0.35f, 0.50f, 0.55f))
        assertTrue(f.note, f.note.contains("khuôn mặt"))
    }

    @Test fun verySmallBlobFarInTheCornerStillEndsUpInsideTheFrame() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.85f, 0.78f, 0.95f, 0.92f)), 400, 300, 0.8f)
        assertTrue(inside(f, 0.85f, 0.78f, 0.95f, 0.92f))
    }

    // ------------------------------------------------------------ hình học cắt
    private fun legacyCrop(w: Int, h: Int, ratio: Float): IntArray {
        val cur = w.toFloat() / h
        val nw: Int; val nh: Int
        if (cur > ratio) { nh = h; nw = (h * ratio).roundToInt() } else { nw = w; nh = (w / ratio).roundToInt() }
        val cw = nw.coerceIn(1, w); val ch = nh.coerceIn(1, h)
        return intArrayOf((w - cw) / 2, (h - ch) / 2, cw, ch)
    }

    @Test fun defaultCropRectIsExactlyTheOldCenteredCrop() {
        for (w in listOf(1000, 1001, 1920, 2047, 333)) for (h in listOf(750, 751, 1080, 1999, 500)) for (r in listOf(1f, 0.8f, 0.75f, 1.3333f, 1.7778f, 0.5625f, 2.39f, 0.3f)) {
            assertEquals("$w x $h r=$r", legacyCrop(w, h, r).toList(), AutoFrame.cropRect(w, h, r).toList())
        }
    }

    @Test fun cropRectClampsInsideTheImageAndKeepsRatio() {
        val w = 1200; val h = 800
        val lo = AutoFrame.cropRect(w, h, 1f, 0f, 0f, 1f)
        assertEquals(0, lo[0]); assertEquals(0, lo[1])
        val hi = AutoFrame.cropRect(w, h, 1f, 1f, 1f, 1f)
        assertEquals(w - hi[2], hi[0]); assertEquals(h - hi[3], hi[1])
        val tiny = AutoFrame.cropRect(w, h, 1f, 0.5f, 0.5f, 0.1f)          // scale thấp quá bị kẹp về MIN_SCALE
        val half = AutoFrame.cropRect(w, h, 1f, 0.5f, 0.5f, AutoFrame.MIN_SCALE)
        assertEquals(half.toList(), tiny.toList())
        for (s in listOf(1f, 0.88f, 0.64f, 0.52f)) for (r in listOf(1f, 0.8f, 1.7778f, 0.5625f)) {
            val c = AutoFrame.cropRect(w, h, r, 0.37f, 0.61f, s)
            assertTrue(c[0] >= 0 && c[1] >= 0 && c[0] + c[2] <= w && c[1] + c[3] <= h)
            assertTrue("tỉ lệ $r scale $s: ${c[2]}x${c[3]}", abs(c[2] - r * c[3]) <= r + 1.5f)
        }
    }

    @Test fun suggestedFrameAndActualCropAgree() {
        // khung gợi ý (chuẩn hóa) và hình chữ nhật cắt thật sai lệch tối đa vài điểm ảnh
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.10f, 0.30f, 0.30f, 0.70f)), 1600, 1200, 0.8f)
        val r = AutoFrame.cropRect(1600, 1200, 0.8f, f.cx, f.cy, f.scale)
        assertEquals(f.x0 * 1600, r[0].toFloat(), 3f); assertEquals(f.y0 * 1200, r[1].toFloat(), 3f)
        assertEquals((f.x1 - f.x0) * 1600, r[2].toFloat(), 3f); assertEquals((f.y1 - f.y0) * 1200, r[3].toFloat(), 3f)
    }

    // ------------------------------------------------------------ arg
    @Test fun argRoundTripAndNormalization() {
        val f = AutoFrame.suggest(AutoFrame.Maps(40, 30, blob(40, 30, 0.08f, 0.30f, 0.30f, 0.70f)), 400, 300, 1f)
        val t = AutoFrame.parseArg(AutoFrame.encodeArg(f))!!
        assertEquals(f.cx, t.first, 1e-3f); assertEquals(f.cy, t.second, 1e-3f); assertEquals(f.scale, t.third, 1e-3f)
        assertNull(AutoFrame.normalizeArg("0.5,0.5,1"))                      // chính là cắt giữa mặc định
        assertNull(AutoFrame.normalizeArg("hỏng")); assertNull(AutoFrame.normalizeArg("1,2")); assertNull(AutoFrame.normalizeArg(null)); assertNull(AutoFrame.normalizeArg("a,b,c"))
        assertNull(AutoFrame.parseArg("NaN,0.5,1"))
        assertEquals("0.2500,1.0000,0.500", AutoFrame.normalizeArg("0.25,7,0.1"))   // ngoài khoảng bị kẹp
    }

    @Test fun cropOpKeepsAutoFrameArgThroughSanitizeButStillDropsGarbage() {
        val keep = EditOp(OpType.CROP_RATIO, 0.8f, "0.3000,0.5000,0.760").sanitized()
        assertNotNull(keep); assertEquals("0.3000,0.5000,0.760", keep!!.arg)
        assertNull(EditOp(OpType.CROP_RATIO, 0.8f, "rác").sanitized()!!.arg)
        assertNull(EditOp(OpType.CROP_RATIO, 0.8f, null).sanitized()!!.arg)
        assertTrue(EditOp(OpType.CROP_RATIO, 0.8f, "0.3000,0.5000,0.760").describe().contains("Auto Frame"))
        assertFalse(EditOp(OpType.CROP_RATIO, 0.8f).describe().contains("Auto Frame"))
    }

    // ------------------------------------------------------------ bản đồ quan trọng
    @Test fun saliencyFindsAColorfulObjectOnPlainBackground() {
        val w = 40; val h = 30
        val px = IntArray(w * h) { 0xFF808080.toInt() }
        for (y in 10 until 18) for (x in 20 until 28) px[y * w + x] = 0xFFE02020.toInt()
        val s = AutoFrame.saliency(px, w, h)
        assertTrue("tâm vật thể ${s[14 * w + 24]}", s[14 * w + 24] > 0.5f)
        assertTrue("góc nền ${s[2 * w + 2]}", s[2 * w + 2] < 0.1f)
        assertTrue(s.all { it in 0f..1f })
    }

    @Test fun saliencyOfAFlatImageIsAllZeroAndBadInputIsSafe() {
        assertTrue(AutoFrame.saliency(IntArray(40 * 30) { 0xFF404040.toInt() }, 40, 30).all { it == 0f })
        assertEquals(0, AutoFrame.saliency(IntArray(0), 0, 0).size)
        assertTrue(AutoFrame.saliency(IntArray(5), 40, 30).all { it == 0f })
    }

    @Test fun endToEndFromPixelsFindsTheSubjectSide() {
        val w = 120; val h = 90
        val px = IntArray(w * h) { 0xFF707070.toInt() }
        for (y in 30 until 62) for (x in 14 until 36) px[y * w + x] = 0xFF1060D0.toInt()
        val maps = AutoFrame.Maps(w, h, AutoFrame.combine(AutoFrame.saliency(px, w, h), null, null))
        val f = AutoFrame.suggest(maps, 1200, 900, 1f)
        assertTrue("cx=${f.cx}", f.cx < 0.45f)
        assertTrue(inside(f, 14f / w, 30f / h, 36f / w, 62f / h))
    }

    @Test fun combineIgnoresBrokenSegmentationAndLiftsFaces() {
        val sal = FloatArray(100) { if (it < 10) 0.8f else 0.1f }
        assertEquals(sal.toList(), AutoFrame.combine(sal, FloatArray(100) { 1f }, null).toList())     // mặt nạ phủ cả ảnh = hỏng, bỏ qua
        assertEquals(sal.toList(), AutoFrame.combine(sal, FloatArray(100), null).toList())             // mặt nạ trống = hỏng, bỏ qua
        assertEquals(sal.toList(), AutoFrame.combine(sal, FloatArray(7) { 1f }, null).toList())        // sai kích thước = bỏ qua
        val fg = FloatArray(100) { if (it in 40..49) 1f else 0f }
        val c = AutoFrame.combine(sal, fg, null)
        assertTrue(c[45] > 0.7f && c[5] < 0.3f)                                                        // chủ thể model chiếm phần lớn
        val faces = FloatArray(100) { if (it == 99) 1f else 0f }
        assertEquals(0.9f, AutoFrame.combine(sal, null, faces)[99], 1e-4f)
    }

    @Test fun fgUsableBoundaries() {
        assertFalse(AutoFrame.fgUsable(FloatArray(100)))
        assertFalse(AutoFrame.fgUsable(FloatArray(100) { if (it < 1) 1f else 0f }))     // 1% quá ít
        assertTrue(AutoFrame.fgUsable(FloatArray(100) { if (it < 3) 1f else 0f }))
        assertTrue(AutoFrame.fgUsable(FloatArray(100) { if (it < 80) 1f else 0f }))
        assertFalse(AutoFrame.fgUsable(FloatArray(100) { if (it < 85) 1f else 0f }))
        assertFalse(AutoFrame.fgUsable(FloatArray(0)))
    }

    @Test fun resizeMeanAveragesCells() {
        val src = floatArrayOf(0f, 1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f, 10f, 11f, 12f, 13f, 14f, 15f)
        assertEquals(listOf(2.5f, 4.5f, 10.5f, 12.5f), AutoFrame.resizeMean(src, 4, 4, 2, 2).toList())
        assertEquals(src.toList(), AutoFrame.resizeMean(src, 4, 4, 4, 4).toList())
        assertEquals(4, AutoFrame.resizeMean(floatArrayOf(1f, 1f), 2, 1, 2, 2).size)            // phóng lớn không lỗi
    }

    @Test fun mapsRejectWrongSizes() {
        var thrown = false
        try { AutoFrame.Maps(4, 4, FloatArray(15)) } catch (e: IllegalArgumentException) { thrown = true }
        assertTrue(thrown)
    }

    // ------------------------------------------------------------ nhận biết yêu cầu bằng lời
    @Test fun intentRecognisesAutoFramePhrasesWithOptionalRatio() {
        assertEquals(0.8f, AutoFrameIntent.detect("cắt 4:5 theo chủ thể")!!.ratio!!, 1e-4f)
        assertEquals(1f, AutoFrameIntent.detect("tự động cắt vuông")!!.ratio!!, 1e-4f)
        assertEquals(16f / 9f, AutoFrameIntent.detect("Auto frame 16:9")!!.ratio!!, 1e-3f)
        assertNull(AutoFrameIntent.detect("cắt thông minh")!!.ratio)
        assertEquals(0.75f, AutoFrameIntent.detect("crop around the subject 3/4")!!.ratio!!, 1e-4f)
        assertNotNull(AutoFrameIntent.detect("bố cục đẹp hơn"))
        assertNotNull(AutoFrameIntent.detect("cắt ảnh theo quy tắc 1/3"))
    }

    @Test fun intentDoesNotStealOrdinaryCropsOrOtherRequests() {
        for (p in listOf("cắt 16:9", "cắt vuông", "crop 4:3", "làm đẹp tự nhiên", "xóa người lạ", "mở rộng ảnh thành 16:9", "tăng tương phản", "chủ thể sáng hơn", "")) assertNull(p, AutoFrameIntent.detect(p))
    }
}
