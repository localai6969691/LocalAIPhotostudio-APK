package com.aiphoto.studio

import com.aiphoto.studio.engine.Adaptive
import com.aiphoto.studio.engine.DepthProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.max

/**
 * R30f: bộ điều khiển THÍCH NGHI của cạnh vào model độ sâu ([Adaptive]) — thay cho bảng ngưỡng RAM viết cứng. Mô phỏng nhiều "máy" theo đúng đường cong chi phí ViT-S/14
 * (FLOPs). Mọi khẳng định đã được bản port Python `tools/verify_ports/adaptive.py` kiểm với cùng hằng số (đọc từ mã Kotlin).
 */
class R30AdaptiveTest {
    private val patch = DepthProfile.PATCH
    private val maxEdge = DepthProfile.LONG_EDGE
    private val minEdge = patch * Adaptive.MIN_PATCHES
    private val budget = Adaptive.DEFAULT_BUDGET_MS

    /** Chi phí ViT-S/14 (d = 384, 12 khối) theo cạnh e: 12·(12·n·d² + 2·n²·d), n = (e/14)². */
    private fun flops(e: Int): Double {
        val n = (e.toDouble() / patch) * (e.toDouble() / patch)
        return 12.0 * (12.0 * n * 384.0 * 384.0 + 2.0 * n * n * 384.0)
    }

    private fun timeMs(tMax: Double, e: Int): Double = tMax * flops(e) / flops(maxEdge)

    private fun bestEdge(tMax: Double): Int {
        var best = minEdge
        var e = minEdge
        while (e <= maxEdge) { if (timeMs(tMax, e) <= budget) best = e; e += patch }
        return best
    }

    private fun converge(tMax: Double, coldExtra: Double = 0.0, runs: Int = 12): Pair<Int, List<Pair<Int, Double>>> {
        var edge = maxEdge
        val hist = ArrayList<Pair<Int, Double>>()
        for (k in 0 until runs) {
            val t = timeMs(tMax, edge) + (if (k == 0) coldExtra else 0.0)
            hist.add(Pair(edge, t))
            edge = Adaptive.nextEdge(edge, t.toLong(), budget, minEdge, maxEdge, patch, k == 0)
        }
        return Pair(edge, hist)
    }

    @Test fun constantsAreTheDerivedOnes() {
        assertEquals(0, maxEdge % patch)
        assertEquals(0, minEdge % patch)
        assertEquals("cận dưới của mũ chi phí", 2.0f, Adaptive.SHRINK_EXPONENT, 0f)
        // mũ cục bộ ở cạnh lớn nhất của ViT-S: d ln F / d ln e
        val e = maxEdge.toDouble()
        val n = (e / patch) * (e / patch)
        val a = 12.0 * 384.0 * 384.0
        val b = 2.0 * 384.0
        val local = 2.0 * (a * n + 2.0 * b * n * n) / (a * n + b * n * n)
        assertTrue("GROW_EXPONENT ${Adaptive.GROW_EXPONENT} phải ≥ mũ cục bộ $local và không lớn hơn quá 0.05", Adaptive.GROW_EXPONENT >= local - 1e-9 && Adaptive.GROW_EXPONENT <= local + 0.05)
        assertTrue("phóng to không bao giờ vượt ngân sách: GROW_BELOW·MAX_GROW^GROW_EXP < 1", Adaptive.GROW_BELOW * Math.pow(Adaptive.MAX_GROW.toDouble(), Adaptive.GROW_EXPONENT.toDouble()) < 1.0)
        assertTrue("COLD_TOLERANCE phủ lần nạp đầu tệ nhất đã công bố của Qualcomm AI Hub (11,2 s)", 11200.0 <= Adaptive.COLD_TOLERANCE * budget)
    }

    @Test fun convergesToTheLargestEdgeWithinBudgetOnEveryKindOfDevice() {
        for (tMax in listOf(47.0, 80.0, 400.0, 1500.0, 4000.0, 9000.0, 30000.0)) {
            val (final, hist) = converge(tMax)
            val opt = bestEdge(tMax)
            val steady = timeMs(tMax, final)
            assertTrue("tMax=$tMax: cạnh $final ngoài biên", final in minEdge..maxEdge && final % patch == 0)
            assertTrue("tMax=$tMax: thời gian ổn định $steady > $budget (cạnh $final)", steady <= budget || final == minEdge)
            assertTrue("tMax=$tMax: cạnh $final < 75% tối ưu $opt; lịch sử $hist", final >= 0.75 * opt)
            assertEquals("tMax=$tMax: không dao động", final, Adaptive.nextEdge(final, steady.toLong(), budget, minEdge, maxEdge, patch, false))
        }
    }

    @Test fun coldFirstRunIsNotLearnedFromUnlessItIsHopelesslySlow() {
        val (finalNpu, histNpu) = converge(47.0, coldExtra = 11200.0)
        assertEquals("NPU có lần chạy đầu thêm 11,2 s (số công bố) không bị thu nhỏ oan: $histNpu", maxEdge, finalNpu)
        val (_, histSlow) = converge(40000.0)
        assertTrue("máy cực yếu: lần đầu 40 s > 6× ngân sách thì thu nhỏ ngay: $histSlow", histSlow[1].first < maxEdge)
        val mutated = Adaptive.nextEdge(maxEdge, 11250L, budget, minEdge, maxEdge, patch, false)
        assertTrue("coi lần đầu như lần thường sẽ thu nhỏ NPU oan", mutated < maxEdge)
    }

    @Test fun growsGraduallyFromASmallStartOnAFastDevice() {
        var edge = minEdge
        var prev = edge
        for (k in 0 until 14) {
            val t = timeMs(100.0, edge)
            edge = Adaptive.nextEdge(edge, t.toLong(), budget, minEdge, maxEdge, patch, false)
            assertTrue("bước tăng quá lớn: $prev -> $edge", edge <= Math.ceil(prev * Adaptive.MAX_GROW.toDouble()).toInt() + patch)
            prev = edge
        }
        assertTrue("phải lớn lại gần tối ưu ${bestEdge(100.0)}: $edge", edge >= 0.75 * bestEdge(100.0))
    }

    @Test fun neverOvershootsTheBudgetWhenGrowing() {
        var worst = 0.0
        var e = minEdge
        while (e < maxEdge) {
            for (frac in listOf(0.02, 0.1, 0.25, 0.4, Adaptive.GROW_BELOW - 1e-3)) {
                val t = budget * frac
                val e2 = Adaptive.nextEdge(e, t.toLong(), budget, minEdge, maxEdge, patch, false)
                worst = max(worst, t * flops(e2) / flops(e) / budget)
            }
            e += patch
        }
        assertTrue("sau khi phóng to thời gian dự đoán tệ nhất = $worst × ngân sách", worst <= 1.0)
    }

    @Test fun oneShrinkStepIsEnoughToReturnWithinBudget() {
        for (tMax in listOf(2000.0, 4000.0, 9000.0, 30000.0)) {
            val e1 = Adaptive.nextEdge(maxEdge, tMax.toLong(), budget, minEdge, maxEdge, patch, false)
            assertTrue("tMax=$tMax: một bước chưa đủ: cạnh $e1 mất ${timeMs(tMax, e1)} ms", e1 == minEdge || timeMs(tMax, e1) <= budget)
        }
    }

    @Test fun failureShrinksStrictlyDownToTheMinimumAndStops() {
        var e = maxEdge
        val chain = arrayListOf(e)
        repeat(20) {
            val n = Adaptive.afterFailure(e, minEdge, patch)
            if (n >= e) return@repeat
            e = n
            chain.add(e)
        }
        for (i in 1 until chain.size) assertTrue("giảm nghiêm ngặt: $chain", chain[i] < chain[i - 1])
        assertEquals("dừng ở mức tối thiểu: $chain", minEdge, chain.last())
        assertTrue(chain.all { it % patch == 0 })
        assertEquals(minEdge, Adaptive.afterFailure(minEdge, minEdge, patch))
        assertEquals(minEdge, Adaptive.afterFailure(minEdge + patch, minEdge, patch))
    }

    @Test fun hysteresisBandAndInputBoundsAreRespected() {
        for (f in listOf(Adaptive.GROW_BELOW + 0.01, 0.75, 1.0)) {
            assertEquals(294, Adaptive.nextEdge(294, (budget * f).toLong(), budget, minEdge, maxEdge, patch, false))
        }
        assertEquals(300, Adaptive.nextEdge(300, 0L, budget, minEdge, maxEdge, patch, false))
        assertEquals(300, Adaptive.nextEdge(300, 100L, 0L, minEdge, maxEdge, patch, false))
        assertTrue(Adaptive.nextEdge(9999, 1500L, budget, minEdge, maxEdge, patch, false) <= maxEdge)
        assertTrue(Adaptive.nextEdge(5, 1500L, budget, minEdge, maxEdge, patch, false) >= minEdge)
        assertEquals(maxEdge, Adaptive.nextEdge(maxEdge, 1L, budget, minEdge, maxEdge, patch, false))
        assertEquals(DepthProfile.PATCH * 14, Adaptive.snap(DepthProfile.PATCH * 14 + 3f, patch, 0, 9999))
    }
}
