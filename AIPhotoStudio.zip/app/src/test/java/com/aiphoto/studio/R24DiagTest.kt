package com.aiphoto.studio

import com.aiphoto.studio.util.CrashHandler
import com.aiphoto.studio.util.CrashStore
import com.aiphoto.studio.util.DiagLog
import com.aiphoto.studio.util.DiagReport
import com.aiphoto.studio.util.ExitRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

/**
 * R24: kênh báo lỗi cho tester. Kiểm: nhật ký vòng tròn, ẩn khóa/token/email/đường dẫn ảnh, ghép báo cáo (cắt gọn đúng chỗ),
 * lưu + đọc lại lỗi đóng đột ngột, móc bắt ngoại lệ, và lọc lần bị hệ thống tắt (ApplicationExitInfo).
 */
class R24DiagTest {
    private fun tmp(): File = Files.createTempDirectory("diag").toFile()

    private fun input(
        status: String = "Đã xong.", log: List<String> = listOf("+  1.0s [trạng thái] mở ảnh"), crash: String? = null,
        exits: List<ExitRecord> = emptyList(), settings: List<Pair<String, String>> = listOf("model Gemini" to "gemini-x"),
        prompts: List<String> = emptyList()
    ) = DiagReport.Input(
        appVersion = "1.0 (mã 1)", device = listOf("máy" to "Acme Phone"), perf = "Hạng MID",
        modelsReady = listOf("tách nền"), modelsMissing = listOf("LaMa"), modelFiles = listOf("segmenter.onnx" to 5_000_000L),
        settings = settings, doc = listOf("số lớp" to "2"), status = status, recentPrompts = prompts, log = log, crash = crash, exits = exits
    )

    // ------------------------------------------------------------ nhật ký
    @Test fun logIsRingBufferKeepingNewest() {
        DiagLog.reset { 0L }
        for (i in 1..(DiagLog.CAPACITY + 50)) DiagLog.add("t", "dòng $i")
        val snap = DiagLog.snapshot()
        assertEquals(DiagLog.CAPACITY, snap.size)
        assertTrue(snap.first().endsWith("dòng 51"))
        assertTrue(snap.last().endsWith("dòng ${DiagLog.CAPACITY + 50}"))
    }

    @Test fun logSkipsRepeatsFlattensNewlinesAndCutsLongLines() {
        DiagLog.reset { 0L }
        DiagLog.add("a", "x"); DiagLog.add("a", "x"); DiagLog.add("b", "x"); DiagLog.add("a", "   ")
        assertEquals(2, DiagLog.size())
        DiagLog.add("c", "một\nhai")
        assertTrue(DiagLog.snapshot().last().endsWith("một|hai"))
        DiagLog.add("d", "z".repeat(1000))
        val l = DiagLog.snapshot().last()
        assertTrue(l.length < DiagLog.MAX_LINE + 40)
        DiagLog.add("e", "z".repeat(1000), 900)
        assertTrue(DiagLog.snapshot().last().length > 800)
    }

    @Test fun logTimestampsAreRelativeSecondsAndSnapshotTakesTail() {
        var now = 1_000_000L
        DiagLog.reset { now }
        now += 12_340; DiagLog.add("t", "một")
        now += 100; DiagLog.add("t", "hai")
        val s = DiagLog.snapshot()
        assertTrue(s[0], s[0].startsWith("+   12.3s [t] một"))
        assertEquals(listOf(s[1]), DiagLog.snapshot(1))
        assertTrue(DiagLog.snapshot(0).isEmpty())
    }

    // ------------------------------------------------------------ ẩn dữ liệu nhạy cảm
    private val geminiKey = "AIzaSyD-1234567890abcdefghijklmnopqrstu"
    private val bearer = "tok_9f8e7d6c5b4a39281716"

    @Test fun scrubHidesGoogleKeysTokensAndHeaders() {
        val raw = "GET https://x.googleapis.com/v1/models?key=$geminiKey&alt=sse -H 'Authorization: Bearer $bearer' api_key: $geminiKey {\"token\":\"$bearer\"}"
        val s = DiagReport.scrub(raw)
        assertFalse(s, s.contains(geminiKey)); assertFalse(s, s.contains("AIzaSyD")); assertFalse(s, s.contains(bearer))
        assertTrue(s, s.contains("[đã ẩn]"))
        assertTrue(s, s.contains("alt=sse"))   // phần không nhạy cảm giữ nguyên
    }

    @Test fun scrubHidesBareLongTokensEncryptedBlobsAndEmails() {
        val s = DiagReport.scrub("khóa AIza$geminiKey dán nhầm; blob enc1:QUJDREVGR0hJSktMTU5PUA== ; liên hệ nguoi.dung+tag@gmail.com; uuid 3f2504e0-4f89-11d3-9a0c-0305e82c3301")
        assertFalse(s, s.contains("1234567890abcdef"))
        assertFalse(s, s.contains("QUJDREVG"))
        assertFalse(s, s.contains("gmail.com"))
        assertFalse(s, s.contains("3f2504e0-4f89-11d3-9a0c-0305e82c3301"))
        assertTrue(s, s.contains("[email]"))
    }

    @Test fun scrubHidesImagePathsAndUriButKeepsAppPaths() {
        val s = DiagReport.scrub("lỗi đọc content://media/external/images/media/1234 và /storage/emulated/0/DCIM/Camera/IMG_2024.jpg, model ở /data/user/0/com.aiphoto.studio/files/models/lama.onnx")
        assertFalse(s, s.contains("media/external"))
        assertFalse(s, s.contains("IMG_2024"))
        assertTrue(s, s.contains("/data/user/0/com.aiphoto.studio/files/models/lama.onnx"))
    }

    @Test fun scrubHidesUrlCredentialsButNotOrdinaryText() {
        val s = DiagReport.scrub("kết nối https://admin:s3cr3tpass@192.168.1.5:7860/sdapi thất bại")
        assertFalse(s, s.contains("s3cr3tpass")); assertFalse(s, s.contains("admin:"))
        val plain = "Đã xóa vật thể trong 1.2s. Ảnh 1024×768, model segmenter_portrait.onnx, com.aiphoto.studio.MainViewModel.run(MainViewModel.kt:1628)"
        assertEquals(plain, DiagReport.scrub(plain))
    }

    @Test fun hostOfKeepsOnlyHostAndPort() {
        assertEquals("api.example.com:8443", DiagReport.hostOf("https://user:pw@api.example.com:8443/v1/x?k=1#a"))
        assertEquals("192.168.1.5:7860", DiagReport.hostOf("http://192.168.1.5:7860"))
        assertEquals("host", DiagReport.hostOf("host/path"))
        assertEquals("", DiagReport.hostOf("  "))
    }

    // ------------------------------------------------------------ ngăn xếp lỗi
    @Test fun formatThrowableCapsFramesAndFollowsCauses() {
        fun deep(n: Int): Nothing = if (n == 0) throw IllegalStateException("gốc rễ") else deep(n - 1)
        val e = try { deep(60); throw AssertionError() } catch (t: IllegalStateException) { RuntimeException("bọc ngoài", t) }
        val s = DiagReport.formatThrowable(e, maxFrames = 5)
        assertTrue(s, s.startsWith("java.lang.RuntimeException: bọc ngoài"))
        assertTrue(s, s.contains("Caused by: java.lang.IllegalStateException: gốc rễ"))
        assertTrue(s, s.contains("khung nữa"))
        assertTrue(s.lines().count { it.startsWith("  at ") } <= 10)
    }

    @Test fun formatThrowableLimitsCauseChainLength() {
        val chain = RuntimeException("c0", RuntimeException("c1", RuntimeException("c2", RuntimeException("c3"))))
        val s = DiagReport.formatThrowable(chain, maxFrames = 1, maxCauses = 1)
        assertEquals(2, Regex("""(?m)^(Caused by: )?java\.lang\.RuntimeException""").findAll(s).count())
        assertTrue(s, s.contains("c1")); assertFalse(s, s.contains("c2"))
        assertEquals(4, Regex("""(?m)^(Caused by: )?java\.lang\.RuntimeException""").findAll(DiagReport.formatThrowable(chain, 1, 9)).count())
    }

    @Test fun formatThrowableSurvivesCauseCycleAndLongMessage() {
        val a = RuntimeException("a" + "x".repeat(900)); val b = RuntimeException("b", a)
        a.initCause(b)
        val s = DiagReport.formatThrowable(a, 2, 5)
        assertTrue(s.length < 1500)
        assertEquals(2, Regex("""(?m)^(Caused by: )?java\.lang\.RuntimeException""").findAll(s).count())
    }

    // ------------------------------------------------------------ ghép báo cáo
    @Test fun reportHasAllSectionsAndNoRawSecrets() {
        val r = DiagReport.compose(
            input(
                status = "Lỗi: 403 key=$geminiKey", log = listOf("+  2.0s [lỗi] Authorization: Bearer $bearer"),
                crash = "java.lang.OutOfMemoryError: Failed\n  at a.b.C.d(C.kt:1)",
                exits = listOf(ExitRecord(3, 100, 1_700_000_000_000L, 800_000, 900_000, "low mem")),
                prompts = listOf("xóa người thừa ở bìa phải")
            ), 1_700_000_100_000L
        )
        for (h in listOf("Ứng dụng", "Máy", "Model", "Cài đặt", "Ảnh và lớp", "Trạng thái cuối", "Lỗi làm app đóng", "Lần app bị hệ thống kết thúc", "Nhật ký gần nhất"))
            assertTrue("thiếu mục $h\n$r", r.contains("== $h"))
        assertFalse(r, r.contains(geminiKey)); assertFalse(r, r.contains(bearer))
        assertTrue(r, r.contains("LOW_MEMORY")); assertTrue(r, r.contains("2023-11-14T22:15:00Z"))
        assertTrue(r, r.contains("đã nạp: tách nền")); assertTrue(r, r.contains("chưa nạp: LaMa"))
        assertTrue(r, r.contains("tệp segmenter.onnx: 4.8 MB"))
        assertTrue(r, r.contains("lời nhắc gần đây: xóa người thừa ở bìa phải"))
    }

    @Test fun exitsAreListedNewestFirst() {
        val r = DiagReport.compose(input(exits = listOf(ExitRecord(4, 100, 1_700_000_000_000L), ExitRecord(3, 100, 1_700_000_500_000L))))
        assertTrue(r, r.indexOf("LOW_MEMORY") in 0 until r.indexOf("CRASH "))
    }

    @Test fun reportOmitsCrashAndExitSectionsWhenNone() {
        val r = DiagReport.compose(input())
        assertFalse(r.contains("Lỗi làm app đóng")); assertFalse(r.contains("hệ thống kết thúc"))
    }

    @Test fun oversizedReportKeepsNewestLogLinesAndStaysUnderCap() {
        val log = (1..200).map { "+${it}.0s [t] " + "n".repeat(250) + " số $it" }
        val r = DiagReport.compose(input(log = log))
        assertTrue(r.length <= DiagReport.MAX_CHARS)
        assertTrue(r, r.contains("số 200"))     // dòng mới nhất còn
        assertFalse(r, r.contains("số 1\n"))    // dòng cũ nhất đã bị bỏ trước
        assertTrue(r, r.contains("== Máy ==")); assertTrue(r, r.contains("== Trạng thái cuối =="))   // mục khác không bị cắt
    }

    @Test fun noteIsScrubbedCappedAndOptional() {
        assertEquals("R", DiagReport.withNote("   ", "R"))
        val r = DiagReport.withNote("khóa của tôi $geminiKey sai", "R")
        assertTrue(r.startsWith("Ghi chú của tester: ")); assertFalse(r.contains(geminiKey)); assertTrue(r.endsWith("\n\nR"))
        assertTrue(DiagReport.withNote("y".repeat(5000), "R").length < DiagReport.NOTE_MAX + 60)
    }

    // ------------------------------------------------------------ lưu lỗi đóng đột ngột
    @Test fun crashStoreRoundTripAndShownFlag() {
        val dir = tmp()
        val st = CrashStore(dir)
        assertNull(st.peek()); assertNull(st.pendingUnseen())
        DiagLog.reset { 0L }; DiagLog.add("việc", "Đang xóa vật thể…")
        st.save("main", IllegalStateException("hỏng rồi"), 1_700_000_000_000L)
        val t = st.peek()!!
        assertTrue(t, t.contains("java.lang.IllegalStateException: hỏng rồi")); assertTrue(t, t.contains("luồng: main"))
        assertTrue(t, t.contains("Đang xóa vật thể"))                  // nhật ký ngay trước lỗi được lưu kèm
        assertEquals(t, st.pendingUnseen())
        st.markShown()
        assertNull(st.pendingUnseen()); assertEquals(t, st.peek())     // đã hiện thì không hiện lại, nhưng Cài đặt vẫn gửi kèm được
        st.save("worker", RuntimeException("lỗi mới"))                  // lỗi mới ghi đè và hiện lại
        assertTrue(st.pendingUnseen()!!.contains("lỗi mới"))
        st.clear()
        assertNull(st.peek()); assertNull(st.pendingUnseen())
    }

    @Test fun crashStoreNeverThrowsWhenDirIsUnwritable() {
        val f = File.createTempFile("notadir", "x")
        CrashStore(File(f, "sub")).save("t", RuntimeException("x"))   // thư mục cha là tệp thường
        assertNull(CrashStore(File(f, "sub")).peek())
        CrashStore(File(f, "sub")).markShown(); CrashStore(File(f, "sub")).clear()
    }

    @Test fun crashStoreAtUsesDiagSubdir() {
        val root = tmp()
        CrashStore.at(root).save("t", RuntimeException("x"))
        assertTrue(File(root, "diag/last_crash.txt").isFile)
    }

    @Test fun handlerSavesThenDelegatesToPreviousHandlerAndIsNotStackedTwice() {
        val prevDefault = Thread.getDefaultUncaughtExceptionHandler()
        var delegated: Throwable? = null
        Thread.setDefaultUncaughtExceptionHandler { _, e -> delegated = e }
        val store = CrashStore(tmp())
        val undo = CrashHandler.install(store)
        try {
            val first = Thread.getDefaultUncaughtExceptionHandler()
            val noop = CrashHandler.install(store)
            assertTrue("cài lần hai không được bọc chồng", first === Thread.getDefaultUncaughtExceptionHandler())
            noop()                                                      // lần cài thứ hai không làm gì
            val h = Thread.getDefaultUncaughtExceptionHandler()
            assertTrue(first === h)
            assertTrue(h is CrashHandler.Hook)
            h.uncaughtException(Thread.currentThread(), IllegalArgumentException("bắt được"))
            assertTrue(store.peek()!!.contains("IllegalArgumentException: bắt được"))
            assertEquals("bắt được", delegated?.message)               // bộ xử lý cũ của hệ thống vẫn chạy (app vẫn đóng như thường)
        } finally {
            undo()
            Thread.setDefaultUncaughtExceptionHandler(prevDefault)
        }
        assertFalse(Thread.getDefaultUncaughtExceptionHandler() is CrashHandler.Hook)
    }

    @Test fun handlerStillDelegatesWhenSaveFails() {
        val prevDefault = Thread.getDefaultUncaughtExceptionHandler()
        var delegated = false
        Thread.setDefaultUncaughtExceptionHandler { _, _ -> delegated = true }
        val f = File.createTempFile("notadir", "x")
        val undo = CrashHandler.install(CrashStore(File(f, "sub")))
        try {
            Thread.getDefaultUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), RuntimeException("x"))
            assertTrue(delegated)
        } finally {
            undo(); Thread.setDefaultUncaughtExceptionHandler(prevDefault)
        }
    }

    // ------------------------------------------------------------ ApplicationExitInfo
    @Test fun abnormalReasonsAreTheOnesTesterShouldHearAbout() {
        for (r in listOf(2, 3, 4, 5, 6, 7, 9, 12, 14)) assertTrue("reason $r", DiagReport.isAbnormal(r))
        for (r in listOf(0, 1, 8, 10, 11, 13, 15, 16)) assertFalse("reason $r", DiagReport.isAbnormal(r))   // vuốt tắt, tự thoát, cài bản mới... là bình thường
        assertEquals("LOW_MEMORY", DiagReport.reasonName(3)); assertEquals("REASON_99", DiagReport.reasonName(99))
    }

    @Test fun visibilityThresholdSeparatesForegroundFromBackground() {
        assertTrue(DiagReport.wasVisible(100)); assertTrue(DiagReport.wasVisible(230)); assertTrue(DiagReport.wasVisible(125))
        assertFalse(DiagReport.wasVisible(300)); assertFalse(DiagReport.wasVisible(400)); assertFalse(DiagReport.wasVisible(0))
    }

    @Test fun pickUnseenReturnsNewestAbnormalVisibleAfterSeenMark() {
        val old = ExitRecord(3, 100, 1000)
        val newer = ExitRecord(5, 100, 3000)
        val bg = ExitRecord(3, 400, 4000)            // bị tắt lúc chạy nền: không quấy rầy
        val normal = ExitRecord(10, 100, 5000)       // vuốt tắt
        val all = listOf(old, newer, bg, normal)
        assertEquals(newer, DiagReport.pickUnseen(all, 0))
        assertEquals(5000L, DiagReport.latestTs(all))
        assertNull(DiagReport.pickUnseen(all, 3000))                 // đã báo đến mốc 3000: không báo lại
        assertEquals(old, DiagReport.pickUnseen(listOf(old, normal), 999))
        assertNull(DiagReport.pickUnseen(emptyList(), 0)); assertEquals(0L, DiagReport.latestTs(emptyList()))
    }

    @Test fun explanationsAreGivenForActionableReasons() {
        assertTrue(DiagReport.explainExit(3).contains("thiếu bộ nhớ"))
        assertTrue(DiagReport.explainExit(5).contains("native"))
        assertTrue(DiagReport.explainExit(6).contains("treo"))
        assertEquals("", DiagReport.explainExit(10))
    }

    @Test fun describeExitIncludesReasonImportanceAndMemory() {
        val d = DiagReport.describeExit(ExitRecord(3, 400, 1_700_000_000_000L, 1_048_576, 2_097_152, "lmkd kill"))
        assertTrue(d, d.contains("LOW_MEMORY")); assertTrue(d, d.contains("chạy nền")); assertTrue(d, d.contains("pss 1024 MB"))
        assertTrue(d, d.contains("rss 2048 MB")); assertTrue(d, d.contains("lmkd kill"))
        assertNotNull(DiagReport.describeExit(ExitRecord(0, 0, 0)))
    }
}
