package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.billing.BILLING_PRODUCTS
import com.aiphoto.studio.billing.accountHash
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.PlanJson
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.mergeOps
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.RecipeCodec
import com.aiphoto.studio.engine.FaceLiquify
import com.aiphoto.studio.engine.FilterFx
import com.aiphoto.studio.engine.MaskMath
import com.aiphoto.studio.engine.MeshWarp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Kiểm thử R10: Filter Gallery, Colorize, mặt nạ theo kênh / Focus, Warp lưới, Liquify khuôn mặt, planner Tóc. */
class R10Test {

    private fun argb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun red(p: Int) = (p shr 16) and 255
    private fun grn(p: Int) = (p shr 8) and 255
    private fun blu(p: Int) = p and 255

    // ------------------------------------------------------------------ Filter Gallery
    @Test fun posterizeLevels() {
        assertEquals(16, FilterFx.posterLevels(0f))
        assertEquals(2, FilterFx.posterLevels(1f))
        val px = IntArray(256) { argb(it, it, it) }
        val out = FilterFx.posterize(px, 1f)
        assertEquals(2, out.map { red(it) }.toSet().size)
        assertTrue(out.all { (it ushr 24) == 255 })
    }

    @Test fun pixelateBlocksAreUniform() {
        val w = 40
        val h = 40
        val px = IntArray(w * h) { argb((it * 7) % 256, (it * 13) % 256, (it * 29) % 256) }
        val bs = FilterFx.pixelBlock(w, h, 1f)
        assertEquals(2, bs)
        val out = FilterFx.pixelate(px, w, h, 1f)
        assertEquals(out[0], out[1])
        assertEquals(out[0], out[w])
        assertEquals(out[0], out[w + 1])
    }

    @Test fun duotoneEndpoints() {
        val out = FilterFx.duotone(intArrayOf(argb(0, 0, 0), argb(255, 255, 255)), 1f, null)
        assertEquals(argb(0x20, 0x12, 0x4D), out[0])
        assertEquals(argb(0xF6, 0xC1, 0x77), out[1])
        val custom = FilterFx.duotone(intArrayOf(argb(0, 0, 0)), 1f, "#FF0000,#00FF00")
        assertEquals(argb(255, 0, 0), custom[0])
        val none = FilterFx.duotone(intArrayOf(argb(90, 80, 70)), 0f, null)
        assertEquals(argb(90, 80, 70), none[0])
    }

    @Test fun embossSketchFlatAreas() {
        val w = 30
        val h = 30
        val flat = IntArray(w * h) { argb(90, 90, 90) }
        assertTrue(abs(red(FilterFx.emboss(flat, w, h, 1f)[15 * w + 15]) - 128) <= 1)
        assertTrue(red(FilterFx.sketch(flat, w, h, 1f)[15 * w + 15]) >= 250)
    }

    @Test fun glowNeverDarkens() {
        val w = 40
        val h = 40
        val px = IntArray(w * h) { argb((it * 5) % 256, (it * 11) % 256, (it * 3) % 256) }
        val out = FilterFx.glow(px, w, h, 0.8f)
        for (i in px.indices) assertTrue(red(out[i]) >= red(px[i]) - 1 && blu(out[i]) >= blu(px[i]) - 1)
    }

    @Test fun chromaCenterStaysAndIdentityAtZero() {
        val w = 41
        val h = 31
        val px = IntArray(w * h) { argb((it * 5) % 256, (it * 11) % 256, (it * 3) % 256) }
        assertTrue(FilterFx.chroma(px, w, h, 0f).contentEquals(px))
        val out = FilterFx.chroma(px, w, h, 1f)
        val c = (h / 2) * w + w / 2
        assertEquals(px[c], out[c])
    }

    @Test fun matteLiftsBlackKeepsWhite() {
        val out = FilterFx.matte(intArrayOf(argb(0, 0, 0), argb(255, 255, 255)), 1f)
        assertEquals(36, red(out[0]))
        assertEquals(255, red(out[1]))
    }

    @Test fun colorizeSetsTargetHueKeepsOrder() {
        val target = 0xC81E1E // đỏ
        val dark = FilterFx.colorize(intArrayOf(argb(40, 30, 25)), target, 1f)[0]
        assertTrue(red(dark) > grn(dark) + 40 && abs(grn(dark) - blu(dark)) <= 2)
        val none = FilterFx.colorize(intArrayOf(argb(40, 30, 25)), target, 0f)[0]
        assertEquals(argb(40, 30, 25), none)
        val g = intArrayOf(argb(10, 10, 10), argb(60, 60, 60), argb(120, 120, 120), argb(200, 200, 200))
        val l = FilterFx.colorize(g, target, 1f).map { FilterFx.rgbToHsl(red(it), grn(it), blu(it))[2] }
        assertEquals(l.sorted(), l)
        assertEquals(0xFF, FilterFx.hexRgb("#00FF00", 0) and 0xFF00 shr 8)
        assertEquals(7, FilterFx.hexRgb("oops", 7))
    }

    // ------------------------------------------------------------------ sanitize / merge cho phép mới
    @Test fun newOpsSanitizeAndMerge() {
        assertNull(EditOp(OpType.COLORIZE, 0.8f, null).sanitized())
        assertNull(EditOp(OpType.COLORIZE, 0.8f, "red").sanitized())
        assertEquals("#6B4423", EditOp(OpType.COLORIZE, 0.8f, "#6b4423").sanitized()!!.arg)
        assertNull(EditOp(OpType.COLORIZE, 0.005f, "#6B4423").sanitized())
        assertNull(EditOp(OpType.DUOTONE, 0f, null).sanitized())
        assertNull(EditOp(OpType.DUOTONE, 0.9f, "#112233").sanitized()!!.arg) // thiếu màu sáng -> dùng mặc định
        assertEquals("#112233,#AABBCC", EditOp(OpType.DUOTONE, 0.9f, "#112233, #aabbcc").sanitized()!!.arg)
        assertNotNull(EditOp(OpType.GLOW, 0.5f, null).sanitized())
        assertNull(EditOp(OpType.POSTERIZE, 0.001f, null).sanitized())
        val merged = mergeOps(listOf(EditOp(OpType.COLORIZE, 0.5f, "#FF0000"), EditOp(OpType.COLORIZE, 0.7f, "#0000FF")))
        assertEquals(1, merged.size)
        assertEquals("#0000FF", merged[0].arg) // hai màu khác nhau: lấy phép sau cùng, không cộng
    }

    // ------------------------------------------------------------------ Mặt nạ theo kênh / Focus
    @Test fun labMatchesKnownValues() {
        val white = MaskMath.rgbToLab(255, 255, 255)
        assertEquals(100f, white[0], 0.2f)
        assertEquals(0f, white[1], 0.3f)
        val red = MaskMath.rgbToLab(255, 0, 0) // CIE Lab D65: L≈53.24, a≈80.09, b≈67.20
        assertEquals(53.24f, red[0], 0.3f)
        assertEquals(80.09f, red[1], 0.5f)
        assertEquals(67.20f, red[2], 0.5f)
    }

    @Test fun channelMaskSelectsByRange() {
        val w = 20
        val h = 4
        val px = IntArray(w * h) { if (it % w < 10) argb(220, 30, 30) else argb(30, 30, 220) }
        val m = MaskMath.channelMask(px, MaskMath.SPACE_RGB, 0, 0.6f, 1f)
        assertTrue(m[0] > 0.99f && m[15] < 0.01f)
        val hsvS = MaskMath.channelMask(px, MaskMath.SPACE_HSV, 1, 0.5f, 1f)
        assertTrue(hsvS.all { it > 0.95f })
        assertEquals(1f / 3f, MaskMath.channelValue(argb(0, 255, 0), MaskMath.SPACE_HSV, 0), 0.01f) // H(xanh lục) = 120° -> 0.333
    }

    @Test fun focusMaskSharpVsFlat() {
        val w = 120
        val h = 80
        val px = IntArray(w * h) { i ->
            val x = i % w
            if (x < 60) { val v = ((i * 2654435761L) ushr 8).toInt() and 255; argb(v, v, v) } else argb(120, 120, 120)
        }
        val m = MaskMath.focusMask(px, w, h, 0.35f, 1f)
        var sharp = 0f
        var flat = 0f
        for (y in 0 until h) { for (x in 5 until 50) sharp += m[y * w + x]; for (x in 75 until 115) flat += m[y * w + x] }
        assertTrue(sharp / (h * 45) > 0.8f)
        assertTrue(flat / (h * 40) < 0.05f)
    }

    @Test fun channelAndFocusMasksSurviveRecipeCodec() {
        for (spec in listOf(MaskSpec.Channel(MaskMath.SPACE_LAB, 1, 0.58f, 1f), MaskSpec.Focus(0.35f, 1f))) {
            val layer = AdjustmentLayer(7L, "t", listOf(EditOp(OpType.BRIGHTNESS, 0.2f)), mask = LayerMask(spec))
            assertTrue(RecipeCodec.portable(layer))
            val back = RecipeCodec.decode(RecipeCodec.encode(listOf(layer)))
            assertEquals(1, back.size)
            assertEquals(spec, back[0].mask!!.spec)
        }
    }

    // ------------------------------------------------------------------ Warp lưới
    @Test fun meshParseEncodeAndIdentity() {
        val id = MeshWarp.identity(4, 4)
        assertTrue(MeshWarp.isIdentity(id))
        assertEquals(50, id.d.size)
        val moved = MeshWarp.moved(id, 2, 2, 0.1f, -0.05f)
        assertFalse(MeshWarp.isIdentity(moved))
        val back = MeshWarp.parse(MeshWarp.encode(moved))!!
        assertEquals(0.1f, back.d[2 * (2 * 5 + 2)], 1e-3f)
        assertNull(MeshWarp.parse("4,4;1,2,3"))
        assertNull(MeshWarp.parse("99,4;0"))
        assertNull(EditOp(OpType.MESH_WARP, 1f, MeshWarp.encode(id)).sanitized())
        assertNotNull(EditOp(OpType.MESH_WARP, 1f, MeshWarp.encode(moved)).sanitized())
    }

    @Test fun meshWarpZeroIsIdentityAndShiftMovesContent() {
        val w = 60
        val h = 40
        val px = IntArray(w * h) { i -> val x = i % w; argb(x * 4 % 256, (i / w) * 6 % 256, 100) }
        assertTrue(MeshWarp.warp(px, w, h, MeshWarp.identity(4, 4)).contentEquals(px))
        val m = MeshWarp.identity(4, 4)
        val shifted = MeshWarp.Mesh(4, 4, FloatArray(m.d.size) { if (it % 2 == 0) 0.1f else 0f })
        val out = MeshWarp.warp(px, w, h, shifted)
        val sh = 6 // 0.1 * 60
        for (x in sh + 2 until w - 2) assertTrue(abs(red(px[20 * w + x - sh]) - red(out[20 * w + x])) <= 4)
    }

    // ------------------------------------------------------------------ Liquify theo khuôn mặt
    private fun syntheticFace(): FloatArray {
        val lm = FloatArray(2 * 478)
        val oval = intArrayOf(10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109)
        for ((k, i) in oval.withIndex()) {
            val t = (-90 + 10 * k) * PI / 180.0
            lm[2 * i] = (0.5 + 0.20 * cos(t)).toFloat(); lm[2 * i + 1] = (0.5 + 0.28 * sin(t)).toFloat()
        }
        val right = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
        val left = intArrayOf(263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249)
        for ((k, i) in right.withIndex()) { val t = (180 + 22.5 * k) * PI / 180.0; lm[2 * i] = (0.40 + 0.05 * cos(t)).toFloat(); lm[2 * i + 1] = (0.42 + 0.02 * sin(t)).toFloat() }
        for ((k, i) in left.withIndex()) { val t = (0 - 22.5 * k) * PI / 180.0; lm[2 * i] = (0.60 + 0.05 * cos(t)).toFloat(); lm[2 * i + 1] = (0.42 + 0.02 * sin(t)).toFloat() }
        lm[2 * 129] = 0.46f; lm[2 * 129 + 1] = 0.56f; lm[2 * 358] = 0.54f; lm[2 * 358 + 1] = 0.56f
        lm[2 * 61] = 0.43f; lm[2 * 61 + 1] = 0.68f; lm[2 * 291] = 0.57f; lm[2 * 291 + 1] = 0.68f
        return lm
    }

    @Test fun faceLiquifyArgsAreWellFormed() {
        val lm = syntheticFace()
        assertEquals("", FaceLiquify.args(lm, 800, 1000, 0f, 0f, 0f, 0f))
        assertEquals("", FaceLiquify.args(FloatArray(10), 800, 1000, 1f, 1f, 1f, 1f))
        val arg = FaceLiquify.args(lm, 800, 1000, 1f, 0f, 0f, 0f)
        val segs = arg.split(';')
        assertEquals(18, segs.size) // 9 điểm hàm mỗi bên
        for (s in segs) {
            val f = s.split(',').map { it.toFloat() }
            assertEquals(5, f.size)
            assertTrue(f[4] > 0f && abs(f[2]) < 0.05f && abs(f[3]) < 0.05f)
        }
        // điểm hàm bên ảnh phải (x > 0.5) bị đẩy sang TRÁI (dx < 0), bên ảnh trái bị đẩy sang PHẢI (dx > 0)
        val perSide = segs.map { it.split(',').map { v -> v.toFloat() } }
        assertTrue(perSide.filter { it[0] > 0.5f }.all { it[2] < 0f })
        assertTrue(perSide.filter { it[0] < 0.5f }.all { it[2] > 0f })
        assertEquals(8 + 8, FaceLiquify.args(lm, 800, 1000, 0f, 1f, 0f, 0f).split(';').size)
        assertNotNull(EditOp(OpType.LIQUIFY, 1f, arg).sanitized())
    }

    // ------------------------------------------------------------------ Planner: Tóc + Filter Gallery
    @Test fun plannerHairColor() {
        val plan = RuleBasedPlanner.plan("nhuộm tóc màu nâu")
        assertEquals(1, plan.scoped.size)
        assertEquals(Scope.HAIR, plan.scoped[0].scope)
        val op = plan.scoped[0].ops[0]
        assertEquals(OpType.COLORIZE, op.type)
        assertEquals("#6B4423", op.arg)
        val blonde = RuleBasedPlanner.plan("Đổi màu tóc thành vàng")
        assertEquals("#D8B25A", blonde.scoped.first().ops[0].arg)
        val blue = RuleBasedPlanner.plan("hair blue")
        assertEquals("#2D6CDF", blue.scoped.first().ops[0].arg)
        val shine = RuleBasedPlanner.plan("tóc bóng mượt")
        assertEquals(Scope.HAIR, shine.scoped.first().scope)
    }

    @Test fun plannerFilterGallery() {
        assertTrue(RuleBasedPlanner.plan("phác họa bút chì").ops.any { it.type == OpType.SKETCH })
        assertTrue(RuleBasedPlanner.plan("pixel hóa").ops.any { it.type == OpType.PIXELATE })
        assertTrue(RuleBasedPlanner.plan("hiệu ứng phát sáng").ops.any { it.type == OpType.GLOW })
        assertTrue(RuleBasedPlanner.plan("matte").ops.any { it.type == OpType.MATTE })
        assertTrue(RuleBasedPlanner.plan("posterize mạnh").ops.any { it.type == OpType.POSTERIZE })
    }

    @Test fun llmJsonAcceptsHairColorize() {
        val p = PlanJson.parseFull("""{"ops":[{"op":"colorize","value":0.85,"arg":"#6B4423","scope":"hair"}]}""")!!
        assertEquals(Scope.HAIR, p.scoped[0].scope)
        assertEquals(OpType.COLORIZE, p.scoped[0].ops[0].type)
        assertTrue(Scope.HAIR in Scope.ALL)
        assertFalse(Scope.needsFace(Scope.HAIR))
        assertEquals("Tóc", Scope.label(Scope.HAIR))
    }

    // ------------------------------------------------------------------ Thanh toán: mã tài khoản phải trùng backend/server.py account_hash
    @Test fun accountHashMatchesBackend() {
        // python3: hashlib.sha256(b"device-12345678").hexdigest()[:32]
        assertEquals("15ff1f3285f342871079a4469c65640d", accountHash("device-12345678"))
        assertEquals(32, accountHash("x").length)
        assertTrue("pro_30d" in BILLING_PRODUCTS && "credits_20" in BILLING_PRODUCTS)
    }
}
