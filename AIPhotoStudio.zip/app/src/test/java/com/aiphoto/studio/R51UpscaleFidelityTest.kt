package com.aiphoto.studio

import com.aiphoto.studio.engine.UpscaleCancelled
import com.aiphoto.studio.engine.UpscaleFidelity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.math.abs

/** R51: hiệu chỉnh nhất quán + thanh "Độ trung thực" của Phóng to AI. Giá trị chuẩn lấy từ bản port tools/verify_ports/upscale_fidelity.py. */
class R51UpscaleFidelityTest {
    private fun rgb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun ch(p: Int, c: Int) = (p shr (16 - 8 * c)) and 255

    private fun synthLr(w: Int, h: Int) = IntArray(w * h) { i ->
        val x = i % w; val y = i / w
        rgb((x * 53 + y * 97 + x * y * 7) % 256, (x * 29 + y * 61 + 40) % 256, (x * 11 + y * 131 + x * y * 3 + 90) % 256)
    }
    private fun synthSr(w: Int, h: Int) = IntArray(w * h) { i ->
        val x = i % w; val y = i / w
        rgb((x * 31 + y * 17 + ((x * y) % 13) * 11) % 256, (x * 7 + y * 43 + ((x + y) % 5) * 23) % 256, (x * 19 + y * 5 + ((x * 3 + y) % 7) * 17) % 256)
    }
    private fun sum(a: IntArray): Long = a.sumOf { (ch(it, 0) + ch(it, 1) + ch(it, 2)).toLong() }
    private fun near(exp: IntArray, p: Int, tol: Int = 2) { for (c in 0..2) assertTrue("kênh $c: ${ch(p, c)} vs ${exp[c]}", abs(ch(p, c) - exp[c]) <= tol) }

    @Test fun goldenValuesMatchPythonPort() {
        val expect = listOf(
            Triple(0.0f, 176682L, listOf(intArrayOf(0, 0, 0), intArrayOf(50, 225, 185), intArrayOf(0, 29, 255))),
            Triple(0.15f, 176700L, listOf(intArrayOf(0, 5, 12), intArrayOf(68, 220, 192), intArrayOf(0, 52, 251))),
            Triple(0.6f, 176660L, listOf(intArrayOf(0, 20, 48), intArrayOf(122, 203, 212), intArrayOf(1, 119, 240)))
        )
        for ((f, s, px) in expect) {
            val out = synthSr(24, 20)
            assertTrue(UpscaleFidelity.refine(out, 24, 20, synthLr(6, 5), 6, 5, f))
            assertTrue("tổng ${sum(out)} vs $s (f=$f)", abs(sum(out) - s) <= 60)
            near(px[0], out[0]); near(px[1], out[7 * 24 + 9]); near(px[2], out[19 * 24 + 23])
        }
    }

    @Test fun consistencyMakesDownscaleMatchInput() {
        val lr = synthLr(8, 8)
        val out = synthSr(32, 32)
        fun err(o: IntArray): Double { // sai số trung bình của (trung bình ô 4×4) so với ảnh vào
            var e = 0.0
            for (y in 0 until 8) for (x in 0 until 8) for (c in 0..2) {
                var s = 0
                for (dy in 0 until 4) for (dx in 0 until 4) s += ch(o[(y * 4 + dy) * 32 + x * 4 + dx], c)
                e += abs(s / 16.0 - ch(lr[y * 8 + x], c))
            }
            return e / (8 * 8 * 3)
        }
        val before = err(out)
        UpscaleFidelity.refine(out, 32, 32, lr, 8, 8, 0f)
        assertTrue("trước $before sau ${err(out)}", err(out) < before * 0.5)
    }

    @Test fun perfectSrIsUnchangedAtZeroFidelity() {
        val lr = IntArray(16) { rgb(100, 150, 200) }
        val out = IntArray(256) { rgb(100, 150, 200) }
        UpscaleFidelity.refine(out, 16, 16, lr, 4, 4, 0f)
        assertTrue(out.all { it == rgb(100, 150, 200) })
        UpscaleFidelity.refine(out, 16, 16, lr, 4, 4, 0.6f)      // phẳng thì trộn nội suy cũng không đổi
        assertTrue(out.all { it == rgb(100, 150, 200) })
    }

    @Test fun mismatchedSizesAreLeftAlone() {
        val out = synthSr(25, 20)
        val copy = out.copyOf()
        assertFalse(UpscaleFidelity.refine(out, 25, 20, synthLr(6, 5), 6, 5, 0.3f))
        assertTrue(out.contentEquals(copy))
        assertEquals(0, UpscaleFidelity.ratio(24, 20, 6, 4))
        assertEquals(4, UpscaleFidelity.ratio(24, 20, 6, 5))
        assertEquals(0, UpscaleFidelity.ratio(6, 5, 6, 5))
    }

    @Test fun clampAndWeights() {
        assertEquals(0f, UpscaleFidelity.clamp(-1f), 0f)
        assertEquals(UpscaleFidelity.MAX_BLEND, UpscaleFidelity.clamp(9f), 0f)
        assertEquals(UpscaleFidelity.DEFAULT, UpscaleFidelity.clamp(Float.NaN), 0f)
        val w = FloatArray(4)
        for (t in listOf(0f, 0.25f, 0.5f, 0.99f)) { UpscaleFidelity.catmullRom(t, w, 0); assertEquals(1f, w.sum(), 1e-5f) }
        UpscaleFidelity.catmullRom(0f, w, 0); assertEquals(1f, w[1], 0f)
    }

    @Test fun higherFidelityMovesTowardBicubicOfInput() {
        val lr = synthLr(6, 5)
        val a = synthSr(24, 20); val b = synthSr(24, 20)
        UpscaleFidelity.refine(a, 24, 20, lr, 6, 5, 0f)
        UpscaleFidelity.refine(b, 24, 20, lr, 6, 5, 0.6f)
        assertFalse(a.contentEquals(b))
    }

    @Test fun cancelThrows() {
        try {
            UpscaleFidelity.refine(synthSr(24, 20), 24, 20, synthLr(6, 5), 6, 5, 0.2f, isCancelled = { true })
            fail("phải ném UpscaleCancelled")
        } catch (e: UpscaleCancelled) { }
    }

    @Test fun nonSquareAndOtherScale() {
        val out = synthSr(18, 12); val lr = synthLr(6, 4)   // k = 3
        assertTrue(UpscaleFidelity.refine(out, 18, 12, lr, 6, 4, 0.2f))
        assertTrue(out.all { ch(it, 0) in 0..255 && (it ushr 24) == 255 })
    }
}
