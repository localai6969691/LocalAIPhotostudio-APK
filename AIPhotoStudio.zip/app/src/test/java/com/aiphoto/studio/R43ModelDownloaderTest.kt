package com.aiphoto.studio

import com.aiphoto.studio.models.ModelDownloader
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.nio.file.Files
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/** R43: bộ tải model — chạy với máy chủ HTTP cục bộ: tải đủ, tiếp tục từ .part, máy chủ bỏ qua Range, sai SHA-256, địa chỉ dự phòng, hủy, thiếu dung lượng. */
class R43ModelDownloaderTest {
    private lateinit var server: HttpServer
    private lateinit var dir: File
    private val data = ByteArray(600_000) { (it * 31 + 7).toByte() }
    private val wrong = ByteArray(600_000) { (it * 17 + 3).toByte() }
    private val sha = hex(data)
    private val hits = AtomicInteger()
    private val ranges = CopyOnWriteArrayList<String>()

    private fun hex(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
    private fun url(p: String) = "http://127.0.0.1:${server.address.port}$p"
    private fun dl() = ModelDownloader(allowHttp = true, spaceMarginBytes = 1L shl 20)

    private fun serve(ex: HttpExchange, body: ByteArray, range: Boolean, slow: Boolean = false) {
        try {
            hits.incrementAndGet()
            val rh = ex.requestHeaders.getFirst("Range")
            if (rh != null) ranges.add(rh)
            var start = 0
            var code = 200
            if (range && rh != null) {
                start = Regex("bytes=(\\d+)-").find(rh)!!.groupValues[1].toInt()
                code = 206
                ex.responseHeaders.add("Content-Range", "bytes $start-${body.size - 1}/${body.size}")
            }
            ex.sendResponseHeaders(code, (body.size - start).toLong())
            ex.responseBody.use { out ->
                var off = start
                while (off < body.size) {
                    val n = minOf(32_768, body.size - off)
                    out.write(body, off, n); out.flush(); off += n
                    if (slow) Thread.sleep(25)
                }
            }
        } catch (e: IOException) { /* máy khách ngắt kết nối (hủy) — bình thường */ }
    }

    @Before fun up() {
        dir = Files.createTempDirectory("r43dl").toFile()
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/ok") { serve(it, data, range = true) }
        server.createContext("/norange") { serve(it, data, range = false) }
        server.createContext("/bad") { serve(it, wrong, range = true) }
        server.createContext("/slow") { serve(it, data, range = true, slow = true) }
        server.createContext("/missing") { it.sendResponseHeaders(404, -1); it.close() }
        server.start()
    }

    @After fun down() { server.stop(0); dir.deleteRecursively() }

    @Test fun fullDownloadVerifiesAndLeavesNoPartFile() {
        val dest = File(dir, "m.onnx")
        val progress = ArrayList<Long>()
        val r = dl().download(listOf(url("/ok")), dest, data.size.toLong(), sha, onProgress = { d, _ -> progress.add(d) })
        assertTrue(r.ok); assertArrayEquals(data, dest.readBytes())
        assertFalse(File(dest.path + ".part").exists())
        assertEquals(data.size.toLong(), progress.last())
    }

    @Test fun resumesFromPartialFileWithRangeHeader() {
        val dest = File(dir, "m.onnx")
        File(dest.path + ".part").writeBytes(data.copyOf(200_000))
        val r = dl().download(listOf(url("/ok")), dest, data.size.toLong(), sha)
        assertTrue(r.ok); assertArrayEquals(data, dest.readBytes())
        assertEquals(listOf("bytes=200000-"), ranges.toList())
    }

    @Test fun serverIgnoringRangeRestartsFromZero() {
        val dest = File(dir, "m.onnx")
        File(dest.path + ".part").writeBytes(data.copyOf(100_000))
        val r = dl().download(listOf(url("/norange")), dest, data.size.toLong(), sha)
        assertTrue(r.ok); assertArrayEquals(data, dest.readBytes())
    }

    @Test fun wrongBytesAreRejectedAndNothingIsLeft() {
        val dest = File(dir, "m.onnx")
        val r = dl().download(listOf(url("/bad")), dest, wrong.size.toLong(), sha)
        assertFalse(r.ok); assertEquals(ModelDownloader.Err.SHA256, r.err)
        assertFalse(dest.exists()); assertFalse(File(dest.path + ".part").exists())
    }

    @Test fun fallsBackToNextUrlAfterHttpErrorOrBadHash() {
        val dest = File(dir, "m.onnx")
        val r = dl().download(listOf(url("/missing"), url("/bad"), url("/ok")), dest, data.size.toLong(), sha)
        assertTrue(r.ok); assertArrayEquals(data, dest.readBytes())
    }

    @Test fun allUrlsFailReportsLastError() {
        val r = dl().download(listOf(url("/missing")), File(dir, "m.onnx"), data.size.toLong(), sha)
        assertFalse(r.ok); assertEquals(ModelDownloader.Err.HTTP, r.err); assertEquals("HTTP 404", r.detail)
    }

    @Test fun cancelKeepsPartialFileThenResumeCompletes() {
        val dest = File(dir, "m.onnx")
        var cancel = false
        val r1 = dl().download(listOf(url("/slow")), dest, data.size.toLong(), sha, isCancelled = { cancel }, onProgress = { _, _ -> cancel = true })
        assertEquals(ModelDownloader.Err.CANCELLED, r1.err)
        val part = File(dest.path + ".part")
        assertTrue("giữ .part để tiếp tục", part.exists() && part.length() in 1 until data.size.toLong())
        assertFalse(dest.exists())
        val r2 = dl().download(listOf(url("/ok")), dest, data.size.toLong(), sha)
        assertTrue(r2.ok); assertArrayEquals(data, dest.readBytes())
        assertTrue("lần 2 phải gửi Range", ranges.isNotEmpty())
    }

    @Test fun notEnoughFreeSpaceIsReportedBeforeDownloading() {
        val r = dl().download(listOf(url("/ok")), File(dir, "m.onnx"), Long.MAX_VALUE / 4, sha)
        assertEquals(ModelDownloader.Err.SPACE, r.err); assertEquals(0, hits.get())
    }

    @Test fun existingCorrectFileIsNotDownloadedAgain() {
        val dest = File(dir, "m.onnx"); dest.writeBytes(data)
        val r = dl().download(listOf(url("/ok")), dest, data.size.toLong(), sha)
        assertTrue(r.ok); assertEquals(0, hits.get())
    }

    @Test fun plainHttpIsRefusedByDefault() {
        val r = ModelDownloader().download(listOf(url("/ok")), File(dir, "m.onnx"), data.size.toLong(), sha)
        assertEquals(ModelDownloader.Err.HTTP, r.err); assertEquals(0, hits.get()); assertNotNull(r.detail)
    }

    @Test fun shortBodyKeepsPartForLaterResume() {
        val dest = File(dir, "m.onnx")
        // máy chủ báo đủ nhưng kích thước kỳ vọng lớn hơn ⇒ "tải chưa đủ", giữ .part
        val r = dl().download(listOf(url("/ok")), dest, data.size.toLong() + 10, sha)
        assertEquals(ModelDownloader.Err.NETWORK, r.err); assertTrue(File(dest.path + ".part").exists())
    }
}
