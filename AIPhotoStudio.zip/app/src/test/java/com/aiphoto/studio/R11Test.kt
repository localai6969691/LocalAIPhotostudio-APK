package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.PlanJson
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.mergeOps
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.Layer
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.OverlayLayer
import com.aiphoto.studio.doc.ProjectCodec
import com.aiphoto.studio.doc.RecipeCodec
import com.aiphoto.studio.engine.CubeLut
import com.aiphoto.studio.engine.Despeckle
import com.aiphoto.studio.engine.LutStore
import com.aiphoto.studio.engine.ProTone
import com.aiphoto.studio.engine.SkyFx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs

/** Kiểm thử R11: tông chuyên nghiệp (Vùng sáng/Vibrance/Tint/Dehaze/Texture), LUT .cube, planner. */
class R11Test {

    private fun argb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun red(p: Int) = (p shr 16) and 255
    private fun grn(p: Int) = (p shr 8) and 255
    private fun blu(p: Int) = p and 255
    private fun lum(p: Int) = 0.299f * red(p) + 0.587f * grn(p) + 0.114f * blu(p)

    // ------------------------------------------------------------------ Highlights
    @Test fun highlightLutIsIdentityBelowPivotAndMonotone() {
        for (a in listOf(-1f, -0.5f, 0.5f, 1f)) {
            val lut = ProTone.highlightLut(a)
            for (i in 0..114) assertEquals("a=$a i=$i", i.toFloat(), lut[i], 1e-3f)
            for (i in 1..255) assertTrue("đơn điệu a=$a i=$i", lut[i] - lut[i - 1] >= 0.2f)
        }
        assertEquals(229.5f, ProTone.highlightLut(-1f)[255], 0.5f)
        assertEquals(255f, ProTone.highlightLut(1f)[255], 0.01f)
    }

    @Test fun highlightsRecoverDarkensBrightKeepsHueAndMidtones() {
        val px = intArrayOf(argb(240, 200, 160), argb(100, 90, 80), argb(0, 0, 0))
        val out = ProTone.highlights(px, -1f)
        assertTrue(lum(out[0]) < lum(px[0]) - 8f)
        // giữ tỉ lệ kênh
        val rIn = 240f / (240 + 200 + 160); val rOut = red(out[0]).toFloat() / (red(out[0]) + grn(out[0]) + blu(out[0]))
        assertEquals(rIn, rOut, 0.01f)
        assertEquals(px[1], out[1])
        assertEquals(px[2], out[2])
        assertTrue(out.all { (it ushr 24) == 255 })
        assertTrue(ProTone.highlights(px, 0f) === px)
    }

    @Test fun highlightsBrightenNeverExceeds255() {
        val out = ProTone.highlights(intArrayOf(argb(255, 250, 240)), 1f)[0]
        assertTrue(red(out) <= 255 && red(out) >= grn(out) && grn(out) >= blu(out))
    }

    // ------------------------------------------------------------------ Vibrance / Tint
    @Test fun vibranceKeepsGrayAndBoostsMutedMoreThanVivid() {
        val gray = argb(128, 128, 128)
        assertEquals(gray, ProTone.vibrance(intArrayOf(gray), 1f)[0])
        fun chroma(p: Int) = maxOf(red(p), grn(p), blu(p)) - minOf(red(p), grn(p), blu(p))
        val muted = argb(120, 130, 140)
        val vivid = argb(220, 40, 40)
        val m = ProTone.vibrance(intArrayOf(muted, vivid), 1f)
        val gainMuted = chroma(m[0]).toFloat() / chroma(muted)
        val gainVivid = chroma(m[1]).toFloat() / chroma(vivid)
        assertTrue("nhạt $gainMuted vs rực $gainVivid", gainMuted > gainVivid * 1.5f)
        assertTrue(abs(lum(m[0]) - lum(muted)) <= 2.5f)
    }

    @Test fun vibranceProtectsSkinTone() {
        fun chroma(p: Int) = maxOf(red(p), grn(p), blu(p)) - minOf(red(p), grn(p), blu(p))
        val skin = argb(200, 150, 120)
        val other = argb(120, 150, 200)
        val o = ProTone.vibrance(intArrayOf(skin, other), 1f)
        assertTrue(chroma(o[0]) - chroma(skin) < chroma(o[1]) - chroma(other))
    }

    @Test fun vibranceNegativeNeverFullyGray() {
        val vivid = argb(220, 40, 40)
        val o = ProTone.vibrance(intArrayOf(vivid), -1f)[0]
        val c = maxOf(red(o), grn(o), blu(o)) - minOf(red(o), grn(o), blu(o))
        assertTrue(c in 18..72)
    }

    @Test fun tintDirectionAndLuminance() {
        val mid = argb(128, 128, 128)
        val mag = ProTone.tint(intArrayOf(mid), 1f)[0]
        assertTrue(red(mag) > 128 && blu(mag) > 128 && grn(mag) < 128)
        val grn1 = ProTone.tint(intArrayOf(mid), -1f)[0]
        assertTrue(grn(grn1) > 128 && red(grn1) < 128)
        assertTrue(abs(lum(mag) - 128f) <= 1.5f && abs(lum(grn1) - 128f) <= 1.5f)
    }

    // ------------------------------------------------------------------ Dehaze / Texture
    @Test fun dehazeZeroIsNoOpAndNegativeLowersContrast() {
        val w = 32; val h = 32
        val px = IntArray(w * h) { i -> val v = if ((i / 4) % 2 == 0) 60 else 200; argb(v, v, v + 10) }
        assertTrue(ProTone.dehaze(px, w, h, 0f) === px)
        fun spread(a: IntArray) = a.maxOf { lum(it) } - a.minOf { lum(it) }
        val fog = ProTone.dehaze(px, w, h, -1f)
        assertTrue(spread(fog) < spread(px) * 0.7f)
        assertEquals(px.size, fog.size)
    }

    @Test fun dehazeFlatImageStaysSane() {
        val w = 40; val h = 30
        val px = IntArray(w * h) { argb(200, 200, 200) }
        val o = ProTone.dehaze(px, w, h, 1f)
        assertEquals(px.size, o.size)
        assertTrue(abs(lum(o[0]) - 200f) <= 25f)
    }

    @Test fun dehazeNonMultipleSizeWorks() {
        val w = 97; val h = 131
        val px = IntArray(w * h) { i -> argb((i * 7) % 256, (i * 13) % 256, (i * 29) % 256) }
        assertEquals(w * h, ProTone.dehaze(px, w, h, 0.7f).size)
    }

    @Test fun textureRadiusScalesWithSize() {
        assertEquals(1, ProTone.textureRadius(1024, 768))
        assertEquals(3, ProTone.textureRadius(2048, 1536))
    }

    @Test fun textureAddsAndRemovesDetail() {
        val w = 48; val h = 48
        val rnd = java.util.Random(5)
        val px = IntArray(w * h) { val v = (128 + rnd.nextGaussian() * 12).toInt().coerceIn(0, 255); argb(v, v, v) }
        fun energy(a: IntArray): Double {
            var s = 0.0
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val d = 4 * lum(a[i]) - lum(a[i - 1]) - lum(a[i + 1]) - lum(a[i - w]) - lum(a[i + w])
                s += d * d
            }
            return s
        }
        assertTrue(energy(ProTone.texture(px, w, h, 1f)) > energy(px) * 1.5)
        assertTrue(energy(ProTone.texture(px, w, h, -1f)) < energy(px) * 0.6)
        assertTrue(ProTone.texture(px, w, h, 0f) === px)
    }

    // ------------------------------------------------------------------ LUT .cube
    private fun cubeText(n: Int, extra: String = "", f: (Float, Float, Float) -> FloatArray): String {
        val sb = StringBuilder(extra).append("\nLUT_3D_SIZE $n\n")
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val o = f(r / (n - 1f), g / (n - 1f), b / (n - 1f))
            sb.append(String.format(java.util.Locale.US, "%.6f %.6f %.6f\n", o[0], o[1], o[2]))
        }
        return sb.toString()
    }

    @Test fun cubeIdentityKeepsPixels() {
        val res = CubeLut.parse(cubeText(17, "TITLE \"id\"\n# note") { r, g, b -> floatArrayOf(r, g, b) })
        assertNotNull(res.lut)
        val px = IntArray(500) { argb((it * 37) % 256, (it * 91) % 256, (it * 53) % 256) }
        val out = CubeLut.apply(px, res.lut!!, 1f)
        for (i in px.indices) {
            assertTrue(abs(red(out[i]) - red(px[i])) <= 1 && abs(grn(out[i]) - grn(px[i])) <= 1 && abs(blu(out[i]) - blu(px[i])) <= 1)
        }
    }

    @Test fun cubeChannelOrderIsRedFastest() {
        val res = CubeLut.parse(cubeText(9) { r, g, b -> floatArrayOf(b, g, r) })   // hoán R↔B
        val px = intArrayOf(argb(250, 100, 10), argb(0, 255, 128))
        val out = CubeLut.apply(px, res.lut!!, 1f)
        assertTrue(abs(red(out[0]) - 10) <= 1 && abs(blu(out[0]) - 250) <= 1 && abs(grn(out[0]) - 100) <= 1)
        assertTrue(abs(red(out[1]) - 128) <= 1 && abs(blu(out[1]) - 0) <= 1)
    }

    @Test fun cubeIntensityBlendsAndAlphaKept() {
        val lut = CubeLut.parse(cubeText(9) { r, g, b -> floatArrayOf(b, g, r) }).lut!!
        val px = intArrayOf((77 shl 24) or (200 shl 16) or (100 shl 8) or 0)
        assertTrue(CubeLut.apply(px, lut, 0f) === px)
        val half = CubeLut.apply(px, lut, 0.5f)[0]
        assertEquals(77, half ushr 24)
        assertTrue(abs(red(half) - 100) <= 1 && abs(blu(half) - 100) <= 1)
    }

    @Test fun cubeDomainAppliesToInputOnly() {
        val lut = CubeLut.parse(cubeText(9, "DOMAIN_MIN 0 0 0\nDOMAIN_MAX 2 2 2") { r, g, b -> floatArrayOf(r, g, b) }).lut!!
        val out = CubeLut.apply(intArrayOf(argb(200, 100, 50)), lut, 1f)[0]
        assertTrue(abs(red(out) - 100) <= 1 && abs(grn(out) - 50) <= 1 && abs(blu(out) - 25) <= 1)
    }

    @Test fun cubeRejectsBadInput() {
        assertNull(CubeLut.parse("").lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 1\n0 0 0\n").lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 66\n").lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 2\n" + "0 0 0\n".repeat(7)).lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 2\n" + "0 0 0\n".repeat(9)).lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 2\n" + "0 0 x\n".repeat(8)).lut)
        assertNull(CubeLut.parse("LUT_3D_SIZE 2\n" + "0 NaN 0\n".repeat(8)).lut)
        val oneD = CubeLut.parse("LUT_1D_SIZE 4\n0 0 0\n1 1 1\n")
        assertNull(oneD.lut)
        assertTrue(oneD.error!!.contains("1D"))
        assertNull(CubeLut.parse("LUT_3D_SIZE 2\nDOMAIN_MIN 1 1 1\nDOMAIN_MAX 1 1 1\n" + "0 0 0\n".repeat(8)).lut)
    }

    @Test fun cubeParsesCrlfAndWhitespace() {
        val t = cubeText(5) { r, g, b -> floatArrayOf(r, g, b) }.replace("\n", "\r\n").replace("LUT_3D_SIZE 5", "  LUT_3D_SIZE   5  ")
        assertNotNull(CubeLut.parse(t).lut)
    }

    @Test fun lutStoreSaveGetDeleteAndNameValidation() {
        val dir = File(System.getProperty("java.io.tmpdir"), "luts_test_${System.nanoTime()}").apply { mkdirs() }
        try {
            LutStore.dir = dir
            assertTrue(LutStore.isValidName("Warm Film_1.cube"))
            assertFalse(LutStore.isValidName("../evil.cube"))
            assertFalse(LutStore.isValidName("a.txt"))
            assertFalse(LutStore.isValidName(null))
            assertEquals("Teal Orange.cube", LutStore.sanitizeName("Teal Orange.cube"))
            assertEquals("a_b_.cube", LutStore.sanitizeName("a/b?.CUBE"))
            val good = cubeText(5) { r, g, b -> floatArrayOf(r, g, b) }
            val (name, err) = LutStore.save("my look.cube", good)
            assertEquals("my look.cube", name)
            assertNull(err)
            assertNotNull(LutStore.get("my look.cube"))
            assertEquals(listOf("my look.cube"), LutStore.list())
            val (n2, e2) = LutStore.save("bad.cube", "garbage")
            assertNull(n2)
            assertNotNull(e2)
            assertNull(LutStore.get("../etc/passwd"))
            LutStore.delete("my look.cube")
            assertNull(LutStore.get("my look.cube"))
            assertTrue(LutStore.list().isEmpty())
        } finally {
            LutStore.dir = null
            dir.deleteRecursively()
        }
    }

    // ------------------------------------------------------------------ OpType / sanitize / planner
    @Test fun newOpsSanitizeAndMerge() {
        for (t in listOf(OpType.HIGHLIGHTS, OpType.VIBRANCE, OpType.TINT, OpType.DEHAZE, OpType.TEXTURE)) {
            assertTrue(t.signed && t.scalable)
            assertEquals(-1f, EditOp(t, -3f).sanitized()!!.value, 1e-6f)
            assertEquals(1f, EditOp(t, 3f).sanitized()!!.value, 1e-6f)
            assertNull(EditOp(t, 0.004f).sanitized())
            assertEquals(OpType.fromKey(t.key), t)
        }
        assertNull(EditOp(OpType.LUT, 1f, "../x.cube").sanitized())
        assertNull(EditOp(OpType.LUT, 1f, null).sanitized())
        assertNull(EditOp(OpType.LUT, 0f, "a.cube").sanitized())
        assertEquals(0.6f, EditOp(OpType.LUT, 0.6f, "a.cube").sanitized()!!.value, 1e-6f)
        val m = mergeOps(listOf(EditOp(OpType.LUT, 1f, "a.cube"), EditOp(OpType.LUT, 0.5f, "b.cube")))
        assertEquals(1, m.size)
        assertEquals("b.cube", m[0].arg)
        val sum = mergeOps(listOf(EditOp(OpType.HIGHLIGHTS, -0.2f), EditOp(OpType.HIGHLIGHTS, -0.3f)))
        assertEquals(-0.5f, sum[0].value, 1e-6f)
    }

    private fun ops(prompt: String) = RuleBasedPlanner.plan(prompt).ops

    @Test fun plannerHighlightsDehazeVibranceTintTexture() {
        assertTrue(ops("giảm vùng sáng").any { it.type == OpType.HIGHLIGHTS && it.value < 0 })
        assertTrue(ops("giảm vùng sáng").none { it.type == OpType.BRIGHTNESS })
        assertTrue(ops("hạ vùng sáng").any { it.type == OpType.HIGHLIGHTS && it.value < 0 })
        assertTrue(ops("ảnh bị cháy sáng").any { it.type == OpType.HIGHLIGHTS && it.value < 0 })
        assertTrue(ops("khử sương mù").any { it.type == OpType.DEHAZE && it.value > 0 })
        assertTrue(ops("ảnh bị mờ sương").let { o -> o.any { it.type == OpType.DEHAZE && it.value > 0 } && o.none { it.type == OpType.BLUR } })
        assertTrue(ops("thêm sương mù").any { it.type == OpType.DEHAZE && it.value < 0 })
        assertTrue(ops("tăng vibrance").let { o -> o.any { it.type == OpType.VIBRANCE && it.value > 0 } && o.none { it.type == OpType.SATURATION } })
        assertTrue(ops("tăng bão hòa").any { it.type == OpType.SATURATION })
        assertTrue(ops("thêm magenta").any { it.type == OpType.TINT && it.value > 0 })
        assertTrue(ops("green tint").any { it.type == OpType.TINT && it.value < 0 })
        assertTrue(ops("tăng kết cấu").any { it.type == OpType.TEXTURE && it.value > 0 })
        assertTrue(ops("làm mịn kết cấu").let { o -> o.any { it.type == OpType.TEXTURE && it.value < 0 } && o.none { it.type == OpType.SKIN_SMOOTH } })
    }

    @Test fun plannerNangIsNotSun() {
        // lỗi cũ: bỏ dấu làm "nâng" (raise) trùng "nắng" (sun) -> thêm tông ấm ngoài ý muốn
        val o = ops("nâng vùng tối")
        assertTrue(o.any { it.type == OpType.SHADOWS })
        assertTrue(o.none { it.type == OpType.WARMTH })
        assertTrue(ops("tăng nắng").any { it.type == OpType.WARMTH && it.value > 0 })
        assertTrue(ops("hạ độ sáng").any { it.type == OpType.BRIGHTNESS && it.value < 0 })
    }

    // ------------------------------------------------------------------ Bầu trời
    /** Cảnh tổng hợp: trời xanh chuyển sắc ở [0, skyRows), đất lục có kết cấu bên dưới. */
    private fun skyScene(w: Int, h: Int, skyRows: Int): IntArray {
        val rnd = java.util.Random(21)
        return IntArray(w * h) { i ->
            val y = i / w
            if (y < skyRows) {
                val t = y / skyRows.toFloat()
                argb((30 + 140 * t).toInt(), (90 + 115 * t).toInt(), (200 + 40 * t).toInt())
            } else {
                argb(
                    (50 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255),
                    (120 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255),
                    (45 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255)
                )
            }
        }
    }

    @Test fun skyMaskFindsSkyAndSkipsGround() {
        val w = 160; val h = 120
        val px = skyScene(w, h, 55)
        val m = SkyFx.mask(px, w, h)
        var skyHit = 0; var skyTotal = 0; var gndHit = 0; var gndTotal = 0
        for (y in 0 until h) for (x in 0 until w) {
            val v = m[y * w + x] > 0.5f
            if (y < 50) { skyTotal++; if (v) skyHit++ } else if (y > 62) { gndTotal++; if (v) gndHit++ }
        }
        assertTrue("trời bị sót: $skyHit/$skyTotal", skyHit > skyTotal * 0.97)
        assertTrue("đất bị lấy nhầm: $gndHit/$gndTotal", gndHit < gndTotal * 0.01)
    }

    @Test fun skyMaskIsEmptyWithoutSky() {
        val w = 120; val h = 90
        val rnd = java.util.Random(3)
        val px = IntArray(w * h) { argb(40 + rnd.nextInt(160), 40 + rnd.nextInt(160), 40 + rnd.nextInt(160)) }
        assertTrue(SkyFx.mask(px, w, h).all { it <= 0.01f })
        assertTrue(SkyFx.replace(px, w, h, "sunset", 1f) === px)
    }

    @Test fun skyReplaceChangesSkyKeepsGroundAndIsDeterministic() {
        val w = 160; val h = 120
        val px = skyScene(w, h, 55)
        for (preset in SkyFx.PRESETS) {
            val out = SkyFx.replace(px, w, h, preset, 1f)
            var skyDiff = 0L; var maxGround = 0
            for (y in 0 until h) for (x in 0 until w) {
                val a = px[y * w + x]; val b = out[y * w + x]
                val d = abs(red(a) - red(b)) + abs(grn(a) - grn(b)) + abs(blu(a) - blu(b))
                if (y < 40) skyDiff += d else if (y > 66) maxGround = maxOf(maxGround, d)
            }
            assertTrue("đất bị đổi ($preset): $maxGround", maxGround <= 6)
            if (preset != "blue") assertTrue("trời không đổi ($preset)", skyDiff > 40L * w * 20)
            assertTrue(out.contentEquals(SkyFx.replace(px, w, h, preset, 1f)))
        }
        assertTrue(SkyFx.replace(px, w, h, "sunset", 0f) === px)
    }

    @Test fun skyReplaceNightIsDark() {
        val w = 160; val h = 120
        val out = SkyFx.replace(skyScene(w, h, 55), w, h, "night", 1f)
        var sum = 0.0
        for (y in 0 until 40) for (x in 0 until w) sum += lum(out[y * w + x])
        assertTrue(sum / (40 * w) < 60.0)
    }

    @Test fun skyOpSanitizeAndRecipeRoundTrip() {
        val ok = EditOp(OpType.SKY_REPLACE, 0.8f, "sunset").sanitized()!!
        assertEquals("sunset", ok.arg)
        assertEquals("blue", EditOp(OpType.SKY_REPLACE, 1f, "lava").sanitized()!!.arg)
        assertEquals("blue", EditOp(OpType.SKY_REPLACE, 1f, null).sanitized()!!.arg)
        assertNull(EditOp(OpType.SKY_REPLACE, 0.001f, "night").sanitized())
        val m = mergeOps(listOf(EditOp(OpType.SKY_REPLACE, 1f, "night"), EditOp(OpType.SKY_REPLACE, 1f, "dusk")))
        assertEquals(1, m.size)
        assertEquals("dusk", m[0].arg)
        // công thức: MaskSpec.Sky được lưu/đọc lại nguyên vẹn
        val layer = AdjustmentLayer(1L, "Trời", listOf(EditOp(OpType.CLARITY, 0.4f)), mask = LayerMask(MaskSpec.Sky(0.7f), feather = 0.01f))
        val back = RecipeCodec.decode(RecipeCodec.encode(listOf(layer)))
        val spec = back[0].mask!!.spec
        assertTrue(spec is MaskSpec.Sky)
        assertEquals(0.7f, (spec as MaskSpec.Sky).sensitivity, 1e-6f)
        assertTrue(RecipeCodec.portable(layer))
    }

    @Test fun plannerSkyReplaceVersusSkyColor() {
        fun o(p: String) = RuleBasedPlanner.plan(p)
        assertEquals("sunset", o("thay bầu trời hoàng hôn").ops.first { it.type == OpType.SKY_REPLACE }.arg)
        assertTrue(o("thay bầu trời hoàng hôn").ops.none { it.type == OpType.WARMTH })
        assertEquals("night", o("đổi bầu trời đêm sao").ops.first { it.type == OpType.SKY_REPLACE }.arg)
        assertEquals("blue", o("thay bầu trời").ops.first { it.type == OpType.SKY_REPLACE }.arg)
        // chỉnh MÀU vùng trời vẫn là phép theo vùng, không phải thay trời
        val tint = o("bầu trời xanh hơn")
        assertTrue(tint.ops.none { it.type == OpType.SKY_REPLACE })
        assertTrue(tint.scoped.any { it.scope == com.aiphoto.studio.ai.Scope.SKY })
    }

    // ------------------------------------------------------------------ Lưu / khôi phục phiên làm việc
    private fun encodeLayers(layers: List<Layer>, files: MutableMap<String, ByteArray>): org.json.JSONObject =
        ProjectCodec.encode(
            ProjectCodec.Meta(1234L, 200, 100, "bg_1.png", 42L), layers,
            patchFile = { error("không có lớp vá trong test") },
            maskFile = { id, m -> "mask_$id.bin".also { files[it] = m.data } },
            imageFile = { error("không có ảnh phủ trong test") }
        )

    private fun decodeLayers(json: org.json.JSONObject, files: Map<String, ByteArray>) =
        ProjectCodec.decode(json, 200, 100, loadPatch = { null }, loadMask = { name, w, h -> files[name]?.takeIf { it.size == w * h } })

    @Test fun projectRoundTripKeepsEverything() {
        val painted = ByteArray(200 * 100) { (it % 251).toByte() }
        val layers = listOf<Layer>(
            AdjustmentLayer(7L, "Cơ bản", listOf(EditOp(OpType.BRIGHTNESS, 0.3f), EditOp(OpType.LUT, 0.6f, "film.cube")), kind = "basic"),
            AdjustmentLayer(
                9L, "Vùng tô", listOf(EditOp(OpType.SATURATION, -0.4f)), visible = false, opacity = 0.55f, blend = BlendMode.SOFT_LIGHT,
                mask = LayerMask(MaskSpec.Painted(painted, 200, 100), invert = true, feather = 0.03f, shift = 0.2f), kind = "local"
            ),
            AdjustmentLayer(
                12L, "Trời", listOf(EditOp(OpType.SKY_REPLACE, 1f, "sunset")), blend = BlendMode.MULTIPLY,
                mask = LayerMask(MaskSpec.Sky(0.4f), feather = 0.01f), kind = "ai", scope = "sky"
            )
        )
        val files = HashMap<String, ByteArray>()
        val json = encodeLayers(layers, files)
        // đi qua chuỗi văn bản như khi ghi/đọc tệp thật
        val back = decodeLayers(org.json.JSONObject(json.toString()), files)
        assertEquals(0, back.skipped)
        assertEquals(12L, back.maxId)
        assertEquals(3, back.layers.size)
        val a = back.layers[0] as AdjustmentLayer
        assertEquals(7L, a.id); assertEquals("Cơ bản", a.name); assertEquals("basic", a.kind)
        assertEquals(listOf(OpType.BRIGHTNESS, OpType.LUT), a.ops.map { it.type })
        assertEquals("film.cube", a.ops[1].arg)
        val b = back.layers[1] as AdjustmentLayer
        assertFalse(b.visible)
        assertEquals(0.55f, b.opacity, 1e-6f)
        assertEquals(BlendMode.SOFT_LIGHT, b.blend)
        val pm = b.mask!!
        assertTrue(pm.invert && abs(pm.feather - 0.03f) < 1e-6f && abs(pm.shift - 0.2f) < 1e-6f)
        val ps = pm.spec as MaskSpec.Painted
        assertEquals(200, ps.w); assertEquals(100, ps.h)
        assertTrue(ps.data.contentEquals(painted))
        val c = back.layers[2] as AdjustmentLayer
        assertEquals("sky", c.scope)
        assertEquals(0.4f, (c.mask!!.spec as MaskSpec.Sky).sensitivity, 1e-6f)
        assertEquals(BlendMode.MULTIPLY, c.blend)
        assertEquals(setOf("bg_1.png", "mask_9.bin"), ProjectCodec.referencedFiles(json))
        val meta = ProjectCodec.meta(json)!!
        assertEquals(42L, meta.idCounter); assertEquals(200, meta.w); assertEquals("bg_1.png", meta.bgFile)
        assertEquals(3, ProjectCodec.layerCount(json))
    }

    @Test fun projectDecodeIsDefensive() {
        val files = HashMap<String, ByteArray>()
        val ok = AdjustmentLayer(1L, "A", listOf(EditOp(OpType.CONTRAST, 0.2f)))
        val json = encodeLayers(listOf(ok), files)
        val arr = json.getJSONArray("layers")
        // id trùng + lớp không có id + kiểu lạ + ops ngoài khoảng + LUT tên xấu + opacity vượt biên
        arr.put(org.json.JSONObject(arr.getJSONObject(0).toString()))                       // id trùng
        arr.put(org.json.JSONObject().put("t", "adj").put("name", "no id"))                   // không id
        arr.put(org.json.JSONObject().put("t", "hologram").put("id", 77))                     // kiểu lạ
        arr.put(
            org.json.JSONObject().put("t", "adj").put("id", 5).put("opacity", 9.0).put("name", "x".repeat(500))
                .put("ops", org.json.JSONArray()
                    .put(org.json.JSONObject().put("op", "brightness").put("value", 50.0))
                    .put(org.json.JSONObject().put("op", "lut").put("value", 1.0).put("arg", "../../evil.cube"))
                    .put(org.json.JSONObject().put("op", "không_có_phép_này").put("value", 1.0)))
        )
        val dec = decodeLayers(json, files)
        assertEquals(2, dec.layers.size)
        assertEquals(3, dec.skipped)                      // id trùng, thiếu id, kiểu lạ (phép chỉnh lỗi trong lớp hợp lệ không tính)
        val x = dec.layers[1] as AdjustmentLayer
        assertEquals(1f, x.opacity, 1e-6f)
        assertEquals(80, x.name.length)
        assertEquals(1, x.ops.size)                       // chỉ còn brightness (đã kẹp), LUT xấu và phép lạ bị loại
        assertEquals(1f, x.ops[0].value, 1e-6f)
    }

    @Test fun projectDropsLayerWhenItsMaskFileIsMissing() {
        val files = HashMap<String, ByteArray>()
        val painted = AdjustmentLayer(3L, "Tô", listOf(EditOp(OpType.BRIGHTNESS, 0.5f)), mask = LayerMask(MaskSpec.Painted(ByteArray(200 * 100), 200, 100)))
        val keep = AdjustmentLayer(4L, "Giữ", listOf(EditOp(OpType.CONTRAST, 0.1f)))
        val json = encodeLayers(listOf(painted, keep), files)
        files.clear()                                     // mô phỏng tệp mặt nạ bị xóa
        val dec = decodeLayers(json, files)
        // KHÔNG được áp phép chỉnh lên toàn ảnh khi mặt nạ mất → bỏ cả lớp
        assertEquals(listOf(4L), dec.layers.map { it.id })
        assertEquals(1, dec.skipped)
        // tệp mặt nạ sai kích thước cũng bị coi là hỏng
        val files2 = HashMap<String, ByteArray>().apply { put("mask_3.bin", ByteArray(10)) }
        assertEquals(listOf(4L), decodeLayers(json, files2).layers.map { it.id })
    }

    @Test fun projectMetaRejectsBadVersionOrSize() {
        val files = HashMap<String, ByteArray>()
        val json = encodeLayers(emptyList(), files)
        assertNotNull(ProjectCodec.meta(json))
        assertNull(ProjectCodec.meta(org.json.JSONObject(json.toString()).put("v", 99)))
        assertNull(ProjectCodec.meta(org.json.JSONObject(json.toString()).put("w", 0)))
        assertNull(ProjectCodec.meta(org.json.JSONObject(json.toString()).put("bg", "")))
    }

    // ------------------------------------------------------------------ Lớp phủ chữ / ảnh
    @Test fun overlayTextLayerRoundTripsThroughProject() {
        val files = HashMap<String, ByteArray>()
        val t = OverlayLayer(
            21L, "Chữ: Xin chào", "text", text = "Xin chào\nThế giới", color = 0xFFFFD60A.toInt(), bold = false, outline = false,
            cx = 0.3f, cy = 0.8f, size = 0.2f, rotation = -15f, opacity = 0.9f, blend = BlendMode.OVERLAY,
            mask = LayerMask(MaskSpec.Radial(0.5f, 0.5f, 0.4f))
        )
        val json = encodeLayers(listOf(t), files)
        val back = decodeLayers(org.json.JSONObject(json.toString()), files)
        assertEquals(0, back.skipped)
        val o = back.layers[0] as OverlayLayer
        assertEquals("text", o.kind)
        assertEquals("Xin chào\nThế giới", o.text)
        assertEquals(0xFFFFD60A.toInt(), o.color)
        assertFalse(o.bold); assertFalse(o.outline)
        assertEquals(0.3f, o.cx, 1e-6f); assertEquals(0.8f, o.cy, 1e-6f)
        assertEquals(0.2f, o.size, 1e-6f); assertEquals(-15f, o.rotation, 1e-6f)
        assertEquals(BlendMode.OVERLAY, o.blend)
        assertTrue(o.mask!!.spec is MaskSpec.Radial)
        assertEquals(21L, back.maxId)
    }

    @Test fun overlayDecodeClampsAbsurdValuesAndDropsImageWithoutFile() {
        val files = HashMap<String, ByteArray>()
        val json = encodeLayers(listOf(OverlayLayer(1L, "T", "text", text = "x")), files)
        val arr = json.getJSONArray("layers")
        arr.getJSONObject(0).put("size", 99.0).put("cx", -40.0).put("cy", 77.0).put("rotation", 9999.0).put("text", "a".repeat(1000))
        arr.put(org.json.JSONObject().put("t", "overlay").put("kind", "image").put("id", 2).put("file", "khong_ton_tai.png")) // ảnh mất tệp
        arr.put(org.json.JSONObject().put("t", "overlay").put("kind", "ma_thuat").put("id", 3))                              // kiểu lạ
        val dec = decodeLayers(json, files)
        assertEquals(1, dec.layers.size)
        assertEquals(2, dec.skipped)
        val o = dec.layers[0] as OverlayLayer
        assertEquals(2f, o.size, 1e-6f)
        assertEquals(-0.5f, o.cx, 1e-6f); assertEquals(1.5f, o.cy, 1e-6f)
        assertEquals(360f, o.rotation, 1e-6f)
        assertEquals(OverlayLayer.MAX_TEXT, o.text.length)
    }

    @Test fun overlayClampParamsKeepsOtherFields() {
        val l = OverlayLayer(5L, "n", "text", text = "hi", color = 123, size = 0f, rotation = 500f)
        val c = OverlayLayer.clampParams(l)
        assertEquals(0.01f, c.size, 1e-6f)
        assertEquals(360f, c.rotation, 1e-6f)
        assertEquals(123, c.color); assertEquals("hi", c.text); assertEquals(5L, c.id)
        assertTrue(l.update(opacity = 0.4f) is OverlayLayer)
        assertEquals(0.4f, l.update(opacity = 0.4f).opacity, 1e-6f)
    }

    @Test fun agentPlanJsonCarriesNewOps() {
        val p = PlanJson.parseFull(
            """{"ops":[{"op":"sky_replace","value":1,"arg":"night"},{"op":"highlights","value":-0.4},{"op":"dehaze","value":0.5},{"op":"vibrance","value":0.3}]}"""
        )!!
        assertEquals(listOf(OpType.SKY_REPLACE, OpType.HIGHLIGHTS, OpType.DEHAZE, OpType.VIBRANCE), p.ops.map { it.type })
        assertEquals("night", p.ops[0].arg)
        val clean = p.ops.mapNotNull { it.sanitized() }
        assertEquals(4, clean.size)
        assertEquals(-0.4f, clean[1].value, 1e-6f)
    }

    // ------------------------------------------------------------------ R12: xóa bụi / xước / sợi mảnh
    @Test fun despeckleRemovesDustAndScratchKeepsEdges() {
        val w = 300; val h = 200
        val clean = IntArray(w * h) { i -> val x = i % w; val y = i / w; if (x >= 200) argb(180, 180, 180) else argb(120 + (y / 10) % 3, 120, 120) }
        val dirty = clean.copyOf()
        for (dy in 0..1) for (dx in 0..1) dirty[(50 + dy) * w + 50 + dx] = argb(20, 20, 20)    // hạt bụi 2x2
        for (y in 20..80) dirty[y * w + 100] = argb(255, 255, 255)                              // vết xước sáng 1 px
        val out = Despeckle.apply(dirty, w, h, 1f)
        assertTrue("bụi chưa mất: ${lum(out[50 * w + 50])}", abs(lum(out[50 * w + 50]) - 120f) <= 8f)
        assertTrue("xước chưa mất: ${lum(out[40 * w + 100])}", abs(lum(out[40 * w + 100]) - 120f) <= 8f)
        for (y in 100..190) for (x in 190..210) assertEquals("cạnh bị đổi tại ($x,$y)", dirty[y * w + x], out[y * w + x])
        assertTrue(out.all { (it ushr 24) == 255 })
        assertTrue(Despeckle.apply(clean, w, h, 1f) === clean)        // ảnh sạch: không đổi, trả cùng mảng
        assertTrue(Despeckle.apply(dirty, w, h, 0f) === dirty)
        val (r, t) = Despeckle.params(w, h, 1f)
        val flagged = Despeckle.detect(dirty, w, h, r, t)
        assertTrue(flagged[50 * w + 50])
        assertFalse(flagged[10 * w + 10])
    }

    @Test fun despeckleParamsAndGuards() {
        assertTrue(Despeckle.params(1500, 1000, 0.2f).first <= Despeckle.params(1500, 1000, 1f).first)
        assertTrue(Despeckle.params(1500, 1000, 0.2f).second > Despeckle.params(1500, 1000, 1f).second)
        assertEquals(1, Despeckle.params(80, 60, 1f).first)
        assertEquals(8, Despeckle.params(12000, 9000, 1f).first)
        val tiny = IntArray(4)
        assertTrue(Despeckle.apply(tiny, 2, 2, 1f) === tiny)
        assertTrue(Despeckle.apply(IntArray(10), 3, 3, 1f).size == 10)   // kích thước không khớp: trả nguyên, không ném lỗi
    }

    @Test fun dustOpAndPlanner() {
        assertTrue(OpType.DUST.scalable && !OpType.DUST.signed)
        assertEquals(1f, EditOp(OpType.DUST, 3f).sanitized()!!.value, 1e-6f)
        assertNull(EditOp(OpType.DUST, 0.001f).sanitized())
        assertTrue(RuleBasedPlanner.plan("xóa bụi").ops.any { it.type == OpType.DUST })
        assertTrue(RuleBasedPlanner.plan("xóa vết xước").ops.any { it.type == OpType.DUST })
        val hair = RuleBasedPlanner.plan("xóa sợi tóc lạc")
        assertTrue(hair.ops.none { it.type == OpType.SKIN_SMOOTH })
        val scopes = hair.scoped.map { it.scope }.toSet()
        assertTrue(com.aiphoto.studio.ai.Scope.SKIN in scopes && com.aiphoto.studio.ai.Scope.BACKGROUND in scopes)
        assertTrue(hair.scoped.all { s -> s.ops.all { it.type == OpType.DUST } })
        assertTrue(RuleBasedPlanner.plan("làm sáng tóc").scoped.none { s -> s.ops.any { it.type == OpType.DUST } })
    }
}
