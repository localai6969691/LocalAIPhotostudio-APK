package com.aiphoto.studio

import com.aiphoto.studio.engine.StrangerMask
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

/**
 * R21: "Xóa người lạ" nhận cả người QUAY LƯNG nhờ hộp người (PersonDetectorEngine, không chạy được ở đây vì cần model) —
 * kiểm phần logic thuần: ghép mặt với hộp, quy cỡ, chọn giữ/xóa, dựng mặt nạ, bảo vệ chủ thể.
 */
class R21PersonTest {

    private val W = 400
    private val H = 600

    private fun face(cx: Float, cy: Float, fw: Float, fh: Float): FloatArray {
        val a = FloatArray(2 * 478)
        for (i in 0 until 478) {
            val t = 2.0 * Math.PI * i / 478
            a[2 * i] = ((cx + fw / 2 * cos(t)) / W).toFloat()
            a[2 * i + 1] = ((cy + fh / 2 * sin(t)) / H).toFloat()
        }
        a[2 * 10] = cx / W; a[2 * 10 + 1] = (cy - fh / 2) / H
        a[2 * 152] = cx / W; a[2 * 152 + 1] = (cy + fh / 2) / H
        return a
    }

    /** Hộp người theo pixel → [x0,y0,x1,y1,score] chuẩn hóa. */
    private fun box(x0: Float, y0: Float, x1: Float, y1: Float, score: Float = 0.8f) = floatArrayOf(x0 / W, y0 / H, x1 / W, y1 / H, score)

    private fun m(res: StrangerMask.Result, x: Int, y: Int) = res.mask[y * W + x].toInt() != 0

    private val main = face(140f, 170f, 50f, 62f)
    private val mainBox = box(50f, 100f, 230f, 560f)

    // ---------------------------------------------------------------- hộp & ghép
    @Test fun boxesAreConvertedToPixelsAndTinyOrDegenerateOnesAreDropped() {
        val b = StrangerMask.personBoxes(listOf(box(40f, 60f, 100f, 300f, 0.9f)), W, H)
        assertEquals(1, b.size)
        assertEquals(40f, b[0].x0, 0.01f); assertEquals(300f, b[0].y1, 0.01f); assertEquals(0.9f, b[0].score, 1e-6f)
        val none = StrangerMask.personBoxes(
            listOf(box(10f, 10f, 12f, 200f), box(10f, 10f, 200f, 20f), FloatArray(3), box(50f, 50f, 50f, 50f)), W, H   // quá hẹp, quá thấp, thiếu số, rỗng
        )
        assertTrue(none.isEmpty())
        // tọa độ ngoài ảnh bị kẹp lại
        val clip = StrangerMask.personBoxes(listOf(floatArrayOf(-0.2f, -0.1f, 1.3f, 1.2f, 0.7f)), W, H)[0]
        assertEquals(0f, clip.x0, 0f); assertEquals(W.toFloat(), clip.x1, 0f); assertEquals(H.toFloat(), clip.y1, 0f)
        // thiếu điểm số → 1
        assertEquals(1f, StrangerMask.personBoxes(listOf(floatArrayOf(0.1f, 0.1f, 0.5f, 0.9f)), W, H)[0].score, 0f)
    }

    @Test fun aFaceInsideABoxBelongsToThatPersonAndIsNotCountedTwice() {
        val subs = StrangerMask.subjects(
            StrangerMask.faceBoxes(listOf(main), W, H),
            StrangerMask.personBoxes(listOf(mainBox), W, H)
        )
        assertEquals(1, subs.size)
        assertNotNull(subs[0].face); assertNotNull(subs[0].box)
    }

    @Test fun aBoxWithoutAFaceIsAPersonFacingAway() {
        val subs = StrangerMask.subjects(
            StrangerMask.faceBoxes(listOf(main), W, H),
            StrangerMask.personBoxes(listOf(mainBox, box(300f, 260f, 360f, 420f)), W, H)
        )
        assertEquals(2, subs.size)
        assertEquals(1, subs.count { it.face == null })
    }

    @Test fun duplicateDetectionsInsideAnotherPersonsBoxAreIgnored() {
        val subs = StrangerMask.subjects(
            emptyList(),
            StrangerMask.personBoxes(listOf(box(50f, 100f, 230f, 560f), box(70f, 120f, 200f, 300f), box(300f, 260f, 360f, 420f)), W, H)
        )
        assertEquals("hộp con nằm trọn trong hộp lớn là bản trùng", 2, subs.size)
    }

    @Test fun aBoxMustBeWiderThanTheFaceToOwnIt() {
        // hộp nhỏ hơn mặt (nhận nhầm) không được nuốt mặt
        val subs = StrangerMask.subjects(
            StrangerMask.faceBoxes(listOf(main), W, H),
            StrangerMask.personBoxes(listOf(box(125f, 150f, 150f, 200f)), W, H)
        )
        assertTrue(subs.any { it.face != null && it.box == null })
    }

    // ---------------------------------------------------------------- cỡ và chọn giữ / xóa
    @Test fun boxOnlySizeIsComparableToFaceSizeForAnAdultStandingFullBody() {
        // mặt 50×62 (3100) ↔ vai ≈ 3,2 bề ngang mặt = 160 px: hộp rộng 160 phải cho cỡ tương đương mặt thật
        val s = StrangerMask.Subject(null, StrangerMask.Box(0f, 0f, 160f, 450f, 1f))
        assertEquals(3100f, s.size, 3100f * 0.12f)
    }

    @Test fun smallBackFacingStrangerIsDroppedAndTheBigOneIsKept() {
        val a = StrangerMask.analyze(listOf(main), listOf(mainBox, box(300f, 260f, 360f, 420f)), W, H)
        assertEquals(1, a.keep.size); assertEquals(1, a.drop.size)
        assertNull(a.drop[0].face)
    }

    @Test fun backFacingMainSubjectIsKeptWhenNoFaceIsVisibleAtAll() {
        val a = StrangerMask.analyze(emptyList(), listOf(mainBox, box(300f, 260f, 360f, 420f), box(10f, 300f, 60f, 450f)), W, H)
        assertEquals(1, a.keep.size)
        assertEquals(2, a.drop.size)
        assertEquals(mainBox[0] * W, a.keep[0].box!!.x0, 0.01f)
    }

    @Test fun friendsOfSimilarSizeAreAllKeptEvenWhenFacingAway() {
        val a = StrangerMask.analyze(listOf(main), listOf(mainBox, box(250f, 110f, 390f, 560f)), W, H)
        assertEquals(2, a.keep.size); assertTrue(a.drop.isEmpty())
    }

    @Test fun mainSubjectCutOffAtTheFrameEdgeIsNotMistakenForAStranger() {
        // chân dung cắt ngang ngực (hộp thấp, sát đáy ảnh) + bạn đi cùng toàn thân CÙNG khoảng cách (mặt cùng cỡ):
        // so theo cỡ MẶT nên cả hai được giữ; nếu so theo diện tích hộp, người bị cắt cụt sẽ bị xóa nhầm
        val cut = face(120f, 385f, 60f, 74f)
        val friend = face(300f, 130f, 60f, 74f)
        val boxes = listOf(box(55f, 340f, 185f, 600f), box(220f, 80f, 380f, 560f))     // diện tích hộp người bị cắt chỉ ~44% hộp bạn
        val a = StrangerMask.analyze(listOf(cut, friend), boxes, W, H)
        assertEquals(2, a.keep.size); assertTrue(a.drop.isEmpty())
    }

    @Test fun nobodyToRemoveWhenOnlyOnePersonOrAllSimilar() {
        assertNull(StrangerMask.build(emptyList(), W, H, null, listOf(mainBox)))
        assertNull(StrangerMask.build(listOf(main), W, H, null, listOf(mainBox)))
        assertNull(StrangerMask.build(emptyList(), W, H, null, listOf(box(20f, 100f, 180f, 560f), box(220f, 110f, 380f, 560f))))
    }

    // ---------------------------------------------------------------- mặt nạ
    @Test fun backFacingStrangerIsMaskedAndTheMainSubjectIsProtected() {
        val res = StrangerMask.build(listOf(main), W, H, null, listOf(mainBox, box(300f, 260f, 360f, 420f)))
        assertNotNull(res); res!!
        assertEquals(1, res.kept); assertEquals(1, res.removed); assertEquals(1, res.detectorOnly)
        for ((x, y) in listOf(330 to 340, 330 to 290, 330 to 400, 315 to 340, 345 to 340)) assertTrue("người quay lưng ($x,$y)", m(res, x, y))
        for ((x, y) in listOf(140 to 170, 100 to 300, 180 to 400, 140 to 520)) assertFalse("chủ thể ($x,$y)", m(res, x, y))
        assertFalse(m(res, 20, 20)); assertFalse(m(res, 200, 590))
        assertTrue("diện tích hợp lý ${res.coverage}", res.coverage in 0.01f..0.1f)
    }

    @Test fun boxShapeCoversMostOfThePersonButNotTheBoxCorners() {
        val res = StrangerMask.build(listOf(main), W, H, null, listOf(mainBox, box(300f, 260f, 360f, 420f)))!!
        var tot = 0; var hit = 0
        for (y in 260 until 420) for (x in 300 until 360) { tot++; if (m(res, x, y)) hit++ }
        assertTrue("phủ ${hit * 100 / tot}% hộp", hit * 100 / tot in 80..100)
    }

    @Test fun faceAndBoxStrangersAreBothRemovedInOneRun() {
        val front = face(330f, 300f, 24f, 30f)                    // người lạ nhìn thẳng (có mặt, có hộp)
        val back = box(2f, 360f, 46f, 520f)                        // người lạ quay lưng
        val res = StrangerMask.build(listOf(main, front), W, H, null, listOf(mainBox, box(300f, 270f, 360f, 480f), back))!!
        assertEquals(1, res.kept); assertEquals(2, res.removed); assertEquals(1, res.detectorOnly)
        assertTrue(m(res, 330, 300)); assertTrue(m(res, 24, 440))
        assertFalse(m(res, 140, 170))
    }

    @Test fun withoutPeopleTheResultIsExactlyTheOldFaceOnlyBehaviour() {
        val stranger = face(330f, 300f, 24f, 30f)
        val old = StrangerMask.build(listOf(main, stranger), W, H)!!
        val nul = StrangerMask.build(listOf(main, stranger), W, H, null, null)!!
        val empty = StrangerMask.build(listOf(main, stranger), W, H, null, emptyList())!!
        assertTrue(old.mask.contentEquals(nul.mask)); assertTrue(old.mask.contentEquals(empty.mask))
        assertEquals(0, old.detectorOnly)
    }

    @Test fun anEmptyDetectorRunNeverBreaksTheFaceBasedPath() {
        // bộ phát hiện người trả rỗng (không thấy ai) → vẫn dùng khuôn mặt như cũ
        val stranger = face(330f, 300f, 24f, 30f)
        val res = StrangerMask.build(listOf(main, stranger), W, H, null, emptyList())!!
        assertEquals(1, res.removed)
        assertTrue(m(res, 330, 340))
    }

    @Test fun strangerStandingBehindTheMainSubjectIsOnlyRemovedWhereVisible() {
        // người quay lưng ngay sau chủ thể: phần chồng lên chủ thể được bảo vệ, phần lộ ra bị xóa
        val res = StrangerMask.build(listOf(main), W, H, null, listOf(mainBox, box(190f, 300f, 270f, 480f)))!!
        assertTrue("phần lộ ra bên phải", m(res, 255, 390))
        assertFalse("phần chồng lên chủ thể", m(res, 150, 390))
    }

    @Test fun segmentationRefinesABoxOnlyStrangerToItsRealBody() {
        val plain = StrangerMask.build(listOf(main), W, H, null, listOf(mainBox, box(290f, 260f, 370f, 440f)))!!
        val fg = FloatArray(W * H)
        for (y in 270..430) for (x in 315..345) fg[y * W + x] = 1f                    // người thật gọn hơn hộp
        for (y in 100..560) for (x in 90..190) fg[y * W + x] = 1f                     // chủ thể chính
        val refined = StrangerMask.build(listOf(main), W, H, fg, listOf(mainBox, box(290f, 260f, 370f, 440f)))!!
        assertTrue("bám cơ thể nên nhỏ hơn: ${refined.coverage} < 0,8·${plain.coverage}", refined.coverage < plain.coverage * 0.8f)
        for (y in 290..420 step 10) for (x in 320..340 step 5) assertTrue("thân thật ($x,$y)", m(refined, x, y))
        assertFalse(m(refined, 140, 300))
        // fg vô dụng (không phủ hình) → quay về hình nội tiếp hộp
        val useless = StrangerMask.build(listOf(main), W, H, FloatArray(W * H), listOf(mainBox, box(290f, 260f, 370f, 440f)))!!
        assertEquals(plain.coverage, useless.coverage, 1e-6f)
    }

    @Test fun boxAtTheFrameEdgeIsClippedNotCrashing() {
        val res = StrangerMask.build(listOf(main), W, H, null, listOf(mainBox, box(360f, 420f, 400f, 600f)))!!
        assertEquals(W * H, res.mask.size)
        assertTrue(m(res, 385, 520))
    }
}
