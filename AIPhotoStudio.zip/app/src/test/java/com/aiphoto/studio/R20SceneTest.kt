package com.aiphoto.studio

import com.aiphoto.studio.ai.BackgroundScene
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.engine.BackgroundSwap
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot

/** R20: thay nền bằng cảnh tạo sinh nhưng giữ nguyên chủ thể (hiểu câu lệnh + lõi ghép ảnh). */
class R20SceneTest {

    // ---------------------------------------------------------------- hiểu câu lệnh
    @Test fun sceneIsExtractedFromVietnameseAndEnglish() {
        assertEquals("bãi biển lúc hoàng hôn", BackgroundScene.extract("thay nền thành bãi biển lúc hoàng hôn"))
        assertEquals("khu rừng", BackgroundScene.extract("Thay nền ảnh bằng một khu rừng"))
        assertEquals("thành phố ban đêm", BackgroundScene.extract("đổi nền sang thành phố ban đêm"))
        assertEquals("văn phòng hiện đại", BackgroundScene.extract("đổi phông nền thành văn phòng hiện đại"))
        assertEquals("beach at sunset", BackgroundScene.extract("change the background to a beach at sunset"))
        assertEquals("a snowy mountain".removePrefix("a "), BackgroundScene.extract("replace background with a snowy mountain"))
        // chữ gõ NFD (bàn phím cũ) vẫn hiểu
        val nfd = java.text.Normalizer.normalize("thay nền thành bãi biển", java.text.Normalizer.Form.NFD)
        assertNotNull(BackgroundScene.extract(nfd))
    }

    @Test fun sceneStopsAtTheNextEditRequest() {
        assertEquals("bãi biển", BackgroundScene.extract("thay nền thành bãi biển, tăng sáng"))
        assertEquals("bãi biển", BackgroundScene.extract("thay nền thành bãi biển và làm da mịn"))
        assertEquals("bãi biển", BackgroundScene.extract("thay nền thành bãi biển rồi làm da mịn"))
        assertEquals("beach", BackgroundScene.extract("change the background to beach and make it brighter"))
        // dấu phẩy / "và" bên trong mô tả cảnh thì giữ nguyên
        assertEquals("bãi biển, hoàng hôn", BackgroundScene.extract("thay nền thành bãi biển, hoàng hôn"))
        assertEquals("núi và biển", BackgroundScene.extract("thay nền thành núi và biển"))
    }

    @Test fun putSubjectInPlace() {
        assertEquals("bãi biển", BackgroundScene.extract("đặt tôi vào bãi biển"))
        assertEquals("giữa phố cổ", BackgroundScene.extract("đưa cô ấy ra giữa phố cổ"))
        assertEquals("beach", BackgroundScene.extract("put me on a beach"))
        // thay trang phục KHÔNG phải thay nền
        assertNull(BackgroundScene.extract("đặt cô ấy vào chiếc váy đỏ"))
        assertNull(BackgroundScene.extract("put her in a red dress"))
        assertFalse(BackgroundScene.isBackgroundSwap("put him in a suit"))
    }

    @Test fun plainColorBackgroundsStayOnTheCutoutPath() {
        for (p in listOf("đổi nền thành màu trắng", "thay nền sang màu xanh dương", "change the background to white", "đổi nền thành màu đen", "thay nền màu hồng nhạt")) {
            assertNull("\"$p\" là màu trơn → không sinh cảnh", BackgroundScene.extract(p))
            assertTrue("\"$p\" vẫn là yêu cầu đổi nền", BackgroundScene.isBackgroundSwap(p))
            assertNull("\"$p\" không được coi là tạo vật thể", GenIntent.detect(p, false))
            val bg = RuleBasedPlanner.plan(p).ops.firstOrNull { it.type == OpType.BG_REMOVE }
            assertNotNull("\"$p\" phải ra BG_REMOVE", bg)
        }
        assertEquals("#FFFFFF", RuleBasedPlanner.plan("đổi nền thành màu trắng").ops.first { it.type == OpType.BG_REMOVE }.arg)
    }

    @Test fun backgroundAdjustmentsAreNotSwaps() {
        for (p in listOf("làm mờ nền", "xóa nền", "tối nền", "đổi nền mờ hơn", "make the background darker", "change the background blurrier", "tăng sáng", "thay áo thành màu đỏ")) {
            assertNull("\"$p\"", BackgroundScene.extract(p))
        }
        assertFalse(BackgroundScene.isBackgroundSwap("làm mờ nền"))
        assertFalse(BackgroundScene.isBackgroundSwap("xóa nền"))
        assertFalse(BackgroundScene.isBackgroundSwap("thay áo thành màu đỏ"))
    }

    @Test fun genIntentRoutesBackgroundSwapAwayFromObjectFill() {
        // chưa tô vùng → không phải "thêm vật thể" (MainViewModel.run xử lý riêng)
        assertNull(GenIntent.detect("thay nền thành bãi biển", false))
        assertNull(GenIntent.detect("thay nền", false))
        assertNull(GenIntent.detect("đặt tôi vào bãi biển", false))
        // đã tô vùng → tôn trọng vùng người dùng tô
        assertEquals(GenKind.FILL, GenIntent.detect("thay nền thành bãi biển", true))
        // thêm / xóa vật thể không đổi
        assertEquals(GenKind.FILL, GenIntent.detect("thêm một con chim", false))
        assertEquals(GenKind.REMOVE, GenIntent.detect("xóa người bên trái", false))
        assertEquals(GenKind.FILL, GenIntent.detect("thay áo thành màu đỏ", false))
    }

    @Test fun generationPromptKeepsTheSceneAndAddsConstraints() {
        val p = BackgroundScene.generationPrompt("bãi biển lúc hoàng hôn")
        assertTrue(p.startsWith("bãi biển lúc hoàng hôn"))
        assertTrue(p.contains("lighting") && p.contains("no people"))
    }

    // ---------------------------------------------------------------- lõi ghép
    private val W = 120
    private val H = 90
    private fun disc(r: Float, ramp: Float = 0f): FloatArray = FloatArray(W * H) { i ->
        val d = hypot((i % W) - 59.5f, (i / W) - 44.5f)
        if (ramp <= 0f) (if (d <= r) 1f else 0f) else (1f - ((d - r) / ramp)).coerceIn(0f, 1f)
    }
    private fun px(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private fun at(x: Int, y: Int) = y * W + x

    @Test fun coverageOfASimpleSubject() {
        val c = BackgroundSwap.subjectCoverage(disc(25f))
        assertEquals(Math.PI * 25 * 25 / (W * H), c.toDouble(), 0.01)
        assertEquals(0f, BackgroundSwap.subjectCoverage(FloatArray(W * H)), 0f)
        assertEquals(1f, BackgroundSwap.subjectCoverage(FloatArray(W * H) { 1f }), 0f)
    }

    @Test fun backgroundMaskCoversBackgroundAndEatsIntoTheSubjectEdge() {
        val fg = disc(25f)
        val exact = BackgroundSwap.backgroundMask(fg, W, H, 0)
        for (i in fg.indices) assertEquals(if (fg[i] < 0.5f) 255 else 0, exact[i].toInt() and 255)

        val m3 = BackgroundSwap.backgroundMask(fg, W, H, 3)
        assertEquals("điểm sát mép trong chủ thể bị nuốt", 255, m3[at(59 + 24, 44)].toInt() and 255)
        assertEquals("điểm sâu trong chủ thể được giữ", 0, m3[at(59 + 18, 44)].toInt() and 255)
        assertEquals("tâm chủ thể được giữ", 0, m3[at(59, 44)].toInt() and 255)
        assertEquals("nền xa vẫn là nền", 255, m3[at(2, 2)].toInt() and 255)
        val c0 = exact.count { it.toInt() != 0 }
        val c3 = m3.count { it.toInt() != 0 }
        val c6 = BackgroundSwap.backgroundMask(fg, W, H, 6).count { it.toInt() != 0 }
        assertTrue("nới nhiều hơn → vùng sinh lớn hơn ($c0 < $c3 < $c6)", c0 < c3 && c3 < c6)
    }

    @Test fun degenerateSubjectMasks() {
        val none = BackgroundSwap.backgroundMask(FloatArray(W * H), W, H, 3)
        assertTrue(none.all { it.toInt() != 0 })                       // không có chủ thể → toàn ảnh là nền
        val all = BackgroundSwap.backgroundMask(FloatArray(W * H) { 1f }, W, H, 3)
        assertTrue(all.all { it.toInt() == 0 })                        // toàn ảnh là chủ thể → không có gì để sinh
    }

    @Test fun matteIsOneInsideZeroOutsideAndSmoothAcrossTheEdge() {
        val m = BackgroundSwap.matte(disc(25f, ramp = 4f), W, H, choke = 0, feather = 2)
        assertTrue(m[at(59, 44)] >= 0.999f)
        assertTrue(m[at(1, 1)] <= 0.001f)
        // dọc một đường ngang từ tâm ra ngoài matte không tăng trở lại
        var prev = 1.01f
        var transitional = 0
        for (x in 59..100) {
            val v = m[at(x, 44)]
            assertTrue("matte giảm dần tại x=$x: $v ≤ $prev", v <= prev + 1e-4f)
            if (v > 0.05f && v < 0.95f) transitional++
            prev = v
        }
        assertTrue("có vùng chuyển mềm ($transitional điểm)", transitional >= 3)
    }

    @Test fun compositeKeepsSubjectPixelsEvenIfTheServiceMessesThemUp() {
        val orig = IntArray(W * H) { px(255, 200, 30, 30) }            // chủ thể + nền đều đỏ
        val gen = IntArray(W * H) { px(255, 20, 200, 40) }             // dịch vụ trả toàn ảnh xanh lá (làm hỏng cả chủ thể)
        val fg = disc(25f, ramp = 3f)
        val out = BackgroundSwap.composite(orig, gen, fg, W, H, choke = 0, feather = 1)
        assertEquals("lõi chủ thể = điểm ảnh GỐC", orig[at(59, 44)], out[at(59, 44)])
        assertEquals("nền xa = ảnh sinh", px(255, 20, 200, 40), out[at(1, 1)])
        // vùng viền là hỗn hợp hai màu
        var blended = 0
        for (x in 59..100) {
            val r = (out[at(x, 44)] shr 16) and 255
            if (r in 30..190) blended++
        }
        assertTrue("có điểm viền hòa trộn ($blended)", blended >= 2)
    }

    @Test fun compositeKeepsOriginalAlphaAndIsIdentityWhenNothingChanged() {
        val orig = IntArray(W * H) { px(if (it == at(2, 2)) 128 else 255, (it * 7) and 255, (it * 13) and 255, (it * 29) and 255) }
        val fg = disc(25f, ramp = 3f)
        val same = BackgroundSwap.composite(orig, orig.copyOf(), fg, W, H, choke = 0, feather = 1)
        for (i in orig.indices) assertEquals("điểm $i", orig[i], same[i])
        val gen = IntArray(W * H) { px(255, 0, 0, 255) }
        val out = BackgroundSwap.composite(orig, gen, fg, W, H, choke = 0, feather = 1)
        assertEquals(128, out[at(2, 2)] ushr 24)
    }

    @Test fun maskAndCompositeCooperateOnARealisticSwap() {
        // chủ thể = đĩa đỏ, nền gốc = xanh; dịch vụ "vẽ" nền mới vàng nhưng làm hơi lệch cả khung (dịch pixel)
        val orig = IntArray(W * H) { i -> if (hypot((i % W) - 59.5f, (i / W) - 44.5f) <= 25f) px(255, 220, 20, 20) else px(255, 20, 20, 220) }
        val fg = disc(25f, ramp = 2f)
        val grow = BackgroundSwap.growFor(W, H)
        val mask = BackgroundSwap.backgroundMask(fg, W, H, grow)
        val gen = IntArray(W * H) { i -> if (mask[i].toInt() != 0) px(255, 240, 220, 40) else px(255, 90, 90, 90) }   // trong vùng giữ: xám rác
        val out = BackgroundSwap.composite(orig, gen, fg, W, H, grow, BackgroundSwap.featherFor(W, H))
        assertEquals(px(255, 220, 20, 20), out[at(59, 44)])
        assertEquals(px(255, 240, 220, 40), out[at(5, 5)])
        // không còn dấu vết của nền xanh cũ hay xám rác ở mép: mọi điểm là đỏ, vàng hoặc hỗn hợp giữa hai màu này
        var stray = 0
        for (v in out) {
            val b = v and 255
            val r = (v shr 16) and 255
            if (b > 120 || r < 100) stray++      // xanh cũ (b=220) hoặc xám (r=90) lọt vào
        }
        assertTrue("điểm lạc màu = $stray", stray <= 6)
    }
}
