package com.aiphoto.studio

import com.aiphoto.studio.i18n.AppLanguages
import com.aiphoto.studio.i18n.HelpContent
import com.aiphoto.studio.i18n.HelpItem
import com.aiphoto.studio.i18n.HelpSection
import com.aiphoto.studio.i18n.Translator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R33: lớp dịch (Translator), danh sách ngôn ngữ và Trợ giúp. Mọi khẳng định đã được kiểm bằng bản port Python tools/verify_ports/i18n_translator.py
 * (cũng chạy trên các gói dịch thật trong assets/ và có đột biến).
 */
class R33I18nTest {

    private fun tr() = Translator(
        mapOf(
            "Mở" to "Open",
            "Lớp ({0})" to "Layers ({0})",
            "Đã xóa {0} vật thể" to "Removed {0} object(s)",
            "{0}×{1}" to "{0} by {1}",
            "Cắt {0}" to "Crop {0}",
            "Nhuộm {0}" to "Dye {0}",
            "Nâu" to "Brown",
            "{0} lớp" to "{0} layers",
            "Đã lưu {0} lớp ({1})" to "Saved {1}: {0} layers",
            "Chữ (a+b)" to "Text (a+b)"
        )
    )

    @Test fun khopChinhXacVaKhongCo() {
        val t = tr()
        assertEquals("Open", t.lookup("Mở"))
        assertNull(t.lookup("Xyz"))
        assertEquals("Xyz", t.translate("Xyz"))
        assertNull(t.lookup(""))
        assertNull(t.lookup("Mở" + "x".repeat(500)))      // chuỗi quá dài không tra
    }

    @Test fun khopMauVaChoTrong() {
        val t = tr()
        assertEquals("Layers (3)", t.lookup("Lớp (3)"))
        assertEquals("Saved nháp: 5 layers", t.lookup("Đã lưu 5 lớp (nháp)"))   // đảo thứ tự chỗ trống trong bản dịch
        assertEquals("1920 by 1080", t.lookup("1920×1080"))
        assertEquals("Crop 16:9", t.lookup("Cắt 16:9"))                          // số / tên riêng giữ nguyên
        assertEquals("Layers (a\nb)", t.lookup("Lớp (a\nb)"))                   // nhiều dòng
        assertEquals("Text (a+b)", t.lookup("Chữ (a+b)"))                       // ký tự regex được thoát
    }

    @Test fun phanTrongChoTrongDuocDichNeuLaKhoa() {
        assertEquals("Dye Brown", tr().lookup("Nhuộm Nâu"))
    }

    @Test fun mauCuTheThangMauNgan() {
        // "{0} lớp" có ít chữ cố định hơn "Đã xóa {0} vật thể": mẫu cụ thể phải được thử trước
        assertEquals("Removed 2 object(s)", tr().lookup("Đã xóa 2 vật thể"))
    }

    @Test fun khopChinhXacThangKhopMau() {
        val t = Translator(mapOf("Lớp (1)" to "Layer one", "Lớp ({0})" to "Layers ({0})"))
        assertEquals("Layer one", t.lookup("Lớp (1)"))
        assertEquals("Layers (2)", t.lookup("Lớp (2)"))
    }

    @Test fun banDichRongBiBoQua() {
        assertNull(Translator(mapOf("A" to "")).lookup("A"))
    }

    @Test fun ketQuaNhoDemGiongNhau() {
        val t = tr()
        assertEquals(t.lookup("Lớp (9)"), t.lookup("Lớp (9)"))
        assertNull(t.lookup("Chuỗi lạ 1"))
        assertNull(t.lookup("Chuỗi lạ 1"))
    }

    // ------------------------------------------------------------------ ngôn ngữ
    @Test fun ngonNguTuDongVaHoTro() {
        assertEquals("vi", AppLanguages.resolveAuto("vi"))
        assertEquals("zh", AppLanguages.resolveAuto("zh"))
        assertEquals("id", AppLanguages.resolveAuto("in"))       // Android cũ trả "in" cho tiếng Indonesia
        assertEquals("en", AppLanguages.resolveAuto("th"))       // chưa hỗ trợ ⇒ tiếng Anh
        assertEquals("en", AppLanguages.resolveAuto("EN"))
        assertEquals("ja", AppLanguages.resolve("ja", "vi"))
        assertEquals("fr", AppLanguages.resolve("xx", "fr"))     // mã lạ ⇒ như tự động
        assertEquals("de", AppLanguages.resolve(AppLanguages.AUTO, "de"))
    }

    @Test fun danhSachNgonNguDayDu() {
        val codes = AppLanguages.ALL.map { it.code }
        assertEquals(listOf("vi", "en", "zh", "es", "hi", "ar", "pt", "ru", "ja", "ko", "fr", "de", "id"), codes)
        assertEquals(codes.size, codes.toSet().size)
        assertTrue(AppLanguages.byCode("ar")!!.rtl)
        assertEquals(listOf("ar"), AppLanguages.ALL.filter { it.rtl }.map { it.code })
        assertNotNull(AppLanguages.byCode(AppLanguages.SOURCE))
    }

    // ------------------------------------------------------------------ Trợ giúp
    @Test fun phanTichVaLocTroGiup() {
        val json = """{"sections":[
            {"title":"Bắt đầu","items":[{"t":"Mở ảnh","b":"Bấm Mở"},{"t":"Lưu","b":"Xuất ra thư viện"}]},
            {"title":"Màu","items":[{"t":"Cân bằng","b":"ấm lạnh"}]}]}"""
        val secs = HelpContent.parse(json)
        assertEquals(2, secs.size)
        assertEquals(listOf(2, 1), secs.map { it.items.size })
        assertEquals(secs, HelpContent.filter(secs, "  "))
        assertEquals(listOf("Bắt đầu"), HelpContent.filter(secs, "thư viện").map { it.title })
        assertEquals(1, HelpContent.filter(secs, "thư viện")[0].items.size)
        assertEquals(2, HelpContent.filter(secs, "bắt đầu")[0].items.size)            // khớp tiêu đề nhóm ⇒ giữ cả nhóm
        assertEquals(listOf("Màu"), HelpContent.filter(secs, "ẤM LẠNH").map { it.title })
        assertEquals(listOf("Bắt đầu"), HelpContent.filter(secs, "mo anh").map { it.title })  // không phân biệt dấu
        assertEquals(2, HelpContent.filter(secs, "ẤM").size)                         // "ẤM" cũng khớp "Bấm" — đúng thiết kế
        assertTrue(HelpContent.filter(secs, "zzz").isEmpty())
        assertEquals("tho", HelpContent.fold("Thở"))
        assertEquals("dd", HelpContent.fold("Đđ"))
    }

    @Test fun locTroGiupTiengTayBanNha() {
        val secs = listOf(HelpSection("x", listOf(HelpItem("cámara", "b"))))
        assertEquals(1, HelpContent.filter(secs, "camara").size)
        assertFalse(HelpContent.filter(secs, "camaras").isNotEmpty())
    }
}
