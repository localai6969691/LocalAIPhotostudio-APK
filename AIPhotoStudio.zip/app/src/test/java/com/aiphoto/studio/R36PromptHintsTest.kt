package com.aiphoto.studio

import com.aiphoto.studio.ai.LlmPrompts
import com.aiphoto.studio.ai.OpType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** R36: dòng mô tả "phép hiếm" chỉ chèn vào prompt LLM khi câu lệnh có từ khóa. Cùng ca với phần R36 của tools/verify_ports/llm_prompts.py. */
class R36PromptHintsTest {
    private val ordinary = listOf(
        "làm da mịn và sáng hơn, tông ấm", "xóa nền, nền trắng", "nhuộm tóc màu nâu",
        "make it black and white with strong contrast", "làm đẹp tự nhiên cho ảnh chân dung", "sáng hơn, trời xanh hơn"
    )

    @Test fun ordinaryRequestsAddNothingSoThePromptIsTheOriginal() {
        for (r in ordinary) assertTrue(r, LlmPrompts.extraOpLines(r).isEmpty())
        // khi không có từ khóa, mọi thứ trước dòng Request cuối cùng giống hệt nhau
        val a = LlmPrompts.plan("làm da mịn")
        val b = LlmPrompts.plan("xóa nền")
        assertEquals(a.substringBeforeLast("Request:"), b.substringBeforeLast("Request:"))
    }

    @Test fun keywordInsertsItsLineBeforeTheScopeLineAndKeepsTheRequestLast() {
        val p = LlmPrompts.plan("khử nhiễu")
        val line = LlmPrompts.extraOpLines("khử nhiễu").single()
        assertTrue(line.startsWith("denoise:"))
        assertTrue(p.contains(line))
        assertTrue(p.indexOf("style: value") < p.indexOf(line))
        assertTrue(p.indexOf(line) < p.indexOf("Optional"))
        assertTrue(p.trimEnd().endsWith("Request: \"khử nhiễu\""))
    }

    @Test fun matchingIsAccentAndCaseInsensitiveAndWholeWord() {
        assertEquals(1, LlmPrompts.extraOpLines("KHỬ NHIỄU ảnh").size)
        assertEquals(1, LlmPrompts.extraOpLines("thêm hạt film").size)
        assertEquals(1, LlmPrompts.extraOpLines("please replace the sky").size)
        assertTrue(LlmPrompts.extraOpLines("make the flares dark").isEmpty())   // "flares" không phải từ "flare"
        assertTrue(LlmPrompts.extraOpLines("grained texture").isEmpty())
    }

    @Test fun neverMoreThanMaxExtraLines() {
        val many = LlmPrompts.extraOpLines("khử nhiễu, thêm hạt film, thay trời, chỉnh thẳng, lens flare")
        assertEquals(LlmPrompts.MAX_EXTRA_LINES, many.size)
    }

    @Test fun everyHintNamesARealOpAndNoneIsAlreadyInTheBasePrompt() {
        val keys = OpType.values().map { it.key }.toSet()
        val base = LlmPrompts.plan("x")
        val probes = listOf("clarity", "hue", "grain", "denoise", "dust", "frequency separation", "motion blur", "radial blur", "straighten", "lens flare", "duotone", "sky replace")
        for (probe in probes) {
            val line = LlmPrompts.extraOpLines(probe).singleOrNull() ?: throw AssertionError("$probe: không có đúng một dòng")
            val op = line.substringBefore(':')
            assertTrue("$op không phải khóa OpType", op in keys)
            assertFalse("$op đã có sẵn trong prompt gốc", base.contains("\n$op:") || base.contains(", $op,") || base.contains("\n$op,"))
        }
    }

    @Test fun imagePlanStillEndsWithThePlanPrompt() {
        val p = LlmPrompts.imagePlan("thay trời hoàng hôn")
        assertTrue(p.endsWith(LlmPrompts.plan("thay trời hoàng hôn")))
        assertTrue(p.contains("sky_replace:"))
    }
}
