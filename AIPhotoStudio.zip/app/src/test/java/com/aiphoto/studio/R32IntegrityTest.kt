package com.aiphoto.studio

import com.aiphoto.studio.integrity.IntegrityCoordinator
import com.aiphoto.studio.integrity.IntegrityHash
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R32: phần THUẦN của client Play Integrity. Các giá trị băm đã đối chiếu với `hashlib.sha256(b"dev|abc").hexdigest()` của Python (cùng công thức với
 * backend/integrity.py `expected_request_hash`) — nếu hai phía lệch nhau thì mọi lần chứng thực đều thất bại.
 */
class R32IntegrityTest {

    @Test fun requestHashKhopVoiMayChu() {
        assertEquals("b00c54cfb501b2c769b5b87f795912a3c20cd4eb1945a061dc4e3a5763e976c9", IntegrityHash.forChallenge("dev", "abc"))
        assertEquals("3460649385708acb86df9dbe73a93eba90db0f9c05dc003b744545d18cedbea1", IntegrityHash.forChallenge("device-12345678", "0123456789abcdef"))
    }

    @Test fun requestHashDaiDungVaPhuThuocCaHaiDauVao() {
        val a = IntegrityHash.forChallenge("d1", "c")
        assertEquals(64, a.length)
        assertTrue(a.all { it in '0'..'9' || it in 'a'..'f' })
        assertFalse(a == IntegrityHash.forChallenge("d2", "c"))
        assertFalse(a == IntegrityHash.forChallenge("d1", "c2"))
    }

    @Test fun dieuPhoiChiChungThucMotLanTrongCuaSoTuoi() {
        var t = 1_000L
        var calls = 0
        val c = IntegrityCoordinator({ t }, 60_000L)
        assertTrue(c.ensure { calls++; true })
        assertEquals(1, calls)
        t += 59_000
        assertTrue(c.ensure { calls++; true })           // còn tươi: không chứng thực lại, báo đã ổn để thử lại lệnh gốc
        assertEquals(1, calls)
        t += 2_000                                        // hết cửa sổ tươi
        assertTrue(c.ensure { calls++; true })
        assertEquals(2, calls)
    }

    @Test fun chungThucThatBaiKhongDuocGhiNhoVaNgoaiLeLaThatBai() {
        var t = 0L
        var calls = 0
        val c = IntegrityCoordinator({ t }, 60_000L)
        assertFalse(c.ensure { calls++; false })
        assertFalse(c.ensure { calls++; throw IllegalStateException("mạng lỗi") })
        assertEquals(2, calls)                            // thất bại thì lần sau vẫn thử lại
        assertTrue(c.ensure { calls++; true })
        assertEquals(3, calls)
    }
}
