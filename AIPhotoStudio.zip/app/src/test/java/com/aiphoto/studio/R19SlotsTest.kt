package com.aiphoto.studio

import com.aiphoto.studio.doc.ProjectSlots
import java.io.File
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** R19: nhiều phiên làm việc (ProjectSlots) — liệt kê, dọn bớt, chuyển phiên bản cũ, chống đường dẫn độc. */
class R19SlotsTest {

    private lateinit var files: File

    @Before fun setUp() { files = java.nio.file.Files.createTempDirectory("slots").toFile() }
    @After fun tearDown() { files.deleteRecursively() }

    private fun makeSlot(id: String, savedAt: Long, layers: Int = 2, validBg: Boolean = true, root: File = ProjectSlots.root(files)) {
        val d = File(root, id)
        d.mkdirs()
        val arr = (0 until layers).joinToString(",") { """{"id":$it}""" }
        File(d, "meta.json").writeText("""{"v":1,"savedAt":$savedAt,"w":640,"h":480,"bg":"bg_$id.png","idCounter":9,"layers":[$arr]}""")
        if (validBg) File(d, "bg_$id.png").writeBytes(byteArrayOf(1, 2, 3))
    }

    @Test fun listIsNewestFirstAndSkipsBrokenSlots() {
        makeSlot("a", 1000)
        makeSlot("b", 3000, layers = 5)
        makeSlot("c", 2000)
        makeSlot("broken", 9999, validBg = false)                       // thiếu ảnh nền -> không đọc được
        File(ProjectSlots.root(files), "junk").mkdirs()                  // không có meta
        val l = ProjectSlots.list(files)
        assertEquals(listOf("b", "c", "a"), l.map { it.id })
        assertEquals(5, l[0].info.layerCount)
        assertEquals(640, l[0].info.w)
    }

    @Test fun evictKeepsNewestAndNeverTheProtectedOne() {
        for (i in 1..8) makeSlot("s$i", i * 1000L)
        val removed = ProjectSlots.evict(files, keep = 5, protect = "s1")   // s1 là cũ nhất nhưng đang làm việc
        val left = ProjectSlots.list(files).map { it.id }.toSet()
        assertEquals(5, left.size)
        assertTrue("s1" in left)
        assertEquals(setOf("s1", "s8", "s7", "s6", "s5"), left)
        assertEquals(setOf("s2", "s3", "s4"), removed.toSet())
        for (id in removed) assertFalse(File(ProjectSlots.root(files), id).exists())
    }

    @Test fun evictRemovesBrokenSlotsButNotTheWorkingOne() {
        makeSlot("ok", 1000)
        makeSlot("bad", 2000, validBg = false)
        File(ProjectSlots.root(files), "work").mkdirs()                   // ngăn đang làm việc, chưa ghi meta lần nào
        ProjectSlots.evict(files, keep = 5, protect = "work")
        assertFalse(File(ProjectSlots.root(files), "bad").exists())
        assertTrue(File(ProjectSlots.root(files), "work").exists())
        assertTrue(File(ProjectSlots.root(files), "ok").exists())
    }

    @Test fun newIdsNeverCollide() {
        val a = ProjectSlots.newId(123456789L, emptySet())
        assertTrue(ProjectSlots.validId(a))
        val b = ProjectSlots.newId(123456789L, setOf(a))
        assertTrue(b != a && ProjectSlots.validId(b))
        val c = ProjectSlots.newId(123456789L, setOf(a, b))
        assertTrue(c != a && c != b && ProjectSlots.validId(c))
    }

    @Test fun idsCannotEscapeTheProjectsFolder() {
        for (bad in listOf("", "..", "../x", "a/b", "a\\b", "x y", "é", "a".repeat(49), ".hidden")) assertFalse("'$bad'", ProjectSlots.validId(bad))
        for (good in listOf("default", "p1a2b3", "p1a2b3-2", "A_b-9")) assertTrue(good, ProjectSlots.validId(good))
        makeSlot("keep", 1000)
        val outside = File(files, "outside").apply { mkdirs() }
        ProjectSlots.delete(files, "../outside")                         // bị từ chối, không xóa gì
        assertTrue(outside.exists())
        assertTrue(File(ProjectSlots.root(files), "keep").exists())
        ProjectSlots.delete(files, "keep")
        assertFalse(File(ProjectSlots.root(files), "keep").exists())
    }

    @Test fun legacySingleSessionBecomesTheDefaultSlot() {
        val old = File(files, "project").apply { mkdirs() }
        File(old, "meta.json").writeText("""{"v":1,"savedAt":5000,"w":100,"h":80,"bg":"bg_old.png","idCounter":4,"layers":[{"id":1}]}""")
        File(old, "bg_old.png").writeBytes(byteArrayOf(9))
        ProjectSlots.migrateLegacy(files)
        assertFalse(old.exists())
        val l = ProjectSlots.list(files)
        assertEquals(listOf(ProjectSlots.DEFAULT), l.map { it.id })
        assertEquals(1, l[0].info.layerCount)
        // gọi lại không làm gì (idempotent) và không đè ngăn đã có
        ProjectSlots.migrateLegacy(files)
        assertEquals(1, ProjectSlots.list(files).size)
    }

    @Test fun migrationDoesNotOverwriteAnExistingDefaultSlot() {
        makeSlot(ProjectSlots.DEFAULT, 7000, layers = 3)
        val old = File(files, "project").apply { mkdirs() }
        File(old, "meta.json").writeText("""{"v":1,"savedAt":1,"w":1,"h":1,"bg":"x.png","layers":[]}""")
        ProjectSlots.migrateLegacy(files)
        assertEquals(3, ProjectSlots.list(files).first { it.id == ProjectSlots.DEFAULT }.info.layerCount)
        assertTrue(old.exists())   // giữ nguyên bản cũ, không mất dữ liệu
    }

    @Test fun infoOfRejectsWrongVersionAndMissingFields() {
        val d = File(files, "x").apply { mkdirs() }
        File(d, "meta.json").writeText("""{"v":2,"savedAt":1,"w":10,"h":10,"bg":"b.png"}""")
        File(d, "b.png").writeBytes(byteArrayOf(1))
        assertNull(ProjectSlots.infoOf(d))
        File(d, "meta.json").writeText("""{"v":1,"savedAt":1,"w":0,"h":10,"bg":"b.png"}""")
        assertNull(ProjectSlots.infoOf(d))
        File(d, "meta.json").writeText("not json")
        assertNull(ProjectSlots.infoOf(d))
        File(d, "meta.json").writeText("""{"v":1,"savedAt":1,"w":10,"h":10,"bg":"b.png"}""")
        assertNotNull(ProjectSlots.infoOf(d))
    }
}
