package com.aiphoto.studio

import com.aiphoto.studio.models.NetKind
import com.aiphoto.studio.models.NetworkPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** R44: quy tắc "chỉ tải bằng Wi-Fi" — bảng quyết định đầy đủ (loại mạng × cài đặt × "lần này"). */
class R44NetworkPolicyTest {
    @Test fun classifyFollowsInternetThenMeteredFlag() {
        assertEquals(NetKind.OFFLINE, NetworkPolicy.classify(hasInternet = false, notMetered = true))
        assertEquals(NetKind.OFFLINE, NetworkPolicy.classify(hasInternet = false, notMetered = false))
        assertEquals(NetKind.UNMETERED, NetworkPolicy.classify(hasInternet = true, notMetered = true))
        assertEquals(NetKind.METERED, NetworkPolicy.classify(hasInternet = true, notMetered = false))
    }

    @Test fun unmeteredAlwaysAllowed() {
        for (wifiOnly in listOf(true, false)) for (once in listOf(true, false))
            assertTrue(NetworkPolicy.allows(wifiOnly, once, NetKind.UNMETERED))
    }

    @Test fun offlineNeverAllowed() {
        for (wifiOnly in listOf(true, false)) for (once in listOf(true, false))
            assertFalse(NetworkPolicy.allows(wifiOnly, once, NetKind.OFFLINE))
    }

    @Test fun meteredNeedsWifiOnlyOffOrOneShotPermission() {
        assertFalse(NetworkPolicy.allows(wifiOnly = true, allowMeteredNow = false, kind = NetKind.METERED))
        assertTrue(NetworkPolicy.allows(wifiOnly = true, allowMeteredNow = true, kind = NetKind.METERED))
        assertTrue(NetworkPolicy.allows(wifiOnly = false, allowMeteredNow = false, kind = NetKind.METERED))
    }

    @Test fun waitReasonNamesTheRightCause() {
        assertEquals(NetworkPolicy.Wait.WIFI, NetworkPolicy.waitReason(true, false, NetKind.METERED))
        assertEquals(NetworkPolicy.Wait.NETWORK, NetworkPolicy.waitReason(true, false, NetKind.OFFLINE))
        assertEquals(NetworkPolicy.Wait.NETWORK, NetworkPolicy.waitReason(false, true, NetKind.OFFLINE))
        assertNull(NetworkPolicy.waitReason(true, false, NetKind.UNMETERED))
        assertNull(NetworkPolicy.waitReason(false, false, NetKind.METERED))
        assertNull(NetworkPolicy.waitReason(true, true, NetKind.METERED))
    }
}
