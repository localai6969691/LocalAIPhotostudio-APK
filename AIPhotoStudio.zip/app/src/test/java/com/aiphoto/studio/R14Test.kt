package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.billing.BILLING_PRODUCTS
import com.aiphoto.studio.billing.BILLING_SUBSCRIPTIONS
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.Blend
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.Layer
import com.aiphoto.studio.doc.ProjectCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R14: 21 chế độ hòa trộn (kỳ vọng tính bằng tools/verify_ports/blend_modes.py, đối chiếu đặc tả W3C). */
class R14Test {

    private fun one(mode: BlendMode, base: Long, top: Long, opacity: Float = 1f): Int =
        Blend.blend(intArrayOf(base.toInt()), intArrayOf(top.toInt()), mode, opacity, null)[0]

    // ------------------------------------------------------------------ Blend mode
    @Test fun blendHas21ModesAndFourNonSeparable() {
        assertEquals(21, BlendMode.values().size)
        assertEquals(
            listOf(BlendMode.HUE, BlendMode.SATURATION, BlendMode.COLOR, BlendMode.LUMINOSITY),
            BlendMode.values().filter { !it.separable }
        )
        // 9 chế độ cũ giữ nguyên thứ tự đầu danh sách (ProjectCodec lưu theo tên nhưng giao diện/lịch sử dựa vào đó)
        assertEquals(BlendMode.NORMAL, BlendMode.values()[0])
        assertEquals(BlendMode.LIGHTEN, BlendMode.values()[8])
        assertEquals(BlendMode.NORMAL, BlendMode.LUMINOSITY.next())     // vòng lặp quay về đầu
    }

    @Test fun blendExactPixelsMatchSpec() {
        assertEquals(0xFF666666.toInt(), one(BlendMode.DIFFERENCE, 0xFF336699, 0xFF99CC33))          // |a-b| từng kênh
        assertEquals(0xFF7F7F7F.toInt(), one(BlendMode.EXCLUSION, 0xFF808080, 0xFF808080))
        assertEquals(0xFFC2C2C2.toInt(), one(BlendMode.HARD_LIGHT, 0xFF666666, 0xFFCCCCCC))          // .4 + .6 - .24 = .76
        // biên W3C (R14 sửa): nền đen luôn đen với Color Dodge, nền trắng luôn trắng với Color Burn
        assertEquals(0xFF000000.toInt(), one(BlendMode.COLOR_DODGE, 0xFF000000, 0xFFFFFFFF))
        assertEquals(0xFFFFFFFF.toInt(), one(BlendMode.COLOR_BURN, 0xFFFFFFFF, 0xFF000000))
        // Luminosity với lớp trên trắng -> trắng; Color với lớp trên xám -> xám có độ chói của nền (0.3R+0.59G+0.11B = 111.65 -> 112)
        assertEquals(0xFFFFFFFF.toInt(), one(BlendMode.LUMINOSITY, 0xFFCC4C33, 0xFFFFFFFF))
        assertEquals(0xFF707070.toInt(), one(BlendMode.COLOR, 0xFFCC4C33, 0xFF808080))
    }

    @Test fun blendClampsBeforeOpacityMix() {
        // Linear Dodge: .898 + .502 = 1.4 -> kẹp 1.0 RỒI mới trộn 50%: 229 + (255-229)/2 = 242 (không phải 255)
        assertEquals(0xFFF2F2F2.toInt(), one(BlendMode.LINEAR_DODGE, 0xFFE5E5E5, 0xFF808080, 0.5f))
    }

    @Test fun blendSelfMixIsIdentityForNonSeparable() {
        for (m in listOf(BlendMode.HUE, BlendMode.SATURATION, BlendMode.COLOR, BlendMode.LUMINOSITY))
            assertEquals("$m", 0xFFCC4C33.toInt(), one(m, 0xFFCC4C33, 0xFFCC4C33))
    }

    @Test fun blendOpacityMaskAndAlpha() {
        val base = 0xCC808080
        val top = 0xFF404040
        assertEquals(base.toInt(), one(BlendMode.MULTIPLY, base, top, 0f))
        assertEquals(base.toInt(), Blend.blend(intArrayOf(base.toInt()), intArrayOf(top.toInt()), BlendMode.HUE, 1f, floatArrayOf(0f))[0])
        assertEquals(base.toInt(), one(BlendMode.SCREEN, base, top, 0.0005f))                       // dưới ngưỡng 0.001
        assertEquals(0xCC404040.toInt(), one(BlendMode.NORMAL, base, top))                           // alpha lấy từ NỀN
        for (m in BlendMode.values())                                                                // mọi chế độ giữ alpha nền
            assertEquals("$m", 0xCC, (one(m, base, top, 0.7f) ushr 24) and 255)
    }

    // ------------------------------------------------------------------ Lưu / khôi phục phiên với chế độ mới
    private fun encodeLayers(layers: List<Layer>): org.json.JSONObject =
        ProjectCodec.encode(
            ProjectCodec.Meta(1234L, 200, 100, "bg_1.png", 42L), layers,
            patchFile = { error("không có lớp vá trong test") },
            maskFile = { _, _ -> error("không có mặt nạ tô tay trong test") },
            imageFile = { error("không có ảnh phủ trong test") }
        )

    private fun decodeLayers(json: org.json.JSONObject) =
        ProjectCodec.decode(json, 200, 100, loadPatch = { null }, loadMask = { _, _, _ -> null })

    @Test fun everyBlendModeSurvivesProjectRoundTrip() {
        val layers = BlendMode.values().mapIndexed { i, m ->
            AdjustmentLayer((i + 1).toLong(), "L$i", listOf(EditOp(OpType.BRIGHTNESS, 0.1f)), blend = m) as Layer
        }
        val back = decodeLayers(org.json.JSONObject(encodeLayers(layers).toString()))
        assertEquals(0, back.skipped)
        assertEquals(BlendMode.values().toList(), back.layers.map { it.blend })
    }

    @Test fun unknownBlendNameFallsBackToNormal() {
        val layers = listOf<Layer>(AdjustmentLayer(1L, "x", listOf(EditOp(OpType.BRIGHTNESS, 0.2f)), blend = BlendMode.MULTIPLY))
        val text = encodeLayers(layers).toString().replace("\"blend\":\"MULTIPLY\"", "\"blend\":\"CHE_DO_TUONG_LAI\"")
        assertFalse(text.contains("MULTIPLY"))
        val back = decodeLayers(org.json.JSONObject(text))
        assertEquals(1, back.layers.size)
        assertEquals(BlendMode.NORMAL, back.layers[0].blend)
        assertTrue(back.layers[0] is AdjustmentLayer)
    }

    // ------------------------------------------------------------------ Mã gói thanh toán (khớp mặc định backend; static_check cũng kiểm)
    @Test fun billingProductIdsAreConsistent() {
        assertEquals(listOf("pro_monthly", "pro_yearly"), BILLING_SUBSCRIPTIONS)
        assertTrue(BILLING_PRODUCTS.none { it in BILLING_SUBSCRIPTIONS })       // mua một lần và đăng ký định kỳ không trùng mã
        assertEquals(setOf("credits_20", "credits_100", "pro_30d", "pro_365d"), BILLING_PRODUCTS.toSet())
    }
}
