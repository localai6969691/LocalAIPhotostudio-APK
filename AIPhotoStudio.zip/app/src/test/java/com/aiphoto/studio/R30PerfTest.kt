package com.aiphoto.studio

import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.PerfMeasure
import com.aiphoto.studio.routing.PerfModel
import com.aiphoto.studio.routing.PerfProfile
import com.aiphoto.studio.routing.Tier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R30g: hồ sơ hiệu năng SUY RA từ số đo thật của máy ([PerfModel] / [PerfProfile.derive]) thay cho bảng ba hạng theo tổng RAM. Mọi khẳng định đã được bản port Python
 * `tools/verify_ports/perf_model.py` kiểm với cùng hằng số (đọc từ mã Kotlin) trên lưới 420 máy giả lập. Phần đo thật (`PerfCalibrator`) cần Android nên không kiểm được trên JVM.
 */
class R30PerfTest {
    private val mb = 1024L * 1024

    private fun m(ms: Double, hz: Float, heapMb: Long, availMb: Int) = PerfMeasure(ms, hz, heapMb * mb, availMb)

    @Test fun oldTableStillWorksAsTheStartingValueBeforeTheDeviceIsMeasured() {
        assertEquals(Tier.LOW, PerfProfile.from(DeviceInfo(2000, "", 30, 8), emptyMap()).tier)
        assertEquals(Tier.HIGH, PerfProfile.from(DeviceInfo(12000, "", 34, 8), emptyMap()).tier)
        assertEquals(2, PerfProfile.from(DeviceInfo(2000, "", 30, 4), emptyMap()).poolCapacity)
        assertEquals(6, PerfProfile.from(DeviceInfo(12000, "", 34, 8), emptyMap()).poolCapacity)
    }

    @Test fun constantsAreTiedToTheirSourcesInTheCode() {
        assertEquals("cùng số đếm byte heap với ImageEngine", com.aiphoto.studio.engine.ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL, PerfModel.HEAP_BYTES_PER_PIXEL)
        assertEquals("20 bản = 15 hoàn tác + 5 đang dùng", 15 + 5, PerfModel.NATIVE_BITMAPS)
        assertEquals(4 * PerfModel.NATIVE_BITMAPS, PerfModel.NATIVE_BYTES_PER_PIXEL)
        assertEquals(2560, PerfModel.SIDE_CEIL)
        assertEquals(Tier.LOW, PerfModel.tierOf(1536))
        assertEquals(Tier.MID, PerfModel.tierOf(2048))
        assertEquals(Tier.HIGH, PerfModel.tierOf(2560))
        assertTrue("khe hồ model ≈ 511 MB × 1,3", Math.abs(PerfModel.POOL_SLOT_MB - 511 * 1.3) <= 10)
    }

    @Test fun sideForBudgetIsTheLargestSideWithinTheBudget() {
        for (ms in listOf(10.0, 25.0, 60.0, 120.0, 250.0, 600.0, 1500.0)) {
            for (budget in listOf(8.3, 50.0, 100.0, 3000.0)) {
                val s = PerfModel.sideForBudget(ms, budget)
                val px = s * (s / PerfModel.ASPECT)
                val px2 = (s + 2) * ((s + 2) / PerfModel.ASPECT)
                assertTrue("ms=$ms budget=$budget s=$s: ${px / 1e6 * ms} ms", px / 1e6 * ms <= budget * 1.0001)
                assertTrue("cạnh +2 phải đã vượt ngân sách", px2 / 1e6 * ms > budget)
            }
        }
        assertEquals(0, PerfModel.sideForBudget(0.0, 100.0))
        assertEquals(0, PerfModel.sideForBudget(-5.0, 100.0))
        assertEquals(0, PerfModel.sideForBudget(Double.NaN, 100.0))
        assertEquals(0, PerfModel.sideForBudget(50.0, 0.0))
    }

    @Test fun maxSideIsTheSmallestOfTimeHeapAndNativeMemoryAndRespectsAllThree() {
        for (ms in listOf(10.0, 60.0, 250.0, 1500.0)) {
            for (heap in listOf(64L, 128L, 256L, 512L)) {
                for (avail in listOf(500, 1000, 2000, 4000, 8000)) {
                    val meas = m(ms, 60f, heap, avail)
                    val s = PerfModel.maxSide(meas)
                    val t = PerfModel.sideForBudget(ms * PerfModel.BAKE_CHAIN_FACTOR, PerfModel.BAKE_MS)
                    val h = PerfModel.sideForMemory(heap * mb.toDouble(), PerfModel.HEAP_SAFETY, PerfModel.HEAP_BYTES_PER_PIXEL)
                    val n = PerfModel.sideForMemory(avail * mb.toDouble(), PerfModel.NATIVE_SHARE, PerfModel.NATIVE_BYTES_PER_PIXEL)
                    assertEquals("ms=$ms heap=$heap avail=$avail", minOf(t, h, n).coerceIn(PerfModel.SIDE_FLOOR, PerfModel.SIDE_CEIL), s)
                    if (s > PerfModel.SIDE_FLOOR) {
                        val px = s.toDouble() * s / PerfModel.ASPECT
                        assertTrue(px / 1e6 * ms * PerfModel.BAKE_CHAIN_FACTOR <= PerfModel.BAKE_MS * 1.001)
                        assertTrue(px * PerfModel.HEAP_BYTES_PER_PIXEL <= heap * mb * PerfModel.HEAP_SAFETY * 1.001)
                        assertTrue(px * PerfModel.NATIVE_BYTES_PER_PIXEL <= avail * mb * PerfModel.NATIVE_SHARE * 1.001)
                    }
                }
            }
        }
    }

    @Test fun derivedProfileIsOrderedBoundedAndMonotone() {
        var prevSide = Int.MAX_VALUE
        for (ms in listOf(10.0, 25.0, 60.0, 120.0, 250.0, 600.0, 1500.0)) {
            val d = PerfProfile.derive(DeviceInfo(8000, "", 33, 8), m(ms, 60f, 256, 4000), emptyMap())
            assertTrue("kéo ≤ thả ≤ cạnh làm việc: $d", d.previewLo <= d.previewHi && d.previewHi <= d.maxSide)
            assertTrue(d.maxSide in PerfModel.SIDE_FLOOR..PerfModel.SIDE_CEIL)
            assertTrue(d.poolCapacity in 1..12 && d.threads in 1..4)
            assertTrue("máy chậm hơn không nhận cạnh lớn hơn", d.maxSide <= prevSide)
            prevSide = d.maxSide
        }
        val hz60 = PerfModel.previewLo(m(120.0, 60f, 0, 0))
        val hz120 = PerfModel.previewLo(m(120.0, 120f, 0, 0))
        assertTrue("120 Hz không lớn hơn 60 Hz", hz120 <= hz60)
        assertTrue("ví dụ 120 ms/MP, 60 Hz → kéo ≈ 745", Math.abs(hz60 - 745) <= 8)
        assertTrue("ví dụ 120 ms/MP → thả ≈ 1054", Math.abs(PerfModel.previewHi(m(120.0, 60f, 0, 0)) - 1054) <= 8)
        val fastBig = PerfProfile.derive(DeviceInfo(12000, "", 34, 8), m(40.0, 120f, 256, 5000), emptyMap())
        val slowSmall = PerfProfile.derive(DeviceInfo(3000, "", 30, 8), m(1200.0, 60f, 96, 400), emptyMap())
        assertEquals(Tier.HIGH, fastBig.tier)
        assertEquals(Tier.LOW, slowSmall.tier)
    }

    @Test fun poolSlotsThreadsAndBlendBehave() {
        assertEquals(listOf(5, 1, 1, 12), listOf(PerfModel.poolSlots(8000), PerfModel.poolSlots(2000), PerfModel.poolSlots(500), PerfModel.poolSlots(40000)))
        assertEquals(listOf(1, 3, 4, 1), listOf(PerfModel.threads(1), PerfModel.threads(3), PerfModel.threads(8), PerfModel.threads(0)))
        assertEquals(80.0, PerfModel.blend(0.0, 80.0), 0.0)
        assertEquals("nhanh hơn nhận ngay", 60.0, PerfModel.blend(100.0, 60.0), 0.0)
        assertEquals("chậm hơn chỉ đẩy lên 5%", 105.0, PerfModel.blend(100.0, 500.0), 1e-9)
        var v = 100.0
        var n = 0
        while (v < 500.0 - 1e-9 && n < 100) { v = PerfModel.blend(v, 500.0); n++ }
        assertTrue("máy thật sự chậm đi được phản ánh sau $n lần", n <= 40)
    }

    @Test fun overridesFromRoutingStillApplyToTheDerivedProfile() {
        val meas = m(120.0, 60f, 256, 2500)
        val base = PerfProfile.derive(DeviceInfo(8000, "", 33, 8), meas, emptyMap())
        val over = PerfProfile.derive(DeviceInfo(8000, "", 33, 8), meas, mapOf(base.tier.name.lowercase() to mapOf("maxSide" to "1200", "pool" to "3")))
        assertEquals(1200, over.maxSide)
        assertEquals(3, over.poolCapacity)
    }
}
