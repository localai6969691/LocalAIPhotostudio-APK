package com.aiphoto.studio

import com.aiphoto.studio.engine.Pt
import com.aiphoto.studio.engine.Sketch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** R26 Sketch-to-image: lõi vẽ nét màu → lớp ARGB, ảnh dẫn, mặt nạ, tên màu, câu lệnh. Không gọi model. */
class R26SketchTest {

    private val W = 120
    private val H = 80
    private val RED = 0xFFE53935.toInt()
    private val BLUE = 0xFF1E88E5.toInt()

    private fun alpha(p: Int) = p ushr 24
    private fun rgb(p: Int) = p and 0xFFFFFF
    private fun pt(x: Float, y: Float) = Pt(x / W, y / H)          // toạ độ điểm ảnh → chuẩn hóa
    private val brush = 5f / 120f                                    // bán kính 5 điểm ảnh ở khung 120 (cạnh dài)

    /** Đáp án tham chiếu: độ phủ = clamp(r + 0,5 − khoảng cách tới đường gấp khúc). */
    private fun oracle(poly: List<Pair<Float, Float>>, r: Float, x: Int, y: Int): Float {
        val cx = x + 0.5f; val cy = y + 0.5f
        var best = Float.MAX_VALUE
        if (poly.size == 1) best = sqrt((cx - poly[0].first) * (cx - poly[0].first) + (cy - poly[0].second) * (cy - poly[0].second))
        for (i in 0 until poly.size - 1) {
            val (ax, ay) = poly[i]; val (bx, by) = poly[i + 1]
            val dx = bx - ax; val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 < 1e-9f) 0f else (((cx - ax) * dx + (cy - ay) * dy) / l2).coerceIn(0f, 1f)
            val qx = ax + t * dx - cx; val qy = ay + t * dy - cy
            best = min(best, sqrt(qx * qx + qy * qy))
        }
        return (r + 0.5f - best).coerceIn(0f, 1f)
    }

    @Test fun singleDotIsADiscWithSoftEdge() {
        val s = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(RED), brush, W, H)
        assertEquals(W * H, s.size)
        assertEquals(RED, s[40 * W + 60])
        assertEquals(255, alpha(s[40 * W + 62]))                    // bên trong
        assertEquals(255, alpha(s[40 * W + 63]))                    // tâm ô (63,5; 40,5) cách (60; 40) ≈ 3,54 < r − 0,5
        assertTrue("điểm sát mép r nằm trong khoảng mờ", alpha(s[40 * W + 64]) in 200..254)   // d ≈ 4,53 ⇒ độ phủ ≈ 0,97
        assertEquals(0, alpha(s[40 * W + 67]))                      // ngoài r + 0,5
        assertEquals(0, alpha(s[10 * W + 10]))
        val edge = (50..70).map { alpha(s[40 * W + it]) }.filter { it in 1..254 }
        assertTrue("phải có điểm mép mờ", edge.isNotEmpty())
        // màu ở mép mờ giữ nguyên màu nét (không nhân alpha → không bị tối)
        for (x in 50..70) { val p = s[40 * W + x]; if (alpha(p) in 1..254) assertTrue("màu mép $x", abs(((p shr 16) and 255) - ((RED shr 16) and 255)) <= 1) }
    }

    @Test fun strokeMatchesDistanceOracleExactly() {
        val poly = listOf(20f to 15f, 50f to 60f, 90f to 25f, 100f to 70f)
        val s = Sketch.rasterize(listOf(poly.map { pt(it.first, it.second) }), listOf(BLUE), brush, W, H)
        var worst = 0f
        for (y in 0 until H) for (x in 0 until W) {
            val want = oracle(poly, 5f, x, y)
            val got = alpha(s[y * W + x]) / 255f
            worst = max(worst, abs(want - got))
        }
        assertTrue("lệch lớn nhất $worst", worst < 0.01f)
    }

    @Test fun denseCollinearPointsDoNotMakeEdgesOpaquerThanTwoPoints() {
        val two = Sketch.rasterize(listOf(listOf(pt(20f, 40f), pt(100f, 40f))), listOf(RED), brush, W, H)
        val many = Sketch.rasterize(listOf((0..80).map { pt(20f + it, 40f) }), listOf(RED), brush, W, H)
        for (i in two.indices) assertTrue("điểm $i: ${alpha(two[i])} vs ${alpha(many[i])}", abs(alpha(two[i]) - alpha(many[i])) <= 2)
    }

    @Test fun laterStrokeCoversEarlierAndColorsStaySeparate() {
        val a = listOf(pt(20f, 40f), pt(100f, 40f))             // đỏ nằm ngang
        val b = listOf(pt(60f, 10f), pt(60f, 70f))              // xanh dọc, cắt ngang
        val s = Sketch.rasterize(listOf(a, b), listOf(RED, BLUE), brush, W, H)
        assertEquals(BLUE, s[40 * W + 60])                      // chỗ cắt: nét sau đè
        assertEquals(RED, s[40 * W + 30])
        assertEquals(BLUE, s[20 * W + 60])
        assertEquals(0, alpha(s[20 * W + 30]))
        // đảo thứ tự → đảo kết quả ở chỗ cắt
        val s2 = Sketch.rasterize(listOf(b, a), listOf(BLUE, RED), brush, W, H)
        assertEquals(RED, s2[40 * W + 60])
    }

    @Test fun missingColorsUseDefaultAndAlphaOfColorIsIgnored() {
        val d = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), emptyList(), brush, W, H)
        assertEquals(Sketch.DEFAULT_COLOR, d[40 * W + 60])
        val t = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(0x00FF0000), brush, W, H)
        assertEquals(0xFFFF0000.toInt(), t[40 * W + 60])
    }

    @Test fun invalidInputsAreHarmless() {
        assertEquals(0, Sketch.rasterize(listOf(listOf(pt(1f, 1f))), listOf(RED), brush, 0, 10).size)
        assertTrue(Sketch.rasterize(emptyList(), emptyList(), brush, W, H).all { it == 0 })
        assertTrue(Sketch.rasterize(listOf(emptyList()), listOf(RED), brush, W, H).all { it == 0 })
        val nan = Sketch.rasterize(listOf(listOf(Pt(Float.NaN, 0.5f), Pt(0.5f, Float.POSITIVE_INFINITY))), listOf(RED), brush, W, H)
        assertTrue("điểm hỏng bị bỏ", nan.all { it == 0 })
        val mixed = Sketch.rasterize(listOf(listOf(Pt(Float.NaN, 0.5f), pt(60f, 40f))), listOf(RED), brush, W, H)
        assertEquals("điểm hợp lệ còn lại vẫn vẽ", RED, mixed[40 * W + 60])
        // brush hỏng → dùng mặc định, không ném lỗi
        assertEquals(RED, Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(RED), Float.NaN, W, H)[40 * W + 60])
        // điểm ngoài khung bị kẹp, không ném lỗi và không tràn mảng
        val out = Sketch.rasterize(listOf(listOf(Pt(9f, 9f), Pt(-9f, -9f))), listOf(RED), brush, W, H)
        assertEquals(W * H, out.size)
        // quá nhiều nét bị cắt: nét thứ 201 trở đi KHÔNG được vẽ, 200 nét đầu vẫn vẽ
        val many = Sketch.rasterize(List(300) { listOf(pt(if (it < Sketch.MAX_STROKES) 30f else 90f, 40f)) }, List(300) { RED }, brush, W, H)
        assertEquals(RED, many[40 * W + 30])
        assertEquals(0, alpha(many[40 * W + 90]))
    }

    @Test fun overlayBlendsOverTheBaseAndLeavesTheRestUntouched() {
        val base = IntArray(W * H) { 0xFF808080.toInt() }
        val sk = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(RED), brush, W, H)
        val g = Sketch.overlay(base, sk)
        assertNotSame(base, g)
        assertEquals(RED, g[40 * W + 60])
        assertEquals(0xFF808080.toInt(), g[5 * W + 5])
        assertEquals(0xFF808080.toInt(), base[40 * W + 60])        // ảnh gốc không bị sửa
        for (x in 50..70) {
            val a = alpha(sk[40 * W + x])
            if (a in 1..254) {
                val r = (g[40 * W + x] shr 16) and 255
                assertTrue("mép $x phải nằm giữa xám (128) và đỏ (229)", r in 128..229)
                assertEquals(255, alpha(g[40 * W + x]))
            }
        }
        assertSame(base, Sketch.overlay(base, IntArray(10)))
    }

    @Test fun maskCoversEveryStrokePixelAndGrowsByTheGivenAmount() {
        assertNull(Sketch.mask(IntArray(W * H), W, H, 3))
        assertNull(Sketch.mask(IntArray(5), W, H, 3))
        val sk = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(RED), brush, W, H)
        val m = Sketch.mask(sk, W, H, 4)!!
        for (i in sk.indices) if (alpha(sk[i]) != 0) assertTrue("điểm có nét $i phải nằm trong vùng", m[i].toInt() != 0)
        assertTrue("nới ra ngoài nét", m[40 * W + 60 + 5 + 3].toInt() != 0)
        assertEquals("quá phạm vi nới", 0, m[40 * W + 60 + 5 + 6].toInt())
        assertEquals(0, m[2 * W + 2].toInt())
    }

    @Test fun maskWithoutGrowStillIncludesTheSoftFringe() {
        val sk = Sketch.rasterize(listOf(listOf(pt(60f, 40f))), listOf(RED), brush, W, H)
        val m = Sketch.mask(sk, W, H, 0)!!
        var fringe = 0
        for (i in sk.indices) {
            val a = alpha(sk[i])
            if (a != 0) assertTrue("điểm có nét (alpha $a) phải nằm trong vùng", m[i].toInt() != 0)
            else assertEquals(0, m[i].toInt())
            if (a in 1..127) fringe++
        }
        assertTrue("phải có điểm mép mờ để phép thử có nghĩa", fringe > 0)
    }

    @Test fun growScalesWithImageSizeAndHasAFloor() {
        assertEquals(3, Sketch.growFor(100, 80))
        assertTrue(Sketch.growFor(4000, 3000) in 20..30)
        assertTrue(Sketch.growFor(4000, 3000) > Sketch.growFor(1000, 750))
        assertEquals(Sketch.growFor(3000, 4000), Sketch.growFor(4000, 3000))
    }

    @Test fun colorNamesForThePaletteAndCommonShades() {
        val expect = mapOf(
            "Đỏ" to "red", "Cam" to "orange", "Vàng" to "yellow", "Xanh lá" to "green", "Xanh dương" to "blue",
            "Tím" to "purple", "Nâu" to "brown", "Trắng" to "white", "Đen" to "black"
        )
        for ((vi, argb) in Sketch.PALETTE) assertEquals(vi, expect[vi], Sketch.colorName(argb))
        assertEquals(9, Sketch.PALETTE.size)
        assertEquals("gray", Sketch.colorName(0xFF9E9E9E.toInt()))
        assertEquals("pink", Sketch.colorName(0xFFF48FB1.toInt()))
        assertEquals("cyan", Sketch.colorName(0xFF00BCD4.toInt()))
        assertEquals("black", Sketch.colorName(0xFF000000.toInt()))
        assertEquals("white", Sketch.colorName(0xFFFFFFFF.toInt()))
    }

    @Test fun usedColorNamesAreDistinctOrderedAndSkipEmptyOrBrokenStrokes() {
        val strokes = listOf(listOf(pt(1f, 1f)), emptyList(), listOf(pt(5f, 5f)), listOf(Pt(Float.NaN, 0f)), listOf(pt(9f, 9f)))
        val colors = listOf(BLUE, RED, RED, BLUE, BLUE)
        assertEquals(listOf("blue", "red"), Sketch.usedColorNames(strokes, colors))
        assertEquals(listOf("red"), Sketch.usedColorNames(listOf(listOf(pt(1f, 1f))), emptyList()))   // thiếu màu → mặc định đỏ
        assertTrue(Sketch.usedColorNames(emptyList(), emptyList()).isEmpty())
    }

    @Test fun instructionNamesColorsAndSubjectAndForbidsVisibleLines() {
        val t = Sketch.instruction("a tall oak tree.  ", listOf("green", "brown"))
        assertTrue(t, t.contains("green/brown"))
        assertTrue(t, t.contains("replace the sketch with a tall oak tree,"))
        assertFalse("dấu chấm cuối bị gỡ", t.contains("tree.,"))
        assertTrue(t, t.contains("must NOT show any of the sketch lines"))
        val e = Sketch.instruction("   ", emptyList())
        assertTrue(e, e.contains("colored sketch strokes"))
        assertTrue(e, e.contains("the real object the sketch depicts"))
    }

    @Test fun sdPromptIsADescriptionNotACommand() {
        assertEquals("a red sports car, highly detailed, photorealistic", Sketch.sdPrompt("a red sports car!"))
        assertEquals("a realistic object, highly detailed, photorealistic", Sketch.sdPrompt(" "))
    }

    @Test fun hasStrokesIgnoresEmptyAndBrokenStrokes() {
        assertFalse(Sketch.hasStrokes(emptyList()))
        assertFalse(Sketch.hasStrokes(listOf(emptyList(), listOf(Pt(Float.NaN, 1f)))))
        assertTrue(Sketch.hasStrokes(listOf(emptyList(), listOf(Pt(0.1f, 0.2f)))))
    }

    @Test fun largeImageWithLongSquiggleRunsAndKeepsSizes() {
        val w = 2400; val h = 1600
        val poly = (0 until 400).map { Pt(0.05f + 0.9f * it / 400f, 0.5f + 0.3f * kotlin.math.sin(it / 12f)) }
        val s = Sketch.rasterize(listOf(poly), listOf(RED), 0.02f, w, h)
        assertEquals(w * h, s.size)
        assertTrue(s.any { alpha(it) == 255 })
        val m = Sketch.mask(s, w, h, Sketch.growFor(w, h))
        assertNotNull(m)
        assertEquals(w * h, m!!.size)
    }

    @Test fun alignColorsTrimsPadsAndNeverThrows() {
        assertEquals(listOf(1, 2), Sketch.alignColors(listOf(1, 2, 3, 4), 2, 9))      // thừa → cắt từ cuối
        assertEquals(listOf(1, 2, 9, 9), Sketch.alignColors(listOf(1, 2), 4, 9))      // thiếu → thêm màu dự phòng
        assertEquals(listOf(5, 6), Sketch.alignColors(listOf(5, 6), 2, 9))
        assertTrue(Sketch.alignColors(listOf(1, 2), 0, 9).isEmpty())
        assertTrue(Sketch.alignColors(listOf(1, 2), -3, 9).isEmpty())
        assertEquals(listOf(9, 9, 9), Sketch.alignColors(emptyList(), 3, 9))
    }

    @Test fun overlayInPlaceWritesIntoTheBaseAndMatchesTheCopyingVersion() {
        val base1 = IntArray(W * H) { 0xFF808080.toInt() }
        val base2 = base1.copyOf()
        val sk = Sketch.rasterize(listOf(listOf(pt(60f, 40f), pt(90f, 40f))), listOf(BLUE), brush, W, H)
        val copied = Sketch.overlay(base1, sk)
        val inPlace = Sketch.overlay(base2, sk, copy = false)
        assertSame(base2, inPlace)
        assertTrue(copied.contentEquals(inPlace))
        assertFalse("bản sao không được đụng vào base1", base1.contentEquals(copied))
    }
}
