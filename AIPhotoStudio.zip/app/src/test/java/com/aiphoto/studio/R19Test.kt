package com.aiphoto.studio

import com.aiphoto.studio.engine.MeshWarp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R19: xoay tự do trong Free Transform (MeshWarp.rotated) + bộ giải ngược Newton của MeshWarp.warp. */
class R19Test {

    private fun argb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun red(p: Int) = (p shr 16) and 255
    private fun blue(p: Int) = p and 255

    /** ảnh trơn: R tăng theo x, B tăng theo y - nội suy song tuyến gần như chính xác nên so được với phép xoay lý thuyết. */
    private fun gradient(w: Int, h: Int) = IntArray(w * h) { argb(((it % w) * 255) / (w - 1), 128, ((it / w) * 255) / (h - 1)) }

    private fun deg(d: Double) = d * PI / 180.0

    @Test fun rotationIsRigidInPixelSpace() {
        val w = 400
        val h = 300
        val r = MeshWarp.rotated(MeshWarp.identity(4, 4), w, h, deg(20.0))
        assertEquals(deg(20.0), r.appliedRad, 1e-9)
        val cx = (w - 1) / 2.0
        val cy = (h - 1) / 2.0
        val m = r.mesh
        for (j in 0..4) for (i in 0..4) {
            val n = j * 5 + i
            val bx = i / 4.0 * (w - 1)
            val by = j / 4.0 * (h - 1)
            val qx = bx + m.d[2 * n] * w
            val qy = by + m.d[2 * n + 1] * h
            // khoảng cách tới tâm không đổi (xoay cứng), kể cả khi ảnh không vuông
            assertEquals("nút ($i,$j)", hypot(bx - cx, by - cy), hypot(qx - cx, qy - cy), 0.05)
        }
        // nút ở tâm (i=2, j=2) đứng yên
        assertEquals(0f, m.d[2 * 12], 1e-4f)
        assertEquals(0f, m.d[2 * 12 + 1], 1e-4f)
    }

    @Test fun rotatingBackRestoresTheMesh() {
        val w = 640
        val h = 480
        val start = MeshWarp.moved(MeshWarp.identity(4, 4), 1, 2, 0.05f, -0.03f) // đã có biến dạng cục bộ
        val fwd = MeshWarp.rotated(start, w, h, deg(17.0))
        val back = MeshWarp.rotated(fwd.mesh, w, h, -fwd.appliedRad)
        for (k in start.d.indices) assertEquals("phần tử $k", start.d[k], back.mesh.d[k], 2e-4f)
    }

    @Test fun warpedPixelsMatchTheoreticalRotation() {
        val w = 200
        val h = 150
        val src = gradient(w, h)
        for (angle in listOf(10.0, 20.0, -25.0)) {
            val r = MeshWarp.rotated(MeshWarp.identity(4, 4), w, h, deg(angle))
            assertEquals(deg(angle), r.appliedRad, 1e-9)
            val out = MeshWarp.warp(src, w, h, r.mesh)
            val cx = (w - 1) / 2.0
            val cy = (h - 1) / 2.0
            val c = cos(deg(angle))
            val s = sin(deg(angle))
            var worst = 0
            var counted = 0
            for (y in 0 until h) for (x in 0 until w) {
                // pixel ra (x, y) lấy từ nguồn R^-1 (x - c) + c
                val sx = cx + c * (x - cx) + s * (y - cy)
                val sy = cy - s * (x - cx) + c * (y - cy)
                if (sx < 3 || sx > w - 4 || sy < 3 || sy > h - 4) continue // vùng ngoài ảnh nguồn bị kẹp mép, không so
                val er = (sx * 255 / (w - 1)).toInt()
                val eb = (sy * 255 / (h - 1)).toInt()
                worst = maxOf(worst, abs(red(out[y * w + x]) - er), abs(blue(out[y * w + x]) - eb))
                counted++
            }
            assertTrue("góc $angle: chỉ so được $counted điểm", counted > w * h / 3)
            assertTrue("góc $angle: lệch tối đa $worst mức xám (cho phép <= 2)", worst <= 2)
        }
    }

    @Test fun oldFixedPointWouldHaveBeenWayOff() {
        // 30°: lặp điểm cố định 4 lần (cách cũ) còn sai ~ (2·sin15°)^4 ≈ 7% quãng dời; Newton phải chính xác. Đo trực tiếp trên điểm xa tâm.
        val w = 300
        val h = 300
        val src = gradient(w, h)
        val r = MeshWarp.rotated(MeshWarp.identity(6, 6), w, h, deg(30.0))
        assertEquals(deg(30.0), r.appliedRad, 1e-9)
        val out = MeshWarp.warp(src, w, h, r.mesh)
        val cx = (w - 1) / 2.0
        val cy = (h - 1) / 2.0
        val c = cos(deg(30.0))
        val s = sin(deg(30.0))
        // điểm ra gần góc, nguồn vẫn nằm trong ảnh
        val x = 250
        val y = 150
        val sx = cx + c * (x - cx) + s * (y - cy)
        val sy = cy - s * (x - cx) + c * (y - cy)
        assertTrue(sx in 3.0..(w - 4.0) && sy in 3.0..(h - 4.0))
        assertEquals((sx * 255 / (w - 1)), red(out[y * w + x]).toDouble(), 1.5)
        assertEquals((sy * 255 / (h - 1)), blue(out[y * w + x]).toDouble(), 1.5)
    }

    @Test fun hugeAngleIsLimitedNotDistorted() {
        val w = 400
        val h = 300
        val r = MeshWarp.rotated(MeshWarp.identity(4, 4), w, h, deg(85.0))
        assertTrue("phải bị thu nhỏ", r.appliedRad < deg(85.0) && r.appliedRad > deg(20.0))
        for (v in r.mesh.d) assertTrue("độ dời trong giới hạn ±0.5: $v", abs(v) <= 0.5f)
        // vẫn là xoay cứng ở góc đã áp dụng
        val cx = (w - 1) / 2.0
        val cy = (h - 1) / 2.0
        for (j in 0..4) for (i in 0..4) {
            val n = j * 5 + i
            val bx = i / 4.0 * (w - 1)
            val by = j / 4.0 * (h - 1)
            val qx = bx + r.mesh.d[2 * n] * w
            val qy = by + r.mesh.d[2 * n + 1] * h
            assertEquals(hypot(bx - cx, by - cy), hypot(qx - cx, qy - cy), 0.1)
        }
        // lưới đã xoay hết cỡ: xoay tiếp cùng chiều không đi thêm được
        val more = MeshWarp.rotated(r.mesh, w, h, deg(10.0))
        assertTrue("xoay thêm bị chặn (${more.appliedRad})", more.appliedRad < deg(2.0))
        // nhưng xoay ngược lại vẫn được
        val undo = MeshWarp.rotated(r.mesh, w, h, -r.appliedRad)
        assertEquals(-r.appliedRad, undo.appliedRad, 1e-6)
        assertTrue(MeshWarp.isIdentity(undo.mesh))
    }

    @Test fun encodeDecodeKeepsRotation() {
        val w = 400
        val h = 300
        val r = MeshWarp.rotated(MeshWarp.identity(4, 4), w, h, deg(12.0))
        val back = MeshWarp.parse(MeshWarp.encode(r.mesh))!!
        for (k in r.mesh.d.indices) assertEquals(r.mesh.d[k], back.d[k], 6e-5f)
        assertTrue(!MeshWarp.isIdentity(back))
    }

    @Test fun cornerDragStillFollowsFingerWithNewton() {
        // hành vi cũ giữ nguyên: kéo nút giữa 0.15 sang phải thì nội dung tại nút đó đi đúng 0.15·w (không chỉ ~66%)
        val w = 200
        val h = 200
        val src = IntArray(w * h) { argb(if (it % w in 98..101 && it / w in 98..101) 255 else 0, 0, 0) }
        val m = MeshWarp.moved(MeshWarp.identity(4, 4), 2, 2, 0.15f, 0f)
        val out = MeshWarp.warp(src, w, h, m)
        var sum = 0.0
        var cnt = 0.0
        for (y in 0 until h) for (x in 0 until w) { val v = red(out[y * w + x]); if (v > 100) { sum += x * v; cnt += v } }
        val cxOut = sum / cnt
        assertEquals(99.5 + 0.15 * w, cxOut, 2.0)
    }

    @Test fun warpIsFastEnoughForPreview() {
        val w = 1024
        val h = 768
        val src = gradient(w, h)
        val r = MeshWarp.rotated(MeshWarp.identity(4, 4), w, h, deg(25.0))
        val t0 = System.nanoTime()
        MeshWarp.warp(src, w, h, r.mesh)
        val ms = (System.nanoTime() - t0) / 1_000_000
        println("MeshWarp.warp xoay 25° ${w}x$h: $ms ms (JVM)")
        assertTrue("quá chậm: $ms ms", ms < 8000)
    }

    /** Tính độc lập (trong test) độ dời song tuyến tại điểm nguồn (x, y) - dùng để kiểm nghiệm của bộ giải ngược. */
    private fun disp(m: MeshWarp.Mesh, w: Int, h: Int, x: Double, y: Double): DoubleArray {
        val u = (x / (w - 1) * m.gx).coerceIn(0.0, m.gx.toDouble())
        val v = (y / (h - 1) * m.gy).coerceIn(0.0, m.gy.toDouble())
        val i0 = minOf(u.toInt(), m.gx - 1)
        val j0 = minOf(v.toInt(), m.gy - 1)
        val fu = u - i0
        val fv = v - j0
        fun node(i: Int, j: Int, c: Int) = m.d[2 * (j * (m.gx + 1) + i) + c].toDouble()
        val r = DoubleArray(2)
        for (c in 0..1) {
            r[c] = (node(i0, j0, c) * (1 - fu) * (1 - fv) + node(i0 + 1, j0, c) * fu * (1 - fv) +
                node(i0, j0 + 1, c) * (1 - fu) * fv + node(i0 + 1, j0 + 1, c) * fu * fv) * (if (c == 0) w else h)
        }
        return r
    }

    @Test fun inverseSolvesTheMappingOnRandomMeshes() {
        // ảnh mã hóa chính tọa độ: R = x, B = y (w, h <= 256 nên không mất độ chính xác) -> đọc ra s rồi kiểm s + D(s) = x
        val w = 240
        val h = 180
        val src = IntArray(w * h) { argb(it % w, 100, it / w) }
        val rnd = java.util.Random(11)
        for (trial in 0 until 12) {
            val g = 3 + trial % 4
            // biên độ ±0.04: độ dốc tối đa của trường ≈ 0.48 mỗi trục nên det(Jacobian) ≥ 0.52² - 0.48² > 0 => ánh xạ không gập, nghiệm duy nhất
            val d = FloatArray(2 * (g + 1) * (g + 1)) { (rnd.nextFloat() - 0.5f) * 0.08f }
            val m = MeshWarp.Mesh(g, g, d)
            val out = MeshWarp.warp(src, w, h, m)
            var bad = 0
            var worst = 0.0
            var checked = 0
            for (y in 2 until h - 2 step 3) for (x in 2 until w - 2 step 3) {
                val sx = red(out[y * w + x]).toDouble()
                val sy = blue(out[y * w + x]).toDouble()
                // nghiệm nằm ngoài ảnh nguồn thì bị kẹp mép (đúng thiết kế) - phương trình không còn nghiệm trong ảnh, bỏ qua
                if (sx <= 0.0 || sx >= w - 1.0 || sy <= 0.0 || sy >= h - 1.0) continue
                checked++
                val dd = disp(m, w, h, sx, sy)
                val err = hypot(sx + dd[0] - x, sy + dd[1] - y)
                worst = maxOf(worst, err)
                if (err > 1.5) bad++
            }
            assertTrue("lưới #$trial: chỉ kiểm được $checked điểm", checked > 1000)
            assertEquals("lưới #$trial (g=$g): $bad điểm sai > 1.5px, tệ nhất $worst px", 0, bad)
        }
    }
}
