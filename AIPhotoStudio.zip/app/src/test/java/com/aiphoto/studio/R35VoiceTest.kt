package com.aiphoto.studio

import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.VoiceInput
import com.aiphoto.studio.i18n.AppLanguages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R35: nhập yêu cầu bằng giọng nói — phần thuần Kotlin (chọn bản chép, làm sạch, ghép vào ô yêu cầu, thẻ ngôn ngữ).
 * Cùng ca với tools/verify_ports/voice_input.py (bản port đã chạy kèm 8 đột biến).
 */
class R35VoiceTest {
    // ------------------------------------------------------------ thẻ ngôn ngữ
    @Test fun everyAppLanguageHasARecognizerTag() {
        for (l in AppLanguages.ALL) {
            val tag = VoiceInput.languageTag(l.code)
            assertTrue("${l.code} → $tag", Regex("[a-z]{2}-[A-Z]{2}").matches(tag))
            assertEquals(l.code, tag.substringBefore('-'))
        }
    }

    @Test fun tagLookupIsForgiving() {
        assertEquals("vi-VN", VoiceInput.languageTag(" VI "))
        assertEquals("en-US", VoiceInput.languageTag("xx"))
        assertEquals("en-US", VoiceInput.languageTag(""))
    }

    // ------------------------------------------------------------ normalize
    @Test fun normalizeCollapsesWhitespaceAndTrailingPunctuation() {
        assertEquals("", VoiceInput.normalize(null))
        assertEquals("làm sáng ảnh", VoiceInput.normalize("  làm sáng   ảnh.  "))
        assertEquals("tăng sáng và ấm", VoiceInput.normalize("tăng\nsáng\t\tvà ấm ..."))
        assertEquals("", VoiceInput.normalize("..."))
        assertEquals("", VoiceInput.normalize(" . , "))
        assertEquals("Làm sáng ảnh?", VoiceInput.normalize("Làm sáng ảnh?"))
        assertEquals("mịn da", VoiceInput.normalize("mịn da , "))
        assertEquals("明るくして", VoiceInput.normalize("明るくして。"))
        assertEquals("明るくして", VoiceInput.normalize("明るくして…"))
        assertEquals("a b", VoiceInput.normalize("a\u00A0\u00A0b"))
    }

    @Test fun normalizeDropsInvisibleButKeepsJoiners() {
        assertEquals("abcd", VoiceInput.normalize("a\u200Bb\uFEFFc\u2060d"))
        assertEquals("क\u200Dष", VoiceInput.normalize("क\u200Dष"))
    }

    @Test fun normalizeCapsLengthWithoutSplittingSurrogatePairs() {
        assertEquals(VoiceInput.MAX_CHARS, VoiceInput.normalize("a".repeat(VoiceInput.MAX_CHARS + 100)).length)
        val s = VoiceInput.normalize("a".repeat(VoiceInput.MAX_CHARS - 1) + "😀😀")
        assertEquals("a".repeat(VoiceInput.MAX_CHARS - 1), s)
        assertFalse(Character.isHighSurrogate(s.last()))
    }

    // ------------------------------------------------------------ pick
    @Test fun pickHandlesEmptyInput() {
        assertNull(VoiceInput.pick(null) { true })
        assertNull(VoiceInput.pick(emptyList()) { true })
        assertNull(VoiceInput.pick(listOf("", "...")) { true })
        assertEquals("mờ phông", VoiceInput.pick(listOf("", "  ", "mờ phông")) { false })
    }

    @Test fun pickPrefersFirstUnlessLaterOneIsUnderstoodAndFirstIsNot() {
        assertEquals("làm sáng ảnh", VoiceInput.pick(listOf("làm sáng ảnh.")) { false })
        assertEquals("làm sáng ảnh", VoiceInput.pick(listOf("làm sáng anh", "làm sáng ảnh")) { it == "làm sáng ảnh" })
        assertEquals("a b", VoiceInput.pick(listOf("a b", "c d")) { true })
        assertEquals("z", VoiceInput.pick(listOf("x y.", "x y", "z")) { it == "z" })
    }

    @Test fun pickOnlyConsidersMaxResultsAndSurvivesBrokenPredicate() {
        assertEquals("1 a", VoiceInput.pick(listOf("1 a", "2 b", "3 c", "4 d")) { it == "4 d" })
        assertEquals("x", VoiceInput.pick(listOf("x", "y")) { throw IllegalStateException("lỗi bộ hiểu") })
    }

    // ------------------------------------------------------------ merge
    @Test fun mergeJoinsIntoPromptBox() {
        assertEquals("tông ấm", VoiceInput.merge("", "tông ấm"))
        assertEquals("tông ấm", VoiceInput.merge("   ", "tông ấm"))
        assertEquals("da mịn, tông ấm", VoiceInput.merge("da mịn", "tông ấm"))
        assertEquals("da mịn. tông ấm", VoiceInput.merge("da mịn.", "tông ấm"))
        assertEquals("da mịn, x", VoiceInput.merge("da mịn,", "x"))
        assertEquals("da mịn, x", VoiceInput.merge("da mịn   ", "x"))
        assertEquals("abc ", VoiceInput.merge("abc ", ""))
        assertEquals("abc", VoiceInput.merge("abc", "..."))
    }

    @Test fun mergeNeverExceedsMaxChars() {
        val m = VoiceInput.merge("a".repeat(VoiceInput.MAX_CHARS - 10), "b".repeat(50))
        assertTrue(m.length <= VoiceInput.MAX_CHARS)
        assertTrue(m.startsWith("a"))
    }

    // ------------------------------------------------------------ nối với bộ hiểu lệnh thật
    /** Cùng định nghĩa "hiểu được" như MainViewModel.voiceUnderstands (chỉ thiếu hai nhánh Auto Frame / WholeEdit). */
    private fun understands(p: String): Boolean {
        val plan = RuleBasedPlanner.plan(p)
        return plan.ops.isNotEmpty() || plan.scoped.isNotEmpty() || GenIntent.detect(p, false) != null
    }

    @Test fun pickFixesAKnownAsrConfusionWithTheRealPlanner() {
        // một bản chép đúng lệnh phải được hiểu; một bản chép vô nghĩa thì không
        assertTrue(understands("làm sáng ảnh"))
        assertFalse(understands("qwxz vbnm"))
        val picked = VoiceInput.pick(listOf("qwxz vbnm", "làm sáng ảnh", "make it brighter")) { understands(it) }
        assertNotNull(picked)
        assertEquals("làm sáng ảnh", picked)
    }

    @Test fun spokenEnglishCommandIsUnderstoodToo() {
        assertTrue(understands("make it brighter"))
        assertEquals("make it brighter", VoiceInput.pick(listOf("make it brighter.")) { understands(it) })
    }
}
