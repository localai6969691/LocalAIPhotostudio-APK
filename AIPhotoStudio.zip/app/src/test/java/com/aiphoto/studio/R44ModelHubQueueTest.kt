package com.aiphoto.studio

import com.aiphoto.studio.models.ModelEntry
import com.aiphoto.studio.models.ModelHub
import com.aiphoto.studio.models.NetKind
import com.aiphoto.studio.models.NetworkPolicy
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.nio.file.Files
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/**
 * R44: bộ điều phối tải — hàng đợi, chế độ chỉ Wi-Fi (tạm dừng / tự tải tiếp), mất mạng, thử lại lỗi thoáng qua, lưu hàng đợi, gỡ phần tải dở.
 * Chạy với máy chủ HTTP cục bộ; mạng giả lập bằng biến [net].
 */
class R44ModelHubQueueTest {
    private lateinit var server: HttpServer
    private lateinit var dir: File
    private lateinit var scope: CoroutineScope
    private val data = ByteArray(600_000) { (it * 31 + 7).toByte() }
    private val sha = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
    private val said = CopyOnWriteArrayList<String>()
    private val installed = CopyOnWriteArrayList<Pair<String, File>>()
    private val results = CopyOnWriteArrayList<Triple<String, Boolean, String>>()
    private val keep = CopyOnWriteArrayList<Boolean>()
    private val ranges = CopyOnWriteArrayList<String>()
    private val flakyHits = AtomicInteger()
    private val okHits = AtomicInteger()
    @Volatile private var net = NetKind.UNMETERED
    private val savedWifi = CopyOnWriteArrayList<Boolean>()

    private fun base() = "http://127.0.0.1:${server.address.port}"

    private fun entryJson(id: String, slot: String, path: String = "{release}/ok") =
        """{"id":"$id","slot":"$slot","name":"Model $id","file":"$id.onnx","sizeBytes":${data.size},"sha256":"$sha","urls":["$path"],"license":"Apache-2.0","licenseUrl":"https://example.com/l","vi":"mô tả","en":"desc"}"""

    private fun catalog(vararg entries: String) =
        """{"version":1,"catalogUrl":"${base()}/catalog","releaseBase":"${base()}","models":[${entries.joinToString(",")}]}"""

    private fun serve(ex: HttpExchange, slow: Boolean) {
        try {
            val rh = ex.requestHeaders.getFirst("Range")
            if (rh != null) ranges.add(rh)
            var start = 0
            var code = 200
            if (rh != null) {
                start = Regex("bytes=(\\d+)-").find(rh)!!.groupValues[1].toInt()
                code = 206
                ex.responseHeaders.add("Content-Range", "bytes $start-${data.size - 1}/${data.size}")
            }
            ex.sendResponseHeaders(code, (data.size - start).toLong())
            ex.responseBody.use { out ->
                var off = start
                while (off < data.size) {
                    val n = minOf(32_768, data.size - off)
                    out.write(data, off, n); out.flush(); off += n
                    if (slow) Thread.sleep(40)
                }
            }
        } catch (e: IOException) { /* máy khách hủy / ngắt */ }
    }


    // Máy chủ socket thô: lần kết nối ĐẦU gửi đủ tiêu đề rồi chỉ 150 KB và đóng socket (ngắt thật, client thấy EOF sớm); các lần sau phục vụ bình thường (có Range).
    private lateinit var raw: java.net.ServerSocket

    private fun startRaw() {
        raw = java.net.ServerSocket(0, 5, java.net.InetAddress.getByName("127.0.0.1"))
        Thread {
            while (!raw.isClosed) {
                val c = try { raw.accept() } catch (e: IOException) { return@Thread }
                Thread { handleRaw(c) }.apply { isDaemon = true }.start()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun handleRaw(c: java.net.Socket) {
        try {
            c.use { sock ->
                val rd = sock.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                var range: String? = null
                while (true) {
                    val line = rd.readLine() ?: return
                    if (line.isEmpty()) break
                    if (line.startsWith("Range:", ignoreCase = true)) range = line.substringAfter(":").trim()
                }
                var start = 0
                var status = "200 OK"
                var extra = ""
                if (range != null) {
                    start = Regex("bytes=(\\d+)-").find(range)!!.groupValues[1].toInt()
                    status = "206 Partial Content"
                    ranges.add(range)
                    extra = "Content-Range: bytes $start-${data.size - 1}/${data.size}\r\n"
                }
                val out = sock.getOutputStream()
                out.write("HTTP/1.1 $status\r\nContent-Length: ${data.size - start}\r\n${extra}Connection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
                val cut = flakyHits.incrementAndGet() == 1
                val end = if (cut) start + 150_000 else data.size
                out.write(data, start, end - start)
                out.flush()
            }
        } catch (e: IOException) { /* máy khách ngắt */ }
    }

    @Before fun up() {
        dir = Files.createTempDirectory("r44hub").toFile()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/ok") { okHits.incrementAndGet(); serve(it, false) }
        server.createContext("/slow") { serve(it, true) }
        startRaw()
        server.start()
    }

    @After fun down() { scope.cancel(); server.stop(0); runCatching { raw.close() }; dir.deleteRecursively() }

    private fun hub(bundled: String, wifiOnly: Boolean = false, queueFile: File? = null, retry: List<Long> = listOf(10L, 10L)) = ModelHub(
        scope = scope, workDir = File(dir, "work"), consentFile = File(dir, "licenses.txt"), catalogCache = File(dir, "cache.json"),
        bundledJson = { bundled }, slotFile = { File(dir, "models/$it.bin") },
        install = { slot, f -> installed.add(slot to File(dir, "copy_${installed.size}_${f.name}").also { c -> f.copyTo(c) }) },
        say = { said.add(it) }, allowHttp = true,
        network = { net }, wifiOnly = wifiOnly, saveWifiOnly = { savedWifi.add(it) }, queueFile = queueFile, retryDelaysMs = retry
    ).also { h ->
        h.onKeepAlive = { keep.add(it) }
        h.onResult = { e: ModelEntry, ok: Boolean, msg: String -> results.add(Triple(e.id, ok, msg)) }
    }

    private fun await(what: String, cond: () -> Boolean) {
        val end = System.currentTimeMillis() + 12_000
        while (System.currentTimeMillis() < end) { if (cond()) return; Thread.sleep(20) }
        throw AssertionError("quá hạn chờ: $what — said=$said results=$results ranges=$ranges flakyHits=${flakyHits.get()} okHits=${okHits.get()}")
    }

    private fun accept(vararg ids: String) { File(dir, "licenses.txt").writeText(ids.joinToString("\n") + "\n") }

    // ---------------------------------------------------------------- chế độ chỉ Wi-Fi

    @Test fun wifiOnlyOnMobileDataWaitsThenDownloadsWhenWifiReturns() {
        net = NetKind.METERED
        accept("a")
        val h = hub(catalog(entryJson("a", "seg")), wifiOnly = true)
        h.request("a")
        await("chờ Wi-Fi") { h.state.value.waiting == NetworkPolicy.Wait.WIFI }
        assertEquals(listOf("a"), h.state.value.queue); assertNull(h.state.value.activeId)
        assertEquals("không được chạm mạng khi chưa có Wi-Fi", 0, okHits.get())
        assertTrue(said.any { it.startsWith("Đang chờ Wi-Fi") })
        assertEquals(listOf(true), keep.toList())
        net = NetKind.UNMETERED; h.onNetworkChanged()
        await("cài đặt") { installed.isNotEmpty() }
        assertArrayEquals(data, installed[0].second.readBytes())
        await("hàng đợi rỗng") { h.state.value.queue.isEmpty() && h.state.value.activeId == null }
        assertNull(h.state.value.waiting)
        await("tắt giữ sống") { keep.lastOrNull() == false }
    }

    @Test fun allowMeteredOnceLetsDownloadProceedAndResetsAfterQueueDrains() {
        net = NetKind.METERED
        accept("a")
        val h = hub(catalog(entryJson("a", "seg")), wifiOnly = true)
        h.request("a")
        await("chờ Wi-Fi") { h.state.value.waiting == NetworkPolicy.Wait.WIFI }
        h.allowMeteredOnce()
        assertTrue(h.state.value.meteredAllowed || h.state.value.activeId != null || installed.isNotEmpty())
        await("cài đặt") { installed.isNotEmpty() }
        await("hàng đợi rỗng") { h.state.value.queue.isEmpty() && !h.state.value.meteredAllowed }
        // đợt sau lại phải hỏi lại
        installed.clear()
        h.request("a")
        await("lại chờ Wi-Fi") { h.state.value.waiting == NetworkPolicy.Wait.WIFI }
        assertTrue(installed.isEmpty())
    }

    @Test fun wifiOnlyOffDownloadsOnMobileDataImmediately() {
        net = NetKind.METERED
        accept("a")
        val h = hub(catalog(entryJson("a", "seg")), wifiOnly = false)
        h.request("a")
        await("cài đặt") { installed.isNotEmpty() }
    }

    @Test fun turningWifiOnlyOffWhileWaitingStartsTheDownload() {
        net = NetKind.METERED
        accept("a")
        val h = hub(catalog(entryJson("a", "seg")), wifiOnly = true)
        h.request("a")
        await("chờ Wi-Fi") { h.state.value.waiting == NetworkPolicy.Wait.WIFI }
        h.setWifiOnly(false)
        await("cài đặt") { installed.isNotEmpty() }
        assertEquals(listOf(false), savedWifi.toList())
        assertFalse(h.state.value.wifiOnly)
    }

    @Test fun switchingToMobileDataMidDownloadPausesKeepsPartialAndResumesWithRange() {
        accept("a")
        val h = hub(catalog(entryJson("a", "seg", "{release}/slow")), wifiOnly = true)
        h.request("a")
        await("đang tải") { h.state.value.activeId == "a" && h.state.value.progress > 0f }
        net = NetKind.METERED; h.onNetworkChanged()
        await("tạm dừng chờ Wi-Fi") { h.state.value.activeId == null && h.state.value.waiting == NetworkPolicy.Wait.WIFI }
        val part = File(dir, "work/a.onnx.part")
        assertTrue("giữ phần đã tải", part.exists() && part.length() in 1 until data.size.toLong())
        assertEquals(listOf("a"), h.state.value.queue)
        assertFalse("không phải người dùng hủy", said.any { it.startsWith("Đã hủy") })
        assertTrue(results.isEmpty()); assertTrue(installed.isEmpty())
        net = NetKind.UNMETERED; h.onNetworkChanged()
        await("cài đặt") { installed.isNotEmpty() }
        assertArrayEquals(data, installed[0].second.readBytes())
        assertTrue("tải tiếp phải gửi Range", ranges.any { it.startsWith("bytes=") && it != "bytes=0-" })
    }

    // ---------------------------------------------------------------- mất mạng / lỗi thoáng qua

    @Test fun offlineWaitsForNetworkThenDownloads() {
        net = NetKind.OFFLINE
        accept("a")
        val h = hub(catalog(entryJson("a", "seg")))
        h.request("a")
        await("chờ mạng") { h.state.value.waiting == NetworkPolicy.Wait.NETWORK }
        assertTrue(said.any { it.startsWith("Không có mạng") })
        net = NetKind.UNMETERED; h.onNetworkChanged()
        await("cài đặt") { installed.isNotEmpty() }
        assertNull(h.state.value.waiting)
    }

    @Test fun transientConnectionDropIsRetriedAutomaticallyFromPartialFile() {
        accept("a")
        val h = hub(catalog(entryJson("a", "seg", "http://127.0.0.1:${raw.localPort}/f")), retry = listOf(10L, 10L, 10L))
        h.request("a")
        await("cài đặt") { installed.isNotEmpty() }
        assertArrayEquals(data, installed[0].second.readBytes())
        assertTrue("lần thử lại phải tiếp tục bằng Range", ranges.any { it.startsWith("bytes=") })
        assertFalse(said.any { it.startsWith("Mất kết nối") })
        assertEquals(listOf(Triple("a", true, "Đã tải xong Model a.")), results.toList())
    }

    // ---------------------------------------------------------------- hàng đợi

    @Test fun twoModelsAreDownloadedOneAfterAnotherInRequestOrder() {
        accept("a", "b")
        val h = hub(catalog(entryJson("a", "seg"), entryJson("b", "lama", "{release}/slow")))
        h.request("a"); h.request("b")
        await("cả hai cài đặt") { installed.size == 2 }
        assertEquals(listOf("seg", "lama"), installed.map { it.first })
        await("rỗng") { h.state.value.queue.isEmpty() }
        assertEquals(listOf("a", "b"), results.map { it.first })
        assertEquals("giữ sống bật rồi tắt đúng một lần cuối", false, keep.last())
    }

    @Test fun cancelOneQueuedModelKeepsTheActiveOne() {
        accept("a", "b")
        val h = hub(catalog(entryJson("a", "seg", "{release}/slow"), entryJson("b", "lama")))
        h.request("a"); h.request("b")
        await("a đang tải") { h.state.value.activeId == "a" }
        assertEquals(listOf("a", "b"), h.state.value.queue)
        h.cancel("b")
        assertEquals(listOf("a"), h.state.value.queue)
        await("a xong") { installed.size == 1 }
        assertEquals("seg", installed[0].first)
        await("rỗng") { h.state.value.queue.isEmpty() }
        assertEquals(1, installed.size)
    }

    @Test fun cancelAllStopsActiveAndClearsQueueButKeepsPartial() {
        accept("a", "b")
        val h = hub(catalog(entryJson("a", "seg", "{release}/slow"), entryJson("b", "lama")))
        h.request("a"); h.request("b")
        await("a đang tải") { h.state.value.activeId == "a" && h.state.value.progress > 0f }
        h.cancel()
        await("đã hủy") { said.any { it.startsWith("Đã hủy tải") } && h.state.value.activeId == null }
        assertTrue(h.state.value.queue.isEmpty()); assertTrue(installed.isEmpty())
        assertTrue("giữ .part để lần sau tiếp tục", File(dir, "work/a.onnx.part").exists())
        await("tắt giữ sống") { keep.lastOrNull() == false }
        assertTrue(results.isEmpty())
    }

    @Test fun discardPartialRemovesDownloadedPieces() {
        accept("a")
        val h = hub(catalog(entryJson("a", "seg", "{release}/slow")))
        h.request("a")
        await("đang tải") { h.state.value.activeId == "a" && h.state.value.progress > 0f }
        h.discardPartial("a")
        await("dừng") { h.state.value.activeId == null }
        Thread.sleep(100)
        assertFalse(File(dir, "work/a.onnx.part").exists() && File(dir, "work/a.onnx.part").length() > 0 && h.state.value.queue.isNotEmpty())
        assertTrue(h.state.value.queue.isEmpty())
    }

    @Test fun requestingAnAlreadyQueuedModelDoesNotDuplicateIt() {
        accept("a")
        net = NetKind.OFFLINE
        val h = hub(catalog(entryJson("a", "seg")))
        h.request("a"); h.request("a")
        assertEquals(listOf("a"), h.state.value.queue)
    }

    // ---------------------------------------------------------------- lưu hàng đợi

    @Test fun queueSurvivesProcessDeathAndResumesInANewHub() {
        accept("a")
        val q = File(dir, "queue.txt")
        net = NetKind.METERED
        val h1 = hub(catalog(entryJson("a", "seg")), wifiOnly = true, queueFile = q)
        h1.request("a")
        await("chờ Wi-Fi") { h1.state.value.waiting == NetworkPolicy.Wait.WIFI }
        assertEquals(listOf("a"), q.readLines().filter { it.isNotBlank() })
        // "tiến trình bị tắt": hub mới đọc lại hàng đợi, có Wi-Fi ⇒ tải tiếp
        net = NetKind.UNMETERED
        val h2 = hub(catalog(entryJson("a", "seg")), wifiOnly = true, queueFile = q)
        assertEquals(listOf("a"), h2.state.value.queue)
        assertTrue("chưa tự tải trước khi resumeIfWanted", installed.isEmpty())
        h2.resumeIfWanted()
        await("cài đặt") { installed.isNotEmpty() }
        await("tệp hàng đợi bị xóa") { !q.exists() }
    }

    @Test fun queuedIdsMissingFromTheCatalogAreDroppedOnRestore() {
        val q = File(dir, "queue.txt"); q.writeText("ghost\n")
        val h = hub(catalog(entryJson("a", "seg")), queueFile = q)
        assertTrue(h.state.value.queue.isEmpty())
        h.resumeIfWanted()
        assertTrue(installed.isEmpty())
    }

    @Test fun cancelAllDeletesQueueFile() {
        accept("a")
        net = NetKind.OFFLINE
        val q = File(dir, "queue.txt")
        val h = hub(catalog(entryJson("a", "seg")), queueFile = q)
        h.request("a")
        assertTrue(q.exists())
        h.cancel()
        await("xóa tệp") { !q.exists() }
    }

    // ---------------------------------------------------------------- lỗi vẫn báo như cũ

    @Test fun wrongChecksumRemovesModelFromQueueAndReportsFailure() {
        accept("a")
        val bad = catalog(entryJson("a", "seg").replace(sha, "0".repeat(64)))
        val h = hub(bad)
        h.request("a")
        await("báo lỗi") { said.any { it.contains("SHA-256") } }
        await("rỗng") { h.state.value.queue.isEmpty() }
        assertTrue(installed.isEmpty())
        assertEquals(1, results.size); assertFalse(results[0].second)
    }
}
