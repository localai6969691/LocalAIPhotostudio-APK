package com.aiphoto.studio

import com.aiphoto.studio.engine.DistanceField
import com.aiphoto.studio.engine.Outpaint
import com.aiphoto.studio.engine.PatchMatchInpaint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin

/** R20: mở rộng ảnh (outpainting) — lõi thuần mảng. Chất lượng đo so với ẢNH GỐC rộng hơn (ground truth), không tự bịa. */
class R20OutpaintTest {

    private fun rgb(r: Int, g: Int, b: Int) = (255 shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun periodicAt(x: Int, y: Int): Int {
        val a = sin(2 * PI * x / 12.0) * cos(2 * PI * y / 9.0)
        val b = sin(2 * PI * (x + 2 * y) / 17.0)
        return rgb((128 + 70 * a + 20 * b).toInt(), (120 + 60 * a - 30 * b).toInt(), (110 - 50 * a + 40 * b).toInt())
    }

    private fun diagonalAt(x: Int, y: Int, w: Int, h: Int) = if (x + y < (w + h) / 2) rgb(200, 60, 40) else rgb(30, 90, 200)

    private fun crop(full: IntArray, fw: Int, x0: Int, y0: Int, w: Int, h: Int) = IntArray(w * h) { full[(y0 + it / w) * fw + x0 + it % w] }

    private fun psnrMasked(a: IntArray, b: IntArray, mask: ByteArray): Double {
        var se = 0.0; var n = 0
        for (i in a.indices) if (mask[i].toInt() != 0) for (s in intArrayOf(16, 8, 0)) {
            val d = ((a[i] shr s) and 255) - ((b[i] shr s) and 255); se += d * d; n += 3
        }
        val mse = se / n
        return if (mse < 1e-9) 99.0 else 10 * log10(255.0 * 255.0 / mse)
    }

    // ---------------------------------------------------------------- yêu cầu → khung mới
    @Test fun canonicalAcceptsGoodAndRejectsGarbage() {
        assertEquals("l=0.200,r=0.200,t=0.000,b=0.000", Outpaint.canonical("l=0.2,r=0.2"))
        assertEquals("l=1.000,r=0.000,t=0.000,b=0.000", Outpaint.canonical("l=5"))                    // chặn quá đà
        assertEquals("ratio=1.7778,a=c", Outpaint.canonical("ratio=1.7778"))
        assertEquals("ratio=1.0000,a=r", Outpaint.canonical("ratio=1,a=R"))
        assertNull(Outpaint.canonical(null))
        assertNull(Outpaint.canonical(""))
        assertNull(Outpaint.canonical("l=0,r=0,t=0,b=0"))
        assertNull(Outpaint.canonical("xin chao"))
        assertNull(Outpaint.canonical("ratio=0.01"))
        assertNull(Outpaint.canonical("ratio=99"))
        assertNull(Outpaint.canonical("ratio=abc"))
        assertEquals("l=0.000,r=0.300,t=0.000,b=0.000", Outpaint.canonical("l=-3,r=0.3,t=nan"))      // số xấu/âm bị coi là 0
    }

    @Test fun ratioToSpecCentersByDefault() {
        // 400×300 (4:3) → 16:9 cần thêm chiều rộng; chia đều hai bên
        val s = Outpaint.resolve("ratio=1.7778", 400, 300)!!
        assertEquals(s.left, s.right, 1e-6f)
        assertEquals(0f, s.top, 0f)
        val plan = Outpaint.plan(400, 300, s, 4000)!!
        assertEquals(300, plan.newH)
        assertEquals(1.7778f, plan.newW / 300f, 0.01f)
        assertTrue(kotlin.math.abs(plan.offX - (plan.newW - plan.offX - 400)) <= 1)          // hai bên bằng nhau (±1 điểm do làm tròn)
        // → 1:1 cần thêm chiều cao
        val sq = Outpaint.plan(400, 300, Outpaint.resolve("ratio=1", 400, 300)!!, 4000)!!
        assertEquals(400, sq.newW)
        assertEquals(400, sq.newH)
    }

    @Test fun ratioAnchorsAndAlreadyRightRatio() {
        val r = Outpaint.resolve("ratio=1.7778,a=r", 400, 300)!!
        assertEquals(0f, r.left, 0f); assertTrue(r.right > 0.3f)
        val l = Outpaint.resolve("ratio=1.7778,a=l", 400, 300)!!
        assertEquals(0f, l.right, 0f); assertTrue(l.left > 0.3f)
        val t = Outpaint.resolve("ratio=1,a=t", 400, 300)!!
        assertEquals(0f, t.bottom, 0f); assertTrue(t.top > 0.3f)
        // neo ngang không áp cho mở chiều cao (rơi về chia đều)
        val c = Outpaint.resolve("ratio=1,a=l", 400, 300)!!
        assertEquals(c.top, c.bottom, 1e-6f)
        assertNull(Outpaint.resolve("ratio=1.3333", 400, 300))             // đã đúng 4:3
    }

    @Test fun planKeepsResultWithinMaxSideAndAspect() {
        val s = Outpaint.Spec(0.5f, 0.5f, 0f, 0f)
        val p = Outpaint.plan(2000, 1500, s, 2560)!!
        assertTrue(max(p.newW, p.newH) <= 2560)
        assertEquals(p.newW, p.offX + p.drawW + (p.newW - p.offX - p.drawW))
        assertEquals(2000f / 1500f, p.drawW.toFloat() / p.drawH, 0.01f)       // ảnh gốc thu nhỏ đều, không méo
        assertTrue(p.offX + p.drawW <= p.newW && p.offY + p.drawH <= p.newH)
        val small = Outpaint.plan(400, 300, s, 2560)!!
        assertEquals(800, small.newW); assertEquals(300, small.newH); assertEquals(200, small.offX)
        assertEquals(400, small.drawW); assertEquals(300, small.drawH)
        assertNull(Outpaint.plan(400, 300, Outpaint.Spec(0f, 0f, 0f, 0f), 2560))
    }

    // ---------------------------------------------------------------- dựng khung
    @Test fun canvasPlacesOriginalExactlyAndMasksOnlyTheNewArea() {
        val w = 40; val h = 30
        val src = IntArray(w * h) { periodicAt(it % w, it / w) }
        val plan = Outpaint.plan(w, h, Outpaint.Spec(0.25f, 0.5f, 0.2f, 0f), 1000)!!
        val c = Outpaint.makeCanvas(src, w, h, plan, blurPrefill = false)
        assertEquals(plan.newW * plan.newH, c.px.size)
        var newPx = 0
        for (y in 0 until c.h) for (x in 0 until c.w) {
            val inside = x >= c.ox && x < c.ox + c.dw && y >= c.oy && y < c.oy + c.dh
            assertEquals(!inside, c.mask[y * c.w + x].toInt() != 0)
            if (inside) assertEquals(src[(y - c.oy) * w + (x - c.ox)], c.px[y * c.w + x]) else newPx++
        }
        assertEquals(c.w * c.h - w * h, newPx)
        // phần điền tạm là phản chiếu qua mép: điểm sát mép trái trùng cột 0, điểm kế tiếp trùng cột 1
        assertEquals(src[0], c.px[c.oy * c.w + c.ox - 1])
        assertEquals(src[1], c.px[c.oy * c.w + c.ox - 2])
    }

    @Test fun blurredPrefillDiffersOnlyInsideTheMask() {
        val w = 60; val h = 40
        val src = IntArray(w * h) { periodicAt(it % w, it / w) }
        val plan = Outpaint.plan(w, h, Outpaint.Spec(0.3f, 0.3f, 0f, 0f), 1000)!!
        val raw = Outpaint.makeCanvas(src, w, h, plan, false)
        val blur = Outpaint.makeCanvas(src, w, h, plan, true)
        var diffInMask = 0
        for (i in raw.px.indices) {
            if (raw.mask[i].toInt() == 0) assertEquals(raw.px[i], blur.px[i]) else if (raw.px[i] != blur.px[i]) diffInMask++
        }
        assertTrue("bản mờ phải khác bản thô trong vùng mới", diffInMask > 100)
    }

    @Test fun resizedOriginalWhenCanvasWouldExceedLimit() {
        val w = 200; val h = 100
        val src = IntArray(w * h) { rgb(100, 150, 200) }
        val plan = Outpaint.plan(w, h, Outpaint.Spec(1f, 1f, 0f, 0f), 300)!!       // 600×100 → ép về ≤ 300
        val c = Outpaint.makeCanvas(src, w, h, plan, false)
        assertTrue(max(c.w, c.h) <= 300)
        for (y in c.oy until c.oy + c.dh) for (x in c.ox until c.ox + c.dw) assertEquals(rgb(100, 150, 200), c.px[y * c.w + x])
    }

    // ---------------------------------------------------------------- chất lượng so với ground truth
    private fun extendAndScore(truthFull: IntArray, fw: Int, fh: Int, x0: Int, y0: Int, w: Int, h: Int, addX: Int, addY: Int,
                               engine: PatchMatchInpaint): Triple<Double, Double, IntArray> {
        val src = crop(truthFull, fw, x0, y0, w, h)
        val plan = Outpaint.Plan(w + 2 * addX, h + 2 * addY, addX, addY, w, h)
        val c = Outpaint.makeCanvas(src, w, h, plan, false)
        val truth = crop(truthFull, fw, x0 - addX, y0 - addY, c.w, c.h)
        val out = engine.inpaintPixels(c.px, c.w, c.h, c.mask)
        return Triple(psnrMasked(out, truth, c.mask), psnrMasked(c.px, truth, c.mask), out)
    }

    @Test fun periodicTextureContinuesBetterThanMirrorPadding() {
        val fw = 360; val fh = 280
        val full = IntArray(fw * fh) { periodicAt(it % fw, it / fw) }
        val t0 = System.nanoTime()
        val (pm, reflect, _) = extendAndScore(full, fw, fh, 80, 60, 200, 150, 40, 30, PatchMatchInpaint(growPx = 0, featherPx = 0f))
        println("R20 outpaint periodic: PatchMatch ${"%.1f".format(pm)} dB vs phản chiếu ${"%.1f".format(reflect)} dB (${(System.nanoTime() - t0) / 1_000_000} ms)")
        assertTrue("PatchMatch phải nối tiếp họa tiết (PSNR=$pm)", pm > 26.0)
        assertTrue("phải hơn phản chiếu ≥ 8 dB ($pm vs $reflect)", pm > reflect + 8.0)
    }

    @Test fun diagonalEdgeIsExtendedInTheRightDirection() {
        val fw = 360; val fh = 280
        val full = IntArray(fw * fh) { diagonalAt(it % fw, it / fw, fw, fh) }
        val (pm, reflect, _) = extendAndScore(full, fw, fh, 80, 60, 200, 150, 40, 30, PatchMatchInpaint(growPx = 0, featherPx = 0f))
        println("R20 outpaint edge: PatchMatch ${"%.1f".format(pm)} dB vs phản chiếu ${"%.1f".format(reflect)} dB")
        assertTrue("biên chéo phải được kéo ra ngoài khung (PSNR=$pm)", pm > 23.0)
        assertTrue(pm > reflect + 3.5)
    }

    @Test fun originalPixelsStayBitExactWithExactGrowAndFeather() {
        val fw = 300; val fh = 240
        val full = IntArray(fw * fh) { periodicAt(it % fw, it / fw) }
        val w = 160; val h = 120
        val src = crop(full, fw, 70, 60, w, h)
        val c = Outpaint.makeCanvas(src, w, h, Outpaint.Plan(w + 60, h + 20, 30, 10, w, h), false)
        val out = PatchMatchInpaint(growPx = 0, featherPx = 0f).inpaintPixels(c.px, c.w, c.h, c.mask)
        for (y in 0 until h) for (x in 0 until w) assertEquals(src[y * w + x], out[(y + c.oy) * c.w + x + c.ox])
    }

    @Test fun compositeKeepsOriginalExceptABandNextToTheSeam() {
        val w = 60; val h = 20
        val orig = IntArray(w * h) { rgb(10, 20, 30) }
        val mask = ByteArray(w * h) { if (it % w >= 40) 255.toByte() else 0 }
        val filled = IntArray(w * h) { rgb(200, 100, 50) }
        val out = Outpaint.composite(orig, filled, mask, w, h, band = 8)
        val row = 5 * w
        assertEquals(filled[row + 45], out[row + 45])                      // phần mới lấy hoàn toàn từ bản sinh
        assertEquals(filled[row + 39], out[row + 39])                      // sát mép: dùng bản sinh (a = 1)
        assertEquals(orig[row + 20], out[row + 20])                        // xa mép: nguyên vẹn
        assertEquals(orig[row + 31], out[row + 31])                        // vừa ngoài dải 8 điểm
        var prev = 256
        for (x in 32..39) {                                                // trong dải: hòa dần từ gốc sang bản sinh
            val r = (out[row + x] shr 16) and 255
            assertTrue("phải tăng dần về phía mép ($x: $r)", r >= (out[row + x - 1] shr 16 and 255))
            prev = r
        }
        assertTrue(prev > 150)
    }

    @Test fun compositeWithoutBandIsAHardCut() {
        val w = 10; val h = 4
        val orig = IntArray(w * h) { rgb(1, 1, 1) }
        val mask = ByteArray(w * h) { if (it % w >= 5) 255.toByte() else 0 }
        val filled = IntArray(w * h) { rgb(9, 9, 9) }
        val out = Outpaint.composite(orig, filled, mask, w, h, band = 0)
        for (i in out.indices) assertEquals(if (mask[i].toInt() != 0) filled[i] else orig[i], out[i])
    }

    @Test fun planAndCanvasHandleEveryDirectionOnATinyImage() {
        val w = 12; val h = 9
        val src = IntArray(w * h) { periodicAt(it % w, it / w) }
        for (spec in listOf(Outpaint.Spec(1f, 0f, 0f, 0f), Outpaint.Spec(0f, 0f, 1f, 0f), Outpaint.Spec(1f, 1f, 1f, 1f))) {
            val plan = Outpaint.plan(w, h, spec, 500)!!
            val c = Outpaint.makeCanvas(src, w, h, plan, true)
            val out = PatchMatchInpaint(growPx = 0, featherPx = 0f).inpaintPixels(c.px, c.w, c.h, c.mask)
            assertEquals(c.w * c.h, out.size)
            // hole khoảng cách tới điểm biết: tính được, không NaN/ngoại lệ
            val d = DistanceField.chamfer(BooleanArray(c.w * c.h) { c.mask[it].toInt() == 0 }, c.w, c.h)
            assertTrue(d.all { !it.isNaN() })
        }
    }
}
