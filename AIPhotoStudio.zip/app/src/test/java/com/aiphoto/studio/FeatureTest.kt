package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.RecipeCodec
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.PlanJson
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.ColorFx
import com.aiphoto.studio.engine.EdgeOps
import com.aiphoto.studio.engine.FaceGeometry
import com.aiphoto.studio.engine.Keystone
import com.aiphoto.studio.engine.MagicWand
import com.aiphoto.studio.engine.SegProfile
import com.aiphoto.studio.engine.SelectiveColor
import com.aiphoto.studio.routing.Routing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Kiểm thử phần thêm theo PDF nâng cấp: kế hoạch theo vùng, hình học khuôn mặt, đũa thần, Refine Edge, keystone, hồ sơ IS-Net. */
class FeatureTest {

    // ---------------------------------------------------------------- planner theo vùng
    private fun scopes(p: String) = RuleBasedPlanner.plan(p).scoped.associateBy { it.scope }

    @Test fun teethWhiteningIsScopedNotGlobal() {
        val plan = RuleBasedPlanner.plan("làm trắng răng")
        assertTrue(plan.ops.isEmpty())
        val teeth = plan.scoped.single { it.scope == Scope.TEETH }
        assertTrue(teeth.ops.first { it.type == OpType.BRIGHTNESS }.value > 0f)
        assertTrue(teeth.ops.first { it.type == OpType.SATURATION }.value < 0f)
    }

    @Test fun eyesNeedAccentedWordToAvoidFaceConfusion() {
        assertTrue(scopes("làm sáng mắt").containsKey(Scope.EYES))
        assertTrue(scopes("mắt long lanh hơn").containsKey(Scope.EYES))
        // "mặt" (khuôn mặt) bỏ dấu trùng "mắt" -> không được hiểu thành mắt
        assertFalse(scopes("làm sáng mặt").containsKey(Scope.EYES))
        assertTrue(RuleBasedPlanner.plan("làm sáng mặt").ops.any { it.type == OpType.BRIGHTNESS })
    }

    @Test fun darkCirclesSkyAndBackgroundScopes() {
        assertTrue(scopes("xóa quầng thâm").containsKey(Scope.DARK_CIRCLES))
        val sky = scopes("bầu trời xanh hơn").getValue(Scope.SKY)
        assertTrue(sky.ops.first { it.type == OpType.SATURATION }.value > 0f)
        assertTrue(scopes("làm tối nền").getValue(Scope.BACKGROUND).ops.first().value < 0f)
        assertTrue(scopes("làm nổi bật chủ thể").containsKey(Scope.SUBJECT))
    }

    @Test fun mixedPromptSplitsGlobalAndScoped() {
        val plan = RuleBasedPlanner.plan("da mịn, răng trắng và bầu trời xanh")
        assertTrue(plan.ops.any { it.type == OpType.SKIN_SMOOTH })
        assertTrue(plan.scoped.map { it.scope }.containsAll(listOf(Scope.TEETH, Scope.SKY)))
    }

    @Test fun reduceDoesNotAddScopedEffect() {
        val plan = RuleBasedPlanner.plan("giảm bọng mắt")
        assertTrue(plan.scoped.isEmpty() && plan.ops.isEmpty())
    }

    @Test fun faceAndSkyAdjustmentsAreNotGenerativeButRemovalStaysGenerative() {
        assertNull(GenIntent.detect("xóa quầng thâm", false))
        assertNull(GenIntent.detect("làm trắng răng", false))
        assertNull(GenIntent.detect("làm bầu trời xanh hơn", false))
        assertEquals(GenKind.REMOVE, GenIntent.detect("xóa chim trên bầu trời", false))
        assertEquals(GenKind.FILL, GenIntent.detect("thay bầu trời thành hoàng hôn", false))
    }

    @Test fun llmJsonKeepsScopeAndDropsUnknownScope() {
        val raw = """{"ops":[{"op":"brightness","value":0.2,"scope":"teeth"},{"op":"contrast","value":0.1},{"op":"saturation","value":0.3,"scope":"toenails"}]}"""
        val p = PlanJson.parseFull(raw)!!
        assertEquals(1, p.ops.size)
        assertEquals(listOf(Scope.TEETH), p.scoped.map { it.scope })
    }

    // ---------------------------------------------------------------- hình học khuôn mặt
    @Test fun polygonFillMatchesAnalyticArea() {
        val out = ByteArray(200 * 200)
        FaceGeometry.fillPolygon(floatArrayOf(20f, 120f, 120f, 20f), floatArrayOf(30f, 30f, 130f, 130f), 200, 200, out)
        assertEquals(10000, out.count { it.toInt() != 0 })
        val tri = ByteArray(200 * 200)
        FaceGeometry.fillPolygon(floatArrayOf(10f, 190f, 100f), floatArrayOf(10f, 10f, 180f), 200, 200, tri)
        assertEquals(15300.0, tri.count { it.toInt() != 0 }.toDouble(), 15300 * 0.01)
    }

    @Test fun convexHullDropsInteriorPoints() {
        val h = FaceGeometry.convexHull(floatArrayOf(0f, 10f, 10f, 0f, 5f, 5f), floatArrayOf(0f, 0f, 10f, 10f, 5f, 2f))
        assertEquals(4, h.first.size)
    }

    private fun syntheticFace(): FloatArray {
        val lm = FloatArray(2 * 478) { 0.5f }
        fun place(ids: IntArray, ox: Float, oy: Float, rx: Float, ry: Float, start: Double) {
            for ((k, id) in ids.withIndex()) {
                val a = start + 2.0 * PI * k / ids.size
                lm[2 * id] = 0.5f + ox + rx * cos(a).toFloat()
                lm[2 * id + 1] = 0.5f + oy + ry * sin(a).toFloat()
            }
        }
        place(FaceGeometry.FACE_OVAL, 0f, 0f, 0.25f, 0.35f, -PI / 2)
        place(FaceGeometry.RIGHT_EYE, -0.10f, -0.08f, 0.05f, 0.025f, PI)
        place(FaceGeometry.LEFT_EYE, 0.10f, -0.08f, 0.05f, 0.025f, 0.0)
        place(FaceGeometry.LIPS_OUTER, 0f, 0.16f, 0.08f, 0.035f, PI)
        place(FaceGeometry.LIPS_INNER, 0f, 0.16f, 0.06f, 0.015f, PI)
        place(FaceGeometry.RIGHT_BROW, -0.10f, -0.15f, 0.06f, 0.012f, PI)
        place(FaceGeometry.LEFT_BROW, 0.10f, -0.15f, 0.06f, 0.012f, 0.0)
        return lm
    }

    @Test fun faceRegionsAreDisjointAndUnderEyesSitBelowEyes() {
        val w = 400
        val h = 500
        val parts = FaceGeometry.parts(listOf(syntheticFace()), w, h)
        assertEquals(1, parts.faces)
        assertTrue(parts.skin.count { it.toInt() != 0 } > 20000)
        var overlapEyes = 0
        var overlapMouth = 0
        var eyeY = 0L
        var eyeN = 0
        var underY = 0L
        var underN = 0
        for (i in 0 until w * h) {
            val s = parts.skin[i].toInt() != 0
            if (s && parts.eyes[i].toInt() != 0) overlapEyes++
            if (s && parts.mouth[i].toInt() != 0) overlapMouth++
            if (parts.eyes[i].toInt() != 0) { eyeY += i / w; eyeN++ }
            if (parts.underEyes[i].toInt() != 0) { underY += i / w; underN++ }
        }
        assertEquals(0, overlapEyes)
        assertEquals(0, overlapMouth)
        assertTrue(eyeN > 0 && underN > 0)
        assertTrue(underY.toDouble() / underN > eyeY.toDouble() / eyeN + 5)
    }

    @Test fun tonalMaskSplitsSkinIntoLightAndShadowAndIgnoresOutside() {
        val skin = byteArrayOf(255.toByte(), 255.toByte(), 255.toByte(), 0)
        val argb = intArrayOf(
            (255 shl 24) or (235 shl 16) or (200 shl 8) or 180,   // sáng
            (255 shl 24) or (60 shl 16) or (40 shl 8) or 35,      // tối
            (255 shl 24) or (130 shl 16) or (100 shl 8) or 90,    // trung tính
            (255 shl 24) or (240 shl 16) or (240 shl 8) or 240    // ngoài vùng da
        )
        val light = FaceGeometry.tonalMask(skin, argb, true)
        val shadow = FaceGeometry.tonalMask(skin, argb, false)
        assertTrue((light[0].toInt() and 255) > 230 && (light[1].toInt() and 255) < 10)
        assertTrue((shadow[1].toInt() and 255) > 230 && (shadow[0].toInt() and 255) < 10)
        assertEquals(0, light[3].toInt())
        assertEquals(0, shadow[3].toInt())
    }

    @Test fun contourPromptCreatesLightAndShadowLayers() {
        val sc = scopes("làm nổi khối khuôn mặt")
        assertTrue(sc.getValue(Scope.FACE_LIGHT).ops.first().value > 0f)
        assertTrue(sc.getValue(Scope.FACE_SHADOW).ops.first().value < 0f)
        assertNull(GenIntent.detect("làm nổi khối khuôn mặt", false))
        assertTrue(Scope.needsFace(Scope.FACE_LIGHT) && Scope.needsFace(Scope.FACE_SHADOW))
    }

    @Test fun faceWithTooFewPointsIsIgnored() {
        assertEquals(0, FaceGeometry.parts(listOf(FloatArray(100)), 100, 100).faces)
    }

    @Test fun teethMaskKeepsWhiteRejectsLipsAndTongue() {
        val mouth = ByteArray(3) { 255.toByte() }
        val argb = intArrayOf(
            (255 shl 24) or (240 shl 16) or (240 shl 8) or 235,   // răng trắng
            (255 shl 24) or (180 shl 16) or (60 shl 8) or 70,     // môi/nướu đỏ
            (255 shl 24) or (90 shl 16) or (40 shl 8) or 45       // lưỡi/bóng tối
        )
        val m = FaceGeometry.teethMask(mouth, argb)
        assertTrue((m[0].toInt() and 255) > 230)
        assertTrue((m[1].toInt() and 255) < 20)
        assertTrue((m[2].toInt() and 255) < 20)
    }

    // ---------------------------------------------------------------- đũa thần
    @Test fun magicWandSelectsConnectedSimilarColorOnly() {
        val w = 40
        val h = 20
        val px = IntArray(w * h) { if (it % w < 20) (255 shl 24) or (200 shl 16) or (40 shl 8) or 40 else (255 shl 24) or (40 shl 16) or (60 shl 8) or 200 }
        val m = MagicWand.select(px, w, h, 5, 10)
        assertEquals(20 * h, m.count { it.toInt() != 0 })
        assertEquals(0, (20 until w).count { m[10 * w + it].toInt() != 0 })
    }

    @Test fun magicWandToleranceLimitsGradientAndStaysConnected() {
        val w = 60
        val h = 60
        // đảo màu khác nằm giữa vùng nền: phải bị loại
        val px = IntArray(w * h) { (255 shl 24) or (120 shl 16) or (200 shl 8) or 120 }
        for (y in 25 until 35) for (x in 25 until 35) px[y * w + x] = (255 shl 24) or (250 shl 16) or (250 shl 8) or 20
        val m = MagicWand.select(px, w, h, 5, 5)
        assertEquals(w * h - 100, m.count { it.toInt() != 0 })
    }

    // ---------------------------------------------------------------- Refine Edge
    @Test fun normalCdfKnownValues() {
        assertEquals(0.5f, EdgeOps.normalCdf(0f), 1e-4f)
        assertEquals(0.8413f, EdgeOps.normalCdf(1f), 1e-3f)
        assertEquals(0.1587f, EdgeOps.normalCdf(-1f), 1e-3f)
    }

    @Test fun shiftEdgeGrowsAndShrinksTheMask() {
        val w = 400
        val h = 40
        val mask = FloatArray(w * h) { if (it % w < 200) 1f else 0f }
        fun area(m: FloatArray) = m.count { it > 0.5f }
        val base = area(mask)
        assertEquals(base, area(EdgeOps.shiftEdge(mask, w, h, 0f)))
        val grown = area(EdgeOps.shiftEdge(mask, w, h, 0.5f))
        val shrunk = area(EdgeOps.shiftEdge(mask, w, h, -0.5f))
        // ±0.5 ≈ ±4 điểm ảnh trên 400px, 40 hàng
        assertEquals((base + 4 * h).toDouble(), grown.toDouble(), (3 * h).toDouble())
        assertEquals((base - 4 * h).toDouble(), shrunk.toDouble(), (3 * h).toDouble())
    }

    @Test fun decontaminateMovesEdgeColorTowardForeground() {
        val w = 200
        val h = 20
        val alpha = FloatArray(w * h) { ((100 - (it % w)) / 12f + 0.5f).coerceIn(0f, 1f) }
        // màu viền = pha trộn (chủ thể đỏ, nền cũ xanh lá) theo alpha
        val px = IntArray(w * h) {
            val a = alpha[it]
            val r = (200 * a + 30 * (1 - a)).toInt()
            val g = (30 * a + 200 * (1 - a)).toInt()
            (255 shl 24) or (r shl 16) or (g shl 8) or 30
        }
        val out = EdgeOps.decontaminate(px, alpha, w, h, 8)
        var before = 0L
        var after = 0L
        var n = 0
        for (i in px.indices) {
            if (alpha[i] in 0.1f..0.9f) {
                before += abs(((px[i] shr 16) and 255) - 200)
                after += abs(((out[i] shr 16) and 255) - 200)
                n++
            }
        }
        assertTrue(n > 0)
        assertTrue("sai số màu viền phải giảm rõ rệt: $before -> $after", after * 3 < before * 2)
    }

    // ---------------------------------------------------------------- phối cảnh
    @Test fun keystoneParseAndQuad() {
        assertNull(Keystone.parse("abc"))
        assertNull(Keystone.parse("0.5"))
        val kv = Keystone.parse("2,-3")!!
        assertEquals(1f, kv.first, 0f)
        assertEquals(-1f, kv.second, 0f)
        val q0 = Keystone.sourceQuad(400, 300, 0f, 0f)
        assertEquals(listOf(0f, 0f, 400f, 0f, 400f, 300f, 0f, 300f), q0.toList())
        val q = Keystone.sourceQuad(400, 300, 1f, 0f)   // cạnh trên co 25% mỗi bên
        assertEquals(100f, q[0], 1e-3f)
        assertEquals(300f, q[2], 1e-3f)
        assertEquals(0f, q[6], 1e-3f)
        for (v in q) assertTrue(v >= 0f && v <= 400f)
    }

    @Test fun perspectiveOpIsDroppedWhenNeutral() {
        assertNull(EditOp(OpType.PERSPECTIVE, 1f, "0.000,0.000").sanitized())
        assertNull(EditOp(OpType.PERSPECTIVE, 1f, null).sanitized())
        assertNotNull(EditOp(OpType.PERSPECTIVE, 1f, "0.5,-0.2").sanitized())
    }

    // ---------------------------------------------------------------- hồ sơ model
    // ---------------------------------------------------------------- Selective Color (giá trị kỳ vọng từ tools/verify_ports/selective_color.py)
    private fun argb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b

    private fun sel(absolute: Boolean = false, vararg set: Pair<Int, Float>): String {
        val v = FloatArray(37)
        for ((i, x) in set) v[i] = x
        if (absolute) v[36] = 1f
        return v.joinToString(",")
    }

    private fun one(px: Int, arg: String): Int? = SelectiveColor.apply(intArrayOf(px), arg)?.get(0)

    private fun near(expected: Int, actual: Int, tol: Int = 2) =
        assertTrue("kỳ vọng ~$expected, nhận $actual", abs(expected - actual) <= tol)

    @Test fun selectiveColorIdentityIsNullAndRangesAreIndependent() {
        assertNull(SelectiveColor.apply(intArrayOf(argb(10, 20, 30)), sel()))
        assertNull(SelectiveColor.apply(intArrayOf(argb(10, 20, 30)), "1,2,3"))              // thiếu số
        val red = one(argb(255, 0, 0), sel(false, 1 to -1f))!!                               // Đỏ: Magenta -100% -> vàng
        assertEquals(listOf(255, 255, 0), listOf((red shr 16) and 255, (red shr 8) and 255, red and 255))
        val blue = argb(26, 51, 230)
        assertEquals(blue, one(blue, sel(false, 1 to -1f)))                                  // chỉnh dải Đỏ không động tới pixel lam
    }

    @Test fun selectiveColorWhitesNeutralsRelativeAndAbsolute() {
        val w = one(argb(255, 247, 230), sel(false, (6 * 4 + 2) to 1f))!!                    // Trắng: Vàng +100% -> ấm hơn
        near(206, w and 255)
        assertEquals(247, (w shr 8) and 255)
        val gray = one(argb(128, 128, 128), sel(false, (7 * 4 + 3) to -0.8f))!!              // Trung tính: Đen -80% -> sáng hơn
        near(230, gray and 255)
        val dark = one(argb(26, 26, 31), sel(true, (8 * 4 + 3) to 0.5f))!!                   // Tuyệt đối: Đen +50 điểm -> đen hẳn
        assertEquals(0, dark and 0xFFFFFF)
        // Tương đối trên pixel không có magenta thì không đổi; Tuyệt đối thì có
        val green = argb(51, 179, 77)
        assertEquals(green, one(green, sel(false, (2 * 4 + 1) to 0.5f)))
        near(108, ((one(green, sel(true, (2 * 4 + 1) to 0.5f))!!) shr 8) and 255)
    }

    @Test fun selectiveColorOpSanitizing() {
        assertNull(EditOp(OpType.SELECTIVE_COLOR, 1f, sel()).sanitized())
        assertNotNull(EditOp(OpType.SELECTIVE_COLOR, 1f, sel(false, 0 to 0.4f)).sanitized())
    }

    // ---------------------------------------------------------------- công thức mang theo điều chỉnh cục bộ
    @Test fun recipeKeepsParametricMasksAndScopesButDropsPaintedMasks() {
        val plain = AdjustmentLayer(1, "Sáng", listOf(EditOp(OpType.BRIGHTNESS, 0.2f)))
        val sky = AdjustmentLayer(2, "Trời", listOf(EditOp(OpType.SATURATION, 0.3f)),
            mask = LayerMask(MaskSpec.ColorRange(210f, 45f, 0.12f), invert = false, feather = 0.03f, shift = 0.25f),
            blend = BlendMode.SOFT_LIGHT, opacity = 0.8f)
        val teeth = AdjustmentLayer(3, "AI: Răng", listOf(EditOp(OpType.BRIGHTNESS, 0.22f)),
            mask = LayerMask(MaskSpec.Painted(ByteArray(4), 2, 2)), scope = Scope.TEETH)
        val painted = AdjustmentLayer(4, "Tô tay", listOf(EditOp(OpType.BLUR, 0.5f)), mask = LayerMask(MaskSpec.Painted(ByteArray(4), 2, 2)))
        assertTrue(RecipeCodec.portable(plain) && RecipeCodec.portable(sky) && RecipeCodec.portable(teeth))
        assertFalse(RecipeCodec.portable(painted))

        val back = RecipeCodec.decode(RecipeCodec.encode(listOf(plain, sky, teeth, painted)))
        assertEquals(3, back.size)
        assertNull(back[0].mask)
        val m = back[1].mask!!
        assertEquals(MaskSpec.ColorRange(210f, 45f, 0.12f), m.spec)
        assertEquals(0.03f, m.feather, 1e-6f)
        assertEquals(0.25f, m.shift, 1e-6f)
        assertEquals(BlendMode.SOFT_LIGHT, back[1].blend)
        assertEquals(0.8f, back[1].opacity, 1e-6f)
        assertEquals(Scope.TEETH, back[2].scope)
        assertNull(back[2].mask)          // mặt nạ theo vùng được dựng lại cho từng ảnh, không lưu dữ liệu điểm ảnh
        assertEquals("recipe", back[2].kind)
    }

    // ---------------------------------------------------------------- Hue + Lens flare (giá trị kỳ vọng từ tools/verify_ports/color_fx.py)
    @Test fun hueShiftRotatesAroundTheWheelAndKeepsGrayAndValue() {
        fun rgb(p: Int) = listOf((p shr 16) and 255, (p shr 8) and 255, p and 255)
        assertEquals(listOf(0, 255, 0), rgb(ColorFx.hueShift(intArrayOf(argb(255, 0, 0)), 120f)[0]))
        assertEquals(listOf(0, 0, 255), rgb(ColorFx.hueShift(intArrayOf(argb(255, 0, 0)), 240f)[0]))
        assertEquals(listOf(200, 100, 50), rgb(ColorFx.hueShift(intArrayOf(argb(200, 100, 50)), 360f)[0]))
        assertEquals(listOf(90, 90, 90), rgb(ColorFx.hueShift(intArrayOf(argb(90, 90, 90)), 77f)[0]))
        assertEquals(listOf(75, 200, 50), rgb(ColorFx.hueShift(intArrayOf(argb(200, 100, 50)), 90f)[0]))
    }

    @Test fun lensFlareOnlyAddsLightAndLeavesFarPixelsAlone() {
        val w = 400
        val h = 300
        val base = IntArray(w * h) { argb(51, 51, 51) }
        val out = ColorFx.lensFlare(base, w, h, 0.8f, 0.8f, 0.2f)
        var brightest = 0
        var bi = 0
        for (i in out.indices) {
            val r = (out[i] shr 16) and 255
            assertTrue("flare không được làm tối ảnh", r >= 51)
            if (r > brightest) { brightest = r; bi = i }
        }
        assertTrue(brightest > 200)
        assertTrue(abs(bi % w - 320) <= 12 && abs(bi / w - 60) <= 12)
        assertEquals(base[290 * w + 5], out[290 * w + 5])
        assertTrue(ColorFx.lensFlare(base, w, h, 0f, 0.8f, 0.2f) === base)
    }

    @Test fun hueAndFlareOpsSanitize() {
        assertNull(EditOp(OpType.HUE, 0.001f).sanitized())
        assertEquals(-1f, EditOp(OpType.HUE, -3f).sanitized()!!.value, 0f)
        assertNull(EditOp(OpType.LENS_FLARE, 0f, "0.5,0.5").sanitized())
        val f = EditOp(OpType.LENS_FLARE, 0.6f, "2,-1").sanitized()!!
        assertEquals("1.000,0.000", f.arg)
        assertEquals("0.780,0.200", EditOp(OpType.LENS_FLARE, 0.6f, null).sanitized()!!.arg)
    }

    @Test fun modnetSizeMatchesOfficialScaleFactorRule() {
        // vector lấy từ get_scale_factor trong onnx/inference_onnx.py chính thức của MODNet (ref_size = 512)
        assertEquals(Pair(672, 512), SegProfile.modnetSize(2048, 1536))
        assertEquals(Pair(512, 672), SegProfile.modnetSize(1536, 2048))
        assertEquals(Pair(768, 512), SegProfile.modnetSize(300, 200))
        assertEquals(Pair(512, 512), SegProfile.modnetSize(512, 512))
        assertEquals(Pair(992, 384), SegProfile.modnetSize(1000, 400))   // max >= 512 và min <= 512: giữ nguyên rồi chia hết 32
        assertEquals(Pair(672, 512), SegProfile.modnetSize(4000, 3000))
    }

    @Test fun modnetProfileDiffersFromRembgFamily() {
        assertEquals(0.5f, SegProfile.mean(SegProfile.MODNET)[1], 0f)
        assertEquals(0.5f, SegProfile.std(SegProfile.MODNET)[2], 0f)
        assertFalse(SegProfile.divideByMax(SegProfile.MODNET))
        assertFalse(SegProfile.minMaxOutput(SegProfile.MODNET))
        assertTrue(SegProfile.divideByMax(SegProfile.U2NET) && SegProfile.minMaxOutput(SegProfile.ISNET))
        assertEquals(512, SegProfile.defaultSize(SegProfile.MODNET))
        assertTrue("modnet_onnx" in Routing.KNOWN_KINDS)
    }

    @Test fun segmenterProfiles() {
        assertEquals(1f, SegProfile.std(SegProfile.ISNET)[0], 0f)
        assertEquals(0.229f, SegProfile.std(SegProfile.U2NET)[0], 1e-6f)
        assertEquals(1024, SegProfile.defaultSize(SegProfile.ISNET))
        assertEquals(320, SegProfile.defaultSize(SegProfile.U2NET))
        assertTrue("isnet_onnx" in Routing.KNOWN_KINDS && "mp_face_landmarker" in Routing.KNOWN_KINDS)
    }
}
