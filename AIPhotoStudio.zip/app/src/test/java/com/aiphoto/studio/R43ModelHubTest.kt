package com.aiphoto.studio

import com.aiphoto.studio.models.ModelHub
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.nio.file.Files
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList

/** R43: bộ điều phối tải model — đồng ý điều khoản một lần, giao tệp cho hàm nạp, danh mục mới/đã lưu/có sẵn, hủy, sai SHA-256. */
class R43ModelHubTest {
    private lateinit var server: HttpServer
    private lateinit var dir: File
    private lateinit var scope: CoroutineScope
    private val data = ByteArray(600_000) { (it * 31 + 7).toByte() }
    private val sha = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
    private val said = CopyOnWriteArrayList<String>()
    private val installed = CopyOnWriteArrayList<Pair<String, File>>()

    private fun base() = "http://127.0.0.1:${server.address.port}"
    private fun catalog(path: String = "{release}/ok", id: String = "seg_test", sha: String = this.sha, slot: String = "seg") =
        """{"version":1,"catalogUrl":"${base()}/catalog","releaseBase":"${base()}","models":[{"id":"$id","slot":"$slot","name":"Seg $id","file":"$id.onnx","sizeBytes":${data.size},"sha256":"$sha","urls":["$path"],"license":"Apache-2.0","licenseUrl":"https://example.com/l","vi":"mô tả","en":"desc"}]}"""

    private fun serve(ex: HttpExchange, slow: Boolean) {
        try {
            val rh = ex.requestHeaders.getFirst("Range")
            var start = 0; var code = 200
            if (rh != null) { start = Regex("bytes=(\\d+)-").find(rh)!!.groupValues[1].toInt(); code = 206; ex.responseHeaders.add("Content-Range", "bytes $start-${data.size - 1}/${data.size}") }
            ex.sendResponseHeaders(code, (data.size - start).toLong())
            ex.responseBody.use { out ->
                var off = start
                while (off < data.size) { val n = minOf(32_768, data.size - off); out.write(data, off, n); out.flush(); off += n; if (slow) Thread.sleep(40) }
            }
        } catch (e: IOException) { /* hủy */ }
    }

    @Before fun up() {
        dir = Files.createTempDirectory("r43hub").toFile()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/ok") { serve(it, false) }
        server.createContext("/slow") { serve(it, true) }
        server.start()
    }

    @After fun down() { scope.cancel(); server.stop(0); dir.deleteRecursively() }

    private fun hub(bundled: String, fetch: (String) -> String? = { null }, slotOk: Boolean = true) = ModelHub(
        scope = scope, workDir = File(dir, "work"), consentFile = File(dir, "licenses.txt"), catalogCache = File(dir, "cache.json"),
        bundledJson = { bundled }, slotFile = { if (slotOk) File(dir, "models/$it.bin") else null },
        install = { slot, f -> installed.add(slot to f) }, say = { said.add(it) }, allowHttp = true, fetchText = fetch
    )

    private fun await(what: String, cond: () -> Boolean) {
        val end = System.currentTimeMillis() + 10_000
        while (System.currentTimeMillis() < end) { if (cond()) return; Thread.sleep(25) }
        throw AssertionError("quá hạn chờ: $what")
    }

    @Test fun consentIsAskedOnceThenDownloadInstallsFile() {
        val h = hub(catalog())
        assertEquals(listOf("seg_test"), h.state.value.entries.map { it.id })
        h.request("seg_test")
        assertEquals("seg_test", h.state.value.pendingConsent); assertTrue(installed.isEmpty())
        h.confirm("seg_test")
        await("cài đặt") { installed.isNotEmpty() }
        assertEquals("seg", installed[0].first); assertArrayEquals(data, installed[0].second.readBytes())
        assertNull(h.state.value.pendingConsent)
        await("hết tải") { h.state.value.activeId == null }
        assertTrue(File(dir, "licenses.txt").readText().contains("seg_test"))
        // hub mới (cùng tệp đồng ý): không hỏi lại
        installed.clear()
        val h2 = hub(catalog())
        h2.request("seg_test")
        assertNull(h2.state.value.pendingConsent)
        await("tải lần 2") { installed.isNotEmpty() }
    }

    @Test fun slotUnknownToThisAppIsHidden() {
        assertTrue(hub(catalog(), slotOk = false).state.value.entries.isEmpty())
    }

    @Test fun remoteCatalogReplacesBundledAndIsCached() {
        val h = hub(catalog(id = "seg_old"), fetch = { catalog(id = "seg_new") })
        assertEquals(listOf("seg_old"), h.state.value.entries.map { it.id })
        h.refresh()
        await("danh mục mới") { h.state.value.entries.map { it.id } == listOf("seg_new") }
        assertTrue(File(dir, "cache.json").exists())
        val h2 = hub(catalog(id = "seg_old"))            // không có mạng: dùng bản đã lưu
        assertEquals(listOf("seg_new"), h2.state.value.entries.map { it.id })
    }

    @Test fun badRemoteCatalogKeepsBundledAndExplains() {
        val h = hub(catalog(), fetch = { "{hỏng" })
        h.refresh()
        await("ghi chú") { h.state.value.note.startsWith("Chưa lấy được") }
        assertEquals(listOf("seg_test"), h.state.value.entries.map { it.id })
    }

    @Test fun wrongChecksumIsReportedAndNothingInstalled() {
        val h = hub(catalog(sha = "0".repeat(64)))
        h.request("seg_test"); h.confirm("seg_test")
        await("báo lỗi") { said.any { it.contains("SHA-256") } }
        assertTrue(installed.isEmpty())
    }

    @Test fun cancelStopsDownloadWithoutInstalling() {
        val h = hub(catalog(path = "{release}/slow"))
        h.request("seg_test"); h.confirm("seg_test")
        await("đang tải") { h.state.value.activeId != null }
        h.cancel()
        await("đã hủy") { said.any { it.startsWith("Đã hủy tải") } }
        assertTrue(installed.isEmpty()); assertFalse(h.state.value.activeId != null)
    }
}
