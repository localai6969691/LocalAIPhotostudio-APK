package com.aiphoto.studio

import com.aiphoto.studio.util.ImageDrop
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** R42: kéo-thả ảnh từ ứng dụng khác — quy tắc chọn mục ảnh (phần thuần, không cần thiết bị). */
class R42ImageDropTest {
    @Test fun imageMimeRecognisedCaseInsensitively() {
        assertTrue(ImageDrop.isImageMime("image/jpeg"))
        assertTrue(ImageDrop.isImageMime(" IMAGE/PNG "))
        assertTrue(ImageDrop.isImageMime("image/*"))
        assertFalse(ImageDrop.isImageMime("video/mp4"))
        assertFalse(ImageDrop.isImageMime("application/pdf"))
        assertFalse(ImageDrop.isImageMime(null))
    }

    @Test fun genericMimeFallsBackToExtension() {
        assertTrue(ImageDrop.accepts(null, "a.jpg"))
        assertTrue(ImageDrop.accepts("", "b.PNG"))
        assertTrue(ImageDrop.accepts("*/*", "c.heic"))
        assertTrue(ImageDrop.accepts("application/octet-stream", "primary:DCIM/Camera/d.webp"))
        assertFalse(ImageDrop.accepts(null, "ghi_chu.txt"))
        assertFalse(ImageDrop.accepts("application/octet-stream", null))
        assertFalse(ImageDrop.accepts(null, "khong_duoi"))
    }

    @Test fun specificNonImageMimeBeatsImageExtension() {
        assertFalse(ImageDrop.accepts("application/pdf", "scan.jpg"))
        assertFalse(ImageDrop.accepts("video/mp4", "clip.png"))
        assertFalse(ImageDrop.accepts("text/plain", "x.heic"))
    }

    @Test fun extensionParsingIsStrict() {
        assertTrue(ImageDrop.isImageName("IMG_0001.JPG"))
        assertTrue(ImageDrop.isImageName("anh.chan.dung.jpeg"))
        assertTrue(ImageDrop.isImageName("a.heif"))
        assertFalse(ImageDrop.isImageName("photo.jpg.txt"))
        assertFalse(ImageDrop.isImageName("photo."))
        assertFalse(ImageDrop.isImageName(".jpg_"))
        assertFalse(ImageDrop.isImageName(null))
    }

    @Test fun startOfDragAcceptsOnlyPossibleImages() {
        assertTrue(ImageDrop.mayContainImage(listOf("image/jpeg")))
        assertTrue(ImageDrop.mayContainImage(listOf("text/plain", "image/png")))
        assertTrue(ImageDrop.mayContainImage(listOf("*/*")))
        assertTrue(ImageDrop.mayContainImage(listOf("application/octet-stream")))
        assertTrue(ImageDrop.mayContainImage(listOf("text/uri-list")))
        assertFalse(ImageDrop.mayContainImage(listOf("text/plain")))
        assertFalse(ImageDrop.mayContainImage(listOf("video/mp4", "application/pdf")))
        assertFalse(ImageDrop.mayContainImage(emptyList()))
        assertFalse(ImageDrop.mayContainImage(listOf("")))
    }

    @Test fun pickImagesKeepsDropOrderAndSkipsOthers() {
        val items = listOf(
            ImageDrop.Item("u1", "image/jpeg", "1.jpg"),
            ImageDrop.Item("u2", "video/mp4", "2.mp4"),
            ImageDrop.Item("u3", null, "3.PNG"),
            ImageDrop.Item("u4", "application/pdf", "4.jpg"),
            ImageDrop.Item("u5", "application/octet-stream", "5.heic"),
            ImageDrop.Item("u6", "", "ghi_chu.txt")
        )
        assertEquals(listOf("u1", "u3", "u5"), ImageDrop.pickImages(items))
        assertEquals(emptyList<String>(), ImageDrop.pickImages(emptyList<ImageDrop.Item<String>>()))
    }
}
