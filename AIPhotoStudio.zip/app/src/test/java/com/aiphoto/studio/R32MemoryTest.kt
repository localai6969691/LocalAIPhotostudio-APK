package com.aiphoto.studio

import com.aiphoto.studio.engine.MemoryLedger
import com.aiphoto.studio.engine.ModelMemory
import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.Routing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R32: tầng bằng chứng cho RAM nạp model ([ModelMemory] + [MemoryLedger]) và móc [Routing.memoryGuard].
 * Mọi số dưới đây đã được kiểm bằng bản port Python `tools/verify_ports/model_memory.py` (28 khẳng định + 6 đột biến đều bị bắt).
 */
class R32MemoryTest {

    private class MemStore : MemoryLedger.Store {
        val m = HashMap<String, Any>()
        override fun getInt(key: String, def: Int): Int = (m[key] as Int?) ?: def
        override fun putInt(key: String, value: Int) { m[key] = value }
        override fun getString(key: String, def: String): String = (m[key] as String?) ?: def
        override fun putString(key: String, value: String) { m[key] = value }
    }

    // ------------------------------------------------------------------ ước lượng
    @Test fun chuaCoBangChungThiKhongChan() {
        assertEquals(0, ModelMemory.estimateMb(555, 0, 0))
        assertTrue(ModelMemory.fits(0, 0L, 4096))
    }

    @Test fun daDoThiLayDoNhanBien() {
        assertEquals(1125, ModelMemory.estimateMb(555, 900, 0))     // 900 × 1,25
        assertEquals(1366, ModelMemory.estimateMb(555, 5000, 0))    // số đo phình bị kẹp ở tệp×2+256
        assertEquals(555, ModelMemory.estimateMb(555, 10, 0))       // số đo nhỏ vô lý được nâng lên bằng kích thước tệp
        assertEquals(125, ModelMemory.estimateMb(-5, 100, 0))
        assertEquals(64, ModelMemory.estimateMb(0, 10, 0))          // sàn tối thiểu
    }

    @Test fun biGietThiThanTrongHon() {
        assertEquals(2049, ModelMemory.estimateMb(555, 0, 1))       // (555×2+256) × 1,5
        assertEquals(3074, ModelMemory.estimateMb(555, 0, 2))
        assertEquals(3074, ModelMemory.estimateMb(555, 0, 9))       // trần 2 lần
        assertEquals(1688, ModelMemory.estimateMb(555, 900, 1))     // 1125 × 1,5
        assertEquals(384, ModelMemory.estimateMb(0, 0, 1))
    }

    @Test fun quyetDinhVuaKhongVuaTheoRamTrong() {
        // máy 4096 MB: chừa int(4096 × 0,15) = 614
        assertTrue(ModelMemory.fits(1366, 3000L, 4096))
        assertFalse(ModelMemory.fits(1366, 1900L, 4096))
        assertTrue(ModelMemory.fits(1366, 1980L, 4096))             // đúng biên
        assertFalse(ModelMemory.fits(1366, 1979L, 4096))
    }

    // ------------------------------------------------------------------ sổ ghi nhớ
    @Test fun chetLucNapThiGhiNhanVaHetHanSau7Ngay() {
        var now = 1_000_000L
        val l = MemoryLedger(MemStore()) { now }
        assertEquals(0, l.kills("gemma"))
        l.beginLoad("gemma"); l.recoverAfterCrash()
        assertEquals(1, l.kills("gemma"))
        l.recoverAfterCrash()                                       // lần mở sau không chết ⇒ không tăng
        assertEquals(1, l.kills("gemma"))
        l.beginLoad("gemma"); l.recoverAfterCrash()
        assertEquals(2, l.kills("gemma"))
        now += ModelMemory.KILL_TTL_MS + 1
        assertEquals(0, l.kills("gemma"))                           // bằng chứng hết hạn
        l.beginLoad("gemma"); l.recoverAfterCrash()
        assertEquals(1, l.kills("gemma"))                           // đếm lại từ 1
    }

    @Test fun napThanhCongXoaDemVaGhiSoDo() {
        val l = MemoryLedger(MemStore()) { 5L }
        l.beginLoad("gemma"); l.recoverAfterCrash()
        assertEquals(1, l.kills("gemma"))
        l.beginLoad("gemma"); l.endLoad("gemma", 800)
        assertEquals(0, l.kills("gemma"))
        assertEquals(800, l.learnedMb("gemma"))
        l.beginLoad("gemma"); l.endLoad("gemma", 0)                 // số đo 0 không ghi đè
        assertEquals(800, l.learnedMb("gemma"))
        assertEquals(0, l.learnedMb("isnet"))                       // độc lập theo model
    }

    @Test fun ngoaiLeLucNapKhongBiTinhLaBiGiet() {
        val l = MemoryLedger(MemStore()) { 5L }
        l.beginLoad("lama"); l.abortLoad(); l.recoverAfterCrash()
        assertEquals(0, l.kills("lama"))
    }

    // ------------------------------------------------------------------ móc định tuyến
    @Test fun memoryGuardLocNhaCungCapVaMacDinhChoQua() {
        val cfg = Routing.parse(
            """{"version":1,"tasks":{"understand_prompt":{"providers":[
                {"id":"gemma","kind":"gemma_mediapipe","needs":["file:llm.task"],"minRamMb":4000},
                {"id":"rules","kind":"rules","needs":[]}]}}}"""
        )
        val dev = DeviceInfo(8000, "", 33, 8)
        val saved = Routing.memoryGuard
        try {
            Routing.memoryGuard = { true }
            assertEquals(listOf("gemma", "rules"), Routing.chain(cfg, "understand_prompt", dev, "pro") { true }.map { it.id })
            Routing.memoryGuard = { p -> p.id != "gemma" }          // bằng chứng nói gemma chưa đủ RAM
            assertEquals(listOf("rules"), Routing.chain(cfg, "understand_prompt", dev, "pro") { true }.map { it.id })
            assertTrue(Routing.describe(cfg, dev, "pro") { true }.contains("RAM trống không đủ"))
        } finally {
            Routing.memoryGuard = saved
        }
    }
}
