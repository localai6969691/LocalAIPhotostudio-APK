package com.aiphoto.studio

import com.aiphoto.studio.ui.BackAction
import com.aiphoto.studio.ui.TOP_BAR_ACTION_COUNT
import com.aiphoto.studio.ui.TOP_BAR_ACTION_MIN_DP
import com.aiphoto.studio.ui.TOP_BAR_TITLE_MIN_DP
import com.aiphoto.studio.ui.controlsMaxHeightDp
import com.aiphoto.studio.ui.decideBack
import com.aiphoto.studio.ui.isWideLayout
import com.aiphoto.studio.ui.sidePanelWidthDp
import com.aiphoto.studio.ui.topBarActionsMinWidthDp
import com.aiphoto.studio.ui.topBarShowsTitle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R45: ba lỗi thấy trên máy thật (điện thoại 1080x2400, ~411dp) — thanh trên tràn khiến tiêu đề xuống dòng từng ký tự (thanh trên ~1000px, ảnh còn 0px, nút ⚙ ra
 * ngoài màn hình), bảng điều khiển dưới chiếm ~50% chiều cao, và vuốt Back thoát app ngay. Các quy tắc thuần ở ui/AdaptiveLayout.kt.
 */
class R45LayoutBackTest {
    // ------------------------------------------------------------ thanh trên

    @Test fun sevenActionsFitTheNarrowestPhoneWithoutScrolling() {
        // điện thoại hẹp nhất cần hỗ trợ: 360dp, lề mỗi bên 10dp ⇒ 340dp khả dụng
        assertEquals(7, TOP_BAR_ACTION_COUNT)
        assertTrue("7 nút phải vừa 340dp", topBarActionsMinWidthDp() <= 340)
    }

    @Test fun actionsStayAtLeastTouchableSize() {
        assertTrue("vùng chạm không nhỏ hơn 44dp", TOP_BAR_ACTION_MIN_DP >= 44)
    }

    @Test fun titleIsHiddenOnPhonesInsteadOfBeingSqueezedToZeroWidth() {
        // đúng máy trong ảnh chụp: 1080px / mật độ 2,75 ≈ 392dp, trừ lề 20dp ≈ 372dp khả dụng
        assertFalse("điện thoại 411dp không còn chỗ cho tiêu đề cùng 7 nút", topBarShowsTitle(392 - 20))
        assertFalse(topBarShowsTitle(340))
        assertTrue(topBarShowsTitle(TOP_BAR_TITLE_MIN_DP))
        assertTrue("máy tính bảng / cửa sổ rộng có tiêu đề", topBarShowsTitle(700))
    }

    @Test fun whenTitleShownThereIsRoomLeftForItBesideTheActions() {
        // tiêu đề chỉ hiện khi sau khi trừ 7 nút vẫn còn >= 90dp cho chữ
        assertTrue(TOP_BAR_TITLE_MIN_DP - topBarActionsMinWidthDp() >= 90)
    }

    @Test fun wideLayoutLeftColumnTitleDecision() {
        // máy tính bảng nằm ngang 1280x800dp: cột trái = 1280 - 460 (khung phải) - 30
        val left = 1280 - sidePanelWidthDp(1280) - 30
        assertTrue(isWideLayout(1280, 800))
        assertTrue(topBarShowsTitle(left))
        // điện thoại nằm ngang 850x390dp: cột trái hẹp hơn nhiều nhưng vẫn >= 420dp
        val phoneLandscape = 850 - sidePanelWidthDp(850) - 30
        assertTrue(isWideLayout(850, 390))
        assertEquals(phoneLandscape >= TOP_BAR_TITLE_MIN_DP, topBarShowsTitle(phoneLandscape))
    }

    // ------------------------------------------------------------ bảng điều khiển dưới ảnh

    @Test fun controlsPanelNeverTakesMoreThanAboutHalfTheWindow() {
        // điện thoại 2400px / 2,75 ≈ 873dp cao
        val max = controlsMaxHeightDp(873)
        assertTrue(max < 873 / 2)
        assertEquals(392, max)
    }

    @Test fun controlsPanelKeepsAUsableMinimumInTinyWindows() {
        assertEquals(140, controlsMaxHeightDp(200))
        assertEquals(140, controlsMaxHeightDp(0))
    }

    @Test fun imageAreaKeepsRealSpaceOnTheScreenInTheBugReport() {
        // ảnh chụp: cao ~873dp; trừ vùng an toàn ~60dp, thanh trên ~56dp, lề 12dp, trần bảng điều khiển
        val canvas = 873 - 60 - 56 - 12 - controlsMaxHeightDp(873)
        assertTrue("vùng ảnh phải còn ít nhất 250dp (trước đây 0)", canvas >= 250)
    }

    // ------------------------------------------------------------ nút Back

    @Test fun backLeavesPaintModeFirst() {
        assertEquals(BackAction.LEAVE_PAINT, decideBack(paintActive = true, panelOpen = true, hasImage = true))
        assertEquals(BackAction.LEAVE_PAINT, decideBack(paintActive = true, panelOpen = false, hasImage = true))
    }

    @Test fun backClosesAnOpenPanelBeforeAnythingElse() {
        assertEquals(BackAction.CLOSE_PANEL, decideBack(paintActive = false, panelOpen = true, hasImage = true))
        assertEquals(BackAction.CLOSE_PANEL, decideBack(paintActive = false, panelOpen = true, hasImage = false))
    }

    @Test fun backWithAnImageAsksBeforeExiting() {
        assertEquals(BackAction.CONFIRM_EXIT, decideBack(paintActive = false, panelOpen = false, hasImage = true))
    }

    @Test fun backWithNothingOpenLetsTheSystemExit() {
        assertEquals(BackAction.SYSTEM, decideBack(paintActive = false, panelOpen = false, hasImage = false))
    }

    @Test fun backSequenceReachesTheExitDialogInAtMostThreeSteps() {
        // ảnh vừa mở: tô + thẻ AI đang mở ⇒ 1) thoát tô  2) thu gọn thẻ  3) hỏi thoát
        var paint = true; var panel = true
        val steps = ArrayList<BackAction>()
        while (true) {
            val a = decideBack(paint, panel, hasImage = true)
            steps.add(a)
            when (a) {
                BackAction.LEAVE_PAINT -> paint = false
                BackAction.CLOSE_PANEL -> panel = false
                else -> break
            }
        }
        assertEquals(listOf(BackAction.LEAVE_PAINT, BackAction.CLOSE_PANEL, BackAction.CONFIRM_EXIT), steps)
    }
}
