package com.aiphoto.studio

import com.aiphoto.studio.engine.Reframe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * R29 Reframe 2.5D: độ sâu giả (trời / mặt đất / chủ thể + lọc dẫn hướng), dịch theo độ sâu (z-buffer + lấp vết nứt + kéo ngược màu),
 * lấp chỗ lộ ra bằng màu nền (không rò màu chủ thể), phóng che viền. Cảnh tổng hợp có đáp án giải tích nên kiểm được từng điểm ảnh.
 */
class R29ReframeTest {

    // ------------------------------------------------------------------ tiện ích
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    private fun red(c: Int) = (c shr 16) and 255
    private fun grn(c: Int) = (c shr 8) and 255
    private fun blu(c: Int) = c and 255

    private fun hash(x: Int, y: Int, s: Int = 0): Int {
        var v = x * 374761393 + y * 668265263 + s * 1274126177
        v = (v xor (v ushr 13)) * 1274126177
        v = v xor (v ushr 16)
        return v and 0x7fffffff
    }

    /** Màu nhiễu theo vị trí: mỗi điểm ảnh một màu riêng nên mọi phép dịch sai đều lộ ra khi so điểm–điểm. */
    private fun noisy(x: Int, y: Int, s: Int = 0) = rgb(hash(x, y, s) % 256, hash(x, y, s + 1) % 256, hash(x, y, s + 2) % 256)

    private class Scene(val w: Int, val h: Int, val px: IntArray, val sky: FloatArray, val sub: FloatArray)

    /** Trời xanh phía trên [horizon], đất xanh lá nhiễu, chủ thể elip đỏ (mặt nạ có thể lệch [maskShift] điểm ảnh sang phải so với ảnh). */
    private fun scene(
        w: Int = 160, h: Int = 120, horizon: Int = 48, cx: Int = 80, cy: Int = 80, rx: Int = 15, ry: Int = 25, maskShift: Int = 0, withSubject: Boolean = true,
        dark: Boolean = false
    ): Scene {
        val px = IntArray(w * h)
        val sky = FloatArray(w * h)
        val sub = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (y < horizon) {
                px[i] = rgb(90 + y % 7, 150 + y % 5, 230)
                sky[i] = 1f
            } else {
                px[i] = rgb(40 + hash(x, y) % 20, 130 + hash(x, y, 1) % 30, 40 + hash(x, y, 2) % 20)
            }
            if (withSubject) {
                val dx = (x - cx).toFloat() / rx
                val dy = (y - cy).toFloat() / ry
                if (dx * dx + dy * dy <= 1f) px[i] = if (dark) rgb(25 + hash(x, y) % 8, 20, 20) else rgb(210 + hash(x, y) % 10, 30 + hash(x, y, 1) % 10, 40)
                val mx = (x - cx - maskShift).toFloat() / rx
                if (mx * mx + dy * dy <= 1f) sub[i] = 1f
            }
        }
        return Scene(w, h, px, sky, sub)
    }

    private fun depthOf(s: Scene, subject: Boolean = true, sky: Boolean = true) =
        Reframe.depthMap(s.px, s.w, s.h, if (subject) s.sub else null, if (sky) s.sky else null)

    /** Cảnh phẳng hai lớp: nền màu đều ở độ sâu [bgD], chữ nhật chủ thể đỏ ở độ sâu [fgD]. */
    private class Flat(val w: Int, val h: Int, val px: IntArray, val d: FloatArray)

    private fun flat(w: Int, h: Int, x0: Int, x1: Int, y0: Int, y1: Int, bgD: Float, fgD: Float, noisyBg: Boolean = false): Flat {
        val px = IntArray(w * h)
        val d = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val inside = x in x0 until x1 && y in y0 until y1
            px[i] = if (inside) rgb(220, 30, 30) else if (noisyBg) noisy(x, y) else rgb(50, 160, 50)
            d[i] = if (inside) fgD else bgD
        }
        return Flat(w, h, px, d)
    }

    // ------------------------------------------------------------------ hằng số bất biến
    @Test fun constantsOrdering() {
        // độ sâu chủ thể = SUBJECT_MIN + (1 − SUBJECT_MIN)·g (g = vị trí chân), mặt đất cùng hàng = GROUND_MAX·g: chủ thể luôn gần hơn nền sau lưng nó rõ rệt
        for (k in 0..10) {
            val g = k / 10f
            val gap = Reframe.SUBJECT_MIN + (1f - Reframe.SUBJECT_MIN) * g - Reframe.GROUND_MAX * g
            assertTrue("g=$g gap=$gap", gap > 3f * Reframe.OCCLUDER_TOL)
        }
        assertTrue("vết nứt phải hẹp hơn ngưỡng vật che", Reframe.CRACK_TOL < Reframe.OCCLUDER_TOL)
        assertTrue(Reframe.GROUND_MAX in 0.3f..0.9f)
        assertTrue(Reframe.MAX_SHIFT_FRAC in 0.005f..0.08f)
        assertTrue(Reframe.MIN_SHIFT_PX > 0f && Reframe.MIN_DEPTH_RANGE > 0f)
    }

    // ------------------------------------------------------------------ shift
    @Test fun shiftScalesWithLongSideAndAngle() {
        val s = Reframe.shift(1f, 0.5f, 1f, 400, 300)
        assertEquals(0.03f * 400f, s[0], 1e-4f)
        assertEquals(0.03f * 400f * 0.5f, s[1], 1e-4f)
    }

    @Test fun shiftClampsAngleAndGain() {
        val a = Reframe.shift(5f, -7f, 1f, 200, 100)
        assertEquals(0.03f * 200f, a[0], 1e-4f)
        assertEquals(-0.03f * 200f, a[1], 1e-4f)
        val g = Reframe.shift(1f, 0f, 9f, 200, 100)
        assertEquals(0.03f * 200f * 2f, g[0], 1e-4f)          // gain tối đa 2
        val z = Reframe.shift(1f, 1f, -3f, 200, 100)
        assertEquals(0f, z[0], 0f)
        assertEquals(0f, z[1], 0f)
        val n = Reframe.shift(0f, 0f, 1f, 200, 100)
        assertEquals(0f, n[0], 0f)
    }

    // ------------------------------------------------------------------ bộ lọc cơ bản
    @Test fun boxMeanConstantAndKnownValues() {
        val c = Reframe.boxMean(FloatArray(5 * 4) { 7f }, 5, 4, 2)
        for (v in c) assertEquals(7f, v, 1e-4f)
        // một hàng, biên chia theo số điểm thật trong cửa sổ
        val row = Reframe.boxMean(floatArrayOf(3f, 6f, 9f), 3, 1, 1)
        assertEquals(4.5f, row[0], 1e-5f)
        assertEquals(6f, row[1], 1e-5f)
        assertEquals(7.5f, row[2], 1e-5f)
        val spike = Reframe.boxMean(floatArrayOf(0f, 0f, 0f, 9f, 0f, 0f, 0f), 7, 1, 1)
        assertEquals(3f, spike[2], 1e-5f); assertEquals(3f, spike[3], 1e-5f); assertEquals(3f, spike[4], 1e-5f)
        assertEquals(0f, spike[1], 1e-5f); assertEquals(0f, spike[5], 1e-5f)
    }

    @Test fun boxMeanMatchesBruteForce2D() {
        val w = 9; val h = 7; val r = 2
        val src = FloatArray(w * h) { (hash(it, 3) % 1000) / 10f }
        val got = Reframe.boxMean(src, w, h, r)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0.0; var n = 0
            for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) { s += src[yy * w + xx]; n++ }
            assertEquals("($x,$y)", (s / n).toFloat(), got[y * w + x], 1e-3f)
        }
    }

    @Test fun extremeFilterMatchesBruteForce() {
        for ((w, h, r) in listOf(Triple(11, 8, 1), Triple(11, 8, 3), Triple(6, 9, 20), Triple(1, 1, 2), Triple(13, 1, 4))) {
            val src = FloatArray(w * h) { (hash(it, w * 7 + r) % 1000) / 10f }
            for (wantMin in listOf(true, false)) {
                val got = Reframe.extremeFilter(src, w, h, r, wantMin)
                for (y in 0 until h) for (x in 0 until w) {
                    var best = if (wantMin) Float.MAX_VALUE else -Float.MAX_VALUE
                    for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) {
                        val v = src[yy * w + xx]
                        best = if (wantMin) min(best, v) else max(best, v)
                    }
                    assertEquals("w=$w h=$h r=$r min=$wantMin ($x,$y)", best, got[y * w + x], 0f)
                }
            }
        }
    }

    @Test fun guidedFilterReproducesLinearFunctionOfGuide() {
        val w = 24; val h = 16
        val guide = FloatArray(w * h) { (hash(it, 5) % 1000) / 1000f }
        val p = FloatArray(w * h) { 2f * guide[it] + 0.1f }
        val out = Reframe.guidedFilter(guide, p, w, h, 3, 1e-6f)
        for (y in 4 until h - 4) for (x in 4 until w - 4) assertEquals("($x,$y)", p[y * w + x], out[y * w + x], 5e-3f)
    }

    @Test fun guidedFilterSnapsEdgeToGuideEdge() {
        val w = 32; val h = 8
        val guide = FloatArray(w * h) { if (it % w < 16) 0.1f else 0.9f }
        val p = FloatArray(w * h) { if (it % w < 15) 0f else 1f }        // cạnh của p lệch 1 điểm ảnh so với ảnh dẫn (16)
        val gf = Reframe.guidedFilter(guide, p, w, h, 4, 1e-4f)
        val bm = Reframe.boxMean(p, w, h, 4)
        val y = 3
        assertTrue("lọc dẫn hướng kéo điểm lệch về phía ảnh dẫn: gf=${gf[y * w + 15]} bm=${bm[y * w + 15]}", gf[y * w + 15] < bm[y * w + 15] - 0.1f)
        assertTrue("gf=${gf[y * w + 15]}", gf[y * w + 15] < 0.5f)
        assertTrue("trung bình hộp thì không: ${bm[y * w + 15]}", bm[y * w + 15] > 0.5f)
        assertTrue(gf[y * w + 20] > 0.9f && gf[y * w + 5] < 0.1f)
    }

    // ------------------------------------------------------------------ độ sâu giả
    @Test fun depthSkyFarGroundRampsSubjectNear() {
        val s = scene()
        val d = depthOf(s)
        assertTrue(d.hasSky && d.hasSubject)
        assertEquals(s.w * s.h, d.d.size)
        for (v in d.d) assertTrue(v in 0f..1f)
        val at = { x: Int, y: Int -> d.d[y * s.w + x] }
        assertTrue("trời ở xa nhất: ${at(10, 5)}", at(10, 5) < 0.03f)
        assertEquals(0.375f, d.horizon, 0.03f)                    // trời phủ 48/120 hàng = 0,4; chân trời nằm quanh đó
        assertTrue(at(10, 60) < at(10, 90) && at(10, 90) < at(10, 115))
        assertTrue("đáy ảnh không vượt GROUND_MAX: ${at(10, 119)}", at(10, 119) <= Reframe.GROUND_MAX + 0.02f)
        assertTrue("đáy ảnh phải gần hơn mặt đất gần chân trời", at(10, 119) > 0.5f)
        assertEquals(d.focus, at(80, 80), 0f)
        assertTrue("chủ thể ≥ SUBJECT_MIN: ${d.focus}", d.focus >= Reframe.SUBJECT_MIN)
        assertTrue("chủ thể gần hơn mặt đất cùng hàng", at(80, 80) > at(40, 80) + 0.2f)
    }

    @Test fun depthSubjectDepthFollowsFootPosition() {
        val low = depthOf(scene(cy = 90, ry = 20))      // chân ở hàng 110
        val high = depthOf(scene(cy = 70, ry = 20))     // chân ở hàng 90
        assertTrue("chân thấp hơn → gần hơn: ${low.focus} vs ${high.focus}", low.focus > high.focus + 0.03f)
        // pin: foot ≈ hàng 105, đất từ 48 → ground = (105,5−48)/72 ≈ 0,80 → 0,62 + 0,38·0,80 ≈ 0,92
        val d = depthOf(scene())
        assertEquals(0.92f, d.focus, 0.02f)
    }

    @Test fun depthSubjectEdgeIsBinary() {
        val s = scene()
        val d = depthOf(s)
        for (i in d.d.indices) {
            val v = d.d[i]
            assertTrue("điểm $i có độ sâu trung gian $v", v == d.focus || v <= Reframe.GROUND_MAX + 0.02f)
        }
        var subjectPixels = 0
        for (v in d.d) if (v == d.focus) subjectPixels++
        val ellipse = Math.PI * 15 * 25
        assertEquals(ellipse, subjectPixels.toDouble(), ellipse * 0.1)
    }

    @Test fun depthEdgeSnapsToImageEdgeWhenMaskIsSlightlyOff() {
        // cỡ làm việc 640 (r = 5): mặt nạ lệch phải 2 điểm so với chủ thể thật (cạnh thật ở x = 260, mặt nạ ở 262); chủ thể tối để cạnh ảnh đủ rõ
        val s = scene(w = 640, h = 480, horizon = 192, cx = 320, cy = 320, rx = 60, ry = 100, maskShift = 2, dark = true)
        val d = depthOf(s)
        val y = 320
        var firstSubject = -1
        for (x in 0 until s.w) if (d.d[y * s.w + x] == d.focus) { firstSubject = x; break }
        assertTrue("cạnh độ sâu ($firstSubject) phải gần cạnh ảnh thật (260) hơn mép mặt nạ (262)", firstSubject in 259..261)
        // mặt nạ khớp sẵn thì không bị lệch đi
        val t = scene(w = 640, h = 480, horizon = 192, cx = 320, cy = 320, rx = 60, ry = 100, maskShift = 0, dark = true)
        val dt = depthOf(t)
        var f0 = -1
        for (x in 0 until t.w) if (dt.d[y * t.w + x] == dt.focus) { f0 = x; break }
        assertTrue("mặt nạ đúng: $f0", f0 in 259..261)
    }

    @Test fun depthWithoutCuesIsPureGroundRamp() {
        val s = scene(withSubject = false)
        val d = depthOf(s, subject = false, sky = false)
        assertFalse(d.hasSubject); assertFalse(d.hasSky)
        assertEquals(0f, d.horizon, 1e-6f)
        val at = { y: Int -> d.d[y * s.w + 20] }
        assertTrue(at(10) < at(60) && at(60) < at(110))
        // 0,65 · y / h
        assertEquals(Reframe.GROUND_MAX * 60.5f / s.h, at(60), 0.06f)
        var sum = 0.0
        for (v in d.d) sum += v
        assertEquals(Reframe.GROUND_MAX / 2.0, d.focus.toDouble(), 0.03)
        assertEquals(sum / d.d.size, d.focus.toDouble(), 1e-3)
    }

    @Test fun depthHorizonNeedsEnoughSkyPerRow() {
        val w = 160; val h = 120
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        val sky = FloatArray(w * h)
        for (y in 0 until 120) for (x in 0 until w) {
            val cover = when {
                y < 48 -> w                    // trời kín
                y < 54 -> w / 2                // 50 % — đủ (≥ 30 %)
                y < 57 -> 8                    // 5 % — không đủ
                else -> 0
            }
            if (x < cover) sky[y * w + x] = 1f
        }
        val d = Reframe.depthMap(px, w, h, null, sky)
        assertTrue(d.hasSky)
        assertEquals(54f / 120f, d.horizon, 1e-4f)
    }

    @Test fun depthIgnoresSkyThatReachesTheBottomOfTheImage() {
        // ảnh toàn "trời" (hay gặp khi bộ nhận trời nhận nhầm mặt gỗ / lông thú là trời): không có mặt đất để dốc ⇒ bỏ trời, độ sâu theo vị trí
        val w = 64; val h = 48
        val px = IntArray(w * h) { rgb(100, 150, 230) }
        val d = Reframe.depthMap(px, w, h, null, FloatArray(w * h) { 1f })
        assertFalse(d.hasSky)
        assertEquals(0f, d.horizon, 0f)
        for (v in d.d) assertTrue("hữu hạn: $v", v.isFinite() && v in 0f..1f)
        assertTrue("dốc theo vị trí: ${d.d[2 * w]} < ${d.d[45 * w]}", d.d[2 * w] + 0.3f < d.d[45 * w])
        assertTrue(d.focus.isFinite() && d.focus > 0.1f)
    }

    @Test fun depthSkyHorizonLimitIsEightyPercentOfHeight() {
        val w = 40; val h = 100
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        fun sky(rows: Int) = FloatArray(w * h) { if (it / w < rows) 1f else 0f }
        val atLimit = Reframe.depthMap(px, w, h, null, sky(80))
        assertTrue("đúng 80 %: vẫn dùng", atLimit.hasSky)
        assertEquals(0.8f, atLimit.horizon, 1e-4f)
        val over = Reframe.depthMap(px, w, h, null, sky(81))
        assertFalse("81 %: bỏ", over.hasSky)
        assertEquals(0f, over.horizon, 0f)
        // 60 % vẫn dùng, trời xa nhất
        val ok = Reframe.depthMap(px, w, h, null, sky(60))
        assertTrue(ok.hasSky && ok.d[10 * w] < 0.02f && ok.d[99 * w] > 0.5f)
    }

    @Test fun depthSkyPatchBelowHorizonStaysFar() {
        // khoảng trời lọt giữa tán cây ở nửa dưới ảnh vẫn phải ở xa (không lấy độ sâu mặt đất theo hàng)
        val s = scene(withSubject = false)
        for (y in 80 until 100) for (x in 100 until 130) { s.sky[y * s.w + x] = 1f; s.px[y * s.w + x] = rgb(100, 160, 230) }
        val d = depthOf(s, subject = false)
        assertTrue("khoảng trời dưới chân trời: ${d.d[90 * s.w + 115]}", d.d[90 * s.w + 115] < 0.05f)
        assertTrue("mặt đất cùng hàng thì gần: ${d.d[90 * s.w + 30]}", d.d[90 * s.w + 30] > 0.25f)
        assertEquals(0.4f, d.horizon, 0.03f)
    }

    @Test fun depthIgnoresTinySubjectAndTinySky() {
        // chủ thể 4×4 trên ảnh 160×120 = 0,08 % < SUBJECT_MIN_AREA
        val s = scene(rx = 2, ry = 2)
        val d = depthOf(s)
        assertFalse("chủ thể quá nhỏ không được dùng", d.hasSubject)
        // trời 2 hàng / 120 = 1,7 % < SKY_MIN_AREA
        val t = scene(horizon = 2)
        val dt = depthOf(t)
        assertFalse("trời quá ít không được dùng", dt.hasSky)
        assertTrue(dt.hasSubject)
    }

    @Test fun depthIgnoresMasksOfWrongSize() {
        val s = scene()
        val d = Reframe.depthMap(s.px, s.w, s.h, FloatArray(10), FloatArray(7))
        assertFalse(d.hasSubject); assertFalse(d.hasSky)
        assertEquals(s.w * s.h, d.d.size)
    }

    @Test fun depthOnLargeImageUsesWorkingResolutionButReturnsFullSize() {
        val s = scene(w = 1280, h = 960, horizon = 384, cx = 640, cy = 640, rx = 120, ry = 200)
        val d = depthOf(s)
        assertEquals(1280 * 960, d.d.size)
        assertTrue(d.hasSky && d.hasSubject)
        val at = { x: Int, y: Int -> d.d[y * 1280 + x] }
        assertTrue(at(50, 20) < 0.03f)
        assertTrue(at(50, 600) < at(50, 900))
        assertEquals(d.focus, at(640, 640), 0f)
        assertTrue(d.focus > 0.85f)
    }

    // ------------------------------------------------------------------ warp
    @Test fun warpConstantDepthAtFocusIsIdentity() {
        val w = 20; val h = 12
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        val f = Reframe.warp(px, w, h, FloatArray(w * h) { 0.5f }, 0.5f, 17f, -9f)
        for (i in px.indices) { assertFalse(f.hole[i]); assertEquals(px[i], f.color[i]); assertEquals(0.5f, f.dd[i], 0f) }
    }

    @Test fun warpUniformNearLayerTranslatesExactlyAndLeavesBorderHoles() {
        val w = 30; val h = 14
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        // e = 0,8 − 0,5 = 0,3; sx = 10 → +3 ngang; sy = −10 → −3 dọc
        val f = Reframe.warp(px, w, h, FloatArray(w * h) { 0.8f }, 0.5f, 10f, -10f)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val inside = x >= 3 && y < h - 3
            assertEquals("hole ($x,$y)", !inside, f.hole[i])
            assertEquals("hole ⇔ dd < 0", !inside, f.dd[i] < 0f)
            if (inside) assertEquals("màu ($x,$y)", px[(y + 3) * w + (x - 3)], f.color[i])
        }
    }

    @Test fun warpFarLayerMovesOppositeToNearLayer() {
        val w = 64; val h = 6
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        // trái: xa (0,2), phải: gần (0,9); điểm xoay 0,5; sx = 20 → xa dịch −6, gần dịch +8 → hở một khe giữa hai lớp
        val d = FloatArray(w * h) { if (it % w < 32) 0.2f else 0.9f }
        val f = Reframe.warp(px, w, h, d, 0.5f, 20f, 0f)
        val y = 2
        for (x in 0..20) assertEquals("xa ($x)", px[y * w + x + 6], f.color[y * w + x])
        for (x in 45 until w) assertEquals("gần ($x)", px[y * w + x - 8], f.color[y * w + x])
        // lớp xa còn lại x ∈ [0, 26), lớp gần bắt đầu từ 32 + 8 = 40 → khe [26, 40) là chỗ trống
        for (x in 26 until 40) assertTrue("khe ($x)", f.hole[y * w + x])
        assertFalse(f.hole[y * w + 25]); assertFalse(f.hole[y * w + 40])
    }

    @Test fun warpNearerLayerWinsWhereLayersOverlap() {
        val w = 64; val h = 4
        val px = IntArray(w * h) { noisy(it % w, it / w, 4) }
        // trái: GẦN dịch +8, phải: XA dịch −6 → chồng lên nhau 14 điểm quanh x = 32: gần phải thắng
        val d = FloatArray(w * h) { if (it % w < 32) 0.9f else 0.2f }
        val f = Reframe.warp(px, w, h, d, 0.5f, 20f, 0f)
        val y = 1
        for (x in 26..39) {
            assertFalse("($x)", f.hole[y * w + x])
            if (x <= 39) assertEquals("độ sâu tại $x phải là lớp gần", 0.9f, f.dd[y * w + x], 1e-6f)
        }
        // ngay sau vùng chồng, lớp xa lộ ra trở lại
        assertEquals(0.2f, f.dd[y * w + 41], 1e-6f)
        // màu của vùng chồng lấy từ lớp gần: nguồn x − 8 (< 32)
        for (x in 26..31) assertEquals(px[y * w + x - 8], f.color[y * w + x])
    }

    @Test fun warpFillsStretchCracksOnSmoothRamp() {
        val w = 100; val h = 5
        val px = IntArray(w * h) { noisy(it % w, it / w, 9) }
        val d = FloatArray(w * h) { 0.2f + 0.6f * (it % w) / w }
        val f = Reframe.warp(px, w, h, d, 0.2f, 30f, 0f)         // e ≥ 0 → kéo giãn ≈ 18 %
        var holes = 0
        for (v in f.hole) if (v) holes++
        assertEquals("vết nứt 1 điểm ảnh phải được lấp, không để thành lỗ", 0, holes)
        val y = 2
        for (x in 1 until w - 1) {
            val a = f.dd[y * w + x - 1]; val b = f.dd[y * w + x]; val c = f.dd[y * w + x + 1]
            assertTrue("độ sâu đơn điệu tại $x: $a $b $c", b >= a - 1e-6f && b <= c + 1e-6f)
        }
    }

    @Test fun warpFillsTwoPixelCracksButNotThreePixelGaps() {
        val w = 100; val h = 5
        val px = IntArray(w * h) { noisy(it % w, it / w, 11) }
        // dest(x) = x + 300·(0,6·x/w) = 2,8·x → khe ≈ 2 điểm ảnh giữa hai điểm liên tiếp của cùng một dốc
        val d = FloatArray(w * h) { 0.2f + 0.6f * (it % w) / w }
        val f = Reframe.warp(px, w, h, d, 0.2f, 300f, 0f)
        var holes = 0
        for (y in 0 until h) for (x in 0 until w - 4) if (f.hole[y * w + x]) holes++      // 4 cột cuối: mép ảnh thật, chưa có điểm nguồn nào đẩy tới
        assertEquals("khe 2 điểm ảnh phải được nội suy", 0, holes)
        val y = 3
        for (x in 1 until w - 4) assertTrue("dd đơn điệu tại $x", f.dd[y * w + x] >= f.dd[y * w + x - 1] - 1e-6f)
        // dest(x) = x + 700·(0,6·x/w) = 5,2·x → khe ≈ 4 điểm ảnh: quá rộng, phải để trống
        val g = Reframe.warp(px, w, h, d, 0.2f, 700f, 0f)
        var holes2 = 0
        for (v in g.hole) if (v) holes2++
        assertTrue("khe 4 điểm ảnh không được lấp ở bước này: $holes2", holes2 > 0)
    }

    @Test fun warpInterpolatesCrackDepthLinearly() {
        val w = 12; val h = 1
        val px = IntArray(w) { noisy(it, 0) }
        // hai điểm nguồn cùng bề mặt (độ sâu 0,50 và 0,53) bị kéo cách nhau 3 điểm: hai điểm giữa nội suy 0,51 và 0,52
        val d = FloatArray(w) { if (it < 6) 0.50f else 0.53f }
        // lớp trái e = 0 (đứng yên), lớp phải e = 0,03 → cần dịch 2 điểm: sx = 2/0,03
        val f = Reframe.warp(px, w, h, d, 0.5f, 2f / 0.03f, 0f)
        assertEquals(0.50f, f.dd[5], 1e-5f)
        assertEquals(0.51f, f.dd[6], 1e-4f)
        assertEquals(0.52f, f.dd[7], 1e-4f)
        assertEquals(0.53f, f.dd[8], 1e-5f)
    }

    @Test fun warpDoesNotBridgeBetweenDifferentSurfaces() {
        // khe giữa hai lớp cách nhau xa về độ sâu phải là chỗ trống thật, không bị coi là vết nứt
        val w = 64; val h = 4
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        val d = FloatArray(w * h) { if (it % w < 32) 0.2f else 0.9f }
        val f = Reframe.warp(px, w, h, d, 0.5f, 20f, 0f)
        var gap = 0
        for (x in 0 until w) if (f.hole[w + x]) gap++
        assertEquals(14, gap)
    }

    @Test fun warpKeepsSubjectAtFocusInPlace() {
        val fl = flat(120, 40, 40, 80, 8, 32, 0.2f, 0.9f, noisyBg = true)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        for (y in 8 until 32) for (x in 40 until 80) {
            val i = y * fl.w + x
            assertFalse(f.hole[i]); assertEquals(fl.px[i], f.color[i]); assertEquals(0.9f, f.dd[i], 0f)
        }
    }

    @Test fun warpHoleCountGrowsWithShift() {
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f, noisyBg = true)
        var last = -1
        for (sx in listOf(4f, 10f, 20f, 40f)) {
            val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, sx, 0f)
            var c = 0
            for (v in f.hole) if (v) c++
            assertTrue("sx=$sx holes=$c last=$last", c > last)
            last = c
        }
    }

    // ------------------------------------------------------------------ fill
    @Test fun fillReturnsSameColorsWhenNoHoles() {
        val w = 10; val h = 10
        val col = IntArray(w * h) { noisy(it % w, it / w) }
        val f = Reframe.Frame(col, BooleanArray(w * h), FloatArray(w * h) { 0.5f })
        assertTrue(Reframe.fill(f, w, h, 4) === col)
    }

    @Test fun fillGivesUpWhenAlmostEverythingIsHole() {
        val w = 20; val h = 20
        val hole = BooleanArray(w * h) { it > 2 }
        val f = Reframe.Frame(IntArray(w * h), hole, FloatArray(w * h) { if (hole[it]) -1f else 0.5f })
        assertNull(Reframe.fill(f, w, h, 4))
    }

    @Test fun fillUsesBackgroundColourNotOccluderColour() {
        val fl = flat(200, 60, 70, 170, 10, 50, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)      // nền trượt trái 14 điểm → khe lộ ra bên trái chủ thể
        var strip = 0
        for (y in 10 until 50) for (x in 56 until 70) if (f.hole[y * fl.w + x]) strip++
        assertEquals("khe lộ ra bên trái chủ thể: 14 × 40", 14 * 40, strip)
        val out = Reframe.fill(f, fl.w, fl.h, 16)!!
        for (y in 10 until 50) for (x in 56 until 70) {
            val c = out[y * fl.w + x]
            assertTrue("($x,$y) phải là màu nền, không phải đỏ: ${Integer.toHexString(c)}", abs(red(c) - 50) <= 3 && abs(grn(c) - 160) <= 3 && abs(blu(c) - 50) <= 3)
        }
    }

    @Test fun fillDoesNotLeakOccluderThroughCoarseLevels() {
        // chủ thể rộng (100 điểm) ≫ dải lấp: phần thân xa chỗ trống không được chi phối màu ở các mức thô
        val fl = flat(240, 40, 60, 200, 5, 35, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        val out = Reframe.fill(f, fl.w, fl.h, 16)!!
        var maxRed = 0
        for (i in out.indices) if (f.hole[i]) maxRed = max(maxRed, red(out[i]))
        assertTrue("đỏ rò vào chỗ lấp: $maxRed", maxRed <= 56)
    }

    @Test fun fillKeepsNonHolePixelsUntouched() {
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f, noisyBg = true)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        val out = Reframe.fill(f, fl.w, fl.h, 16)!!
        for (i in out.indices) if (!f.hole[i]) assertEquals(f.color[i], out[i])
        for (i in out.indices) assertEquals("alpha", 0xFF, out[i] ushr 24)
    }

    @Test fun fillFallsBackToAllKnownPixelsWhenEveryNearbyPixelIsAnOccluder() {
        // 1 hàng: lỗ ở x=20; quanh nó (14..26) là "vật" gần (0,9, đỏ), ngoài dải là nền xa (0,1, xanh) nằm đúng trong cửa sổ 2r của mọi điểm trong dải
        val w = 41; val h = 1
        val col = IntArray(w) { if (it in 14..26) rgb(220, 30, 30) else rgb(40, 160, 40) }
        val dd = FloatArray(w) { if (it in 14..26) 0.9f else 0.1f }
        val hole = BooleanArray(w) { it == 20 }
        dd[20] = -1f
        val out = Reframe.fill(Reframe.Frame(col, hole, dd), w, h, 3)!!
        val c = out[20]
        assertTrue("phải có màu thật, không phải đen: ${Integer.toHexString(c)}", c != 0 && c != 0xFF000000.toInt())
        assertEquals(0xFF, c ushr 24)
        assertTrue(red(c) in 40..220 && grn(c) in 30..160)
    }

    // ------------------------------------------------------------------ cropWindow
    @Test fun cropWindowForUniformShiftCutsOnlyTheEmptySide() {
        val w = 100; val h = 60
        val win = Reframe.cropWindow(FloatArray(w * h) { 0.8f }, 0.5f, 10f, 0f, w, h)       // dịch +3 → trống bên trái 3 điểm
        assertEquals(3f, win[0], 1e-4f)
        assertEquals(w.toFloat(), win[2], 1e-3f)
        assertEquals(w / (w - 3f), win[4], 1e-4f)
        assertEquals((win[2] - win[0]) / (win[3] - win[1]), w.toFloat() / h, 1e-3f)
    }

    @Test fun cropWindowForNearAndFarLayersCutsBothSides() {
        val w = 100; val h = 60
        val d = FloatArray(w * h) { if (it % w < 50) 0.2f else 0.9f }                      // dịch −6 và +8
        val win = Reframe.cropWindow(d, 0.5f, 20f, 0f, w, h)
        assertEquals(8f, win[0], 1e-3f)
        assertEquals(w - 6f, win[2], 1e-3f)
        assertEquals(w / (w - 14f), win[4], 1e-4f)
    }

    @Test fun cropWindowNoShiftIsWholeImage() {
        val win = Reframe.cropWindow(FloatArray(50 * 30) { 0.3f }, 0.3f, 12f, 8f, 50, 30)
        assertEquals(0f, win[0], 0f); assertEquals(0f, win[1], 0f)
        assertEquals(50f, win[2], 1e-4f); assertEquals(30f, win[3], 1e-4f); assertEquals(1f, win[4], 1e-6f)
    }

    @Test fun cropWindowVerticalShiftAndStaysInsideImage() {
        val w = 80; val h = 80
        val d = FloatArray(w * h) { 0.2f + 0.7f * (it / w) / h }
        val win = Reframe.cropWindow(d, 0.5f, -6f, 16f, w, h)
        assertTrue(win[0] >= 0f && win[1] >= 0f && win[2] <= w + 1e-3f && win[3] <= h + 1e-3f)
        assertTrue(win[4] > 1f)
        assertEquals((win[2] - win[0]) / (win[3] - win[1]), 1f, 1e-3f)
    }

    // ------------------------------------------------------------------ render
    private fun rampDepth(w: Int, h: Int) = Reframe.Depth(FloatArray(w * h) { 0.2f + 0.6f * (it % w) / w }, 0.5f, false, false, 0f)

    @Test fun renderReturnsNullWhenNothingToDo() {
        val w = 40; val h = 20
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        assertNull("dịch dưới MIN_SHIFT_PX", Reframe.render(px, w, h, rampDepth(w, h), 0.3f, 0f))
        assertNull(Reframe.render(px, w, h, rampDepth(w, h), 0f, 0f))
        val flatD = Reframe.Depth(FloatArray(w * h) { 0.5f }, 0.5f, false, false, 0f)
        assertNull("độ sâu phẳng", Reframe.render(px, w, h, flatD, 12f, 0f))
        assertNotNull(Reframe.render(px, w, h, rampDepth(w, h), 12f, 0f))
        assertNotNull("dịch đúng MIN_SHIFT_PX trở lên là có làm", Reframe.render(px, w, h, rampDepth(w, h), 0.55f, 0f))
        assertNull(Reframe.render(px, w, h, rampDepth(w, h), 0.45f, 0f))
        assertNotNull("chỉ dịch dọc cũng tính", Reframe.render(px, w, h, rampDepth(w, h), 0f, -3f))
        assertNull("độ sâu gần phẳng (khoảng 0,04 < MIN_DEPTH_RANGE)", Reframe.render(px, w, h, Reframe.Depth(FloatArray(w * h) { 0.5f + 0.04f * (it % w) / w }, 0.5f, false, false, 0f), 12f, 0f))
    }

    @Test fun renderZoomHidesBordersWhenThereAreNoOcclusions() {
        val w = 100; val h = 40
        val px = IntArray(w * h) { noisy(it % w, it / w, 2) }
        val r = Reframe.render(px, w, h, rampDepth(w, h), 20f, 0f)!!       // dịch −6…+6 → viền trống mỗi bên 6 điểm
        assertEquals(w * h, r.px.size)
        val maxShift = 20f * (0.2f + 0.6f * (w - 1) / w - 0.5f)            // điểm cuối của dốc: 5,88
        assertEquals(w / (w - 6f - maxShift), r.zoom, 1e-3f)
        assertEquals("đã phóng đủ che viền, không còn chỗ trống", 0f, r.holeFrac, 0f)
        for (c in r.px) assertEquals(0xFF, c ushr 24)
    }

    @Test fun renderSubjectStaysSharpAndBackgroundIsFilledNotRed() {
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val r = Reframe.render(fl.px, fl.w, fl.h, dep, 20f, 0f)!!
        assertTrue(r.zoom > 1f)
        // số điểm đỏ ≈ diện tích chủ thể × zoom² (không rò sang vùng lấp, không mất)
        var reds = 0
        for (c in r.px) if (red(c) > 200 && grn(c) < 60) reds++
        val expected = 60 * 40 * r.zoom * r.zoom
        assertEquals(expected.toDouble(), reds.toDouble(), expected * 0.06)
        // còn lại là nền xanh (khe đã lấp)
        var bad = 0
        for (c in r.px) {
            val isRed = red(c) > 200 && grn(c) < 60
            val isGreen = abs(red(c) - 50) <= 4 && abs(grn(c) - 160) <= 4 && abs(blu(c) - 50) <= 4
            if (!isRed && !isGreen) bad++
        }
        assertTrue("chỉ phép lẫn ở mép: $bad", bad < 4 * (40 + 60) * r.zoom * 2)
    }

    @Test fun renderIsDeterministicAndDoesNotModifyInputs() {
        val fl = flat(120, 40, 40, 80, 8, 32, 0.2f, 0.9f, noisyBg = true)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val pxCopy = fl.px.copyOf(); val dCopy = fl.d.copyOf()
        val a = Reframe.render(fl.px, fl.w, fl.h, dep, 14f, 5f)!!
        val b = Reframe.render(fl.px, fl.w, fl.h, dep, 14f, 5f)!!
        assertTrue(a.px.contentEquals(b.px)); assertEquals(a.zoom, b.zoom, 0f); assertEquals(a.holeFrac, b.holeFrac, 0f)
        assertTrue(pxCopy.contentEquals(fl.px)); assertTrue(dCopy.contentEquals(fl.d))
    }

    @Test fun renderOppositeAnglesMirrorTheBackgroundSlide() {
        val fl = flat(200, 60, 80, 120, 10, 50, 0.2f, 0.9f, noisyBg = true)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val a = Reframe.render(fl.px, fl.w, fl.h, dep, 16f, 0f)!!
        val b = Reframe.render(fl.px, fl.w, fl.h, dep, -16f, 0f)!!
        assertEquals(a.zoom, b.zoom, 1e-3f)
        // chủ thể (đỏ) nằm gần giữa; trọng tâm điểm đỏ của hai kết quả đối xứng qua tâm ảnh
        fun cx(r: Reframe.Result): Double {
            var s = 0.0; var n = 0
            for (i in r.px.indices) { val c = r.px[i]; if (red(c) > 200 && grn(c) < 60) { s += i % fl.w; n++ } }
            return s / n
        }
        assertEquals(cx(a) + cx(b), fl.w.toDouble(), 2.0)
    }

    @Test fun renderReturnsNullWhenFillImpossible() {
        // mọi điểm bị đẩy ra ngoài ảnh → toàn chỗ trống
        val w = 20; val h = 10
        val px = IntArray(w * h) { noisy(it % w, it / w) }
        val dep = Reframe.Depth(FloatArray(w * h) { if (it % w < 10) 0.1f else 1f }, 0f, false, false, 0f)
        assertNull(Reframe.render(px, w, h, dep, 400f, 0f))
    }

    // ------------------------------------------------------------------ bổ sung sau vòng đột biến 1
    @Test fun guidedFilterMatchesDirectFormula() {
        val w = 11; val h = 9; val r = 2; val eps = 0.01f
        val guide = FloatArray(w * h) { (hash(it, 21) % 1000) / 1000f }
        val p = FloatArray(w * h) { (hash(it, 22) % 1000) / 1000f }
        val got = Reframe.guidedFilter(guide, p, w, h, r, eps)
        val a = DoubleArray(w * h)
        val b = DoubleArray(w * h)
        fun window(x: Int, y: Int, f: (Int) -> Unit) {
            for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) f(yy * w + xx)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var n = 0; var sI = 0.0; var sP = 0.0; var sIP = 0.0; var sII = 0.0
            window(x, y) { i -> n++; sI += guide[i]; sP += p[i]; sIP += guide[i].toDouble() * p[i]; sII += guide[i].toDouble() * guide[i] }
            val mI = sI / n; val mP = sP / n
            val ak = (sIP / n - mI * mP) / (sII / n - mI * mI + eps)
            a[y * w + x] = ak
            b[y * w + x] = mP - ak * mI
        }
        for (y in 0 until h) for (x in 0 until w) {
            var n = 0; var sa = 0.0; var sb = 0.0
            window(x, y) { i -> n++; sa += a[i]; sb += b[i] }
            val expected = (sa / n) * guide[y * w + x] + sb / n
            assertEquals("($x,$y)", expected.toFloat(), got[y * w + x], 1e-4f)
        }
    }

    @Test fun fillCracksInterpolatesOnlyNarrowGapsBetweenSameSurface() {
        fun row(vararg v: Float) = v.copyOf()
        // khe 1 và 2 điểm ảnh: nội suy tuyến tính
        var a = row(0.50f, -1f, 0.52f)
        Reframe.fillCracks(a, 3, 1)
        assertEquals(0.51f, a[1], 1e-5f)
        a = row(0.50f, -1f, -1f, 0.53f)
        Reframe.fillCracks(a, 4, 1)
        assertEquals(0.51f, a[1], 1e-5f); assertEquals(0.52f, a[2], 1e-5f)
        // khe 3 điểm ảnh: quá rộng
        a = row(0.50f, -1f, -1f, -1f, 0.52f)
        Reframe.fillCracks(a, 5, 1)
        assertEquals(-1f, a[1], 0f); assertEquals(-1f, a[2], 0f); assertEquals(-1f, a[3], 0f)
        // hai bề mặt khác nhau (chênh > CRACK_TOL): chỗ lộ ra thật, không nội suy — cả khe 1 và 2
        a = row(0.20f, -1f, 0.90f); Reframe.fillCracks(a, 3, 1); assertEquals(-1f, a[1], 0f)
        a = row(0.50f, -1f, 0.55f); Reframe.fillCracks(a, 3, 1); assertEquals(-1f, a[1], 0f)
        a = row(0.20f, -1f, -1f, 0.90f); Reframe.fillCracks(a, 4, 1); assertEquals(-1f, a[1], 0f); assertEquals(-1f, a[2], 0f)
        // khe chạm mép ảnh không có đầu bên kia
        a = row(0.5f, 0.5f, -1f, -1f); Reframe.fillCracks(a, 4, 1); assertEquals(-1f, a[2], 0f); assertEquals(-1f, a[3], 0f)
        a = row(0.5f, 0.5f, 0.5f, -1f); Reframe.fillCracks(a, 4, 1); assertEquals(-1f, a[3], 0f)
        a = row(-1f, 0.5f, 0.5f, 0.5f); Reframe.fillCracks(a, 4, 1); assertEquals(-1f, a[0], 0f)
    }

    @Test fun fillCracksWorksVerticallyToo() {
        // ba cột: hai cột bên là hai bề mặt rất khác nhau (0,9 và 0,1) nên khe NGANG ở cột giữa không được lấp, chỉ khe DỌC
        fun grid(h: Int, vararg mid: Float): FloatArray {
            val g = FloatArray(3 * h)
            for (y in 0 until h) { g[3 * y] = 0.9f; g[3 * y + 1] = mid[y]; g[3 * y + 2] = 0.1f }
            return g
        }
        var a = grid(3, 0.50f, -1f, 0.52f)
        Reframe.fillCracks(a, 3, 3)
        assertEquals(0.51f, a[3 * 1 + 1], 1e-5f)
        a = grid(4, 0.50f, -1f, -1f, 0.53f)
        Reframe.fillCracks(a, 3, 4)
        assertEquals(0.51f, a[3 * 1 + 1], 1e-5f); assertEquals(0.52f, a[3 * 2 + 1], 1e-5f)
        a = grid(5, 0.50f, -1f, -1f, -1f, 0.52f)
        Reframe.fillCracks(a, 3, 5)
        for (y in 1..3) assertEquals(-1f, a[3 * y + 1], 0f)
        a = grid(3, 0.20f, -1f, 0.90f); Reframe.fillCracks(a, 3, 3); assertEquals(-1f, a[3 * 1 + 1], 0f)
        a = grid(3, -1f, 0.5f, 0.5f); Reframe.fillCracks(a, 3, 3); assertEquals(-1f, a[1], 0f)          // chạm mép trên
        a = grid(3, 0.5f, 0.5f, -1f); Reframe.fillCracks(a, 3, 3); assertEquals(-1f, a[3 * 2 + 1], 0f)    // chạm mép dưới
    }

    @Test fun fillCracksDoesNotWrapAroundRowEnds() {
        // (0,1) trống; điểm cuối hàng 0 (đã biết) KHÔNG phải hàng xóm bên trái của nó
        val w = 4; val h = 2
        val dd = floatArrayOf(-1f, -1f, -1f, 0.5f, -1f, 0.5f, 0.5f, 0.5f)
        Reframe.fillCracks(dd, w, h)
        assertEquals(-1f, dd[4], 0f)
    }

    @Test fun closeCracksNeedsTwoPassesForLShapedGaps() {
        val w = 6; val h = 6
        val dd = FloatArray(w * h) { 0.5f }
        for (x in 1..3) dd[2 * w + x] = -1f
        dd[3 * w + 1] = -1f; dd[3 * w + 3] = -1f; dd[4 * w + 3] = -1f
        val one = dd.copyOf()
        Reframe.fillCracks(one, w, h)
        assertEquals("sau 1 lượt vẫn còn điểm (3,2)", -1f, one[2 * w + 3], 0f)
        Reframe.closeCracks(dd, w, h)
        for (i in dd.indices) assertEquals("điểm $i", 0.5f, dd[i], 1e-6f)
    }

    @Test fun fillRadiusIsLargestRevealedWidthPlusMargin() {
        assertEquals(12, Reframe.fillRadius(10f, -20f, 0.5f))
        assertEquals(5, Reframe.fillRadius(3f, 2f, 1f))
        assertEquals(2, Reframe.fillRadius(0f, 0f, 0.7f))
        assertEquals(6, Reframe.fillRadius(-6.2f, 0f, 0.5f))
        assertEquals(10, Reframe.fillRadius(0f, 4f, 2f))
    }

    @Test fun fillHandlesRadiusLimitsAndHoleFractions() {
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        // bán kính < 2 coi như 2, > MAX coi như MAX
        assertTrue(Reframe.fill(f, fl.w, fl.h, 0)!!.contentEquals(Reframe.fill(f, fl.w, fl.h, 2)!!))
        assertTrue(Reframe.fill(f, fl.w, fl.h, 1000)!!.contentEquals(Reframe.fill(f, fl.w, fl.h, 96)!!))
        // 60 % trống vẫn lấp được; 99,5 % thì bỏ
        val w = 10; val h = 10
        val hole = BooleanArray(w * h) { it < 60 }
        val col = IntArray(w * h) { if (hole[it]) 0 else rgb(40, 120, 200) }
        val ok = Reframe.fill(Reframe.Frame(col, hole, FloatArray(w * h) { if (hole[it]) -1f else 0.5f }), w, h, 4)
        assertNotNull(ok)
        for (i in 0 until 60) assertEquals(rgb(40, 120, 200), ok!![i])
        val few = BooleanArray(200) { it < 199 }
        assertNull(Reframe.fill(Reframe.Frame(IntArray(200), few, FloatArray(200) { if (few[it]) -1f else 0.5f }), 200, 1, 4))
    }

    @Test fun fillWithHoleAsWideAsRadiusStillUsesOnlyBackground() {
        // chỗ lộ ra rộng đúng bằng bán kính (trường hợp xấu nhất mà render tạo ra): điểm vật che cách lỗ tới 2·radius không được lọt vào nguồn
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        val out = Reframe.fill(f, fl.w, fl.h, Reframe.fillRadius(20f, 0f, 0.7f) - 2)!!      // = 14
        var maxRed = 0
        for (i in out.indices) if (f.hole[i]) maxRed = max(maxRed, red(out[i]))
        assertTrue("đỏ rò vào chỗ lấp: $maxRed", maxRed <= 56)
    }

    @Test fun renderPlacesTheStaticSubjectWhereTheCropWindowSays() {
        for ((sx, sy) in listOf(Pair(16f, 10f), Pair(-16f, -10f), Pair(-12f, 14f), Pair(12f, -14f))) checkRenderPlacement(sx, sy)
    }

    private fun checkRenderPlacement(sx: Float, sy: Float) {
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val win = Reframe.cropWindow(fl.d, 0.9f, sx, sy, fl.w, fl.h)
        val z = win[4]
        val r = Reframe.render(fl.px, fl.w, fl.h, dep, sx, sy)!!
        val tag = "sx=$sx sy=$sy"
        assertEquals(tag, z, r.zoom, 1e-6f)
        var cover = 0.0; var cxs = 0.0; var cys = 0.0
        for (y in 0 until fl.h) for (x in 0 until fl.w) {
            val c = ((160 - grn(r.px[y * fl.w + x])) / 130.0).coerceIn(0.0, 1.0)
            cover += c; cxs += c * (x + 0.5); cys += c * (y + 0.5)
        }
        // chủ thể đứng yên: hình chữ nhật nguồn [70,130) × [10,50) → trong khung đầu ra (tọa độ − gốc cửa sổ) × zoom
        assertEquals("$tag diện tích", 60.0 * 40.0 * z * z, cover, 60.0 * 40.0 * z * z * 0.01)
        assertEquals("$tag tâm x", (100.0 - win[0]) * z, cxs / cover, 0.15)
        assertEquals("$tag tâm y", (30.0 - win[1]) * z, cys / cover, 0.15)
        // tỉ lệ chỗ lộ ra trong khung cuối = số điểm trống nguồn nằm trong cửa sổ × zoom² / tổng
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, sx, sy)
        var holesInWindow = 0
        for (y in 0 until fl.h) for (x in 0 until fl.w) {
            if (f.hole[y * fl.w + x] && x + 0.5f >= win[0] && x + 0.5f < win[2] && y + 0.5f >= win[1] && y + 0.5f < win[3]) holesInWindow++
        }
        assertTrue("$tag có chỗ lộ để đo: $holesInWindow", holesInWindow > 100)
        val expected = holesInWindow.toDouble() * z * z / (fl.w * fl.h)
        assertEquals("$tag holeFrac", expected, r.holeFrac.toDouble(), expected * 0.06)
    }

    @Test fun fillOfAWideSubjectsExposedStripNeverTakesTheSubjectColour() {
        // chủ thể rộng 400 (≫ 2·radius): dải lộ ra phía trên rộng 400 nên giữa dải không có điểm nền "biết" nào trong cửa sổ — trước đây điểm chủ thể sát mép
        // lọt vào nguồn và màu đỏ "kéo" lên trên; giờ nền được đo trên độ sâu nguồn nên mọi điểm chủ thể đều bị loại
        val fl = flat(500, 120, 50, 450, 10, 100, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 0f, 14f)       // nền (e = −0,7) lên 9,8 điểm: lộ dải 9–10 hàng ngay trên chủ thể, sát mép trên ảnh
        var holes = 0
        for (v in f.hole) if (v) holes++
        assertTrue("phải có chỗ lộ rộng: $holes", holes > 3000)
        val out = Reframe.fill(f, fl.w, fl.h, Reframe.fillRadius(0f, 14f, 0.7f))!!
        var maxRed = 0
        for (i in out.indices) if (f.hole[i]) maxRed = max(maxRed, red(out[i]))
        assertTrue("đỏ rò vào chỗ lấp: $maxRed", maxRed <= 52)
    }

    @Test fun fillIgnoresSubjectPixelsNextToAnOutOfImageBand() {
        // dải trống ngoài ảnh (nguồn nằm ngoài khung) ngay dưới chủ thể rộng: điểm chủ thể sát dải không được thành nguồn — dải 'ngoài ảnh' vốn bị cắt khi phóng
        val fl = flat(300, 60, 40, 260, 10, 50, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 0f, 14f)
        val out = Reframe.fill(f, fl.w, fl.h, Reframe.fillRadius(0f, 14f, 0.7f))!!
        var maxRed = 0
        for (i in out.indices) if (f.hole[i]) maxRed = max(maxRed, red(out[i]))
        assertTrue("đỏ rò vào chỗ lấp: $maxRed", maxRed <= 52)
    }

    @Test fun depthOfNonSkyTextureAboveTheHorizonIsFarAndNeverNegative() {
        // tòa nhà (không phải trời) giữa vùng trời phía trên chân trời: độ sâu = 0 như trời (xa), tuyệt đối không âm
        val s = scene(withSubject = false)
        for (y in 10 until 40) for (x in 20 until 60) s.sky[y * s.w + x] = 0f
        val d = depthOf(s, subject = false)
        assertTrue(d.hasSky)
        var mn = 1f
        for (v in d.d) mn = min(mn, v)
        assertTrue("độ sâu âm: $mn", mn > -1e-4f)
        assertEquals(0f, d.d[25 * s.w + 40], 1e-3f)
    }

    @Test fun fillCracksTreatsHolesAtTheImageBorderAsNotCracks() {
        // cột trái và hàng trên trống (dải ngoài ảnh): không có bên kia để nội suy ⇒ giữ nguyên, và không đọc ra ngoài mảng
        val w = 6; val h = 4
        val dd = FloatArray(w * h) { if (it % w == 0 || it / w == 0) -1f else 0.5f }
        Reframe.fillCracks(dd, w, h)
        for (i in dd.indices) assertEquals("i=$i", if (i % w == 0 || i / w == 0) -1f else 0.5f, dd[i], 0f)
    }

    @Test fun fillBandRadiusHasMinimumTwoAndOnlyNearBackgroundDrivesTheFill() {
        // chỗ lộ RỘNG (42 điểm) để chỗ lấp dùng cả các mức thô — lúc đó dải nguồn mới có ý nghĩa; ảnh đủ rộng để dải trống ngoài ảnh (mép phải) ở rất xa
        val fl = flat(400, 60, 150, 250, 10, 50, 0.2f, 0.9f, noisyBg = true)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 60f, 0f)
        val r = Reframe.fillRadius(60f, 0f, 0.7f)
        assertEquals(44, r)
        // bán kính nhỏ nhất là 2: 0, 1, 2 như nhau nhưng KHÁC 20 (dải hẹp hơn thì nguồn khác đi trên nền nhiễu)
        val r2 = Reframe.fill(f, fl.w, fl.h, 2)!!
        assertTrue(r2.contentEquals(Reframe.fill(f, fl.w, fl.h, 1)!!))
        assertFalse("bán kính 2 và 20 phải cho kết quả khác nhau", r2.contentEquals(Reframe.fill(f, fl.w, fl.h, 20)!!))
        // nền dịch trái 42 ⇒ chỗ lộ nằm bên TRÁI chủ thể: [hl, hr) = [108, 150); dải quanh lỗ = r điểm (Chebyshev) tính từ điểm lỗ đầu hl
        var hl = 0
        while (!f.hole[30 * fl.w + hl]) hl++
        var hr = hl
        while (f.hole[30 * fl.w + hr]) hr++
        assertEquals(108, hl)
        assertEquals(150, hr)
        val base = Reframe.fill(f, fl.w, fl.h, r)!!
        /** Sơn trắng các cột nền [x0, x1] (mọi hàng) rồi đếm điểm chỗ lộ chính ([hl, hr)) đổi màu so với [base]. */
        fun diffCount(x0: Int, x1: Int): Int {
            val col = f.color.copyOf()
            for (y in 0 until fl.h) for (x in x0..x1) if (!f.hole[y * fl.w + x]) col[y * fl.w + x] = rgb(255, 255, 255)
            val out = Reframe.fill(Reframe.Frame(col, f.hole, f.dd, f.srcDepth), fl.w, fl.h, r)!!
            var c = 0
            for (y in 0 until fl.h) for (x in hl until hr) if (out[y * fl.w + x] != base[y * fl.w + x]) c++
            return c
        }
        // nền sát chỗ lộ (cách mép 9..18) là nguồn thật ⇒ sơn trắng làm đổi chỗ lấp; nền ngoài dải (cách mép r+1..2r) không được ảnh hưởng.
        // (Đo thử: push-pull theo cấu trúc ô nên nền cách mép > ~18 điểm hầu như không đổi kết quả ở hình học này — bài này không phân biệt được dải r với r/2 hay 2r, xem A150.)
        assertTrue("cột nền sát chỗ lộ phải ảnh hưởng chỗ lấp", diffCount(hl - 18, hl - 9) > 0)
        assertEquals("cột nền ngoài dải không được ảnh hưởng chỗ lấp", 0, diffCount(hl - 2 * r, hl - r - 1))
    }

    @Test fun renderSizesTheFillBandByTheDepthRangeNotByTheNearestDepth() {
        // render phải lấp với bán kính theo dải độ sâu (cao − thấp), lấp trên nền nhiễu, rồi lấy mẫu theo cửa sổ phóng — dựng lại từng bước và so từng điểm
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f, noisyBg = true)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val sx = 20f; val sy = 0f
        val r = Reframe.render(fl.px, fl.w, fl.h, dep, sx, sy)!!
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, sx, sy)
        val filled = Reframe.fill(f, fl.w, fl.h, Reframe.fillRadius(sx, sy, 0.9f - 0.2f))!!
        val win = Reframe.cropWindow(fl.d, 0.9f, sx, sy, fl.w, fl.h)
        val z = win[4]
        assertTrue(z > 1.0005f)
        assertEquals(z, r.zoom, 0f)
        for (y in 0 until fl.h) for (x in 0 until fl.w) {
            val e = Reframe.sample(filled, fl.w, fl.h, win[0] + (x + 0.5f) / z, win[1] + (y + 0.5f) / z)
            assertEquals("x=$x y=$y", e, r.px[y * fl.w + x])
        }
    }

    @Test fun fillFallsBackToDestinationDepthWhenSourceDepthIsAbsent() {
        // Frame dựng tay không có độ sâu nguồn: cách cũ (đo trên độ sâu đích) vẫn chạy và vẫn loại vật che có nền ngay bên cạnh
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val w0 = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 20f, 0f)
        assertNotNull(w0.srcDepth)
        val bare = Reframe.Frame(w0.color, w0.hole, w0.dd)
        assertNull(bare.srcDepth)
        val out = Reframe.fill(bare, fl.w, fl.h, Reframe.fillRadius(20f, 0f, 0.7f))!!
        var maxRed = 0
        for (i in out.indices) if (bare.hole[i]) maxRed = max(maxRed, red(out[i]))
        assertTrue("đỏ rò vào chỗ lấp: $maxRed", maxRed <= 56)
    }

    @Test fun renderWithNegligibleCropKeepsZoomOneAndCountsHolesOnTheFrame() {
        // ảnh rất rộng + dịch nhỏ: cửa sổ phóng < 0,05 % ⇒ coi như không phóng (zoom đúng 1), holeFrac = chỗ trống / toàn khung
        val fl = flat(4000, 2, 2000, 3000, 0, 2, 0.2f, 0.9f)
        val dep = Reframe.Depth(fl.d, 0.9f, true, false, 0f)
        val r = Reframe.render(fl.px, fl.w, fl.h, dep, 2f, 0f)!!
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 2f, 0f)
        var holes = 0
        for (v in f.hole) if (v) holes++
        assertTrue("có chỗ lộ: $holes", holes in 1..40)
        assertEquals(1f, r.zoom, 0f)
        assertEquals(holes.toFloat() / (fl.w * fl.h), r.holeFrac, 1e-9f)
    }

    @Test fun sampleBilinearIsExactRoundedAndClamped() {
        val w = 2; val h = 2
        val px = intArrayOf(rgb(100, 10, 0), rgb(200, 11, 255), rgb(60, 10, 0), rgb(0, 11, 255))
        // tâm mẫu (1,1) = giữa bốn điểm
        assertEquals(rgb(90, 11, 128), Reframe.sample(px, w, h, 1f, 1f))      // 90; 10,5 → 11; 127,5 → 128
        // tx = 0,25, ty = 0,5
        assertEquals(rgb(85, 10, 64), Reframe.sample(px, w, h, 0.75f, 1f))    // R: (125 + 45) / 2 = 85; G: 10,25 → 10; B: 63,75 → 64
        // đúng tâm một điểm: trả đúng điểm đó
        assertEquals(px[0], Reframe.sample(px, w, h, 0.5f, 0.5f))
        assertEquals(px[3], Reframe.sample(px, w, h, 1.5f, 1.5f))
        // kẹp biên
        assertEquals(px[0], Reframe.sample(px, w, h, -9f, -9f))
        assertEquals(px[3], Reframe.sample(px, w, h, 9f, 9f))
        assertEquals(0xFF, Reframe.sample(px, w, h, 1f, 1f) ushr 24)
    }

    @Test fun backgroundDepthIsSmoothOnTexturedGroundAndSharpAtStrongEdges() {
        // đất có nhiễu độc lập từng điểm: độ sâu chỉ được đổi theo vị trí (độ chói chuẩn hóa 0..1 + eps 4e-3 không cho nhiễu lọt vào độ sâu)
        val s = scene(withSubject = false)
        val d = depthOf(s, subject = false)
        var maxDx = 0f
        for (y in 60 until 110) for (x in 5 until s.w - 5) maxDx = max(maxDx, abs(d.d[y * s.w + x + 1] - d.d[y * s.w + x]))
        assertTrue("nhiễu ảnh lọt vào độ sâu: $maxDx", maxDx < 0.002f)
        // cạnh khoảng trời mạnh: nhảy từ đất (≈ 0,39) xuống trời (≈ 0) trong ≤ 2–3 điểm ảnh
        val t = scene(withSubject = false)
        for (y in 80 until 100) for (x in 100 until 130) { t.sky[y * t.w + x] = 1f; t.px[y * t.w + x] = rgb(120, 190, 255) }
        val e = depthOf(t, subject = false)
        val row = 90 * t.w
        for (x in 96..98) assertTrue("đất sát cạnh x=$x: ${e.d[row + x]}", e.d[row + x] in 0.33f..0.45f)
        for (x in 101..103) assertTrue("trời sát cạnh x=$x: ${e.d[row + x]}", e.d[row + x] < 0.07f)
    }

    @Test fun warpDoesNotBlendSubjectColourIntoBackgroundAcrossDepthEdge() {
        // nền dịch −11,2 điểm (lẻ) ⇒ điểm nền sát chỗ lộ ra lấy mẫu ở tọa độ lẻ, kề cạnh chủ thể: không được trộn màu đỏ
        val fl = flat(200, 60, 70, 130, 10, 50, 0.2f, 0.9f)
        val f = Reframe.warp(fl.px, fl.w, fl.h, fl.d, 0.9f, 16f, 10f)
        var checkedBg = 0; var checkedFg = 0
        for (i in f.color.indices) {
            if (f.hole[i]) continue
            if (abs(f.dd[i] - 0.2f) < 1e-6f) { checkedBg++; assertEquals("nền tại $i", rgb(50, 160, 50), f.color[i]) }
            if (abs(f.dd[i] - 0.9f) < 1e-6f) { checkedFg++; assertEquals("chủ thể tại $i", rgb(220, 30, 30), f.color[i]) }
        }
        assertTrue(checkedBg > 5000 && checkedFg == 60 * 40)
    }

    @Test fun sampleDepthBlendsOnlyTapsOfSimilarDepth() {
        val w = 2; val h = 2
        val px = intArrayOf(rgb(100, 100, 100), rgb(200, 200, 200), rgb(60, 60, 60), rgb(0, 0, 0))
        val d = floatArrayOf(0.5f, 0.5f, 0.5f, 0.5f)
        // tâm mẫu (1,1) = giữa bốn điểm; tx = ty = 0,5 → trung bình đều (100 + 200 + 60 + 0) / 4 = 90
        assertEquals(rgb(90, 90, 90), Reframe.sampleDepth(px, d, w, h, 1f, 1f, 0.5f))
        // tx = 0,25, ty = 0,5: trọng số 0,375 / 0,125 / 0,375 / 0,125; bỏ điểm (1,0) ⇒ (100·0,375 + 60·0,375 + 0·0,125) / 0,875 = 68,57 → 69
        val d2 = floatArrayOf(0.5f, 0.9f, 0.5f, 0.5f)
        assertEquals(rgb(69, 69, 69), Reframe.sampleDepth(px, d2, w, h, 0.75f, 1f, 0.5f))
        // dung sai: chênh đúng dưới OCCLUDER_TOL vẫn trộn; trên thì loại
        val d3 = floatArrayOf(0.5f, 0.5f + Reframe.OCCLUDER_TOL * 0.9f, 0.5f, 0.5f)
        assertEquals(rgb(90, 90, 90), Reframe.sampleDepth(px, d3, w, h, 1f, 1f, 0.5f))
        val d4 = floatArrayOf(0.5f, 0.5f + Reframe.OCCLUDER_TOL * 1.1f, 0.5f, 0.5f)
        assertEquals(rgb(53, 53, 53), Reframe.sampleDepth(px, d4, w, h, 1f, 1f, 0.5f))     // (100 + 60 + 0) / 3 = 53,3 → 53
        // không điểm nào gần độ sâu đích: lấy đúng điểm gần nhất, không trộn
        val d5 = floatArrayOf(0.1f, 0.95f, 0.4f, 0.9f)
        assertEquals(rgb(60, 60, 60), Reframe.sampleDepth(px, d5, w, h, 1f, 1f, 0.5f))
        // loại riêng từng điểm (tâm mẫu tx = ty = 0,5: bốn trọng số 0,25) — còn ba điểm trộn đều
        val ex = intArrayOf(rgb(87, 87, 87), rgb(53, 53, 53), rgb(100, 100, 100), rgb(120, 120, 120))   // (200+60+0)/3, (100+60+0)/3, (100+200+0)/3, (100+200+60)/3
        for (k in 0..3) {
            val dk = FloatArray(4) { 0.5f }
            dk[k] = 0.9f
            assertEquals("bỏ điểm $k", ex[k], Reframe.sampleDepth(px, dk, w, h, 1f, 1f, 0.5f))
        }
        // không điểm nào đủ gần: lấy đúng điểm có độ sâu gần nhất, ở từng vị trí
        for (best in 0..3) {
            val dk = FloatArray(4) { 0.95f }
            dk[best] = 0.7f
            assertEquals("gần nhất $best", px[best], Reframe.sampleDepth(px, dk, w, h, 1f, 1f, 0.5f))
        }
        // biên: kẹp tọa độ và giữ alpha
        assertEquals(rgb(100, 100, 100), Reframe.sampleDepth(px, d, w, h, -5f, -5f, 0.5f))
        assertEquals(rgb(0, 0, 0), Reframe.sampleDepth(px, d, w, h, 9f, 9f, 0.5f))
    }

    @Test fun renderRejectsDepthOfWrongSize() {
        val w = 10; val h = 10
        val px = IntArray(w * h)
        var thrown = false
        try { Reframe.render(px, w, h, Reframe.Depth(FloatArray(5), 0.5f, false, false, 0f), 5f, 0f) } catch (e: IllegalArgumentException) { thrown = true }
        assertTrue(thrown)
        thrown = false
        try { Reframe.render(IntArray(7), w, h, Reframe.Depth(FloatArray(w * h) { it / 100f }, 0.5f, false, false, 0f), 5f, 0f) } catch (e: IllegalArgumentException) { thrown = true }
        assertTrue(thrown)
    }

    @Test fun cropWindowVerticalLayersCutTopAndBottom() {
        val w = 60; val h = 100
        val d = FloatArray(w * h) { if (it / w < 50) 0.2f else 0.9f }                      // dịch dọc −6 (xa) và +8 (gần)
        val win = Reframe.cropWindow(d, 0.5f, 0f, 20f, w, h)
        assertEquals(8f, win[1], 1e-3f)
        assertEquals(h - 6f, win[3], 1e-3f)
        assertEquals(h / (h - 14f), win[4], 1e-4f)
        assertEquals("giữa theo chiều ngang", (w - w / win[4]) / 2f, win[0], 1e-3f)
    }

    @Test fun sampleRoundsInterpolatedChannelsToNearest() {
        val w = 20; val h = 3
        // cột lẻ 11, cột chẵn 10; dịch đúng 2,5 điểm ảnh ⇒ mỗi điểm trộn 50/50 hai cột kề = 10,5 → làm tròn thành 11
        val px = IntArray(w * h) { val v = 10 + (it % w) % 2; rgb(v, v, v) }
        val f = Reframe.warp(px, w, h, FloatArray(w * h) { 1f }, 0.5f, 5f, 0f)          // e = 0,5 → 2,5 điểm ảnh
        for (x in 4 until w) assertEquals("x=$x", 11, red(f.color[w + x]))
    }

    @Test fun backgroundDepthKeepsStrongLumaEdgesButSmoothsFaintOnes() {
        // khoảng trời dưới chân trời: cạnh độ sâu nền bám cạnh ảnh khi tương phản đủ mạnh, nhòe ra khi quá mờ (eps của lọc dẫn hướng, độ chói chuẩn hóa 0..1)
        fun step(skyColor: Int): Float {
            val s = scene(withSubject = false)
            for (y in 80 until 100) for (x in 100 until 130) { s.sky[y * s.w + x] = 1f; s.px[y * s.w + x] = skyColor }
            val d = depthOf(s, subject = false)
            val row = 90 * s.w
            return d.d[row + 98] - d.d[row + 101]            // ngay ngoài (đất) trừ ngay trong (trời) mép trái khoảng trời
        }
        val strong = step(rgb(120, 190, 255))
        val faint = step(rgb(60, 140, 60))                    // gần đúng độ chói của đất (≈ 0,40)
        assertTrue("mạnh: $strong", strong > 0.15f)
        assertTrue("mờ: $faint", faint < strong * 0.7f)
    }

    // ------------------------------------------------------------------ mô tả
    @Test fun describeMentionsWhatWasDone() {
        val dep = Reframe.Depth(FloatArray(4), 0.9f, true, true, 0.4f)
        val r = Reframe.Result(IntArray(4), 1.03f, 0.012f)
        val t = Reframe.describe(0.5f, -0.25f, 1.5f, r, dep)
        assertTrue(t, t.startsWith("Reframe 2.5D: xoay ngang 50%, dọc -25%, độ sâu 150%"))
        assertTrue(t, t.contains("xoay quanh chủ thể"))
        assertTrue(t, t.contains("có trời ở xa"))
        assertTrue(t, Regex("phóng 1[.,]03× để che viền").containsMatchIn(t))
        assertTrue(t, Regex("lấp 1[.,]2% chỗ lộ ra").containsMatchIn(t))
        assertTrue(t.endsWith("."))
    }

    @Test fun describeOmitsAbsentParts() {
        val dep = Reframe.Depth(FloatArray(4), 0.4f, false, false, 0f)
        val t = Reframe.describe(0.1f, 0.2f, 1f, Reframe.Result(IntArray(4), 1f, 0.0001f), dep)
        assertTrue(t, t.contains("không thấy chủ thể"))
        assertFalse(t, t.contains("có trời ở xa"))
        assertFalse(t, t.contains("lấp"))
    }
}
