package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.Outpaint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** R20: các luật bộ hiểu prompt offline mới (mở rộng ảnh, ...) và sửa lỗi nhầm "mở rộng" với "mờ". */
class R20PlannerTest {

    private fun ops(prompt: String): List<EditOp> = RuleBasedPlanner.plan(prompt).ops
    private fun outpaintArg(prompt: String): String? = ops(prompt).firstOrNull { it.type == OpType.OUTPAINT }?.arg

    // ---------------------------------------------------------------- mở rộng ảnh
    @Test fun extendIsNeverMistakenForBlur() {
        for (p in listOf("mở rộng ảnh", "Mở rộng ảnh sang trái 30%", "mở rộng khung hình", "extend the image", "mo rong anh", "kéo dài nền lên trên")) {
            val o = ops(p)
            assertTrue("\"$p\" phải ra OUTPAINT: $o", o.any { it.type == OpType.OUTPAINT })
            assertFalse("\"$p\" KHÔNG được ra BLUR/BG_BLUR: $o", o.any { it.type == OpType.BLUR || it.type == OpType.BG_BLUR })
        }
    }

    @Test fun realBlurRequestsStillWork() {
        assertTrue(ops("làm mờ ảnh").any { it.type == OpType.BLUR })
        assertTrue(ops("mờ phông").any { it.type == OpType.BG_BLUR })
        assertTrue(ops("làm mờ nền").any { it.type == OpType.BG_BLUR })
        assertTrue(ops("blur the photo").any { it.type == OpType.BLUR })
        assertTrue(ops("làm ảnh bớt mờ").any { it.type == OpType.SHARPEN })
    }

    @Test fun sidesAndAmounts() {
        assertEquals("l=0.200,r=0.200,t=0.200,b=0.200", Outpaint.canonical(outpaintArg("mở rộng ảnh")))              // không nêu hướng → mọi phía
        assertEquals("l=0.300,r=0.000,t=0.000,b=0.000", Outpaint.canonical(outpaintArg("mở rộng ảnh sang trái 30%")))
        assertEquals("l=0.000,r=0.200,t=0.000,b=0.000", Outpaint.canonical(outpaintArg("mở rộng ảnh sang phải")))
        assertEquals("l=0.000,r=0.000,t=0.200,b=0.000", Outpaint.canonical(outpaintArg("kéo dài nền lên trên")))
        assertEquals("l=0.000,r=0.000,t=0.000,b=0.250", Outpaint.canonical(outpaintArg("mở rộng ảnh xuống dưới 25%")))
        assertEquals("l=0.200,r=0.200,t=0.000,b=0.000", Outpaint.canonical(outpaintArg("mở rộng ảnh hai bên")))
        assertEquals("l=0.200,r=0.200,t=0.000,b=0.000", Outpaint.canonical(outpaintArg("mở rộng ảnh sang trái và phải")))   // "và" không tách mệnh đề
        assertEquals("l=0.200,r=0.200,t=0.000,b=0.000", Outpaint.canonical(outpaintArg("extend the image on the left and right")))
        assertEquals("l=0.000,r=0.000,t=0.150,b=0.150", Outpaint.canonical(outpaintArg("mở rộng ảnh trên và dưới 15%")))
        assertEquals("l=0.100,r=0.100,t=0.100,b=0.100", Outpaint.canonical(outpaintArg("mở rộng ảnh xung quanh 10%")))
        assertEquals("l=0.000,r=0.000,t=0.000,b=0.320", Outpaint.canonical(outpaintArg("mở rộng ảnh xuống dưới thật nhiều")))   // "nhiều" = mạnh ×1,6
    }

    @Test fun ratioTargets() {
        assertEquals("ratio=1.7778,a=c", Outpaint.canonical(outpaintArg("mở rộng ảnh thành 16:9")))
        assertEquals("ratio=1.0000,a=c", Outpaint.canonical(outpaintArg("mở rộng ảnh thành khung vuông")))
        assertEquals("ratio=1.7778,a=r", Outpaint.canonical(outpaintArg("mở rộng ảnh sang phải thành 16:9")))
        assertEquals("ratio=0.5625,a=c", Outpaint.canonical(outpaintArg("extend to 9:16")))
        // không để luật cắt tỉ lệ "ăn" yêu cầu mở rộng: không được ra CROP_RATIO
        assertTrue(ops("mở rộng ảnh thành 16:9").none { it.type == OpType.CROP_RATIO })
        assertTrue(ops("cắt 16:9").any { it.type == OpType.CROP_RATIO })
    }

    @Test fun extendCombinesWithOtherEditsAcrossClauses() {
        val o = ops("tăng sáng và mở rộng ảnh sang phải 20%")
        assertTrue(o.any { it.type == OpType.BRIGHTNESS && it.value > 0 })
        assertEquals("l=0.000,r=0.200,t=0.000,b=0.000", Outpaint.canonical(o.first { it.type == OpType.OUTPAINT }.arg))
    }

    @Test fun extendFrameIsNotAGenerativeIntent() {
        for (p in listOf("mở rộng ảnh", "mở rộng ảnh sang trái", "extend the image", "outpaint 20%")) assertNull("\"$p\"", GenIntent.detect(p, false))
        // nhưng xóa/thêm vật thể vẫn đúng ý định
        assertNotNull(GenIntent.detect("xóa người bên trái", false))
        assertNotNull(GenIntent.detect("thêm một con chim", false))
    }

    @Test fun describeIsReadable() {
        assertEquals("Mở rộng ảnh: trái 30%", EditOp(OpType.OUTPAINT, 1f, "l=0.3").sanitized()!!.describe())
        assertEquals("Mở rộng ảnh: tỉ lệ 1.78 (về phía phải)", EditOp(OpType.OUTPAINT, 1f, "ratio=1.7778,a=r").sanitized()!!.describe())
        assertNull(EditOp(OpType.OUTPAINT, 1f, "xin chào").sanitized())
        assertNull(EditOp(OpType.OUTPAINT, 1f, null).sanitized())
    }

    // ---------------------------------------------------------------- câu mơ hồ (PDF: "trông chuyên nghiệp hơn, da đẹp tự nhiên, màu ấm áp")
    private fun has(o: List<EditOp>, t: OpType) = o.any { it.type == t }
    private fun value(o: List<EditOp>, t: OpType) = o.first { it.type == t }.value

    @Test fun pdfExampleSentenceBecomesAFullPlan() {
        val o = ops("Làm cho bức ảnh này trông chuyên nghiệp hơn, da đẹp tự nhiên, màu ấm áp")
        for (t in listOf(OpType.AUTO_ENHANCE, OpType.CONTRAST, OpType.VIBRANCE, OpType.SHARPEN, OpType.FREQ_SEP, OpType.SKIN_SMOOTH, OpType.WARMTH)) {
            assertTrue("thiếu $t trong ${o.map { it.type }}", has(o, t))
        }
        assertTrue(value(o, OpType.WARMTH) > 0)
        assertFalse("\"màu ấm áp\" không có nghĩa là tăng bão hòa: $o", o.any { it.type == OpType.SATURATION && it.value > 0 })
        for (op in o) assertNotNull("${op.type} phải qua sanitized", op.sanitized())
    }

    @Test fun professionalLooksInBothLanguages() {
        for (p in listOf("trông chuyên nghiệp hơn", "make it look professional", "ảnh nhìn sang trọng hơn", "kiểu tạp chí", "magazine style", "cao cấp hơn", "studio quality")) {
            val o = ops(p)
            assertTrue("\"$p\" → AUTO_ENHANCE + VIBRANCE: ${o.map { it.type }}", has(o, OpType.AUTO_ENHANCE) && has(o, OpType.VIBRANCE))
        }
        // "sang trọng" (classy) khác "sáng trong" (bright, clear): câu về độ sáng vẫn là độ sáng
        val bright = ops("tăng sáng trong vùng tối")
        assertTrue(has(bright, OpType.SHADOWS)); assertFalse(has(bright, OpType.AUTO_ENHANCE)); assertFalse(has(bright, OpType.VIGNETTE))
    }

    @Test fun naturalSkinKeepsTextureSeparatedFromPlainSmoothing() {
        for (p in listOf("da đẹp tự nhiên", "da đẹp hơn", "da khỏe", "natural skin", "healthy skin")) {
            val o = ops(p)
            assertTrue("\"$p\" → tách tần số (giữ lỗ chân lông) + mịn nhẹ: ${o.map { it.type }}", has(o, OpType.FREQ_SEP) && has(o, OpType.SKIN_SMOOTH))
            assertTrue(value(o, OpType.SKIN_SMOOTH) < 0.4f)
        }
        // "da mịn" vẫn là làm mịn thường (không đổi hành vi cũ)
        val plain = ops("làm da mịn")
        assertTrue(has(plain, OpType.SKIN_SMOOTH)); assertFalse(has(plain, OpType.FREQ_SEP))
    }

    @Test fun englishAndVietnameseGenericImprovement() {
        for (p in listOf("make this photo look better", "improve the photo", "polish it", "ảnh đẹp lên", "xịn hơn", "cho đẹp")) {
            val o = ops(p)
            assertTrue("\"$p\": ${o.map { it.type }}", has(o, OpType.AUTO_ENHANCE))
        }
        // "làm đẹp" kiểu cũ (có làm mịn da) giữ nguyên
        assertTrue(has(ops("ảnh đẹp hơn"), OpType.SKIN_SMOOTH))
    }

    @Test fun popRequestsBoostContrastAndColor() {
        for (p in listOf("make it pop", "làm ảnh nổi bật", "ảnh bắt mắt hơn")) {
            val o = ops(p)
            assertTrue("\"$p\": ${o.map { it.type }}", has(o, OpType.CONTRAST) && has(o, OpType.VIBRANCE) && has(o, OpType.CLARITY))
        }
    }

    @Test fun intensityWordsScaleTheBundle() {
        val soft = value(ops("hơi chuyên nghiệp hơn"), OpType.AUTO_ENHANCE)
        val normal = value(ops("chuyên nghiệp hơn"), OpType.AUTO_ENHANCE)
        val strong = value(ops("rất chuyên nghiệp"), OpType.AUTO_ENHANCE)
        assertTrue("$soft < $normal < $strong", soft < normal && normal < strong)
    }

    @Test fun colorWordAloneStillMeansSaturationButToneWordsDoNot() {
        assertTrue(ops("tăng màu").any { it.type == OpType.SATURATION && it.value > 0 })
        assertTrue(ops("màu sắc rực rỡ hơn").any { it.type == OpType.SATURATION && it.value > 0 })
        val warm = ops("màu ấm áp")
        assertTrue(has(warm, OpType.WARMTH) && !has(warm, OpType.SATURATION))
        val cool = ops("màu lạnh")
        assertTrue(cool.any { it.type == OpType.WARMTH && it.value < 0 } && !has(cool, OpType.SATURATION))
    }

    @Test fun backgroundWordingWithTheDefiniteArticleStillCutsOut() {
        assertEquals("#FFFFFF", ops("change the background to white").first { it.type == OpType.BG_REMOVE }.arg)
        assertTrue(has(ops("replace the background with transparent"), OpType.BG_REMOVE))
    }
}
