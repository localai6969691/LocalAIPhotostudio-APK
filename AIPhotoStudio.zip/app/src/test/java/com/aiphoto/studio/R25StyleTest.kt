package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.WholeEditIntent
import com.aiphoto.studio.ai.mergeOps
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.Stylize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** R25 Phong cách: Kuwahara (đối chiếu bản vét cạn, giữ cạnh), sơn dầu / hoạt hình / màu nước, hòa theo cường độ, nhiễu giấy xác định. */
class R25StyleTest {

    private fun argb(r: Int, g: Int, b: Int, a: Int = 255) = (a shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    private fun luma(p: Int) = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000

    /** Ảnh hai nửa (trái tối, phải sáng) + nhiễu Gauss độ lệch [noise]. */
    private fun stepImage(w: Int, h: Int, lo: Int, hi: Int, noise: Double, seed: Long): IntArray {
        val rnd = java.util.Random(seed)
        return IntArray(w * h) {
            val base = if (it % w < w / 2) lo else hi
            val v = (base + rnd.nextGaussian() * noise).toInt()
            argb(v, v, v)
        }
    }

    private fun std(px: IntArray, w: Int, x0: Int, x1: Int, y0: Int, y1: Int): Double {
        var s = 0.0; var s2 = 0.0; var n = 0
        for (y in y0 until y1) for (x in x0 until x1) { val v = luma(px[y * w + x]).toDouble(); s += v; s2 += v * v; n++ }
        val m = s / n
        return sqrt(max(0.0, s2 / n - m * m))
    }

    // ------------------------------------------------------------------ Kuwahara
    /** Bản vét cạn của Kuwahara 4 góc (cùng quy ước: ô (r+1)×(r+1) chung đỉnh tại điểm, cắt theo biên, phương sai độ chói nguyên). */
    private fun bruteKuwahara(px: IntArray, w: Int, h: Int, r: Int): IntArray {
        val out = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            var bestVar = Double.MAX_VALUE
            var best = intArrayOf(0, 0, 0, 1)
            for (quad in 0 until 4) {
                val xa = if (quad and 1 == 0) max(0, x - r) else x
                val xb = if (quad and 1 == 0) x else min(w - 1, x + r)
                val ya = if (quad and 2 == 0) max(0, y - r) else y
                val yb = if (quad and 2 == 0) y else min(h - 1, y + r)
                var sr = 0L; var sg = 0L; var sb = 0L; var sl = 0L; var sq = 0L; var n = 0L
                for (yy in ya..yb) for (xx in xa..xb) {
                    val p = px[yy * w + xx]
                    val l = luma(p).toLong()
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; sl += l; sq += l * l; n++
                }
                val ml = sl.toDouble() / n
                val v = sq.toDouble() / n - ml * ml
                if (v < bestVar) { bestVar = v; best = intArrayOf(sr.toInt(), sg.toInt(), sb.toInt(), n.toInt()) }
            }
            val n = best[3]
            out[y * w + x] = (px[y * w + x] and (0xFF shl 24)) or (((best[0] + n / 2) / n) shl 16) or (((best[1] + n / 2) / n) shl 8) or ((best[2] + n / 2) / n)
        }
        return out
    }

    private fun randomImage(w: Int, h: Int, seed: Long): IntArray {
        val rnd = java.util.Random(seed)
        return IntArray(w * h) { argb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256), 128 + rnd.nextInt(128)) }
    }

    @Test fun kuwaharaMatchesBruteForceOnSmallImages() {
        for ((w, h, r) in listOf(Triple(23, 17, 1), Triple(31, 29, 3), Triple(9, 40, 4), Triple(5, 5, 6))) {
            val px = randomImage(w, h, (w * 31 + h).toLong())
            val got = Stylize.kuwahara(px, w, h, r)
            val want = bruteKuwahara(px, w, h, r)
            for (i in px.indices) assertEquals("${w}x$h r=$r tại $i", want[i], got[i])
        }
    }

    @Test fun kuwaharaBandBoundariesAreInvisible() {
        // 2000×900: dải hàng nội bộ ≈ 800 hàng → hai dải; mép dải phải khớp bản vét cạn từng điểm
        val w = 2000; val h = 900; val r = 3
        val px = randomImage(w, h, 5)
        val got = Stylize.kuwahara(px, w, h, r)
        val want = bruteKuwahara(px, w, h, r)
        var bad = 0
        for (i in px.indices) if (want[i] != got[i]) bad++
        assertEquals("điểm lệch giữa kuwahara theo dải và vét cạn", 0, bad)
    }

    @Test fun kuwaharaFlattensNoiseButKeepsTheEdge() {
        val w = 160; val h = 96
        val px = stepImage(w, h, 60, 200, 14.0, 3)
        val out = Stylize.kuwahara(px, w, h, 4)
        val before = std(px, w, 10, 50, 10, 86)
        val after = std(out, w, 10, 50, 10, 86)
        assertTrue("nhiễu vùng phẳng $before → $after (cần giảm ≥ 60%)", after < before * 0.4)
        // cạnh dọc tại x = 80 vẫn dựng đứng: hai bên cách cạnh 2 điểm ảnh đã ở đúng mức
        var worst = 0
        for (y in 6 until h - 6) {
            val l = luma(out[y * w + 77]); val rr = luma(out[y * w + 83])
            worst = max(worst, max(abs(l - 60), abs(rr - 200)))
        }
        assertTrue("cạnh bị nhòe: lệch tối đa $worst mức xám", worst <= 25)
    }

    @Test fun kuwaharaKeepsConstantImagesAndAlpha() {
        val w = 40; val h = 30
        val px = IntArray(w * h) { argb(90, 120, 200, 77) }
        val out = Stylize.kuwahara(px, w, h, 3)
        for (i in px.indices) assertEquals(px[i], out[i])
        val r = randomImage(w, h, 1)
        val o2 = Stylize.kuwahara(r, w, h, 2)
        for (i in r.indices) assertEquals("alpha", (r[i] ushr 24) and 255, (o2[i] ushr 24) and 255)
    }

    // ------------------------------------------------------------------ ba phong cách
    @Test fun oilSimplifiesTexture() {
        val w = 240; val h = 180
        val px = randomImage(w, h, 9).map { it or (0xFF shl 24) }.toIntArray()
        val out = Stylize.oil(px, w, h)
        assertTrue("độ lệch ${std(px, w, 0, w, 0, h)} → ${std(out, w, 0, w, 0, h)}", std(out, w, 0, w, 0, h) < std(px, w, 0, w, 0, h) * 0.6)
    }

    @Test fun cartoonQuantisesTonesAndDrawsOutlines() {
        val w = 300; val h = 200
        // dải chuyển sắc mượt + hình vuông sáng trên nền xám để có cạnh mạnh
        val px = IntArray(w * h) {
            val x = it % w; val y = it / w
            val g = (x * 255 / (w - 1))
            if (x in 120..180 && y in 60..140) argb(235, 235, 235) else argb(g, g, g)
        }
        val out = Stylize.cartoon(px, w, h)
        // vùng dải chuyển sắc thuần (hàng 10..40, x 10..110): phần lớn điểm phải nằm trên "bậc" 255/7·k (ảnh gốc chỉ ~16% tình cờ gần bậc)
        fun onPlateau(a: IntArray): Double {
            var hit = 0; var n = 0
            for (y in 10..40) for (x in 10..110) {
                val l = luma(a[y * w + x]) / (255f / 7f)
                if (abs(l - Math.round(l)) * (255f / 7f) <= 3f) hit++
                n++
            }
            return hit.toDouble() / n
        }
        assertTrue("tỉ lệ điểm trên bậc ${onPlateau(px)} → ${onPlateau(out)}", onPlateau(px) < 0.3 && onPlateau(out) > 0.6)
        // viền: điểm trên mép hình vuông tối hơn cả hai phía
        var darkest = 255
        for (x in 117..123) darkest = min(darkest, luma(out[100 * w + x]))
        val outside = luma(out[100 * w + 100]); val inside = luma(out[100 * w + 150])
        assertTrue("viền $darkest so với ngoài $outside / trong $inside", darkest < min(outside, inside) * 0.7)
    }

    @Test fun watercolorIsDeterministicLightAndPaperTextured() {
        val w = 200; val h = 150
        val flat = IntArray(w * h) { argb(120, 110, 100) }
        val a = Stylize.watercolor(flat, w, h)
        val b = Stylize.watercolor(flat, w, h)
        assertTrue("phải xác định", a.contentEquals(b))
        val meanIn = flat.map { luma(it) }.average()
        val meanOut = a.map { luma(it) }.average()
        assertTrue("màu nước phải sáng hơn nền: $meanIn → $meanOut", meanOut > meanIn + 8)
        val s = std(a, w, 0, w, 0, h)
        assertTrue("phải có vân giấy nhưng nhẹ: std=$s", s in 0.8..8.0)
        // vân giấy theo toạ độ chuẩn hóa: ảnh gấp đôi kích thước cho độ lệch cùng cỡ
        val big = Stylize.watercolor(IntArray(400 * 300) { argb(120, 110, 100) }, 400, 300)
        val sb = std(big, 400, 0, 400, 0, 300)
        assertTrue("độ lệch vân giấy $s vs $sb", sb > s / 1.8 && sb < s * 1.8)
    }

    @Test fun watercolorDarkensPigmentAtEdges() {
        val w = 200; val h = 120
        val px = stepImage(w, h, 70, 190, 0.0, 1)
        val out = Stylize.watercolor(px, w, h)
        val sideInside = luma(out[60 * w + 160])             // xa mép, nửa sáng
        var edgeMin = 255
        for (x in 96..104) edgeMin = min(edgeMin, luma(out[60 * w + x]))
        assertTrue("mép $edgeMin phải tối hơn vùng phẳng sáng $sideInside", edgeMin < sideInside - 15)
    }

    // ------------------------------------------------------------------ hòa / hợp lệ
    @Test fun applyBlendsWithTheOriginalAndIgnoresBadInput() {
        val w = 120; val h = 90
        val px = randomImage(w, h, 4)
        assertSame(px, Stylize.apply(px, w, h, 1f, null))
        assertSame(px, Stylize.apply(px, w, h, 1f, "anime"))
        assertSame(px, Stylize.apply(px, w, h, 0f, "oil"))
        val full = Stylize.apply(px, w, h, 1f, "oil")
        val half = Stylize.apply(px, w, h, 0.5f, "OIL")
        for (i in px.indices step 7) {
            assertEquals("alpha", (px[i] ushr 24) and 255, (half[i] ushr 24) and 255)
            for (sh in intArrayOf(16, 8, 0)) {
                val a = (px[i] shr sh) and 255; val f = (full[i] shr sh) and 255; val hh = (half[i] shr sh) and 255
                assertTrue("kênh $sh: gốc $a, đủ $f, nửa $hh", abs(hh - (a + f) / 2.0) <= 1.01)
            }
        }
        val bad = IntArray(10)
        assertSame("ảnh quá nhỏ / sai kích thước không ném lỗi", bad, Stylize.apply(bad, 3, 3, 1f, "oil"))
        assertSame(bad, Stylize.apply(bad, 5, 5, 1f, "oil"))
    }

    @Test fun namesAndNoise() {
        assertEquals("oil", Stylize.canonical(" Oil "))
        assertEquals("cartoon", Stylize.canonical("CARTOON"))
        assertEquals("watercolor", Stylize.canonical("watercolor"))
        assertNull(Stylize.canonical("anime"))
        assertNull(Stylize.canonical(null))
        assertEquals("hoạt hình", Stylize.label("cartoon"))
        for (i in 0 until 200) {
            val u = i * 0.37f; val v = i * 0.51f
            val n = Stylize.valueNoise(u, v, 5)
            assertTrue(n in 0f..1f)
            assertEquals(n, Stylize.valueNoise(u, v, 5), 0f)
            assertTrue("nhiễu phải trơn", abs(Stylize.valueNoise(u + 0.002f, v, 5) - n) < 0.02f)
        }
        assertTrue((0 until 50).any { Stylize.valueNoise(it * 0.9f, it * 0.4f, 1) != Stylize.valueNoise(it * 0.9f, it * 0.4f, 2) })
    }

    @Test fun radiusScalesWithLongSideAndIsClamped() {
        assertEquals(2, Stylize.radius(200, 100, 380f))
        assertEquals(5, Stylize.radius(2048, 1536, 380f))
        assertEquals(10, Stylize.radius(8000, 6000, 380f, 2, 10))
        assertTrue(Stylize.radius(4096, 3072, 380f) > Stylize.radius(1024, 768, 380f))
    }

    // ------------------------------------------------------------------ nối vào OpType / planner
    @Test fun styleOpIsRegisteredAndSanitised() {
        assertEquals(OpType.STYLE, OpType.fromKey("style"))
        assertTrue(OpType.STYLE.scalable)
        val ok = EditOp(OpType.STYLE, 1.8f, " Watercolor ").sanitized()!!
        assertEquals(1f, ok.value, 1e-6f)
        assertEquals("watercolor", ok.arg)
        assertNull("arg lạ", EditOp(OpType.STYLE, 0.5f, "anime").sanitized())
        assertNull("không arg", EditOp(OpType.STYLE, 0.5f, null).sanitized())
        assertNull("giá trị ~0", EditOp(OpType.STYLE, 0.001f, "oil").sanitized())
        assertEquals("Phong cách tranh: tranh sơn dầu 60%", EditOp(OpType.STYLE, 0.6f, "oil").describe())
        // hai phong cách khác nhau không cộng gộp: lấy phép sau cùng
        val merged = mergeOps(listOf(EditOp(OpType.STYLE, 0.5f, "oil"), EditOp(OpType.STYLE, 0.7f, "watercolor")))
        assertEquals(1, merged.size)
        assertEquals("watercolor", merged[0].arg)
        assertEquals(0.7f, merged[0].value, 1e-6f)
    }

    private fun styleOps(p: String) = RuleBasedPlanner.plan(p).ops.filter { it.type == OpType.STYLE }

    @Test fun plannerRoutesClassicStylesOnDeviceAndKeepsThemOutOfGenerative() {
        assertEquals("oil", styleOps("chuyển thành tranh sơn dầu").single().arg)
        assertEquals("oil", styleOps("make it an oil painting").single().arg)
        assertEquals("cartoon", styleOps("biến ảnh thành hoạt hình").single().arg)
        assertEquals("cartoon", styleOps("cartoon").single().arg)
        assertEquals("watercolor", styleOps("phong cách màu nước").single().arg)
        assertEquals("watercolor", styleOps("watercolor effect").single().arg)
        assertEquals(0.6f, styleOps("tranh sơn dầu 60%").single().value, 1e-4f)
        // các lệnh khác không bị nhận nhầm
        for (p in listOf("làm mờ ảnh", "làm sáng ảnh", "khử mờ", "phác họa bút chì", "pixel hóa", "anime")) assertTrue("\"$p\"", styleOps(p).isEmpty())
        // "biến thành / chuyển thành" không được rơi vào luồng thêm vật thể, và không phải AI toàn ảnh (miễn phí, chạy trên máy)
        for (p in listOf("biến ảnh thành tranh sơn dầu", "đổi thành hoạt hình", "chuyển thành màu nước", "turn it into an oil painting")) {
            assertNull("\"$p\" không phải GenIntent", GenIntent.detect(p, false))
            assertNull("\"$p\" không phải AI toàn ảnh", WholeEditIntent.detect(p))
        }
        // các kiểu AI vẫn đi đường AI, không bị planner cổ điển ăn
        assertTrue(WholeEditIntent.detect("biến ảnh thành anime") != null)
    }
}
