package com.aiphoto.studio

import com.aiphoto.studio.engine.ClassicInpaint
import com.aiphoto.studio.engine.DistanceField
import com.aiphoto.studio.engine.InpaintComplexity
import com.aiphoto.studio.engine.PatchMatchInpaint
import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.ProviderSpec
import com.aiphoto.studio.routing.Routing
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * R20: PatchMatch inpainting thật + đo độ khó vùng xóa + định tuyến theo độ khó.
 * Mọi bài kiểm chứng chất lượng so với ẢNH GỐC (ground truth) trên ảnh tổng hợp, không so với số tự bịa.
 */
class R20Test {

    private fun rgb(r: Int, g: Int, b: Int) = (255 shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun rect(w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int): ByteArray {
        val m = ByteArray(w * h)
        for (y in y0 until y1) for (x in x0 until x1) m[y * w + x] = 255.toByte()
        return m
    }

    /** PSNR (dB) trên các điểm của mặt nạ, 3 kênh. */
    private fun psnr(a: IntArray, b: IntArray, mask: ByteArray): Double {
        var se = 0.0
        var n = 0
        for (i in a.indices) if (mask[i].toInt() != 0) {
            for (s in intArrayOf(16, 8, 0)) {
                val d = ((a[i] shr s) and 255) - ((b[i] shr s) and 255)
                se += d * d
            }
            n += 3
        }
        val mse = se / n
        return if (mse < 1e-9) 99.0 else 10 * log10(255.0 * 255.0 / mse)
    }

    private fun stdOf(px: IntArray, mask: ByteArray): Double {
        var s = 0.0; var s2 = 0.0; var n = 0
        for (i in px.indices) if (mask[i].toInt() != 0) {
            val l = 0.299 * ((px[i] shr 16) and 255) + 0.587 * ((px[i] shr 8) and 255) + 0.114 * (px[i] and 255)
            s += l; s2 += l * l; n++
        }
        val m = s / n
        return sqrt(max0(s2 / n - m * m))
    }

    private fun max0(v: Double) = if (v < 0) 0.0 else v

    private fun classic(px: IntArray, w: Int, h: Int, mask: ByteArray): IntArray {
        // ClassicInpaint cần Bitmap (stub tối thiểu) → dùng đúng thuật toán lõi của nó trên mảng.
        val hole = BooleanArray(w * h) { mask[it].toInt() != 0 }
        // nới như ClassicInpaint (grow = 2) để so công bằng
        val d = DistanceField.chamfer(hole, w, h)
        val grown = BooleanArray(w * h) { d[it] <= 2f }
        return ClassicInpaint.pushPull(px, grown, w, h)
    }

    // ---------------------------------------------------------------- ảnh tổng hợp
    private fun periodic(w: Int, h: Int): IntArray = IntArray(w * h) { i ->
        val x = i % w; val y = i / w
        val a = sin(2 * PI * x / 12.0) * cos(2 * PI * y / 9.0)
        val b = sin(2 * PI * (x + 2 * y) / 17.0)
        rgb((128 + 70 * a + 20 * b).toInt(), (120 + 60 * a - 30 * b).toInt(), (110 - 50 * a + 40 * b).toInt())
    }

    private fun grain(w: Int, h: Int, seed: Long): IntArray {
        val rnd = Random(seed)
        val base = FloatArray(w * h) { rnd.nextFloat() * 255f }
        // làm mượt nhẹ → hạt có tương quan không gian (giống vân gỗ/cỏ)
        val sm = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var s = 0f
            for (dy in -1..1) for (dx in -1..1) s += base[(y + dy) * w + x + dx]
            sm[y * w + x] = s / 9f
        }
        return IntArray(w * h) { val v = sm[it].toInt() + 40; rgb(v, v - 10, v - 20) }
    }

    private fun diagonalEdge(w: Int, h: Int): IntArray = IntArray(w * h) { i ->
        val x = i % w; val y = i / w
        if (x + y < (w + h) / 2) rgb(200, 60, 40) else rgb(30, 90, 200)
    }

    // ================================================================ PatchMatch: chất lượng so với ground truth
    @Test fun periodicTextureIsRecoveredFarBetterThanPushPull() {
        val w = 160; val h = 120
        val truth = periodic(w, h)
        val mask = rect(w, h, 60, 40, 92, 72)
        val damaged = truth.copyOf().also { for (i in it.indices) if (mask[i].toInt() != 0) it[i] = rgb(255, 0, 255) }
        val t0 = System.nanoTime()
        val pm = PatchMatchInpaint().inpaintPixels(damaged, w, h, mask)
        val ms = (System.nanoTime() - t0) / 1_000_000
        val cl = classic(damaged, w, h, mask)
        val pPm = psnr(pm, truth, mask)
        val pCl = psnr(cl, truth, mask)
        println("R20 periodic: PatchMatch ${"%.1f".format(pPm)} dB (${ms} ms) vs push-pull ${"%.1f".format(pCl)} dB")
        assertTrue("PatchMatch phải phục hồi họa tiết tuần hoàn (PSNR=$pPm)", pPm > 24.0)
        assertTrue("PatchMatch phải hơn push-pull ≥ 8 dB ($pPm vs $pCl)", pPm > pCl + 8.0)
        // không còn màu "bẩn" đã dùng để đánh dấu vùng hỏng
        for (i in pm.indices) if (mask[i].toInt() != 0) assertTrue(pm[i] != rgb(255, 0, 255))
    }

    @Test fun grainKeepsTextureStatisticsWhilePushPullGoesFlat() {
        val w = 160; val h = 120
        val mask = rect(w, h, 55, 35, 95, 75)
        val ring = ByteArray(w * h)
        for (y in 20 until 90) for (x in 40 until 110) if (mask[y * w + x].toInt() == 0) ring[y * w + x] = 1
        val ratios = ArrayList<Double>()
        for (seed in 3L..8L) {                       // nhiều hạt giống khác nhau: không "tối ưu cho đúng một ảnh"
            val truth = grain(w, h, seed)
            val damaged = truth.copyOf().also { for (i in it.indices) if (mask[i].toInt() != 0) it[i] = 0 }
            val ctx = stdOf(truth, ring)
            val sPm = stdOf(PatchMatchInpaint().inpaintPixels(damaged, w, h, mask), mask)
            val sCl = stdOf(classic(damaged, w, h, mask), mask)
            println("R20 grain seed=$seed: std ngữ cảnh=${"%.1f".format(ctx)}  PatchMatch=${"%.1f".format(sPm)}  push-pull=${"%.1f".format(sCl)}")
            assertTrue("push-pull làm phẳng ($sCl vs $ctx)", sCl < 0.45 * ctx)
            assertTrue("mỗi ảnh PatchMatch giữ ≥ 45% độ nhám ($sPm vs $ctx)", sPm > 0.45 * ctx)
            assertTrue(sPm > 2 * sCl)
            ratios.add(sPm / ctx)
        }
        println("R20 grain: tỷ lệ độ nhám giữ lại trung bình = ${"%.2f".format(ratios.average())}")
        assertTrue("trung bình phải ≥ 55% (${ratios.average()})", ratios.average() > 0.55)
    }

    @Test fun diagonalEdgeIsContinuedAcrossTheHole() {
        val w = 160; val h = 120
        val truth = diagonalEdge(w, h)
        val mask = rect(w, h, 60, 40, 100, 80)       // đường biên (x+y=140) cắt qua tâm vùng xóa
        val damaged = truth.copyOf().also { for (i in it.indices) if (mask[i].toInt() != 0) it[i] = 0 }
        val pm = PatchMatchInpaint().inpaintPixels(damaged, w, h, mask)
        val cl = classic(damaged, w, h, mask)
        val pPm = psnr(pm, truth, mask)
        val pCl = psnr(cl, truth, mask)
        println("R20 edge: PatchMatch ${"%.1f".format(pPm)} dB vs push-pull ${"%.1f".format(pCl)} dB")
        assertTrue("biên phải được kéo dài (PSNR=$pPm)", pPm > 20.0)
        assertTrue(pPm > pCl + 3.0)
        // hai phía của biên vẫn đúng màu: kiểm tra 1 điểm rõ ràng mỗi phía
        val topLeft = pm[45 * w + 65]
        val bottomRight = pm[75 * w + 95]
        assertTrue("phía trên-trái phải là đỏ", ((topLeft shr 16) and 255) > 140)
        assertTrue("phía dưới-phải phải là xanh", (bottomRight and 255) > 140)
    }

    @Test fun pixelsOutsideTheGrownHoleAreUntouched() {
        val w = 120; val h = 90
        val truth = grain(w, h, 5)
        val mask = rect(w, h, 40, 30, 70, 60)
        val out = PatchMatchInpaint().inpaintPixels(truth, w, h, mask)
        val hole = BooleanArray(w * h) { mask[it].toInt() != 0 }
        val d = DistanceField.chamfer(hole, w, h)
        var checked = 0
        for (i in out.indices) if (d[i] > 3f) { assertEquals("điểm $i ngoài vùng nới phải giữ nguyên", truth[i], out[i]); checked++ }
        assertTrue(checked > w * h / 2)
        assertTrue("có thay đổi trong vùng trống", (0 until w * h).any { mask[it].toInt() != 0 && out[it] != truth[it] })
    }

    @Test fun deterministicAndEmptyMask() {
        val w = 100; val h = 80
        val img = grain(w, h, 9)
        val mask = rect(w, h, 30, 25, 55, 50)
        val a = PatchMatchInpaint().inpaintPixels(img, w, h, mask)
        val b = PatchMatchInpaint().inpaintPixels(img, w, h, mask)
        assertArrayEquals(a, b)
        assertSame(img, PatchMatchInpaint().inpaintPixels(img, w, h, ByteArray(w * h)))
    }

    @Test fun holeTouchingBorderAndCornerWorks() {
        val w = 120; val h = 90
        val truth = periodic(w, h)
        for (m in listOf(rect(w, h, 0, 0, 25, 25), rect(w, h, 95, 65, 120, 90), rect(w, h, 0, 30, 20, 55), rect(w, h, 40, 0, 70, 12))) {
            val damaged = truth.copyOf().also { for (i in it.indices) if (m[i].toInt() != 0) it[i] = rgb(0, 255, 0) }
            val out = PatchMatchInpaint().inpaintPixels(damaged, w, h, m)
            val p = psnr(out, truth, m)
            assertTrue("hole ở biên vẫn phải khôi phục tốt (PSNR=$p)", p > 18.0)
        }
    }

    @Test fun cheapFineLevelsStillBeatPushPullOnStructureAndKeepGrain() {
        // ép mọi mức tháp lớn vào chế độ rẻ (maxWorkHolePx nhỏ): chi tiết phải vẫn lấy từ ảnh thật ở độ phân giải đầy đủ.
        // Cảnh kiểm tra cấu trúc là biên chéo lớn (thông tin nằm ở tỷ lệ thô nên NNF phóng to chính xác); họa tiết tuần hoàn
        // mịn bị răng cưa ở tỷ lệ thô nên KHÔNG dùng PSNR cho nó (chép sai pha còn bị phạt nặng hơn mảng phẳng).
        val w = 360; val h = 260
        val truth = diagonalEdge(w, h)
        val mask = rect(w, h, 90, 60, 270, 200)       // ~25k điểm
        val damaged = truth.copyOf().also { for (i in it.indices) if (mask[i].toInt() != 0) it[i] = 0 }
        val t0 = System.nanoTime()
        val out = PatchMatchInpaint(maxWorkHolePx = 3_000).inpaintPixels(damaged, w, h, mask)
        val ms = (System.nanoTime() - t0) / 1_000_000
        val cl = classic(damaged, w, h, mask)
        val p = psnr(out, truth, mask)
        val pc = psnr(cl, truth, mask)
        val full = psnr(PatchMatchInpaint(maxWorkHolePx = 10_000_000).inpaintPixels(damaged, w, h, mask), truth, mask)
        println("R20 cheap levels (biên chéo): rẻ ${"%.1f".format(p)} dB (${ms} ms), đầy đủ ${"%.1f".format(full)} dB, push-pull ${"%.1f".format(pc)} dB")
        assertTrue("biên phải giữ được ở chế độ rẻ ($p vs $pc)", p > 17.0 && p > pc + 4.0)
        assertTrue("chế độ rẻ không được kém chế độ đầy đủ quá 3 dB ($p vs $full)", p > full - 3.0)
        assertEquals(w * h, out.size)

        val g = grain(w, h, 21)
        val gd = g.copyOf().also { for (i in it.indices) if (mask[i].toInt() != 0) it[i] = 0 }
        val ring = ByteArray(w * h)
        for (y in 30 until 230) for (x in 60 until 300) if (mask[y * w + x].toInt() == 0) ring[y * w + x] = 1
        val ctx = stdOf(g, ring)
        val sCheap = stdOf(PatchMatchInpaint(maxWorkHolePx = 3_000).inpaintPixels(gd, w, h, mask), mask)
        val sPush = stdOf(classic(gd, w, h, mask), mask)
        println("R20 cheap levels grain: ngữ cảnh=${"%.1f".format(ctx)} PatchMatch(rẻ)=${"%.1f".format(sCheap)} push-pull=${"%.1f".format(sPush)}")
        assertTrue("giữ ≥ 40% độ nhám ($sCheap vs $ctx)", sCheap > 0.4 * ctx)
        assertTrue(sCheap > 2 * sPush)
    }

    @Test fun everythingMaskedDoesNotCrash() {
        val w = 40; val h = 30
        val img = grain(w, h, 1)
        val out = PatchMatchInpaint().inpaintPixels(img, w, h, ByteArray(w * h) { 255.toByte() })
        assertEquals(w * h, out.size)
    }

    @Test fun speedIsReasonableForTypicalPhoneCrop() {
        val w = 480; val h = 360
        val img = grain(w, h, 11)
        val mask = rect(w, h, 170, 120, 270, 220)     // vùng trống 100×100
        val t0 = System.nanoTime()
        PatchMatchInpaint().inpaintPixels(img, w, h, mask)
        val ms = (System.nanoTime() - t0) / 1_000_000
        println("R20 speed: 480x360, hole 100x100 → $ms ms (JVM)")
        assertTrue("quá chậm: $ms ms", ms < 20_000)
    }

    @Test fun speedAtTheWorkingResolutionCeiling() {
        // trần chi phí: vùng trống ≈ maxWorkHolePx (36k điểm) trong khung 720 px; ảnh lớn hơn nữa bị thu nhỏ trước
        val w = 1200; val h = 900
        val img = grain(w, h, 12)
        val mask = rect(w, h, 500, 350, 690, 540)     // 190×190 = 36.1k
        val t0 = System.nanoTime()
        val out = PatchMatchInpaint().inpaintPixels(img, w, h, mask)
        val ms = (System.nanoTime() - t0) / 1_000_000
        println("R20 speed: 1200x900, hole 190x190 → $ms ms (JVM)")
        assertEquals(w * h, out.size)
        assertTrue("quá chậm: $ms ms", ms < 30_000)
        val huge = rect(w, h, 100, 100, 1100, 800)    // 700k điểm → buộc thu nhỏ, chi phí không tăng theo diện tích
        val t1 = System.nanoTime()
        PatchMatchInpaint().inpaintPixels(img, w, h, huge)
        val ms2 = (System.nanoTime() - t1) / 1_000_000
        println("R20 speed: hole 1000x700 (thu nhỏ tự động) → $ms2 ms (JVM)")
        assertTrue("vùng khổng lồ phải vẫn xong trong vài giây ($ms2 ms)", ms2 < 30_000)
    }

    // ================================================================ độ khó vùng xóa
    private fun diff(img: IntArray, w: Int, h: Int, m: ByteArray) = InpaintComplexity.analyze(img, w, h, m)

    private fun flat(w: Int, h: Int) = IntArray(w * h) { rgb(120, 140, 200) }
    private fun stripes(w: Int, h: Int) = IntArray(w * h) { val v = if (((it % w) / 3 + (it / w) / 4) % 2 == 0) 40 else 220; rgb(v, v, v) }

    @Test fun noMaskMeansZeroDifficulty() {
        assertEquals(0f, diff(flat(100, 80), 100, 80, ByteArray(8000)).difficulty, 0f)
    }

    @Test fun smallHoleOnFlatBackgroundIsEasy() {
        val w = 400; val h = 300
        val r = diff(flat(w, h), w, h, rect(w, h, 180, 130, 210, 160))
        println("R20 diff small/flat: ${r.describe()}")
        assertTrue(r.difficulty < 0.12f)
        assertTrue(r.structure < 0.1f)
    }

    @Test fun sameHoleOnBusyBackgroundIsHarder() {
        val w = 400; val h = 300
        val m = rect(w, h, 170, 120, 230, 180)
        val easy = diff(flat(w, h), w, h, m)
        val hard = diff(stripes(w, h), w, h, m)
        println("R20 diff 60px: flat=${"%.2f".format(easy.difficulty)} stripes=${"%.2f".format(hard.difficulty)}")
        assertTrue(hard.structure > 0.8f)
        assertTrue("nền nhiều chi tiết phải khó hơn rõ rệt", hard.difficulty > easy.difficulty + 0.08f)
    }

    @Test fun difficultyGrowsWithHoleSizeOnBusyBackground() {
        val w = 400; val h = 300
        val img = stripes(w, h)
        val sizes = listOf(10, 30, 60, 100, 160)
        val d = sizes.map { s -> diff(img, w, h, rect(w, h, 200 - s / 2, 150 - s / 2, 200 + s / 2, 150 + s / 2)).difficulty }
        println("R20 diff theo kích thước ${sizes}: ${d.map { "%.2f".format(it) }}")
        for (i in 1 until d.size) assertTrue("độ khó phải tăng theo kích thước: $d", d[i] > d[i - 1])
        assertTrue(d.first() < 0.15f)
        assertTrue(d.last() > 0.6f)
    }

    @Test fun hugeHoleOnFlatBackgroundStaysEasierThanOnBusyBackground() {
        val w = 400; val h = 300
        val m = rect(w, h, 100, 60, 300, 240)
        val flatD = diff(flat(w, h), w, h, m).difficulty
        val busyD = diff(stripes(w, h), w, h, m).difficulty
        println("R20 diff hole rất lớn: flat=${"%.2f".format(flatD)} busy=${"%.2f".format(busyD)}")
        assertTrue(flatD < 0.30f)           // vẫn thuộc diện PatchMatch/push-pull xử lý được (trời, tường)
        assertTrue(busyD > 0.6f)
    }

    @Test fun thinLongWireIsEasyEvenOnBusyBackground() {
        val w = 400; val h = 300
        val wire = rect(w, h, 0, 148, w, 152)        // dây 4 px kéo suốt chiều ngang
        val r = diff(stripes(w, h), w, h, wire)
        println("R20 diff dây mảnh: ${r.describe()}")
        assertTrue("độ dày mới quyết định, không phải chiều dài (${r.difficulty})", r.difficulty < 0.2f)
        val blob = rect(w, h, 150, 100, 250, 200)
        assertTrue(diff(stripes(w, h), w, h, blob).difficulty > r.difficulty + 0.3f)
    }

    @Test fun analysisIsScaleInvariantEnough() {
        // cùng cảnh ở hai độ phân giải: độ khó phải gần nhau (đo trên bản thu nhỏ có hệ số thích ứng)
        fun scene(w: Int, h: Int): Pair<IntArray, ByteArray> {
            val img = IntArray(w * h) { i -> val x = i % w; val y = i / w
                val v = if (((x * 100 / w) / 4 + (y * 100 / h) / 5) % 2 == 0) 50 else 210; rgb(v, v, v) }
            return img to rect(w, h, w * 4 / 10, h * 4 / 10, w * 6 / 10, h * 6 / 10)
        }
        val (a, ma) = scene(400, 300)
        val (b, mb) = scene(1600, 1200)
        val da = diff(a, 400, 300, ma).difficulty
        val db = diff(b, 1600, 1200, mb).difficulty
        println("R20 diff theo độ phân giải: 400px=${"%.2f".format(da)} 1600px=${"%.2f".format(db)}")
        assertTrue("lệch quá lớn: $da vs $db", abs(da - db) < 0.12f)
    }

    // ================================================================ định tuyến theo độ khó
    private fun spec(id: String, kind: String, maxD: String? = null) =
        ProviderSpec(id, kind, emptyList(), 0, "free", if (maxD == null) emptyMap() else mapOf("max_difficulty" to maxD))

    @Test fun forDifficultyDropsEasyOnlyProvidersWhenTheJobIsHard() {
        val chain = listOf(spec("pm_fast", "patchmatch_fill", "0.30"), spec("lama", "lama_onnx"), spec("pm", "patchmatch_fill"), spec("classic", "classic_fill"))
        assertEquals(listOf("pm_fast", "lama", "pm", "classic"), Routing.forDifficulty(chain, 0.1f).map { it.id })
        assertEquals(listOf("pm_fast", "lama", "pm", "classic"), Routing.forDifficulty(chain, 0.30f).map { it.id })   // biên: ≤ max vẫn dùng
        assertEquals(listOf("lama", "pm", "classic"), Routing.forDifficulty(chain, 0.55f).map { it.id })
    }

    @Test fun forDifficultyNeverReturnsEmptyAndIgnoresGarbage() {
        val only = listOf(spec("pm_fast", "patchmatch_fill", "0.30"))
        assertEquals(listOf("pm_fast"), Routing.forDifficulty(only, 0.9f).map { it.id })       // thà thử còn hơn không có gì
        val junk = listOf(spec("a", "classic_fill", "abc"), spec("b", "lama_onnx", ""))
        assertEquals(listOf("a", "b"), Routing.forDifficulty(junk, 0.9f).map { it.id })
    }

    @Test fun defaultRoutingFileEndToEndOrderingByDifficulty() {
        val json = java.io.File("app/src/main/assets/routing_default.json").let { if (it.exists()) it else java.io.File("../app/src/main/assets/routing_default.json") }.readText()
        val cfg = Routing.parse(json)
        assertTrue("version phải ≥ 5 để cấu hình cũ trên máy người dùng bị thay", cfg.version >= 5)
        val dev = DeviceInfo(8000, "", 33, 8)
        // máy đã nạp LaMa + MI-GAN
        val withModels = Routing.chain(cfg, "inpaint_remove", dev, "pro") { it == "file:lama.onnx" || it == "file:migan.onnx" }
        assertEquals(listOf("patchmatch_fast", "lama", "migan", "lama_lowram", "patchmatch", "classic"), withModels.map { it.id })
        assertEquals("patchmatch_fast", Routing.forDifficulty(withModels, 0.1f).first().id)
        assertEquals("lama", Routing.forDifficulty(withModels, 0.7f).first().id)
        // máy mới cài, chưa có model nào: việc khó vẫn rơi vào PatchMatch (tốt hơn push-pull), classic là chốt cuối
        val bare = Routing.chain(cfg, "inpaint_remove", DeviceInfo(3000, "", 30, 4), "free") { false }
        assertEquals(listOf("patchmatch_fast", "patchmatch", "classic"), bare.map { it.id })
        assertEquals(listOf("patchmatch", "classic"), Routing.forDifficulty(bare, 0.9f).map { it.id })
    }
}
