package com.aiphoto.studio

import com.aiphoto.studio.engine.BestTake
import com.aiphoto.studio.engine.FaceGeometry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * R28 Best Take: đo mắt mở / nụ cười, khớp mặt, chọn khung, căn khung bằng tương quan pha, phép đồng dạng và ghép (viền mềm + hiệu chỉnh màu).
 * Khuôn mặt tổng hợp: điểm mốc dựng theo công thức giải tích và ảnh vẽ khớp với các điểm đó, nên kiểm được cả đo lẫn ghép mà không cần model thật.
 */
class R28BestTakeTest {

    // ------------------------------------------------------------------ khuôn mặt tổng hợp
    private val NP = 478

    /** Khuôn mặt giả: tâm (cx, cy) điểm ảnh, [scale] = nửa bề rộng mặt (điểm ảnh), độ mở mắt (EAR) từng mắt, nụ cười 0..1, độ há miệng, độ quay (mũi lệch). */
    private class Face(
        val cx: Float, val cy: Float, val scale: Float,
        val earR: Float = 0.30f, val earL: Float = 0.30f, val smile: Float = 0f, val open: Float = 0.02f, val yaw: Float = 0f
    )

    private fun fakeLm(f: Face, w: Int, h: Int): FloatArray {
        val a = FloatArray(2 * NP)
        fun put(i: Int, u: Float, v: Float) { a[2 * i] = (f.cx + u * f.scale) / w; a[2 * i + 1] = (f.cy + v * f.scale) / h }
        for (i in 0 until NP) put(i, 0f, 0f)
        val oval = FaceGeometry.FACE_OVAL
        for (k in oval.indices) {
            val th = Math.toRadians(-90.0 + 360.0 * k / oval.size)
            put(oval[k], cos(th).toFloat(), 1.25f * sin(th).toFloat())
        }
        put(454, 1f, 0f); put(234, -1f, 0f); put(10, 0f, -1.25f); put(152, 0f, 1.25f)
        val ey = -0.25f
        val sepR = f.earR * 0.40f
        val sepL = f.earL * 0.40f
        put(33, -0.62f, ey); put(133, -0.22f, ey)
        put(160, -0.50f, ey - sepR / 2); put(159, -0.42f, ey - sepR / 2); put(158, -0.32f, ey - sepR / 2)
        put(144, -0.50f, ey + sepR / 2); put(145, -0.42f, ey + sepR / 2); put(153, -0.32f, ey + sepR / 2)
        put(263, 0.62f, ey); put(362, 0.22f, ey)
        put(387, 0.50f, ey - sepL / 2); put(386, 0.42f, ey - sepL / 2); put(385, 0.32f, ey - sepL / 2)
        put(373, 0.50f, ey + sepL / 2); put(374, 0.42f, ey + sepL / 2); put(380, 0.32f, ey + sepL / 2)
        put(1, f.yaw * 2f, 0.15f); put(168, 0f, -0.3f); put(6, 0f, -0.1f); put(127, -0.95f, -0.3f); put(356, 0.95f, -0.3f)
        val d = 1.24f                                      // khoảng cách hai khóe mắt ngoài (đơn vị mặt)
        val mw = d * (0.55f + 0.15f * f.smile)
        val lift = 0.08f * d * f.smile
        val my = 0.62f
        put(61, -mw / 2, my - lift); put(291, mw / 2, my - lift)
        put(13, 0f, my - f.open * d / 2); put(14, 0f, my + f.open * d / 2)
        return a
    }

    /** Băm số nguyên trộn bit tốt (không có chu kỳ ngắn như hàm xor-nhân đơn giản — chu kỳ ngắn làm tương quan pha mơ hồ). */
    private fun hash(u: Int, v: Int): Int {
        var x = u * 374761393 + v * 668265263
        x = (x xor (x ushr 13)) * 1274126177
        return (x xor (x ushr 16)) and 0x7fffffff
    }

    private fun world(u: Int, v: Int): Int {
        val base = 110 + (50 * sin(0.05 * u) * cos(0.04 * v)).toInt() + (25 * sin(0.17 * u + 0.11 * v)).toInt() + (hash(u, v) and 31)
        return base.coerceIn(0, 255)
    }

    /** Vẽ cảnh: nền kết cấu (nội dung dịch theo ([sx],[sy])) + các khuôn mặt (tâm cũng dịch theo). [bright] cộng đều vào mọi kênh (lệch phơi sáng). */
    private fun render(w: Int, h: Int, faces: List<Face>, sx: Int, sy: Int, bright: Int = 0): IntArray {
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) { val g = world(x - sx, y - sy); px[y * w + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g }
        for (f in faces) {
            val cx = f.cx + sx; val cy = f.cy + sy; val s = f.scale
            for (y in (cy - 1.4f * s).toInt()..(cy + 1.4f * s).toInt()) for (x in (cx - 1.1f * s).toInt()..(cx + 1.1f * s).toInt()) {
                if (x !in 0 until w || y !in 0 until h) continue
                val u = (x + 0.5f - cx) / s; val v = (y + 0.5f - cy) / s
                if (u * u + (v / 1.25f) * (v / 1.25f) > 1f) continue
                var c = intArrayOf(200, 160, 140)
                // mắt: elip tối, cao theo độ mở
                for ((ex, ear) in listOf(-0.42f to f.earR, 0.42f to f.earL)) {
                    val hh = max(0.9f / s, ear * 0.40f * 0.5f * 1.0f)
                    val du = (u - ex) / 0.17f; val dv = (v + 0.25f) / hh
                    if (du * du + dv * dv <= 1f) c = intArrayOf(40, 30, 30)
                }
                // miệng: hai đoạn dày 1,5 điểm ảnh từ khóe tới giữa
                val d = 1.24f; val mw = d * (0.55f + 0.15f * f.smile); val lift = 0.08f * d * f.smile
                val my = 0.62f
                if (segDist(u, v, -mw / 2, my - lift, 0f, my) * s < 1.5f || segDist(u, v, mw / 2, my - lift, 0f, my) * s < 1.5f) c = intArrayOf(150, 40, 50)
                px[y * w + x] = (0xFF shl 24) or (c[0] shl 16) or (c[1] shl 8) or c[2]
            }
        }
        if (bright != 0) for (i in px.indices) {
            val p = px[i]
            px[i] = (0xFF shl 24) or ((((p shr 16) and 255) + bright).coerceIn(0, 255) shl 16) or ((((p shr 8) and 255) + bright).coerceIn(0, 255) shl 8) or (((p and 255) + bright).coerceIn(0, 255))
        }
        return px
    }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax; val vy = by - ay
        val t = (((px - ax) * vx + (py - ay) * vy) / (vx * vx + vy * vy)).coerceIn(0f, 1f)
        return hypot(px - (ax + t * vx), py - (ay + t * vy))
    }

    private fun lum(p: Int) = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)

    private fun darkCount(px: IntArray, w: Int, cx: Int, cy: Int, rx: Int, ry: Int): Int {
        var n = 0
        for (y in cy - ry..cy + ry) for (x in cx - rx..cx + rx) if (lum(px[y * w + x]) < 80f) n++
        return n
    }

    private fun m(f: Face, w: Int = 400, h: Int = 300) = BestTake.metrics(fakeLm(f, w, h), w, h)!!

    // ------------------------------------------------------------------ đo biểu cảm
    @Test fun eyeOpennessIsCalibratedAndMonotonic() {
        var prev = -1f
        for (ear in listOf(0.08f, 0.13f, 0.17f, 0.20f, 0.24f, 0.27f, 0.32f)) {
            val e = m(Face(200f, 150f, 60f, earR = ear, earL = ear)).eyes
            assertTrue("EAR $ear: $e >= $prev", e >= prev - 1e-4f)
            prev = e
        }
        assertEquals(0f, m(Face(200f, 150f, 60f, earR = 0.08f, earL = 0.08f)).eyes, 1e-3f)
        assertEquals(0f, m(Face(200f, 150f, 60f, earR = 0.13f, earL = 0.13f)).eyes, 1e-3f)
        assertEquals(0.5f, m(Face(200f, 150f, 60f, earR = 0.20f, earL = 0.20f)).eyes, 0.02f)
        assertEquals(1f, m(Face(200f, 150f, 60f, earR = 0.27f, earL = 0.27f)).eyes, 1e-3f)
        assertEquals(1f, m(Face(200f, 150f, 60f, earR = 0.40f, earL = 0.40f)).eyes, 1e-3f)
    }

    @Test fun oneClosedEyeDragsTheEyeScoreDown() {
        val one = m(Face(200f, 150f, 60f, earR = 0.30f, earL = 0.10f))
        assertEquals(1f, one.eyeR, 1e-3f)
        assertEquals(0f, one.eyeL, 1e-3f)
        assertEquals(0.15f, one.eyes, 1e-3f)                  // 0,7·min + 0,3·trung bình = 0 + 0,15
        assertTrue(m(Face(200f, 150f, 60f)).eyes > one.eyes + 0.8f)
    }

    @Test fun smileIsCalibrated() {
        assertEquals(0f, m(Face(200f, 150f, 60f, smile = 0f)).smile, 0.02f)
        assertEquals(0.5f, m(Face(200f, 150f, 60f, smile = 0.5f)).smile, 0.03f)
        assertEquals(1f, m(Face(200f, 150f, 60f, smile = 1f)).smile, 0.02f)
        assertTrue(m(Face(200f, 150f, 60f, smile = 0.8f)).smile > m(Face(200f, 150f, 60f, smile = 0.3f)).smile)
    }

    @Test fun measurementsDoNotDependOnFaceSizeOrPosition() {
        val a = m(Face(100f, 80f, 30f, earR = 0.2f, earL = 0.2f, smile = 0.6f))
        val b = m(Face(300f, 200f, 90f, earR = 0.2f, earL = 0.2f, smile = 0.6f))
        assertEquals(a.eyes, b.eyes, 0.01f)
        assertEquals(a.smile, b.smile, 0.01f)
        assertEquals(a.mouthOpen, b.mouthOpen, 0.01f)
    }

    @Test fun yawIsSignedAndZeroForFrontalFaces() {
        assertEquals(0f, m(Face(200f, 150f, 60f)).yaw, 1e-3f)
        assertEquals(0.2f, m(Face(200f, 150f, 60f, yaw = 0.2f)).yaw, 0.01f)
        assertEquals(-0.2f, m(Face(200f, 150f, 60f, yaw = -0.2f)).yaw, 0.01f)
    }

    @Test fun mouthOpenIsMeasured() {
        assertEquals(0.02f, m(Face(200f, 150f, 60f, open = 0.02f)).mouthOpen, 0.005f)
        assertEquals(0.4f, m(Face(200f, 150f, 60f, open = 0.4f)).mouthOpen, 0.01f)
    }

    @Test fun metricsRejectBadInput() {
        assertNull(BestTake.metrics(FloatArray(10), 400, 300))
        assertNull(BestTake.metrics(fakeLm(Face(200f, 150f, 60f), 400, 300), 0, 300))
        assertNull(BestTake.metrics(fakeLm(Face(200f, 150f, 1f), 400, 300), 400, 300))     // mặt nhỏ hơn 4 điểm ảnh
        // mảng có khối chiều sâu nối đuôi (3 × 478) vẫn đọc được
        val deep = fakeLm(Face(200f, 150f, 60f), 400, 300).copyOf(3 * NP)
        assertNotNull(BestTake.metrics(deep, 400, 300))
    }

    @Test fun scoreRanksFacesTheWayAPersonWould() {
        fun s(f: Face, sharp: Float = 1f) = BestTake.score(m(f), sharp)
        val neutralOpen = s(Face(200f, 150f, 60f))
        val smiling = s(Face(200f, 150f, 60f, smile = 0.9f))
        val blinkSmiling = s(Face(200f, 150f, 60f, earR = 0.08f, earL = 0.08f, smile = 0.9f))
        val winkSmiling = s(Face(200f, 150f, 60f, earR = 0.30f, earL = 0.08f, smile = 0.9f))
        assertTrue(smiling > neutralOpen)
        assertTrue("mắt mở không cười > nhắm mà cười", neutralOpen > blinkSmiling)
        assertTrue("nháy một mắt vẫn thua mở cả hai", neutralOpen > winkSmiling)
        assertTrue("quay mặt đi bị phạt", s(Face(200f, 150f, 60f, yaw = 0.30f)) < neutralOpen - 0.05f)
        assertEquals("gần chính diện thì không phạt", neutralOpen, s(Face(200f, 150f, 60f, yaw = 0.10f)), 1e-4f)
        assertTrue("há miệng quá rộng bị phạt", s(Face(200f, 150f, 60f, smile = 0.9f, open = 0.5f)) < smiling - 0.1f)
        assertEquals("há miệng vừa phải không phạt", smiling, s(Face(200f, 150f, 60f, smile = 0.9f, open = 0.2f)), 0.01f)
        assertTrue("mặt nhòe thua mặt nét", s(Face(200f, 150f, 60f), 0.2f) < neutralOpen)
        assertEquals(BestTake.W_SHARP * 0.8f, neutralOpen - s(Face(200f, 150f, 60f), 0.2f), 1e-4f)
    }

    // --- các bài "ghim chặt" thêm sau đột biến: công thức chấm điểm là tổng có trọng số ghi trong KDoc; đổi hằng số ⇒ cập nhật các bài này + PROJECT_STATUS §10
    @Test fun scoreIsTheDocumentedWeightedSum() {
        fun s(f: Face, sharp: Float = 1f) = BestTake.score(m(f), sharp)
        assertEquals(0.70f, s(Face(200f, 150f, 60f)), 0.01f)                                        // mắt mở hết 0,55 + nét nhất 0,15
        assertEquals(1.00f, s(Face(200f, 150f, 60f, smile = 1f)), 0.02f)                            // + cười hết 0,30
        assertEquals(0.425f, s(Face(200f, 150f, 60f, earR = 0.20f, earL = 0.20f)), 0.015f)         // mắt mở nửa (trên ngưỡng nhắm): 0,55 · 0,5 + 0,15
        assertEquals(0.55f, s(Face(200f, 150f, 60f), 0f), 0.01f)                                    // không nét: chỉ còn phần mắt
    }

    @Test fun blinkIsPenalizedBelowTheGateAndOnlyBelowIt() {
        fun s(r: Float, l: Float) = BestTake.score(m(Face(200f, 150f, 60f, earR = r, earL = l)), 1f)
        // hai mắt cùng độ mở: eyes 0,30 (dưới ngưỡng 0,35: phạt 0,30) so với 0,40 (trên ngưỡng)
        assertEquals(0.015f, s(0.172f, 0.172f), 0.01f)
        assertEquals(0.370f, s(0.186f, 0.186f), 0.01f)
        // nháy MỘT mắt: tính theo mắt nhắm (min), không theo mắt mở: 0,55 · 0,15 + 0,15 − 0,30
        assertEquals(-0.0675f, s(0.30f, 0.10f), 0.01f)
    }

    @Test fun turnedAwayIsPenalizedInEitherDirectionByTheDocumentedAmount() {
        fun s(y: Float) = BestTake.score(m(Face(200f, 150f, 60f, yaw = y)), 1f)
        val front = s(0f)
        assertEquals(front - 0.18f, s(0.30f), 0.01f)
        assertEquals(front - 0.18f, s(-0.30f), 0.01f)
        assertEquals(front - 0.25f, s(0.60f), 0.01f)                                                // phạt tối đa
        assertEquals(front, s(-0.10f), 1e-4f)                                                       // trong vùng miễn phạt
    }

    @Test fun relativeSharpnessIsClamped() {
        val mm = m(Face(200f, 150f, 60f))
        assertEquals(BestTake.score(mm, 1f), BestTake.score(mm, 7f), 1e-6f)
        assertEquals(BestTake.score(mm, 0f), BestTake.score(mm, -3f), 1e-6f)
    }

    @Test fun aDegenerateEyeIsReportedClosedNotNaN() {
        val lm = fakeLm(Face(200f, 150f, 60f), 400, 300)
        lm[2 * 133] = lm[2 * 33]; lm[2 * 133 + 1] = lm[2 * 33 + 1]                                  // mắt phải co thành một điểm
        val mm = BestTake.metrics(lm, 400, 300)!!
        assertEquals(0f, mm.eyeR, 0f)
        assertEquals(1f, mm.eyeL, 1e-3f)
    }

    // ------------------------------------------------------------------ hình học
    @Test fun centerWidthAndBoxOfAFace() {
        val lm = fakeLm(Face(150f, 100f, 40f), 400, 300)
        val c = BestTake.center(lm, 400, 300)
        assertEquals(150f, c[0], 1.5f)
        assertEquals(100f, c[1], 2f)
        assertEquals(80f, BestTake.faceWidth(lm, 400, 300), 0.5f)
        val b = BestTake.faceBox(lm, 400, 300, 0)!!
        assertTrue(abs(b[0] - 110) <= 2 && abs(b[2] - 190) <= 2 && abs(b[1] - 50) <= 2 && abs(b[3] - 150) <= 2)
        val near = BestTake.faceBox(fakeLm(Face(10f, 10f, 40f), 400, 300), 400, 300, 5)!!
        assertEquals(0, near[0]); assertEquals(0, near[1])                              // kẹp trong ảnh
        assertNull(BestTake.faceBox(FloatArray(4), 400, 300, 0))
    }

    @Test fun faceBoxIsClampedAtAllFourBordersAndRejectsEmpty() {
        val near = BestTake.faceBox(fakeLm(Face(392f, 292f, 40f), 400, 300), 400, 300, 6)!!
        assertEquals(400, near[2]); assertEquals(300, near[3])
        // mọi điểm trùng nhau ở tọa độ nguyên ⇒ khung rỗng
        assertNull(BestTake.faceBox(FloatArray(2 * NP) { 0.5f }, 400, 300, 0))
    }

    @Test fun sharpnessOfATinyFaceIsZero() {
        val f = Face(200f, 150f, 3f)
        val px = render(400, 300, listOf(f), 0, 0)
        assertEquals(0f, BestTake.sharpness(px, 400, 300, fakeLm(f, 400, 300)), 0f)
    }

    @Test fun sharpnessDropsWhenTheFaceIsBlurred() {
        val w = 400; val h = 300
        val f = Face(200f, 150f, 60f)
        val lm = fakeLm(f, w, h)
        val sharp = render(w, h, listOf(f), 0, 0)
        val blur = sharp.copyOf()
        // làm nhòe hộp 5×5 trong khung mặt
        val box = BestTake.faceBox(lm, w, h, 0)!!
        for (y in box[1] + 2 until box[3] - 2) for (x in box[0] + 2 until box[2] - 2) {
            var r = 0; var n = 0
            for (dy in -2..2) for (dx in -2..2) { r += (sharp[(y + dy) * w + x + dx] shr 8) and 255; n++ }
            val g = r / n
            blur[y * w + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        val a = BestTake.sharpness(sharp, w, h, lm)
        val b = BestTake.sharpness(blur, w, h, lm)
        assertTrue("$a vs $b", a > 3f * b)
        assertEquals(0f, BestTake.sharpness(sharp, w, h, FloatArray(10)), 0f)
        assertEquals(0f, BestTake.sharpness(IntArray(5), w, h, lm), 0f)
    }

    @Test fun sameFramingIsARelativeToleranceAtAnyAspect() {
        assertTrue(BestTake.sameFraming(1000, 750, 1358, 1000))       // 1,333 vs 1,358: lệch tuyệt đối 0,025 nhưng chỉ 1,9%
        assertTrue(BestTake.sameFraming(3000, 1000, 3050, 1000))      // tỉ lệ rộng: 1,7%
        assertFalse(BestTake.sameFraming(3000, 1000, 3100, 1000))     // 3,3%
        assertFalse(BestTake.sameFraming(500, 1000, 512, 1000))       // tỉ lệ hẹp: lệch tuyệt đối 0,012 nhưng 2,4%
    }

    @Test fun sameFramingToleratesTwoPercent() {
        assertTrue(BestTake.sameFraming(4000, 3000, 1600, 1200))
        assertTrue(BestTake.sameFraming(1000, 750, 1010, 750))
        assertFalse(BestTake.sameFraming(1000, 750, 750, 1000))
        assertFalse(BestTake.sameFraming(1000, 750, 1000, 700))
        assertFalse(BestTake.sameFraming(0, 750, 1000, 700))
    }

    // ------------------------------------------------------------------ khớp mặt
    @Test fun matchFacesUsesShiftAndRejectsFarOrDifferentSizedFaces() {
        val w = 400; val h = 300
        val base = listOf(fakeLm(Face(100f, 150f, 40f), w, h), fakeLm(Face(300f, 150f, 40f), w, h))
        // khung phụ: cùng hai người nhưng đảo thứ tự và dịch (+10, −6)
        val other = listOf(fakeLm(Face(310f, 144f, 41f), w, h), fakeLm(Face(110f, 144f, 39f), w, h))
        val none = BestTake.matchFaces(base, other, w, h, 0f, 0f)
        assertEquals(listOf(1, 0), none.toList())                  // dịch 10 điểm ảnh vẫn nằm trong 0,6 × bề rộng mặt (80)
        val shifted = BestTake.matchFaces(base, other, w, h, -10f, 6f)
        assertEquals(listOf(1, 0), shifted.toList())
        // dịch lớn: không khớp nếu không bù
        val far = listOf(fakeLm(Face(180f, 150f, 40f), w, h))
        assertEquals(listOf(-1, -1), BestTake.matchFaces(base, far, w, h, 0f, 0f).toList())
        assertEquals(listOf(0, -1), BestTake.matchFaces(base, far, w, h, -80f, 0f).toList())
        // khác cỡ quá 1,8 lần: không khớp
        val big = listOf(fakeLm(Face(100f, 150f, 80f), w, h))
        assertEquals(listOf(-1, -1), BestTake.matchFaces(base, big, w, h, 0f, 0f).toList())
        // mỗi mặt phụ chỉ khớp một mặt gốc: hai mặt gốc sát nhau tranh một mặt phụ → mặt gần hơn thắng
        val close = listOf(fakeLm(Face(100f, 150f, 40f), w, h), fakeLm(Face(140f, 150f, 40f), w, h))
        val one = listOf(fakeLm(Face(138f, 150f, 40f), w, h))
        assertEquals(listOf(-1, 0), BestTake.matchFaces(close, one, w, h, 0f, 0f).toList())
        assertEquals(listOf(-1, -1), BestTake.matchFaces(base, emptyList(), w, h, 0f, 0f).toList())
        assertEquals(emptyList<Int>(), BestTake.matchFaces(emptyList(), other, w, h, 0f, 0f).toList())
        // điểm mốc thiếu: bỏ qua
        assertEquals(listOf(-1, -1), BestTake.matchFaces(base, listOf(FloatArray(10)), w, h, 0f, 0f).toList())
    }

    @Test fun matchRadiusScalesWithTheLargerFace() {
        val w = 400; val h = 300
        val small = listOf(fakeLm(Face(100f, 150f, 40f), w, h))           // rộng 80
        val bigger = listOf(fakeLm(Face(160f, 150f, 60f), w, h))          // rộng 120, tâm cách 60: ≤ 0,6 × 120 nhưng > 0,6 × 80
        assertEquals(listOf(0), BestTake.matchFaces(small, bigger, w, h, 0f, 0f).toList())
        assertEquals(listOf(0), BestTake.matchFaces(bigger, small, w, h, 0f, 0f).toList())
    }

    @Test fun matchIgnoresFacesTooSmallToMeasure() {
        val w = 400; val h = 300
        val tiny = listOf(fakeLm(Face(100f, 150f, 1.75f), w, h))          // rộng 3,5 < 4
        val abit = listOf(fakeLm(Face(100f, 150f, 2.5f), w, h))          // rộng 5, tỉ lệ 1,43 (qua ngưỡng tỉ lệ)
        assertEquals(listOf(-1), BestTake.matchFaces(tiny, abit, w, h, 0f, 0f).toList())
        assertEquals(listOf(-1), BestTake.matchFaces(abit, tiny, w, h, 0f, 0f).toList())
    }

    // ------------------------------------------------------------------ chọn khung
    private fun frame(faces: List<Face>, dx: Float = 0f, dy: Float = 0f, w: Int = 400, h: Int = 300, sharp: Float = 100f) =
        BestTake.FaceFrame(faces.map { fakeLm(it, w, h) }, FloatArray(faces.size) { sharp }, dx, dy)

    @Test fun planPicksTheBestFramePerFace() {
        val a0 = Face(120f, 150f, 55f, earR = 0.05f, earL = 0.05f, smile = 0.3f)     // A nhắm mắt ở gốc
        val b0 = Face(280f, 150f, 55f, smile = 0.8f)                                  // B ổn ở gốc
        val f0 = frame(listOf(a0, b0))
        val f1 = frame(listOf(Face(126f, 146f, 55f, smile = 0.7f), Face(286f, 146f, 55f, earR = 0.05f, earL = 0.05f)), dx = -6f, dy = 4f)
        val f2 = frame(listOf(Face(115f, 153f, 55f, smile = 0.1f), Face(275f, 153f, 55f, smile = 0.9f)), dx = 5f, dy = -3f)
        val picks = BestTake.plan(listOf(f0, f1, f2), 400, 300)
        assertEquals(2, picks.size)
        assertEquals(1, picks[0].frame)                       // A: mở mắt + cười ở khung 1
        assertEquals(0, picks[0].frameFace)
        assertTrue(picks[0].changed)
        assertTrue(picks[0].bestScore > picks[0].baseScore + BestTake.SWITCH_MARGIN)
        assertEquals(0, picks[1].frame)                       // B: khung 2 chỉ hơn chút (< lề đổi) ⇒ giữ ảnh gốc
        assertFalse(picks[1].changed)
        assertEquals(picks[1].baseScore, picks[1].bestScore, 1e-6f)
    }

    @Test fun planKeepsTheBaseWhenNothingIsClearlyBetter() {
        val a = Face(120f, 150f, 55f, smile = 0.5f)
        val picks = BestTake.plan(listOf(frame(listOf(a)), frame(listOf(Face(121f, 150f, 55f, smile = 0.55f)))), 400, 300)
        assertFalse(picks.single().changed)
    }

    @Test fun planIgnoresFramesWhereTheFaceIsMissingOrTurnedAway() {
        val a = Face(120f, 150f, 55f, earR = 0.05f, earL = 0.05f)
        val missing = frame(listOf(Face(330f, 150f, 55f)))                           // người khác, quá xa
        val turned = frame(listOf(Face(120f, 150f, 55f, yaw = 0.35f, earR = 0.30f, earL = 0.30f, smile = 0.2f)))
        val picks = BestTake.plan(listOf(frame(listOf(a)), missing, turned), 400, 300)
        assertEquals(2, picks.single().frame)   // khung 1 không có người này (người khác, quá xa) bị bỏ qua; khung 2 quay mặt nhưng vẫn hơn mặt nhắm mắt
        val onlyMissing = BestTake.plan(listOf(frame(listOf(a)), missing), 400, 300)
        assertFalse(onlyMissing.single().changed)
    }

    @Test fun planUsesSharpnessAsAWeakTieBreaker() {
        val a = Face(120f, 150f, 55f, smile = 0.5f)
        val blurry = BestTake.FaceFrame(listOf(fakeLm(a, 400, 300)), floatArrayOf(10f), 0f, 0f)
        val sharp = BestTake.FaceFrame(listOf(fakeLm(a, 400, 300)), floatArrayOf(100f), 0f, 0f)
        // hai khung giống hệt về biểu cảm: độ nét chênh (0,15 × 0,9 = 0,135 ≥ lề 0,10) ⇒ chọn khung nét
        val p = BestTake.plan(listOf(blurry, sharp), 400, 300).single()
        assertEquals(1, p.frame)
        // chênh nhẹ ⇒ không đổi
        val almost = BestTake.FaceFrame(listOf(fakeLm(a, 400, 300)), floatArrayOf(95f), 0f, 0f)
        assertFalse(BestTake.plan(listOf(sharp, almost), 400, 300).single().changed)
    }

    @Test fun describeSaysWhatChangedInPlainNumbers() {
        val a0 = Face(120f, 150f, 55f, earR = 0.05f, earL = 0.05f, smile = 0.3f)
        val f1 = Face(126f, 146f, 55f, smile = 0.8f)
        val picks = BestTake.plan(listOf(frame(listOf(a0)), frame(listOf(f1), dx = -6f, dy = 4f)), 400, 300)
        val t = BestTake.describe(picks.single(), "ảnh phụ 1")
        assertTrue(t, t.startsWith("Mặt 1 ← ảnh phụ 1 (mắt mở 0% → 100%"))
        assertTrue(t, "cười" in t && t.endsWith("%)"))
        // mặt giữ nguyên + mặt không đo được
        val keep = BestTake.plan(listOf(frame(listOf(a0)), frame(listOf(Face(121f, 150f, 55f, earR = 0.05f, earL = 0.05f, smile = 0.3f)))), 400, 300).single()
        assertEquals("Mặt 1: giữ ảnh gốc.", BestTake.describe(keep, "ảnh phụ 1"))
        assertEquals("Mặt 3: không đo được.", BestTake.describe(BestTake.Pick(2, 0, 2, 0f, 0f, null, null), "x"))
    }

    @Test fun frameLimitIsSmallEnoughForWeakDevices() {
        assertTrue(BestTake.MAX_FRAMES in 2..12)
    }

    @Test fun planKeepsABaseFaceThatCannotBeMeasuredEvenWhenOtherFramesCan() {
        val bad = fakeLm(Face(120f, 150f, 55f), W, H)
        bad[2 * 263] = bad[2 * 33]; bad[2 * 263 + 1] = bad[2 * 33 + 1]    // hai khóe mắt ngoài trùng nhau ⇒ không đo được, nhưng bề rộng mặt vẫn hợp lệ
        val base = BestTake.FaceFrame(listOf(bad), floatArrayOf(100f), 0f, 0f)
        val p = BestTake.plan(listOf(base, frame(listOf(Face(120f, 150f, 55f, smile = 0.9f)))), W, H).single()
        assertFalse(p.changed)
        assertNull(p.baseMetrics)
    }

    @Test fun planHandlesEmptyAndFacelessBase() {
        assertEquals(0, BestTake.plan(emptyList(), 400, 300).size)
        assertEquals(0, BestTake.plan(listOf(BestTake.FaceFrame(emptyList(), FloatArray(0), 0f, 0f)), 400, 300).size)
        // điểm mốc hỏng ở khung gốc: giữ nguyên, không ném lỗi
        val broken = BestTake.FaceFrame(listOf(FloatArray(10)), floatArrayOf(1f), 0f, 0f)
        val p = BestTake.plan(listOf(broken, frame(listOf(Face(120f, 150f, 55f)))), 400, 300).single()
        assertFalse(p.changed)
        assertNull(p.baseMetrics)
    }

    // ------------------------------------------------------------------ phép đồng dạng
    @Test fun similarityRecoversRotationScaleAndTranslation() {
        val ang = 0.35f; val k = 1.3f; val tx = 40f; val ty = -25f
        val pts = floatArrayOf(10f, 20f, 100f, 30f, 60f, 150f, 200f, 120f, 5f, 90f)
        val dst = FloatArray(pts.size)
        for (i in 0 until pts.size / 2) {
            val x = pts[2 * i]; val y = pts[2 * i + 1]
            dst[2 * i] = k * (cos(ang) * x - sin(ang) * y) + tx
            dst[2 * i + 1] = k * (sin(ang) * x + cos(ang) * y) + ty
        }
        val s = BestTake.similarity(pts, dst)!!
        assertEquals(k, s.scale, 1e-4f)
        assertEquals(ang, s.angle, 1e-4f)
        for (i in 0 until pts.size / 2) {
            assertEquals(dst[2 * i], s.mapX(pts[2 * i], pts[2 * i + 1]), 1e-2f)
            assertEquals(dst[2 * i + 1], s.mapY(pts[2 * i], pts[2 * i + 1]), 1e-2f)
        }
        val inv = s.inverse()!!
        for (i in 0 until pts.size / 2) {
            assertEquals(pts[2 * i], inv.mapX(dst[2 * i], dst[2 * i + 1]), 1e-2f)
            assertEquals(pts[2 * i + 1], inv.mapY(dst[2 * i], dst[2 * i + 1]), 1e-2f)
        }
    }

    @Test fun similarityIsLeastSquaresUnderNoiseAndRejectsDegenerateInput() {
        val pts = FloatArray(40) { (it * 37 % 101).toFloat() }
        val dst = FloatArray(40) { pts[it] + (if (it % 3 == 0) 0.4f else -0.3f) }       // tịnh tiến ≈ 0 kèm nhiễu nhỏ
        val s = BestTake.similarity(pts, dst)!!
        assertEquals(1f, s.scale, 0.01f)
        assertEquals(0f, s.angle, 0.01f)
        assertNull(BestTake.similarity(floatArrayOf(1f, 1f), floatArrayOf(2f, 2f)))               // 1 điểm
        assertNull(BestTake.similarity(floatArrayOf(5f, 5f, 5f, 5f), floatArrayOf(1f, 2f, 3f, 4f))) // nguồn suy biến
        assertNull(BestTake.Sim(0f, 0f, 1f, 1f).inverse())
    }

    @Test fun faceSimAveragesNoiseOverManyRigidPoints() {
        val w = 400; val h = 300
        val base = fakeLm(Face(120f, 150f, 55f), w, h)
        val src = fakeLm(Face(130f, 144f, 55f), w, h)
        // bốn khóe mắt bị đo lệch (+2, +2) điểm ảnh: ước lượng trên 12 điểm "cứng" chỉ lệch ≈ 2 · 4/12, không phải cả 2
        for (i in intArrayOf(33, 133, 362, 263)) { src[2 * i] += 2f / w; src[2 * i + 1] += 2f / h }
        val s = BestTake.faceSim(src, base, w, h)!!
        assertEquals(120f, s.mapX(130f, 144f), 1.0f)
        assertEquals(150f, s.mapY(130f, 144f), 1.0f)
    }

    @Test fun faceSimAlignsTwoRendersOfTheSameFaceAndRejectsAbsurdScales() {
        val w = 400; val h = 300
        val base = fakeLm(Face(120f, 150f, 55f), w, h)
        val other = fakeLm(Face(130f, 144f, 55f, smile = 0.8f, earR = 0.1f, earL = 0.1f), w, h)    // biểu cảm khác, dịch (+10, −6)
        val s = BestTake.faceSim(other, base, w, h)!!
        assertEquals(1f, s.scale, 0.01f)
        assertEquals(-10f, s.mapX(130f, 144f) - 130f + 0f, 1.0f)       // (130,144) → (120,150): dịch (−10,+6)
        assertEquals(6f, s.mapY(130f, 144f) - 144f, 1.0f)
        assertNull(BestTake.faceSim(fakeLm(Face(130f, 144f, 150f), w, h), base, w, h))            // lớn gấp 2,7 lần
        assertNull(BestTake.faceSim(FloatArray(10), base, w, h))
    }

    // ------------------------------------------------------------------ căn khung toàn cục
    private fun texture(n: Int, dx: Int, dy: Int): FloatArray {
        val out = FloatArray(n * n)
        for (y in 0 until n) for (x in 0 until n) {
            val u = x - dx; val v = y - dy
            out[y * n + x] = if (u < 0 || v < 0 || u >= n || v >= n) 0f else
                (100 + 60 * sin(0.21 * u) * cos(0.17 * v) + 35 * sin(0.047 * u + 0.09 * v) + (hash(u, v) and 15)).toFloat()
        }
        return out
    }

    @Test fun phaseShiftFindsIntegerTranslationsWithHighConfidence() {
        val n = 256
        val a = texture(n, 0, 0)
        for ((dx, dy) in listOf(13 to -7, -20 to 15, 0 to 0, 3 to 0, 0 to -9)) {
            val s = BestTake.phaseShift(a, texture(n, dx, dy), n)
            assertEquals("dx=$dx dy=$dy", dx.toFloat(), s.dx, 1f)
            assertEquals("dx=$dx dy=$dy", dy.toFloat(), s.dy, 1f)
            assertTrue("PSR ${s.psr}", s.psr > 10f)
        }
    }

    /** Cảnh các đốm Gauss (nội dung dịch theo (dx,dy), đốm ra khỏi khung thì mất) + dốc sáng CỐ ĐỊNH theo khung (vignette / ánh sáng) + nhiễu ĐỘC LẬP mỗi khung (nhiễu cảm biến). */
    private fun blobScene(n: Int, dx: Int, dy: Int, noiseSeed: Long, noise: Float): FloatArray {
        val rnd = java.util.Random(7)
        val bx = FloatArray(60) { rnd.nextFloat() * n }; val by = FloatArray(60) { rnd.nextFloat() * n }
        val bs = FloatArray(60) { 5f + rnd.nextFloat() * 6f }; val ba = FloatArray(60) { 40f + rnd.nextFloat() * 60f }
        val nr = java.util.Random(noiseSeed)
        val out = FloatArray(n * n)
        for (y in 0 until n) for (x in 0 until n) {
            var v = 40f + 0.6f * x + 0.4f * y
            for (k in 0 until 60) {
                val ex = x - (bx[k] + dx); val ey = y - (by[k] + dy)
                v += ba[k] * kotlin.math.exp(-(ex * ex + ey * ey) / (2f * bs[k] * bs[k]))
            }
            out[y * n + x] = v + noise * nr.nextGaussian().toFloat()
        }
        return out
    }

    @Test fun phaseShiftSurvivesFrameFixedGradientsAndIndependentNoise() {
        val n = 256
        // pha thuần túy (không trọng số tần số) chỉ đúng 7/20 ở nhiễu σ = 5 vì nhiễu tần số cao ngang quyền với cấu trúc — xem ALIGN_BAND
        for (noise in listOf(5f, 20f, 40f)) for ((dx, dy) in listOf(11 to -6, -17 to 9, 4 to 3, 25 to 20)) {
            val s = BestTake.phaseShift(blobScene(n, 0, 0, 1, noise), blobScene(n, dx, dy, 2, noise), n)
            assertEquals("σ=$noise dx", dx.toFloat(), s.dx, 1f)
            assertEquals("σ=$noise dy", dy.toFloat(), s.dy, 1f)
            assertTrue("σ=$noise PSR ${s.psr}", s.psr > 8f)
        }
    }

    @Test fun phaseShiftIsNotConfidentOnUnrelatedOrFlatImages() {
        val n = 256
        val a = texture(n, 0, 0)
        val rnd = java.util.Random(99)
        val noise = FloatArray(n * n) { 100f + rnd.nextFloat() * 20f }
        assertTrue(BestTake.phaseShift(a, noise, n).psr < 8f)
        val flat = FloatArray(n * n) { 80f }
        assertTrue(BestTake.phaseShift(flat, flat, n).psr < 8f)
    }

    @Test fun alignShiftDistrustsUnrelatedImages() {
        val n = 256
        val rnd = java.util.Random(99)
        val noise = FloatArray(n * n) { 100f + rnd.nextFloat() * 20f }
        val raw = BestTake.phaseShift(texture(n, 0, 0), noise, n)
        assertTrue("đỉnh ngẫu nhiên phải khác (0,0) để bài này có nghĩa", raw.dx != 0f || raw.dy != 0f)
        val s = BestTake.alignShift(texture(n, 0, 0), noise, 512, 384)
        assertEquals(0f, s[0], 0f); assertEquals(0f, s[1], 0f)
    }

    @Test fun alignShiftReturnsTheOffsetFromOtherToBaseCoordinates() {
        val w = 512; val h = 384
        val a = render(w, h, emptyList(), 0, 0)
        val b = render(w, h, emptyList(), 20, -12)                    // nội dung của b dịch (+20, −12) so với a
        val s = BestTake.alignShift(BestTake.thumb(a, w, h), BestTake.thumb(b, w, h), w, h)
        // x_gốc = x_phụ − 20, y_gốc = y_phụ + 12
        assertEquals(-20f, s[0], 3f)
        assertEquals(12f, s[1], 3f)
        val same = BestTake.alignShift(BestTake.thumb(a, w, h), BestTake.thumb(a, w, h), w, h)
        assertEquals(0f, same[0], 1e-3f); assertEquals(0f, same[1], 1e-3f)
        val flat = IntArray(w * h) { 0xFF808080.toInt() }
        val none = BestTake.alignShift(BestTake.thumb(flat, w, h), BestTake.thumb(flat, w, h), w, h)
        assertEquals(0f, none[0], 1e-3f); assertEquals(0f, none[1], 1e-3f)       // ảnh trơn: không tin ⇒ (0, 0)
    }

    // ------------------------------------------------------------------ khoảng cách trong + hiệu chỉnh điều hòa
    @Test fun insideDistanceGrowsFromTheBoundaryInward() {
        val bw = 40; val bh = 30
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; x in 10..29 && y in 5..24 }
        val d = BestTake.insideDistance(inside, bw, bh)
        assertEquals(0f, d[0], 0f)                                          // ngoài vùng
        assertEquals(1f, d[5 * bw + 10], 1e-4f)                             // điểm ngay sát biên
        assertEquals(1f, d[5 * bw + 20], 1e-4f)
        assertEquals(2f, d[6 * bw + 20], 1e-4f)
        assertTrue(d[15 * bw + 20] in 9.5f..10.5f)                          // gần tâm: ≈ nửa cạnh ngắn
        for (i in d.indices) if (!inside[i]) assertEquals(0f, d[i], 0f)
    }

    @Test fun insideDistanceIsCloseToEuclideanOnADisc() {
        val bw = 100; val bh = 100
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; (x - 50) * (x - 50) + (y - 50) * (y - 50) <= 900 }
        val d = BestTake.insideDistance(inside, bw, bh)
        assertTrue("tâm ${d[50 * bw + 50]}", d[50 * bw + 50] in 29f..33f)
        for ((x, y) in listOf(50 to 70, 50 to 30, 70 to 50, 30 to 50)) assertTrue("($x,$y) ${d[y * bw + x]}", d[y * bw + x] in 9.5f..12f)   // 20 điểm tính từ tâm theo trục: còn ≈ 11 tới biên
        assertTrue("chéo ${d[64 * bw + 64]}", d[64 * bw + 64] in 9.5f..12.5f)                                                              // cách tâm 19,8 theo đường chéo
    }

    @Test fun theArrayBorderCountsAsOutsideForInsideDistance() {
        val d = BestTake.insideDistance(BooleanArray(25) { true }, 5, 5)
        for (y in 0 until 5) for (x in 0 until 5) assertEquals("($x,$y)", minOf(minOf(x + 1, y + 1), minOf(5 - x, 5 - y)).toFloat(), d[y * 5 + x], 1e-4f)
    }

    @Test fun harmonicOffsetOfAConstantDifferenceIsThatConstant() {
        val bw = 60; val bh = 50
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; (x - 30) * (x - 30) + (y - 25) * (y - 25) <= 400 }
        val diff = FloatArray(3 * bw * bh)
        for (i in 0 until bw * bh) if (inside[i]) { diff[3 * i] = -25f; diff[3 * i + 1] = 10f; diff[3 * i + 2] = 3f }
        val h = BestTake.harmonicOffset(diff, inside, bw, bh)
        for (i in 0 until bw * bh) if (inside[i]) {
            assertEquals(-25f, h[3 * i], 0.6f); assertEquals(10f, h[3 * i + 1], 0.6f); assertEquals(3f, h[3 * i + 2], 0.6f)
        }
    }

    @Test fun harmonicOffsetInterpolatesBoundaryValuesAndIgnoresInteriorDetail() {
        val bw = 80; val bh = 80
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; x in 8..71 && y in 8..71 }
        val diff = FloatArray(3 * bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) if (inside[y * bw + x]) {
            val edge = x == 8 || x == 71 || y == 8 || y == 71
            // biên: độ lệch tuyến tính theo x (hàm điều hòa); trong lòng: gai nhiễu lớn không được phép ảnh hưởng nghiệm
            diff[3 * (y * bw + x)] = if (edge) 20f + 0.25f * x else 500f
        }
        val h = BestTake.harmonicOffset(diff, inside, bw, bh)
        for (y in 20..60 step 8) for (x in 20..60 step 8) assertEquals("($x,$y)", 20f + 0.25f * x, h[3 * (y * bw + x)], 2.0f)
        assertEquals(0f, BestTake.harmonicOffset(FloatArray(3 * 4), BooleanArray(4), 2, 2)[0], 0f)    // không có vùng ⇒ 0
    }

    @Test fun harmonicOffsetReproducesALinearFieldWithoutSubCellShift() {
        val bw = 100; val bh = 100
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; x in 10..89 && y in 10..89 }
        val diff = FloatArray(3 * bw * bh)
        for (i in 0 until bw * bh) if (inside[i]) { diff[3 * i] = 2f * (i % bw); diff[3 * i + 1] = 2f * (i / bw) }      // kênh đỏ đổi theo x, kênh lục theo y
        val h = BestTake.harmonicOffset(diff, inside, bw, bh)
        for (x in 20..60 step 10) assertEquals("x=$x", 2f * x, h[3 * (50 * bw + x)], 0.6f)       // nội suy lệch nửa ô sẽ lệch ≈ 2 mức
        for (y in 20..60 step 10) assertEquals("y=$y", 2f * y, h[3 * (y * bw + 50) + 1], 0.6f)
    }

    @Test fun aThinSpikeOfOutliersDoesNotLeakIntoTheInterior() {
        val bw = 100; val bh = 100
        val inside = BooleanArray(bw * bh) { val x = it % bw; val y = it / bw; (x - 50) * (x - 50) + (y - 50) * (y - 50) <= 900 || (y == 50 && x in 81..90) }
        val diff = FloatArray(3 * bw * bh)
        for (i in 0 until bw * bh) if (inside[i]) diff[3 * i] = if ((i / bw) == 50 && (i % bw) > 80) 200f else 10f
        val h = BestTake.harmonicOffset(diff, inside, bw, bh)
        for ((x, y) in listOf(50 to 50, 40 to 50, 60 to 50, 50 to 40)) assertEquals("($x,$y)", 10f, h[3 * (y * bw + x)], 0.5f)   // ô chỉ phủ vài điểm của gai không được làm điều kiện biên
    }

    // ------------------------------------------------------------------ ghép
    private val W = 400
    private val H = 300

    private fun scene(a: Face, b: Face, sx: Int = 0, sy: Int = 0, bright: Int = 0) = render(W, H, listOf(a, b), sx, sy, bright)

    @Test fun applyFaceOpensTheEyesOfTheBaseFaceAndTouchesNothingElse() {
        val a0 = Face(120f, 150f, 55f, earR = 0.04f, earL = 0.04f, smile = 0.2f)
        val a1 = Face(120f, 150f, 55f, smile = 0.8f)
        val b = Face(280f, 150f, 55f, smile = 0.5f)
        val base = scene(a0, b)
        val src = scene(a1, b, 6, -4)                                   // khung phụ lệch (6, −4)
        val out = base.copyOf()
        val lmBase = fakeLm(a0, W, H)
        val lmSrc = fakeLm(Face(126f, 146f, 55f, smile = 0.8f), W, H)    // điểm mốc phát hiện được trên khung phụ
        assertTrue(BestTake.applyFace(out, W, H, src, lmSrc, lmBase))
        // mắt phải của A: số điểm tối ở cửa sổ quanh mắt
        val ex = (120f - 0.42f * 55f).toInt(); val ey = (150f - 0.25f * 55f).toInt()
        val closed = darkCount(base, W, ex, ey, 14, 8)
        val opened = darkCount(out, W, ex, ey, 14, 8)
        val target = darkCount(src, W, ex + 6, ey - 4, 14, 8)
        assertTrue("mắt gốc $closed → sau ghép $opened (đích $target)", opened > 2 * closed)
        assertEquals(target.toFloat(), opened.toFloat(), 0.2f * target)
        // mọi điểm ngoài khung bao khuôn mặt A giữ nguyên từng bit (kể cả B)
        val box = BestTake.faceBox(lmBase, W, H, 2)!!
        for (y in 0 until H) for (x in 0 until W) {
            if (x in box[0] until box[2] && y in box[1] until box[3]) continue
            assertEquals("($x,$y)", base[y * W + x], out[y * W + x])
        }
    }

    @Test fun applyFaceLeavesNoSeamWhenTheFramesDifferInExposure() {
        val a0 = Face(120f, 150f, 55f, earR = 0.04f, earL = 0.04f)
        val a1 = Face(120f, 150f, 55f, smile = 0.8f)
        val b = Face(280f, 150f, 55f)
        val base = scene(a0, b)
        val src = scene(a1, b, 4, 3, bright = 28)                       // khung phụ sáng hơn 28 mức
        val out = base.copyOf()
        assertTrue(BestTake.applyFace(out, W, H, src, fakeLm(Face(124f, 153f, 55f, smile = 0.8f), W, H), fakeLm(a0, W, H)))
        // vùng da không có chi tiết (má trái, má phải, trán): đúng màu da của ảnh gốc dù nguồn sáng hơn 28 mức
        for ((u, v) in listOf(-0.6f to 0.3f, 0.6f to 0.3f, 0f to -0.8f, -0.4f to 0.9f)) {
            val x = (120f + u * 55f).toInt(); val y = (150f + v * 55f).toInt()
            for (shift in intArrayOf(16, 8, 0)) {
                val want = (base[y * W + x] shr shift) and 255
                val got = (out[y * W + x] shr shift) and 255
                assertEquals("da ở ($u,$v) kênh $shift", want.toFloat(), got.toFloat(), 4f)
            }
        }
        // không có "bậc thang" ở viền mặt: sai khác so với ảnh gốc trên vành trong ≤ 3 mức
        val lm = fakeLm(a0, W, H)
        var worst = 0
        for (k in 0 until 72) {
            val th = Math.toRadians(5.0 * k)
            val x = (120 + 0.97 * 55 * cos(th)).toInt(); val y = (150 + 0.97 * 1.25 * 55 * sin(th)).toInt()
            worst = max(worst, abs((base[y * W + x] shr 8 and 255) - (out[y * W + x] shr 8 and 255)))
        }
        assertTrue("sai khác lớn nhất ở viền: $worst", worst <= 6)
        assertNotNull(lm)
    }

    private fun noisy(w: Int, h: Int): IntArray = IntArray(w * h) { val g = 100 + (hash(it % w, it / w) % 61) - 30; (0xFF shl 24) or (g shl 16) or (g shl 8) or g }

    @Test fun theBlendFadesInGraduallyFromTheFaceOutline() {
        val a = Face(200f, 150f, 55f)
        val base = IntArray(W * H) { 0xFF646464.toInt() }
        val src = noisy(W, H)
        val out = base.copyOf()
        val lm = fakeLm(a, W, H)
        assertTrue(BestTake.applyFace(out, W, H, src, lm, lm))
        fun meanDev(rLo: Float, rHi: Float): Float {
            var acc = 0f; var n = 0
            for (y in 60..240) for (x in 120..280) {
                val u = (x + 0.5f - 200f) / 55f; val v = (y + 0.5f - 150f) / (55f * 1.25f)
                val r = kotlin.math.sqrt(u * u + v * v)
                if (r < rLo || r >= rHi) continue
                acc += abs((out[y * W + x] and 255) - 100).toFloat(); n++
            }
            return acc / n
        }
        val ring = meanDev(0.93f, 0.96f)       // cách viền ≈ 2–4 điểm ảnh
        val core = meanDev(0f, 0.5f)
        assertTrue("lõi $core phải thấy rõ khuôn mặt nguồn", core > 8f)
        assertTrue("vành $ring so với lõi $core: viền phải mềm", ring < 0.35f * core)
    }

    @Test fun pixelsWhoseSourceCoordinateFallsOutsideTheSourceImageAreNotTouched() {
        val base = IntArray(W * H) { 0xFF646464.toInt() }
        val src = noisy(W, H)
        val out = base.copyOf()
        // mặt gốc ở (100,150) nhưng mặt nguồn ở (30,150): điểm gốc x < 70 ứng với x_nguồn < 0 (không có dữ liệu)
        assertTrue(BestTake.applyFace(out, W, H, src, fakeLm(Face(30f, 150f, 55f), W, H), fakeLm(Face(100f, 150f, 55f), W, H)))
        for (y in 120..180) for (x in 46..66) assertEquals("($x,$y)", base[y * W + x], out[y * W + x])
        var changed = 0
        for (y in 120..180) for (x in 90..110) if (out[y * W + x] != base[y * W + x]) changed++
        assertTrue("phần có dữ liệu vẫn phải được ghép", changed > 100)
    }

    @Test fun applyFaceRefusesAFaceTooSmallToBlend() {
        val tiny = Face(200f, 150f, 1f)
        val base = render(W, H, listOf(tiny), 0, 0)
        val keep = base.copyOf()
        assertFalse(BestTake.applyFace(keep, W, H, base, fakeLm(tiny, W, H), fakeLm(tiny, W, H)))
        assertTrue(keep.contentEquals(base))
    }

    @Test fun naivePasteWouldHaveLeftTheExposureStep() {
        // đối chứng cho bài trên: nếu KHÔNG hiệu chỉnh điều hòa thì má lệch ≈ 28 mức
        val bw = 40; val bh = 40
        val inside = BooleanArray(bw * bh) { true }
        val diff = FloatArray(3 * bw * bh) { -28f }
        val h = BestTake.harmonicOffset(diff, inside, bw, bh)
        assertEquals(-28f, h[3 * (20 * bw + 20)], 0.6f)
    }

    @Test fun applyFaceRefusesWhatItCannotAlign() {
        val a = Face(120f, 150f, 55f)
        val base = scene(a, Face(280f, 150f, 55f))
        val keep = base.copyOf()
        val lm = fakeLm(a, W, H)
        // khác tỉ lệ quá nhiều
        assertFalse(BestTake.applyFace(keep, W, H, base, fakeLm(Face(120f, 150f, 150f), W, H), lm))
        // thiếu điểm mốc
        assertFalse(BestTake.applyFace(keep, W, H, base, FloatArray(10), lm))
        assertFalse(BestTake.applyFace(keep, W, H, base, lm, FloatArray(10)))
        // kích thước ảnh nguồn sai
        assertFalse(BestTake.applyFace(keep, W, H, IntArray(5), lm, lm))
        assertTrue(keep.contentEquals(base))
    }

    @Test fun applyFaceWithIdenticalFramesChangesNothing() {
        val a = Face(120f, 150f, 55f, smile = 0.4f)
        val base = scene(a, Face(280f, 150f, 55f))
        val out = base.copyOf()
        assertTrue(BestTake.applyFace(out, W, H, base, fakeLm(a, W, H), fakeLm(a, W, H)))
        var worst = 0
        for (i in base.indices) worst = max(worst, abs((base[i] shr 8 and 255) - (out[i] shr 8 and 255)))
        assertTrue("sai khác $worst", worst <= 2)                           // chỉ sai số làm tròn nội suy
    }

    @Test fun applyFaceHandlesAFaceCutByTheImageBorder() {
        val a0 = Face(20f, 150f, 55f, earR = 0.04f, earL = 0.04f)        // mặt cắt ở mép trái ảnh
        val a1 = Face(20f, 150f, 55f)
        val base = render(W, H, listOf(a0), 0, 0)
        val src = render(W, H, listOf(a1), 0, 0)
        val out = base.copyOf()
        assertTrue(BestTake.applyFace(out, W, H, src, fakeLm(a1, W, H), fakeLm(a0, W, H)))
        // không ném lỗi, ảnh vẫn hợp lệ (alpha giữ 255)
        for (p in out) assertEquals(255, p ushr 24)
    }

    @Test fun fullPipelineOnTwoPeopleAndThreeFrames() {
        // người A nhắm mắt ở ảnh gốc, người B nhắm mắt ở khung 1 (không nhắm ở gốc / khung 2)
        val a0 = Face(120f, 150f, 55f, earR = 0.04f, earL = 0.04f, smile = 0.3f)
        val b0 = Face(280f, 150f, 55f, smile = 0.6f)
        val base = scene(a0, b0)
        val f1 = scene(Face(120f, 150f, 55f, smile = 0.8f), Face(280f, 150f, 55f, earR = 0.04f, earL = 0.04f), 8, -5)
        val f2 = scene(Face(120f, 150f, 55f, smile = 0.2f), Face(280f, 150f, 55f, smile = 0.65f), -6, 4)
        // "bộ phát hiện" = điểm mốc đúng của từng khung (đã dịch theo nội dung)
        fun lms(faces: List<Face>, sx: Int, sy: Int) = faces.map { fakeLm(Face(it.cx + sx, it.cy + sy, it.scale, it.earR, it.earL, it.smile, it.open, it.yaw), W, H) }
        val frames = ArrayList<BestTake.FaceFrame>()
        frames.add(BestTake.FaceFrame(lms(listOf(a0, b0), 0, 0), floatArrayOf(100f, 100f), 0f, 0f))
        val tb = BestTake.thumb(base, W, H)
        for ((px, spec) in listOf(f1 to Triple(listOf(Face(120f, 150f, 55f, smile = 0.8f), Face(280f, 150f, 55f, earR = 0.04f, earL = 0.04f)), 8, -5),
            f2 to Triple(listOf(Face(120f, 150f, 55f, smile = 0.2f), Face(280f, 150f, 55f, smile = 0.65f)), -6, 4))) {
            val sh = BestTake.alignShift(tb, BestTake.thumb(px, W, H), W, H)
            frames.add(BestTake.FaceFrame(lms(spec.first, spec.second, spec.third), floatArrayOf(100f, 100f), sh[0], sh[1]))
        }
        val picks = BestTake.plan(frames, W, H)
        assertEquals(1, picks[0].frame)      // A lấy từ khung 1 (mắt mở, cười)
        assertEquals(0, picks[1].frame)      // B: gốc đã tốt (khung 2 hơn quá ít)
        val out = base.copyOf()
        val srcs = listOf(base, f1, f2)
        for (p in picks) if (p.changed) assertTrue(BestTake.applyFace(out, W, H, srcs[p.frame], frames[p.frame].lm[p.frameFace], frames[0].lm[p.face]))
        val ex = (120f - 0.42f * 55f).toInt(); val ey = (150f - 0.25f * 55f).toInt()
        assertTrue(darkCount(out, W, ex, ey, 14, 8) > 2 * darkCount(base, W, ex, ey, 14, 8))
        // B nguyên vẹn
        val bx = BestTake.faceBox(frames[0].lm[1], W, H, 2)!!
        for (y in bx[1] until bx[3]) for (x in bx[0] until bx[2]) assertEquals(base[y * W + x], out[y * W + x])
    }
}
