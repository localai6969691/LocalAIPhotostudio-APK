package com.aiphoto.studio

import com.aiphoto.studio.engine.Monetization
import com.aiphoto.studio.engine.ProxyBackend
import com.aiphoto.studio.engine.TeamText
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * R23: chế độ DÙNG THỬ MIỄN PHÍ phía app. Dữ liệu mẫu là phản hồi THẬT chụp từ backend/server.py chạy với OPEN_BETA=1, BETA_DAILY_LIMIT=2
 * (đã đủ 2 lượt rồi bị 429), nên test giữ cho hai phía khớp nhau.
 */
class R23BetaTest {
    private val ACCOUNT_BETA = """{"plan": "free", "plan_until": 0, "credits": 2, "credits_personal": 2, "credits_team": 0, "limits": {"high_quality": true, "watermark": false}, "open_beta": true, "server_ai": true, "usage_today": 2, "daily_limit": 2, "subscription": null, "team": null}"""
    /** Mặc định của máy chủ dùng thử: chủ app KHÔNG trả tiền AI (BETA_OWNER_PAYS=0) -> server_ai=false, không có trần. */
    private val ACCOUNT_BYOK = """{"plan": "free", "plan_until": 0, "credits": 2, "credits_personal": 2, "credits_team": 0, "limits": {"high_quality": true, "watermark": false}, "open_beta": true, "server_ai": false, "usage_today": 0, "daily_limit": 0, "subscription": null, "team": null}"""
    private val ERR_403_BYOK = """Máy chủ trả mã 403: {"error": "b\u1ea3n d\u00f9ng th\u1eed mi\u1ec5n ph\u00ed kh\u00f4ng d\u00f9ng kh\u00f3a AI c\u1ee7a m\u00e1y ch\u1ee7: h\u00e3y nh\u1eadp kh\u00f3a AI c\u1ee7a b\u1ea1n trong C\u00e0i \u0111\u1eb7t (m\u1ee5c T\u1ea1o \u1ea3nh) ho\u1eb7c d\u00f9ng model ch\u1ea1y tr\u00ean m\u00e1y", "code": "byok_required", "credits": 2}"""
    /** Máy chủ R22 trở về trước: chưa có open_beta/usage_today/daily_limit. */
    private val ACCOUNT_OLD = """{"plan": "free", "plan_until": 0, "credits": 2, "credits_personal": 2, "credits_team": 0, "limits": {"high_quality": false, "watermark": true}, "subscription": null, "team": null}"""
    private val ERR_429 = """Máy chủ trả mã 429: {"error": "đã đạt giới hạn dùng thử trong ngày, mai dùng tiếp nhé", "code": "beta_daily_limit", "credits": 2}"""

    private val ERR_429_GLOBAL = """Máy chủ trả mã 429: {"error": "m\u00e1y ch\u1ee7 d\u00f9ng th\u1eed \u0111\u00e3 h\u1ebft l\u01b0\u1ee3t h\u00f4m nay, mai th\u1eed l\u1ea1i nh\u00e9", "code": "beta_global_limit", "credits": 2}"""

    // ------------------------------------------------------------ bản giao cho tester
    @Test fun deliveredBuildIsFreeForTesters() {
        // Nếu đổi ENABLED thành true (bán thật) thì test này đỏ để buộc phải nhìn lại: nhớ đặt OPEN_BETA=0 ở máy chủ.
        assertFalse("Bản giao cho tester phải miễn phí (Monetization.ENABLED=false)", Monetization.ENABLED)
        assertFalse(Monetization.showPaidUi())
        assertFalse(Monetization.needsWatermark(proxyConfigured = true, isPro = false))
    }

    @Test fun noWatermarkWhileFreeEvenOnFreePlanWithServer() {
        for (proxy in listOf(false, true)) for (pro in listOf(false, true)) {
            assertFalse("proxy=$proxy pro=$pro", Monetization.needsWatermark(proxy, pro, enabled = false))
        }
    }

    @Test fun watermarkRulesStillWorkWhenMonetizationIsSwitchedOn() {
        // module tính phí để đó: bật lại thì quy tắc cũ chạy y nguyên
        assertTrue(Monetization.needsWatermark(proxyConfigured = true, isPro = false, enabled = true))
        assertFalse(Monetization.needsWatermark(proxyConfigured = true, isPro = true, enabled = true))
        assertFalse("chế độ cá nhân (không máy chủ) không bao giờ đóng dấu", Monetization.needsWatermark(proxyConfigured = false, isPro = false, enabled = true))
        assertTrue(Monetization.showPaidUi(enabled = true))
    }

    // ------------------------------------------------------------ chữ hiển thị
    @Test fun betaTextNeverMentionsMoneyOrPlans() {
        val texts = listOf(
            Monetization.agentChipLabel(isPro = false), Monetization.agentChipLabel(isPro = true),
            Monetization.agentModeStatus(on = true), Monetization.agentModeStatus(on = false),
            Monetization.serverSectionTitle(), Monetization.refreshButtonLabel(), Monetization.registeredMessage(7),
            Monetization.betaLine(-1, 0)!!, Monetization.betaLine(3, 100)!!, Monetization.betaLine(3, 0)!!,
            Monetization.betaLine(-1, 0, serverAi = false)!!, Monetization.agentChipLabel(isPro = false, serverAi = false),
            Monetization.agentModeStatus(on = true, serverAi = false), Monetization.byokHint()!!
        )
        for (t in texts) {
            val low = t.lowercase()
            assertFalse("\"$t\" nhắc tới credits", "credit" in low)
            assertFalse("\"$t\" nhắc tới gói Pro/Free", Regex("""\b(pro|free)\b""").containsMatchIn(low))   // \b: "prompt" không phải "Pro"
            assertFalse("\"$t\" nhắc tới watermark", "watermark" in low)
        }
        assertFalse("không lộ số dư credits khi đăng ký", "7" in Monetization.registeredMessage(7))
    }

    @Test fun commercialTextKeptWhenEnabled() {
        assertEquals("Agent AI nhìn ảnh (Pro: miễn phí)", Monetization.agentChipLabel(true, enabled = true))
        assertEquals("Agent AI nhìn ảnh (1 credit/lần)", Monetization.agentChipLabel(false, enabled = true))
        assertTrue("credits" in Monetization.serverSectionTitle(enabled = true))
        assertEquals("Cập nhật credits", Monetization.refreshButtonLabel(enabled = true))
        assertEquals("Đã đăng ký. Credits: 7", Monetization.registeredMessage(7, enabled = true))
        assertTrue("1 credit/lần" in Monetization.agentModeStatus(true, enabled = true))
        assertEquals("Agent AI tắt.", Monetization.agentModeStatus(false, enabled = true))
        assertEquals("Agent AI tắt.", Monetization.agentModeStatus(false))
    }

    @Test fun betaLineShowsUsageAgainstTheDailyCap() {
        assertEquals("Đang dùng thử miễn phí · hôm nay đã dùng 3/100 lượt AI trên máy chủ.", Monetization.betaLine(3, 100))
        assertEquals("Đang dùng thử miễn phí · hôm nay đã dùng 0/100 lượt AI trên máy chủ.", Monetization.betaLine(0, 100))
        assertEquals("Đang dùng thử miễn phí · hôm nay đã dùng 5 lượt (không giới hạn) AI trên máy chủ.", Monetization.betaLine(5, 0))
        val unknown = Monetization.betaLine(-1, 0)!!                 // chưa hỏi máy chủ / máy chủ cũ: không bịa số
        assertTrue("không bịa số lượt", unknown.none { it.isDigit() })
        assertNull("đang bán thật thì không hiện dòng dùng thử", Monetization.betaLine(3, 100, enabled = true))
    }

    // ------------------------------------------------------------ chủ app KHÔNG trả tiền AI (mặc định): tester dùng khóa của mình / model trên máy
    @Test fun proxyAiIsUsedOnlyWhenRegisteredAndServerOffersAi() {
        for (url in listOf("", "https://api.example.com")) for (tok in listOf("", "t0k")) for (srv in listOf(false, true)) {
            val want = url.isNotEmpty() && tok.isNotEmpty() && srv
            assertEquals("url='$url' token='$tok' serverAi=$srv", want, Monetization.proxyAiUsable(url, tok, srv))
        }
    }

    @Test fun byokAccountSaysServerOffersNoAiAndNoQuota() {
        val a = ProxyBackend.parseAccount(JSONObject(ACCOUNT_BYOK))
        assertFalse("máy chủ không cung cấp AI cho tester", a.serverAi)
        assertTrue(a.openBeta); assertEquals(0, a.dailyLimit); assertEquals(0, a.usageToday)
        assertFalse(a.watermark)
        assertTrue("máy chủ trả tiền (BETA_OWNER_PAYS=1) thì có AI", ProxyBackend.parseAccount(JSONObject(ACCOUNT_BETA)).serverAi)
        assertTrue("máy chủ cũ chưa có trường server_ai: coi như có AI (chạy y như trước)", ProxyBackend.parseAccount(JSONObject(ACCOUNT_OLD)).serverAi)
    }

    @Test fun byokTextsGuideTheTesterToPrepareTheirOwnKeyOrModel() {
        val line = Monetization.betaLine(5, 100, serverAi = false)!!
        assertTrue("nói rõ máy chủ không dùng khóa của chủ app", "không dùng khóa AI của chủ app" in line)
        assertTrue("chỉ cách tự chuẩn bị", "khóa của chính bạn" in line && "model chạy trên máy" in line)
        assertTrue("không hiện số lượt vô nghĩa khi máy chủ không cung cấp AI", line.none { it.isDigit() })
        assertTrue("Agent: nói rõ cần model trên máy", "cần model" in Monetization.agentChipLabel(false, serverAi = false))
        assertTrue("Agent: không hứa AI máy chủ", "máy chủ" !in Monetization.agentModeStatus(true, serverAi = false))
        assertTrue("gợi ý khóa: gọi thẳng tới Google, không qua máy chủ chủ app", "gọi thẳng tới Google" in Monetization.byokHint()!!)
        assertNull("bán thật: không hiện gợi ý dùng thử", Monetization.byokHint(enabled = true))
        // bán thật thì serverAi không đổi chữ
        assertEquals("Agent AI nhìn ảnh (1 credit/lần)", Monetization.agentChipLabel(false, enabled = true, serverAi = false))
        assertNull(Monetization.betaLine(5, 100, enabled = true, serverAi = false))
    }

    @Test fun byokRejectionReadsAsAGuidingSentence() {
        val m = TeamText.friendlyError(ERR_403_BYOK)
        assertTrue(m, "khóa AI của bạn" in m && "model chạy trên máy" in m)
    }

    // ------------------------------------------------------------ đọc phản hồi máy chủ
    @Test fun betaAccountIsParsedAndStaysHonestAboutPlan() {
        val a = ProxyBackend.parseAccount(JSONObject(ACCOUNT_BETA))
        assertTrue(a.openBeta); assertEquals(2, a.usageToday); assertEquals(2, a.dailyLimit)
        assertFalse(a.watermark); assertTrue(a.highQuality)
        assertFalse("không giả làm Pro", a.isPro); assertEquals("free", a.plan)
    }

    @Test fun oldServerWithoutBetaFieldsStillParses() {
        val a = ProxyBackend.parseAccount(JSONObject(ACCOUNT_OLD))
        assertFalse(a.openBeta); assertEquals(-1, a.usageToday); assertEquals(0, a.dailyLimit)
        assertTrue(a.watermark); assertFalse(a.highQuality)
        assertNull(a.team)
    }

    @Test fun serverWideCapErrorReadsAsAFriendlySentenceDifferentFromPersonalCap() {
        val g = TeamText.friendlyError(ERR_429_GLOBAL)
        assertEquals("máy chủ dùng thử đã hết lượt hôm nay, mai thử lại nhé", g)
        assertTrue("khác thông báo trần cá nhân để người dùng biết không phải lỗi của mình", g != TeamText.friendlyError(ERR_429))
    }

    @Test fun dailyCapErrorReadsAsAFriendlySentence() {
        val m = TeamText.friendlyError(ERR_429)
        assertEquals("đã đạt giới hạn dùng thử trong ngày, mai dùng tiếp nhé", m)
        assertNotNull(m)
    }
}
