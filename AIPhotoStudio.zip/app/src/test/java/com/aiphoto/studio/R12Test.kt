package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.ClipLogic
import com.aiphoto.studio.doc.HistoryLabels
import com.aiphoto.studio.doc.Layer
import com.aiphoto.studio.doc.OverlayLayer
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.ProjectCodec
import com.aiphoto.studio.doc.RecipeCodec
import com.aiphoto.studio.engine.CubeLut
import com.aiphoto.studio.engine.PolygonFill
import com.aiphoto.studio.engine.Pt
import com.aiphoto.studio.engine.QuickSelect
import com.aiphoto.studio.engine.SkyFx
import com.aiphoto.studio.engine.SkyStore
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.sanitized
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Kiểm thử R12: lasso (mặt nạ vector), Quick Selection, và các mục bổ sung sau R11. */
class R12Test {

    private fun argb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun circle(cx: Float, cy: Float, r: Float, n: Int) =
        List(n) { i -> Pt(cx + r * cos(2 * PI * i / n).toFloat(), cy + r * sin(2 * PI * i / n).toFloat()) }

    // ------------------------------------------------------------------ Polygon / Lasso
    @Test fun polygonSquareCoverage() {
        val w = 200; val h = 100
        val m = PolygonFill.rasterize(listOf(Pt(0.25f, 0.25f), Pt(0.75f, 0.25f), Pt(0.75f, 0.75f), Pt(0.25f, 0.75f)), w, h)
        assertEquals(0.25f, m.average().toFloat(), 0.002f)
        assertEquals(1f, m[50 * w + 100], 0f)
        assertEquals(0f, m[5 * w + 5], 0f)
        assertTrue(m.all { it in 0f..1f })
    }

    @Test fun polygonCircleMatchesShoelaceArea() {
        val c = circle(0.5f, 0.5f, 0.3f, 90)
        val m = PolygonFill.rasterize(c, 200, 100)
        assertEquals(PolygonFill.area(c), m.average().toFloat(), 0.002f)
    }

    @Test fun polygonEvenOddStarHasEmptyCenter() {
        val star = List(5) { k ->
            val a = 2 * PI * k * 2 / 5
            Pt(0.5f + 0.4f * sin(a).toFloat(), 0.5f - 0.4f * cos(a).toFloat())
        }
        val w = 400
        val m = PolygonFill.rasterize(star, w, 400)
        assertEquals(0f, m[200 * w + 200], 0f)
        val tipRow = (0.5f * 400 - 0.38f * 400).toInt() + 6
        assertTrue(m[tipRow * w + 200] > 0.9f)   // mũi cánh sao được tô
    }

    @Test fun polygonDegenerateAndOutOfRange() {
        assertTrue(PolygonFill.rasterize(listOf(Pt(0.1f, 0.1f), Pt(0.9f, 0.9f)), 50, 50).all { it == 0f })
        assertTrue(PolygonFill.rasterize(listOf(Pt(0.1f, 0.1f), Pt(0.5f, 0.5f), Pt(0.9f, 0.9f)), 50, 50).all { it == 0f })
        val full = PolygonFill.rasterize(listOf(Pt(-1f, -1f), Pt(2f, -1f), Pt(2f, 2f), Pt(-1f, 2f)), 40, 30)
        assertTrue(full.all { it == 1f })
        assertEquals(1, PolygonFill.rasterize(listOf(Pt(0f, 0f), Pt(1f, 0f), Pt(1f, 1f)), 1, 1).size)
    }

    @Test fun polygonSimplifyAndFromStroke() {
        val line = List(100) { Pt(it / 99f, 0.5f) }
        assertEquals(2, PolygonFill.simplify(line, 0.004f).size)
        val ring = circle(0.5f, 0.5f, 0.2f, 300)
        val poly = PolygonFill.fromStroke(ring)
        assertNotNull(poly)
        assertTrue(poly!!.size in 3..80)
        assertEquals((PI * 0.04).toFloat(), PolygonFill.area(poly), (PI * 0.04 * 0.06).toFloat())
        assertNull(PolygonFill.fromStroke(listOf(Pt(0.5f, 0.5f), Pt(0.501f, 0.5f), Pt(0.5f, 0.501f))))
        assertNull(PolygonFill.fromStroke(listOf(Pt(0.1f, 0.1f), Pt(0.5f, 0.5f), Pt(0.9f, 0.9f))))
        assertNull(PolygonFill.fromStroke(listOf(Pt(0.1f, 0.1f), Pt(0.2f, 0.2f))))
        val closed = PolygonFill.fromStroke(listOf(Pt(0.2f, 0.2f), Pt(0.2f, 0.2f), Pt(0.8f, 0.2f), Pt(0.8f, 0.8f), Pt(0.2f, 0.8f), Pt(0.2f, 0.2f)))
        assertEquals(4, closed!!.size)
    }

    @Test fun polygonMaskSurvivesRecipeAndProjectRoundTrip() {
        val pts = listOf(Pt(0.1f, 0.2f), Pt(0.7f, 0.15f), Pt(0.8f, 0.8f), Pt(0.25f, 0.9f))
        val layer = AdjustmentLayer(4L, "Lasso", listOf(EditOp(OpType.BRIGHTNESS, 0.3f)), mask = LayerMask(MaskSpec.Polygon(pts), feather = 0.01f), kind = "local")
        assertTrue(RecipeCodec.portable(layer))
        val viaRecipe = RecipeCodec.decode(RecipeCodec.encode(listOf(layer)))[0].mask!!.spec as MaskSpec.Polygon
        assertEquals(pts, viaRecipe.pts)
        val json = ProjectCodec.encode(
            ProjectCodec.Meta(1L, 100, 100, "bg.png", 10L), listOf(layer),
            patchFile = { error("x") }, maskFile = { _, _ -> error("x") }, imageFile = { error("x") }
        )
        val dec = ProjectCodec.decode(org.json.JSONObject(json.toString()), 100, 100, { null }, { _, _, _ -> null })
        assertEquals(0, dec.skipped)
        assertEquals(pts, ((dec.layers[0] as AdjustmentLayer).mask!!.spec as MaskSpec.Polygon).pts)
    }

    @Test fun polygonRecipeRejectsAbsurdData() {
        val ok = RecipeCodec.encode(listOf(AdjustmentLayer(1L, "L", emptyList(), mask = LayerMask(MaskSpec.Polygon(circle(0.5f, 0.5f, 0.2f, 8))))))
        val o = ok.getJSONObject(0).getJSONObject("mask")
        o.put("pts", org.json.JSONArray(listOf(0.1, 0.1, 0.5, 0.5)))                       // chỉ 2 điểm
        assertTrue("mặt nạ hỏng phải bỏ cả lớp, không áp lên toàn ảnh", RecipeCodec.decode(ok).isEmpty())
        o.put("pts", org.json.JSONArray(listOf(0.1, 0.1, 0.5, 0.5, 0.9)))                  // lẻ số
        assertTrue(RecipeCodec.decode(ok).isEmpty())
    }

    // ------------------------------------------------------------------ Quick Selection
    private fun scene(w: Int, h: Int): Triple<IntArray, BooleanArray, BooleanArray> {
        val rnd = java.util.Random(8)
        val obj = BooleanArray(w * h)
        val far = BooleanArray(w * h)
        val px = IntArray(w * h) { i ->
            val x = i % w; val y = i / w
            val inObj = (x - 50) * (x - 50) + (y - 45) * (y - 45) <= 25 * 25
            val inFar = (x - 140) * (x - 140) + (y - 60) * (y - 60) <= 18 * 18
            obj[i] = inObj; far[i] = inFar
            fun n(s: Double) = (rnd.nextGaussian() * s).toInt()
            when {
                inObj -> argb((235 + n(5.0)).coerceIn(0, 255), (120 + n(5.0)).coerceIn(0, 255), (30 + n(5.0)).coerceIn(0, 255))
                inFar -> argb((235 + n(5.0)).coerceIn(0, 255), (120 + n(5.0)).coerceIn(0, 255), (30 + n(5.0)).coerceIn(0, 255))
                else -> argb((90 + n(6.0)).coerceIn(0, 255), (110 + n(6.0)).coerceIn(0, 255), (130 + n(6.0)).coerceIn(0, 255))
            }
        }
        return Triple(px, obj, far)
    }

    @Test fun quickSelectGrowsOverObjectButNotOverDisconnectedTwin() {
        val w = 180; val h = 100
        val (px, obj, far) = scene(w, h)
        val seeds = ByteArray(w * h)
        for (x in 40..60) for (y in 44..46) seeds[y * w + x] = 255.toByte()
        val sel = QuickSelect.select(px, w, h, seeds, 0.5f)
        var inter = 0; var uni = 0; var farHit = 0
        for (i in 0 until w * h) {
            val s = sel[i].toInt() != 0
            if (s && obj[i]) inter++
            if (s || obj[i]) uni++
            if (s && far[i]) farHit++
        }
        assertTrue("IoU thấp: ${inter.toFloat() / uni}", inter.toFloat() / uni >= 0.9f)
        assertEquals("vật thứ hai bị chọn nhầm", 0, farHit)
        assertTrue(seeds.indices.all { seeds[it].toInt() == 0 || sel[it].toInt() != 0 })
    }

    @Test fun quickSelectToleranceMonotoneAndGuards() {
        val w = 180; val h = 100
        val (px, _, _) = scene(w, h)
        val seeds = ByteArray(w * h)
        for (x in 40..60) for (y in 44..46) seeds[y * w + x] = 255.toByte()
        val lo = QuickSelect.select(px, w, h, seeds, 0.1f).count { it.toInt() != 0 }
        val hi = QuickSelect.select(px, w, h, seeds, 0.9f).count { it.toInt() != 0 }
        assertTrue(lo <= hi)
        assertEquals(0, QuickSelect.select(px, w, h, ByteArray(w * h), 0.5f).count { it.toInt() != 0 })
        assertEquals(0, QuickSelect.select(IntArray(4), 2, 2, ByteArray(4) { 1 }, 0.5f).count { it.toInt() != 0 })
        assertEquals(0, QuickSelect.select(px, w, h, ByteArray(10), 0.5f).count { it.toInt() != 0 })   // kích thước hạt giống sai
    }

    @Test fun quickSelectOnBackgroundDoesNotSwallowLargeObject() {
        val w = 180; val h = 100
        val (px, obj, _) = scene(w, h)
        val seeds = ByteArray(w * h)
        for (x in 5..60) for (y in 5..7) seeds[y * w + x] = 255.toByte()
        val sel = QuickSelect.select(px, w, h, seeds, 0.5f)
        val objHit = (0 until w * h).count { obj[it] && sel[it].toInt() != 0 }
        assertEquals("điền lỗ không được nuốt vật lớn nằm trong nền", 0, objHit)
    }

    // ------------------------------------------------------------------ Clipping mask
    private fun adj(id: Long, clip: Boolean = false) = AdjustmentLayer(id, "L$id", listOf(EditOp(OpType.BRIGHTNESS, 0.1f)), clip = clip)

    @Test fun clipBaseIsNearestUnclippedLayerBelow() {
        val stack = listOf<Layer>(adj(1), adj(2, clip = true), adj(3, clip = true))
        assertEquals(0, ClipLogic.baseIndex(stack, 1))
        assertEquals(0, ClipLogic.baseIndex(stack, 2))                    // hai lớp bị cắt liên tiếp dùng chung một gốc
        val mixed = listOf<Layer>(adj(1), adj(2), adj(3, clip = true))
        assertEquals(1, ClipLogic.baseIndex(mixed, 2))
        assertEquals(-1, ClipLogic.baseIndex(mixed, 1))                   // lớp không bật clip
        assertEquals(-1, ClipLogic.baseIndex(listOf<Layer>(adj(1, clip = true)), 0))   // không có lớp nào bên dưới
        assertEquals(-1, ClipLogic.baseIndex(stack, 7))
        assertEquals(-1, ClipLogic.baseIndex(stack, -1))
    }

    @Test fun clipFlagIsKeptByUpdateAndProject() {
        val l = adj(5).update(clip = true)
        assertTrue(l.clip)
        assertEquals(0.4f, l.update(opacity = 0.4f).opacity, 1e-6f)
        assertTrue(l.update(opacity = 0.4f).clip)                         // đổi thuộc tính khác không làm mất clip
        assertFalse(l.update(clip = false).clip)
        val json = ProjectCodec.encode(
            ProjectCodec.Meta(1L, 10, 10, "bg.png", 9L), listOf(adj(1), l),
            patchFile = { error("x") }, maskFile = { _, _ -> error("x") }, imageFile = { error("x") }
        )
        val dec = ProjectCodec.decode(org.json.JSONObject(json.toString()), 10, 10, { null }, { _, _, _ -> null })
        assertEquals(listOf(false, true), dec.layers.map { it.clip })
    }

    /**
     * Ảnh nhiễu độc lập từng điểm (KHÔNG có trời). Lưu ý: công thức cũ `(it * 37) % 160` với bề rộng 160 cho ra các cột hằng theo y
     * (37·160 ≡ 0 mod 160) tức là ảnh sọc dọc, trơn theo chiều đứng - thuật toán nhận đúng là có trời; nên dùng bộ sinh số ngẫu nhiên thật.
     */
    private fun noiseImage(w: Int, h: Int): IntArray {
        val rnd = java.util.Random(7)
        return IntArray(w * h) { argb(40 + rnd.nextInt(160), 40 + rnd.nextInt(160), 40 + rnd.nextInt(160)) }
    }

    // ------------------------------------------------------------------ Ảnh trời của người dùng
    private fun skyScene(w: Int, h: Int, skyRows: Int): IntArray {
        val rnd = java.util.Random(21)
        return IntArray(w * h) { i ->
            val y = i / w
            if (y < skyRows) {
                val t = y / skyRows.toFloat()
                argb((30 + 140 * t).toInt(), (90 + 115 * t).toInt(), (200 + 40 * t).toInt())
            } else argb(
                (50 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255),
                (120 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255),
                (45 + rnd.nextGaussian() * 40).toInt().coerceIn(0, 255)
            )
        }
    }

    @Test fun skyStoreNameAndArgValidation() {
        assertEquals("abc.jpg", SkyStore.nameFromArg("img:abc.jpg"))
        assertEquals("my sky_1.jpg", SkyStore.nameFromArg("img:my sky_1.jpg"))
        assertNull(SkyStore.nameFromArg("img:../x.jpg"))
        assertNull(SkyStore.nameFromArg("img:a.png"))
        assertNull(SkyStore.nameFromArg("blue"))
        assertNull(SkyStore.nameFromArg(null))
        assertEquals("img:abc.jpg", SkyStore.arg("abc.jpg"))
        assertEquals("a_b_.jpg", SkyStore.sanitizeName("a/b?.PNG"))
        assertEquals("sky.jpg", SkyStore.sanitizeName("   "))
        assertTrue(SkyStore.sanitizeName("x".repeat(100)).length <= 40)
        assertTrue(SkyStore.isValidName(SkyStore.sanitizeName("x".repeat(100))))
    }

    @Test fun skyOpAcceptsOwnImageArgOnly() {
        assertEquals("img:my sky.jpg", EditOp(OpType.SKY_REPLACE, 1f, "img:my sky.jpg").sanitized()!!.arg)
        assertEquals("blue", EditOp(OpType.SKY_REPLACE, 1f, "img:../../etc.jpg").sanitized()!!.arg)
        assertEquals("sunset", EditOp(OpType.SKY_REPLACE, 1f, "sunset").sanitized()!!.arg)
    }

    @Test fun fitCoverIsCenteredAndTopAnchored() {
        // ảnh trời 200x100: cột xanh lục ở giữa; đỉnh đỏ → dưới vàng
        val sw = 200; val sh = 100
        val src = IntArray(sw * sh) { i -> val y = i / sw; val x = i % sw; if (x in 99..100) argb(0, 255, 0) else argb(220, 60 + y, 80) }
        val w = 120; val h = 80
        val out = SkyFx.fitCover(src, sw, sh, w, h, 49)               // vùng trời cao 50
        var markerX = -1
        for (x in 0 until w) if (((out[10 * w + x] shr 8) and 255) > 150) { markerX = x; break }   // cột hẹp sau khi thu nhỏ chỉ còn G≈196
        assertTrue("cột đánh dấu lệch tâm: $markerX", abs(markerX - w / 2) <= 3)
        assertTrue("không căn mép trên", abs(((out[0] shr 16) and 255) - 220) <= 3 && ((out[0] shr 8) and 255) < 90)
        assertTrue(out.all { (it ushr 24) == 255 })
        assertEquals(w * h, out.size)
    }

    @Test fun replaceWithImageKeepsGroundAndGuards() {
        val w = 160; val h = 120
        val px = skyScene(w, h, 55)
        val src = IntArray(100 * 40) { argb(220, 60, 80) }
        val out = SkyFx.replaceWithImage(px, w, h, src, 100, 40, 1f)
        var skyOk = 0; var skyTotal = 0; var groundMax = 0
        for (y in 0 until h) for (x in 0 until w) {
            val a = px[y * w + x]; val b = out[y * w + x]
            if (y < 40) { skyTotal++; if (abs(((b shr 16) and 255) - 220) <= 4 && abs(((b shr 8) and 255) - 60) <= 4) skyOk++ }
            else if (y > 66) groundMax = maxOf(groundMax, abs(((a shr 16) and 255) - ((b shr 16) and 255)) + abs(((a shr 8) and 255) - ((b shr 8) and 255)) + abs((a and 255) - (b and 255)))
        }
        assertTrue("trời chưa thay đủ: $skyOk/$skyTotal", skyOk > skyTotal * 0.95)
        assertTrue("đất bị đổi: $groundMax", groundMax <= 6)
        assertTrue(SkyFx.replaceWithImage(px, w, h, src, 100, 40, 0f) === px)
        assertTrue(SkyFx.replaceWithImage(px, w, h, IntArray(1), 1, 1, 1f) === px)               // ảnh trời 1x1
        assertTrue(SkyFx.replaceWithImage(px, w, h, IntArray(5), 100, 40, 1f) === px)            // kích thước không khớp
        val noSky = noiseImage(w, h)
        assertTrue(SkyFx.replaceWithImage(noSky, w, h, src, 100, 40, 1f) === noSky)              // ảnh không có trời
    }

    // ------------------------------------------------------------------ Kéo / chụm / xoay lớp phủ
    @Test fun overlayTransformPanZoomRotate() {
        val l = OverlayLayer(1L, "T", "text", text = "x", cx = 0.5f, cy = 0.5f, size = 0.1f, rotation = 0f)
        val a = l.transformed(0.1f, -0.2f, 2f, 30f)
        assertEquals(0.6f, a.cx, 1e-6f); assertEquals(0.3f, a.cy, 1e-6f)
        assertEquals(0.2f, a.size, 1e-6f); assertEquals(30f, a.rotation, 1e-4f)
        assertEquals(0.5f, l.transformed(0f, 0f, 100f, 0f).size, 1e-6f)          // chụm quá tay bị kẹp ×5
        assertEquals(0.1f, l.transformed(0f, 0f, 0f, 0f).size, 1e-6f)            // zoom ≤ 0 bị bỏ qua
        assertEquals(0.1f, l.transformed(0f, 0f, Float.NaN, 0f).size, 1e-6f)
        val nan = l.transformed(Float.NaN, Float.POSITIVE_INFINITY, 1f, Float.NaN)
        assertEquals(0.5f, nan.cx, 1e-6f); assertEquals(0.5f, nan.cy, 1e-6f); assertEquals(0f, nan.rotation, 1e-6f)
    }

    @Test fun overlayRotationWrapsAndPositionClamps() {
        val base = OverlayLayer(1L, "T", "text", text = "x")
        assertEquals(-170f, base.copy(rotation = 170f).transformed(0f, 0f, 1f, 20f).rotation, 1e-3f)
        assertEquals(170f, base.copy(rotation = -170f).transformed(0f, 0f, 1f, -20f).rotation, 1e-3f)
        assertEquals(180f, base.transformed(0f, 0f, 1f, 180f).rotation, 1e-3f)       // −180 chuẩn hóa thành +180
        assertEquals(10f, base.copy(rotation = 350f).transformed(0f, 0f, 1f, 20f).rotation, 1e-3f)
        assertEquals(1.5f, base.copy(cx = 1.4f).transformed(0.5f, 0f, 1f, 0f).cx, 1e-6f)
        assertEquals(-0.5f, base.copy(cy = -0.4f).transformed(0f, -0.5f, 1f, 0f).cy, 1e-6f)
        assertEquals(2f, base.copy(size = 1.9f).transformed(0f, 0f, 5f, 0f).size, 1e-6f)
        val big = base.copy(size = 0.02f).transformed(0f, 0f, 0.2f, 0f)
        assertEquals(0.01f, big.size, 1e-6f)                                          // không nhỏ hơn mức tối thiểu
        // chuỗi cử chỉ nhỏ liên tiếp tương đương một cử chỉ lớn
        var chain = base
        repeat(10) { chain = chain.transformed(0.01f, 0.01f, 1.05f, 3f) }
        assertEquals(base.cx + 0.1f, chain.cx, 1e-4f)
        assertEquals(30f, chain.rotation, 1e-3f)
    }

    // ------------------------------------------------------------------ Lịch sử
    private fun hl(id: Long) = AdjustmentLayer(id, "L$id", listOf(EditOp(OpType.BRIGHTNESS, 0.1f)))

    @Test fun historyLabelsStructuralChanges() {
        val a = hl(1); val b = hl(2); val c = hl(3)
        assertEquals("Thêm lớp “L2”", HistoryLabels.describe(false, listOf(a), listOf(a, b)))
        assertEquals("Thêm 2 lớp", HistoryLabels.describe(false, listOf(a), listOf(a, b, c)))
        assertEquals("Xóa lớp “L1”", HistoryLabels.describe(false, listOf(a, b), listOf(b)))
        assertEquals("Xóa 2 lớp", HistoryLabels.describe(false, listOf(a, b, c), listOf(c)))
        assertEquals("Đổi thứ tự lớp", HistoryLabels.describe(false, listOf(a, b), listOf(b, a)))
        assertEquals("Không thay đổi", HistoryLabels.describe(false, listOf(a), listOf(a)))
        assertTrue(HistoryLabels.describe(true, listOf(a), listOf(a)).startsWith("Đổi ảnh nền"))
        assertTrue(HistoryLabels.describe(true, listOf(a), listOf(a, b)).let { it.startsWith("Đổi ảnh nền") && it.contains("Thêm lớp “L2”") })
        assertEquals("Thêm lớp “L1”", HistoryLabels.describe(false, emptyList(), listOf(a)))
    }

    @Test fun historyLabelsPropertyChanges() {
        val a = hl(1)
        assertEquals("Ẩn lớp “L1”", HistoryLabels.describe(false, listOf(a), listOf(a.update(visible = false))))
        assertEquals("Hiện lớp “L1”", HistoryLabels.describe(false, listOf(a.update(visible = false)), listOf(a)))
        assertEquals("Độ mờ lớp “L1”: 40%", HistoryLabels.describe(false, listOf(a), listOf(a.update(opacity = 0.4f))))
        assertTrue(HistoryLabels.describe(false, listOf(a), listOf(a.update(blend = BlendMode.SOFT_LIGHT))).contains("hòa trộn"))
        assertEquals("Cắt “L1” theo lớp dưới", HistoryLabels.describe(false, listOf(a), listOf(a.update(clip = true))))
        assertEquals("Bỏ cắt lớp “L1”", HistoryLabels.describe(false, listOf(a.update(clip = true)), listOf(a)))
        assertEquals("Sửa mặt nạ lớp “L1”", HistoryLabels.describe(false, listOf(a), listOf(a.update(mask = LayerMask(MaskSpec.Sky(0.5f))))))
        val moreBright = a.copy(ops = listOf(EditOp(OpType.BRIGHTNESS, 0.3f)))
        assertEquals("Chỉnh ${OpType.BRIGHTNESS.label}: L1", HistoryLabels.describe(false, listOf(a), listOf(moreBright)))
        val three = a.copy(ops = listOf(EditOp(OpType.BRIGHTNESS, 0.5f), EditOp(OpType.CONTRAST, 0.2f), EditOp(OpType.HIGHLIGHTS, -0.3f)))
        val desc = HistoryLabels.describe(false, listOf(a), listOf(three))
        assertTrue(desc, desc.contains(OpType.BRIGHTNESS.label) && desc.contains(OpType.CONTRAST.label) && desc.contains("…") && !desc.contains(OpType.HIGHLIGHTS.label))
        val onlyTwo = a.copy(ops = listOf(EditOp(OpType.BRIGHTNESS, 0.1f), EditOp(OpType.CONTRAST, 0.2f), EditOp(OpType.HIGHLIGHTS, -0.3f)))
        val d2 = HistoryLabels.describe(false, listOf(a), listOf(onlyTwo))
        assertTrue(d2, d2.contains(OpType.CONTRAST.label) && d2.contains(OpType.HIGHLIGHTS.label) && !d2.contains("…") && !d2.contains(OpType.BRIGHTNESS.label))
        assertEquals("Đổi tên lớp “L1” → “Mới”", HistoryLabels.describe(false, listOf(a), listOf(a.copy(name = "Mới"))))
    }

    @Test fun historyLabelsOverlayAndMultipleChanges() {
        val t = OverlayLayer(7L, "Chữ", "text", text = "a")
        assertEquals("Sửa lớp chữ “Chữ”", HistoryLabels.describe(false, listOf(t), listOf(t.copy(text = "b"))))
        assertEquals("Sửa lớp chữ “Chữ”", HistoryLabels.describe(false, listOf(t), listOf(t.copy(cx = 0.9f))))
        val a = hl(1); val b = hl(2); val c = hl(3)
        val many = HistoryLabels.describe(false, listOf(a, b, c), listOf(a.update(visible = false), b.update(visible = false), c.update(visible = false)))
        assertEquals("Ẩn lớp “L1” · Ẩn lớp “L2” …", many)
    }

    // ------------------------------------------------------------------ LUT tứ diện
    private fun cube(n: Int, f: (Float, Float, Float) -> FloatArray): String {
        val sb = StringBuilder("LUT_3D_SIZE $n\n")
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val o = f(r / (n - 1f), g / (n - 1f), b / (n - 1f))
            sb.append(String.format(java.util.Locale.US, "%.6f %.6f %.6f\n", o[0], o[1], o[2]))
        }
        return sb.toString()
    }

    @Test fun tetrahedralKeepsNeutralLutOnGrayAxis() {
        // LUT trung tính (xám → xám) nhưng các nút ngoài trục xám bị ám đỏ mạnh: tam tuyến sẽ làm dải xám ám màu, tứ diện thì không
        val lut = CubeLut.parse(cube(9) { r, g, b ->
            val v = Math.pow(((r + g + b) / 3f).toDouble(), 1.4).toFloat()
            val chroma = maxOf(r, g, b) - minOf(r, g, b)
            floatArrayOf(v + 0.35f * chroma, v, v)
        }).lut!!
        val ramp = IntArray(256) { argb(it, it, it) }
        val out = CubeLut.apply(ramp, lut, 1f)
        for (i in 0..255) {
            val r = (out[i] shr 16) and 255; val g = (out[i] shr 8) and 255; val b = out[i] and 255
            assertTrue("xám bị ám màu tại $i: ($r,$g,$b)", maxOf(r, g, b) - minOf(r, g, b) <= 1)
        }
    }

    @Test fun tetrahedralIsExactForAffineLutInAllSixAxisOrders() {
        val lut = CubeLut.parse(cube(5) { r, g, b -> floatArrayOf(0.3f * r + 0.2f * g + 0.1f * b, 0.1f * r + 0.5f * g, 0.4f * b + 0.2f * g) }).lut!!
        val rnd = java.util.Random(9)
        val px = IntArray(3000) { argb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)) }
        val out = CubeLut.apply(px, lut, 1f)
        for (i in px.indices) {
            val r = ((px[i] shr 16) and 255) / 255f; val g = ((px[i] shr 8) and 255) / 255f; val b = (px[i] and 255) / 255f
            val er = (0.3f * r + 0.2f * g + 0.1f * b) * 255f
            val eg = (0.1f * r + 0.5f * g) * 255f
            val eb = (0.4f * b + 0.2f * g) * 255f
            assertTrue("lệch tại $i", abs(((out[i] shr 16) and 255) - er) <= 1.01f && abs(((out[i] shr 8) and 255) - eg) <= 1.01f && abs((out[i] and 255) - eb) <= 1.01f)
        }
    }

    // ------------------------------------------------------------------ Tái chiếu sáng tiền cảnh khi đổi trời
    private fun meanLum(px: IntArray, y0: Int, y1: Int, w: Int): Double {
        var s = 0.0; var n = 0
        for (y in y0 until y1) for (x in 0 until w) { val p = px[y * w + x]; s += 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255); n++ }
        return s / n
    }

    @Test fun skyRelightDarkensGroundForNightAndLeavesSkyAlone() {
        val w = 160; val h = 120
        val px = skyScene(w, h, 55)
        val plain = SkyFx.replace(px, w, h, "night", 1f)
        val lit = SkyFx.replace(px, w, h, "night", 1f, 1f)
        assertTrue(SkyFx.replace(px, w, h, "night", 1f, 0f).contentEquals(plain))          // relight = 0: y hệt
        val ratio = meanLum(lit, 70, h, w) / meanLum(plain, 70, h, w)
        assertTrue("đất chưa tối đi: $ratio", ratio < 0.8)
        val m = SkyFx.mask(px, w, h)
        for (i in px.indices) if (m[i] > 0.99f) {
            val a = plain[i]; val b = lit[i]
            assertTrue("relight đụng vào trời tại $i", abs(((a shr 16) and 255) - ((b shr 16) and 255)) <= 1 &&
                abs(((a shr 8) and 255) - ((b shr 8) and 255)) <= 1 && abs((a and 255) - (b and 255)) <= 1)
        }
        // relight 0.5 nằm giữa
        val half = SkyFx.replace(px, w, h, "night", 1f, 0.5f)
        val rh = meanLum(half, 70, h, w) / meanLum(plain, 70, h, w)
        assertTrue(rh < 1.0 && rh > ratio)
        // không có trời → trả nguyên
        val noSky = noiseImage(w, h)
        assertTrue(SkyFx.replace(noSky, w, h, "night", 1f, 1f) === noSky)
    }

    @Test fun skyRelightOpAndPlanner() {
        assertTrue(OpType.SKY_RELIGHT.scalable && !OpType.SKY_RELIGHT.signed)
        assertEquals(1f, EditOp(OpType.SKY_RELIGHT, 4f).sanitized()!!.value, 1e-6f)
        assertNull(EditOp(OpType.SKY_RELIGHT, 0.001f).sanitized())
        val p = RuleBasedPlanner.plan("thay bầu trời hoàng hôn và khớp ánh sáng")
        assertEquals("sunset", p.ops.first { it.type == OpType.SKY_REPLACE }.arg)
        assertTrue(p.ops.any { it.type == OpType.SKY_RELIGHT })
        assertTrue(p.ops.none { it.type == OpType.BRIGHTNESS || it.type == OpType.WARMTH })
        assertTrue(RuleBasedPlanner.plan("làm sáng ảnh").ops.none { it.type == OpType.SKY_RELIGHT })
    }
}
