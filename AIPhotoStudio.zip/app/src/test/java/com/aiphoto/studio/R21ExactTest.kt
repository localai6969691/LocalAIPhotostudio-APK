package com.aiphoto.studio

import android.graphics.Bitmap
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.engine.Blur
import com.aiphoto.studio.engine.ClassicInpaint
import com.aiphoto.studio.engine.DistanceField
import com.aiphoto.studio.engine.InpaintEdge
import com.aiphoto.studio.engine.Inpainter
import com.aiphoto.studio.engine.PatchMatchInpaint
import com.aiphoto.studio.engine.RegionCrop
import com.aiphoto.studio.engine.TiledInpaint
import com.aiphoto.studio.engine.makeBitmap
import com.aiphoto.studio.engine.readPixels
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * R21: "Xóa chính xác" (không nới, không hòa mép) cho cả 4 engine xóa vật thể.
 * Lõi dựng rìa dùng chung ([InpaintEdge]) được kiểm bằng cách so với bản cài đặt CŨ
 * (chép nguyên từ LamaInpainter trước khi refactor) và với mã băm kết quả của ClassicInpaint/PatchMatch/composite lấy TRƯỚC khi sửa.
 * LaMa/MI-GAN cần model nên không chạy được ở đây: phần của chúng kiểm được là dựng rìa, thu mặt nạ, dán lại.
 */
class R21ExactTest {

    // ---------------------------------------------------------------------------------------------- dữ liệu thử
    /** Ảnh nhiễu ĐỘC LẬP theo kênh: điểm lấp trùng giá trị gốc chỉ do ngẫu nhiên (xác suất ~ 1/40³). */
    private fun scene(w: Int, h: Int, seed: Long): IntArray {
        val rnd = java.util.Random(seed)
        return IntArray(w * h) { i ->
            val x = i % w; val y = i / w
            val r = (100 + 60 * sin(x / 23.0) + rnd.nextInt(40)).toInt().coerceIn(0, 255)
            val g = (110 + 50 * cos(y / 17.0) + rnd.nextInt(40)).toInt().coerceIn(0, 255)
            val b = (90 + 40 * sin((x + y) / 31.0) + rnd.nextInt(40)).toInt().coerceIn(0, 255)
            (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun discs(w: Int, h: Int, pts: List<Triple<Int, Int, Int>>): ByteArray {
        val m = ByteArray(w * h)
        for ((cx, cy, r) in pts) for (y in cy - r..cy + r) for (x in cx - r..cx + r)
            if (x in 0 until w && y in 0 until h && hypot((x - cx).toDouble(), (y - cy).toDouble()) <= r) m[y * w + x] = 255.toByte()
        return m
    }

    private data class Case(val w: Int, val h: Int, val seed: Long, val pts: List<Triple<Int, Int, Int>>)

    private val cases = listOf(
        Case(200, 150, 100L, listOf(Triple(100, 75, 12), Triple(60, 40, 5))),
        Case(320, 240, 101L, listOf(Triple(160, 120, 30))),
        Case(256, 256, 102L, listOf(Triple(20, 20, 8), Triple(240, 230, 9)))
    )

    private class Outside(val changedOutside: Int, val changedInside: Int, val inside: Int, val maxDist: Float)

    private fun measure(src: IntArray, out: IntArray, mask: ByteArray, w: Int, h: Int): Outside {
        val painted = BooleanArray(w * h) { mask[it].toInt() != 0 }
        val dist = DistanceField.chamfer(painted, w, h)
        var co = 0; var ci = 0; var inside = 0; var md = 0f
        for (i in src.indices) {
            if (painted[i]) inside++
            if (out[i] != src[i]) {
                if (painted[i]) ci++ else { co++; md = max(md, dist[i]) }
            }
        }
        return Outside(co, ci, inside, md)
    }

    // ---------------------------------------------------------------------------------------------- chế độ thường KHÔNG đổi
    // Mã băm lấy từ mã TRƯỚC refactor (cùng cảnh/mặt nạ như bên dưới). Đổi các hằng số nới/hòa mép thì cố ý phải cập nhật các số này.
    private val goldenClassic = intArrayOf(-23628148, 848191638, -1950394766)
    private val goldenComposite = intArrayOf(-136600873, -1442943103, 1513668151)
    private val goldenPatchMatch = intArrayOf(-525175842, 937246238, 820264532)

    @Test fun normalModeOutputIsIdenticalToTheCodeBeforeTheRefactor() {
        for ((i, c) in cases.withIndex()) {
            val px = scene(c.w, c.h, c.seed)
            val src = makeBitmap(px, c.w, c.h)
            val mask = discs(c.w, c.h, c.pts)
            assertEquals("Classic[$i]", goldenClassic[i], java.util.Arrays.hashCode(readPixels(ClassicInpaint.inpaint(src, mask))))
            val rect = RegionCrop.compute(mask, c.w, c.h)!!
            val gen = IntArray(rect.w * rect.h) { k -> (255 shl 24) or (((k * 7) and 255) shl 16) or (((k * 3) and 255) shl 8) or ((k * 11) and 255) }
            val comp = RegionCrop.composite(src, mask, rect, makeBitmap(gen, rect.w, rect.h))
            assertEquals("composite[$i]", goldenComposite[i], java.util.Arrays.hashCode(readPixels(comp)))
            // Classic/PatchMatch tự xử lý mặt nạ lớn → qua TiledInpaint phải ra ĐÚNG như gọi thẳng (không chia ô)
            assertEquals("tiled[$i]", goldenClassic[i], java.util.Arrays.hashCode(readPixels(TiledInpaint.run(src, mask, ClassicInpaint, tile = 24, maxTiles = 64))))
            assertEquals("patchmatch[$i]", goldenPatchMatch[i], java.util.Arrays.hashCode(readPixels(PatchMatchInpaint().inpaint(src, mask))))
        }
    }

    /** Bản CŨ của bước 3 + 6 trong LamaInpainter (chép nguyên trước khi refactor) — đối chứng cho phần dùng chung. */
    private fun oldLamaEdge(mask: ByteArray, w: Int, x0: Int, y0: Int, cw: Int, ch: Int, grow: Int): Pair<BooleanArray, IntArray> {
        val gray = IntArray(cw * ch)
        for (y in 0 until ch) for (x in 0 until cw) gray[y * cw + x] = if (mask[(y0 + y) * w + (x0 + x)].toInt() != 0) -1 else (255 shl 24)
        val grown = Blur.gaussian(gray, cw, ch, grow)
        val hole = BooleanArray(cw * ch) { (grown[it] and 255) > 10 }
        val holeGray = IntArray(cw * ch) { if (hole[it]) -1 else (255 shl 24) }
        val feather = Blur.gaussian(holeGray, cw, ch, max(2, max(cw, ch) / 120))
        return Pair(hole, feather)
    }

    private fun oldLamaPaste(src: IntArray, w: Int, h: Int, x0: Int, y0: Int, cw: Int, ch: Int, fp: IntArray, feather: IntArray): IntArray {
        val result = src.copyOf()
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                val a = (feather[y * cw + x] and 255) / 255f
                if (a <= 0.003f) continue
                val i = (y0 + y) * w + (x0 + x)
                val o = result[i]
                val f = fp[y * cw + x]
                val r = (((o shr 16) and 255) * (1f - a) + ((f shr 16) and 255) * a + 0.5f).toInt()
                val g = (((o shr 8) and 255) * (1f - a) + ((f shr 8) and 255) * a + 0.5f).toInt()
                val b = ((o and 255) * (1f - a) + (f and 255) * a + 0.5f).toInt()
                result[i] = (o and (0xFF shl 24)) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
            }
        }
        return result
    }

    @Test fun sharedEdgeCodeMatchesTheOldLamaImplementationBitForBit() {
        val rnd = java.util.Random(5)
        repeat(6) { t ->
            val w = 90 + rnd.nextInt(60); val h = 80 + rnd.nextInt(60)
            val mask = discs(w, h, listOf(Triple(20 + rnd.nextInt(40), 20 + rnd.nextInt(40), 4 + rnd.nextInt(10)), Triple(60 + rnd.nextInt(20), 55 + rnd.nextInt(20), 3 + rnd.nextInt(6))))
            val x0 = rnd.nextInt(10); val y0 = rnd.nextInt(10)
            val cw = w - x0 - rnd.nextInt(10); val ch = h - y0 - rnd.nextInt(10)
            val grow = 1 + rnd.nextInt(6)
            val src = scene(w, h, 40L + t)
            val fill = IntArray(cw * ch) { (255 shl 24) or rnd.nextInt(0x1000000) }
            val (oldHole, oldFeather) = oldLamaEdge(mask, w, x0, y0, cw, ch, grow)
            val oldOut = oldLamaPaste(src, w, h, x0, y0, cw, ch, fill, oldFeather)

            val edge = InpaintEdge.build(mask, w, x0, y0, cw, ch, grow, max(2, max(cw, ch) / 120), exact = false)
            val newOut = src.copyOf()
            InpaintEdge.paste(newOut, w, x0, y0, cw, ch, fill, edge.alpha)
            for (i in oldHole.indices) assertEquals("hole[$i] ở ca $t", oldHole[i], edge.hole[i])
            assertTrue("kết quả dán phải trùng từng bit (ca $t)", oldOut.contentEquals(newOut))
        }
    }

    // ---------------------------------------------------------------------------------------------- chế độ chính xác
    @Test fun exactModeChangesNothingOutsideThePaintedMaskForClassicAndPatchMatch() {
        for ((i, c) in cases.withIndex()) {
            val px = scene(c.w, c.h, c.seed)
            val src = makeBitmap(px, c.w, c.h)
            val mask = discs(c.w, c.h, c.pts)
            for ((name, eng) in listOf("classic" to ClassicInpaint, "patchmatch" to PatchMatchInpaint())) {
                val out = readPixels(eng.inpaintExact(src, mask))
                val m = measure(px, out, mask, c.w, c.h)
                assertEquals("$name[$i]: điểm ngoài nét tô bị đổi", 0, m.changedOutside)
                assertTrue("$name[$i]: vùng tô phải được thay (${m.changedInside}/${m.inside})", m.changedInside >= m.inside * 0.99)
            }
        }
    }

    /** Ép chia ô để kiểm đường chia ô bằng engine thật (LaMa/MI-GAN cần model nên không chạy được ở đây). */
    private class ForceTiled(private val inner: Inpainter) : Inpainter {
        override val needsTiling: Boolean get() = true
        override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap = inner.inpaint(src, mask)
        override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap = inner.inpaintExact(src, mask)
    }

    @Test fun exactModeReplacesThePaintedAreaCompletelyWithoutKeepingAnyOfWhatWasThere() {
        val c = cases[0]
        val px = scene(c.w, c.h, c.seed)
        val mask = discs(c.w, c.h, c.pts)
        val other = px.copyOf()
        for (i in other.indices) if (mask[i].toInt() != 0) other[i] = objectRed        // chỉ khác nhau BÊN TRONG vùng tô
        for ((name, eng) in listOf("classic" to ClassicInpaint, "patchmatch" to PatchMatchInpaint())) {
            val a = readPixels(eng.inpaintExact(makeBitmap(px, c.w, c.h), mask))
            val b = readPixels(eng.inpaintExact(makeBitmap(other, c.w, c.h), mask))
            assertTrue("$name: kết quả chính xác không được phụ thuộc vào thứ nằm dưới nét tô", a.contentEquals(b))
        }
    }

    @Test fun exactModeAlsoHoldsWhenTheMaskIsTiledIntoSeveralPieces() {
        val c = cases[1]
        val px = scene(c.w, c.h, c.seed)
        val src = makeBitmap(px, c.w, c.h)
        val mask = discs(c.w, c.h, c.pts)
        for ((name, eng) in listOf("classic" to ForceTiled(ClassicInpaint), "patchmatch" to ForceTiled(PatchMatchInpaint()))) {
            val out = readPixels(TiledInpaint.run(src, mask, eng, tile = 24, maxTiles = 64, exact = true))
            val m = measure(px, out, mask, c.w, c.h)
            assertEquals("$name qua TiledInpaint", 0, m.changedOutside)
            assertTrue(m.changedInside >= m.inside * 0.99)
        }
    }

    @Test fun normalModeSpillsPastThePaintedMaskWhichIsWhatExactRemoves() {
        val c = cases[1]
        val px = scene(c.w, c.h, c.seed)
        val src = makeBitmap(px, c.w, c.h)
        val mask = discs(c.w, c.h, c.pts)
        for ((name, eng) in listOf("classic" to ClassicInpaint, "patchmatch" to PatchMatchInpaint())) {
            val normal = measure(px, readPixels(eng.inpaint(src, mask)), mask, c.w, c.h)
            val exact = measure(px, readPixels(eng.inpaintExact(src, mask)), mask, c.w, c.h)
            println("R21 $name: thường đổi thêm ${normal.changedOutside} điểm ngoài nét tô (xa nhất ${"%.1f".format(normal.maxDist)} px); chính xác: ${exact.changedOutside}")
            assertTrue("$name: chế độ thường phải nới ra ngoài (đó là thiết kế)", normal.changedOutside > 0)
            assertEquals(0, exact.changedOutside)
        }
    }

    // ---------------------------------------------------------------------------------------------- lỗi rò màu vật thể khi chia ô
    private val objectRed = (255 shl 24) or (220 shl 16) or (30 shl 8) or 30

    /** Nền cỏ xanh có kết cấu + vật thể ĐỎ hình tròn: màu đỏ KHÔNG có trong nền, nên đỏ trong vùng lấp = rò rỉ từ chính vật thể. */
    private fun redObjectScene(w: Int, h: Int, cx: Int, cy: Int, radius: Int): Triple<IntArray, ByteArray, Int> {
        val rnd = java.util.Random(3)
        val px = IntArray(w * h) { i ->
            val x = i % w
            val g = (130 + 30 * sin(x / 19.0) + rnd.nextInt(30)).toInt().coerceIn(0, 255)
            (255 shl 24) or ((40 + rnd.nextInt(20)) shl 16) or (g shl 8) or (50 + rnd.nextInt(20))
        }
        val mask = discs(w, h, listOf(Triple(cx, cy, radius)))
        for (i in px.indices) if (mask[i].toInt() != 0) px[i] = objectRed
        return Triple(px, mask, w * h)
    }

    private fun meanRedness(out: IntArray, mask: ByteArray): Double {
        var sum = 0.0; var n = 0
        for (i in out.indices) if (mask[i].toInt() != 0) { sum += max(0, ((out[i] shr 16) and 255) - ((out[i] shr 8) and 255)); n++ }
        return sum / n
    }

    @Test fun tiledRemovalDoesNotRefillWithTheColourOfTheObjectBeingRemoved() {
        val w = 600; val h = 500
        val (px, mask, _) = redObjectScene(w, h, 300, 250, 200)
        val src = makeBitmap(px, w, h)
        for ((name, eng) in listOf("classic" to ClassicInpaint, "patchmatch" to PatchMatchInpaint())) {
            val tiled = meanRedness(readPixels(TiledInpaint.run(src, mask, ForceTiled(eng), tile = 150)), mask)
            val whole = meanRedness(readPixels(eng.inpaint(src, mask)), mask)
            println("R21 rò màu đỏ ($name): chia ô ${"%.1f".format(tiled)} · không chia ${"%.1f".format(whole)} (trước khi sửa: chia ô ≈ 83–107)")
            assertTrue("$name chia ô: vùng lấp vẫn đỏ ($tiled)", tiled < 6.0)
            assertTrue("$name không chia: ($whole)", whole < 6.0)
        }
    }

    @Test fun noTileCallEverSeesTheObjectPixelsInsideTheMask() {
        val w = 300; val h = 260
        val (px, mask, _) = redObjectScene(w, h, 150, 130, 100)
        val src = makeBitmap(px, w, h)
        var calls = 0; var leaked = 0
        val spy = object : Inpainter {
            private fun look(img: Bitmap): Bitmap {
                calls++
                val p = readPixels(img)
                for (i in p.indices) if (mask[i].toInt() != 0 && p[i] == objectRed) leaked++
                return img
            }
            override fun inpaint(src: Bitmap, mask: ByteArray) = look(src)
            override fun inpaintExact(src: Bitmap, mask: ByteArray) = look(src)
        }
        TiledInpaint.run(src, mask, spy, tile = 60)
        assertTrue("phải chia nhiều ô ($calls)", calls >= 4)
        assertEquals("điểm vật thể còn lại trong ảnh đưa cho engine", 0, leaked)
        calls = 0; leaked = 0
        TiledInpaint.run(src, mask, spy, tile = 60, exact = true)
        assertTrue(calls >= 4); assertEquals(0, leaked)
    }

    @Test fun enginesThatScaleThemselvesAreNotTiled() {
        assertFalse(ClassicInpaint.needsTiling)
        assertFalse(PatchMatchInpaint().needsTiling)
        assertTrue(Spy().needsTiling)
        val c = cases[1]
        val src = makeBitmap(scene(c.w, c.h, c.seed), c.w, c.h)
        val mask = discs(c.w, c.h, c.pts)
        val pm = readPixels(TiledInpaint.run(src, mask, PatchMatchInpaint(), tile = 24, maxTiles = 64))
        assertTrue(pm.contentEquals(readPixels(PatchMatchInpaint().inpaint(src, mask))))
    }

    @Test fun thinStrokesAndSinglePixelsAreHandledExactly() {
        val w = 160; val h = 120
        val px = scene(w, h, 9L)
        val src = makeBitmap(px, w, h)
        val line = ByteArray(w * h)
        for (x in 20..140) line[60 * w + x] = 255.toByte()                // nét 1 điểm ảnh
        val dots = ByteArray(w * h)
        dots[30 * w + 30] = 255.toByte(); dots[90 * w + 120] = 255.toByte()
        for ((nm, mask) in listOf("nét 1px" to line, "hai điểm" to dots)) {
            for ((name, eng) in listOf("classic" to ClassicInpaint, "patchmatch" to PatchMatchInpaint())) {
                val out = readPixels(eng.inpaintExact(src, mask))
                val m = measure(px, out, mask, w, h)
                assertEquals("$name/$nm", 0, m.changedOutside)
                assertTrue("$name/$nm: phải thay ít nhất phần lớn điểm tô (${m.changedInside}/${m.inside})", m.changedInside >= m.inside * 0.9)
            }
        }
    }

    @Test fun emptyMaskReturnsTheSameBitmapInBothModes() {
        val px = scene(40, 30, 3L)
        val src = makeBitmap(px, 40, 30)
        val none = ByteArray(40 * 30)
        for (eng in listOf<Inpainter>(ClassicInpaint, PatchMatchInpaint())) {
            assertTrue(eng.inpaint(src, none) === src)
            assertTrue(eng.inpaintExact(src, none) === src)
        }
    }

    private class Spy : Inpainter {
        var normal = 0; var exact = 0
        override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap { normal++; return src }
        override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap { exact++; return src }
    }

    @Test fun tiledInpaintCallsTheExactEntryPointForEveryTileOnlyWhenAsked() {
        val c = cases[1]
        val src = makeBitmap(scene(c.w, c.h, c.seed), c.w, c.h)
        val mask = discs(c.w, c.h, c.pts)
        val a = Spy(); TiledInpaint.run(src, mask, a, tile = 24, maxTiles = 64, exact = true)
        assertTrue("phải chia nhiều ô (${a.exact})", a.exact >= 4)
        assertEquals(0, a.normal)
        val b = Spy(); TiledInpaint.run(src, mask, b, tile = 24, maxTiles = 64)
        assertEquals(0, b.exact)
        assertEquals(a.exact, b.normal)
        val one = Spy(); TiledInpaint.run(src, mask, one, exact = true)           // mặc định tile 384: một lần gọi
        assertEquals(1, one.exact); assertEquals(0, one.normal)
    }

    // ---------------------------------------------------------------------------------------------- dán lại cho MI-GAN / dịch vụ sinh ảnh
    @Test fun regionCropCompositeExactIsHardEdgedAndBitExactOutside() {
        val c = cases[0]
        val px = scene(c.w, c.h, c.seed)
        val src = makeBitmap(px, c.w, c.h)
        val mask = discs(c.w, c.h, c.pts)
        val rect = RegionCrop.compute(mask, c.w, c.h)!!
        val green = (255 shl 24) or 0x00FF00
        val gen = makeBitmap(IntArray(rect.w * rect.h) { green }, rect.w, rect.h)
        val out = readPixels(RegionCrop.composite(src, mask, rect, gen, exact = true))
        for (i in px.indices) {
            if (mask[i].toInt() != 0) assertEquals("trong mặt nạ phải là bản sinh hoàn toàn", green, out[i])
            else assertEquals("ngoài mặt nạ phải nguyên vẹn", px[i], out[i])
        }
        val soft = readPixels(RegionCrop.composite(src, mask, rect, gen))
        var spill = 0
        for (i in px.indices) if (mask[i].toInt() == 0 && soft[i] != px[i]) spill++
        assertTrue("chế độ thường hòa mép nên lan ra ngoài ($spill)", spill > 0)
    }

    // ---------------------------------------------------------------------------------------------- thu mặt nạ cho model
    @Test fun shrinkAnyNeverDropsAHolePixelAndNeverInventsOne() {
        val rnd = java.util.Random(11)
        val sizes = listOf(Triple(100, 80, 33), Triple(1000, 500, 512), Triple(37, 91, 16), Triple(64, 64, 64), Triple(50, 50, 128), Triple(333, 77, 200))
        for ((cw, ch, m) in sizes) {
            val mw = m; val mh = m
            for (density in listOf(0.0005, 0.01, 0.2)) {
                val hole = BooleanArray(cw * ch) { rnd.nextDouble() < density }
                val out = InpaintEdge.shrinkAny(hole, cw, ch, mw, mh)
                // 1) không bỏ sót: điểm model chứa điểm trống gốc phải là trống
                for (sy in 0 until ch) for (sx in 0 until cw) if (hole[sy * cw + sx]) {
                    val tx = (sx.toLong() * mw / cw).toInt(); val ty = (sy.toLong() * mh / ch).toInt()
                    assertTrue("rớt điểm trống ($sx,$sy) ở $cw×$ch→$mw×$mh", out[ty * mw + tx])
                }
                // 2) không bịa: ô model trống thì phải có ít nhất một điểm trống gốc trong phạm vi ô đó
                for (ty in 0 until mh) for (tx in 0 until mw) if (out[ty * mw + tx]) {
                    val sy0 = (ty.toLong() * ch / mh).toInt(); val sy1 = minOf(ch, maxOf(sy0 + 1, (((ty + 1).toLong() * ch + mh - 1) / mh).toInt()))
                    val sx0 = (tx.toLong() * cw / mw).toInt(); val sx1 = minOf(cw, maxOf(sx0 + 1, (((tx + 1).toLong() * cw + mw - 1) / mw).toInt()))
                    var any = false
                    for (sy in sy0 until sy1) for (sx in sx0 until sx1) if (hole[sy * cw + sx]) any = true
                    assertTrue("ô ($tx,$ty) trống mà không có điểm gốc nào", any)
                }
            }
        }
        assertFalse(InpaintEdge.shrinkAny(BooleanArray(100 * 100), 100, 100, 30, 30).any { it })
    }

    @Test fun shrinkAnyKeepsAOnePixelLineThatNearestSamplingLoses() {
        val cw = 1000; val ch = 1000; val m = 512
        val hole = BooleanArray(cw * ch)
        for (x in 100 until 900) hole[502 * cw + x] = true                 // nét tô 1 điểm ảnh, đúng hàng mà lấy mẫu gần nhất bỏ qua
        val keep = InpaintEdge.shrinkAny(hole, cw, ch, m, m)
        var kept = 0; var nearest = 0
        for (yy in 0 until m) for (xx in 0 until m) {
            if (keep[yy * m + xx]) kept++
            val sy = minOf(ch - 1, yy * ch / m); val sx = minOf(cw - 1, xx * cw / m)
            if (hole[sy * cw + sx]) nearest++
        }
        println("R21 nét 1px 1000→512: lấy mẫu gần nhất giữ $nearest điểm, shrinkAny giữ $kept")
        assertTrue("shrinkAny phải giữ nét (kept=$kept)", kept >= 400)
        assertEquals("lấy mẫu gần nhất làm rớt hẳn nét này", 0, nearest)
    }

    @Test fun exactEdgeIsTheMaskItselfWithHardAlpha() {
        val w = 60; val h = 50
        val mask = discs(w, h, listOf(Triple(30, 25, 10)))
        val e = InpaintEdge.build(mask, w, 5, 4, 50, 40, grow = 0, featherRadius = 3, exact = true)
        for (i in e.hole.indices) {
            val inMask = mask[(4 + i / 50) * w + 5 + i % 50].toInt() != 0
            assertEquals(inMask, e.hole[i]); assertEquals(if (inMask) 1f else 0f, e.alpha[i], 0f)
        }
    }

    // ---------------------------------------------------------------------------------------------- hiểu lời "xóa chính xác"
    @Test fun exactPhrasesAreRecognisedInVietnameseAndEnglish() {
        for (p in listOf("xóa chính xác", "xoá đúng vùng tô", "xóa đúng vùng tôi tô", "Xóa chính xác vùng này", "erase exactly", "remove it precisely", "only the painted area", "xóa đúng chỗ tô"))
            assertTrue(p, GenIntent.wantsExact(p))
        for (p in listOf("xóa", "xóa người", "remove the car", "", "thêm cây dừa", "xóa người lạ"))
            assertFalse(p, GenIntent.wantsExact(p))
    }

    @Test fun exactnessWordsAloneStillMeanRemoveOnAPaintedMaskButNotOnAnUnpaintedImage() {
        assertEquals(GenKind.REMOVE, GenIntent.detect("xóa chính xác", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("chính xác", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("đúng vùng tô", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("erase exactly", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("", true))
        assertEquals(GenKind.FILL, GenIntent.detect("thêm con mèo đúng vùng này", true))
        assertEquals(GenKind.FILL, GenIntent.detect("cây dừa", true))
        assertEquals(GenKind.REMOVE, GenIntent.detect("xóa cái ly bên trái chính xác", false))
        assertNull("không tô thì 'chính xác' một mình không phải lệnh xóa", GenIntent.detect("chính xác", false))
        assertNull(GenIntent.detect("màu sắc chính xác hơn", false))
    }
}
