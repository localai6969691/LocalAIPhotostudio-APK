package com.aiphoto.studio

import com.aiphoto.studio.ai.WholeEditIntent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** R25: nhận biết yêu cầu AI tác động lên CẢ ẢNH (xóa phản chiếu / bóng đổ, đổi phong cách) và không nuốt các lệnh khác. */
class R25WholeEditTest {

    private fun kind(p: String): WholeEditIntent.Kind? = WholeEditIntent.detect(p)?.kind

    @Test fun reflectionRemoval() {
        for (p in listOf("xóa phản chiếu trên kính", "xoá phản chiếu", "remove reflections from the window", "remove the glare", "bỏ phản quang trên cửa kính",
            "khử chói kính", "get rid of the reflection")) assertEquals("\"$p\"", WholeEditIntent.Kind.REFLECTION, kind(p))
        assertNull(kind("thêm phản chiếu dưới nước"))
        assertNull(kind("tạo phản chiếu"))
        assertNull(kind("add reflection to the lake"))
    }

    @Test fun shadowRemovalButNotTonalShadows() {
        for (p in listOf("xóa bóng đổ trên mặt", "xóa bóng", "remove the shadow on his face", "get rid of hard shadows", "bỏ bóng của người trên tường", "remove shadows")) {
            assertEquals("\"$p\"", WholeEditIntent.Kind.SHADOW, kind(p))
        }
        for (p in listOf("nâng vùng bóng", "lift shadows", "làm sáng vùng bóng", "thêm bóng đổ", "add a drop shadow", "xóa quầng thâm", "remove under eye shadows", "xóa bóng mắt")) {
            assertNull("\"$p\" không được là xóa bóng đổ", kind(p).takeIf { it == WholeEditIntent.Kind.SHADOW })
        }
    }

    @Test fun artisticRestyle() {
        val cases = listOf(
            "chuyển thành phong cách anime" to "anime",
            "make it look like a Studio Ghibli film" to "Ghibli",
            "anime" to "anime",
            "biến ảnh thành tranh Van Gogh" to "Van Gogh",
            "in the style of Monet" to "Monet",
            "phong cách cyberpunk" to "cyberpunk",
            "convert to pop art" to "pop art",
            "chuyển thành manga" to "manga",
            "turn this into LEGO" to "LEGO"
        )
        for ((p, expect) in cases) {
            val r = WholeEditIntent.detect(p)
            assertNotNull("\"$p\" phải là RESTYLE", r)
            assertEquals(WholeEditIntent.Kind.RESTYLE, r!!.kind)
            assertTrue("\"$p\": styleName=${r.styleName}", r.styleName!!.contains(expect, ignoreCase = true))
            assertTrue(r.instruction.startsWith("Redraw this photo in the style of"))
            assertTrue(r.label.startsWith("Đổi phong cách"))
        }
        val unknown = WholeEditIntent.detect("theo phong cách tranh lụa")
        assertEquals(WholeEditIntent.Kind.RESTYLE, unknown!!.kind)
        assertTrue(unknown.styleName!!.contains("tranh lua"))
    }

    @Test fun classicStylesStayOnDeviceUnlessAiIsRequested() {
        for (p in listOf("chuyển thành tranh sơn dầu", "hoạt hình", "biến ảnh thành màu nước", "phong cách màu nước", "make it a cartoon", "oil painting")) {
            assertNull("\"$p\" phải đi đường cổ điển miễn phí", WholeEditIntent.detect(p))
        }
        val ai = WholeEditIntent.detect("chuyển thành tranh sơn dầu bằng AI")
        assertEquals(WholeEditIntent.Kind.RESTYLE, ai!!.kind)
        assertTrue(ai.instruction.contains("oil painting"))
        assertEquals(WholeEditIntent.Kind.RESTYLE, WholeEditIntent.detect("make it watercolor with AI")!!.kind)
    }

    @Test fun ordinaryRequestsAreNotSwallowed() {
        for (p in listOf("làm sáng ảnh", "xóa người ở bên trái", "làm mịn da", "tăng độ nét", "thay nền thành bãi biển", "mở rộng ảnh", "xóa vật thể", "",
            "khử mờ ảnh", "khử moiré", "cắt vuông", "làm da sáng hơn", "đổi màu tóc nâu", "bóng đèn sáng hơn", "làm ảnh ấn tượng hơn", "remove the car")) {
            assertNull("\"$p\" bị nhận nhầm là AI toàn ảnh: ${kind(p)}", WholeEditIntent.detect(p))
        }
    }

    @Test fun instructionsPreserveEverythingElse() {
        for (p in listOf("xóa phản chiếu", "xóa bóng đổ", "chuyển thành anime")) {
            val r = WholeEditIntent.detect(p)!!
            assertTrue(r.instruction, r.instruction.contains("Do not add text, borders or frames."))
            assertTrue(r.instruction, r.instruction.contains("unchanged") || r.instruction.contains("exactly the same"))
        }
    }
}
