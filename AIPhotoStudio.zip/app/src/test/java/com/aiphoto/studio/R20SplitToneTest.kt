package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.mergeOps
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.SplitTone
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/** R20: Color Grading chia tông — kiểm chứng số học độc lập (không dựa vào chính hàm đang test) + bộ hiểu lệnh. */
class R20SplitToneTest {

    private fun rgb(r: Int, g: Int, b: Int) = (255 shl 24) or (r shl 16) or (g shl 8) or b
    private fun r(c: Int) = (c shr 16) and 255
    private fun g(c: Int) = (c shr 8) and 255
    private fun b(c: Int) = c and 255
    private fun lum(c: Int) = 0.2126 * r(c) + 0.7152 * g(c) + 0.0722 * b(c)

    /** Hue (độ) của một vector chênh lệch màu (r,g,b) có tổng chói 0: tính độc lập bằng công thức HSV chuẩn từ (max,min). */
    private fun hueOfRgb(rr: Double, gg: Double, bb: Double): Double {
        val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
        if (mx - mn < 1e-9) return 0.0
        val d = mx - mn
        val h = when (mx) {
            rr -> ((gg - bb) / d) % 6
            gg -> (bb - rr) / d + 2
            else -> (rr - gg) / d + 4
        }
        return ((h * 60) + 360) % 360
    }

    private fun apply(c: Int, p: SplitTone.Params) = SplitTone.apply(intArrayOf(c), 1, 1, p)[0]

    @Test fun zeroSaturationIsExactIdentityAndSameArray() {
        val px = IntArray(64) { rgb(it * 3, 255 - it * 2, it * 4 % 256) }
        assertSame(px, SplitTone.apply(px, 8, 8, SplitTone.Params(30f, 0f, 200f, 0f, 0.3f)))
    }

    @Test fun orangeHighlightsAndTealShadows() {
        val p = SplitTone.Params(185f, 0.6f, 28f, 0.6f, 0f)
        val bright = apply(rgb(235, 235, 235), p)          // vùng sáng → ngả cam: R > G > B
        assertTrue("sáng phải ngả cam: ${r(bright)},${g(bright)},${b(bright)}", r(bright) > g(bright) && g(bright) > b(bright))
        val dark = apply(rgb(25, 25, 25), p)               // vùng tối → ngả teal: B,G > R
        assertTrue("tối phải ngả teal: ${r(dark)},${g(dark)},${b(dark)}", b(dark) > r(dark) && g(dark) > r(dark))
        val mid = apply(rgb(128, 128, 128), p)             // giữa: hai tác động triệt nhau phần lớn → gần trung tính hơn hai đầu
        val tint = { c: Int -> max(r(c), max(g(c), b(c))) - min(r(c), min(g(c), b(c))) }
        assertTrue("điểm giữa ít bị nhuộm hơn hai đầu (${tint(mid)} vs ${tint(bright)}, ${tint(dark)})", tint(mid) < tint(bright) && tint(mid) < tint(dark))
    }

    @Test fun tintDirectionMatchesRequestedHue() {
        // nền xám 150 với balance=+1 (150 vẫn thuộc vùng sáng) → chỉ màu vùng sáng tác động, không kênh nào bị cắt;
        // hue đo lại bằng công thức HSV viết độc lập phải khớp hue yêu cầu (±8°)
        for (hue in listOf(0f, 28f, 60f, 120f, 185f, 215f, 275f, 335f)) {
            val c = apply(rgb(150, 150, 150), SplitTone.Params(0f, 0f, hue, 0.8f, 1f))
            val h = hueOfRgb((r(c) - 150).toDouble(), (g(c) - 150).toDouble(), (b(c) - 150).toDouble())
            val diff = abs(((h - hue + 540) % 360) - 180)
            assertTrue("hue yêu cầu $hue, đo được $h (sai $diff°)", diff < 8.0)
        }
    }

    @Test fun lumaIsPreservedWhereNothingClips() {
        val p = SplitTone.Params(250f, 0.5f, 40f, 0.5f, 0f)
        for (v in 70..190 step 10) {
            val c = apply(rgb(v, v, v), p)
            assertTrue("chói đổi quá 1,5 mức tại $v: ${lum(rgb(v, v, v))} → ${lum(c)}", abs(lum(c) - v) < 1.5)
        }
    }

    @Test fun balanceMovesTheCrossover() {
        // điểm xám 100 (hơi tối): balance dương dành nhiều dải cho vùng sáng → bị nhuộm màu vùng sáng nhiều hơn
        fun hiShare(bal: Float): Double {
            val c = apply(rgb(100, 100, 100), SplitTone.Params(185f, 0.6f, 28f, 0.6f, bal))
            return (r(c) - b(c)).toDouble()          // > 0 = cam (sáng) thắng, < 0 = teal (tối) thắng
        }
        assertTrue(hiShare(1f) > hiShare(0f) && hiShare(0f) > hiShare(-1f))
        assertTrue("balance −1 phải ngả teal ở điểm 100", hiShare(-1f) < 0)
        assertTrue("balance +1 phải ngả cam ở điểm 100", hiShare(1f) > 0)
    }

    @Test fun strengthScalesTheShift() {
        fun shift(sat: Float): Int { val c = apply(rgb(220, 220, 220), SplitTone.Params(0f, 0f, 28f, sat, 0f)); return r(c) - b(c) }
        assertTrue(shift(0.2f) < shift(0.5f) && shift(0.5f) < shift(1f))
        assertTrue(shift(0.2f) > 0)
    }

    @Test fun alphaIsKept() {
        val px = IntArray(256) { (it shl 24) or (it shl 16) or ((255 - it) shl 8) or ((it * 7) % 256) }
        val out = SplitTone.apply(px, 16, 16, SplitTone.Params(330f, 1f, 90f, 1f, 0.5f))
        for (i in px.indices) assertEquals("alpha điểm $i", px[i] ushr 24, out[i] ushr 24)
    }

    @Test fun parseFormatCanonicalAndMerge() {
        val p = SplitTone.parse("185,0.5,28,0.5")!!
        assertEquals(0f, p.balance, 0f)
        assertEquals("185.0,0.500,28.0,0.500,0.000", SplitTone.format(p))
        assertEquals(SplitTone.format(p), SplitTone.canonical(" 185 , 0.5 , 28 , 0.5 "))
        assertEquals(330f, SplitTone.parse("-30,2,400,0.2,9")!!.shadowHue, 1e-4f)
        assertEquals(1f, SplitTone.parse("-30,2,400,0.2,9")!!.shadowSat, 0f)
        assertEquals(40f, SplitTone.parse("-30,2,400,0.2,9")!!.highHue, 1e-4f)
        assertEquals(1f, SplitTone.parse("-30,2,400,0.2,9")!!.balance, 0f)
        assertNull(SplitTone.parse("abc"))
        assertNull(SplitTone.parse("1,2,3"))
        assertNull(SplitTone.parse(null))
        assertNull(SplitTone.canonical("10,0,20,0"))                          // vô hiệu → bị loại
        // gộp hai nửa
        val hi = SplitTone.Params(0f, 0f, 28f, 0.55f)
        val sh = SplitTone.Params(215f, 0.55f, 0f, 0f)
        val m = SplitTone.merge(hi, sh)
        assertEquals(215f, m.shadowHue, 0f); assertEquals(0.55f, m.shadowSat, 0f)
        assertEquals(28f, m.highHue, 0f); assertEquals(0.55f, m.highSat, 0f)
        val m2 = SplitTone.merge(sh, hi)
        assertEquals(SplitTone.format(m), SplitTone.format(m2))
    }

    @Test fun hueNames() {
        assertEquals(28f, SplitTone.hueOf("cam")!!, 0f)
        assertEquals(185f, SplitTone.hueOf("teal")!!, 0f)
        assertEquals(185f, SplitTone.hueOf("xanh ngoc")!!, 0f)
        assertEquals(215f, SplitTone.hueOf("xanh")!!, 0f)
        assertEquals(125f, SplitTone.hueOf("xanh la")!!, 0f)
        assertNull(SplitTone.hueOf("khong phai mau"))
        // "xanh ngoc" phải đứng trước "xanh" khi dò (dài trước)
        assertTrue(SplitTone.COLOR_WORDS.indexOf("xanh ngoc") < SplitTone.COLOR_WORDS.indexOf("xanh"))
        assertTrue(SplitTone.COLOR_WORDS.indexOf("xanh la") < SplitTone.COLOR_WORDS.indexOf("xanh"))
    }

    // ---------------------------------------------------------------- bộ hiểu lệnh
    private fun splitOf(prompt: String): SplitTone.Params? =
        RuleBasedPlanner.plan(prompt).ops.firstOrNull { it.type == OpType.SPLIT_TONE }?.let { SplitTone.parse(it.arg) }

    @Test fun vietnameseHighlightShadowAcrossClauses() {
        val p = splitOf("tăng highlight màu cam và shadow màu xanh")!!
        assertEquals(28f, p.highHue, 0f); assertTrue(p.highSat > 0.4f)
        assertEquals(215f, p.shadowHue, 0f); assertTrue(p.shadowSat > 0.4f)
        val ops = RuleBasedPlanner.plan("tăng highlight màu cam và shadow màu xanh").ops
        assertEquals(1, ops.count { it.type == OpType.SPLIT_TONE })           // hai mệnh đề gộp thành MỘT phép
        assertTrue("không còn HIGHLIGHTS/SHADOWS thừa: $ops", ops.none { it.type == OpType.HIGHLIGHTS || it.type == OpType.SHADOWS })
    }

    @Test fun variousPhrasings() {
        splitOf("vùng sáng ngả màu vàng, vùng tối ngả màu tím")!!.let { assertEquals(50f, it.highHue, 0f); assertEquals(275f, it.shadowHue, 0f) }
        splitOf("highlights orange shadows teal")!!.let { assertEquals(28f, it.highHue, 0f); assertEquals(185f, it.shadowHue, 0f) }
        splitOf("orange in the highlights, teal in the shadows")!!.let { assertEquals(28f, it.highHue, 0f); assertEquals(185f, it.shadowHue, 0f) }
        splitOf("cam cho vùng sáng, xanh ngọc cho vùng tối")!!.let { assertEquals(28f, it.highHue, 0f); assertEquals(185f, it.shadowHue, 0f) }
        splitOf("shadow xanh ngọc")!!.let { assertEquals(185f, it.shadowHue, 0f); assertTrue(it.shadowSat > 0.4f); assertEquals(0f, it.highSat, 0f) }
        splitOf("highlight hồng 30%")!!.let { assertEquals(335f, it.highHue, 0f); assertEquals(0.3f, it.highSat, 1e-4f) }
        splitOf("tông teal and orange")!!.let { assertEquals(185f, it.shadowHue, 0f); assertEquals(28f, it.highHue, 0f) }
        splitOf("teal & orange look")!!.let { assertEquals(185f, it.shadowHue, 0f); assertEquals(28f, it.highHue, 0f) }
        splitOf("highlight cam nhẹ")!!.let { assertEquals(0.275f, it.highSat, 1e-3f) }                      // "nhẹ" = ×0,5
        splitOf("highlight cam rất mạnh")!!.let { assertTrue(it.highSat > 0.8f) }
    }

    @Test fun plainHighlightShadowRequestsKeepTheirOldMeaning() {
        // không có tên màu → vẫn là chỉnh vùng sáng / nâng vùng tối như trước
        assertNull(splitOf("tăng highlight"))
        assertTrue(RuleBasedPlanner.plan("tăng highlight").ops.any { it.type == OpType.HIGHLIGHTS })
        assertTrue(RuleBasedPlanner.plan("nâng vùng tối").ops.any { it.type == OpType.SHADOWS })
        assertNull(splitOf("làm ảnh sáng hơn"))
        // "highlight sáng" (sáng ≠ màu) không bị hiểu thành nhuộm
        assertNull(splitOf("highlight sáng hơn"))
    }

    @Test fun otherEditsInTheSameClauseSurvive() {
        val ops = RuleBasedPlanner.plan("tăng tương phản, highlight màu cam").ops
        assertTrue(ops.any { it.type == OpType.CONTRAST && it.value > 0 })
        assertNotNull(ops.firstOrNull { it.type == OpType.SPLIT_TONE })
    }

    @Test fun sanitizedAndDescribe() {
        assertNull(EditOp(OpType.SPLIT_TONE, 1f, "10,0,20,0").sanitized())
        assertNull(EditOp(OpType.SPLIT_TONE, 1f, null).sanitized())
        val op = EditOp(OpType.SPLIT_TONE, 5f, "185,0.5,28,0.5").sanitized()!!
        assertEquals(1f, op.value, 0f)
        assertEquals("Chia tông (vùng sáng/tối): sáng 28° 50%, tối 185° 50%", op.describe())
        assertEquals("Chia tông (vùng sáng/tối): sáng 28° 50%", EditOp(OpType.SPLIT_TONE, 1f, "0,0,28,0.5").sanitized()!!.describe())
    }

    @Test fun mergeOpsKeepsBothHalves() {
        val merged = mergeOps(listOf(
            EditOp(OpType.SPLIT_TONE, 1f, SplitTone.format(SplitTone.Params(0f, 0f, 28f, 0.5f))),
            EditOp(OpType.BRIGHTNESS, 0.1f),
            EditOp(OpType.SPLIT_TONE, 1f, SplitTone.format(SplitTone.Params(215f, 0.4f, 0f, 0f)))
        ))
        val st = merged.single { it.type == OpType.SPLIT_TONE }
        val p = SplitTone.parse(st.arg)!!
        assertEquals(28f, p.highHue, 0f); assertEquals(0.5f, p.highSat, 1e-3f)
        assertEquals(215f, p.shadowHue, 0f); assertEquals(0.4f, p.shadowSat, 1e-3f)
        assertEquals(2, merged.size)
    }

    @Test fun offsetsHaveZeroLumaAndExpectedSigns() {
        for (h in 0..350 step 10) {
            val o = SplitTone.offset(h.toFloat(), 1f)
            val l = 0.2126 * o[0] + 0.7152 * o[1] + 0.0722 * o[2]
            assertTrue("hue $h: tổng chói của dịch chuyển phải bằng 0 ($l)", abs(l) < 1e-6)
        }
        val o = SplitTone.offset(28f, 1f)       // cam: đỏ tăng, lam giảm
        assertTrue(o[0] > 0 && o[2] < 0)
        assertArrayEquals(floatArrayOf(0f, 0f, 0f), SplitTone.offset(120f, 0f), 1e-9f)
    }

    @Test fun everyBuiltInLookSurvivesSanitizing() {
        val names = com.aiphoto.studio.doc.Looks.all.map { it.first }
        assertEquals(names.size, names.toSet().size)                                  // tên không trùng
        for ((name, ops) in com.aiphoto.studio.doc.Looks.all) {
            assertTrue(name, ops.isNotEmpty())
            for (op in ops) { assertNotNull("look \"$name\": ${op.type} bị sanitized loại", op.sanitized()); op.describe() }
        }
        assertNotNull(com.aiphoto.studio.doc.Looks.byName("Teal & Orange"))
    }
}
