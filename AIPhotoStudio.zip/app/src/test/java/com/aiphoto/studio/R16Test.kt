package com.aiphoto.studio

import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.RuleBasedPlanner
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.engine.HairVolume
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử R16: tăng volume tóc (engine.HairVolume + luật tiếng Việt). Kỳ vọng đối chiếu tools/verify_ports/hair_volume.py. */
class R16Test {

    private val HAIR = 0xFF1E140A.toInt()      // (30,20,10)
    private val BG = 0xFFD2C8BE.toInt()        // (210,200,190)

    private class Scene(val px: IntArray, val mask: ByteArray, val w: Int, val h: Int, val cx: Float, val cy: Float, val r: Float)

    private fun disc(size: Int, radius: Float): Scene {
        val c = size / 2f - 0.5f
        val px = IntArray(size * size)
        val m = ByteArray(size * size)
        for (y in 0 until size) for (x in 0 until size) {
            val inside = hypot(x - c, y - c) <= radius
            px[y * size + x] = if (inside) HAIR else BG
            if (inside) m[y * size + x] = 255.toByte()
        }
        return Scene(px, m, size, size, c, c, radius)
    }

    private fun closerToHair(p: Int): Boolean {
        fun d(a: Int, b: Int) = abs(((a shr 16) and 255) - ((b shr 16) and 255)) + abs(((a shr 8) and 255) - ((b shr 8) and 255)) + abs((a and 255) - (b and 255))
        return d(p, HAIR) < d(p, BG)
    }

    private fun effectiveRadius(px: IntArray): Float = sqrt(px.count { closerToHair(it) } / PI.toFloat())

    // ------------------------------------------------------------------ hằng số / đường cong dịch
    @Test fun growAndShiftCurve() {
        assertEquals(2f, HairVolume.growPx(200, 200, 0.5f), 1e-4f)
        assertEquals(0f, HairVolume.growPx(200, 200, Float.NaN), 0f)
        assertEquals(HairVolume.growPx(200, 200, 1f), HairVolume.growPx(200, 200, 9f), 0f)         // kẹp 0..1
        val g = 10f
        val band = g * HairVolume.BAND_FACTOR
        for (d in listOf(0f, 3f, 9.99f, 10f)) assertEquals(g, HairVolume.shiftAt(d, g, band), 1e-4f)
        assertEquals(0f, HairVolume.shiftAt(band, g, band), 0f)
        assertEquals(0f, HairVolume.shiftAt(band + 5f, g, band), 0f)
        var prev = -1e9f
        var d = 0f
        while (d < band + 5f) {                                    // nguồn d - dịch(d) tăng nghiêm ngặt -> không gập
            val src = d - HairVolume.shiftAt(d, g, band)
            assertTrue("gập tại d=$d", src > prev)
            prev = src; d += 0.05f
        }
    }

    // ------------------------------------------------------------------ hạ tầng: đối chiếu cách tính VÉT CẠN độc lập
    @Test fun distanceTransformMatchesBruteForce() {
        val w = 31
        val h = 23
        val inHair = BooleanArray(w * h)
        for (p in listOf(Pair(3, 4), Pair(25, 18), Pair(14, 2), Pair(0, 22))) inHair[p.second * w + p.first] = true
        val fast = HairVolume.distanceToHair(inHair, w, h)
        var worst = 0f
        for (y in 0 until h) for (x in 0 until w) {
            var best = Float.MAX_VALUE
            for (yy in 0 until h) for (xx in 0 until w) if (inHair[yy * w + xx]) best = minOf(best, hypot((x - xx).toFloat(), (y - yy).toFloat()))
            worst = maxOf(worst, abs(best - fast[y * w + x]))
        }
        assertTrue("EDT lệch $worst", worst < 1e-3f)
    }

    @Test fun boxBlurMatchesNaiveClampedAverage() {
        val w = 13
        val h = 9
        val f = FloatArray(w * h) { ((it * 37) % 101) / 100f }
        val r = 2
        val got = HairVolume.boxBlur(f, w, h, r)
        for (y in 0 until h) for (x in 0 until w) {
            var sum = 0f
            for (dy in -r..r) for (dx in -r..r) sum += f[(y + dy).coerceIn(0, h - 1) * w + (x + dx).coerceIn(0, w - 1)]
            assertEquals(sum / ((2 * r + 1) * (2 * r + 1)), got[y * w + x], 1e-4f)
        }
    }

    // ------------------------------------------------------------------ hiệu ứng trên đĩa tóc
    @Test fun discGrowsByGrowPixels() {
        val s = disc(300, 40f)
        val out = HairVolume.apply(s.px, s.w, s.h, s.mask, null, 1f)
        val grow = HairVolume.growPx(300, 300, 1f)                 // 6 px
        assertEquals(s.r + grow, effectiveRadius(out), 1.2f)
        assertTrue(out.count { closerToHair(it) } > s.px.count { closerToHair(it) } * 1.3)
    }

    @Test fun insideHairAndFarBackgroundAreUntouched() {
        val s = disc(300, 40f)
        val out = HairVolume.apply(s.px, s.w, s.h, s.mask, null, 1f)
        val grow = HairVolume.growPx(300, 300, 1f)
        for (y in 0 until s.h) for (x in 0 until s.w) {
            val i = y * s.w + x
            val rr = hypot(x - s.cx, y - s.cy)
            if (s.mask[i].toInt() != 0) assertEquals("trong tóc ($x,$y)", s.px[i], out[i])
            if (rr > s.r + grow * HairVolume.BAND_FACTOR + 2f) assertEquals("ngoài dải ($x,$y)", s.px[i], out[i])
        }
    }

    @Test fun ringCarriesHairTexture() {
        val s = disc(300, 40f)
        // kết cấu: kênh đỏ của tóc dao động 40 <-> 100 theo cột
        for (y in 0 until s.h) for (x in 0 until s.w) {
            val i = y * s.w + x
            if (s.mask[i].toInt() != 0) s.px[i] = (s.px[i] and 0xFF00FFFF.toInt()) or ((if ((x / 3) % 2 == 0) 100 else 40) shl 16)
        }
        val out = HairVolume.apply(s.px, s.w, s.h, s.mask, null, 1f)
        val grow = HairVolume.growPx(300, 300, 1f)
        var lo = 255
        var hi = 0
        for (y in 0 until s.h) for (x in 0 until s.w) {
            val rr = hypot(x - s.cx, y - s.cy)
            if (rr > s.r + 1f && rr < s.r + grow - 1f) {
                val red = (out[y * s.w + x] shr 16) and 255
                lo = minOf(lo, red); hi = maxOf(hi, red)
            }
        }
        assertTrue("vành mới phải mang kết cấu tóc (đỏ $lo..$hi), không phải nền phẳng 210", lo < 70 && hi > 80 && hi < 150)
    }

    @Test fun protectedRegionIsNotCovered() {
        val s = disc(200, 40f)
        val protect = ByteArray(200 * 200) { if (it % 200 < 100) 255.toByte() else 0 }       // nửa trái được bảo vệ
        val out = HairVolume.apply(s.px, s.w, s.h, s.mask, protect, 1f)
        for (y in 0 until 200) for (x in 0 until 93) {
            if (hypot(x - s.cx, y - s.cy) > s.r + 0.5f) assertEquals("bảo vệ ($x,$y)", s.px[y * 200 + x], out[y * 200 + x])
        }
        val grow = HairVolume.growPx(200, 200, 1f)
        var grown = 0
        var total = 0
        for (y in 0 until 200) for (x in 107 until 200) {
            val rr = hypot(x - s.cx, y - s.cy)
            if (rr > s.r + 0.5f && rr < s.r + grow - 0.5f) { total++; if (closerToHair(out[y * 200 + x])) grown++ }
        }
        assertTrue("nửa phải phải vẫn phồng ($grown/$total)", total > 0 && grown > total * 0.85)
    }

    // ------------------------------------------------------------------ không làm gì / biên
    @Test fun noOpCasesReturnEqualCopies() {
        val s = disc(120, 25f)
        val cases = listOf(
            HairVolume.apply(s.px, s.w, s.h, s.mask, null, 0f),
            HairVolume.apply(s.px, s.w, s.h, s.mask, null, 0.1f),                 // grow < 0,75 px
            HairVolume.apply(s.px, s.w, s.h, s.mask, null, Float.NaN),
            HairVolume.apply(s.px, s.w, s.h, ByteArray(s.w * s.h), null, 1f),     // mặt nạ rỗng
            HairVolume.apply(s.px, s.w, s.h, ByteArray(s.w * s.h) { 255.toByte() }, null, 1f)   // phủ kín
        )
        for (c in cases) {
            assertNotSame(s.px, c)
            assertTrue(s.px.contentEquals(c))
        }
        val tiny = intArrayOf(1, 2, 3, 4)
        assertTrue(tiny.contentEquals(HairVolume.apply(tiny, 2, 2, ByteArray(4) { 255.toByte() }, null, 1f)))
        assertTrue(s.px.contentEquals(HairVolume.apply(s.px, s.w, s.h, ByteArray(3), null, 1f)))   // sai kích thước mặt nạ -> không đổi, không ném lỗi
    }

    @Test fun alphaIsPreserved() {
        val s = disc(150, 30f)
        for (i in s.px.indices) s.px[i] = (s.px[i] and 0x00FFFFFF) or (0xCC shl 24)
        val out = HairVolume.apply(s.px, s.w, s.h, s.mask, null, 1f)
        assertTrue(out.all { (it ushr 24) == 0xCC })
    }

    // ------------------------------------------------------------------ luật tiếng Việt / Anh + phép chỉnh
    @Test fun plannerRecognisesHairVolumeRequests() {
        for (q in listOf("làm tóc phồng hơn", "tóc dày hơn", "tăng volume tóc", "make my hair fuller", "add hair volume")) {
            val p = RuleBasedPlanner.plan(q)
            val sc = p.scoped.firstOrNull { it.scope == Scope.HAIR }
            assertNotNull("'$q' phải ra phép tóc phồng", sc)
            val op = sc!!.ops.single()
            assertEquals(q, OpType.HAIR_VOLUME, op.type)
            assertTrue(q, op.value > 0f && op.value <= 1f)
        }
    }

    @Test fun plannerKeepsOtherHairRequestsUnchanged() {
        val dye = RuleBasedPlanner.plan("nhuộm tóc màu đỏ").scoped.firstOrNull { it.scope == Scope.HAIR }
        assertEquals(OpType.COLORIZE, dye!!.ops.single().type)
        val shine = RuleBasedPlanner.plan("tóc bóng mượt").scoped.firstOrNull { it.scope == Scope.HAIR }
        assertTrue(shine!!.ops.none { it.type == OpType.HAIR_VOLUME })
        assertTrue(RuleBasedPlanner.plan("làm sáng ảnh").scoped.none { s -> s.ops.any { it.type == OpType.HAIR_VOLUME } })
        // từ gần giống nhưng KHÔNG phải phồng/dày: "phong cách", "xù" (rối), "tóc xuống vai"
        for (q in listOf("tóc phong cách Hàn Quốc", "tóc xù quá", "tóc xuống vai")) {
            assertTrue(q, RuleBasedPlanner.plan(q).scoped.none { s -> s.ops.any { it.type == OpType.HAIR_VOLUME } })
        }
    }

    @Test fun hairVolumeOpTypeBehaviour() {
        assertEquals(OpType.HAIR_VOLUME, OpType.fromKey("hair_volume"))
        assertEquals(1f, EditOp(OpType.HAIR_VOLUME, 5f).sanitized()!!.value, 0f)
        assertNull(EditOp(OpType.HAIR_VOLUME, 0f).sanitized())
        assertEquals("Tóc phồng 60%", EditOp(OpType.HAIR_VOLUME, 0.6f).describe())
        assertTrue(OpType.HAIR_VOLUME.scalable)
    }
}
