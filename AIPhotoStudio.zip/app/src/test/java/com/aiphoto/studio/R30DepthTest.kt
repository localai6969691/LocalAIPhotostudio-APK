package com.aiphoto.studio

import com.aiphoto.studio.engine.DepthProfile
import com.aiphoto.studio.engine.Reframe
import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.Routing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * R30: model đo độ sâu TÙY CHỌN cho Reframe 2.5D — cỡ vào / chuẩn hóa của [DepthProfile], kéo giãn bất biến theo thang [Reframe.stretch],
 * dựng [Reframe.Depth] từ độ sâu do model đo [Reframe.depthFromField], và nối định tuyến `depth_estimate`.
 * Mọi khẳng định đã được kiểm bằng bản port Python (`tools/verify_ports/depth_field.py`) với cùng cảnh tổng hợp và cùng ngưỡng.
 * Phần chạy model ONNX thật ([com.aiphoto.studio.engine.DepthEstimator]) KHÔNG kiểm được trên JVM (cần ONNX Runtime + model).
 */
class R30DepthTest {

    // ------------------------------------------------------------------ tiện ích
    private val W = 160
    private val H = 120

    private fun scenePixels(): IntArray = IntArray(W * H) {
        val x = it % W
        val y = it / W
        (0xFF shl 24) or ((90 + x % 7) shl 16) or ((150 + y % 5) shl 8) or 200
    }

    /** Nghịch đảo độ sâu giả lập của model: càng xuống thấp càng gần; thang và gốc tùy ý. */
    private fun ramp(fw: Int, fh: Int, scale: Float = 6f, offset: Float = 2f): FloatArray =
        FloatArray(fw * fh) { (it / fw).toFloat() / (fh - 1) * scale + offset }

    private fun rowMeans(d: FloatArray, w: Int, h: Int): FloatArray = FloatArray(h) { y ->
        var s = 0.0
        for (x in 0 until w) s += d[y * w + x]
        (s / w).toFloat()
    }

    private fun isNonDecreasing(v: FloatArray, tol: Float): Boolean {
        for (i in 1 until v.size) if (v[i] < v[i - 1] - tol) return false
        return true
    }

    /** ~N(5, 2) tất định (tổng 12 số đều − 6). */
    private fun gaussianish(n: Int, seed: Int): FloatArray {
        val rnd = Random(seed)
        return FloatArray(n) {
            var s = 0f
            repeat(12) { s += rnd.nextFloat() }
            5f + 2f * (s - 6f)
        }
    }

    private fun maxAbsDiff(a: FloatArray, b: FloatArray): Float {
        var m = 0f
        for (i in a.indices) m = max(m, abs(a[i] - b[i]))
        return m
    }

    // ------------------------------------------------------------------ DepthProfile.inputSize
    @Test fun inputSizeIsMultipleOfPatchWithLongEdge518() {
        val cases = listOf(
            Triple(3000, 4000, Pair(392, 518)), Triple(4000, 3000, Pair(518, 392)), Triple(1080, 1920, Pair(294, 518)),
            Triple(600, 600, Pair(518, 518)), Triple(120, 160, Pair(392, 518)), Triple(100, 4000, Pair(14, 518)),
            Triple(4000, 100, Pair(518, 14)), Triple(1, 1, Pair(518, 518)), Triple(37, 41, Pair(462, 518))
        )
        for (c in cases) {
            val s = DepthProfile.inputSize(c.first, c.second, 0, 0)
            assertEquals("cỡ vào của ${c.first}x${c.second}", c.third, s)
            assertEquals(0, s.first % DepthProfile.PATCH)
            assertEquals(0, s.second % DepthProfile.PATCH)
        }
    }

    @Test fun inputSizeFollowsFixedShapeAndCustomLongEdge() {
        assertEquals(Pair(518, 518), DepthProfile.inputSize(4000, 3000, 518, 518))
        assertEquals(Pair(518, 518), DepthProfile.inputSize(3000, 4000, 518, 518))
        assertEquals(Pair(392, 700), DepthProfile.inputSize(100, 100, 392, 700))
        assertEquals("cạnh dài tùy chỉnh cho máy yếu", Pair(294, 392), DepthProfile.inputSize(3000, 4000, 0, 0, 392))
        assertEquals("cạnh dài nhỏ hơn một mảnh được nâng lên một mảnh", Pair(DepthProfile.PATCH, DepthProfile.PATCH), DepthProfile.inputSize(500, 500, 0, 0, 3))
        // chỉ MỘT chiều cố định (bất thường): coi như động, vẫn là bội của 14 và không ném lỗi
        val odd = DepthProfile.inputSize(1000, 2000, 518, 0)
        assertEquals(0, odd.first % DepthProfile.PATCH)
        assertEquals(0, odd.second % DepthProfile.PATCH)
    }

    // ------------------------------------------------------------------ DepthProfile.toNchw
    @Test fun toNchwNormalizesImageNetInRgbOrder() {
        val px = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt())
        val t = DepthProfile.toNchw(px)
        val plane = px.size
        assertEquals(3 * plane, t.size)
        for (c in 0..2) {
            assertEquals("trắng, kênh $c", (1f - DepthProfile.MEAN[c]) / DepthProfile.STD[c], t[c * plane + 0], 1e-4f)
            assertEquals("đen, kênh $c", -DepthProfile.MEAN[c] / DepthProfile.STD[c], t[c * plane + 1], 1e-4f)
        }
        assertTrue("đỏ thuần: kênh R cao", t[0 * plane + 2] > 2f)
        assertTrue("đỏ thuần: kênh G thấp", t[1 * plane + 2] < -1.9f)
        assertTrue("đỏ thuần: kênh B thấp", t[2 * plane + 2] < -1.7f)
        assertTrue("xanh lá thuần: kênh G cao", t[1 * plane + 3] > 2f && t[0 * plane + 3] < -1.9f)
        assertTrue("xanh dương thuần: kênh B cao", t[2 * plane + 4] > 2f && t[0 * plane + 4] < -1.9f)
    }

    // ------------------------------------------------------------------ Reframe.stretch
    @Test fun stretchOutputsUnitRangeClippingAboutTwoPercentPerEnd() {
        val v = gaussianish(5000, 7)
        val s = Reframe.stretch(v)!!
        assertEquals(v.size, s.size)
        assertTrue(s.all { it in 0f..1f })
        val lo = s.count { it == 0f } / s.size.toFloat()
        val hi = s.count { it == 1f } / s.size.toFloat()
        assertTrue("khoảng 2% bị kẹp ở đầu thấp: $lo", lo in 0.015f..0.06f)
        assertTrue("khoảng 2% bị kẹp ở đầu cao: $hi", hi in 0.015f..0.06f)
    }

    @Test fun stretchIsInvariantToScaleAndOffset() {
        val v = gaussianish(5000, 7)
        val s0 = Reframe.stretch(v)!!
        for ((a, b) in listOf(Pair(3.5f, -12f), Pair(0.2f, 40f), Pair(40f, 25f), Pair(1f, 0f), Pair(0.05f, -3f))) {
            val s = Reframe.stretch(FloatArray(v.size) { v[it] * a + b })!!
            assertTrue("a=$a b=$b lệch ${maxAbsDiff(s, s0)}", maxAbsDiff(s, s0) < 1e-4f)
        }
    }

    @Test fun stretchFlipsWhenModelOutputIsInverted() {
        // hợp đồng "lớn = gần" phụ thuộc chiều đầu ra của model: đảo dấu thì kết quả đảo (1 − s) — nên phải dùng đúng loại model (nghịch đảo độ sâu)
        val v = gaussianish(5000, 7)
        val s = Reframe.stretch(v)!!
        val f = Reframe.stretch(FloatArray(v.size) { -v[it] })!!
        for (i in s.indices) assertEquals(1f - s[i], f[i], 0.02f)
    }

    @Test fun stretchIgnoresAHugeOutlier() {
        val v = gaussianish(5000, 7)
        val s0 = Reframe.stretch(v)!!
        val big = v.copyOf()
        big[0] = 1e6f
        val s = Reframe.stretch(big)!!
        for (i in 1 until v.size) assertEquals(s0[i], s[i], 0.02f)
    }

    @Test fun stretchRejectsFlatNonFiniteAndEmpty() {
        assertNull(Reframe.stretch(FloatArray(100) { 3f }))
        val rnd = Random(3)
        assertNull("biên độ 1e-6 coi là phẳng", Reframe.stretch(FloatArray(100) { 3f + 1e-6f * rnd.nextFloat() }))
        assertNull(Reframe.stretch(floatArrayOf(1f, Float.NaN, 3f)))
        assertNull(Reframe.stretch(floatArrayOf(1f, Float.POSITIVE_INFINITY, 3f)))
        assertNull(Reframe.stretch(FloatArray(0)))
    }

    @Test fun stretchAcceptsSmallAndLargeModelScales() {
        val rnd = Random(5)
        assertNotNull("thang 0..0.01", Reframe.stretch(FloatArray(500) { 0.01f * rnd.nextFloat() }))
        assertNotNull("thang 0..1e5", Reframe.stretch(FloatArray(500) { 1e5f * rnd.nextFloat() }))
    }

    // ------------------------------------------------------------------ Reframe.depthFromField (không chủ thể)
    @Test fun fieldWithoutSubjectOrdersNearAndFarAndCoversTheRange() {
        val fw = 74
        val fh = 56
        val d = Reframe.depthFromField(scenePixels(), W, H, Reframe.Field(ramp(fw, fh), fw, fh), null)!!
        assertEquals(W * H, d.d.size)
        assertTrue("từ model", d.fromModel)
        assertFalse(d.hasSubject)
        assertFalse("không dùng bộ nhận trời", d.hasSky)
        assertTrue(d.d.all { it in 0f..1f })
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in d.d) { lo = min(lo, v); hi = max(hi, v) }
        assertTrue("đáy dải: $lo", lo < 0.05f)
        assertTrue("đỉnh dải: $hi", hi > 0.95f)
        val rows = rowMeans(d.d, W, H)
        assertTrue("trên xa, dưới gần", isNonDecreasing(rows, 1e-3f))
        assertTrue("dải đủ rộng: ${rows[0]} → ${rows[H - 1]}", rows[H - 1] - rows[0] > 0.8f)
        assertEquals("không chủ thể: điểm xoay ≈ trung vị ảnh", 0.5f, d.focus, 0.1f)
    }

    @Test fun fieldDepthIsInvariantToModelScale() {
        val fw = 74
        val fh = 56
        val a = Reframe.depthFromField(scenePixels(), W, H, Reframe.Field(ramp(fw, fh), fw, fh), null)!!
        val b = Reframe.depthFromField(scenePixels(), W, H, Reframe.Field(ramp(fw, fh, 6f * 7.5f, 2f * 7.5f + 3f), fw, fh), null)!!
        assertTrue("lệch ${maxAbsDiff(a.d, b.d)}", maxAbsDiff(a.d, b.d) < 1e-3f)
    }

    @Test fun fieldOfAnyResolutionOrAspectGivesImageSizedMonotoneDepth() {
        for ((fw, fh) in listOf(Pair(518, 518), Pair(64, 64), Pair(200, 100), Pair(160, 120))) {
            val d = Reframe.depthFromField(scenePixels(), W, H, Reframe.Field(ramp(fw, fh, 4f, 1f), fw, fh), null)
            assertNotNull("field ${fw}x$fh", d)
            assertEquals(W * H, d!!.d.size)
            val rows = rowMeans(d.d, W, H)
            assertTrue("field ${fw}x$fh đơn điệu", isNonDecreasing(rows, 2e-3f))
            assertTrue("field ${fw}x$fh phủ dải", rows[H - 1] - rows[0] > 0.8f)
        }
    }

    @Test fun largeImageIsBuiltAtWorkSizeThenScaledBack() {
        val bw = 900
        val bh = 600
        val px = IntArray(bw * bh) { 0xFF808080.toInt() }
        val fw = bw / 4
        val fh = bh / 4
        val d = Reframe.depthFromField(px, bw, bh, Reframe.Field(ramp(fw, fh, 3f, 1f), fw, fh), null)!!
        assertEquals(bw * bh, d.d.size)
        assertTrue(d.d.all { it.isFinite() })
        assertTrue(isNonDecreasing(rowMeans(d.d, bw, bh), 2e-3f))
    }

    // ------------------------------------------------------------------ Reframe.depthFromField (có chủ thể)
    private class Subject(val field: FloatArray, val fw: Int, val fh: Int, val mask: FloatArray, val ell: BooleanArray, val core: BooleanArray)

    /** Chủ thể elip ở giữa; trong chủ thể model đo có độ lồi (mũi / má) cao tới +5 so với nền dốc nhẹ. */
    private fun subjectScene(): Subject {
        val fw = 74
        val fh = 56
        val cx = 80f
        val cy = 62f
        val rx = 22f
        val ry = 34f
        val field = FloatArray(fw * fh) {
            val sx = it % fw
            val sy = it / fw
            val ex = (sx + 0.5f) / fw * W
            val ey = (sy + 0.5f) / fh * H
            val b = max(0f, 1f - (((ex - cx) / rx) * ((ex - cx) / rx) + ((ey - cy) / ry) * ((ey - cy) / ry)))
            (sy.toFloat() / (fh - 1) * 2f + 3f) + 5f * b
        }
        val ell = BooleanArray(W * H)
        val core = BooleanArray(W * H)
        for (i in 0 until W * H) {
            val x = (i % W).toFloat()
            val y = (i / W).toFloat()
            ell[i] = ((x - cx) / rx) * ((x - cx) / rx) + ((y - cy) / ry) * ((y - cy) / ry) <= 1f
            core[i] = ((x - cx) / (rx * 0.6f)) * ((x - cx) / (rx * 0.6f)) + ((y - cy) / (ry * 0.6f)) * ((y - cy) / (ry * 0.6f)) <= 1f
        }
        return Subject(field, fw, fh, FloatArray(W * H) { if (ell[it]) 1f else 0f }, ell, core)
    }

    private fun stdOver(d: FloatArray, sel: BooleanArray): Float {
        var n = 0
        var s = 0.0
        for (i in d.indices) if (sel[i]) { n++; s += d[i] }
        val m = s / n
        var v = 0.0
        for (i in d.indices) if (sel[i]) v += (d[i] - m) * (d[i] - m)
        return sqrt(v / n).toFloat()
    }

    private fun medianOver(d: FloatArray, sel: BooleanArray): Float {
        val xs = ArrayList<Float>()
        for (i in d.indices) if (sel[i]) xs.add(d[i])
        xs.sort()
        return xs[xs.size / 2]
    }

    @Test fun subjectKeepsOnlyAFractionOfItsInnerDepthVariation() {
        val sc = subjectScene()
        val px = scenePixels()
        val none = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), null)!!
        val with = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), sc.mask)!!
        assertTrue(with.hasSubject)
        assertTrue(with.fromModel)
        val before = stdOver(none.d, sc.core)
        val after = stdOver(with.d, sc.core)
        assertEquals("tỉ lệ biến thiên còn lại ≈ SUBJECT_KEEP", Reframe.SUBJECT_KEEP, after / before, 0.06f)
    }

    /** Độ dốc (max |Δx|, |Δy|) của các điểm bên trong [sel] (cả ba điểm i, i+1, i+w đều trong). */
    private fun innerGradients(d: FloatArray, sel: BooleanArray): FloatArray {
        val out = ArrayList<Float>()
        for (y in 0 until H - 1) for (x in 0 until W - 1) {
            val i = y * W + x
            if (sel[i] && sel[i + 1] && sel[i + W]) out.add(max(abs(d[i + 1] - d[i]), abs(d[i + W] - d[i])))
        }
        val a = out.toFloatArray()
        a.sort()
        return a
    }

    @Test fun reliefKeepOnALinearRampMatchesTheClosedForm() {
        val w = 120
        val h = 60
        val d = FloatArray(w * h) { (it % w) / 119f * 0.3f }
        val ins = FloatArray(w * h) { 1f }
        val slope = 0.3f / 119f
        for (sp in listOf(10f, 40f, 100f, 300f)) {
            val expected = if (sp * slope <= Reframe.MAX_CRACK) 1f else Reframe.MAX_CRACK / (sp * slope)
            val got = Reframe.reliefKeep(d, ins, w, h, sp)
            assertTrue("dịch $sp: ra $got, giải tích $expected", got <= expected * 1.0005f && got >= expected * 0.98f)
        }
        assertEquals("mặt phẳng giữ nguyên", 1f, Reframe.reliefKeep(FloatArray(w * h) { 0.4f }, ins, w, h, 80f), 0f)
        assertEquals("không có độ dịch: dự phòng", Reframe.SUBJECT_KEEP, Reframe.reliefKeep(d, ins, w, h, 0f), 0f)
    }

    @Test fun smallShiftKeepsTheReliefAndLargeShiftFlattensItWithinTheCrackTolerance() {
        val sc = subjectScene()
        val px = scenePixels()
        val field = Reframe.Field(sc.field, sc.fw, sc.fh)
        val none = Reframe.depthFromField(px, W, H, field, null)!!
        val before = stdOver(none.d, sc.core)
        val ratios = HashMap<Float, Float>()
        val sel = BooleanArray(W * H) { sc.ell[it] && abs((it % W) - 80) < 22 - 3 && abs((it / W) - 62) < 34 - 3 }
        for (sp in listOf(0.5f, 2f, 8f, 24f, 48f, 96f)) {
            val with = Reframe.depthFromField(px, W, H, field, sc.mask, sp)!!
            ratios[sp] = stdOver(with.d, sc.core) / before
            val g = innerGradients(with.d, sel)
            val exact99 = g[((g.size - 1) * 0.99f).toInt()]
            if (ratios[sp]!! < 0.999f) assertTrue("dịch $sp: dốc p99 × dịch = ${sp * exact99} > MAX_CRACK", sp * exact99 <= Reframe.MAX_CRACK * 1.001f)
        }
        assertTrue("dịch nhỏ giữ độ lồi: ${ratios[0.5f]}", ratios[0.5f]!! >= 0.95f)
        assertTrue("dịch lớn làm phẳng mạnh: ${ratios[96f]}", ratios[96f]!! in 0.0001f..0.5f)
        val order = listOf(0.5f, 2f, 8f, 24f, 48f, 96f)
        for (i in 1 until order.size) assertTrue("tỉ lệ giữ không tăng theo độ dịch", ratios[order[i]]!! <= ratios[order[i - 1]]!! + 0.01f)
    }

    @Test fun subjectLeavesTheOutsideUntouched() {
        val sc = subjectScene()
        val px = scenePixels()
        val none = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), null)!!
        val with = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), sc.mask)!!
        // "ngoài" = ngoài elip nới thêm 2 điểm mỗi phía: mép mặt nạ qua bộ lọc dẫn hướng có thể lệch ≤ 1 điểm, không tính vào đây
        var m = 0f
        for (i in 0 until W * H) {
            val x = (i % W).toFloat()
            val y = (i / W).toFloat()
            val far = ((x - 80f) / (22f + 2f)) * ((x - 80f) / (22f + 2f)) + ((y - 62f) / (34f + 2f)) * ((y - 62f) / (34f + 2f)) > 1f
            if (far) m = max(m, abs(with.d[i] - none.d[i]))
        }
        assertTrue("ngoài chủ thể lệch $m", m < 1e-6f)
    }

    @Test fun focusIsTheMedianDepthOverTheWholeSubjectMask() {
        val sc = subjectScene()
        val px = scenePixels()
        val none = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), null)!!
        val with = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), sc.mask)!!
        val wholeMask = medianOver(none.d, sc.ell)
        val coreMedian = medianOver(none.d, sc.core)
        assertEquals("điểm xoay ≈ trung vị toàn mặt nạ", wholeMask, with.focus, 0.06f)
        assertTrue("lõi nhô cao hơn trung vị toàn mặt nạ (phân biệt hai vùng)", coreMedian - wholeMask > 0.1f)
        // nền ngay sát mép ngoài chủ thể (cách tâm 24..28 điểm theo ngang, ±4 hàng quanh tâm), trung bình như bản port Python
        var sum = 0.0
        var cnt = 0
        for (y in 0 until H) for (x in 0 until W) {
            val i = y * W + x
            if (!sc.ell[i] && abs(x - 80) < 22 + 6 && abs(x - 80) > 22 + 2 && abs(y - 62) < 4) { sum += none.d[i]; cnt++ }
        }
        assertTrue(cnt > 0)
        assertTrue("chủ thể nhô gần hơn nền sát mép ngoài: ${with.focus} vs ${sum / cnt}", with.focus > (sum / cnt).toFloat())
    }

    @Test fun tinyOrMismatchedSubjectMaskIsIgnored() {
        val sc = subjectScene()
        val px = scenePixels()
        val tiny = FloatArray(W * H)
        for (y in 10 until 14) for (x in 10 until 14) tiny[y * W + x] = 1f
        assertFalse("chủ thể < SUBJECT_MIN_AREA", Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), tiny)!!.hasSubject)
        val bad = Reframe.depthFromField(px, W, H, Reframe.Field(sc.field, sc.fw, sc.fh), FloatArray(7) { 1f })
        assertNotNull(bad)
        assertFalse("mặt nạ sai cỡ bị bỏ qua", bad!!.hasSubject)
    }

    // ------------------------------------------------------------------ field hỏng → null (người gọi quay về độ sâu giả)
    @Test fun brokenFieldsAreRejected() {
        val px = scenePixels()
        val fw = 74
        val fh = 56
        val good = ramp(fw, fh)
        assertNull("phẳng", Reframe.depthFromField(px, W, H, Reframe.Field(FloatArray(fw * fh) { 4f }, fw, fh), null))
        assertNull("sai kích thước", Reframe.depthFromField(px, W, H, Reframe.Field(good.copyOf(good.size - 1), fw, fh), null))
        val nan = good.copyOf()
        nan[5] = Float.NaN
        assertNull("NaN", Reframe.depthFromField(px, W, H, Reframe.Field(nan, fw, fh), null))
        assertNull("cỡ 0", Reframe.depthFromField(px, W, H, Reframe.Field(good, 0, fh), null))
    }

    // ------------------------------------------------------------------ nối với phần dịch / mô tả của Reframe
    @Test fun modelDepthFeedsRenderAndDescribeSaysSo() {
        val fw = 74
        val fh = 56
        val px = scenePixels()
        val d = Reframe.depthFromField(px, W, H, Reframe.Field(ramp(fw, fh), fw, fh), null)!!
        val r = Reframe.render(px, W, H, d, 12f, 0f)
        assertNotNull("độ sâu do model đo phải đủ thị sai để render", r)
        assertEquals(W * H, r!!.px.size)
        assertTrue("phóng để che viền", r.zoom > 1f)
        assertTrue("vùng lộ ra không chiếm phần lớn khung: ${r.holeFrac}", r.holeFrac < 0.2f)
        val text = Reframe.describe(0.5f, 0f, 1f, r, d)
        assertTrue(text, text.contains("do model đo"))
        // độ sâu giả (R29) giữ nguyên câu cũ và cờ mặc định false
        val fake = Reframe.Depth(FloatArray(4), 0f, false, false, 0f)
        assertFalse(fake.fromModel)
        val fakeText = Reframe.describe(0.5f, 0f, 1f, r, fake)
        assertFalse(fakeText, fakeText.contains("model"))
        assertTrue(fakeText, fakeText.contains("không thấy chủ thể"))
    }

    // ------------------------------------------------------------------ định tuyến
    private fun defaultRouting() =
        Routing.parse(java.io.File("app/src/main/assets/routing_default.json").let { if (it.exists()) it else java.io.File("../app/src/main/assets/routing_default.json") }.readText())

    @Test fun defaultRoutingVersionIsBumpedSoStoredConfigsGetTheDepthTask() {
        // Routing chỉ thay cấu hình đã lưu khi stored.version < default.version: thêm tác vụ depth_estimate mà không tăng version thì máy cũ không bao giờ nhận được
        val cfg = defaultRouting()
        assertTrue("version phải ≥ 7 (R30 thêm depth_estimate, R30f đổi sang cạnh thích nghi): ${cfg.version}", cfg.version >= 7)
        assertTrue(cfg.tasks.containsKey("depth_estimate"))
    }

    @Test fun depthOnnxIsAKnownKind() {
        assertTrue("depth_onnx" in Routing.KNOWN_KINDS)
    }

    @Test fun defaultRoutingHasNoRamTierForDepthAndNeedsTheModelFile() {
        val cfg = defaultRouting()
        val has = { t: String -> t == "file:depth.onnx" }
        // R30f: cạnh vào không còn chọn theo RAM — mọi máy cùng một nhà cung cấp; edge chỉ là TRẦN và budget_ms là ngân sách thời gian, cạnh thật do Adaptive học
        for (ram in listOf(3000, 6000, 12000)) {
            val chain = Routing.chain(cfg, "depth_estimate", DeviceInfo(ram, "", 33, 8), "pro", has)
            assertEquals("RAM $ram", listOf("depth_adaptive"), chain.map { it.id })
            assertEquals("518", chain.first().params["edge"])
            assertEquals("3000", chain.first().params["budget_ms"])
        }
        assertTrue("chưa nạp tệp model thì không có nhà cung cấp", Routing.chain(cfg, "depth_estimate", DeviceInfo(8000, "", 33, 8), "pro") { false }.isEmpty())
        assertTrue("mọi nhà cung cấp đều cần đúng tệp depth.onnx", cfg.tasks["depth_estimate"].orEmpty().all { it.kind == "depth_onnx" && it.needs == listOf("file:depth.onnx") })
    }
}
