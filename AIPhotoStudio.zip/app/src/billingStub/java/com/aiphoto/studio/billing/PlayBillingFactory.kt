package com.aiphoto.studio.billing

import android.app.Activity
import android.content.Context

/** Bản mặc định: chưa bật thanh toán. Build với -PuseBilling=true để dùng Google Play Billing thật. */
object PlayBillingFactory {
    fun create(@Suppress("UNUSED_PARAMETER") context: Context): BillingGateway = NoBilling
}

private object NoBilling : BillingGateway {
    override val available = false
    override fun connect(onReady: () -> Unit, onError: (String) -> Unit) = onError("Thanh toán chưa bật trong bản build này (build với -PuseBilling=true).")
    override fun products(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit) = onResult(emptyList())
    override fun purchase(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit) =
        onResult(BillingEvent.Error("Thanh toán chưa bật trong bản build này."))
    override fun unconsumed(onResult: (List<Pair<String, String>>) -> Unit) = onResult(emptyList())
    override fun consume(token: String, onDone: (Boolean) -> Unit) = onDone(false)
    override fun subscriptions(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit) = onResult(emptyList())
    override fun purchaseSubscription(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit) =
        onResult(BillingEvent.Error("Thanh toán chưa bật trong bản build này."))
    override fun activeSubscriptions(onResult: (List<Pair<String, String>>) -> Unit) = onResult(emptyList())
    override fun acknowledge(token: String, onDone: (Boolean) -> Unit) = onDone(false)
    override fun close() {}
}
