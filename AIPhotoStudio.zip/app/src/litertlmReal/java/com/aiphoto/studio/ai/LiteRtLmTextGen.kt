package com.aiphoto.studio.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig

/**
 * LiteRT-LM (Google AI Edge): gói Maven chính thức com.google.ai.edge.litertlm:litertlm-android, Kotlin API "Stable" theo tài liệu
 * (cập nhật 09/2026). Chạy model .litertlm (Gemma 3 1B, Gemma 3n E2B/E4B, Gemma 4 E2B/E4B - Gemma 4 giấy phép Apache-2.0),
 * thử GPU rồi rơi về CPU; model đa phương thức nhận ẢNH (Content.ImageFile). Mẫu hội thoại do chính tệp .litertlm áp, nên
 * [generate] gửi nội dung thuần. Mỗi lần gọi mở một Conversation mới (không tích lũy lịch sử).
 * Chữ ký API đối chiếu trang "Get Started with LiteRT-LM on Android"; CHƯA biên dịch/chạy thử (xem A89-A92 trong PROJECT_STATUS.md).
 * NPU (Backend.NPU): chỉ thử khi tệp model được biên dịch sẵn cho đúng SoC của máy ([AcceleratorPolicy]); cần thư viện NPU runtime trong app
 * (xem PROJECT_STATUS.md 8.10) - thiếu thư viện thì khởi tạo NPU lỗi và rơi về nấc kế tiếp.
 */
class LiteRtLmTextGen private constructor(
    private val engine: Engine,
    override val supportsImage: Boolean,
    override val backendName: String
) : TextGen {

    @Synchronized
    override fun generate(prompt: String, imagePath: String?): String {
        require(imagePath == null || supportsImage) { "Model/backend này không nhận ảnh." }
        val contents = if (imagePath == null) {
            Contents.of(Content.Text(prompt))
        } else {
            Contents.of(Content.ImageFile(imagePath), Content.Text(prompt))
        }
        // Nhiệt độ thấp: cần JSON ổn định, không cần sáng tạo
        val config = ConversationConfig(samplerConfig = SamplerConfig(topK = 10, topP = 0.95, temperature = 0.2))
        val reply = engine.createConversation(config).use { conversation -> conversation.sendMessage(contents) }
        return reply.text.orEmpty()
    }

    override fun close() {
        try { engine.close() } catch (e: Throwable) { }
    }

    companion object {
        /**
         * Khởi tạo có thể mất tới ~10 giây -> gọi ngoài luồng giao diện. Thử lần lượt: [tryNpu] -> NPU (Backend.NPU không nêu hãng; LiteRT chọn bộ điều phối
         * Qualcomm / MediaTek / Google Tensor / Samsung... theo thiết bị; cần tệp biên dịch cho đúng SoC và thư viện NPU trong thư mục native của app),
         * GPU + bộ mã hóa ảnh GPU (model đa phương thức) -> GPU chỉ văn bản -> CPU chỉ văn bản. Model chỉ-văn-bản (vd. Gemma 3 1B) sẽ rơi xuống nấc GPU/CPU
         * chỉ văn bản và [supportsImage] = false. [backendName] ghi nấc đã chạy được.
         */
        fun open(context: Context, modelPath: String, tryNpu: Boolean = false): LiteRtLmTextGen {
            val cache = context.cacheDir.path
            val attempts = ArrayList<Triple<() -> EngineConfig, Boolean, String>>()
            if (tryNpu) {
                attempts.add(Triple({ EngineConfig(modelPath = modelPath, backend = Backend.NPU(nativeLibraryDir = context.applicationInfo.nativeLibraryDir), cacheDir = cache) }, false, "NPU"))
            }
            attempts.add(Triple({ EngineConfig(modelPath = modelPath, backend = Backend.GPU(), visionBackend = Backend.GPU(), cacheDir = cache) }, true, "GPU"))
            attempts.add(Triple({ EngineConfig(modelPath = modelPath, backend = Backend.GPU(), cacheDir = cache) }, false, "GPU"))
            attempts.add(Triple({ EngineConfig(modelPath = modelPath, backend = Backend.CPU(), cacheDir = cache) }, false, "CPU"))
            var last: Throwable? = null
            for ((makeConfig, withVision, name) in attempts) {
                var engine: Engine? = null
                try {
                    engine = Engine(makeConfig())
                    engine.initialize()
                    return LiteRtLmTextGen(engine, withVision, name)
                } catch (e: Throwable) {
                    last = e
                    try { engine?.close() } catch (e2: Throwable) { }
                }
            }
            val hint = if (tryNpu) " (tệp này được biên dịch cho NPU của máy; khởi tạo NPU lỗi - bản build có thư viện NPU runtime chưa? xem PROJECT_STATUS.md 8.10)" else ""
            throw IllegalStateException("Không khởi tạo được LiteRT-LM: ${last?.message ?: last?.javaClass?.simpleName}$hint", last)
        }
    }
}
