package com.aiphoto.studio.ai

import android.content.Context
import android.os.Build

object LiteRtLmFactory {
    /**
     * [modelName] = tên tệp GỐC của model (xem LlmBackends.originalName). NPU chỉ được thử khi đó là bản biên dịch sẵn cho ĐÚNG SoC của máy
     * này ([AcceleratorPolicy]); mã không nêu hãng chip nào - LiteRT tự chọn bộ điều phối theo thiết bị.
     */
    fun create(context: Context, modelPath: String, modelName: String?): TextGen? {
        val npu = AcceleratorPolicy.mayUseNpu(Build.VERSION.SDK_INT, Build.SUPPORTED_ABIS.toList(), modelName, Build.SOC_MODEL)
        return LiteRtLmTextGen.open(context, modelPath, npu)
    }
}
