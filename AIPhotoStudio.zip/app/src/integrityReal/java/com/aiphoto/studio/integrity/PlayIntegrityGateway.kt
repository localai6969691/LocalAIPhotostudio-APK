package com.aiphoto.studio.integrity

import android.content.Context
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.StandardIntegrityManager
import com.google.android.play.core.integrity.StandardIntegrityManager.PrepareIntegrityTokenRequest
import com.google.android.play.core.integrity.StandardIntegrityManager.StandardIntegrityTokenProvider
import com.google.android.play.core.integrity.StandardIntegrityManager.StandardIntegrityTokenRequest

/**
 * Play Integrity API — yêu cầu CHUẨN (developer.android.com/google/play/integrity/standard, tra cứu 03/11/2026): chuẩn bị nhà cung cấp token MỘT lần với số dự án
 * Cloud, giữ trong bộ nhớ, rồi mỗi lần cần thì `request()` kèm requestHash. Nhà cung cấp có thể hết hạn (lỗi INTEGRITY_TOKEN_PROVIDER_INVALID): cách xử lý
 * theo tài liệu là chuẩn bị lại — ở đây, khi xin token lỗi bất kỳ thì bỏ nhà cung cấp, chuẩn bị lại và thử đúng MỘT lần nữa (không tham chiếu hằng mã lỗi
 * để khỏi phụ thuộc tên chưa kiểm). Mỗi ứng dụng chỉ được chuẩn bị tối đa 5 lần/phút ⇒ [IntegrityCoordinator] chặn chứng thực dồn dập.
 */
class PlayIntegrityGateway(context: Context, private val cloudProject: Long) : IntegrityGateway {
    private val manager: StandardIntegrityManager = IntegrityManagerFactory.createStandard(context.applicationContext)
    @Volatile private var provider: StandardIntegrityTokenProvider? = null

    override val available: Boolean get() = cloudProject > 0L

    private fun prepare(then: (StandardIntegrityTokenProvider?, String?) -> Unit) {
        manager.prepareIntegrityToken(PrepareIntegrityTokenRequest.builder().setCloudProjectNumber(cloudProject).build())
            .addOnSuccessListener { p -> provider = p; then(p, null) }
            .addOnFailureListener { e -> then(null, e.message ?: e.javaClass.simpleName) }
    }

    override fun requestToken(requestHash: String, onResult: (String?, String?) -> Unit) {
        if (!available) { onResult(null, "Chưa cấu hình số dự án Google Cloud (-PintegrityCloudProject)."); return }
        val p = provider
        if (p != null) send(p, requestHash, true, onResult)
        else prepare { np, err -> if (np == null) onResult(null, err) else send(np, requestHash, false, onResult) }
    }

    private fun send(p: StandardIntegrityTokenProvider, hash: String, mayRetry: Boolean, onResult: (String?, String?) -> Unit) {
        p.request(StandardIntegrityTokenRequest.builder().setRequestHash(hash).build())
            .addOnSuccessListener { r -> onResult(r.token(), null) }
            .addOnFailureListener { e ->
                val why = e.message ?: e.javaClass.simpleName
                if (!mayRetry) { onResult(null, why); return@addOnFailureListener }
                provider = null
                prepare { np, err -> if (np == null) onResult(null, err ?: why) else send(np, hash, false, onResult) }
            }
    }
}
