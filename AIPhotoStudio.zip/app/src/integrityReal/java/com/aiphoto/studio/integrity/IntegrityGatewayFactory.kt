package com.aiphoto.studio.integrity

import android.content.Context
import android.content.pm.PackageManager

object IntegrityGatewayFactory {
    /** Số dự án Google Cloud đọc từ meta-data `integrity.cloud_project` (đặt bằng -PintegrityCloudProject=<số>, lưu kèm tiền tố "n"); thiếu / 0 ⇒ cổng báo không khả dụng. */
    fun create(context: Context): IntegrityGateway {
        val num = runCatching {
            @Suppress("DEPRECATION")
            val md = context.packageManager.getApplicationInfo(context.packageName, PackageManager.GET_META_DATA).metaData
            md?.get("integrity.cloud_project")?.toString()?.removePrefix("n")?.toLongOrNull() ?: 0L
        }.getOrDefault(0L)
        return PlayIntegrityGateway(context, num)
    }
}
