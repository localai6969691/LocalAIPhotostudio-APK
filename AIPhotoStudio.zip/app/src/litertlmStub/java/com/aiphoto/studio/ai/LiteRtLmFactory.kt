package com.aiphoto.studio.ai

import android.content.Context

/** Bản mặc định: chưa bật LiteRT-LM (không thêm thư viện). Build với -PuseLiteRtLm=true để chạy model .litertlm (Gemma 3n / Gemma 4). */
object LiteRtLmFactory {
    @Suppress("UNUSED_PARAMETER")
    fun create(context: Context, modelPath: String, modelName: String?): TextGen? = null
}
