package com.aiphoto.studio.integrity

import android.content.Context

/** Bản mặc định: chưa bật chứng thực. Build với -PuseIntegrity=true -PintegrityCloudProject=<số> để dùng Play Integrity thật. */
object IntegrityGatewayFactory {
    fun create(@Suppress("UNUSED_PARAMETER") context: Context): IntegrityGateway = NoIntegrity
}

private object NoIntegrity : IntegrityGateway {
    override val available = false
    override fun requestToken(requestHash: String, onResult: (String?, String?) -> Unit) =
        onResult(null, "Chứng thực Play Integrity chưa bật trong bản build này (build với -PuseIntegrity=true).")
}
