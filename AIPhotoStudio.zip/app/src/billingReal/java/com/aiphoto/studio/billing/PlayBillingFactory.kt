package com.aiphoto.studio.billing

import android.content.Context

object PlayBillingFactory {
    fun create(context: Context): BillingGateway = PlayBilling(context)
}
