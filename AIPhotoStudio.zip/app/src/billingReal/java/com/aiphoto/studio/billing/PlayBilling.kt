package com.aiphoto.studio.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams

/**
 * Google Play Billing Library 8.x, dùng artifact JAVA `billing` (KHÔNG dùng billing-ktx: từ 8.1 nó build bằng Kotlin 2.2,
 * dự án đang dùng Kotlin 1.9.24 nên sẽ lỗi metadata). Mua MỘT LẦN, TIÊU THỤ được (credits / "N ngày Pro"):
 * mua -> backend /v1/billing/redeem xác minh -> consume để mua lại được. Chữ ký API đối chiếu tài liệu chính thức PBL 8
 * (queryProductDetailsAsync trả QueryProductDetailsResult); CHƯA biên dịch/chạy thử trên máy thật.
 */
class PlayBilling(context: Context) : BillingGateway {

    override val available: Boolean = true

    private var listener: ((BillingEvent) -> Unit)? = null
    private val details = HashMap<String, ProductDetails>()

    private val client: BillingClient = BillingClient.newBuilder(context.applicationContext)
        .setListener { result, purchases -> onPurchasesUpdated(result, purchases) }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()

    override fun connect(onReady: () -> Unit, onError: (String) -> Unit) {
        if (client.isReady) {
            onReady()
            return
        }
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) onReady()
                else onError(result.debugMessage.ifBlank { "mã ${result.responseCode}" })
            }

            override fun onBillingServiceDisconnected() {
                // enableAutoServiceReconnection() tự kết nối lại ở lần gọi kế tiếp
            }
        })
    }

    override fun products(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit) {
        val list = ids.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(list).build()
        client.queryProductDetailsAsync(params) { result, queryResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onError(result.debugMessage.ifBlank { "mã ${result.responseCode}" })
            } else {
                val out = queryResult.productDetailsList.map { pd ->
                    details[pd.productId] = pd
                    BillingProduct(pd.productId, pd.name, pd.oneTimePurchaseOfferDetails?.formattedPrice.orEmpty())
                }
                onResult(out)
            }
        }
    }

    override fun purchase(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit) {
        val pd = details[productId]
        if (pd == null) {
            onResult(BillingEvent.Error("Chưa tải được thông tin sản phẩm \"$productId\"."))
            return
        }
        listener = onResult
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build())
            )
            .setObfuscatedAccountId(accountId)
            .build()
        val r = client.launchBillingFlow(activity, params)
        if (r.responseCode != BillingClient.BillingResponseCode.OK) {
            listener = null
            onResult(BillingEvent.Error(r.debugMessage.ifBlank { "không mở được màn hình thanh toán (mã ${r.responseCode})" }))
        }
    }

    private fun onPurchasesUpdated(result: BillingResult, purchases: List<Purchase>?) {
        val cb = listener
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases?.forEach { p ->
                    when (p.purchaseState) {
                        Purchase.PurchaseState.PURCHASED ->
                            cb?.invoke(BillingEvent.Purchased(p.products.firstOrNull().orEmpty(), p.purchaseToken))
                        Purchase.PurchaseState.PENDING -> cb?.invoke(BillingEvent.Pending)
                        else -> Unit
                    }
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> cb?.invoke(BillingEvent.Cancelled)
            else -> cb?.invoke(BillingEvent.Error(result.debugMessage.ifBlank { "mã ${result.responseCode}" }))
        }
    }

    override fun unconsumed(onResult: (List<Pair<String, String>>) -> Unit) {
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        client.queryPurchasesAsync(params) { result, list ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onResult(emptyList())
            } else {
                onResult(
                    list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                        .map { Pair(it.products.firstOrNull().orEmpty(), it.purchaseToken) }
                )
            }
        }
    }

    override fun consume(token: String, onDone: (Boolean) -> Unit) {
        val params = ConsumeParams.newBuilder().setPurchaseToken(token).build()
        client.consumeAsync(params) { result, _ -> onDone(result.responseCode == BillingClient.BillingResponseCode.OK) }
    }

    // ------------------------------------------------------------------ đăng ký định kỳ (R14)

    /** Chọn gói cơ sở (offerId == null) nếu có, không thì ưu đãi đầu tiên; ưu đãi dùng thử/giảm giá do người bán cấu hình riêng. */
    private fun pickOffer(pd: ProductDetails): ProductDetails.SubscriptionOfferDetails? {
        val offers = pd.subscriptionOfferDetails ?: return null
        return offers.firstOrNull { it.offerId == null } ?: offers.firstOrNull()
    }

    override fun subscriptions(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit) {
        val list = ids.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(list).build()
        client.queryProductDetailsAsync(params) { result, queryResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onError(result.debugMessage.ifBlank { "mã ${result.responseCode}" })
            } else {
                val out = queryResult.productDetailsList.map { pd ->
                    details[pd.productId] = pd
                    val price = pickOffer(pd)?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice.orEmpty()
                    BillingProduct(pd.productId, pd.name, price)
                }
                onResult(out)
            }
        }
    }

    override fun purchaseSubscription(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit) {
        val pd = details[productId]
        val offer = if (pd == null) null else pickOffer(pd)
        if (pd == null || offer == null) {
            onResult(BillingEvent.Error("Chưa tải được gói đăng ký \"$productId\"."))
            return
        }
        listener = onResult
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(offer.offerToken).build())
            )
            .setObfuscatedAccountId(accountId)
            .build()
        val r = client.launchBillingFlow(activity, params)
        if (r.responseCode != BillingClient.BillingResponseCode.OK) {
            listener = null
            onResult(BillingEvent.Error(r.debugMessage.ifBlank { "không mở được màn hình thanh toán (mã ${r.responseCode})" }))
        }
    }

    override fun activeSubscriptions(onResult: (List<Pair<String, String>>) -> Unit) {
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        client.queryPurchasesAsync(params) { result, list ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onResult(emptyList())
            } else {
                onResult(
                    list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                        .map { Pair(it.products.firstOrNull().orEmpty(), it.purchaseToken) }
                )
            }
        }
    }

    override fun acknowledge(token: String, onDone: (Boolean) -> Unit) {
        val params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(token).build()
        client.acknowledgePurchase(params) { result -> onDone(result.responseCode == BillingClient.BillingResponseCode.OK) }
    }

    override fun close() {
        if (client.isReady) client.endConnection()
    }
}
