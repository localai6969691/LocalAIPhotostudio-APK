package com.aiphoto.studio.i18n

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow

/**
 * `Text` của dự án (R33): giống `androidx.compose.material3.Text` nhưng chuỗi được DỊCH theo ngôn ngữ đang chọn ([I18n.tr]) ngay trước khi vẽ.
 * Các tệp giao diện chỉ cần `import com.aiphoto.studio.i18n.Text` thay cho bản của Material3 — mọi `Text("…tiếng Việt…")` đã có sẵn tự được dịch.
 * Chuỗi không có trong gói dịch (ví dụ chữ người dùng gõ, số liệu) giữ nguyên.
 */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    style: TextStyle = LocalTextStyle.current,
    // R45: một dòng, không tự xuống dòng (thanh trên không bị chữ xuống dòng từng ký tự làm cao vọt khi hết chỗ)
    softWrap: Boolean = true,
    overflow: TextOverflow = TextOverflow.Clip
) {
    androidx.compose.material3.Text(
        text = I18n.tr(text), modifier = modifier, color = color, softWrap = softWrap, overflow = overflow, maxLines = maxLines, style = style
    )
}
