package com.aiphoto.studio.doc

import android.graphics.Bitmap
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.engine.readPixels

/**
 * Mô hình tài liệu KHÔNG PHÁ HỦY: ảnh nền (bất biến) + danh sách lớp xếp chồng từ dưới lên.
 *  - AdjustmentLayer: danh sách phép chỉnh (EditOp) + mặt nạ + chế độ hòa trộn + độ mờ.
 *  - PatchLayer: mảng điểm ảnh do AI tạo/xóa vật thể (chỉ lưu vùng thay đổi).
 * Mọi lớp là dữ liệu bất biến -> hoàn tác/làm lại chỉ cần giữ danh sách lớp cũ.
 */
sealed interface Layer {
    val id: Long
    val name: String
    val visible: Boolean
    val opacity: Float
    val blend: BlendMode
    val mask: LayerMask?
    /** Clipping mask: chỉ tác dụng trong phạm vi (mặt nạ / alpha) của lớp gần nhất bên dưới không bị cắt; lớp gốc ẩn thì lớp bị cắt ẩn theo. */
    val clip: Boolean

    fun update(
        visible: Boolean = this.visible,
        opacity: Float = this.opacity,
        blend: BlendMode = this.blend,
        mask: LayerMask? = this.mask,
        name: String = this.name,
        clip: Boolean = this.clip
    ): Layer
}

data class AdjustmentLayer(
    override val id: Long,
    override val name: String,
    val ops: List<EditOp>,
    override val visible: Boolean = true,
    override val opacity: Float = 1f,
    override val blend: BlendMode = BlendMode.NORMAL,
    override val mask: LayerMask? = null,
    /** "basic" | "look" | "ai" | "local" | "recipe" */
    val kind: String = "basic",
    /** Vùng AI dùng dựng mặt nạ (Scope.*): công thức/hàng loạt dựng LẠI mặt nạ này riêng cho từng ảnh. null = không theo vùng. */
    val scope: String? = null,
    override val clip: Boolean = false
) : Layer {
    override fun update(visible: Boolean, opacity: Float, blend: BlendMode, mask: LayerMask?, name: String, clip: Boolean): Layer =
        copy(visible = visible, opacity = opacity, blend = blend, mask = mask, name = name, clip = clip)
}

data class PatchLayer(
    override val id: Long,
    override val name: String,
    val x: Int,
    val y: Int,
    val patch: Bitmap,
    override val visible: Boolean = true,
    override val opacity: Float = 1f,
    override val blend: BlendMode = BlendMode.NORMAL,
    override val mask: LayerMask? = null,
    override val clip: Boolean = false
) : Layer {
    override fun update(visible: Boolean, opacity: Float, blend: BlendMode, mask: LayerMask?, name: String, clip: Boolean): Layer =
        copy(visible = visible, opacity = opacity, blend = blend, mask = mask, name = name, clip = clip)
}

data class DocState(val background: Bitmap, val layers: List<Layer> = emptyList())

/** Logic thuần của clipping mask (kiểm thử được trên JVM). */
object ClipLogic {
    /**
     * Chỉ số của lớp GỐC mà lớp [i] bị cắt theo: lớp gần nhất bên dưới KHÔNG bị cắt (nhiều lớp bị cắt liên tiếp dùng chung một gốc).
     * -1 nếu lớp [i] không bật clip, hoặc bên dưới không có lớp nào để cắt theo.
     */
    fun baseIndex(layers: List<Layer>, i: Int): Int {
        if (i < 0 || i >= layers.size || !layers[i].clip) return -1
        var j = i - 1
        while (j >= 0 && layers[j].clip) j--
        return j
    }
}

object Layers {
    /** Tạo PatchLayer chỉ chứa vùng khác nhau giữa [before] và [after] (cùng kích thước). Null nếu không đổi gì. */
    fun diffPatch(before: Bitmap, after: Bitmap, id: Long, name: String): PatchLayer? {
        val w = before.width
        val h = before.height
        if (after.width != w || after.height != h) return null
        val a = readPixels(before)
        val b = readPixels(after)
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (a[row + x] != b[row + x]) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return null
        val patch = Bitmap.createBitmap(after, minX, minY, maxX - minX + 1, maxY - minY + 1)
        return PatchLayer(id, name, minX, minY, patch)
    }
}
