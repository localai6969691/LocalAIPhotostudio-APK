package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * R12 — Mặt nạ VECTOR (đa giác / lasso): lưu chỉ vài chục điểm theo thang 0..1 nên độc lập độ phân giải, nhẹ, lưu được trong
 * công thức, và dựng lại sắc nét ở mọi cỡ ảnh (khác mặt nạ tô tay là bản đồ điểm ảnh cố định).
 *  - [rasterize]: tô đa giác bằng quy tắc chẵn-lẻ (even-odd, đúng cho hình lõm / tự cắt), 4 mẫu theo chiều dọc + độ phủ ngang
 *    chính xác ở hai đầu mỗi đoạn → biên mịn; kết hợp với feather của LayerMask.
 *  - [simplify]: Douglas–Peucker để biến nét kéo tay (hàng trăm điểm) thành đa giác gọn.
 * Bản port Python: tools/verify_ports/polygon_fill.py.
 */
object PolygonFill {
    const val MAX_POINTS = 2000
    private const val SUB = 4

    fun rasterize(pts: List<Pt>, w: Int, h: Int): FloatArray {
        val out = FloatArray(max(0, w * h))
        val n = pts.size
        if (n < 3 || w <= 0 || h <= 0) return out
        val xs = FloatArray(n) { pts[it].x.coerceIn(0f, 1f) * w }
        val ys = FloatArray(n) { pts[it].y.coerceIn(0f, 1f) * h }
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (i in 0 until n) { minY = min(minY, ys[i]); maxY = max(maxY, ys[i]) }
        val rowStart = max(0, floor(minY).toInt())
        val rowEnd = min(h - 1, floor(maxY).toInt())
        val inter = FloatArray(n)
        val cover = FloatArray(w)
        val diff = FloatArray(w + 2)
        for (row in rowStart..rowEnd) {
            java.util.Arrays.fill(cover, 0f)
            java.util.Arrays.fill(diff, 0f)
            var any = false
            for (s in 0 until SUB) {
                val sy = row + (s + 0.5f) / SUB
                var k = 0
                for (i in 0 until n) {
                    val j = if (i == n - 1) 0 else i + 1
                    val y0 = ys[i]; val y1 = ys[j]
                    if (y0 == y1) continue
                    if (sy >= min(y0, y1) && sy < max(y0, y1)) {
                        inter[k++] = xs[i] + (sy - y0) * (xs[j] - xs[i]) / (y1 - y0)
                    }
                }
                if (k < 2) continue
                java.util.Arrays.sort(inter, 0, k)
                var p = 0
                while (p + 1 < k) {
                    val a = inter[p].coerceIn(0f, w.toFloat())
                    val b = inter[p + 1].coerceIn(0f, w.toFloat())
                    p += 2
                    if (b <= a) continue
                    any = true
                    val ia = min(w - 1, floor(a).toInt())
                    val ib = min(w - 1, floor(b).toInt())
                    if (ia == ib) {
                        cover[ia] += b - a
                    } else {
                        cover[ia] += (ia + 1) - a
                        cover[ib] += b - ib
                        if (ib > ia + 1) { diff[ia + 1] += 1f; diff[ib] -= 1f }
                    }
                }
            }
            if (!any) continue
            var run = 0f
            for (x in 0 until w) {
                run += diff[x]
                val v = (cover[x] + run) / SUB   // run = số mẫu dọc phủ trọn pixel (0..SUB), cover = phần phủ lẻ ở hai đầu đoạn
                out[row * w + x] = if (v > 1f) 1f else if (v < 0f) 0f else v
            }
        }
        return out
    }

    /** Diện tích (thang 0..1 của ảnh) theo công thức dây giày, luôn dương. */
    fun area(pts: List<Pt>): Float {
        var s = 0.0
        for (i in pts.indices) {
            val a = pts[i]
            val b = pts[(i + 1) % pts.size]
            s += a.x.toDouble() * b.y - b.x.toDouble() * a.y
        }
        return abs(s / 2.0).toFloat()
    }

    /** Douglas–Peucker trên đường gấp khúc [pts] (không lặp điểm đầu ở cuối); [eps] theo thang 0..1. Giữ điểm đầu và cuối. */
    fun simplify(pts: List<Pt>, eps: Float): List<Pt> {
        if (pts.size <= 2) return pts
        val keep = BooleanArray(pts.size)
        keep[0] = true
        keep[pts.size - 1] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, pts.size - 1))
        while (stack.isNotEmpty()) {
            val (lo, hi) = stack.removeLast().let { Pair(it[0], it[1]) }
            if (hi <= lo + 1) continue
            var best = -1
            var bestD = eps
            for (i in lo + 1 until hi) {
                val d = distToSegment(pts[i], pts[lo], pts[hi])
                if (d > bestD) { bestD = d; best = i }
            }
            if (best >= 0) {
                keep[best] = true
                stack.addLast(intArrayOf(lo, best))
                stack.addLast(intArrayOf(best, hi))
            }
        }
        return pts.filterIndexed { i, _ -> keep[i] }
    }

    private fun distToSegment(p: Pt, a: Pt, b: Pt): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len2 = dx * dx + dy * dy
        if (len2 <= 1e-12f) return sqrt((p.x - a.x) * (p.x - a.x) + (p.y - a.y) * (p.y - a.y))
        val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / len2).coerceIn(0f, 1f)
        val cx = a.x + t * dx
        val cy = a.y + t * dy
        return sqrt((p.x - cx) * (p.x - cx) + (p.y - cy) * (p.y - cy))
    }

    /**
     * Biến nét kéo tay thành đa giác lasso: bỏ điểm trùng, đơn giản hóa (eps 0.4% cạnh ảnh), giới hạn số điểm.
     * Trả null nếu quá ít điểm hoặc diện tích quá nhỏ (< 0.05% ảnh) — coi như chạm nhầm.
     */
    fun fromStroke(stroke: List<Pt>): List<Pt>? {
        val dedup = ArrayList<Pt>()
        for (p in stroke) {
            val last = dedup.lastOrNull()
            if (last == null || abs(last.x - p.x) + abs(last.y - p.y) > 1e-4f) dedup.add(Pt(p.x.coerceIn(0f, 1f), p.y.coerceIn(0f, 1f)))
        }
        if (dedup.size > 1) {
            val f = dedup.first(); val l = dedup.last()
            if (abs(f.x - l.x) + abs(f.y - l.y) <= 1e-4f) dedup.removeAt(dedup.size - 1)
        }
        if (dedup.size < 3) return null
        var eps = 0.004f
        var poly = simplify(dedup, eps)
        while (poly.size > MAX_POINTS && eps < 0.1f) { eps *= 1.5f; poly = simplify(dedup, eps) }
        if (poly.size < 3 || area(poly) < 0.0005f) return null
        return poly.take(MAX_POINTS)
    }
}
