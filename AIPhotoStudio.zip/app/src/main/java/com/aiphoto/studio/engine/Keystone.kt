package com.aiphoto.studio.engine

import kotlin.math.max

/**
 * Chỉnh phối cảnh (keystone) kiểu "Perspective" của Photoshop, đơn giản hóa cho di động bằng hai thanh trượt:
 *  - [v] dọc (-1..1): > 0 sửa đường thẳng đứng hội tụ lên trên (chụp tòa nhà từ dưới lên), < 0 ngược lại.
 *  - [h] ngang (-1..1): > 0 sửa cạnh trái bị co lại, < 0 cạnh phải.
 * Cách làm: lấy một HÌNH THANG nằm TRONG ảnh gốc rồi kéo giãn thành hình chữ nhật đầy khung -> không bao giờ sinh viền trống.
 * Thuần Kotlin để kiểm thử trên JVM; phần vẽ (Matrix.setPolyToPoly) nằm ở ImageEngine.
 */
object Keystone {

    /** Mức co tối đa của một cạnh so với kích thước ảnh khi thanh trượt = ±1. */
    const val MAX_INSET = 0.25f

    /** "v,h" -> (v, h) đã kẹp về -1..1; null nếu sai định dạng. */
    fun parse(arg: String?): Pair<Float, Float>? {
        val parts = arg?.split(',') ?: return null
        if (parts.size != 2) return null
        val v = parts[0].trim().toFloatOrNull() ?: return null
        val h = parts[1].trim().toFloatOrNull() ?: return null
        return Pair(v.coerceIn(-1f, 1f), h.coerceIn(-1f, 1f))
    }

    /** Bốn đỉnh nguồn theo thứ tự TL, TR, BR, BL: x0,y0,x1,y1,... (điểm ảnh). Đích luôn là (0,0),(w,0),(w,h),(0,h). */
    fun sourceQuad(w: Int, h: Int, v: Float, hk: Float): FloatArray {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val aTop = MAX_INSET * wf * max(v, 0f)
        val aBot = MAX_INSET * wf * max(-v, 0f)
        val bLeft = MAX_INSET * hf * max(hk, 0f)
        val bRight = MAX_INSET * hf * max(-hk, 0f)
        return floatArrayOf(
            aTop, bLeft,
            wf - aTop, bRight,
            wf - aBot, hf - bRight,
            aBot, hf - bLeft
        )
    }
}
