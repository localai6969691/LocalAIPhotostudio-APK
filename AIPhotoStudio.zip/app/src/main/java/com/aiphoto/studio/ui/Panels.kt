@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aiphoto.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import com.aiphoto.studio.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.MainViewModel
import com.aiphoto.studio.PaintMode
import com.aiphoto.studio.UiState
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.Layer
import com.aiphoto.studio.doc.OverlayLayer
import com.aiphoto.studio.doc.Looks
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.engine.BestTake
import com.aiphoto.studio.engine.GenQuality
import com.aiphoto.studio.engine.Monetization
import com.aiphoto.studio.engine.Outpaint
import com.aiphoto.studio.engine.SkyFx
import com.aiphoto.studio.engine.SkyStore
import com.aiphoto.studio.engine.SplitTone

private data class Tool(val type: OpType, val label: String, val min: Float, val max: Float)

private val LIGHT_TOOLS = listOf(
    Tool(OpType.BRIGHTNESS, "Độ sáng", -1f, 1f),
    Tool(OpType.CONTRAST, "Tương phản", -1f, 1f),
    Tool(OpType.HIGHLIGHTS, "Vùng sáng", -1f, 1f),
    Tool(OpType.SHADOWS, "Vùng tối", 0f, 1f),
    Tool(OpType.DEHAZE, "Khử sương mù", -1f, 1f),
    Tool(OpType.AUTO_ENHANCE, "Tự động", 0f, 1f)
)
private val COLOR_TOOLS = listOf(
    Tool(OpType.SATURATION, "Bão hòa", -1f, 1f),
    Tool(OpType.VIBRANCE, "Vibrance (màu thông minh)", -1f, 1f),
    Tool(OpType.WARMTH, "Ấm / Lạnh", -1f, 1f),
    Tool(OpType.TINT, "Xanh lá ↔ Tím", -1f, 1f),
    Tool(OpType.HUE, "Sắc độ (đổi màu)", -1f, 1f),
    Tool(OpType.CINEMATIC, "Điện ảnh", 0f, 1f),
    Tool(OpType.SEPIA, "Sepia", 0f, 1f)
)
private val DETAIL_TOOLS = listOf(
    Tool(OpType.SHARPEN, "Làm nét", 0f, 1f),
    Tool(OpType.CLARITY, "Rõ nét cục bộ", -1f, 1f),
    Tool(OpType.TEXTURE, "Kết cấu (Texture)", -1f, 1f),
    Tool(OpType.DUST, "Xóa bụi & xước", 0f, 1f),
    Tool(OpType.BLUR, "Làm mờ", 0f, 1f),
    Tool(OpType.SKIN_SMOOTH, "Mịn da", 0f, 1f),
    Tool(OpType.FREQ_SEP, "Retouch da", 0f, 1f),
    Tool(OpType.GRAIN, "Hạt film", 0f, 1f),
    Tool(OpType.VIGNETTE, "Vignette", 0f, 1f),
    Tool(OpType.BG_BLUR, "Mờ phông", 0f, 1f),
    Tool(OpType.DENOISE, "Khử nhiễu", 0f, 1f),
    Tool(OpType.RADIAL_BLUR, "Mờ xuyên tâm", 0f, 1f)
)

private val FX_TOOLS = listOf(
    Tool(OpType.GLOW, "Phát sáng (Orton)", 0f, 1f),
    Tool(OpType.MATTE, "Matte (phai đen)", 0f, 1f),
    Tool(OpType.SKETCH, "Phác họa bút chì", 0f, 1f),
    Tool(OpType.EMBOSS, "Nổi khối (Emboss)", 0f, 1f),
    Tool(OpType.POSTERIZE, "Posterize", 0f, 1f),
    Tool(OpType.PIXELATE, "Pixel hóa", 0f, 1f),
    Tool(OpType.CHROMA, "Lệch màu (Chromatic)", 0f, 1f),
    Tool(OpType.DUOTONE, "Duotone", 0f, 1f),
    Tool(OpType.SKY_REPLACE, "Thay bầu trời (cường độ)", 0f, 1f),
    Tool(OpType.SKY_RELIGHT, "Khớp ánh sáng tiền cảnh với trời", 0f, 1f)
)

private val DUOTONE_PRESETS = listOf(
    "Tím-Vàng" to "#20124D,#F6C177",
    "Xanh-Cam" to "#0B3C5D,#F4A259",
    "Đỏ-Kem" to "#5B0E2D,#FFE9C7",
    "Lục-Hồng" to "#0B3D2E,#F7B7D2"
)

private val HAIR_COLORS = listOf(
    "Đen" to "#1A1A1A", "Nâu" to "#6B4423", "Vàng" to "#D8B25A", "Đỏ" to "#B3261E",
    "Cam" to "#D9731A", "Hồng" to "#E85D9E", "Tím" to "#7B3FA0", "Xanh dương" to "#2D6CDF", "Bạc" to "#B8B8C4"
)

private val CHANNEL_MASKS = listOf(
    "chR" to "Kênh R", "chG" to "Kênh G", "chB" to "Kênh B", "chS" to "Bão hòa (S)", "chV" to "Tối (V)",
    "chL" to "Sáng (Lab L)", "chA" to "Hồng-đỏ (Lab a)", "chBl" to "Vàng (Lab b)",
    "focus" to "Vùng nét", "unfocus" to "Vùng mờ"
)

private val AI_SUGGESTIONS = listOf("Làm đẹp tự nhiên", "Trông chuyên nghiệp hơn", "Xóa người lạ", "Thay nền thành bãi biển", "Sáng hơn, tương phản hơn", "Da mịn, tông ấm", "Tông điện ảnh", "Đen trắng", "Mờ phông", "Ảnh thiếu sáng", "Nhẹ hơn")
private val PAINT_SUGGESTIONS = listOf("xóa", "Thêm một con mèo", "Thêm cái cây xanh", "Đổi thành áo màu đỏ", "Thêm một chiếc ghế gỗ", "Thay bằng bầu trời hoàng hôn")

private fun activeOps(st: UiState): List<EditOp> =
    (st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer)?.ops.orEmpty()

// ------------------------------------------------------------------ AI
@Composable
fun AiPanel(st: UiState, vm: MainViewModel) {
    var showAdv by remember { mutableStateOf(false) }
    // R28 Best Take: chọn các ảnh chụp liền nhau cùng cảnh; ghép khuôn mặt (mắt mở, đang cười) đẹp nhất vào ảnh hiện tại
    val pickBest = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(BestTake.MAX_FRAMES)) { uris ->
        if (uris.isNotEmpty()) vm.addBestTakeUris(uris)
    }
    // R30 Agent AI: ảnh MẪU phong cách (agent nhìn cả ảnh này để suy ra gu màu / tông)
    val pickAgentRef = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setAgentReference(uri)
    }
    // R29 Reframe 2.5D: ba thanh trượt (xoay ngang / dọc, độ sâu) chỉ hiện khi mở
    var showReframe by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        st.chat.takeLast(3).forEach { m ->
            Text(
                (if (m.fromUser) "Bạn: " else "AI: ") + m.text,
                style = MaterialTheme.typography.bodySmall,
                color = if (m.fromUser) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3
            )
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = st.paintMode == PaintMode.SELECT,
                onClick = { vm.setPaintMode(if (st.paintMode == PaintMode.SELECT) PaintMode.OFF else PaintMode.SELECT) },
                enabled = st.hasImage && !st.busy,
                label = { Text("Tô vùng (xóa / thêm vật thể)") }
            )
            FilterChip(
                selected = st.paintMode == PaintMode.TAP,
                onClick = { vm.setPaintMode(if (st.paintMode == PaintMode.TAP) PaintMode.OFF else PaintMode.TAP) },
                enabled = st.hasImage && !st.busy,
                label = { Text(if (st.samReady) "Chạm chọn" else "Chạm chọn (đũa thần)") }
            )
            FilterChip(
                selected = st.paintMode == PaintMode.QUICK,
                onClick = { vm.setPaintMode(if (st.paintMode == PaintMode.QUICK) PaintMode.OFF else PaintMode.QUICK) },
                enabled = st.hasImage && !st.busy,
                label = { Text("Quick Selection") }
            )
            FilterChip(
                selected = st.paintMode == PaintMode.LASSO,
                onClick = { vm.setPaintMode(if (st.paintMode == PaintMode.LASSO) PaintMode.OFF else PaintMode.LASSO) },
                enabled = st.hasImage && !st.busy,
                label = { Text("Lasso (vòng)") }
            )
            FilterChip(
                selected = st.paintMode == PaintMode.SKETCH,
                onClick = { vm.setPaintMode(if (st.paintMode == PaintMode.SKETCH) PaintMode.OFF else PaintMode.SKETCH) },
                enabled = st.hasImage && !st.busy,
                label = { Text("Phác thảo → ảnh") }
            )
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            AssistChip(
                onClick = { pickBest.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = st.hasImage && !st.busy,
                label = { Text(if (st.bestTakeUris.isEmpty()) "Best Take: thêm ảnh cùng cảnh" else "Best Take: ${st.bestTakeUris.size} ảnh phụ (thêm)") }
            )
            if (st.bestTakeUris.isNotEmpty()) {
                Button(onClick = { vm.runBestTake() }, enabled = st.hasImage && !st.busy) { Text("Chọn mặt đẹp nhất") }
                TextButton(onClick = { vm.clearBestTake() }, enabled = !st.busy) { Text("Bỏ ảnh phụ") }
            }
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = showReframe,
                onClick = { showReframe = !showReframe },
                enabled = st.hasImage && !st.busy,
                label = { Text("Reframe 2.5D: đổi góc nhìn") }
            )
        }
        if (showReframe) {
            ParamSlider("Xoay ngang", st.reframeX, -1f..1f, { vm.setReframe(x = it) }, {})
            ParamSlider("Xoay dọc", st.reframeY, -1f..1f, { vm.setReframe(y = it) }, {})
            ParamSlider("Độ sâu", st.reframeGain, 0f..2f, { vm.setReframe(gain = it) }, {})
            Text(if (st.depthReady) "Độ sâu: đo bằng model (tương đối)" else "Độ sâu: giả theo vị trí (nạp model độ sâu ở Cài đặt để đo thật)", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.runReframe() }, enabled = st.hasImage && !st.busy) { Text("Áp dụng góc nhìn") }
                TextButton(onClick = { vm.resetReframe() }, enabled = !st.busy) { Text("Về giữa") }
            }
        }
        if (st.proxyToken.isNotBlank()) {
            FilterChip(
                selected = st.agentMode,
                onClick = { vm.setAgentMode(!st.agentMode) },
                enabled = !st.busy,
                label = { Text(Monetization.agentChipLabel(st.isPro, serverAi = st.serverAiOk)) }
            )
            if (st.agentMode) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(
                        onClick = { pickAgentRef.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !st.busy,
                        label = { Text(if (st.agentRefReady) "Đổi ảnh mẫu phong cách" else "Ảnh mẫu phong cách (tùy chọn)") }
                    )
                    if (st.agentRefReady) TextButton(onClick = { vm.clearAgentReference() }, enabled = !st.busy) { Text("Bỏ ảnh mẫu") }
                }
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val painting = st.paintMode == PaintMode.SELECT || st.paintMode == PaintMode.TAP || st.paintMode == PaintMode.QUICK || st.selection != null
            // Gợi ý THÔNG MINH theo nội dung ảnh (thiếu sáng, thiếu tương phản, có chân dung, ảnh mờ...)
            val chips: List<Pair<String, String>> =
                if (painting) PAINT_SUGGESTIONS.map { Pair(it, it) }
                else if (st.suggestions.isNotEmpty()) st.suggestions
                else AI_SUGGESTIONS.map { Pair(it, it) }
            items(chips) { c ->
                AssistChip(onClick = { vm.onPrompt(c.second) }, label = { Text(c.first) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = st.genQuality == GenQuality.FAST, onClick = { vm.setGenQuality(GenQuality.FAST) }, label = { Text("Nhanh") })
            FilterChip(selected = st.genQuality == GenQuality.HIGH, onClick = { vm.setGenQuality(GenQuality.HIGH) }, label = { Text("Chất lượng") })
            FilterChip(selected = showAdv, onClick = { showAdv = !showAdv }, label = { Text("Nâng cao") })
            // Xóa đúng vùng tô: không nới ra ngoài nét tô, không hòa mép (điểm ngoài nét tô giữ nguyên từng bit; viền vật thể tô hụt sẽ còn sót)
            FilterChip(
                selected = st.exactRemove,
                onClick = { vm.setExactRemove(!st.exactRemove) },
                label = { Text("Xóa đúng vùng tô") }
            )
        }
        if (showAdv) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = st.genSeed,
                    onValueChange = { vm.setGenSeed(it) },
                    label = { Text("Seed (trống = ngẫu nhiên)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = st.genNegative,
                onValueChange = { vm.setGenNegative(it) },
                label = { Text("Prompt phủ định (điều không muốn)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            ParamSlider("Độ thay đổi", st.genStrength, 0f..1f, { vm.setGenStrength(it) }, {})
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = st.prompt,
                onValueChange = { vm.onPrompt(it) },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        if (st.paintMode == PaintMode.SELECT || st.selection != null) "Để trống / \"xóa\" = xóa vật thể; hoặc mô tả vật thể cần thêm…"
                        else "VD: da mịn hơn, tông ấm, giảm bớt…"
                    )
                },
                maxLines = 3
            )
            Button(
                onClick = { vm.run() },
                enabled = st.hasImage && !st.busy && (st.prompt.isNotBlank() || st.strokes.isNotEmpty() || st.selection != null)
            ) { Text("Chỉnh") }
        }
    }
}

// ------------------------------------------------------------------ Công cụ
@Composable
private fun ToolSliders(tools: List<Tool>, ops: List<EditOp>, vm: MainViewModel, favs: Set<String> = emptySet()) {
    tools.forEach { t ->
        val cur = ops.firstOrNull { o -> o.type == t.type }
        val v = cur?.value ?: 0f
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.toggleFav(t.type.key) }) { Text(if (t.type.key in favs) "★" else "☆") }
            Column(modifier = Modifier.weight(1f)) {
                ParamSlider(
                    label = t.label,
                    value = v,
                    range = t.min..t.max,
                    onChange = { nv -> vm.setOp(t.type, nv, if (t.type == OpType.DUOTONE || t.type == OpType.SKY_REPLACE) cur?.arg else null) },
                    onFinish = { vm.endEdit() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdvancedTools(ops: List<EditOp>, vm: MainViewModel) {
    val lv = ops.firstOrNull { it.type == OpType.LEVELS }?.arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }
    val black = lv?.getOrNull(0) ?: 0f
    val white = lv?.getOrNull(1) ?: 1f
    val gamma = lv?.getOrNull(2) ?: 1f
    fun setLevels(b: Float, w: Float, g: Float) = vm.setOp(OpType.LEVELS, 1f, fmt3(b) + "," + fmt3(w) + "," + fmt3(g))

    val gray = ops.any { it.type == OpType.GRAYSCALE }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = gray,
            onClick = { vm.setOp(OpType.GRAYSCALE, if (gray) 0f else 1f); vm.endEdit() },
            label = { Text("Đen trắng") }
        )
    }
    Text("Levels", style = MaterialTheme.typography.titleSmall)
    ParamSlider("Điểm đen", black, 0f..0.9f, { setLevels(it, white, gamma) }, { vm.endEdit() }, percent = false)
    ParamSlider("Điểm trắng", white, 0.1f..1f, { setLevels(black, it, gamma) }, { vm.endEdit() }, percent = false)
    ParamSlider("Gamma", gamma, 0.3f..3f, { setLevels(black, white, it) }, { vm.endEdit() }, percent = false)
    Text("Curves (chạm để thêm điểm, kéo để uốn, nhấn giữ để xóa)", style = MaterialTheme.typography.titleSmall)
    CurveEditor(
        arg = ops.firstOrNull { it.type == OpType.CURVES }?.arg,
        onChange = { vm.setOp(OpType.CURVES, 1f, it) },
        onFinish = { vm.endEdit() }
    )
    Text("Cân bằng màu (bóng / giữa / sáng)", style = MaterialTheme.typography.titleSmall)
    BalanceEditor(
        arg = ops.firstOrNull { it.type == OpType.COLOR_BALANCE }?.arg,
        onChange = { vm.setOp(OpType.COLOR_BALANCE, 1f, it) },
        onFinish = { vm.endEdit() }
    )
    Text("Chia tông (màu cho vùng sáng / vùng tối)", style = MaterialTheme.typography.titleSmall)
    SplitToneEditor(ops, vm)
    Text("HSL theo màu", style = MaterialTheme.typography.titleSmall)
    HslEditor(
        arg = ops.firstOrNull { it.type == OpType.HSL }?.arg,
        onChange = { vm.setOp(OpType.HSL, 1f, it) },
        onFinish = { vm.endEdit() }
    )
    Text("Màu chọn lọc (CMYK theo dải màu)", style = MaterialTheme.typography.titleSmall)
    SelectiveColorEditor(
        arg = ops.firstOrNull { it.type == OpType.SELECTIVE_COLOR }?.arg,
        onChange = { vm.setOp(OpType.SELECTIVE_COLOR, 1f, it) },
        onFinish = { vm.endEdit() }
    )
}

@Composable
private fun SplitToneEditor(ops: List<EditOp>, vm: MainViewModel) {
    val p = SplitTone.parse(ops.firstOrNull { it.type == OpType.SPLIT_TONE }?.arg) ?: SplitTone.Params(200f, 0f, 35f, 0f, 0f)
    fun set(n: SplitTone.Params) = vm.setOp(OpType.SPLIT_TONE, 1f, SplitTone.format(n))
    fun dot(h: Float): androidx.compose.ui.graphics.Color {
        val c = SplitTone.hueRgb(h)
        return androidx.compose.ui.graphics.Color(c[0], c[1], c[2])
    }
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AssistChip(onClick = { set(SplitTone.Params(185f, 0.5f, 28f, 0.5f, 0f)); vm.endEdit() }, label = { Text("Teal & Orange") })
        AssistChip(onClick = { set(SplitTone.Params(250f, 0.4f, 45f, 0.4f, 0f)); vm.endEdit() }, label = { Text("Tím tối – vàng sáng") })
        AssistChip(onClick = { set(SplitTone.Params(215f, 0.35f, 15f, 0.25f, 0f)); vm.endEdit() }, label = { Text("Lạnh tối – ấm sáng") })
        AssistChip(onClick = { vm.setOp(OpType.SPLIT_TONE, 0f, null); vm.endEdit() }, label = { Text("Đặt lại") })
    }
    Text("● Vùng sáng", color = dot(p.highHue), style = MaterialTheme.typography.bodySmall)
    ParamSlider("Vùng sáng: màu (°)", p.highHue, 0f..360f, { set(p.copy(highHue = it, highSat = maxOf(p.highSat, 0.05f))) }, { vm.endEdit() }, percent = false)
    ParamSlider("Vùng sáng: đậm", p.highSat, 0f..1f, { set(p.copy(highSat = it)) }, { vm.endEdit() })
    Text("● Vùng tối", color = dot(p.shadowHue), style = MaterialTheme.typography.bodySmall)
    ParamSlider("Vùng tối: màu (°)", p.shadowHue, 0f..360f, { set(p.copy(shadowHue = it, shadowSat = maxOf(p.shadowSat, 0.05f))) }, { vm.endEdit() }, percent = false)
    ParamSlider("Vùng tối: đậm", p.shadowSat, 0f..1f, { set(p.copy(shadowSat = it)) }, { vm.endEdit() })
    ParamSlider("Cân bằng sáng ↔ tối", p.balance, -1f..1f, { set(p.copy(balance = it)) }, { vm.endEdit() }, percent = false)
}

@Composable
private fun LensFlareTool(ops: List<EditOp>, vm: MainViewModel) {
    val op = ops.firstOrNull { it.type == OpType.LENS_FLARE }
    val amount = op?.value ?: 0f
    val xy = op?.arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }
    val x = xy?.getOrNull(0) ?: 0.78f
    val y = xy?.getOrNull(1) ?: 0.2f
    fun set(a: Float, nx: Float, ny: Float) = vm.setOp(OpType.LENS_FLARE, a, String.format(java.util.Locale.US, "%.3f,%.3f", nx, ny))
    ParamSlider("Lens flare", amount, 0f..1f, { set(it, x, y) }, { vm.endEdit() })
    ParamSlider("Nguồn sáng: ngang", x, 0f..1f, { set(maxOf(amount, 0.05f), it, y) }, { vm.endEdit() })
    ParamSlider("Nguồn sáng: dọc", y, 0f..1f, { set(maxOf(amount, 0.05f), x, it) }, { vm.endEdit() })
}

@Composable
private fun MotionBlurTool(ops: List<EditOp>, vm: MainViewModel) {
    val op = ops.firstOrNull { it.type == OpType.MOTION_BLUR }
    val amount = op?.value ?: 0f
    val angle = op?.arg?.toFloatOrNull() ?: 0f
    ParamSlider("Mờ chuyển động", amount, 0f..1f, { vm.setOp(OpType.MOTION_BLUR, it, angle.toInt().toString()) }, { vm.endEdit() })
    ParamSlider("Góc (độ)", angle, 0f..180f, { vm.setOp(OpType.MOTION_BLUR, maxOf(amount, 0.05f), it.toInt().toString()) }, { vm.endEdit() }, percent = false)
}

@Composable
private fun LocalTools(st: UiState, vm: MainViewModel) {
    val items = listOf(
        "subject" to "Chủ thể (AI)", "bright" to "Vùng sáng", "dark" to "Vùng tối", "sky" to "Bầu trời",
        "center" to "Tâm ảnh", "top" to "Nửa trên", "bottom" to "Nửa dưới",
        "brush" to "Tô tay", "dodge" to "Dodge", "burn" to "Burn"
    )
    Text(
        "Tạo lớp chỉnh sửa chỉ áp dụng cho một vùng. Sau đó kéo các thanh trượt ở tab khác để chỉnh riêng vùng đó.",
        style = MaterialTheme.typography.bodySmall
    )
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items.forEach { (k, n) -> AssistChip(onClick = { vm.addLocalLayer(k) }, label = { Text(n) }) }
    }
    Text(
        "Khuôn mặt (nhận diện 478 điểm bằng MediaPipe - cần nạp face_landmarker.task trong Cài đặt; chưa có thì \"Da mặt\" dùng nhận diện màu da)",
        style = MaterialTheme.typography.bodySmall
    )
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        listOf(Scope.SKIN, Scope.EYES, Scope.TEETH, Scope.DARK_CIRCLES, Scope.FACE_LIGHT, Scope.FACE_SHADOW).forEach { sc ->
            AssistChip(onClick = { vm.addFaceLayer(sc) }, label = { Text(Scope.label(sc)) })
        }
    }
    Text("Retouch & biến dạng", style = MaterialTheme.typography.titleSmall)
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AssistChip(onClick = { vm.startClone(false) }, label = { Text("Clone Stamp") })
        AssistChip(onClick = { vm.startClone(true) }, label = { Text("Heal Brush") })
        AssistChip(onClick = { vm.startLiquify() }, label = { Text("Liquify") })
        AssistChip(onClick = { vm.startPatch() }, label = { Text("Patch") })
        AssistChip(onClick = { vm.startWarp() }, label = { Text("Warp lưới / Free Transform") })
    }
    Text("Dáng khuôn mặt (Liquify theo 478 điểm - cần model khuôn mặt)", style = MaterialTheme.typography.titleSmall)
    listOf("Thon hàm", "To mắt", "Thu cánh mũi", "Nâng khóe môi").forEachIndexed { i, label ->
        ParamSlider(label, st.faceShape.getOrElse(i) { 0f }, 0f..1f, { vm.setFaceShape(i, it) }, { vm.endEdit() })
    }
    Text("Tóc (MediaPipe Hair Segmenter - cần nạp hair_segmenter.tflite trong Cài đặt; \"Tóc phồng\" gộp lớp vào ảnh, hoàn tác được)", style = MaterialTheme.typography.titleSmall)
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AssistChip(onClick = { vm.addHairLayer(null) }, label = { Text("Tóc bóng mượt") })
        // R16: phồng tóc là phép "bake" (đổi điểm ảnh cả bên ngoài mặt nạ tóc) -> gộp các lớp vào ảnh, hoàn tác được
        AssistChip(onClick = { vm.bake(listOf(EditOp(OpType.HAIR_VOLUME, 0.35f))) }, label = { Text("Tóc phồng nhẹ") })
        AssistChip(onClick = { vm.bake(listOf(EditOp(OpType.HAIR_VOLUME, 0.8f))) }, label = { Text("Tóc phồng nhiều") })
        HAIR_COLORS.forEach { (n, hex) -> AssistChip(onClick = { vm.addHairLayer(hex) }, label = { Text("Nhuộm $n") }) }
    }
    Text("Mặt nạ theo kênh màu (RGB / HSV / Lab) và vùng nét (Focus Area)", style = MaterialTheme.typography.titleSmall)
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CHANNEL_MASKS.forEach { (k, n) -> AssistChip(onClick = { vm.addLocalLayer(k) }, label = { Text(n) }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsPanel(st: UiState, vm: MainViewModel) {
    val pickSky = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importSky(uri)
    }
    var cat by remember { mutableStateOf("light") }
    val cats = listOf("faves" to "★ Faves", "light" to "Ánh sáng", "color" to "Màu", "detail" to "Chi tiết", "fx" to "Hiệu ứng", "adv" to "Nâng cao", "local" to "Cục bộ")
    val ops = activeOps(st)
    val active = st.layers.firstOrNull { it.id == st.activeId }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            if (active != null) "Đang chỉnh lớp: ${active.name}" else "Kéo thanh trượt sẽ tạo lớp \"Điều chỉnh cơ bản\".",
            style = MaterialTheme.typography.labelSmall
        )
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            cats.forEach { (k, n) -> FilterChip(selected = cat == k, onClick = { cat = k }, label = { Text(n) }) }
        }
        Column(modifier = Modifier.heightIn(max = 250.dp).verticalScroll(rememberScrollState())) {
            when (cat) {
                "faves" -> {
                    val favs = (LIGHT_TOOLS + COLOR_TOOLS + DETAIL_TOOLS + FX_TOOLS).filter { it.type.key in st.favTools }
                    if (favs.isEmpty()) Text("Chưa có công cụ yêu thích: bấm ☆ cạnh một thanh trượt ở các tab khác để ghim vào đây.", style = MaterialTheme.typography.bodySmall)
                    else ToolSliders(favs, ops, vm, st.favTools)
                }
                "light" -> ToolSliders(LIGHT_TOOLS, ops, vm, st.favTools)
                "color" -> ToolSliders(COLOR_TOOLS, ops, vm, st.favTools)
                "detail" -> {
                    ToolSliders(DETAIL_TOOLS, ops, vm, st.favTools)
                    MotionBlurTool(ops, vm)
                    LensFlareTool(ops, vm)
                }
                "fx" -> {
                    ToolSliders(FX_TOOLS, ops, vm, st.favTools)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DUOTONE_PRESETS.forEach { (n, a) ->
                            AssistChip(
                                onClick = { vm.setOp(OpType.DUOTONE, maxOf(ops.firstOrNull { it.type == OpType.DUOTONE }?.value ?: 0f, 0.8f), a); vm.endEdit() },
                                label = { Text(n) }
                            )
                        }
                    }
                    // Thay bầu trời: tự nhận diện trời nối mép trên ảnh rồi thay bằng trời mẫu
                    Text("Thay bầu trời:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SkyFx.PRESETS.forEach { p ->
                            AssistChip(
                                onClick = { vm.setOp(OpType.SKY_REPLACE, maxOf(ops.firstOrNull { it.type == OpType.SKY_REPLACE }?.value ?: 0f, 1f), p); vm.endEdit() },
                                label = { Text(SkyFx.label(p)) }
                            )
                        }
                    }
                    // Ảnh trời của người dùng (nhập một lần, dùng lại cho mọi ảnh)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = { pickSky.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            enabled = st.hasImage && !st.busy, label = { Text("+ Ảnh trời của tôi") }
                        )
                        st.skies.forEach { n ->
                            AssistChip(
                                onClick = { vm.setOp(OpType.SKY_REPLACE, maxOf(ops.firstOrNull { it.type == OpType.SKY_REPLACE }?.value ?: 0f, 1f), SkyStore.arg(n)); vm.endEdit() },
                                enabled = st.hasImage, label = { Text(n.removeSuffix(".jpg")) }
                            )
                            TextButton(onClick = { vm.deleteSky(n) }) { Text("✕") }
                        }
                    }
                }
                "adv" -> AdvancedTools(ops, vm)
                else -> LocalTools(st, vm)
            }
        }
    }
}

// ------------------------------------------------------------------ Looks / công thức / hàng loạt
@Composable
fun LooksPanel(st: UiState, vm: MainViewModel) {
    var showSave by remember { mutableStateOf(false) }
    var recipeName by remember { mutableStateOf("") }
    var batchRecipe by remember { mutableStateOf("") }
    var lookQuery by remember { mutableStateOf("") }
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        if (uris.isNotEmpty() && batchRecipe.isNotEmpty()) vm.batchApply(uris, batchRecipe)
    }
    val pickRef = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.addColorMatch(uri)
    }
    val pickLut = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLut(uri)
    }
    val active = st.layers.firstOrNull { it.id == st.activeId }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        // 80+ look: ô lọc theo tên (không dấu, không phân biệt hoa thường) để khỏi phải lướt hết
        OutlinedTextField(
            value = lookQuery,
            onValueChange = { lookQuery = it.take(40) },
            label = { Text("Tìm look (${Looks.all.size})") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        val q = GenIntent.fold(lookQuery)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Looks.all.map { it.first }.filter { q.isEmpty() || GenIntent.fold(it).contains(q) }) { n ->
                AssistChip(onClick = { vm.applyLook(n) }, enabled = st.hasImage, label = { Text(n) })
            }
        }
        if (active is AdjustmentLayer && active.kind == "look") {
            ParamSlider(
                label = "Cường độ",
                value = active.opacity,
                range = 0f..1f,
                onChange = { vm.setOpacity(active.id, it) },
                onFinish = { vm.endEdit() }
            )
        }
        // LUT 3D (.cube): chuẩn "Looks" của phần mềm chuyên nghiệp — nhập một lần, dùng cho mọi ảnh
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AssistChip(
                onClick = { pickLut.launch(arrayOf("*/*")) },
                enabled = !st.busy,
                label = { Text("+ Nhập LUT (.cube)") }
            )
            st.luts.forEach { n ->
                AssistChip(onClick = { vm.applyLut(n) }, enabled = st.hasImage, label = { Text(n.removeSuffix(".cube")) })
                TextButton(onClick = { vm.deleteLut(n) }) { Text("✕") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { showSave = true }, enabled = st.hasImage) { Text("Lưu thành công thức") }
            Text("${st.recipes.size} công thức", style = MaterialTheme.typography.labelSmall)
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AssistChip(
                onClick = { pickRef.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = st.hasImage && !st.busy,
                label = { Text("Khớp màu với ảnh mẫu") }
            )
            AssistChip(
                onClick = { vm.applyStyleDna() },
                enabled = st.hasImage && st.styleReady,
                label = { Text(if (st.styleReady) "Phong cách của tôi" else "Phong cách (cần chỉnh thêm vài ảnh)") }
            )
        }
        Column(modifier = Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
            st.recipes.forEach { name ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, modifier = Modifier.weight(1f), maxLines = 1)
                    TextButton(onClick = { vm.applyRecipe(name) }, enabled = st.hasImage) { Text("Dùng") }
                    TextButton(onClick = {
                        batchRecipe = name
                        pickMany.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }, enabled = !st.busy) { Text("Hàng loạt") }
                    TextButton(onClick = { vm.deleteRecipe(name) }) { Text("Xóa") }
                }
            }
        }
    }

    if (showSave) {
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Tên công thức") },
            text = {
                OutlinedTextField(value = recipeName, onValueChange = { recipeName = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveRecipe(recipeName)
                    recipeName = ""
                    showSave = false
                }) { Text("Lưu") }
            },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text("Hủy") } }
        )
    }
}

// ------------------------------------------------------------------ Cắt / xoay / biến đổi
@Composable
fun CropPanel(st: UiState, vm: MainViewModel) {
    fun bake(type: OpType, v: Float = 1f, arg: String? = null) = vm.bake(listOf(EditOp(type, v, arg)))
    val enabled = st.hasImage && !st.busy
    var deg by remember { mutableStateOf(0f) }
    var persV by remember { mutableStateOf(0f) }
    var persH by remember { mutableStateOf(0f) }
    var extPct by remember { mutableStateOf(0.2f) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Các thao tác này làm đổi ảnh nền nên các lớp sẽ được gộp vào ảnh (vẫn hoàn tác được).",
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            ParamSlider("Chỉnh thẳng (°)", deg, -15f..15f, { deg = it }, {}, percent = false)
            Button(onClick = { bake(OpType.STRAIGHTEN, deg); deg = 0f }, enabled = enabled && kotlin.math.abs(deg) >= 0.1f) { Text("Áp dụng") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            ParamSlider("Phối cảnh dọc", persV, -1f..1f, { persV = it }, {}, percent = false)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            ParamSlider("Phối cảnh ngang", persH, -1f..1f, { persH = it }, {}, percent = false)
            Button(
                onClick = {
                    bake(OpType.PERSPECTIVE, 1f, String.format(java.util.Locale.US, "%.3f,%.3f", persV, persH))
                    persV = 0f; persH = 0f
                },
                enabled = enabled && (kotlin.math.abs(persV) >= 0.01f || kotlin.math.abs(persH) >= 0.01f)
            ) { Text("Áp dụng") }
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { bake(OpType.ROTATE, 270f) }, enabled = enabled, label = { Text("Xoay trái") })
            AssistChip(onClick = { bake(OpType.ROTATE, 90f) }, enabled = enabled, label = { Text("Xoay phải") })
            AssistChip(onClick = { bake(OpType.ROTATE, 180f) }, enabled = enabled, label = { Text("Xoay 180°") })
            AssistChip(onClick = { bake(OpType.FLIP_H) }, enabled = enabled, label = { Text("Lật ngang") })
            AssistChip(onClick = { bake(OpType.FLIP_V) }, enabled = enabled, label = { Text("Lật dọc") })
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("1:1" to 1f, "4:5" to 0.8f, "3:4" to 0.75f, "4:3" to 1.3333f, "16:9" to 1.7778f, "9:16" to 0.5625f)
                .forEach { (n, r) ->
                    AssistChip(onClick = { bake(OpType.CROP_RATIO, r) }, enabled = enabled, label = { Text("Cắt $n") })
                }
        }
        Text(
            "Auto Frame: tự chọn khung cắt theo chủ thể - giữ trọn khuôn mặt, chừa lề, đặt chủ thể gần điểm 1/3 (nạp model tách nền / khuôn mặt thì chính xác hơn). Có thể hoàn tác.",
            style = MaterialTheme.typography.bodySmall
        )
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { vm.autoFrame(null) }, enabled = enabled, label = { Text("Auto: siết khung") })
            listOf("1:1" to 1f, "4:5" to 0.8f, "3:4" to 0.75f, "4:3" to 1.3333f, "16:9" to 1.7778f, "9:16" to 0.5625f)
                .forEach { (n, r) ->
                    AssistChip(onClick = { vm.autoFrame(r) }, enabled = enabled, label = { Text("Auto $n") })
                }
        }
        Text(
            "Mở rộng ảnh: nới khung rồi AI lấp phần mới cho liền cảnh (dịch vụ sinh ảnh nếu đã cấu hình, không thì engine trên máy).",
            style = MaterialTheme.typography.bodySmall
        )
        ParamSlider("Mở rộng mỗi phía", extPct, 0.05f..0.6f, { extPct = it }, {})
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            fun ext(l: Float, r: Float, t: Float, b: Float) = bake(OpType.OUTPAINT, 1f, Outpaint.format(Outpaint.Spec(l, r, t, b)))
            AssistChip(onClick = { ext(extPct, 0f, 0f, 0f) }, enabled = enabled, label = { Text("Mở ← trái") })
            AssistChip(onClick = { ext(0f, extPct, 0f, 0f) }, enabled = enabled, label = { Text("Mở → phải") })
            AssistChip(onClick = { ext(0f, 0f, extPct, 0f) }, enabled = enabled, label = { Text("Mở ↑ trên") })
            AssistChip(onClick = { ext(0f, 0f, 0f, extPct) }, enabled = enabled, label = { Text("Mở ↓ dưới") })
            AssistChip(onClick = { ext(extPct, extPct, 0f, 0f) }, enabled = enabled, label = { Text("Mở hai bên") })
            AssistChip(onClick = { ext(extPct, extPct, extPct, extPct) }, enabled = enabled, label = { Text("Mở 4 phía") })
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("1:1" to 1f, "4:5" to 0.8f, "4:3" to 1.3333f, "16:9" to 1.7778f, "9:16" to 0.5625f)
                .forEach { (n, r) ->
                    AssistChip(
                        onClick = { bake(OpType.OUTPAINT, 1f, String.format(java.util.Locale.US, "ratio=%.4f,a=c", r)) },
                        enabled = enabled, label = { Text("Mở thành $n") }
                    )
                }
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { bake(OpType.UPSCALE, 2f) }, enabled = enabled, label = { Text("Phóng to ×2") })
            AssistChip(onClick = { bake(OpType.UPSCALE, 4f) }, enabled = enabled, label = { Text("Phóng to ×4") })
            AssistChip(onClick = { bake(OpType.BG_REMOVE, 1f, "transparent") }, enabled = enabled, label = { Text("Tách nền (trong suốt)") })
            AssistChip(onClick = { bake(OpType.BG_REMOVE, 1f, "#FFFFFF") }, enabled = enabled, label = { Text("Nền trắng") })
        }
    }
}

// ------------------------------------------------------------------ Lớp
@Composable
private fun LayerDetail(l: Layer, vm: MainViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        if (l is OverlayLayer) OverlayDetail(l, vm)
        ParamSlider(
            label = "Độ mờ lớp",
            value = l.opacity,
            range = 0f..1f,
            onChange = { vm.setOpacity(l.id, it) },
            onFinish = { vm.endEdit() }
        )
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { vm.moveLayer(l.id, 1) }, label = { Text("Lên ▲") })
            AssistChip(onClick = { vm.moveLayer(l.id, -1) }, label = { Text("Xuống ▼") })
            AssistChip(onClick = { vm.deleteLayer(l.id) }, label = { Text("Xóa lớp") })
            // Clipping mask: chỉ tác dụng trong phạm vi lớp ngay bên dưới (vd. một lớp màu chỉ lên phần chữ/ảnh phủ/vùng lasso của lớp dưới)
            AssistChip(onClick = { vm.setClip(l.id, !l.clip) }, label = { Text(if (l.clip) "↳ Cắt theo lớp dưới ✓" else "↳ Cắt theo lớp dưới") })
        }
        val m = l.mask
        if (m != null) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = { vm.setMaskInvert(l.id, !m.invert) }, label = { Text(if (m.invert) "Mặt nạ: đảo ✓" else "Đảo mặt nạ") })
                if (m.spec is MaskSpec.Polygon) {
                    AssistChip(onClick = { vm.startPolyEdit() }, label = { Text("Sửa điểm lasso") })
                }
                AssistChip(onClick = { vm.setPaintMode(PaintMode.REVEAL) }, label = { Text("Tô thêm") })
                AssistChip(onClick = { vm.setPaintMode(PaintMode.HIDE) }, label = { Text("Tô bớt") })
                AssistChip(onClick = { vm.removeMask(l.id) }, label = { Text("Bỏ mặt nạ") })
            }
            ParamSlider(
                label = "Làm mềm biên",
                value = m.feather,
                range = 0f..1f,
                onChange = { vm.setMaskFeather(l.id, it) },
                onFinish = { vm.endEdit() }
            )
            ParamSlider(
                label = "Dịch biên (co ↔ nở)",
                value = m.shift,
                range = -1f..1f,
                onChange = { vm.setMaskShift(l.id, it) },
                onFinish = { vm.endEdit() }
            )
        }
    }
}

private val TEXT_COLORS = listOf(
    -1 to "Trắng", 0xFF000000.toInt() to "Đen", 0xFFFFD60A.toInt() to "Vàng", 0xFFFF453A.toInt() to "Đỏ",
    0xFF64D2FF.toInt() to "Xanh", 0xFFFF9FCF.toInt() to "Hồng", 0xFF30D158.toInt() to "Lục"
)

/** Chỉnh lớp chữ / ảnh phủ: nội dung, màu, cỡ, vị trí, góc xoay. */
@Composable
private fun OverlayDetail(l: OverlayLayer, vm: MainViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        if (l.kind == "text") {
            OutlinedTextField(
                value = l.text,
                onValueChange = { vm.setOverlayText(l.id, it) },
                label = { Text("Nội dung chữ (Enter = xuống dòng)") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TEXT_COLORS.forEach { (c, n) ->
                    AssistChip(
                        onClick = { vm.updateOverlay(l.id) { it.copy(color = c) }; vm.endEdit() },
                        label = { Text(if (l.color == c) "$n ✓" else n) }
                    )
                }
                AssistChip(
                    onClick = { vm.updateOverlay(l.id) { it.copy(bold = !it.bold) }; vm.endEdit() },
                    label = { Text(if (l.bold) "Đậm ✓" else "Đậm") }
                )
                AssistChip(
                    onClick = { vm.updateOverlay(l.id) { it.copy(outline = !it.outline) }; vm.endEdit() },
                    label = { Text(if (l.outline) "Viền ✓" else "Viền") }
                )
            }
        }
        if (l.kind == "image") {
            // R25: khớp màu + độ sáng ảnh phủ với nền ngay bên dưới (vật chèn vào không còn "dán" lệch tông)
            ParamSlider(
                label = "Hòa màu với nền", value = l.harmonize, range = 0f..1f,
                onChange = { v -> vm.updateOverlay(l.id) { it.copy(harmonize = v) } }, onFinish = { vm.endEdit() }
            )
        }
        ParamSlider(
            label = "Kích cỡ", value = l.size,
            range = if (l.kind == "text") 0.02f..0.4f else 0.1f..2f,
            onChange = { v -> vm.updateOverlay(l.id) { it.copy(size = v) } }, onFinish = { vm.endEdit() }
        )
        ParamSlider(
            label = "Vị trí ngang", value = l.cx, range = 0f..1f,
            onChange = { v -> vm.updateOverlay(l.id) { it.copy(cx = v) } }, onFinish = { vm.endEdit() }
        )
        ParamSlider(
            label = "Vị trí dọc", value = l.cy, range = 0f..1f,
            onChange = { v -> vm.updateOverlay(l.id) { it.copy(cy = v) } }, onFinish = { vm.endEdit() }
        )
        ParamSlider(
            label = "Xoay (°)", value = l.rotation, range = -180f..180f, percent = false,
            onChange = { v -> vm.updateOverlay(l.id) { it.copy(rotation = v) } }, onFinish = { vm.endEdit() }
        )
    }
}

@Composable
fun LayersPanel(st: UiState, vm: MainViewModel) {
    val pickOverlay = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.addImageOverlay(uri, false)
    }
    val pickDouble = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.addImageOverlay(uri, true)
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { vm.addTextLayer() }, enabled = st.hasImage && !st.busy, label = { Text("+ Chữ") })
            AssistChip(
                onClick = { pickDouble.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = st.hasImage && !st.busy, label = { Text("+ Phơi sáng kép") }
            )
            AssistChip(
                onClick = { pickOverlay.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = st.hasImage && !st.busy, label = { Text("+ Ảnh phủ") }
            )
            AssistChip(
                onClick = { vm.toggleHistory() }, enabled = st.hasImage,
                label = { Text(if (st.historyOpen) "Lịch sử ▲" else "Lịch sử ▼") }
            )
        }
        if (st.historyOpen) {
            // mỗi dòng = một bước (cũ → mới); chạm để quay về bước đó, các bước sau vẫn còn để "làm lại"
            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp).verticalScroll(rememberScrollState())) {
                st.history.forEachIndexed { i, label ->
                    val current = i == st.historyIndex
                    TextButton(onClick = { vm.jumpToHistory(i) }, enabled = !st.busy && !current, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            (if (current) "▶ " else "   ") + "${i + 1}. " + label,
                            maxLines = 2,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
        if (st.layers.isEmpty()) {
            Text(
                "Chưa có lớp. Mọi chỉnh sửa (Công cụ, Looks, AI) đều tạo lớp riêng - bật/tắt, đổi độ mờ, chế độ hòa trộn hoặc xóa bất cứ lúc nào, ảnh gốc không bị đổi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Column(modifier = Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
            st.layers.asReversed().forEach { l ->
                val selected = l.id == st.activeId
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { vm.toggleVisible(l.id) }) { Text(if (l.visible) "Hiện" else "Ẩn") }
                    TextButton(onClick = { vm.selectLayer(l.id) }, modifier = Modifier.weight(1f)) {
                        Text((if (selected) "▶ " else "") + (if (l.clip) "↳ " else "") + l.name + (if (l.mask != null) " ◐" else ""), maxLines = 1)
                    }
                    BlendPicker(l.blend) { m -> vm.setBlend(l.id, m) }
                }
                if (selected) LayerDetail(l, vm)
            }
        }
    }
}

/** R14: chọn chế độ hòa trộn từ menu (21 chế độ - xoay vòng từng cái không còn dùng được). */
@Composable
private fun BlendPicker(current: BlendMode, onPick: (BlendMode) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) { Text(current.label + " ▾", maxLines = 1) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            BlendMode.values().forEach { m ->
                DropdownMenuItem(
                    text = { Text((if (m == current) "✓ " else "") + m.label) },
                    onClick = { open = false; onPick(m) }
                )
            }
        }
    }
}
