package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * THÊM / THAY vật thể HOÀN TOÀN TRÊN MÁY bằng stable-diffusion.cpp (MIT) chạy `sd-server` cục bộ.
 * Cắt vùng quanh mặt nạ -> ảnh vuông -> sinh -> dán lại đúng vùng mặt nạ (phần ngoài mặt nạ giữ nguyên điểm ảnh gốc).
 *
 * Hai giao thức (tham số `api` trong cấu hình định tuyến), đã đối chiếu với tài liệu API của sd-server:
 *  - "sdapi" (mặc định): `/sdapi/v1/img2img` kiểu AUTOMATIC1111 - cho model INPAINTING SD 1.5 (đồng bộ).
 *  - "sdcpp_edit": API gốc bất đồng bộ `/sdcpp/v1/img_gen` + `ref_images` - cho model CHỈNH SỬA THEO CHỈ DẪN như
 *    FLUX.2 [klein] 4B (Apache-2.0, chưng cất 4 bước). Có theo dõi tiến độ và HỦY công việc mà không phải tắt tiến trình.
 *
 * Tham số: api, slot, size, steps, steps_full, steps_edit, cfg, cfg_full, cfg_edit, strength, lora, lora_mult, sampler,
 * mask_invert, vae_tiling ("false" để tắt), prompt_suffix, cmd.
 */
class LocalSdBackend(
    private val server: LocalSdServer,
    private val modelPath: String,
    private val threads: Int,
    private val loraDir: String?,
    private val extraDir: String?,
    private val params: Map<String, String>
) : GenerativeFill {

    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var jobId: String? = null
    @Volatile private var cancelled = false

    private val api = params["api"] ?: "sdapi"
    private val vaeTiling = params["vae_tiling"] != "false" // giảm ~70% RAM đỉnh khi giải mã VAE (kỹ thuật trong PDF)

    override fun cancel() {
        cancelled = true
        val id = jobId
        if (api == "sdcpp_edit" && id != null) {
            // hủy đúng công việc, giữ model trong RAM cho lần sau
            Thread { try { http("POST", "/sdcpp/v1/jobs/$id/cancel", "{}", 5_000) } catch (e: Throwable) { } }.start()
        } else {
            try { conn?.disconnect() } catch (e: Throwable) { }
            server.stop() // sdapi là đồng bộ: dừng tiến trình để ngắt suy luận
        }
    }

    override fun inpaint(image: Bitmap, mask: ByteArray, prompt: String, size: Int, opts: GenOptions): Bitmap {
        cancelled = false
        val w = image.width
        val rect = RegionCrop.compute(mask, w, image.height) ?: return image
        server.ensureRunning(modelPath, threads, loraDir, extraDir, params["cmd"])

        val step = if (api == "sdcpp_edit") 16 else 8 // FLUX cần bội số của 16
        val baseSize = if (opts.quality == GenQuality.HIGH) params["size_high"]?.toIntOrNull() ?: 768 else params["size"]?.toIntOrNull() ?: 512
        val side = (baseSize.coerceIn(256, 1024) / step) * step
        val crop = Bitmap.createBitmap(image, rect.x, rect.y, rect.w, rect.h)
        val sendImg = Bitmap.createScaledBitmap(crop, side, side, true)

        val result = if (api == "sdcpp_edit") generateEdit(sendImg, prompt, side, opts)
        else generateInpaint(sendImg, mask, w, rect, prompt, side, opts)

        val generated = Bitmap.createScaledBitmap(result, rect.w, rect.h, true)
        return RegionCrop.composite(image, mask, rect, generated)
    }

    // ------------------------------------------------------------------ SD 1.5 inpainting (sdapi)
    private fun generateInpaint(sendImg: Bitmap, mask: ByteArray, w: Int, rect: CropRect, prompt: String, side: Int, opts: GenOptions): Bitmap {
        val maskFull = makeBitmap(RegionCrop.maskGray(mask, w, rect), rect.w, rect.h)
        val sendMask = Bitmap.createScaledBitmap(maskFull, side, side, true)

        val loraName = params["lora"].orEmpty()
        val useLora = loraDir != null && loraName.isNotEmpty() && File(loraDir, loraName).exists()
        val steps0 = if (useLora) params["steps"]?.toIntOrNull() ?: 6 else params["steps_full"]?.toIntOrNull() ?: 20
        val steps = if (opts.quality == GenQuality.HIGH) steps0 * 3 / 2 else steps0
        val cfg = if (useLora) params["cfg"]?.toDoubleOrNull() ?: 1.0 else params["cfg_full"]?.toDoubleOrNull() ?: 7.0
        val invert = params["mask_invert"] == "true"
        // tham số gốc của sd.cpp đi kèm trong prompt (cơ chế `sd_cpp_extra_args` của tài liệu API)
        val extra = if (vaeTiling) " <sd_cpp_extra_args>{\"vae_tiling_params\":{\"enabled\":true}}</sd_cpp_extra_args>" else ""

        val body = JSONObject().apply {
            put("prompt", prompt + extra)
            put("negative_prompt", opts.negative.ifBlank { "blurry, low quality, deformed, extra limbs, watermark, text" })
            put("init_images", JSONArray().put(png(sendImg)))
            put("mask", png(sendMask))
            put("inpainting_mask_invert", if (invert) 1 else 0)
            put("width", side)
            put("height", side)
            put("steps", steps)
            put("cfg_scale", cfg)
            put("seed", opts.seed)
            put("batch_size", 1)
            put("denoising_strength", (opts.strength ?: params["strength"]?.toFloatOrNull() ?: 1f).toDouble())
            val sampler = params["sampler"]?.takeIf { it.isNotBlank() } ?: if (useLora) "lcm" else null
            if (sampler != null) put("sampler_name", sampler)
            if (useLora) {
                put("lora", JSONArray().put(JSONObject().put("path", loraName).put("multiplier", params["lora_mult"]?.toDoubleOrNull() ?: 1.0)))
            }
        }
        val text = http("POST", "/sdapi/v1/img2img", body.toString(), 1_200_000)
        val images = JSONObject(text).optJSONArray("images")
        if (images == null || images.length() == 0) throw IOException("sd-server không trả ảnh")
        return decode(images.getString(0))
    }

    // ------------------------------------------------------------------ chỉnh sửa theo chỉ dẫn (FLUX.2 klein...) qua API gốc bất đồng bộ
    private fun generateEdit(sendImg: Bitmap, prompt: String, side: Int, opts: GenOptions): Bitmap {
        val suffix = params["prompt_suffix"].orEmpty()
        val body = JSONObject().apply {
            put("prompt", (prompt + suffix).trim())
            put("width", side)
            put("height", side)
            put("seed", opts.seed)
            put("batch_count", 1)
            if (opts.negative.isNotBlank()) put("negative_prompt", opts.negative)
            put("ref_images", JSONArray().put(png(sendImg)))
            put("auto_resize_ref_image", true)
            put(
                "sample_params",
                JSONObject()
                    .put("sample_steps", (params["steps_edit"]?.toIntOrNull() ?: 4) + if (opts.quality == GenQuality.HIGH) 2 else 0)
                    .put("guidance", JSONObject().put("txt_cfg", params["cfg_edit"]?.toDoubleOrNull() ?: 1.0))
            )
            if (vaeTiling) put("vae_tiling_params", JSONObject().put("enabled", true))
            put("output_format", "png")
        }
        val submit = JSONObject(http("POST", "/sdcpp/v1/img_gen", body.toString(), 30_000))
        val id = submit.getString("id")
        jobId = id
        try {
            val deadline = System.currentTimeMillis() + 20 * 60_000L
            while (System.currentTimeMillis() < deadline) {
                if (cancelled) throw IOException("Đã hủy")
                val job = JSONObject(http("GET", "/sdcpp/v1/jobs/$id", null, 15_000))
                when (job.optString("status")) {
                    "completed" -> {
                        val imgs = job.optJSONObject("result")?.optJSONArray("images")
                        if (imgs == null || imgs.length() == 0) throw IOException("sd-server không trả ảnh")
                        return decode(imgs.getJSONObject(0).getString("b64_json"))
                    }
                    "failed" -> throw IOException("sd-server lỗi: " + (job.optJSONObject("error")?.optString("message") ?: "không rõ"))
                    "cancelled" -> throw IOException("Đã hủy")
                }
                Thread.sleep(800)
            }
            throw IOException("Hết thời gian chờ sd-server")
        } finally {
            jobId = null
        }
    }

    private fun decode(b64: String): Bitmap {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IOException("Không giải mã được ảnh từ sd-server")
    }

    private fun png(b: Bitmap): String {
        val bytes = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun http(method: String, path: String, json: String?, readTimeoutMs: Int): String {
        val c = URL("http://127.0.0.1:${LocalSdServer.PORT}$path").openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = readTimeoutMs
            if (json != null) {
                val data = json.toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setFixedLengthStreamingMode(data.size)
                c.outputStream.use { it.write(data) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("sd-server trả mã $code: ${text.take(200)}")
            return text
        } finally {
            c.disconnect()
            if (conn === c) conn = null
        }
    }
}
