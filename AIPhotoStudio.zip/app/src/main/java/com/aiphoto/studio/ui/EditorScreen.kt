@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aiphoto.studio.ui

import androidx.compose.ui.platform.LocalContext
import android.app.Activity
import kotlin.math.abs
import com.aiphoto.studio.engine.MeshWarp
import com.aiphoto.studio.engine.Sketch
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.OpType
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import com.aiphoto.studio.i18n.AppLanguages
import com.aiphoto.studio.i18n.I18n
import com.aiphoto.studio.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import com.aiphoto.studio.doc.OverlayLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aiphoto.studio.MainViewModel
import com.aiphoto.studio.PaintMode
import com.aiphoto.studio.Panel
import com.aiphoto.studio.UiState
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.engine.GenProvider
import com.aiphoto.studio.engine.Monetization
import com.aiphoto.studio.engine.Pt
import kotlin.math.max
import kotlin.math.min

@Composable
fun EditorScreen(vm: MainViewModel = viewModel()) {
    val st by vm.state.collectAsState()
    var showSettings by remember { mutableStateOf(false) }
    // R33: Trợ giúp / chọn ngôn ngữ / chào lần đầu mở app
    val appCtx = LocalContext.current
    var showHelp by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var showWelcome by remember { mutableStateOf(!I18n.welcomeDone(appCtx)) }
    var holdOriginal by remember { mutableStateOf(false) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.openImage(uri)
    }

    val canPaint = st.paintMode != PaintMode.OFF && !st.busy && st.hasImage && st.genKind == null

    /** Toạ độ màn hình trong hộp ảnh -> toạ độ chuẩn hóa 0..1 theo ảnh (ContentScale.Fit, căn giữa). */
    fun toNorm(p: Offset): Pt? {
        val bmp = st.before ?: return null
        if (boxSize.width == 0 || boxSize.height == 0) return null
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val scale = min(boxSize.width / bw, boxSize.height / bh)
        val dw = bw * scale
        val dh = bh * scale
        val ox = (boxSize.width - dw) / 2f
        val oy = (boxSize.height - dh) / 2f
        return Pt(((p.x - ox) / dw).coerceIn(0f, 1f), ((p.y - oy) / dh).coerceIn(0f, 1f))
    }

    val gestureModifier: Modifier =
        if (canPaint && st.paintMode == PaintMode.TAP) {
            Modifier.pointerInput(canPaint) {
                detectTapGestures(onTap = { o -> toNorm(o)?.let { vm.tapSelect(it) } })
            }
        } else if (canPaint && (st.paintMode == PaintMode.QUICK || st.paintMode == PaintMode.LASSO)) {
            // kéo để tô (Quick Selection) hoặc vẽ vòng (Lasso); thả tay → xử lý. Chạm một điểm cũng tính là một nét ngắn.
            Modifier
                .pointerInput(canPaint, st.paintMode) {
                    detectDragGestures(
                        onDragStart = { o -> toNorm(o)?.let { vm.beginStroke(it) } },
                        onDrag = { change, _ -> toNorm(change.position)?.let { vm.addPoint(it) } },
                        onDragEnd = { vm.finishStroke() },
                        onDragCancel = { vm.finishStroke() }
                    )
                }
                .pointerInput(canPaint, st.paintMode) {
                    detectTapGestures(onTap = { o -> toNorm(o)?.let { vm.beginStroke(it); vm.finishStroke() } })
                }
        } else if (canPaint && st.paintMode == PaintMode.CLONE && st.cloneSource == null) {
            Modifier.pointerInput(canPaint) {
                detectTapGestures(onTap = { o -> toNorm(o)?.let { vm.setCloneSource(it) } })
            }
        } else if (canPaint && st.paintMode == PaintMode.LIQUIFY) {
            Modifier.pointerInput(canPaint) {
                var last: Pt? = null
                detectDragGestures(
                    onDragStart = { o -> vm.touchEdit(); last = toNorm(o) },
                    onDrag = { change, _ ->
                        val cur = toNorm(change.position)
                        val prev = last
                        if (cur != null && prev != null) vm.liquifyDrag(prev, cur)
                        last = cur
                    },
                    onDragEnd = { vm.endEdit(); last = null },
                    onDragCancel = { vm.endEdit(); last = null }
                )
            }
        } else if (canPaint && st.paintMode == PaintMode.PATCH && st.patchPick) {
            Modifier.pointerInput(canPaint) {
                detectTapGestures(onTap = { o -> toNorm(o)?.let { vm.patchFromTap(it) } })
            }
        } else if (canPaint && st.paintMode == PaintMode.POLY_EDIT) {
            // sửa điểm lasso: kéo điểm (kéo từ cạnh = thêm điểm rồi kéo), chạm cạnh = thêm điểm, chạm giữ điểm = xóa
            Modifier
                .pointerInput(canPaint) {
                    detectDragGestures(
                        onDragStart = { o -> toNorm(o)?.let { vm.polyBegin(it) } },
                        onDrag = { change, _ -> toNorm(change.position)?.let { vm.polyDrag(it) } },
                        onDragEnd = { vm.endEdit() },
                        onDragCancel = { vm.endEdit() }
                    )
                }
                .pointerInput(canPaint) {
                    detectTapGestures(
                        onTap = { o -> toNorm(o)?.let { vm.polyTap(it) } },
                        onLongPress = { o -> toNorm(o)?.let { vm.polyDelete(it) } }
                    )
                }
        } else if (canPaint && st.paintMode == PaintMode.WARP) {
            Modifier.pointerInput(canPaint) {
                var last: Pt? = null
                detectDragGestures(
                    onDragStart = { o -> last = toNorm(o); last?.let { vm.warpBegin(it) } },
                    onDrag = { change, _ ->
                        val cur = toNorm(change.position)
                        val prev = last
                        if (cur != null && prev != null) vm.warpDrag(prev, cur)
                        last = cur
                    },
                    onDragEnd = { vm.endEdit(); last = null },
                    onDragCancel = { vm.endEdit(); last = null }
                )
            }
        } else if (canPaint) {
            Modifier
                .pointerInput(canPaint) {
                    detectTapGestures(onTap = { o -> toNorm(o)?.let { vm.beginStroke(it) } })
                }
                .pointerInput(canPaint) {
                    detectDragGestures(
                        onDragStart = { o -> toNorm(o)?.let { vm.beginStroke(it) } },
                        onDrag = { change, _ -> toNorm(change.position)?.let { vm.addPoint(it) } }
                    )
                }
        } else {
            val hold = Modifier.pointerInput(st.hasImage) {
                detectTapGestures(onPress = {
                    holdOriginal = true
                    tryAwaitRelease()
                    holdOriginal = false
                })
            }
            val overlayId = (st.layers.firstOrNull { it.id == st.activeId } as? OverlayLayer)?.takeIf { it.visible }?.id
            if (st.panel == Panel.LAYERS && st.hasImage && overlayId != null) {
                // lớp chữ / ảnh phủ đang chọn: kéo = di chuyển, hai ngón = phóng to/thu nhỏ + xoay (không dùng "giữ để xem ảnh gốc")
                Modifier.pointerInput(overlayId) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                            val pan = event.calculatePan()
                            val zoom = event.calculateZoom()
                            val rot = event.calculateRotation()
                            val bmp = st.before
                            if ((pan != Offset.Zero || zoom != 1f || rot != 0f) && bmp != null && boxSize.width > 0 && boxSize.height > 0) {
                                val fit = min(boxSize.width / bmp.width.toFloat(), boxSize.height / bmp.height.toFloat())
                                vm.transformOverlay(overlayId, pan.x / (bmp.width * fit), pan.y / (bmp.height * fit), zoom, rot)
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        } while (event.changes.any { it.pressed })
                        vm.endEdit()
                    }
                }
            } else if (st.panel == Panel.TOOLS && st.hasImage) {
                // thanh trượt đa chức năng: vuốt NGANG trên ảnh = chỉnh thông số đang chọn, vuốt DỌC = đổi thông số
                hold.pointerInput(st.panel) {
                    var tx = 0f
                    var ty = 0f
                    detectDragGestures(
                        onDragStart = { holdOriginal = false; tx = 0f; ty = 0f },
                        onDrag = { _, drag ->
                            tx += drag.x
                            ty += drag.y
                            if (abs(tx) >= abs(ty)) vm.scrubValue(drag.x / max(1, boxSize.width))
                        },
                        onDragEnd = {
                            if (abs(ty) > abs(tx) && abs(ty) > 60f) vm.scrubCycle(if (ty < 0f) 1 else -1)
                            vm.endEdit()
                        },
                        onDragCancel = { vm.endEdit() }
                    )
                }
            } else hold
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // ------------------------------------------------ thanh trên
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("AI Photo Studio", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (Monetization.showPaidUi()) st.credits?.let { c -> Text("Credits: $c", style = MaterialTheme.typography.labelSmall) }
            OutlinedButton(
                onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = !st.busy
            ) { Text("Mở") }
            OutlinedButton(onClick = { vm.undo() }, enabled = st.canUndo && !st.busy) { Text("↶") }
            OutlinedButton(onClick = { vm.redo() }, enabled = st.canRedo && !st.busy) { Text("↷") }
            Button(onClick = { vm.save() }, enabled = st.hasImage && !st.busy) { Text("Lưu") }
            TextButton(onClick = { vm.saveAndShare() }, enabled = st.hasImage && !st.busy) { Text("↗") } // chia sẻ
            Text("?", style = MaterialTheme.typography.titleMedium, modifier = Modifier.clickable { showHelp = true }.padding(horizontal = 10.dp, vertical = 8.dp))
            TextButton(onClick = { showSettings = true }) { Text("⚙") }
        }

        // ------------------------------------------------ vùng ảnh (giữ ngón tay = xem ảnh gốc)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .checkerboard()
                .onSizeChanged { boxSize = it }
                .then(gestureModifier),
            contentAlignment = Alignment.Center
        ) {
            val shown = if (holdOriginal) st.before else (st.preview ?: st.before)
            if (shown != null) {
                val image = remember(shown) { shown.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = "Ảnh đang chỉnh",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chưa có ảnh - bấm \"Mở\"", color = Color.White)
                    // các phiên làm việc đã tự lưu: mở lại cả ảnh nền lẫn các lớp (vẫn chỉnh được từng thông số)
                    if (st.savedProjects.isNotEmpty()) {
                        Text("Phiên đã lưu", color = Color.White, style = MaterialTheme.typography.labelMedium)
                        st.savedProjects.forEach { sp ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(onClick = { vm.restoreProject(sp.id) }, enabled = !st.busy) { Text("Mở · ${sp.text}", maxLines = 1) }
                                TextButton(onClick = { vm.discardProject(sp.id) }, enabled = !st.busy) { Text("Xóa") }
                            }
                        }
                    }
                }
            }

            val sel = st.selection
            if (sel != null && st.genKind == null && !holdOriginal) {
                val selImage = remember(sel) { sel.asImageBitmap() }
                Image(
                    bitmap = selImage,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // R34: chấm xanh đánh dấu các điểm đã chạm để chọn vật thể (chạm thêm = mở rộng; "Chọn lại" xóa hết) — trước đây `tapPoints` có trong trạng thái nhưng UI không vẽ
            if (st.tapPoints.isNotEmpty() && st.selection != null && st.paintMode == PaintMode.TAP && st.genKind == null && !holdOriginal) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val bmp = st.before ?: return@Canvas
                    val bw = bmp.width.toFloat()
                    val bh = bmp.height.toFloat()
                    val scale = min(size.width / bw, size.height / bh)
                    val dw = bw * scale
                    val dh = bh * scale
                    val ox = (size.width - dw) / 2f
                    val oy = (size.height - dh) / 2f
                    for (tp in st.tapPoints) {
                        val c = Offset(ox + tp.x * dw, oy + tp.y * dh)
                        drawCircle(Color.White, 8.dp.toPx(), c)
                        drawCircle(Color(0xFF34C759), 5.dp.toPx(), c)
                    }
                }
            }

            val cs = st.cloneSource
            if (cs != null && st.paintMode == PaintMode.CLONE && !holdOriginal) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val bmp = st.before ?: return@Canvas
                    val bw = bmp.width.toFloat()
                    val bh = bmp.height.toFloat()
                    val scale = min(size.width / bw, size.height / bh)
                    val dw = bw * scale
                    val dh = bh * scale
                    val c = Offset((size.width - dw) / 2f + cs.x * dw, (size.height - dh) / 2f + cs.y * dh)
                    drawCircle(color = Color.White, radius = 14.dp.toPx(), center = c, style = Stroke(width = 3f))
                    drawLine(Color.White, Offset(c.x - 22.dp.toPx(), c.y), Offset(c.x + 22.dp.toPx(), c.y), 3f)
                    drawLine(Color.White, Offset(c.x, c.y - 22.dp.toPx()), Offset(c.x, c.y + 22.dp.toPx()), 3f)
                }
            }

            if (st.paintMode == PaintMode.WARP && !holdOriginal) {
                val wl = st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer
                val mesh = MeshWarp.parse(wl?.ops?.firstOrNull { it.type == OpType.MESH_WARP }?.arg)
                    ?: MeshWarp.identity(MeshWarp.DEFAULT_GRID, MeshWarp.DEFAULT_GRID)
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val bmp = st.before ?: return@Canvas
                    val bw = bmp.width.toFloat()
                    val bh = bmp.height.toFloat()
                    val scale = min(size.width / bw, size.height / bh)
                    val dw = bw * scale
                    val dh = bh * scale
                    val ox = (size.width - dw) / 2f
                    val oy = (size.height - dh) / 2f
                    fun pos(i: Int, j: Int): Offset {
                        val n = j * (mesh.gx + 1) + i
                        return Offset(
                            ox + (i / mesh.gx.toFloat() + mesh.d[2 * n]) * dw,
                            oy + (j / mesh.gy.toFloat() + mesh.d[2 * n + 1]) * dh
                        )
                    }
                    for (j in 0..mesh.gy) for (i in 0..mesh.gx) {
                        if (i < mesh.gx) drawLine(Color(0x88FFFFFF), pos(i, j), pos(i + 1, j), 2f)
                        if (j < mesh.gy) drawLine(Color(0x88FFFFFF), pos(i, j), pos(i, j + 1), 2f)
                    }
                    for (j in 0..mesh.gy) for (i in 0..mesh.gx) drawCircle(Color.White, 9.dp.toPx(), pos(i, j))
                }
            }

            if (st.paintMode == PaintMode.POLY_EDIT && !holdOriginal) {
                val pl = st.layers.firstOrNull { it.id == st.activeId }
                val poly = (pl?.mask?.spec as? MaskSpec.Polygon)?.pts
                if (poly != null && poly.size >= 3) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val bmp = st.before ?: return@Canvas
                        val bw = bmp.width.toFloat()
                        val bh = bmp.height.toFloat()
                        val scale = min(size.width / bw, size.height / bh)
                        val dw = bw * scale
                        val dh = bh * scale
                        val ox = (size.width - dw) / 2f
                        val oy = (size.height - dh) / 2f
                        fun at(p: Pt) = Offset(ox + p.x * dw, oy + p.y * dh)
                        for (i in poly.indices) {
                            drawLine(Color(0xCCFFFFFF), at(poly[i]), at(poly[(i + 1) % poly.size]), 3f)
                        }
                        for (p in poly) {
                            drawCircle(Color.White, 9.dp.toPx(), at(p))
                            drawCircle(Color(0xFF007AFF), 6.dp.toPx(), at(p))
                        }
                    }
                }
            }

            if (st.strokes.isNotEmpty() && st.genKind == null && !holdOriginal) {
                val color = when (st.paintMode) {
                    PaintMode.REVEAL -> Color(0x9934C759)
                    PaintMode.HIDE -> Color(0x99007AFF)
                    else -> Color(0x99FF3B30)
                }
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val bmp = st.before ?: return@Canvas
                    val bw = bmp.width.toFloat()
                    val bh = bmp.height.toFloat()
                    val scale = min(size.width / bw, size.height / bh)
                    val dw = bw * scale
                    val dh = bh * scale
                    val ox = (size.width - dw) / 2f
                    val oy = (size.height - dh) / 2f
                    val diameter = if (st.paintMode == PaintMode.LASSO) 3.dp.toPx() else st.brush * 2f * max(dw, dh)
                    val sketchColors = if (st.paintMode == PaintMode.SKETCH) Sketch.alignColors(st.strokeColors, st.strokes.size, st.sketchColor) else emptyList()
                    for ((si, stroke) in st.strokes.withIndex()) {
                        if (stroke.isEmpty()) continue
                        val color = sketchColors.getOrNull(si)?.let { Color(it or (0xFF shl 24)).copy(alpha = 0.9f) } ?: color
                        if (stroke.size == 1) {
                            drawCircle(
                                color = color,
                                radius = diameter / 2f,
                                center = Offset(ox + stroke[0].x * dw, oy + stroke[0].y * dh)
                            )
                        } else {
                            val path = Path()
                            stroke.forEachIndexed { i, p ->
                                val x = ox + p.x * dw
                                val y = oy + p.y * dh
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            drawPath(
                                path = path,
                                color = color,
                                style = Stroke(width = diameter, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                    }
                }
            }

            val hint = when {
                holdOriginal -> "Ảnh gốc"
                !canPaint && st.panel == Panel.LAYERS && (st.layers.firstOrNull { it.id == st.activeId } as? OverlayLayer)?.visible == true ->
                    "Kéo để di chuyển · hai ngón để phóng to/thu nhỏ và xoay lớp đang chọn"
                canPaint && st.paintMode == PaintMode.CLONE && st.cloneSource == null -> "Chạm để chọn điểm nguồn"
                canPaint && st.paintMode == PaintMode.CLONE -> "Tô vào vùng đích"
                canPaint && st.paintMode == PaintMode.LIQUIFY -> "Kéo để đẩy / biến dạng"
                canPaint && st.paintMode == PaintMode.WARP -> "Kéo điểm lưới để biến dạng"
                canPaint && st.paintMode == PaintMode.POLY_EDIT -> "Kéo điểm xanh · chạm cạnh để thêm điểm · chạm giữ để xóa điểm"
                canPaint && st.paintMode == PaintMode.PATCH && st.patchPick -> "Chạm vào vùng sạch làm nguồn"
                canPaint && st.paintMode == PaintMode.PATCH -> "Tô quanh khuyết điểm cần vá"
                canPaint && st.paintMode == PaintMode.TAP -> "Chạm lên vật thể để chọn (chạm thêm để mở rộng)"
                canPaint && st.paintMode == PaintMode.QUICK -> "Tô một nét ngắn bên trong vật — vùng chọn tự lan theo màu"
                canPaint && st.paintMode == PaintMode.LASSO -> "Vẽ một vòng khép kín quanh vùng cần chọn"
                canPaint && st.paintMode == PaintMode.SKETCH -> "Vẽ nét màu lên chỗ muốn thêm vật thể, rồi mô tả vật đó"
                canPaint -> "Tô lên vùng cần xử lý"
                st.preview != null -> "Giữ ngón tay để xem ảnh gốc"
                else -> ""
            }
            if (hint.isNotEmpty()) {
                Text(
                    hint,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(6.dp)
                )
            }
        }

        // ------------------------------------------------ thanh công cụ cọ
        if (st.paintMode != PaintMode.OFF && st.hasImage) PaintBar(st, vm)

        // ------------------------------------------------ kết quả AI chờ áp dụng
        if (st.genKind != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        when (st.genKind) {
                            GenKind.REMOVE -> "Kết quả: xóa vật thể"
                            GenKind.CLONE -> "Kết quả: clone / heal"
                            else -> "Kết quả: thêm / thay vật thể"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.applyPending() }, enabled = !st.busy) { Text("Áp dụng") }
                        if (st.genKind == GenKind.FILL) {
                            OutlinedButton(onClick = { vm.run() }, enabled = !st.busy) { Text("Tạo lại") }
                        }
                        OutlinedButton(onClick = { vm.discardPending() }, enabled = !st.busy) { Text("Bỏ") }
                    }
                }
            }
        }

        // ------------------------------------------------ trạng thái + hủy
        if (st.busy) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.cancel() }) { Text("Hủy") }
            }
        }
        Text(
            st.status,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 3
        )

        // ------------------------------------------------ thẻ nội dung theo công cụ đang chọn
        when (st.panel) {
            Panel.AI -> AiPanel(st, vm)
            Panel.TOOLS -> ToolsPanel(st, vm)
            Panel.LOOKS -> LooksPanel(st, vm)
            Panel.CROP -> CropPanel(st, vm)
            Panel.LAYERS -> LayersPanel(st, vm)
            Panel.NONE -> {}
        }

        // ------------------------------------------------ thanh công cụ chính (5 mục)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                Panel.AI to "AI",
                Panel.TOOLS to "Công cụ",
                Panel.LOOKS to "Looks",
                Panel.CROP to "Cắt / Xoay",
                Panel.LAYERS to "Lớp (${st.layers.size})"
            ).forEach { (p, label) ->
                FilterChip(
                    selected = st.panel == p,
                    onClick = { vm.setPanel(if (st.panel == p) Panel.NONE else p) },
                    enabled = st.hasImage,
                    label = { Text(label) }
                )
            }
        }
    }

    if (showSettings) SettingsDialog(st, vm, onHelp = { showHelp = true }, onLanguage = { showLanguage = true }) { showSettings = false }
    if (showWelcome) WelcomeDialog(
        beta = !Monetization.showPaidUi(),
        onStart = { I18n.markWelcomeDone(appCtx); showWelcome = false },
        onHelp = { I18n.markWelcomeDone(appCtx); showWelcome = false; showHelp = true },
        onLanguage = { showLanguage = true }
    )
    if (showHelp) HelpDialog { showHelp = false }
    if (showLanguage) LanguageDialog { showLanguage = false }
    if (st.diagReport != null) DiagDialog(st, vm)
}

/** R24: xem trước báo cáo lỗi (thông số máy, model, nhật ký - không có ảnh/khóa) + ô ghi chú, rồi gửi qua hộp chia sẻ hệ thống. */
@Composable
private fun DiagDialog(st: UiState, vm: MainViewModel) {
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { vm.dismissDiagReport(false) },
        title = { Text(st.diagTitle.ifBlank { "Gửi thông tin lỗi" }) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (st.diagHint.isNotBlank()) Text(st.diagHint, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(600) },
                    label = { Text("Bạn đang làm gì khi lỗi xảy ra? (tùy chọn)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Nội dung sẽ gửi:", style = MaterialTheme.typography.titleSmall)
                Text(st.diagReport.orEmpty().take(6000), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { vm.shareDiagReport(note) }) { Text("Gửi") } },
        dismissButton = {
            Row {
                if (st.diagCrash) TextButton(onClick = { vm.dismissDiagReport(true) }) { Text("Bỏ qua") }
                TextButton(onClick = { vm.dismissDiagReport(false) }) { Text("Để sau") }
            }
        }
    )
}

@Composable
private fun PaintBar(st: UiState, vm: MainViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            when (st.paintMode) {
                PaintMode.SELECT -> "Chế độ tô vùng: chọn vật thể để xóa / thêm"
                PaintMode.REVEAL -> "Tô mặt nạ: tô vào chỗ muốn HIỆN hiệu ứng của lớp đang chọn"
                PaintMode.HIDE -> "Tô mặt nạ: tô vào chỗ muốn CHE hiệu ứng của lớp đang chọn"
                PaintMode.TAP -> "Chạm để chọn (MobileSAM; chưa nạp thì đũa thần theo màu)"
                PaintMode.CLONE -> "Clone / Heal: chọn nguồn rồi tô vào vùng đích"
                PaintMode.LIQUIFY -> "Liquify: kéo trên ảnh để đẩy điểm ảnh (cọ = vùng ảnh hưởng)"
                PaintMode.WARP -> "Warp lưới: kéo điểm trắng; 4 điểm góc = Free Transform (co giãn/nghiêng); thanh Xoay = xoay tự do"
                PaintMode.PATCH -> "Patch: tô khuyết điểm → Chọn nguồn → chạm vùng sạch"
                PaintMode.QUICK -> "Quick Selection: tô một nét ngắn lên vật; tô thêm để mở rộng, chỉnh Dung sai nếu lan chưa đủ/quá"
                PaintMode.LASSO -> "Lasso: vẽ vòng khép kín quanh vùng cần chọn; thả tay = tạo lớp có mặt nạ vector"
                PaintMode.POLY_EDIT -> "Sửa lasso: kéo điểm để chỉnh vùng · chạm cạnh = thêm điểm · chạm giữ điểm = xóa điểm"
                PaintMode.SKETCH -> "Phác thảo: chọn màu, vẽ nét lên chỗ muốn thêm vật (hình + màu gần đúng), gõ mô tả rồi bấm \"Vẽ thành ảnh\""
                PaintMode.OFF -> ""
            },
            style = MaterialTheme.typography.labelSmall
        )
        if (st.paintMode == PaintMode.QUICK) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dung sai", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.width(8.dp))
            Slider(
                value = st.quickTol,
                onValueChange = { vm.setQuickTol(it) },
                valueRange = 0f..1f,
                modifier = Modifier.weight(1f)
            )
        }
        if (st.paintMode == PaintMode.WARP) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Xoay ${"%.1f".format(st.warpAngle)}°", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.width(8.dp))
            Slider(
                value = st.warpAngle.coerceIn(-45f, 45f),
                onValueChange = { vm.setWarpAngle(it) },
                onValueChangeFinished = { vm.endEdit() },
                valueRange = -45f..45f,
                modifier = Modifier.weight(1f)
            )
        }
        if (st.paintMode == PaintMode.SKETCH) Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for ((name, argb) in Sketch.PALETTE) {
                FilterChip(
                    selected = st.sketchColor == argb,
                    onClick = { vm.setSketchColor(argb) },
                    label = { Text("● $name", color = Color(argb)) }
                )
            }
        }
        if (st.paintMode != PaintMode.TAP && st.paintMode != PaintMode.WARP && st.paintMode != PaintMode.LASSO && st.paintMode != PaintMode.POLY_EDIT) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cọ", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.width(8.dp))
            Slider(
                value = st.brush,
                onValueChange = { vm.setBrush(it) },
                valueRange = 0.01f..0.09f,
                modifier = Modifier.weight(1f)
            )
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.undoStroke() }, enabled = st.strokes.isNotEmpty() && !st.busy) { Text("Xóa nét") }
            TextButton(onClick = { vm.clearStrokes() }, enabled = st.strokes.isNotEmpty() && !st.busy) { Text("Xóa hết") }
            if (st.paintMode == PaintMode.REVEAL || st.paintMode == PaintMode.HIDE) {
                Button(
                    onClick = {
                        vm.commitMaskStrokes()
                        vm.setPaintMode(PaintMode.OFF)
                    },
                    enabled = st.strokes.isNotEmpty()
                ) { Text("Xong") }
            }
            if (st.paintMode == PaintMode.SKETCH) {
                Button(
                    onClick = { vm.run() },
                    enabled = Sketch.hasStrokes(st.strokes) && st.prompt.isNotBlank() && !st.busy
                ) { Text("Vẽ thành ảnh") }
            }
            if (st.paintMode == PaintMode.TAP || st.paintMode == PaintMode.QUICK) {
                TextButton(onClick = { vm.clearSelection() }, enabled = st.selection != null) { Text("Chọn lại") }
                Button(onClick = { vm.addLocalFromSelection() }, enabled = st.selection != null) { Text("Tạo lớp cục bộ") }
            }
            if (st.paintMode == PaintMode.CLONE) {
                TextButton(onClick = { vm.resetCloneSource() }, enabled = st.cloneSource != null) { Text("Đặt lại nguồn") }
                Button(
                    onClick = { vm.applyClone() },
                    enabled = st.cloneSource != null && st.strokes.isNotEmpty() && !st.busy
                ) { Text("Áp dụng") }
            }
            if (st.paintMode == PaintMode.REVEAL || st.paintMode == PaintMode.HIDE) {
                // AI Brush: giới hạn nét tô trong vùng AI nhận diện
                listOf<Pair<String?, String>>(
                    null to "Cọ thường", Scope.SKIN to "Chỉ da", Scope.HAIR to "Chỉ tóc",
                    Scope.SUBJECT to "Chỉ chủ thể", Scope.SKY to "Chỉ trời", Scope.BACKGROUND to "Chỉ nền"
                ).forEach { (sc, n) ->
                    AssistChip(onClick = { vm.setBrushLimit(sc) }, label = { Text(if (st.brushLimit == sc) "✓ $n" else n) })
                }
            }
            if (st.paintMode == PaintMode.PATCH) {
                Button(
                    onClick = { vm.beginPatchPick() },
                    enabled = st.strokes.isNotEmpty() && !st.busy && !st.patchPick
                ) { Text(if (st.patchPick) "Chạm vào nguồn…" else "Chọn nguồn") }
            }
            if (st.paintMode == PaintMode.WARP) {
                TextButton(onClick = { vm.resetWarp() }) { Text("Đặt lại lưới") }
            }
            OutlinedButton(onClick = { vm.setPaintMode(PaintMode.OFF) }) { Text("Thoát") }
        }
        if ((st.paintMode == PaintMode.TAP || st.paintMode == PaintMode.QUICK) && st.selection != null) {
            // Select-and-Do: sau khi chọn vật thể, hiện ngay các việc có thể làm với nó
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "remove" to "Xóa", "move" to "Di chuyển", "blur" to "Làm mờ", "blurbg" to "Mờ nền", "bright" to "Sáng hơn",
                    "dark" to "Tối hơn", "color" to "Tăng màu", "hue" to "Đổi màu", "gray" to "Đen trắng", "graybg" to "Nền đen trắng"
                ).forEach { a -> AssistChip(onClick = { vm.selectionAction(a.first) }, enabled = !st.busy, label = { Text(a.second) }) }
            }
        }
    }
}

@Composable
private fun SettingsDialog(st: UiState, vm: MainViewModel, onHelp: () -> Unit, onLanguage: () -> Unit, onClose: () -> Unit) {
    val pickLlm = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLlm(uri)
    }
    val pickSeg = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSegmenter(uri)
    }
    val pickSegHq = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSegmenterHq(uri)
    }
    val pickPortrait = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importPortrait(uri)
    }
    val pickHair = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importHair(uri)
    }
    val pickFace = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFace(uri)
    }
    val pickPerson = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importPerson(uri)
    }
    val pickDepth = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importDepth(uri)
    }
    val pickLama = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLama(uri)
    }
    val pickMigan = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importMigan(uri)
    }
    val pickEsrgan = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importEsrgan(uri)
    }
    val pickSdLocal = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSdLocalModel(uri)
    }
    val pickKlein = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSdKlein(uri)
    }
    val pickKleinLlm = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSdExtra(uri, "llm")
    }
    val pickKleinVae = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSdExtra(uri, "vae")
    }
    val pickSdLora = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSdLora(uri)
    }
    val pickSamEnc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSamEncoder(uri)
    }
    val pickSamDec = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importSamDecoder(uri)
    }
    val pickRouting = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importRouting(uri)
    }

    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Đóng") } },
        title = { Text("Model AI & dịch vụ") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Ngôn ngữ & trợ giúp", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onLanguage) { Text("Ngôn ngữ: ${AppLanguages.byCode(I18n.active)?.nativeName ?: ""}") }
                    OutlinedButton(onClick = onHelp) { Text("Trợ giúp") }
                }

                Text("Báo lỗi cho nhà phát triển", style = MaterialTheme.typography.titleSmall)
                OutlinedButton(onClick = { onClose(); vm.prepareDiagReport() }) { Text("Gửi thông tin lỗi") }
                Text(
                    "Gom thông số máy, model đã nạp và nhật ký thao tác gần nhất (không có ảnh, không có khóa AI). Bạn xem được nội dung trước khi gửi.",
                    style = MaterialTheme.typography.bodySmall
                )

                Text("Trên máy (cục bộ)", style = MaterialTheme.typography.titleSmall)
                Text(
                    "LLM hiểu prompt: " + when {
                        st.llmLoading -> "đang nạp…"
                        st.llmReady -> "đã nạp" + if (st.llmBackend.isNotBlank() && st.llmBackend != "?") " (chạy trên ${st.llmBackend})" else ""
                        else -> "chưa nạp (dùng bộ quy tắc offline)"
                    }
                )
                OutlinedButton(onClick = { pickLlm.launch(arrayOf("*/*")) }) { Text("Chọn model LLM (.task / .bin / .litertlm)") }
                Text(
                    ".task = Gemma 3 1B (MediaPipe, chỉ văn bản). .litertlm = Gemma 3n / Gemma 4 (LiteRT-LM, GPU, hiểu cả ảnh ngay trên máy cho Agent AI; " +
                        "cần bản build bật LiteRT-LM).",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Xóa vật thể (LaMa .onnx): " + if (st.lamaReady) "đã nạp" else "chưa nạp (dùng thuật toán cổ điển)")
                OutlinedButton(onClick = { pickLama.launch(arrayOf("*/*")) }) { Text("Chọn model LaMa (.onnx)") }
                Text("Xóa vật thể nhẹ, nhanh (MI-GAN .onnx): " + if (st.miganReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickMigan.launch(arrayOf("*/*")) }) { Text("Chọn model MI-GAN (.onnx)") }
                Text(
                    "Tạo ảnh NGAY TRÊN MÁY (stable-diffusion.cpp, thử nghiệm): sd-server " +
                        (if (st.sdLocalBinary) "có trong APK" else "chưa có trong APK") +
                        ", model " + if (st.sdLocalModel) "đã nạp" else "chưa nạp"
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(onClick = { pickSdLocal.launch(arrayOf("*/*")) }) { Text("Model inpainting SD1.5") }
                    OutlinedButton(onClick = { pickSdLora.launch(arrayOf("*/*")) }) { Text("LoRA LCM (tùy chọn)") }
                    OutlinedButton(onClick = { vm.stopLocalSd() }) { Text("Giải phóng RAM") }
                }
                Text("FLUX.2 [klein] 4B (Apache-2.0, chỉnh sửa theo chỉ dẫn, 4 bước): cần 3 tệp", style = MaterialTheme.typography.bodySmall)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(onClick = { pickKlein.launch(arrayOf("*/*")) }) { Text("klein .gguf") }
                    OutlinedButton(onClick = { pickKleinLlm.launch(arrayOf("*/*")) }) { Text("LLM Qwen3 .gguf") }
                    OutlinedButton(onClick = { pickKleinVae.launch(arrayOf("*/*")) }) { Text("VAE") }
                }
                Text("Phóng to AI (Real-ESRGAN x4v3 .onnx): " + if (st.esrganReady) "đã nạp" else "chưa nạp (dùng nội suy + làm nét)")
                OutlinedButton(onClick = { pickEsrgan.launch(arrayOf("*/*")) }) { Text("Chọn model phóng to (.onnx)") }
                Text("Chạm để chọn vật thể (MobileSAM): " + if (st.samReady) "đã nạp" else "chưa nạp (cần 2 tệp)")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { pickSamEnc.launch(arrayOf("*/*")) }) { Text("SAM encoder") }
                    OutlinedButton(onClick = { pickSamDec.launch(arrayOf("*/*")) }) { Text("SAM decoder") }
                }
                Text("Tách nền / chọn chủ thể (U²-Net .onnx): " + if (st.segReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickSeg.launch(arrayOf("*/*")) }) { Text("Chọn model tách nền (.onnx)") }
                Text("Tách nền chất lượng cao (IS-Net .onnx, tùy chọn - máy RAM ≥ 4 GB): " + if (st.segHqReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickSegHq.launch(arrayOf("*/*")) }) { Text("Chọn model IS-Net (.onnx)") }
                Text("Tách nền chân dung (MODNet .onnx, tùy chọn - dùng khi ảnh có mặt và đã nạp model khuôn mặt): " + if (st.portraitReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickPortrait.launch(arrayOf("*/*")) }) { Text("Chọn model MODNet (.onnx)") }
                Text("Khuôn mặt - retouch da, mắt, răng, quầng thâm (MediaPipe face_landmarker.task): " + if (st.faceReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickFace.launch(arrayOf("*/*")) }) { Text("Chọn model khuôn mặt (.task)") }
                Text("Tóc - nhuộm màu, bóng mượt, giới hạn cọ (MediaPipe hair_segmenter.tflite): " + if (st.hairReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickHair.launch(arrayOf("*/*")) }) { Text("Chọn model tóc (.tflite)") }
                Text("Phát hiện người - \"Xóa người lạ\" nhận cả người quay lưng (MediaPipe efficientdet_lite0.tflite, tùy chọn): " + if (st.personReady) "đã nạp" else "chưa nạp")
                OutlinedButton(onClick = { pickPerson.launch(arrayOf("*/*")) }) { Text("Chọn model phát hiện người (.tflite)") }
                Text("Độ sâu - Reframe 2.5D dùng độ sâu đo thật thay độ sâu giả (Depth Anything V2 Small .onnx, Apache-2.0, tùy chọn; đừng nạp bản Base/Large vì giấy phép CC-BY-NC): " + if (st.depthReady) "đã nạp" else "chưa nạp (dùng độ sâu giả)")
                OutlinedButton(onClick = { pickDepth.launch(arrayOf("*/*")) }) { Text("Chọn model độ sâu (.onnx)") }
                TextButton(onClick = { vm.removeModels() }) { Text("Gỡ tất cả model trên máy") }

                Text(Monetization.serverSectionTitle(), style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = st.proxyUrl,
                    onValueChange = { vm.setProxyUrl(it) },
                    label = { Text("Địa chỉ máy chủ, vd https://api.ten-mien.com") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(onClick = { vm.registerProxy() }) { Text(if (st.proxyToken.isBlank()) "Đăng ký" else "Đăng ký lại") }
                    OutlinedButton(onClick = { vm.refreshCredits() }, enabled = st.proxyToken.isNotBlank()) { Text(Monetization.refreshButtonLabel()) }
                    OutlinedButton(onClick = { vm.syncRoutingFromProxy() }, enabled = st.proxyToken.isNotBlank()) { Text("Đồng bộ cấu hình") }
                }
                if (st.proxyToken.isNotBlank()) Monetization.betaLine(st.betaUsedToday, st.betaDailyLimit, serverAi = st.serverAiOk)?.let { Text(it) }
                if (Monetization.showPaidUi() && st.credits != null) Text("Credits còn lại: ${st.credits}" + (st.team?.let { " (gồm quỹ chung của nhóm: ${it.credits})" } ?: ""))
                if (Monetization.showPaidUi() && st.proxyToken.isNotBlank()) {
                    val planText = if (st.isPro) {
                        "Gói: Pro" + if (st.planUntil > 0) " đến " + java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(st.planUntil * 1000)) else ""
                    } else "Gói: Free (xuất ảnh có watermark, không dùng chất lượng cao)"
                    Text(planText)
                    val activity = LocalContext.current as? Activity
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(onClick = { vm.loadBillingProducts() }) { Text("Tải bảng giá") }
                        OutlinedButton(onClick = { vm.restorePurchases() }) { Text("Khôi phục giao dịch") }
                    }
                    st.billingProducts.forEach { p ->
                        OutlinedButton(onClick = { activity?.let { vm.buy(it, p.id) } }) { Text("${p.title} - ${p.price}") }
                    }
                    st.subscriptionProducts.forEach { p ->
                        OutlinedButton(onClick = { activity?.let { vm.buySubscription(it, p.id) } }) { Text("Đăng ký: ${p.title} - ${p.price}") }
                    }
                    TeamSection(st, vm)
                }

                Text("Tạo ảnh: thêm / thay vật thể", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = st.genProvider == GenProvider.CLOUD_GEMINI,
                        onClick = { vm.setGenProvider(GenProvider.CLOUD_GEMINI) },
                        label = { Text("Cloud (Gemini)") }
                    )
                    FilterChip(
                        selected = st.genProvider == GenProvider.LAN_SD,
                        onClick = { vm.setGenProvider(GenProvider.LAN_SD) },
                        label = { Text("Máy chủ SD") }
                    )
                }
                if (st.genProvider == GenProvider.CLOUD_GEMINI) {
                    OutlinedTextField(
                        value = st.cloudKey,
                        onValueChange = { vm.setCloudKey(it) },
                        label = { Text("Gemini API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = st.cloudModel,
                        onValueChange = { vm.setCloudModel(it) },
                        label = { Text("Tên model ảnh") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Chỉ phần ảnh quanh vùng tô (kèm mặt nạ) được gửi tới Google; phần còn lại giữ nguyên trên máy.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Monetization.byokHint()?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                } else {
                    OutlinedTextField(
                        value = st.sdUrl,
                        onValueChange = { vm.setSdUrl(it) },
                        label = { Text("Địa chỉ WebUI, vd http://192.168.1.10:7860") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(512, 768, 1024).forEach { n ->
                            FilterChip(selected = st.sdSize == n, onClick = { vm.setSdSize(n) }, label = { Text("$n px") })
                        }
                    }
                }
                OutlinedButton(onClick = { vm.testServer() }) { Text("Kiểm tra kết nối") }
                if (st.serverInfo.isNotEmpty()) Text(st.serverInfo, style = MaterialTheme.typography.bodySmall)

                Text("Định tuyến model (không hardcode)", style = MaterialTheme.typography.titleSmall)
                Text(st.perfInfo, style = MaterialTheme.typography.bodySmall)
                Text(st.routingSummary, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = st.routingUrl,
                    onValueChange = { vm.setRoutingUrl(it) },
                    label = { Text("URL cấu hình định tuyến (https, tùy chọn)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(onClick = { vm.updateRouting() }) { Text("Cập nhật từ URL") }
                    OutlinedButton(onClick = { pickRouting.launch(arrayOf("*/*")) }) { Text("Nạp từ tệp") }
                    OutlinedButton(onClick = { vm.resetRouting() }) { Text("Mặc định") }
                }
                Text(
                    "Không nạp model/không cấu hình dịch vụ vẫn dùng được chỉnh sửa tham số và xóa vật thể cổ điển.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    )
}
