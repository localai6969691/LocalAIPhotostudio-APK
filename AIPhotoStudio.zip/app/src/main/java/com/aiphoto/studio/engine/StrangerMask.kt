package com.aiphoto.studio.engine

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * "Xóa người lạ" (PDF): từ các khuôn mặt nhận diện được, tự chọn ai là CHỦ THỂ (giữ) và ai là NGƯỜI LẠ (xóa), rồi dựng
 * mặt nạ cả người (đầu + cổ + thân + chân) cho từng người lạ để đưa vào chuỗi xóa vật thể.
 *
 * Quy tắc chọn không gắn với thiết bị hay model nào:
 *  - Mặt càng lớn = càng gần ống kính. Mặt có diện tích ≥ [KEEP_RATIO] × mặt lớn nhất được coi là cùng nhóm chủ thể (ảnh nhóm bạn bè
 *    được giữ nguyên); mặt nhỏ hơn hẳn (người ở xa/phía sau) là người lạ.
 *  - Thân người dựng bằng khuôn mẫu tỉ lệ cơ thể theo kích thước và độ nghiêng của mặt; nếu có mặt nạ "chủ thể" từ model tách nền
 *    thì bám theo hình thật của cơ thể (chỉ giữ phần điểm ảnh thuộc chủ thể bên trong khuôn mẫu nới ra).
 *  - Vùng của người được GIỮ luôn được bảo vệ: không bao giờ nằm trong mặt nạ xóa.
 *  - R21: nếu có bộ phát hiện NGƯỜI (EfficientDet-Lite0, xem [PersonDetectorEngine]) thì người quay lưng / che mặt cũng được nhận ra
 *    bằng hộp bao cả người; mặt và hộp được ghép với nhau (mặt nằm trong hộp nào thì thuộc người đó) để một người không bị đếm hai lần.
 *    Cỡ so sánh luôn quy về "diện tích mặt tương đương" (người có mặt: diện tích mặt thật; người chỉ có hộp: suy từ bề ngang hộp ≈ vai 3,2 bề ngang mặt)
 *    nên người bị cắt cụt ở mép ảnh không bị coi là nhỏ.
 * Giới hạn (nói rõ với người dùng): người quá nhỏ / ở rất xa / bị che gần hết không được nhận ra → cần tô tay.
 */
object StrangerMask {

    const val KEEP_RATIO = 0.45f

    /** Mặt: tâm, kích thước (pixel) và trục thân (vector đơn vị hướng từ đầu xuống chân). */
    class Face(val cx: Float, val cy: Float, val fw: Float, val fh: Float, val ax: Float, val ay: Float) {
        val area: Float get() = fw * fh
    }

    /** [detectorOnly] = số người bị xóa mà CHỈ bộ phát hiện người thấy (không có mặt: quay lưng/che mặt). */
    class Result(val mask: ByteArray, val kept: Int, val removed: Int, val coverage: Float, val detectorOnly: Int = 0)

    /** Hộp bao cả người (pixel). */
    class Box(val x0: Float, val y0: Float, val x1: Float, val y1: Float, val score: Float) {
        val w: Float get() = x1 - x0
        val h: Float get() = y1 - y0
        val area: Float get() = w * h
    }

    /** Một người trong ảnh: có mặt, có hộp, hoặc cả hai. [size] = diện tích mặt tương đương để so cỡ. */
    class Subject(val face: Face?, val box: Box?) {
        val size: Float get() = face?.area ?: box!!.let { b -> FACE_AREA_PER_WIDTH2 * b.w * b.w }
    }

    data class Analysis(val keep: List<Subject>, val drop: List<Subject>)

    /** diện tích mặt ≈ 1,25 × (bề ngang mặt)², bề ngang mặt ≈ bề ngang hộp / 3,2 (vai) → mặt tương đương = 1,25/3,2² × w². */
    private const val FACE_AREA_PER_WIDTH2 = 1.25f / (3.2f * 3.2f)
    private const val MIN_BOX_FRAC = 0.03f
    private const val DUP_OVERLAP = 0.6f

    private const val FOREHEAD = 10
    private const val CHIN = 152
    private const val MAX_TILT_DEG = 30.0

    /** Chuyển các mảng điểm mốc (x,y chuẩn hóa 0..1, xem FaceLandmarkerEngine) thành [Face]. Bỏ mặt suy biến. */
    fun faceBoxes(faces: List<FloatArray>, w: Int, h: Int): List<Face> {
        val out = ArrayList<Face>()
        for (lm in faces) {
            val n = if (lm.size == 3 * 478) 478 else lm.size / 2
            if (n < 3) continue
            var x0 = Float.MAX_VALUE; var y0 = Float.MAX_VALUE
            var x1 = -Float.MAX_VALUE; var y1 = -Float.MAX_VALUE
            for (i in 0 until n) {
                val x = lm[2 * i] * w
                val y = lm[2 * i + 1] * h
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
            val fw = x1 - x0
            val fh = y1 - y0
            if (fw < 2f || fh < 2f) continue
            // trục thân: từ trán xuống cằm (nếu có đủ điểm), giới hạn nghiêng ±30° so với phương thẳng đứng
            var ax = 0f
            var ay = 1f
            if (n > CHIN) {
                val dx = (lm[2 * CHIN] - lm[2 * FOREHEAD]) * w
                val dy = (lm[2 * CHIN + 1] - lm[2 * FOREHEAD + 1]) * h
                val len = sqrt(dx * dx + dy * dy)
                if (len > 1e-3f) {
                    var ang = Math.toDegrees(atan2(dx.toDouble(), dy.toDouble()))   // 0° = thẳng xuống
                    ang = ang.coerceIn(-MAX_TILT_DEG, MAX_TILT_DEG)
                    ax = sin(Math.toRadians(ang)).toFloat()
                    ay = cos(Math.toRadians(ang)).toFloat()
                }
            }
            out.add(Face((x0 + x1) / 2f, (y0 + y1) / 2f, fw, fh, ax, ay))
        }
        return out
    }

    /** (giữ, xóa): mặt lớn gần bằng mặt lớn nhất = chủ thể; còn lại = người lạ. */
    fun split(faces: List<Face>, keepRatio: Float = KEEP_RATIO): Pair<List<Face>, List<Face>> {
        if (faces.isEmpty()) return Pair(emptyList(), emptyList())
        val big = faces.maxOf { it.area }
        val keep = faces.filter { it.area >= keepRatio * big }
        val drop = faces.filter { it.area < keepRatio * big }
        return Pair(keep, drop)
    }

    /** [x0,y0,x1,y1,score] chuẩn hóa 0..1 (xem PersonDetectorEngine) → hộp pixel; bỏ hộp suy biến hoặc quá nhỏ (< 3% chiều cao ảnh). */
    fun personBoxes(people: List<FloatArray>, w: Int, h: Int): List<Box> {
        val out = ArrayList<Box>()
        for (p in people) {
            if (p.size < 4) continue
            val x0 = (p[0] * w).coerceIn(0f, w.toFloat())
            val y0 = (p[1] * h).coerceIn(0f, h.toFloat())
            val x1 = (p[2] * w).coerceIn(0f, w.toFloat())
            val y1 = (p[3] * h).coerceIn(0f, h.toFloat())
            if (x1 - x0 < 4f || y1 - y0 < MIN_BOX_FRAC * h) continue
            out.add(Box(x0, y0, x1, y1, if (p.size > 4) p[4] else 1f))
        }
        return out
    }

    /**
     * Ghép mặt với hộp người: mặt nằm trong hộp nào (hộp rộng hơn mặt ≥ 1,5 lần; chọn hộp nhỏ nhất chứa tâm mặt) thì thuộc người đó.
     * Hộp không chứa mặt nào = người quay lưng/che mặt, trừ khi nó chỉ là bản trùng (≥ 60% diện tích nằm trong hộp của người khác).
     */
    fun subjects(faces: List<Face>, boxes: List<Box>): List<Subject> {
        val taken = BooleanArray(boxes.size)
        val out = ArrayList<Subject>()
        for (f in faces) {
            var best = -1
            for ((i, b) in boxes.withIndex()) {
                if (f.cx < b.x0 || f.cx > b.x1 || f.cy < b.y0 || f.cy > b.y1) continue
                if (b.w < 1.5f * f.fw) continue
                if (best < 0 || b.area < boxes[best].area) best = i
            }
            if (best >= 0) taken[best] = true
            out.add(Subject(f, if (best >= 0) boxes[best] else null))
        }
        // hộp chưa có mặt: loại bản trùng (nằm gần hết trong hộp lớn hơn đã có chủ)
        val order = boxes.indices.filter { !taken[it] }.sortedByDescending { boxes[it].area }
        val placed = ArrayList<Box>()
        for (i in boxes.indices) if (taken[i]) placed.add(boxes[i])
        for (i in order) {
            val b = boxes[i]
            val dup = placed.any { o -> o.area >= b.area && overlap(b, o) >= DUP_OVERLAP * b.area }
            if (dup) continue
            placed.add(b)
            out.add(Subject(null, b))
        }
        return out
    }

    private fun overlap(a: Box, b: Box): Float {
        val iw = minOf(a.x1, b.x1) - maxOf(a.x0, b.x0)
        val ih = minOf(a.y1, b.y1) - maxOf(a.y0, b.y0)
        return if (iw <= 0f || ih <= 0f) 0f else iw * ih
    }

    /** (giữ, xóa) theo [subjects]: người có cỡ ≥ [keepRatio] × cỡ lớn nhất là cùng nhóm chủ thể; còn lại là người lạ. */
    fun analyze(faces: List<FloatArray>, people: List<FloatArray>?, w: Int, h: Int, keepRatio: Float = KEEP_RATIO): Analysis {
        val subs = subjects(faceBoxes(faces, w, h), if (people.isNullOrEmpty()) emptyList() else personBoxes(people, w, h))
        if (subs.isEmpty()) return Analysis(emptyList(), emptyList())
        val big = subs.maxOf { it.size }
        return Analysis(subs.filter { it.size >= keepRatio * big }, subs.filter { it.size < keepRatio * big })
    }

    /**
     * Mặt nạ (255 = xóa) cho người lạ, hoặc null nếu không có ai để xóa.
     * [fg] = mặt nạ chủ thể 0..1 từ model tách nền (tùy chọn, kích thước w*h).
     */
    fun build(faces: List<FloatArray>, w: Int, h: Int, fg: FloatArray? = null, people: List<FloatArray>? = null): Result? {
        val (keep, drop) = analyze(faces, people, w, h)
        if (drop.isEmpty()) return null
        val n = w * h

        // vùng bảo vệ = thân người được giữ (nới nhẹ)
        val protect = ByteArray(n)
        for (s in keep) {
            s.face?.let { paintBody(it, w, h, protect, scale = 1.12f) }
            s.box?.let { paintBox(it, w, h, protect, scale = 1.06f) }
        }

        val remove = ByteArray(n)
        for (s in drop) {
            val f = s.face
            if (f != null) {
                val body = ByteArray(n)
                paintBody(f, w, h, body, scale = 1f)
                val head = ByteArray(n)
                paintHead(f, w, h, head, scale = 1.1f)
                val chosen = if (fg != null && fg.size == n) refine(body, head, fg, f, w, h) else body
                for (i in 0 until n) if (chosen[i].toInt() != 0) remove[i] = 255.toByte()
            } else {
                // chỉ có hộp (quay lưng / che mặt): hình "elip mũ" nội tiếp hộp, bám theo cơ thể thật nếu có mặt nạ chủ thể phủ đủ
                val b = s.box!!
                val shape = ByteArray(n)
                paintBox(b, w, h, shape, scale = 1f)
                val chosen = if (fg != null && fg.size == n) refineBox(shape, fg, b, w, h) else shape
                for (i in 0 until n) if (chosen[i].toInt() != 0) remove[i] = 255.toByte()
            }
        }
        // nới mép để nuốt viền/bóng của người lạ (tỉ lệ theo cỡ mặt trung bình của người bị xóa)
        val meanFace = drop.map { sqrt(it.size) }.average().toFloat()
        val grow = (0.10f * meanFace).roundToInt().coerceIn(3, 24)
        val grown = dilate(remove, w, h, grow)
        for (i in 0 until n) if (protect[i].toInt() != 0) grown[i] = 0
        var cnt = 0
        for (v in grown) if (v.toInt() != 0) cnt++
        if (cnt == 0) return null
        return Result(grown, keep.size, drop.size, cnt / n.toFloat(), drop.count { it.face == null })
    }

    /** Như [refine] nhưng cho người chỉ có hộp: giữ phần điểm thuộc chủ thể nằm trong hình nội tiếp nới ra 6% bề ngang hộp. */
    private fun refineBox(shape: ByteArray, fg: FloatArray, b: Box, w: Int, h: Int): ByteArray {
        val n = w * h
        var tpl = 0
        var hit = 0
        for (i in 0 until n) if (shape[i].toInt() != 0) { tpl++; if (fg[i] >= 0.5f) hit++ }
        if (tpl == 0 || hit < 0.35f * tpl) return shape
        val rad = max(2f, 0.06f * b.w)
        val d = DistanceField.chamfer(BooleanArray(n) { shape[it].toInt() != 0 }, w, h)
        return ByteArray(n) { if (fg[it] >= 0.5f && d[it] <= rad) 255.toByte() else 0 }
    }

    /** "Elip mũ" (|x|³ + |y|³ ≤ 1) nội tiếp hộp [b], phóng [scale] lần quanh tâm: phủ ~88% hộp, hẹp ở bốn góc như dáng người. */
    private fun paintBox(b: Box, w: Int, h: Int, out: ByteArray, scale: Float) {
        val cx = (b.x0 + b.x1) / 2f
        val cy = (b.y0 + b.y1) / 2f
        val rx = max(1f, b.w / 2f * scale)
        val ry = max(1f, b.h / 2f * scale)
        val xa = max(0, (cx - rx).toInt())
        val xb = minOf(w - 1, (cx + rx).toInt() + 1)
        val ya = max(0, (cy - ry).toInt())
        val yb = minOf(h - 1, (cy + ry).toInt() + 1)
        for (y in ya..yb) {
            val ny = kotlin.math.abs(y + 0.5f - cy) / ry
            val y3 = ny * ny * ny
            if (y3 > 1f) continue
            for (x in xa..xb) {
                val nx = kotlin.math.abs(x + 0.5f - cx) / rx
                if (nx * nx * nx + y3 <= 1f) out[y * w + x] = 255.toByte()
            }
        }
    }

    /** Bám theo cơ thể thật nếu mặt nạ chủ thể phủ đủ khuôn mẫu; không thì dùng nguyên khuôn mẫu. */
    private fun refine(body: ByteArray, head: ByteArray, fg: FloatArray, f: Face, w: Int, h: Int): ByteArray {
        val n = w * h
        var tpl = 0
        var hit = 0
        for (i in 0 until n) if (body[i].toInt() != 0) { tpl++; if (fg[i] >= 0.5f) hit++ }
        if (tpl == 0 || hit < 0.35f * tpl) return body
        val rad = max(2f, 0.18f * f.fw)
        val d = DistanceField.chamfer(BooleanArray(n) { body[it].toInt() != 0 }, w, h)
        val out = ByteArray(n)
        for (i in 0 until n) {
            if (head[i].toInt() != 0) out[i] = 255.toByte()
            else if (fg[i] >= 0.5f && d[i] <= rad) out[i] = 255.toByte()
        }
        return out
    }

    private fun dilate(m: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        val d = DistanceField.chamfer(BooleanArray(w * h) { m[it].toInt() != 0 }, w, h)
        return ByteArray(w * h) { if (d[it] <= r) 255.toByte() else 0 }
    }

    // ---------------------------------------------------------------- khuôn mẫu cơ thể (tọa độ cục bộ: u = ngang vai, v = dọc thân, gốc = tâm mặt)
    private class Frame(val f: Face) {
        // trục dọc (xuống) = (ax, ay); trục ngang = (ay, -ax)
        fun x(u: Float, v: Float) = f.cx + u * f.ay + v * f.ax
        fun y(u: Float, v: Float) = f.cy - u * f.ax + v * f.ay
    }

    private fun poly(fr: Frame, pts: List<Pair<Float, Float>>, w: Int, h: Int, out: ByteArray) {
        val xs = FloatArray(pts.size) { fr.x(pts[it].first, pts[it].second) }
        val ys = FloatArray(pts.size) { fr.y(pts[it].first, pts[it].second) }
        FaceGeometry.fillPolygon(xs, ys, w, h, out)
    }

    private fun paintHead(f: Face, w: Int, h: Int, out: ByteArray, scale: Float) {
        val fr = Frame(f)
        val pts = ArrayList<Pair<Float, Float>>()
        val rx = 0.68f * f.fw * scale
        val ry = 0.74f * f.fh * scale
        val cv = -0.12f * f.fh
        for (k in 0 until 28) {
            val t = (2.0 * Math.PI * k / 28).toFloat()
            pts.add(Pair(rx * cos(t), cv + ry * sin(t)))
        }
        poly(fr, pts, w, h, out)
    }

    /** Đầu + cổ + thân + hai chân theo tỉ lệ người lớn (≈ 9,2 lần chiều cao mặt tính từ đỉnh đầu). */
    private fun paintBody(f: Face, w: Int, h: Int, out: ByteArray, scale: Float) {
        val fr = Frame(f)
        paintHead(f, w, h, out, scale)
        val fh = f.fh
        val fw = f.fw * scale
        // cổ
        poly(fr, listOf(Pair(-0.32f * fw, 0.35f * fh), Pair(0.32f * fw, 0.35f * fh), Pair(0.36f * fw, 1.0f * fh), Pair(-0.36f * fw, 1.0f * fh)), w, h, out)
        // thân: vai (rộng ≈ 3,2 bề ngang mặt) → hông
        val sh = 1.6f * fw
        val hip = 1.3f * fw
        poly(fr, listOf(
            Pair(-0.55f * fw, 0.9f * fh), Pair(0.55f * fw, 0.9f * fh),
            Pair(sh, 1.15f * fh), Pair(sh, 2.6f * fh),
            Pair(hip, 4.4f * fh), Pair(-hip, 4.4f * fh),
            Pair(-sh, 2.6f * fh), Pair(-sh, 1.15f * fh)
        ), w, h, out)
        // hai chân
        val feet = 8.5f * fh
        poly(fr, listOf(Pair(-hip, 4.3f * fh), Pair(-0.05f * fw, 4.3f * fh), Pair(-0.1f * fw, feet), Pair(-0.95f * fw, feet)), w, h, out)
        poly(fr, listOf(Pair(0.05f * fw, 4.3f * fh), Pair(hip, 4.3f * fh), Pair(0.95f * fw, feet), Pair(0.1f * fw, feet)), w, h, out)
    }
}
