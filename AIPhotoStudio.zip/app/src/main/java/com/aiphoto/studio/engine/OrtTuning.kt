package com.aiphoto.studio.engine

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession

/**
 * Tạo phiên ONNX Runtime theo cấu hình thiết bị (số luồng + danh sách bộ tăng tốc muốn thử, đọc từ cấu hình định tuyến).
 * Mặc định chỉ CPU. "xnnpack" / "nnapi" (lỗi thời từ Android 15) / "qnn" là TÙY CHỌN, bật từ xa trên dòng máy đã thử nghiệm; mỗi cái được thử
 * lần lượt, lỗi thì bỏ qua và rơi về CPU. ("qnn" cần bản `onnxruntime-android-qnn`, xem app/build.gradle.kts - -PuseQnn=true.)
 */
object OrtTuning {
    @Volatile var threads: Int = 4
    @Volatile var accel: List<String> = emptyList()

    fun createSession(env: OrtEnvironment, path: String): OrtSession {
        for (a in accel) {
            val opts = OrtSession.SessionOptions()
            try {
                opts.setIntraOpNumThreads(threads)
                opts.setInterOpNumThreads(1)
                val ok = when (a) {
                    "xnnpack" -> { opts.addXnnpack(mapOf("intra_op_num_threads" to threads.toString())); true }
                    "nnapi" -> {
                        // R31: NNAPI bị Google đánh dấu lỗi thời từ Android 15 và ONNX Runtime cũng đã đánh dấu EP này sắp bị loại (từ 1.21)
                        // ⇒ gọi bằng reflection (cùng cách với "qnn"): bản ORT nào bỏ API này vẫn biên dịch được, thiếu thì ném lỗi và rơi về CPU.
                        opts.javaClass.getMethod("addNnapi").invoke(opts)
                        true
                    }
                    "qnn" -> {
                        // gọi bằng reflection để vẫn biên dịch được khi dùng bản onnxruntime-android thường
                        opts.javaClass.getMethod("addQnn", Map::class.java)
                            .invoke(opts, mapOf("backend_path" to "libQnnHtp.so"))
                        true
                    }
                    else -> false
                }
                if (ok) return env.createSession(path, opts)
                opts.close()
            } catch (e: Throwable) {
                try { opts.close() } catch (e2: Throwable) { }
            }
        }
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(threads)
        opts.setInterOpNumThreads(1)
        return env.createSession(path, opts)
    }
}
