package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min

/**
 * Đổi kích thước kênh số thực (thuần Kotlin, kiểm thử được): [area] = trung bình theo ô (thu nhỏ, khử răng cưa),
 * [bilinear] = nội suy song tuyến tính (phóng to). Dùng cho các phép làm ở độ phân giải trần (làm nét lại, khử moiré,
 * phong cách) rồi đưa kết quả về ảnh gốc.
 */
object Resample {

    /** Thu nhỏ bằng trung bình có trọng số diện tích (đúng với mọi tỉ lệ, kể cả không nguyên). */
    fun area(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        require(src.size == sw * sh && dw > 0 && dh > 0)
        if (dw == sw && dh == sh) return src.copyOf()
        // tách hai chiều: trước theo ngang, sau theo dọc (trung bình có trọng số diện tích mỗi chiều)
        val tmp = FloatArray(dw * sh)
        val sx = sw.toDouble() / dw
        for (y in 0 until sh) {
            val row = y * sw
            for (x in 0 until dw) {
                val a = x * sx
                val b = (x + 1) * sx
                var i = a.toInt()
                var acc = 0.0
                while (i < b && i < sw) {
                    val lo = max(a, i.toDouble())
                    val hi = min(b, (i + 1).toDouble())
                    acc += src[row + i] * (hi - lo)
                    i++
                }
                tmp[y * dw + x] = (acc / sx).toFloat()
            }
        }
        val out = FloatArray(dw * dh)
        val sy = sh.toDouble() / dh
        for (y in 0 until dh) {
            val a = y * sy
            val b = (y + 1) * sy
            for (x in 0 until dw) {
                var j = a.toInt()
                var acc = 0.0
                while (j < b && j < sh) {
                    val lo = max(a, j.toDouble())
                    val hi = min(b, (j + 1).toDouble())
                    acc += tmp[j * dw + x] * (hi - lo)
                    j++
                }
                out[y * dw + x] = (acc / sy).toFloat()
            }
        }
        return out
    }

    /** Nội suy song tuyến tính theo tâm điểm ảnh (khớp [area] khi thu nhỏ rồi phóng lại). */
    fun bilinear(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        require(src.size == sw * sh && dw > 0 && dh > 0)
        if (dw == sw && dh == sh) return src.copyOf()
        val out = FloatArray(dw * dh)
        val fx = sw.toFloat() / dw
        val fy = sh.toFloat() / dh
        for (y in 0 until dh) {
            val gy = ((y + 0.5f) * fy - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = gy.toInt()
            val y1 = min(sh - 1, y0 + 1)
            val ty = gy - y0
            for (x in 0 until dw) {
                val gx = ((x + 0.5f) * fx - 0.5f).coerceIn(0f, (sw - 1).toFloat())
                val x0 = gx.toInt()
                val x1 = min(sw - 1, x0 + 1)
                val tx = gx - x0
                val a = src[y0 * sw + x0] * (1 - tx) + src[y0 * sw + x1] * tx
                val b = src[y1 * sw + x0] * (1 - tx) + src[y1 * sw + x1] * tx
                out[y * dw + x] = a * (1 - ty) + b * ty
            }
        }
        return out
    }

    /**
     * Như [area] nhưng lấy giá trị từ ảnh ARGB [px] qua hàm [f] (vd. độ chói) mà KHÔNG dựng mảng Float cỡ ảnh gốc
     * (tiết kiệm bộ nhớ với ảnh vài chục triệu điểm).
     */
    fun areaMap(px: IntArray, sw: Int, sh: Int, dw: Int, dh: Int, f: (Int) -> Float): FloatArray {
        require(px.size == sw * sh && dw > 0 && dh > 0)
        val tmp = FloatArray(dw * sh)
        val sx = sw.toDouble() / dw
        for (y in 0 until sh) {
            val row = y * sw
            for (x in 0 until dw) {
                val a = x * sx
                val b = (x + 1) * sx
                var i = a.toInt()
                var acc = 0.0
                while (i < b && i < sw) {
                    val lo = max(a, i.toDouble())
                    val hi = min(b, (i + 1).toDouble())
                    acc += f(px[row + i]) * (hi - lo)
                    i++
                }
                tmp[y * dw + x] = (acc / sx).toFloat()
            }
        }
        val out = FloatArray(dw * dh)
        val sy = sh.toDouble() / dh
        for (y in 0 until dh) {
            val a = y * sy
            val b = (y + 1) * sy
            for (x in 0 until dw) {
                var j = a.toInt()
                var acc = 0.0
                while (j < b && j < sh) {
                    val lo = max(a, j.toDouble())
                    val hi = min(b, (j + 1).toDouble())
                    acc += tmp[j * dw + x] * (hi - lo)
                    j++
                }
                out[y * dw + x] = (acc / sy).toFloat()
            }
        }
        return out
    }

    /** Giá trị song tuyến tính tại điểm ảnh ([x],[y]) của lưới đích dw×dh được lấy từ mảng nguồn [src] sw×sh (cùng quy ước với [bilinear]). */
    fun bilinearAt(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int, x: Int, y: Int): Float {
        val gy = ((y + 0.5f) * sh / dh - 0.5f).coerceIn(0f, (sh - 1).toFloat())
        val gx = ((x + 0.5f) * sw / dw - 0.5f).coerceIn(0f, (sw - 1).toFloat())
        val y0 = gy.toInt()
        val x0 = gx.toInt()
        val y1 = min(sh - 1, y0 + 1)
        val x1 = min(sw - 1, x0 + 1)
        val tx = gx - x0
        val ty = gy - y0
        val a = src[y0 * sw + x0] * (1 - tx) + src[y0 * sw + x1] * tx
        val b = src[y1 * sw + x0] * (1 - tx) + src[y1 * sw + x1] * tx
        return a * (1 - ty) + b * ty
    }

    /** Kích thước sau khi giới hạn cạnh dài ≤ [cap] (giữ tỉ lệ, mỗi cạnh ≥ 1). */
    fun capped(w: Int, h: Int, cap: Int): Pair<Int, Int> {
        val long = max(w, h)
        if (long <= cap) return Pair(w, h)
        val k = cap.toDouble() / long
        return Pair(max(1, Math.round(w * k).toInt()), max(1, Math.round(h * k).toInt()))
    }
}
