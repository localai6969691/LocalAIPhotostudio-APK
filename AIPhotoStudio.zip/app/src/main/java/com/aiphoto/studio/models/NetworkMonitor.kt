package com.aiphoto.studio.models

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities

/**
 * R44: theo dõi mạng mặc định của máy và phân loại bằng [NetworkPolicy.classify] (có Internet? có tính cước?).
 * Đọc nhanh qua [kind] (giá trị đệm, cập nhật bởi callback hệ thống) nên gọi được từ vòng đọc dữ liệu của bộ tải mà không tốn thời gian.
 *
 * Cần quyền ACCESS_NETWORK_STATE (quyền thường, tự cấp). Thiếu quyền / hệ thống từ chối ⇒ coi là mạng không tính cước:
 * thà tải khi chưa chắc còn hơn chặn người dùng mãi (bộ tải vẫn có kiểm tra riêng khi lỗi mạng).
 */
class NetworkMonitor(context: Context, private val onChange: (NetKind) -> Unit) {
    private val cm: ConnectivityManager? = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    @Volatile var kind: NetKind = read()
        private set

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { refresh() }
        override fun onLost(network: Network) { refresh() }
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) { refresh() }
    }

    /** Đăng ký nhận thay đổi (gọi một lần; callback sống cùng tiến trình — rất nhẹ). */
    fun start() {
        runCatching { cm?.registerDefaultNetworkCallback(callback) }
        refresh()
    }

    fun stop() {
        runCatching { cm?.unregisterNetworkCallback(callback) }
    }

    private fun refresh() {
        val k = read()
        if (k != kind) {
            kind = k
            runCatching { onChange(k) }
        }
    }

    private fun read(): NetKind {
        val m = cm ?: return NetKind.UNMETERED
        return try {
            val net = m.activeNetwork ?: return NetKind.OFFLINE
            val caps = m.getNetworkCapabilities(net) ?: return NetKind.OFFLINE
            // isActiveNetworkMetered đã tính cả trường hợp "tạm thời không tính cước" của nhà mạng
            NetworkPolicy.classify(
                hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
                notMetered = !m.isActiveNetworkMetered
            )
        } catch (e: RuntimeException) {
            NetKind.UNMETERED      // gồm cả SecurityException khi thiếu quyền ACCESS_NETWORK_STATE: không chặn người dùng khi không đọc được
        }
    }
}
