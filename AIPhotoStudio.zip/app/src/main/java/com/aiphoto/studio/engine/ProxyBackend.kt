package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.aiphoto.studio.integrity.IntegrityGateway
import com.aiphoto.studio.integrity.IntegrityHash
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tạo ảnh qua MÁY CHỦ TRUNG GIAN CỦA BẠN (hướng thương mại): app KHÔNG giữ khóa của nhà cung cấp AI; máy chủ giữ khóa,
 * tính credits, và có thể đổi nhà cung cấp/model bất cứ lúc nào mà không cần cập nhật app. Xem thư mục `backend/`.
 * Máy chỉ gửi phần ảnh quanh vùng chọn + mặt nạ, nhận ảnh về rồi dán lại cục bộ (giống GeminiImageBackend).
 */
class ProxyBackend(baseUrl: String, private val token: String) : GenerativeFill {

    private val base = baseUrl.trim().trimEnd('/')
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile var credits: Int? = null
        private set

    override fun cancel() {
        try { conn?.disconnect() } catch (e: Throwable) { }
    }

    override fun inpaint(image: Bitmap, mask: ByteArray, prompt: String, size: Int, opts: GenOptions): Bitmap {
        val w = image.width
        val rect = RegionCrop.compute(mask, w, image.height) ?: return image
        val crop = Bitmap.createBitmap(image, rect.x, rect.y, rect.w, rect.h)
        val scale = min(1f, 1024f / max(rect.w, rect.h))
        val sw = max(1, (rect.w * scale).roundToInt())
        val sh = max(1, (rect.h * scale).roundToInt())
        val sendImg = if (scale < 1f) Bitmap.createScaledBitmap(crop, sw, sh, true) else crop
        val maskFull = makeBitmap(RegionCrop.maskGray(mask, w, rect), rect.w, rect.h)
        val sendMask = if (scale < 1f) Bitmap.createScaledBitmap(maskFull, sw, sh, true) else maskFull

        val body = JSONObject()
            .put("image", png(sendImg))
            .put("mask", png(sendMask))
            .put("mask_alpha", png(alphaMask(sendMask)))
            .put("prompt", prompt)
            .put("quality", if (opts.quality == GenQuality.HIGH) "high" else "fast")
            .put("seed", opts.seed)
            .put("negative", opts.negative)
            .put("strength", (opts.strength ?: 0f).toDouble())
        val resp = JSONObject(request("POST", "/v1/generative_fill", body.toString(), 180_000))
        if (resp.has("credits")) credits = resp.optInt("credits")
        val bytes = Base64.decode(resp.getString("image"), Base64.DEFAULT)
        val result = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IOException("Không giải mã được ảnh từ máy chủ")
        val generated = Bitmap.createScaledBitmap(result, rect.w, rect.h, true)
        return RegionCrop.composite(image, mask, rect, generated)
    }

    /** Mặt nạ kiểu OpenAI /v1/images/edits: pixel TRONG SUỐT = vùng được sửa, đục = giữ nguyên. */
    private fun alphaMask(gray: Bitmap): Bitmap {
        val px = readPixels(gray)
        for (i in px.indices) px[i] = if (((px[i] shr 16) and 255) > 127) 0 else (255 shl 24)
        return makeBitmap(px, gray.width, gray.height)
    }

    private fun png(b: Bitmap): String {
        val bytes = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** R32: gặp 403 `integrity_required` thì chứng thực Play Integrity (nếu bản build có) rồi thử lại ĐÚNG MỘT lần. */
    private fun request(method: String, path: String, json: String?, readTimeoutMs: Int): String =
        try {
            requestOnce(method, path, json, readTimeoutMs)
        } catch (e: IntegrityRequired) {
            val h = integrityHook
            if (h != null && h(base, token)) requestOnce(method, path, json, readTimeoutMs) else throw e
        }

    private fun requestOnce(method: String, path: String, json: String?, readTimeoutMs: Int): String {
        val c = URL(base + path).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = readTimeoutMs
            c.setRequestProperty("Authorization", "Bearer $token")
            if (json != null) {
                val data = json.toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setFixedLengthStreamingMode(data.size)
                c.outputStream.use { it.write(data) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getString("error") }.getOrDefault(text.take(200))
                val hint = when (code) {
                    401 -> " (phiên đăng ký hết hạn - bấm Đăng ký lại trong Cài đặt)"
                    402 -> " (hết credits)"
                    else -> ""
                }
                if (code == 403 && text.contains("integrity_required")) throw IntegrityRequired("Máy chủ yêu cầu chứng thực thiết bị (Play Integrity): ${msg.take(200)}")
                throw IOException("Máy chủ trả mã $code$hint: ${msg.take(200)}")
            }
            return text
        } finally {
            c.disconnect()
            if (conn === c) conn = null
        }
    }

    /** 403 `integrity_required` từ máy chủ (kế thừa IOException nên mã cũ bắt IOException vẫn chạy như trước khi không có móc chứng thực). */
    private class IntegrityRequired(message: String) : IOException(message)

    companion object {
        /**
         * R32: móc chứng thực Play Integrity do MainViewModel gắn khi bản build có cổng thật; (base, token) → true nếu đã chứng thực xong.
         * null (mặc định, và với bản stub) ⇒ hành vi y như trước.
         */
        @Volatile var integrityHook: ((String, String) -> Boolean)? = null

        /**
         * Chứng thực Play Integrity MỘT lần (chặn luồng gọi — chạy ở luồng nền như mọi lệnh mạng khác ở đây): xin thử thách → xin token gắn requestHash
         * (SHA-256 của "device_id|thử thách") → gửi máy chủ xác minh. device_id lấy từ token đăng nhập ("device_id.chữ_ký"). true = máy chủ đã xác nhận.
         */
        fun attest(base: String, token: String, gateway: IntegrityGateway): Boolean {
            if (!gateway.available) return false
            val deviceId = token.substringBeforeLast('.')
            val challenge = JSONObject(callOnce(base, "GET", "/v1/integrity/challenge", token, null)).getString("challenge")
            val result = java.util.concurrent.atomic.AtomicReference<Pair<String?, String?>>(null)
            val latch = java.util.concurrent.CountDownLatch(1)
            gateway.requestToken(IntegrityHash.forChallenge(deviceId, challenge)) { t, e -> result.set(Pair(t, e)); latch.countDown() }
            if (!latch.await(75, java.util.concurrent.TimeUnit.SECONDS)) return false
            val tok = result.get()?.first ?: return false
            val body = JSONObject().put("integrity_token", tok).put("challenge", challenge).toString()
            JSONObject(callOnce(base, "POST", "/v1/integrity/verify", token, body, 60_000))
            return true
        }

        private fun call(base: String, method: String, path: String, token: String?, json: String?, readMs: Int = 30_000): String =
            try {
                callOnce(base, method, path, token, json, readMs)
            } catch (e: IntegrityRequired) {
                val h = integrityHook
                if (h != null && token != null && h(base, token)) callOnce(base, method, path, token, json, readMs) else throw e
            }

        private fun callOnce(base: String, method: String, path: String, token: String?, json: String?, readMs: Int = 30_000): String {
            val c = URL(base.trim().trimEnd('/') + path).openConnection() as HttpURLConnection
            try {
                c.requestMethod = method
                c.connectTimeout = 15_000
                c.readTimeout = readMs
                if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
                if (json != null) {
                    val data = json.toByteArray(Charsets.UTF_8)
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setFixedLengthStreamingMode(data.size)
                    c.outputStream.use { it.write(data) }
                }
                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code == 403 && text.contains("integrity_required")) throw IntegrityRequired("Máy chủ yêu cầu chứng thực thiết bị (Play Integrity): ${text.take(300)}")
                if (code !in 200..299) throw IOException("Máy chủ trả mã $code: ${text.take(1200)}")
                return text
            } finally {
                c.disconnect()
            }
        }

        /** Đăng ký thiết bị -> (token, credits). */
        fun register(base: String, deviceId: String): Pair<String, Int> {
            val r = JSONObject(call(base, "POST", "/v1/register", null, JSONObject().put("device_id", deviceId).toString()))
            return Pair(r.getString("token"), r.optInt("credits"))
        }

        fun fetchCredits(base: String, token: String): Int =
            JSONObject(call(base, "GET", "/v1/credits", token, null)).getInt("credits")

        /** Gói tài khoản do máy chủ quyết định: Free (watermark, không chất lượng cao) hay Pro (đến [planUntil], giây Unix). */
        class Account(
            val plan: String, val planUntil: Long, val credits: Int, val highQuality: Boolean, val watermark: Boolean,
            /** R22: nhóm Team/Enterprise đang tham gia (null = không); `credits` đã gồm quỹ nhóm, hai số dưới tách riêng để hiển thị. */
            val team: TeamInfo? = null, val creditsPersonal: Int = -1, val creditsTeam: Int = 0,
            /** R23: máy chủ đang ở chế độ dùng thử miễn phí; số lượt đã dùng trong 24 giờ qua (-1 = máy chủ cũ không báo) và trần (0 = không giới hạn). */
            val openBeta: Boolean = false, val usageToday: Int = -1, val dailyLimit: Int = 0,
            /** R23: máy chủ có cung cấp AI đám mây (bằng khóa của chủ app) cho tài khoản này không; máy chủ cũ không báo = có. */
            val serverAi: Boolean = true
        ) {
            val isPro: Boolean get() = plan == "pro"
        }

        internal fun parseAccount(r: JSONObject): Account {
            val lim = r.optJSONObject("limits")
            return Account(
                r.optString("plan", "free"), r.optLong("plan_until"), r.optInt("credits"),
                lim?.optBoolean("high_quality", false) ?: false, lim?.optBoolean("watermark", true) ?: true,
                TeamInfo.fromJson(r.optJSONObject("team")), r.optInt("credits_personal", -1), r.optInt("credits_team", 0),
                r.optBoolean("open_beta", false), r.optInt("usage_today", -1), r.optInt("daily_limit", 0),
                r.optBoolean("server_ai", true)
            )
        }

        fun fetchAccount(base: String, token: String): Account =
            parseAccount(JSONObject(call(base, "GET", "/v1/account", token, null)))

        // ------------------------------------------------------------------ gói Team/Enterprise (R22): máy chủ kiểm quyền từng lệnh
        private fun teamOf(r: JSONObject): TeamInfo? = TeamInfo.fromJson(r.optJSONObject("team"))

        /** Nhóm hiện tại (kèm danh sách thành viên nếu là quản trị viên); null = chưa thuộc nhóm nào. */
        fun fetchTeam(base: String, token: String): TeamInfo? = teamOf(JSONObject(call(base, "GET", "/v1/team", token, null)))

        fun teamJoin(base: String, token: String, code: String): TeamInfo? =
            teamOf(JSONObject(call(base, "POST", "/v1/team/join", token, JSONObject().put("code", code).toString())))

        /** Tạo nhóm (chỉ khi máy chủ cho tự tạo) -> (nhóm, mã mời; mã mời CHỈ hiện lúc này). */
        fun teamCreate(base: String, token: String, name: String): Pair<TeamInfo?, String> {
            val r = JSONObject(call(base, "POST", "/v1/team/create", token, JSONObject().put("name", name).toString()))
            return Pair(teamOf(r), r.optString("invite_code"))
        }

        fun teamLeave(base: String, token: String) {
            call(base, "POST", "/v1/team/leave", token, "{}")
        }

        fun teamRemove(base: String, token: String, memberId: String): TeamInfo? =
            teamOf(JSONObject(call(base, "POST", "/v1/team/remove", token, JSONObject().put("member_id", memberId).toString())))

        fun teamTransfer(base: String, token: String, memberId: String): TeamInfo? =
            teamOf(JSONObject(call(base, "POST", "/v1/team/transfer", token, JSONObject().put("member_id", memberId).toString())))

        /** Đổi mã mời (mã cũ hết hiệu lực) -> mã mới. */
        fun teamInvite(base: String, token: String): String =
            JSONObject(call(base, "POST", "/v1/team/invite", token, "{}")).optString("invite_code")

        /** Chuyển credits cá nhân của quản trị viên vào quỹ nhóm (một chiều) -> (nhóm, credits dùng được). */
        fun teamFund(base: String, token: String, credits: Int): Pair<TeamInfo?, Int> {
            val r = JSONObject(call(base, "POST", "/v1/team/fund", token, JSONObject().put("credits", credits).toString()))
            return Pair(teamOf(r), r.optInt("credits"))
        }

        /** Đổi giao dịch Google Play thành credits / gói Pro (máy chủ tự xác minh với Google). */
        fun redeem(base: String, token: String, productId: String, purchaseToken: String): Account {
            val body = JSONObject().put("product_id", productId).put("purchase_token", purchaseToken).toString()
            val r = JSONObject(call(base, "POST", "/v1/billing/redeem", token, body, 60_000))
            return Account(r.optString("plan", "free"), r.optLong("plan_until"), r.optInt("credits"), r.optString("plan") == "pro", r.optString("plan") != "pro")
        }

        /**
         * Đăng ký định kỳ: báo giao dịch cho máy chủ -> máy chủ hỏi Google (subscriptionsv2), ghi hạn Pro, cộng credits của kỳ (đúng một lần
         * cho mỗi mã đơn hàng). Gọi lại nhiều lần an toàn (cũng là cách KHÔI PHỤC). Trả (tài khoản, "ok" | "pending" | "client");
         * "client" = máy chủ yêu cầu app tự acknowledgePurchase.
         */
        fun subscribe(base: String, token: String, productId: String, purchaseToken: String): Pair<Account, String> {
            val body = JSONObject().put("product_id", productId).put("purchase_token", purchaseToken).toString()
            val r = JSONObject(call(base, "POST", "/v1/billing/subscribe", token, body, 60_000))
            val pro = r.optString("plan") == "pro"
            return Pair(Account(r.optString("plan", "free"), r.optLong("plan_until"), r.optInt("credits"), pro, !pro), r.optString("ack", "ok"))
        }

        /**
         * Agent AI: gửi ẢNH THU NHỎ (≤ 768 px, JPEG) + yêu cầu cho mô hình đa phương thức ở máy chủ, nhận về kế hoạch chỉnh dạng JSON
         * {"ops":[{"op","value","arg"?,"scope"?}]} (đã lọc ở máy chủ) -> (JSON, credits còn lại). Ảnh gốc không rời máy.
         */
        fun editPlan(base: String, token: String, image: Bitmap, prompt: String, reference: Bitmap? = null): Pair<String, Int> {
            val longSide = max(image.width, image.height)
            val s = if (longSide > 768) 768f / longSide else 1f
            val small = if (s < 1f) Bitmap.createScaledBitmap(image, max(1, (image.width * s).roundToInt()), max(1, (image.height * s).roundToInt()), true) else image
            val bos = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 85, bos)
            val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            val json = JSONObject().put("image", b64).put("prompt", prompt)
            if (reference != null) {
                // R30: ảnh MẪU phong cách (≤ 512 px) để máy chủ cho agent suy ra gu màu / tông rồi chỉnh ảnh chính theo hướng đó
                val rs = max(reference.width, reference.height)
                val k = if (rs > 512) 512f / rs else 1f
                val smallRef = if (k < 1f) Bitmap.createScaledBitmap(reference, max(1, (reference.width * k).roundToInt()), max(1, (reference.height * k).roundToInt()), true) else reference
                val rb = ByteArrayOutputStream()
                smallRef.compress(Bitmap.CompressFormat.JPEG, 80, rb)
                json.put("reference", Base64.encodeToString(rb.toByteArray(), Base64.NO_WRAP))
            }
            val body = json.toString()
            val r = JSONObject(call(base, "POST", "/v1/edit_plan", token, body, 70_000))
            return Pair(r.getJSONObject("plan").toString(), r.optInt("credits"))
        }

        /** Cấu hình định tuyến do máy chủ quyết định theo hạng thiết bị / phiên bản app. */
        fun fetchRouting(base: String, token: String, tier: String, appVersion: String): String =
            call(base, "GET", "/v1/routing?tier=$tier&app=$appVersion", token, null)
    }
}
