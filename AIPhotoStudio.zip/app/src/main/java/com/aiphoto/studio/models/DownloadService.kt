package com.aiphoto.studio.models

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.aiphoto.studio.i18n.I18n
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * R44: dịch vụ nền (foreground service, kiểu `dataSync`) cho việc tải model — giữ tiến trình sống và hiện thông báo tiến độ khi người dùng
 * thoát khỏi app, để tải KHÔNG dừng khi app không còn ở màn hình.
 *
 * Dịch vụ chỉ là "vỏ": việc tải thật do [ModelHub] (sống trong phạm vi ứng dụng) làm; dịch vụ quan sát trạng thái của hub để cập nhật thông báo
 * và tự dừng khi hàng đợi rỗng. Nút "Hủy" trên thông báo hủy toàn bộ hàng đợi.
 *
 * Giới hạn đã biết:
 *  - Android 15 (API 35) giới hạn dịch vụ dataSync chạy nền tối đa 6 giờ / 24 giờ rồi gọi `onTimeout` (bắt buộc dừng trong vài giây, không thì app bị đóng).
 *    Mã này biên dịch cho cả compileSdk 34 (bản tester) nên không ghi đè `onTimeout`; thay vào đó tự dừng sau [WATCHDOG_MS] (5,5 giờ) — luôn trước giới hạn.
 *    Hàng đợi vẫn còn (tải tiếp khi mở app) và hub vẫn tải được trong lúc tiến trình còn sống.
 *  - Google Play yêu cầu khai báo loại dịch vụ nền `dataSync` trong Play Console (mục "Nội dung ứng dụng → Dịch vụ trên nền trước").
 *  - Không có quyền hiện thông báo (Android 13+) thì dịch vụ vẫn chạy nhưng thông báo bị ẩn (xem trong "Ứng dụng đang hoạt động").
 */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observer: Job? = null
    private var watchdog: Job? = null
    private var lastKind = ""
    private var lastPct = -1
    private var lastAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        I18n.init(applicationContext)     // dịch vụ có thể được dựng lại khi chưa có màn hình nào: nạp ngôn ngữ cho thông báo
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val hub = ModelServices.hub(applicationContext)
        if (intent?.action == ACTION_CANCEL) hub.cancel()
        // phải gọi startForeground sớm sau startForegroundService (vài giây), kể cả khi sắp tự dừng
        if (!enterForeground(buildNotification(hub, hub.state.value))) { stopSelf(); return START_NOT_STICKY }
        if (observer == null) {
            // hỏi trạng thái định kỳ (không dùng Flow.collect: vừa nhẹ, vừa tự giãn nhịp cập nhật thông báo); dịch vụ chỉ sống khi đang tải
            observer = scope.launch { while (onState(hub, hub.state.value)) delay(POLL_MS) }
            watchdog = scope.launch { delay(WATCHDOG_MS); leave() }
        }
        hub.resumeIfWanted()
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun enterForeground(n: Notification): Boolean = try {
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(NOTIF_ID, n)
        true
    } catch (e: RuntimeException) {
        // không được phép chạy nền trước (ví dụ app đang ở nền, thiếu quyền loại dịch vụ): hub vẫn tải trong tiến trình
        false
    }

    /** Cập nhật thông báo theo trạng thái hub; trả về false khi hàng đợi đã rỗng (dịch vụ tự dừng) để vòng hỏi kết thúc. */
    private fun onState(hub: ModelHub, s: ModelHub.State): Boolean {
        if (s.queue.isEmpty() && s.activeId == null) { leave(); return false }
        val pct = (s.progress * 100).toInt().coerceIn(0, 100)
        val kind = "${s.activeId}|${s.queue.size}|${s.waiting}"
        val now = System.currentTimeMillis()
        // cùng trạng thái: chỉ cập nhật khi % đổi VÀ đã qua 1 giây (tránh làm hệ thống chậm vì thông báo dồn dập)
        if (kind == lastKind && (pct == lastPct || now - lastAt < 1000)) return true
        lastKind = kind
        lastPct = pct
        lastAt = now
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.notify(NOTIF_ID, buildNotification(hub, s))
        }
        return true
    }

    private fun leave() {
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        stopSelf()
    }

    private fun buildNotification(hub: ModelHub, s: ModelHub.State): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        if (nm != null) ensureChannel(this, nm)
        val id = s.activeId ?: s.queue.firstOrNull()
        val name = id?.let { hub.entry(it)?.name }.orEmpty()
        val pct = (s.progress * 100).toInt().coerceIn(0, 100)
        val text = when {
            s.activeId != null -> I18n.tr("Đang tải $name… $pct%")
            s.waiting == NetworkPolicy.Wait.WIFI -> I18n.tr("Đang chờ Wi-Fi để tải $name")
            s.waiting == NetworkPolicy.Wait.NETWORK -> I18n.tr("Đang chờ mạng để tải $name")
            else -> I18n.tr("Đang chuẩn bị tải model…")
        }
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = packageManager.getLaunchIntentForPackage(packageName)
            ?.let { PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        return Notification.Builder(this, ModelServices.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(I18n.tr("Tải model AI"))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, s.activeId == null)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, I18n.tr("Hủy"), cancel)
            .apply { if (open != null) setContentIntent(open) }
            .build()
    }

    companion object {
        const val ACTION_CANCEL = "com.aiphoto.studio.action.CANCEL_MODEL_DOWNLOAD"
        private const val NOTIF_ID = 4401
        private const val POLL_MS = 700L
        /** 5,5 giờ: dưới giới hạn 6 giờ của dataSync (Android 15). */
        const val WATCHDOG_MS = 5L * 3600_000L + 30L * 60_000L

        /** Yêu cầu hệ điều hành chạy dịch vụ nền (gọi khi người dùng bấm Tải — app đang ở màn hình nên được phép). */
        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, DownloadService::class.java))
            } catch (e: RuntimeException) {
                // không được phép khởi động dịch vụ nền: hub vẫn tải trong tiến trình khi app còn sống
            }
        }

        fun ensureChannel(ctx: Context, nm: NotificationManager) {
            val ch = NotificationChannel(ModelServices.CHANNEL_ID, I18n.tr("Tải model AI"), NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }
}
