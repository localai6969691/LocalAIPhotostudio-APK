package com.aiphoto.studio.engine

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Phác thảo → ảnh ("Sketch to image" / Creative Studio): người dùng vẽ NÉT MÀU lên chỗ muốn có vật thể rồi mô tả bằng lời;
 * dịch vụ sinh ảnh nhìn thấy nét phác (hình dạng + vị trí + màu gần đúng) và vẽ vật thật thay vào. Phần này KHÔNG gọi model,
 * chỉ làm các bước thuần số học để kiểm thử được trên JVM:
 *  1. [rasterize]: nét (điểm chuẩn hóa 0..1) + màu → lớp ARGB phủ độ trong suốt theo khoảng cách tới đoạn thẳng (mép khử răng cưa),
 *     bán kính = `brush × cạnh dài` (cùng quy ước với [MaskBuilder]); nét sau đè nét trước; MỖI nét hợp thành một lần (khớp nối không đậm hơn).
 *  2. [overlay]: ảnh dẫn = ảnh nền + nét phác (src-over) — đây là ảnh gửi cho dịch vụ.
 *  3. [mask]: vùng được phép đổi = mọi điểm có nét (kể cả rìa mờ, alpha > 0) nới thêm [growFor] điểm ảnh để vật thật to hơn nét phác một chút
 *     và quầng màu của rìa mờ nằm gọn trong vùng (ngoài mặt nạ ảnh giữ NGUYÊN điểm ảnh gốc).
 *  4. [instruction]: câu lệnh tiếng Anh nói rõ nét phác chỉ là gợi ý hình/màu, vật phải thật và không còn nét vẽ.
 * Giới hạn: kết quả hoàn toàn do dịch vụ sinh ảnh quyết định; nét phác quá mơ hồ (vài nét nguệch ngoạc không rõ hình) cho vật không như ý;
 * màu nét chỉ là gợi ý nên dịch vụ có thể đổi màu.
 */
object Sketch {

    /** Bảng màu cho giao diện: (tên hiển thị tiếng Việt, ARGB). */
    val PALETTE: List<Pair<String, Int>> = listOf(
        "Đỏ" to 0xFFE53935.toInt(),
        "Cam" to 0xFFFB8C00.toInt(),
        "Vàng" to 0xFFFDD835.toInt(),
        "Xanh lá" to 0xFF43A047.toInt(),
        "Xanh dương" to 0xFF1E88E5.toInt(),
        "Tím" to 0xFF8E24AA.toInt(),
        "Nâu" to 0xFF6D4C41.toInt(),
        "Trắng" to 0xFFFFFFFF.toInt(),
        "Đen" to 0xFF212121.toInt()
    )
    val DEFAULT_COLOR: Int = PALETTE[0].second

    const val MAX_POINTS_PER_STROKE = 20000
    const val MAX_STROKES = 200

    private fun fin(v: Float) = v.isFinite()

    /** Bán kính nét (điểm ảnh) theo quy ước của [MaskBuilder]: `brush × cạnh dài`, tối thiểu 1. */
    fun radiusPx(brush: Float, w: Int, h: Int): Float = max(1f, (if (fin(brush)) brush else 0.03f) * max(w, h))

    /** Nới vùng cho phép đổi: ≈ 0,6% cạnh dài, tối thiểu 3 điểm ảnh. */
    fun growFor(w: Int, h: Int): Int = max(3, (max(w, h) * 0.006f).toInt())

    /**
     * Vẽ các nét lên lớp ARGB trống cỡ w×h. [colors] ứng với từng nét theo thứ tự (thiếu thì dùng [DEFAULT_COLOR]; alpha của màu bị bỏ).
     * Điểm không hữu hạn bị bỏ; nét thừa so với [MAX_STROKES] hoặc [MAX_POINTS_PER_STROKE] bị cắt. Không có nét hợp lệ ⇒ lớp toàn 0.
     */
    fun rasterize(strokes: List<List<Pt>>, colors: List<Int>, brush: Float, w: Int, h: Int): IntArray {
        val out = IntArray(max(0, w) * max(0, h))
        if (w <= 0 || h <= 0) return out
        val r = radiusPx(brush, w, h)
        for ((si, raw) in strokes.take(MAX_STROKES).withIndex()) {
            val pts = raw.take(MAX_POINTS_PER_STROKE).filter { fin(it.x) && fin(it.y) }
            if (pts.isEmpty()) continue
            val rgb = (colors.getOrNull(si) ?: DEFAULT_COLOR) and 0xFFFFFF
            val px = FloatArray(pts.size) { pts[it].x.coerceIn(-0.5f, 1.5f) * w }
            val py = FloatArray(pts.size) { pts[it].y.coerceIn(-0.5f, 1.5f) * h }
            var minX = px[0]; var maxX = px[0]; var minY = py[0]; var maxY = py[0]
            for (i in px.indices) { minX = min(minX, px[i]); maxX = max(maxX, px[i]); minY = min(minY, py[i]); maxY = max(maxY, py[i]) }
            val x0 = max(0, floor(minX - r - 1f).toInt()); val x1 = min(w - 1, floor(maxX + r + 1f).toInt())
            val y0 = max(0, floor(minY - r - 1f).toInt()); val y1 = min(h - 1, floor(maxY + r + 1f).toInt())
            if (x1 < x0 || y1 < y0) continue
            val bw = x1 - x0 + 1
            val cov = ByteArray(bw * (y1 - y0 + 1))
            if (pts.size == 1) segment(cov, bw, x0, y0, x1, y1, px[0], py[0], px[0], py[0], r)
            else for (i in 0 until pts.size - 1) {
                // hộp của riêng đoạn này để không quét cả hộp của nét dài
                val sx0 = max(x0, floor(min(px[i], px[i + 1]) - r - 1f).toInt()); val sx1 = min(x1, floor(max(px[i], px[i + 1]) + r + 1f).toInt())
                val sy0 = max(y0, floor(min(py[i], py[i + 1]) - r - 1f).toInt()); val sy1 = min(y1, floor(max(py[i], py[i + 1]) + r + 1f).toInt())
                if (sx1 < sx0 || sy1 < sy0) continue
                segment(cov, bw, x0, y0, sx1, sy1, px[i], py[i], px[i + 1], py[i + 1], r, sx0, sy0)
            }
            // hợp nét vào lớp: src-over, màu không nhân alpha
            for (y in y0..y1) {
                val crow = (y - y0) * bw
                for (x in x0..x1) {
                    val c = cov[crow + x - x0].toInt() and 255
                    if (c == 0) continue
                    val i = y * w + x
                    val dst = out[i]
                    val da = (dst ushr 24) / 255f
                    val sa = c / 255f
                    val oa = sa + da * (1f - sa)
                    if (oa <= 0f) continue
                    fun ch(sh: Int): Int {
                        val s = (rgb shr sh) and 255
                        val d = (dst shr sh) and 255
                        return ((s * sa + d * da * (1f - sa)) / oa + 0.5f).toInt().coerceIn(0, 255)
                    }
                    out[i] = ((oa * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
                }
            }
        }
        return out
    }

    /** Ghi độ phủ của đoạn a→b (bán kính r) vào [cov] (hộp gốc [bx0],[by0], rộng [bw]); vùng quét = cột sx0 đến x1, hàng sy0 đến y1. */
    private fun segment(
        cov: ByteArray, bw: Int, bx0: Int, by0: Int, x1: Int, y1: Int,
        ax: Float, ay: Float, bx: Float, by: Float, r: Float, sx0: Int = bx0, sy0: Int = by0
    ) {
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        for (y in sy0..y1) {
            val cy = y + 0.5f
            for (x in sx0..x1) {
                val cx = x + 0.5f
                val t = if (len2 < 1e-9f) 0f else (((cx - ax) * dx + (cy - ay) * dy) / len2).coerceIn(0f, 1f)
                val qx = ax + t * dx - cx
                val qy = ay + t * dy - cy
                val d = sqrt(qx * qx + qy * qy)
                val c = (r + 0.5f - d).coerceIn(0f, 1f)
                if (c <= 0f) continue
                val idx = (y - by0) * bw + (x - bx0)
                val v = (c * 255f + 0.5f).toInt()
                if (v > (cov[idx].toInt() and 255)) cov[idx] = v.toByte()
            }
        }
    }

    /** Ảnh dẫn = [base] với [sketch] phủ lên (src-over). Kích thước khác nhau ⇒ trả lại [base] nguyên trạng. Alpha kết quả = hợp của hai lớp. */
    fun overlay(base: IntArray, sketch: IntArray, copy: Boolean = true): IntArray {
        if (base.size != sketch.size) return base
        val out = if (copy) base.copyOf() else base          // copy = false: ghi thẳng vào [base] (tiết kiệm một bản ảnh đầy đủ khi ảnh lớn)
        for (i in out.indices) {
            val s = sketch[i]
            val sa = s ushr 24
            if (sa == 0) continue
            val b = base[i]
            val ba = (b ushr 24) / 255f
            val a = sa / 255f
            val oa = a + ba * (1f - a)
            if (oa <= 0f) continue
            fun ch(sh: Int): Int = ((((s shr sh) and 255) * a + ((b shr sh) and 255) * ba * (1f - a)) / oa + 0.5f).toInt().coerceIn(0, 255)
            out[i] = ((oa * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        return out
    }

    /** Vùng được đổi (255) = điểm có nét (alpha > 0) nới [grow] điểm ảnh; không có nét nào ⇒ null. */
    fun mask(sketch: IntArray, w: Int, h: Int, grow: Int): ByteArray? {
        if (w <= 0 || h <= 0 || sketch.size != w * h) return null
        val m = ByteArray(sketch.size)
        var any = false
        for (i in sketch.indices) if ((sketch[i] ushr 24) != 0) { m[i] = 255.toByte(); any = true }
        if (!any) return null
        return MoveObject.dilate(m, w, h, grow)
    }

    /** Tên màu gần nhất bằng tiếng Anh (dùng trong câu lệnh gửi dịch vụ sinh ảnh). */
    fun colorName(argb: Int): String {
        val r = ((argb shr 16) and 255) / 255f
        val g = ((argb shr 8) and 255) / 255f
        val b = (argb and 255) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val v = mx
        val d = mx - mn
        val s = if (mx <= 0f) 0f else d / mx
        if (v < 0.22f) return "black"
        if (s < 0.14f) return if (v > 0.85f) "white" else "gray"
        var hue = when {
            d <= 0f -> 0f
            mx == r -> 60f * (((g - b) / d) % 6f)
            mx == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        if (hue < 0f) hue += 360f
        if (hue >= 360f) hue -= 360f
        if (v < 0.55f && hue in 10f..50f) return "brown"
        return when {
            hue < 15f || hue >= 340f -> if (s < 0.5f && v > 0.8f) "pink" else "red"
            hue < 40f -> "orange"
            hue < 70f -> "yellow"
            hue < 160f -> "green"
            hue < 200f -> "cyan"
            hue < 255f -> "blue"
            hue < 290f -> "purple"
            else -> "pink"
        }
    }

    /** Các tên màu (không trùng, theo thứ tự xuất hiện) của những nét thực sự được vẽ. */
    fun usedColorNames(strokes: List<List<Pt>>, colors: List<Int>): List<String> {
        val out = LinkedHashSet<String>()
        for ((i, s) in strokes.withIndex()) if (s.any { fin(it.x) && fin(it.y) }) out.add(colorName(colors.getOrNull(i) ?: DEFAULT_COLOR))
        return out.toList()
    }

    /**
     * Câu lệnh cho dịch vụ sinh ảnh (nằm sau cụm "Task for the white area:" của [GeminiImageBackend]). [description] = lời mô tả của người dùng
     * (đã gỡ khoảng trắng thừa; rỗng ⇒ để dịch vụ tự suy từ nét phác).
     */
    fun instruction(description: String, colorNames: List<String>): String {
        val what = description.trim().trimEnd('.', '!', ' ')
        val cols = if (colorNames.isEmpty()) "colored" else colorNames.joinToString("/")
        val subject = if (what.isEmpty()) "the real object the sketch depicts" else what
        return "the white area contains hand-drawn $cols sketch strokes that mark the rough shape, position and colors of what to add; " +
            "replace the sketch with $subject, drawn photorealistically in the shape and place of the strokes. " +
            "The final image must NOT show any of the sketch lines or flat marker color"
    }

    /** Câu mô tả cho SD cục bộ / LAN (không hiểu lệnh, chỉ hiểu mô tả ảnh). */
    fun sdPrompt(description: String): String {
        val what = description.trim().trimEnd('.', '!', ' ')
        return if (what.isEmpty()) "a realistic object, highly detailed, photorealistic" else "$what, highly detailed, photorealistic"
    }

    /**
     * Làm danh sách màu khớp đúng [strokeCount] nét: thừa thì cắt từ cuối, thiếu thì thêm [fallback] ở cuối. Dùng vì danh sách nét có thể bị
     * xóa ở nhiều chỗ khác nhau (xóa nét, đổi chế độ, áp dụng kết quả) mà không ai nhớ xóa danh sách màu theo.
     */
    fun alignColors(colors: List<Int>, strokeCount: Int, fallback: Int): List<Int> {
        val n = max(0, strokeCount)
        return if (colors.size >= n) colors.take(n) else colors + List(n - colors.size) { fallback }
    }

    /** Có nét hợp lệ nào không (để giao diện bật nút "Vẽ thành ảnh"). */
    fun hasStrokes(strokes: List<List<Pt>>): Boolean = strokes.any { s -> s.any { fin(it.x) && fin(it.y) } }
}
