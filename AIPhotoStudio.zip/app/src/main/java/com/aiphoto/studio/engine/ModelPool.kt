package com.aiphoto.studio.engine

/**
 * Hồ bộ nhớ cho các model nặng (kỹ thuật "ModelPool" trong PDF): chỉ giữ trong RAM số model vừa đủ theo hạng máy,
 * model dùng lâu nhất bị giải phóng khi nạp model mới. Sức chứa tính bằng "đơn vị trọng số" (LLM=2, LaMa/MI-GAN/SAM=1, sd-server=4).
 * Mỗi model tự khai báo hàm giải phóng; hồ không biết kiểu model cụ thể nên dùng cho cả ONNX, MediaPipe lẫn tiến trình con.
 */
class ModelPool(private val capacity: () -> Int) {

    private class Entry(val weight: Int, val unload: () -> Unit)

    private val entries = LinkedHashMap<String, Entry>(16, 0.75f, true) // thứ tự truy cập: đầu = ít dùng nhất

    /** Đăng ký / làm mới "vừa dùng". Trả về danh sách tên model đã bị giải phóng để nhường chỗ. */
    fun register(name: String, weight: Int, unload: () -> Unit): List<String> {
        val victims = ArrayList<Pair<String, Entry>>()
        synchronized(this) {
            entries[name] = Entry(weight, unload)
            var total = entries.values.sumOf { it.weight }
            val iter = entries.entries.iterator()
            while (total > capacity() && iter.hasNext()) {
                val e = iter.next()
                if (e.key == name) continue
                total -= e.value.weight
                victims.add(Pair(e.key, e.value))
                iter.remove()
            }
        }
        // giải phóng ngoài khóa của hồ để tránh khóa chéo với khóa của từng model
        for (v in victims) {
            try { v.second.unload() } catch (e: Throwable) { }
        }
        return victims.map { it.first }
    }

    @Synchronized
    fun forget(name: String) {
        entries.remove(name)
    }

    @Synchronized
    fun clear() {
        entries.clear()
    }

    @Synchronized
    fun loaded(): List<String> = entries.keys.toList()
}
