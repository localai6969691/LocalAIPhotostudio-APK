package com.aiphoto.studio.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/**
 * Phần của kênh báo lỗi (R24) phải hỏi hệ thống Android: phiên bản app, thông số máy, lịch sử bị hệ thống kết thúc.
 * Chỉ ĐỌC và chỉ báo cáo - không dùng để quyết định tính năng nào bật/tắt theo hãng máy (xem nguyên tắc không hard-code thiết bị).
 */
object DiagAndroid {
    fun appVersion(ctx: Context): String = runCatching {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        @Suppress("DEPRECATION")
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        "${info.versionName} (mã $code)"
    }.getOrDefault("không rõ")

    /** Hãng/kiểu máy, Android, kiến trúc, RAM, heap: chỉ để người nhận báo cáo biết máy thuộc loại nào. */
    fun deviceFields(ctx: Context): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        out += "máy" to "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        out += "Android" to "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
        out += "chip" to (if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE).orEmpty().ifBlank { "không rõ" }
        out += "kiến trúc" to Build.SUPPORTED_ABIS.joinToString(",")
        runCatching {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            out += "RAM" to "tổng ${mi.totalMem / MB} MB, còn trống ${mi.availMem / MB} MB, ngưỡng thấp ${mi.threshold / MB} MB, đang thiếu bộ nhớ: ${if (mi.lowMemory) "có" else "không"}"
            out += "heap Java" to "lớp ${am.memoryClass} MB / lớn ${am.largeMemoryClass} MB, tối đa của tiến trình ${Runtime.getRuntime().maxMemory() / MB} MB, đang dùng ${(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / MB} MB"
            out += "máy RAM thấp (cờ hệ thống)" to (if (am.isLowRamDevice) "có" else "không")
        }
        out += "số nhân CPU" to Runtime.getRuntime().availableProcessors().toString()
        return out
    }

    /** Lịch sử tiến trình app bị kết thúc (Android 11+; máy cũ hơn trả về rỗng). Mới nhất trước. */
    fun exitRecords(ctx: Context, max: Int = 6): List<ExitRecord> {
        if (Build.VERSION.SDK_INT < 30) return emptyList()
        return runCatching {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.getHistoricalProcessExitReasons(null, 0, max).map {
                ExitRecord(it.reason, it.importance, it.timestamp, it.pss, it.rss, it.description.orEmpty(), it.status)
            }
        }.getOrDefault(emptyList())
    }

    private const val MB = 1024L * 1024L
}
