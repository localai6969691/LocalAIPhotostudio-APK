package com.aiphoto.studio.doc

import org.json.JSONObject
import java.io.File

/**
 * R19 — NHIỀU phiên làm việc: mỗi ảnh mở ra có một "ngăn" riêng filesDir/projects/<id>/ (meta.json + tệp nhị phân như [ProjectStore]),
 * thay vì chỉ một phiên gần nhất bị ghi đè khi mở ảnh khác. Giữ tối đa [MAX_SLOTS] phiên mới nhất; ngăn đang làm việc không bao giờ bị dọn.
 * Thuần java.io + org.json nên kiểm thử được trên JVM (không cần Android).
 */
object ProjectSlots {
    const val DEFAULT = "default"
    const val MAX_SLOTS = 5
    private const val LEGACY_DIR = "project"      // bản cũ: một phiên duy nhất ở filesDir/project
    private val ID_RE = Regex("^[A-Za-z0-9_-]{1,48}$")

    class Item(val id: String, val info: ProjectInfo)

    /** Tên ngăn đi vào đường dẫn tệp nên chỉ nhận ký tự an toàn (chặn "../", dấu "/"). */
    fun validId(id: String): Boolean = ID_RE.matches(id)

    fun root(filesDir: File): File = File(filesDir, "projects")

    /** Chuyển phiên duy nhất của bản cũ (filesDir/project) thành ngăn [DEFAULT]; không đè nếu ngăn đã có. */
    fun migrateLegacy(filesDir: File) {
        val old = File(filesDir, LEGACY_DIR)
        val target = File(root(filesDir), DEFAULT)
        if (!old.isDirectory || target.exists()) return
        root(filesDir).mkdirs()
        if (!old.renameTo(target)) {   // khác phân vùng / lỗi đổi tên: sao chép rồi xóa
            runCatching { old.copyRecursively(target, overwrite = false); old.deleteRecursively() }
        }
    }

    /** Mã ngăn mới, không trùng [existing]. */
    fun newId(now: Long, existing: Set<String>): String {
        val base = "p" + java.lang.Long.toString(now, 36)
        if (base !in existing) return base
        var n = 2
        while ("$base-$n" in existing) n++
        return "$base-$n"
    }

    /** Thông tin phiên trong thư mục [dir]; null nếu meta hỏng hoặc thiếu ảnh nền. */
    fun infoOf(dir: File): ProjectInfo? = runCatching {
        val json = JSONObject(File(dir, "meta.json").readText())
        val m = ProjectCodec.meta(json) ?: return@runCatching null
        if (!File(dir, m.bgFile).isFile) return@runCatching null
        ProjectInfo(m.savedAt, ProjectCodec.layerCount(json), m.w, m.h)
    }.getOrNull()

    fun ids(filesDir: File): Set<String> = root(filesDir).listFiles()?.filter { it.isDirectory }?.map { it.name }?.toSet() ?: emptySet()

    /** Các phiên đọc được, mới nhất trước. */
    fun list(filesDir: File): List<Item> =
        (root(filesDir).listFiles() ?: emptyArray())
            .filter { it.isDirectory && validId(it.name) }
            .mapNotNull { d -> infoOf(d)?.let { Item(d.name, it) } }
            .sortedByDescending { it.info.savedAt }

    fun delete(filesDir: File, id: String) {
        if (!validId(id)) return
        File(root(filesDir), id).deleteRecursively()
    }

    /**
     * Dọn bớt: giữ [keep] phiên mới nhất (tính cả [protect] nếu nó đã có trên đĩa) và xóa phần còn lại, kể cả ngăn hỏng.
     * [protect] (ngăn đang làm việc) không bao giờ bị xóa.
     */
    fun evict(filesDir: File, keep: Int = MAX_SLOTS, protect: String? = null): List<String> {
        val removed = ArrayList<String>()
        val dirs = (root(filesDir).listFiles() ?: emptyArray()).filter { it.isDirectory }
        val valid = list(filesDir)
        val validIds = valid.map { it.id }.toSet()
        // ngăn hỏng / tên lạ (không phải của ta): xóa, trừ ngăn đang làm việc
        for (d in dirs) if ((d.name !in validIds) && d.name != protect) { d.deleteRecursively(); removed.add(d.name) }
        val keepIds = HashSet<String>()
        if (protect != null && protect in validIds) keepIds.add(protect)
        for (item in valid) {
            if (keepIds.size >= keep) break
            keepIds.add(item.id)
        }
        for (item in valid) if (item.id !in keepIds) { File(root(filesDir), item.id).deleteRecursively(); removed.add(item.id) }
        return removed
    }
}
