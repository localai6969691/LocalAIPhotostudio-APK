package com.aiphoto.studio.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object ImageIO {

    /** Đọc ảnh, tự xoay theo EXIF, thu nhỏ để cạnh dài <= maxSide (tránh tràn RAM). */
    fun decode(context: Context, uri: Uri, maxSide: Int): Bitmap {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Không đọc được ảnh" }

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("Không giải mã được ảnh")

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        return scaleToMax(bmp, maxSide)
    }

    fun scaleToMax(b: Bitmap, maxSide: Int): Bitmap {
        val long = max(b.width, b.height)
        if (long <= maxSide) return b
        val f = maxSide.toFloat() / long
        return Bitmap.createScaledBitmap(
            b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true
        )
    }

    /** Ảnh có điểm ảnh trong suốt thật sự không (để chọn PNG thay vì JPEG khi lưu). */
    fun hasTransparency(b: Bitmap): Boolean {
        if (!b.hasAlpha()) return false
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        for (p in px) if ((p ushr 24) < 250) return true
        return false
    }

    /** Lưu vào thư viện ảnh (Pictures/AIPhotoStudio). Trả về đường dẫn để hiển thị cho người dùng. */
    fun saveToGallery(context: Context, bmp: Bitmap, png: Boolean): String = saveToGalleryUri(context, bmp, png).first

    /**
     * Như [saveToGallery] nhưng trả thêm Uri (chỉ có trên Android 10+ vì dùng MediaStore) để chia sẻ ngay mà không cần FileProvider.
     * Android 8-9: Uri = null (ảnh nằm ở thư mục riêng của app, không chia sẻ trực tiếp được).
     */
    fun saveToGalleryUri(context: Context, bmp: Bitmap, png: Boolean): Pair<String, Uri?> {
        val name = "AIPhoto_${System.currentTimeMillis()}" + if (png) ".png" else ".jpg"
        val mime = if (png) "image/png" else "image/jpeg"
        val format = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AIPhotoStudio")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Không tạo được tệp ảnh")
            resolver.openOutputStream(uri)?.use { bmp.compress(format, 95, it) }
                ?: throw IllegalStateException("Không ghi được tệp ảnh")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return Pair("Pictures/AIPhotoStudio/$name", uri)
        }

        // Android 8-9: ghi vào thư mục riêng của app (không cần xin quyền).
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AIPhotoStudio")
        dir.mkdirs()
        val file = File(dir, name)
        FileOutputStream(file).use { bmp.compress(format, 95, it) }
        return Pair(file.absolutePath, null)
    }

    /** Sao chép file (model) từ Uri của trình chọn tệp vào bộ nhớ trong của app. */
    fun copyUriToFile(context: Context, uri: Uri, dest: File) {
        dest.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output, 1 shl 16) }
        } ?: throw IllegalStateException("Không đọc được tệp đã chọn")
    }
}
