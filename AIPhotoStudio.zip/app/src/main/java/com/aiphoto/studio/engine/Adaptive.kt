package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Bộ điều khiển THÍCH NGHI cho kích thước đầu vào của model nặng — thay cho bảng ngưỡng RAM viết cứng ("RAM ≥ 4000 MB ⇒ 518, ngược lại 392").
 * Vì sao không thể phân tầng theo RAM: bảng công bố của Qualcomm AI Hub cho Depth-Anything-V2 (Small, 518x518) ghi 36–60 ms trên NPU Snapdragon 8 Gen 3 / 8 Elite / 8 Elite Gen 5
 * (ONNX 41,6–59,9 ms, bộ nhớ đỉnh tới 511 MB) nhưng lần nạp đầu 6,5–11,2 s (biên dịch đồ thị) trong khi lần chạy sau chỉ vài chục ms; còn trên CPU điện thoại, ước tính từ FLOPs
 * (~46 GMAC ở 518) cỡ vài giây (CHƯA có số công bố). Tốc độ phụ thuộc đường chạy thực tế chứ không phải dung lượng RAM, nên phải ĐO lúc chạy: sau mỗi lần suy luận, so thời gian
 * thật với ngân sách rồi chỉnh cạnh cho lần sau (nhớ lại giữa các lần mở app).
 *
 * Mọi hằng số đều suy ra, không đoán theo máy:
 *  - [SHRINK_EXPONENT] = 2,0 và [GROW_EXPONENT] = 2,75: chi phí ViT-S/14 theo cạnh e là F(e) = 12·(12·n·d² + 2·n²·d) với n = (e/14)², d = 384; mũ cục bộ ở e = 518 bằng 2,745
 *    (phần chú ý 2n²d chiếm 37 %), cận dưới là 2,0 (phần tuyến tính theo số điểm ảnh và đầu DPT). Thu nhỏ dùng cận DƯỚI (thu đủ mạnh), phóng to dùng cận TRÊN (không vượt ngân sách);
 *    sai lệch còn lại do vòng phản hồi sửa ở lần sau. Kiểm bằng `tools/verify_ports/adaptive.py`.
 *  - [COLD_TOLERANCE] = 6: lần chạy ĐẦU của một phiên có thể gồm biên dịch / cấp phát (Qualcomm AI Hub: first app load 6,47 s và 11,2 s ở hai lần đo = tới 3,7× ngân sách 3 s) nên không học từ nó
 *    trừ khi chậm hơn 6× ngân sách (18 s, còn dư so với 11,2 s).
 *  - [DEFAULT_BUDGET_MS] là quyết định trải nghiệm (một bước đo độ sâu không để người dùng chờ quá ~3 s), cấu hình được qua `params.budget_ms` của định tuyến — KHÔNG phụ thuộc máy.
 */
object Adaptive {
    const val DEFAULT_BUDGET_MS = 3000L
    const val MIN_PATCHES = 8
    const val SHRINK_EXPONENT = 2.0f
    const val GROW_EXPONENT = 2.75f
    const val SHRINK_SAFETY = 0.9f
    const val GROW_BELOW = 0.5f
    const val GROW_TARGET = 0.8f
    const val MAX_GROW = 1.25f
    const val FAIL_SHRINK = 0.75f
    const val COLD_TOLERANCE = 6f

    /** Làm tròn [v] về bội gần nhất của [patch] rồi kẹp vào [lo, hi]. */
    fun snap(v: Float, patch: Int, lo: Int, hi: Int): Int = ((v / patch).roundToInt() * patch).coerceIn(lo, hi)

    /**
     * Cạnh cho LẦN SAU, dựa trên lần vừa chạy ở cạnh [edge] mất [elapsedMs]. [cold] = đây là lần chạy đầu của phiên model (không học từ nó trừ khi quá chậm).
     * Vùng [GROW_BELOW·ngân sách, ngân sách] giữ nguyên (trễ, chống dao động); dưới nửa ngân sách thì thử lớn dần (tối đa ×[MAX_GROW] mỗi lần); trên ngân sách thì thu nhỏ.
     */
    fun nextEdge(edge: Int, elapsedMs: Long, budgetMs: Long, minEdge: Int, maxEdge: Int, patch: Int, cold: Boolean): Int {
        val e = edge.coerceIn(minEdge, maxEdge)
        if (elapsedMs <= 0L || budgetMs <= 0L) return e
        if (cold && elapsedMs <= budgetMs * COLD_TOLERANCE) return e
        val ratio = budgetMs.toFloat() / elapsedMs
        return when {
            elapsedMs > budgetMs -> snap(e * ratio.pow(1f / SHRINK_EXPONENT) * SHRINK_SAFETY, patch, minEdge, e)
            elapsedMs < budgetMs * GROW_BELOW && e < maxEdge ->
                snap(min(e * MAX_GROW, e * (ratio * GROW_TARGET).pow(1f / GROW_EXPONENT)), patch, e, maxEdge)
            else -> e
        }
    }

    /** Cạnh sau một lần LỖI (hết bộ nhớ…): thu [FAIL_SHRINK]× và luôn nhỏ hơn thật sự trừ khi đã ở mức tối thiểu. */
    fun afterFailure(edge: Int, minEdge: Int, patch: Int): Int {
        if (edge <= minEdge) return minEdge
        val s = snap(edge * FAIL_SHRINK, patch, minEdge, edge)
        return if (s >= edge) max(minEdge, edge - patch) else s
    }
}
