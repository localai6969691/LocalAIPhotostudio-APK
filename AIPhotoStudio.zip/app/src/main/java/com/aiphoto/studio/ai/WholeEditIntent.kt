package com.aiphoto.studio.ai

/**
 * Nhận biết các yêu cầu cần AI sinh ảnh nhưng tác động LÊN CẢ ẢNH (không cần tô vùng): xóa phản chiếu / chói kính, xóa bóng đổ,
 * đổi phong cách nghệ thuật (anime, Ghibli, tranh Van Gogh…). Khác [GenIntent] (thêm/thay/xóa VẬT THỂ trong vùng tô).
 *
 * Quy tắc phân loại (đặt TRƯỚC [GenIntent] trong MainViewModel.run vì "xóa phản chiếu" chứa từ "xóa" nên [GenIntent] sẽ đòi tô vùng):
 *  - Phản chiếu / bóng đổ: cần từ khóa đối tượng + động từ loại bỏ ("xóa", "bỏ", "khử", "remove"…); "tạo bóng", "thêm phản chiếu" KHÔNG tính.
 *    "nâng vùng bóng / lift shadows" là chỉnh tông (RuleBasedPlanner), không phải xóa bóng đổ.
 *  - Phong cách: tên phong cách AI-only (anime, ghibli…) kèm từ chuyển đổi; hoặc "phong cách <X>" / "in the style of <X>" với X lạ.
 *    Phong cách cổ điển chạy ngay trên máy (sơn dầu / hoạt hình / màu nước → OpType.STYLE; chì / phác họa → SKETCH; pixel → PIXELATE)
 *    KHÔNG đi đường AI trừ khi người dùng nói rõ "bằng AI" (sơn dầu / hoạt hình / màu nước) — vì đường cổ điển miễn phí và không gửi ảnh ra ngoài.
 */
object WholeEditIntent {

    enum class Kind { REFLECTION, SHADOW, RESTYLE }

    /** [instruction] = lệnh gửi cho dịch vụ sinh ảnh (tiếng Anh); [label] = tên ngắn hiển thị cho người dùng. */
    class Request(val kind: Kind, val instruction: String, val label: String, val styleName: String? = null)

    private val REMOVE_VERBS = listOf("xoa", "go bo", "go", "loai bo", "bo", "khu", "triet", "remove", "get rid", "eliminate", "erase", "delete", "fix", "clean", "giam", "han che")

    private val REFLECTION_KEYS = listOf("phan chieu", "phan quang", "reflection", "reflections", "glare", "chop kinh", "choi kinh", "kinh phan", "bong kinh")
    // "bong do" = bóng đổ; "xoa bong" = xóa bóng; KHÔNG dùng "bong" đơn lẻ (bóng mắt, bóng đèn, vùng bóng = shadows tonal)
    private val SHADOW_KEYS = listOf(
        "bong do", "bong cua", "xoa bong", "go bong", "khu bong", "bong gat", "cast shadow", "cast shadows", "hard shadow", "hard shadows",
        "shadow removal", "remove shadow", "remove shadows", "remove the shadow", "remove the shadows", "get rid of shadow", "get rid of the shadow",
        "get rid of shadows", "get rid of the shadows", "unwanted shadow", "unwanted shadows"
    )
    private val SHADOW_BLOCK = listOf("nang vung bong", "vung bong", "lift shadow", "brighten shadow", "lighten shadow", "shadows slider", "them bong", "tao bong", "add shadow", "drop shadow",
        "under eye", "under eyes", "quang tham", "dark circle", "dark circles", "bong mat", "tham mat")

    private val AI_STYLES: List<Pair<List<String>, String>> = listOf(
        listOf("anime", "hoat hinh nhat") to "anime (Japanese animation)",
        listOf("manga", "truyen tranh nhat") to "black-and-white manga ink illustration",
        listOf("ghibli", "studio ghibli") to "Studio Ghibli hand-painted animation",
        listOf("pixar", "disney", "hoat hinh 3d", "3d animation", "3d cartoon") to "3D animated movie (Pixar-like)",
        listOf("cyberpunk") to "cyberpunk neon",
        listOf("pop art", "popart") to "pop art",
        listOf("ukiyo", "ukiyo e", "tranh khac go") to "ukiyo-e Japanese woodblock print",
        listOf("van gogh", "vangogh") to "Van Gogh post-impressionist oil painting with swirling brushstrokes",
        listOf("monet", "tranh an tuong", "impressionism", "impressionist") to "Monet impressionist painting",
        listOf("picasso", "tranh lap the", "cubism", "cubist") to "cubist Picasso painting",
        listOf("chibi") to "chibi cartoon",
        listOf("low poly", "lowpoly") to "low-poly 3D",
        listOf("lego") to "LEGO bricks",
        listOf("claymation", "dat set") to "claymation clay animation",
        listOf("vaporwave", "synthwave") to "vaporwave retro-futuristic",
        listOf("comic", "truyen tranh", "american comic") to "comic book with bold ink lines and halftone dots",
        listOf("tranh son mai", "lacquer") to "Vietnamese lacquer painting"
    )
    // phong cách cổ điển (đi đường OpType.STYLE ngay trên máy, miễn phí)
    private val CLASSIC_STYLES = listOf("son dau", "oil painting", "oil paint", "hoat hinh", "cartoon", "mau nuoc", "watercolor", "watercolour", "water color")
    private val CONVERT = listOf("phong cach", "style", "thanh", "into", "kieu", "ve lai", "restyle", "convert", "turn", "make it", "make this", "bien", "chuyen", "doi")
    private val USE_AI = listOf("bang ai", "dung ai", "with ai", "using ai", "by ai", "ai ve")

    private fun has(t: String, key: String): Boolean = GenIntent.fold(key).let { k ->
        Regex("(?<![a-z0-9])" + Regex.escape(k) + "(?![a-z0-9])").containsMatchIn(t)
    }

    private fun anyHas(t: String, keys: List<String>) = keys.any { has(t, it) }

    private const val TAIL = " Do not add text, borders or frames."

    fun detect(prompt: String): Request? {
        val t = GenIntent.fold(prompt)
        if (t.isEmpty()) return null
        val remove = anyHas(t, REMOVE_VERBS)

        // --- phản chiếu / chói kính
        if (anyHas(t, REFLECTION_KEYS) && (remove || has(t, "kinh") || has(t, "glass") || has(t, "window"))) {
            if (!anyHas(t, listOf("them phan chieu", "tao phan chieu", "add reflection", "create reflection"))) {
                return Request(
                    Kind.REFLECTION,
                    "Remove all reflections and glare from glass, windows, screens, water or other shiny surfaces in this photo and reveal what is behind or beneath them. " +
                        "Keep everything else, the composition, colors, subjects and details, exactly unchanged.$TAIL",
                    "Xóa phản chiếu"
                )
            }
        }

        // --- bóng đổ
        if (anyHas(t, SHADOW_KEYS) && !anyHas(t, SHADOW_BLOCK) && (remove || has(t, "xoa bong") || has(t, "bong do") || has(t, "cast shadow"))) {
            return Request(
                Kind.SHADOW,
                "Remove the unwanted hard cast shadows (for example on faces, walls, objects or the ground) and even out the lighting so the area looks naturally lit. " +
                    "Keep textures, colors, subjects, identity and everything else unchanged.$TAIL",
                "Xóa bóng đổ"
            )
        }

        // --- phong cách nghệ thuật bằng AI
        val forceAi = anyHas(t, USE_AI)
        val classic = anyHas(t, CLASSIC_STYLES)
        val known = AI_STYLES.firstOrNull { (keys, _) -> keys.any { has(t, it) } }
        if (known != null && (anyHas(t, CONVERT) || t.startsWith(GenIntent.fold(known.first[0])))) {
            return restyle(known.second, known.first[0])
        }
        if (classic && forceAi) {
            val en = when {
                anyHas(t, listOf("son dau", "oil painting", "oil paint")) -> "oil painting with thick visible brushstrokes"
                anyHas(t, listOf("mau nuoc", "watercolor", "watercolour", "water color")) -> "soft watercolor painting on textured paper"
                else -> "hand-drawn cartoon with clean outlines and flat colors"
            }
            return restyle(en, en.substringBefore(' '))
        }
        // "phong cách X" / "in the style of X" với X chưa biết (chỉ khi KHÔNG phải kiểu cổ điển miễn phí)
        if (!classic) {
            val m = Regex("(?:phong cach|in the style of|style of|theo phong cach)\\s+([a-z0-9 ]{3,40})$").find(t)
            val x = m?.groupValues?.get(1)?.trim()
            if (!x.isNullOrEmpty() && x !in listOf("khac", "moi", "dep", "nay")) return restyle(x, x)
        }
        return null
    }

    private fun restyle(style: String, shortName: String): Request = Request(
        Kind.RESTYLE,
        "Redraw this photo in the style of $style. Keep the composition, the subjects, their poses, identity and the layout exactly the same; only change the rendering style.$TAIL",
        "Đổi phong cách: $shortName",
        style
    )
}
