package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Phân tích nhanh ảnh (trên bản thu nhỏ) để đưa ra GỢI Ý THÔNG MINH theo ngữ cảnh ảnh (kỹ thuật "Smart Suggestions" trong PDF). */
object ImageStats {

    data class Stats(
        val meanLum: Float,      // 0..1
        val contrast: Float,     // độ lệch chuẩn độ sáng 0..~0.5
        val saturation: Float,   // trung bình 0..1
        val skin: Float,         // tỉ lệ điểm ảnh màu da
        val sharp: Float,        // phương sai Laplacian (thang 0..255)
        val shadows: Float       // tỉ lệ điểm ảnh rất tối
    )

    fun compute(src: Bitmap): Stats {
        val long = max(src.width, src.height)
        val b = if (long > 256) {
            val f = 256f / long
            Bitmap.createScaledBitmap(src, max(8, (src.width * f).toInt()), max(8, (src.height * f).toInt()), true)
        } else src
        val w = b.width
        val h = b.height
        val px = readPixels(b)
        val lum = FloatArray(px.size)
        var sum = 0.0
        var sumSat = 0.0
        var skin = 0
        var dark = 0
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val bl = p and 255
            val l = 0.299f * r + 0.587f * g + 0.114f * bl
            lum[i] = l
            sum += l
            val mx = maxOf(r, g, bl)
            val mn = minOf(r, g, bl)
            sumSat += if (mx == 0) 0.0 else (mx - mn).toDouble() / mx
            if (l < 30f) dark++
            val cb = 128f - 0.168736f * r - 0.331264f * g + 0.5f * bl
            val cr = 128f + 0.5f * r - 0.418688f * g - 0.081312f * bl
            if (cb in 77f..127f && cr in 133f..173f && l > 40f) skin++
        }
        val n = px.size.toFloat()
        val mean = (sum / n).toFloat()
        var varSum = 0.0
        for (v in lum) varSum += (v - mean) * (v - mean)
        val std = sqrt(varSum / n).toFloat()

        // phương sai Laplacian 3x3 làm thước đo độ nét
        var lapSum = 0.0
        var lapSq = 0.0
        var cnt = 0
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val lap = 4f * lum[i] - lum[i - 1] - lum[i + 1] - lum[i - w] - lum[i + w]
                lapSum += lap
                lapSq += lap * lap
                cnt++
            }
        }
        val sharp = if (cnt == 0) 0f else (lapSq / cnt - (lapSum / cnt) * (lapSum / cnt)).toFloat()
        return Stats(mean / 255f, std / 255f, (sumSat / n).toFloat(), skin / n, abs(sharp), dark / n)
    }

    /** (nhãn hiển thị, câu lệnh gửi cho bộ hiểu prompt). */
    fun suggestions(s: Stats): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        if (s.meanLum < 0.30f) out.add(Pair("Ảnh thiếu sáng", "ảnh thiếu sáng"))
        if (s.meanLum > 0.75f) out.add(Pair("Giảm độ sáng", "tối hơn"))
        if (s.shadows > 0.25f && s.meanLum >= 0.30f) out.add(Pair("Nâng vùng tối", "làm sáng vùng tối"))
        if (s.contrast < 0.15f) out.add(Pair("Tăng tương phản", "tăng tương phản"))
        if (s.saturation < 0.20f) out.add(Pair("Màu tươi hơn", "tăng bão hòa"))
        if (s.skin > 0.10f) out.add(Pair("Làm đẹp chân dung", "chân dung"))
        if (s.sharp < 35f) out.add(Pair("Làm nét", "làm nét"))
        out.add(Pair("Tự động cải thiện", "tự động cải thiện"))
        out.add(Pair("Trông chuyên nghiệp hơn", "trông chuyên nghiệp hơn"))
        if (s.skin > 0.03f) {
            // có người trong ảnh: gợi ý các thao tác tạo sinh hay dùng (xóa người lạ nhỏ/xa, thay nền giữ nguyên chủ thể)
            out.add(Pair("Xóa người lạ", "xóa người lạ"))
            out.add(Pair("Thay nền: bãi biển", "thay nền thành bãi biển"))
        }
        out.add(Pair("Tông điện ảnh", "tông điện ảnh"))
        return out.take(8)
    }
}
