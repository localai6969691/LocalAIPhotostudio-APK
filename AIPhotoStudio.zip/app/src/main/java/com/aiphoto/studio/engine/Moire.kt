package com.aiphoto.studio.engine

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Khử moiré (sọc/vân khi chụp màn hình, vải mịn, lưới) KHÔNG cần model, bằng lọc khuyết trong miền tần số:
 *  1. Ảnh → độ chói Y và hai kênh màu Cb, Cr (moiré hay nằm ở kênh màu); mỗi kênh đi qua cửa sổ Tukey rồi FFT 2D (đệm số 0 tới lũy thừa 2).
 *  2. Moiré là các ĐỈNH NHỌN cô lập trong phổ (ảnh tự nhiên có phổ trơn): bin là đỉnh khi lớn hơn [Params.ratio] lần trung vị của hai vòng bin
 *     quanh nó (bán kính 10 và 15 bin, xa chân rò rỉ của chính đỉnh) VÀ lớn hơn [Params.ratioHi] lần bin lớn thứ hai trong 16 bin gần nó (cô lập theo mọi hướng, không phải "sống" phổ của cạnh thẳng), là cực đại cục bộ, và biên độ tương đương ≥ [Params.minAmp] mức xám (nhỏ hơn thì mắt không thấy).
 *  3. Phần "dư" của các bin đỉnh (vượt 1,3× mức nền) được tách thành thành phần moiré (FFT ngược) rồi TRỪ khỏi kênh; phần còn lại của phổ
 *     giữ nguyên nên chi tiết ảnh không bị làm mờ.
 *  4. Ảnh lớn: làm ở cạnh dài ≤ cap (mặc định [CAP]) rồi phóng phần trừ (song tuyến tính) cộng về ảnh gốc.
 * Giới hạn: hoa văn có thật (vải kẻ, gạch, rèm) cũng là đỉnh phổ nên bị giảm theo; vân có chu kỳ ngắn hơn ≈ 2·cạnh_dài/cap điểm ảnh
 * (vd. ảnh 2048 px, cap 1024 → chu kỳ < 4 px) không được khử vì đã bị trung bình mất khi thu nhỏ.
 */
object Moire {

    /** Cạnh dài mặc định khi phân tích (máy yếu); máy mạnh có thể truyền cap lớn hơn (≤ [MAX_CAP]) để bắt được vân mịn hơn trên ảnh lớn. */
    const val CAP = 1024
    const val MAX_CAP = 2048

    /** Cạnh dài phân tích dùng khi gọi không nêu cap: đặt theo hạng RAM của máy ([capFor]); không đặt thì dùng [CAP]. */
    @Volatile var capDefault: Int = CAP

    /** Máy yếu giữ [CAP] (FFT 1024² ≈ 60 MB tạm); máy khá dùng [MAX_CAP] (FFT 2048² ≈ 120 MB tạm / kênh) để bắt vân mịn trên ảnh lớn. */
    fun capFor(lowMemory: Boolean): Int = if (lowMemory) CAP else MAX_CAP
    private const val TAPER = 0.08f
    /** Bỏ qua các bin quá gần tâm (chu kỳ dài hơn ~ cạnh ảnh/12: dải rộng như vậy lẫn với nội dung ảnh): đó là nội dung ảnh, không phải vân. */
    private const val R_MIN = 12
    private const val MAX_PEAKS = 48
    /** Bán kính (bin) vùng quanh đỉnh bị lọc: đủ rộng để lấy cả "chân" rò rỉ của cửa sổ (≈1/r), phẳng ở trong và hạ mềm ở mép. */
    private const val NOTCH_R = 8
    private const val NOTCH_FLAT = 5
    /** Hai vòng bin lấy mức nền: xa hơn chân rò rỉ của đỉnh. */
    private val RING_R = intArrayOf(10, 15)
    private const val CLIP_K = 1.3f
    /** Bán kính các vòng "gần" (8 hướng) để kiểm tra đỉnh cô lập; xa hơn chân rò rỉ cửa sổ (~1/r) nhưng gần hơn [RING_R]. */
    private val NEAR_R = intArrayOf(4, 7)
    private val DIR_X = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
    private val DIR_Y = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)
    private const val WIN_FLOOR = 0.35f

    /**
     * [ratio] = đỉnh phải lớn hơn bấy nhiêu lần TRUNG VỊ hai vòng bin quanh nó; [ratioHi] = và lớn hơn bấy nhiêu lần bin lớn thứ hai trong 16 bin gần (8 hướng × bán kính 4, 7)
     * (chặn "sống" phổ do cạnh thẳng dài: dọc sống, các bin sát bên cùng hướng cũng cao nên không phải đỉnh cô lập, trong khi trung vị vòng xa thì thấp);
     * [minAmp] = biên độ tương đương tối thiểu (mức xám).
     */
    class Params(val ratio: Float, val ratioHi: Float, val minAmp: Float)
    val LUMA = Params(5f, 5f, 2f)
    val CHROMA = Params(4f, 4f, 2.5f)

    /** [removed] = thành phần moiré đã tách (w×h, cùng đơn vị với kênh vào); [peaks] = số đỉnh phổ đã xử lý. */
    class Result(val removed: FloatArray, val peaks: Int)

    private fun tukey(i: Int, n: Int): Float {
        val t = max(1, (n * TAPER).toInt())
        return when {
            i < t -> 0.5f * (1f - cos(Math.PI * (i + 0.5) / t).toFloat())
            i >= n - t -> 0.5f * (1f - cos(Math.PI * (n - i - 0.5) / t).toFloat())
            else -> 1f
        }
    }

    private class Peak(val idx: Int, val mag: Float, val ref: Float)

    /** Tách thành phần moiré khỏi một kênh [ch] (w×h). */
    fun suppress(ch: FloatArray, w: Int, h: Int, p: Params): Result {
        require(ch.size == w * h)
        val nx = Fft.nextPow2(max(w, 8))
        val ny = Fft.nextPow2(max(h, 8))
        val total = nx * ny
        var mean = 0.0
        for (v in ch) mean += v
        mean /= ch.size
        val wx = FloatArray(w) { tukey(it, w) }
        val wy = FloatArray(h) { tukey(it, h) }
        var sumWx = 0.0; for (v in wx) sumWx += v
        var sumWy = 0.0; for (v in wy) sumWy += v
        val sumWin = (sumWx * sumWy).toFloat()
        val re = FloatArray(total)
        val im = FloatArray(total)
        for (y in 0 until h) for (x in 0 until w) re[y * nx + x] = (ch[y * w + x] - mean.toFloat()) * wx[x] * wy[y]
        Fft.transform2d(re, im, nx, ny, false)
        val mag = FloatArray(total) { sqrt(re[it] * re[it] + im[it] * im[it]) }

        // tích phân ảnh của biên độ → trung bình hộp (2R+1)² để lọc nhanh các bin ứng viên
        val iw = nx + 1
        val integ = DoubleArray(iw * (ny + 1))
        for (y in 0 until ny) {
            var row = 0.0
            for (x in 0 until nx) {
                row += mag[y * nx + x]
                integ[(y + 1) * iw + x + 1] = integ[y * iw + x + 1] + row
            }
        }
        fun boxMean(x: Int, y: Int, r: Int): Float {
            val x0 = max(0, x - r); val x1 = min(nx - 1, x + r)
            val y0 = max(0, y - r); val y1 = min(ny - 1, y + r)
            val s = integ[(y1 + 1) * iw + x1 + 1] - integ[y0 * iw + x1 + 1] - integ[(y1 + 1) * iw + x0] + integ[y0 * iw + x0]
            return (s / ((x1 - x0 + 1).toDouble() * (y1 - y0 + 1))).toFloat()
        }
        val minMag = p.minAmp * sumWin / 2f
        val ringCos = FloatArray(12) { cos(2.0 * Math.PI * it / 12).toFloat() }
        val ringSin = FloatArray(12) { sin(2.0 * Math.PI * it / 12).toFloat() }
        val ringVals = FloatArray(24)
        val nearVals = FloatArray(NEAR_R.size * 8)
        val cand = ArrayList<Peak>()
        for (y in 0 until ny) {
            val fv = if (y <= ny / 2) y else y - ny
            for (x in 0 until nx) {
                val m = mag[y * nx + x]
                if (m < minMag) continue
                val fu = if (x <= nx / 2) x else x - nx
                if (fu * fu + fv * fv < R_MIN * R_MIN) continue
                if (m < 3.5f * boxMean(x, y, 6)) continue
                var isMax = true
                loop@ for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val xx = (x + dx + nx) % nx
                    val yy = (y + dy + ny) % ny
                    if (mag[yy * nx + xx] > m) { isMax = false; break@loop }
                }
                if (!isMax) continue
                var c = 0
                for (r in RING_R) for (a in 0 until 12) {
                    val xx = ((x + Math.round(r * ringCos[a]).toInt()) % nx + nx) % nx
                    val yy = ((y + Math.round(r * ringSin[a]).toInt()) % ny + ny) % ny
                    ringVals[c++] = mag[yy * nx + xx]
                }
                java.util.Arrays.sort(ringVals)
                val ref = (ringVals[11] + ringVals[12]) * 0.5f
                if (m < p.ratio * max(ref, 1e-6f)) continue
                // đỉnh thật là cô lập theo MỌI hướng; "sống" phổ của cạnh thẳng dài thì các bin cùng hướng sát bên vẫn cao
                var c2 = 0
                for (r in NEAR_R) for (a in 0 until 8) {
                    val xx = ((x + r * DIR_X[a]) % nx + nx) % nx
                    val yy = ((y + r * DIR_Y[a]) % ny + ny) % ny
                    nearVals[c2++] = mag[yy * nx + xx]
                }
                java.util.Arrays.sort(nearVals)
                if (m >= p.ratioHi * nearVals[nearVals.size - 2]) cand.add(Peak(y * nx + x, m, ref))
            }
        }
        if (cand.isEmpty()) return Result(FloatArray(w * h), 0)
        cand.sortByDescending { it.mag }
        val peaks = if (cand.size > MAX_PEAKS) cand.subList(0, MAX_PEAKS) else cand

        // phần dư của các bin đỉnh: D = F·(|F| − 1,3·ref)/|F|, nhân trọng số phẳng-rồi-hạ-cos theo khoảng cách tới đỉnh
        val dre = FloatArray(total)
        val dim = FloatArray(total)
        val done = BooleanArray(total)
        for (pk in peaks) {
            val px = pk.idx % nx
            val py = pk.idx / nx
            val clip = pk.ref * CLIP_K
            for (dy in -NOTCH_R..NOTCH_R) for (dx in -NOTCH_R..NOTCH_R) {
                val d2 = (dx * dx + dy * dy).toFloat()
                if (d2 > NOTCH_R * NOTCH_R) continue
                val xx = (px + dx + nx) % nx
                val yy = (py + dy + ny) % ny
                val i = yy * nx + xx
                if (done[i]) continue
                done[i] = true
                val mg = mag[i]
                if (mg <= clip) continue
                val d = sqrt(d2)
                val wgt = if (d <= NOTCH_FLAT) 1f else 0.5f * (1f + cos(Math.PI * (d - NOTCH_FLAT) / (NOTCH_R - NOTCH_FLAT + 1)).toFloat())
                val f = (mg - clip) / mg * wgt
                dre[i] = re[i] * f
                dim[i] = im[i] * f
            }
        }
        Fft.transform2d(dre, dim, nx, ny, true)
        val removed = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) removed[y * w + x] = dre[y * nx + x] / max(wx[x] * wy[y], WIN_FLOOR)
        return Result(removed, peaks.size)
    }

    private fun yOf(p: Int) = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
    private fun cbOf(p: Int) = -0.168736f * ((p shr 16) and 255) - 0.331264f * ((p shr 8) and 255) + 0.5f * (p and 255)
    private fun crOf(p: Int) = 0.5f * ((p shr 16) and 255) - 0.418688f * ((p shr 8) and 255) - 0.081312f * (p and 255)

    class Report(val out: IntArray, val peaksY: Int, val peaksCb: Int, val peaksCr: Int) {
        val total: Int get() = peaksY + peaksCb + peaksCr
    }

    /** Khử moiré cho ảnh ARGB [px] (w×h); [strength] 0..1 = phần thành phần moiré bị trừ. Không thấy moiré → trả lại [px] nguyên vẹn. */
    fun applyReport(px: IntArray, w: Int, h: Int, strength: Float, cap: Int = capDefault): Report {
        val s = strength.coerceIn(0f, 1f)
        if (s < 0.01f || w < 16 || h < 16 || px.size != w * h) return Report(px, 0, 0, 0)
        val (iw, ih) = Resample.capped(w, h, cap.coerceIn(256, MAX_CAP))
        val y = Resample.areaMap(px, w, h, iw, ih, ::yOf)
        val rY = suppress(y, iw, ih, LUMA)
        val cb = Resample.areaMap(px, w, h, iw, ih, ::cbOf)
        val rCb = suppress(cb, iw, ih, CHROMA)
        val cr = Resample.areaMap(px, w, h, iw, ih, ::crOf)
        val rCr = suppress(cr, iw, ih, CHROMA)
        val n = rY.peaks + rCb.peaks + rCr.peaks
        if (n == 0) return Report(px, 0, 0, 0)
        val out = IntArray(px.size)
        for (j in 0 until h) for (i in 0 until w) {
            val q = j * w + i
            val dy = -s * Resample.bilinearAt(rY.removed, iw, ih, w, h, i, j)
            val dcb = -s * Resample.bilinearAt(rCb.removed, iw, ih, w, h, i, j)
            val dcr = -s * Resample.bilinearAt(rCr.removed, iw, ih, w, h, i, j)
            val p = px[q]
            val r = (((p shr 16) and 255) + dy + 1.402f * dcr + 0.5f).toInt().coerceIn(0, 255)
            val g = (((p shr 8) and 255) + dy - 0.344136f * dcb - 0.714136f * dcr + 0.5f).toInt().coerceIn(0, 255)
            val b = ((p and 255) + dy + 1.772f * dcb + 0.5f).toInt().coerceIn(0, 255)
            out[q] = (p and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
        return Report(out, rY.peaks, rCb.peaks, rCr.peaks)
    }

    fun apply(px: IntArray, w: Int, h: Int, strength: Float, cap: Int = capDefault): IntArray = applyReport(px, w, h, strength, cap).out
}
