package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.graphics.Bitmap
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * XÓA VẬT THỂ hoàn toàn trên máy: inpainting bằng LaMa (ONNX, đầu vào cố định 512x512).
 * Dùng bản "lama_fp32.onnx" (Carve/LaMa-ONNX): input "image" [1,3,512,512] 0..1, "mask" [1,1,512,512] (1 = lấp),
 * output [1,3,512,512] (0..255 hoặc 0..1, code tự nhận biết).
 *
 * Với ảnh lớn: chỉ cắt vùng quanh mặt nạ (+ ngữ cảnh) đưa vào model rồi dán lại, nên giữ nguyên độ phân giải ảnh.
 */
class LamaInpainter(modelPath: String) : Inpainter, AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val imageName: String
    private val maskName: String
    private val size: Int

    init {
        session = OrtTuning.createSession(env, modelPath)
        val names = session.inputNames.toList()
        maskName = names.firstOrNull { it.contains("mask", ignoreCase = true) } ?: names.last()
        imageName = names.firstOrNull { it != maskName } ?: names.first()
        val shape = (session.inputInfo[imageName]?.info as? TensorInfo)?.shape
        size = if (shape != null && shape.size == 4 && shape[2] > 0) shape[2].toInt() else 512
    }

    override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = false)

    /** Chế độ chính xác: model thấy ĐÚNG mặt nạ (không nới) và chỉ các điểm trong mặt nạ bị thay, hard-edge. */
    override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = true)

    @Synchronized
    private fun run(src: Bitmap, mask: ByteArray, exact: Boolean): Bitmap {
        val w = src.width
        val h = src.height

        // 1. Hộp bao của mặt nạ
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (mask[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return src

        // 2. Vùng cắt = hộp bao + ngữ cảnh, cố gắng cho vuông
        val grow = if (exact) 0 else max(4, max(w, h) / 250)   // bán kính nở mặt nạ (ăn luôn viền/bóng đổ); chế độ chính xác: không nở
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        val margin = max(48, (max(bw, bh) * 0.6f).toInt()) + grow
        var x0 = max(0, minX - margin)
        var y0 = max(0, minY - margin)
        var x1 = min(w, maxX + 1 + margin)
        var y1 = min(h, maxY + 1 + margin)
        var cw = x1 - x0
        var ch = y1 - y0
        val side = max(cw, ch)
        if (side <= min(w, h)) {
            val cx = (x0 + x1) / 2
            val cy = (y0 + y1) / 2
            x0 = (cx - side / 2).coerceIn(0, w - side)
            y0 = (cy - side / 2).coerceIn(0, h - side)
            cw = side
            ch = side
        }

        // 3. Mặt nạ trong vùng cắt: nở + làm mềm biên (chế độ chính xác: đúng mặt nạ, rìa cứng)
        val edge = InpaintEdge.build(mask, w, x0, y0, cw, ch, grow, max(2, max(cw, ch) / 120), exact)

        // 4. Chuẩn bị tensor
        val crop = Bitmap.createBitmap(src, x0, y0, cw, ch)
        val small = Bitmap.createScaledBitmap(crop, size, size, true)
        val px = IntArray(size * size)
        small.getPixels(px, 0, size, 0, 0, size, size)
        val plane = size * size
        val imgData = FloatArray(3 * plane)
        for (i in px.indices) {
            val p = px[i]
            imgData[i] = ((p shr 16) and 255) / 255f
            imgData[plane + i] = ((p shr 8) and 255) / 255f
            imgData[2 * plane + i] = (p and 255) / 255f
        }
        val maskData = FloatArray(plane)
        if (exact) {
            // thu nhỏ kiểu "có điểm trống nào trong ô thì ô là trống": nét tô mảnh không bị rớt (không còn phần nới để bù)
            val m = InpaintEdge.shrinkAny(edge.hole, cw, ch, size, size)
            for (i in 0 until plane) maskData[i] = if (m[i]) 1f else 0f
        } else {
            for (yy in 0 until size) {
                val sy = min(ch - 1, yy * ch / size)
                for (xx in 0 until size) {
                    val sx = min(cw - 1, xx * cw / size)
                    maskData[yy * size + xx] = if (edge.hole[sy * cw + sx]) 1f else 0f
                }
            }
        }

        // 5. Chạy model
        val s = size.toLong()
        val filledPx = IntArray(plane)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(imgData), longArrayOf(1, 3, s, s)).use { tImg ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(maskData), longArrayOf(1, 1, s, s)).use { tMask ->
                session.run(mapOf(imageName to tImg, maskName to tMask)).use { res ->
                    @Suppress("UNCHECKED_CAST")
                    val out = (res.get(0).value as Array<Array<Array<FloatArray>>>)[0]
                    var mx = 0f
                    for (c in 0 until 3) for (y in 0 until size) for (x in 0 until size) {
                        if (out[c][y][x] > mx) mx = out[c][y][x]
                    }
                    val k = if (mx > 2f) 1f else 255f
                    for (y in 0 until size) for (x in 0 until size) {
                        val r = (out[0][y][x] * k).toInt().coerceIn(0, 255)
                        val g = (out[1][y][x] * k).toInt().coerceIn(0, 255)
                        val b = (out[2][y][x] * k).toInt().coerceIn(0, 255)
                        filledPx[y * size + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
            }
        }
        val filledSmall = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        filledSmall.setPixels(filledPx, 0, size, 0, 0, size, size)
        val filled = Bitmap.createScaledBitmap(filledSmall, cw, ch, true)
        val fp = IntArray(cw * ch)
        filled.getPixels(fp, 0, cw, 0, 0, cw, ch)

        // 6. Dán lại vào ảnh gốc (pha trộn theo biên mềm; chế độ chính xác: chỉ điểm trong mặt nạ, thay hẳn)
        val result = IntArray(w * h)
        src.getPixels(result, 0, w, 0, 0, w, h)
        InpaintEdge.paste(result, w, x0, y0, cw, ch, fp, edge.alpha)
        val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        outBmp.setPixels(result, 0, w, 0, 0, w, h)
        return outBmp
    }

    override fun close() {
        try { session.close() } catch (e: Throwable) { }
    }
}
