package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * XÓA VẬT THỂ bản nhẹ cho di động: MI-GAN (Picsart, ICCV 2023, giấy phép MIT), file "pipeline" ONNX
 * (`migan_pipeline_v2.onnx`, ~80 MB). Đã xác minh từ tài liệu: input `image` uint8 [1,3,H,W] (RGB),
 * `mask` uint8 [1,1,H,W] với 0 = vùng cần xóa, 255 = giữ; output uint8 [1,3,H,W] đã ghép sẵn; H, W động.
 * Cắt vùng quanh mặt nạ (≤ 768px) -> chạy model -> dán lại bằng mặt nạ mềm, nên giữ nguyên độ phân giải ảnh.
 */
class MiganInpainter(modelPath: String) : Inpainter, AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession = OrtTuning.createSession(env, modelPath)
    private val imageName: String
    private val maskName: String

    init {
        val names = session.inputNames.toList()
        maskName = names.firstOrNull { it.contains("mask", ignoreCase = true) } ?: names.last()
        imageName = names.firstOrNull { it != maskName } ?: names.first()
    }

    override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = false)

    /** Chế độ chính xác: model thấy ĐÚNG mặt nạ (không nới) và chỉ các điểm trong mặt nạ bị thay, rìa cứng. */
    override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = true)

    @Synchronized
    private fun run(src: Bitmap, mask: ByteArray, exact: Boolean): Bitmap {
        val w = src.width
        val rect = RegionCrop.compute(mask, w, src.height) ?: return src

        val gray = RegionCrop.maskGray(mask, w, rect)
        val grown = if (exact) gray else Blur.gaussian(gray, rect.w, rect.h, max(3, max(rect.w, rect.h) / 120))

        val s = min(1f, 768f / max(rect.w, rect.h))
        val mw = max(16, (rect.w * s).roundToInt())
        val mh = max(16, (rect.h * s).roundToInt())
        val crop = Bitmap.createBitmap(src, rect.x, rect.y, rect.w, rect.h)
        val small = if (mw != rect.w || mh != rect.h) Bitmap.createScaledBitmap(crop, mw, mh, true) else crop
        val px = readPixels(small)

        val plane = mw * mh
        val imgArr = ByteArray(3 * plane)
        for (i in 0 until plane) {
            val p = px[i]
            imgArr[i] = (p shr 16).toByte()
            imgArr[plane + i] = (p shr 8).toByte()
            imgArr[2 * plane + i] = p.toByte()
        }
        val maskArr = ByteArray(plane)
        if (exact) {
            // thu nhỏ kiểu "có điểm trống nào trong ô thì ô là trống" để nét tô mảnh không rớt khỏi mặt nạ của model
            val m = InpaintEdge.shrinkAny(BooleanArray(rect.w * rect.h) { (grown[it] and 255) != 0 }, rect.w, rect.h, mw, mh)
            for (i in 0 until plane) maskArr[i] = if (m[i]) 0 else 255.toByte()
        } else {
            for (y in 0 until mh) {
                val sy = min(rect.h - 1, y * rect.h / mh)
                for (x in 0 until mw) {
                    val sx = min(rect.w - 1, x * rect.w / mw)
                    maskArr[y * mw + x] = if ((grown[sy * rect.w + sx] and 255) > 10) 0 else 255.toByte()
                }
            }
        }

        fun direct(a: ByteArray): ByteBuffer {
            val b = ByteBuffer.allocateDirect(a.size).order(ByteOrder.nativeOrder())
            b.put(a)
            b.rewind()
            return b
        }

        val outPx = IntArray(plane)
        OnnxTensor.createTensor(env, direct(imgArr), longArrayOf(1, 3, mh.toLong(), mw.toLong()), OnnxJavaType.UINT8)
            .use { tImg ->
                OnnxTensor.createTensor(env, direct(maskArr), longArrayOf(1, 1, mh.toLong(), mw.toLong()), OnnxJavaType.UINT8)
                    .use { tMask ->
                        session.run(mapOf(imageName to tImg, maskName to tMask)).use { res ->
                            val buf = (res.get(0) as OnnxTensor).byteBuffer
                            for (i in 0 until plane) {
                                val r = buf.get(i).toInt() and 255
                                val g = buf.get(plane + i).toInt() and 255
                                val b = buf.get(2 * plane + i).toInt() and 255
                                outPx[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                            }
                        }
                    }
            }
        val outSmall = makeBitmap(outPx, mw, mh)
        val generated = if (mw != rect.w || mh != rect.h) Bitmap.createScaledBitmap(outSmall, rect.w, rect.h, true) else outSmall
        return RegionCrop.composite(src, mask, rect, generated, exact)
    }

    override fun close() {
        try { session.close() } catch (e: Throwable) { }
    }
}
