package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * R11 — Bộ chỉnh tông "chuyên nghiệp" còn thiếu so với PDF (Vùng sáng, Cấu trúc) và so với Lightroom/ACDSee:
 *  - [highlights]: kéo/đẩy vùng SÁNG theo đường cong đơn điệu trên độ chói, giữ nguyên sắc độ (hệ số nhân RGB).
 *  - [vibrance]: bão hòa thông minh — tăng nhiều ở màu nhạt, bảo vệ tông da, giảm ít ở màu đã rực.
 *  - [tint]: lệch xanh lá ↔ tím (magenta), bảo toàn độ chói.
 *  - [dehaze]: khử/thêm sương mù theo Dark Channel Prior (ước lượng ở ảnh nhỏ rồi phóng lên → mượt, không quầng).
 *  - [texture]: tương phản chi tiết mịn (tần số giữa), có chặn quầng; giá trị âm = làm mịn kết cấu.
 * Tất cả nhận/ trả IntArray ARGB, không đụng alpha. Bản port Python: tools/verify_ports/pro_tone.py.
 */
object ProTone {

    private fun red(p: Int) = (p shr 16) and 255
    private fun green(p: Int) = (p shr 8) and 255
    private fun blue(p: Int) = p and 255
    private fun pack(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private fun cl(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()
    private fun lum(p: Int): Float = 0.299f * red(p) + 0.587f * green(p) + 0.114f * blue(p)
    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    // ------------------------------------------------------------------ Highlights
    /**
     * LUT độ chói đích (0..255, kiểu Float) cho Vùng sáng. Dựng bằng công thức giải tích (smoothstep) thay vì nội suy qua điểm neo
     * để (1) vùng tối/trung bình (L ≤ 0.45) giữ ĐÚNG đồng nhất, (2) đơn điệu được chứng minh:
     *  a < 0 (cứu cháy sáng): dịch = −|a|·(0.14·s_mid − 0.04·s_top) → đỉnh trắng hạ 0.10, vùng 0.75 hạ 0.14; đạo hàm ≥ 0.3.
     *  a > 0 (làm sáng thêm): dịch = +a·0.12·s_mid·(1 − s_top) → trắng giữ nguyên; đạo hàm ≥ 0.28.
     */
    fun highlightLut(a: Float): FloatArray {
        val v = a.coerceIn(-1f, 1f)
        return FloatArray(256) { i ->
            val l = i / 255f
            val sMid = smooth(0.45f, 0.75f, l)
            val sTop = smooth(0.75f, 1f, l)
            val shift = if (v < 0f) v * (0.14f * sMid - 0.04f * sTop) else v * 0.12f * sMid * (1f - sTop)
            (l + shift).coerceIn(0f, 1f) * 255f
        }
    }

    fun highlights(px: IntArray, amount: Float): IntArray {
        val a = amount.coerceIn(-1f, 1f)
        if (abs(a) < 0.005f) return px
        val lut = highlightLut(a)
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val r = red(p); val g = green(p); val b = blue(p)
            val l = (0.299f * r + 0.587f * g + 0.114f * b + 0.5f).toInt().coerceIn(0, 255)
            if (l == 0) { out[i] = p; continue }
            var s = lut[l] / l
            val mx = max(r, max(g, b)) * s
            if (mx > 255f) s *= 255f / mx
            out[i] = pack(p ushr 24, cl(r * s), cl(g * s), cl(b * s))
        }
        return out
    }

    // ------------------------------------------------------------------ Vibrance
    private fun hueDeg(r: Float, g: Float, b: Float, mx: Float, d: Float): Float {
        val h = when {
            mx == r -> { val t = (g - b) / d; 60f * (if (t < 0f) t + 6f else t) }
            mx == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        return h
    }

    fun vibrance(px: IntArray, amount: Float): IntArray {
        val a = amount.coerceIn(-1f, 1f)
        if (abs(a) < 0.005f) return px
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val r = red(p).toFloat(); val g = green(p).toFloat(); val b = blue(p).toFloat()
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val d = mx - mn
            if (mx <= 0f || d < 1f) { out[i] = p; continue }
            val s = d / mx
            val f: Float
            if (a > 0f) {
                var dh = abs(hueDeg(r, g, b, mx, d) - 25f)
                if (dh > 180f) dh = 360f - dh
                val skin = 1f - smooth(10f, 40f, dh)
                f = a * 0.9f * (1f - s) * (1f - 0.55f * skin)
            } else {
                f = a * (0.3f + 0.5f * s)
            }
            val gray = 0.299f * r + 0.587f * g + 0.114f * b
            val k = 1f + f
            out[i] = pack(p ushr 24, cl(gray + (r - gray) * k), cl(gray + (g - gray) * k), cl(gray + (b - gray) * k))
        }
        return out
    }

    // ------------------------------------------------------------------ Tint
    /** a > 0 = ngả tím (magenta), a < 0 = ngả xanh lá. Dịch R,B cùng chiều và G ngược chiều sao cho độ chói không đổi. */
    fun tint(px: IntArray, amount: Float): IntArray {
        val a = amount.coerceIn(-1f, 1f)
        if (abs(a) < 0.005f) return px
        val dBase = a * 22f
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val l = lum(p) / 255f
            val w = 0.6f + 0.4f * (1f - abs(2f * l - 1f))
            val d = dBase * w
            out[i] = pack(
                p ushr 24,
                cl(red(p) + 1.4213f * d),
                cl(green(p) - d),
                cl(blue(p) + 1.4213f * d)
            )
        }
        return out
    }

    // ------------------------------------------------------------------ Dehaze
    private const val DEHAZE_SIDE = 256
    private const val DEHAZE_T0 = 0.25f

    /** Thu nhỏ bằng trung bình khối; trả (rộng, cao, r, g, b) với giá trị 0..1. */
    private class Small(val w: Int, val h: Int, val r: FloatArray, val g: FloatArray, val b: FloatArray)

    private fun shrink(px: IntArray, w: Int, h: Int): Small {
        val f = max(1, (max(w, h) + DEHAZE_SIDE - 1) / DEHAZE_SIDE)
        val sw = max(1, w / f)
        val sh = max(1, h / f)
        val r = FloatArray(sw * sh); val g = FloatArray(sw * sh); val b = FloatArray(sw * sh)
        for (y in 0 until sh) for (x in 0 until sw) {
            var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
            for (dy in 0 until f) {
                val yy = y * f + dy
                if (yy >= h) break
                for (dx in 0 until f) {
                    val xx = x * f + dx
                    if (xx >= w) break
                    val p = px[yy * w + xx]
                    sr += red(p); sg += green(p); sb += blue(p); n++
                }
            }
            val i = y * sw + x
            r[i] = sr / (255f * n); g[i] = sg / (255f * n); b[i] = sb / (255f * n)
        }
        return Small(sw, sh, r, g, b)
    }

    /** Lọc min (xói mòn) hình vuông bán kính [rad], tách hai chiều. */
    private fun minFilter(src: FloatArray, w: Int, h: Int, rad: Int): FloatArray {
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var m = 1e9f
            for (k in max(0, x - rad)..min(w - 1, x + rad)) m = min(m, src[y * w + k])
            tmp[y * w + x] = m
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var m = 1e9f
            for (k in max(0, y - rad)..min(h - 1, y + rad)) m = min(m, tmp[k * w + x])
            out[y * w + x] = m
        }
        return out
    }

    /** Trung bình hộp bán kính [rad], tách hai chiều, mép lặp lại. */
    private fun boxBlur(src: FloatArray, w: Int, h: Int, rad: Int): FloatArray {
        if (rad < 1) return src.copyOf()
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -rad..rad) s += src[y * w + min(max(x + k, 0), w - 1)]
            tmp[y * w + x] = s / (2 * rad + 1)
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -rad..rad) s += tmp[min(max(y + k, 0), h - 1) * w + x]
            out[y * w + x] = s / (2 * rad + 1)
        }
        return out
    }

    /** Ánh sáng khí quyển A (0..1 mỗi kênh): trung bình các điểm có kênh-tối-nhất thuộc 0.5% cao nhất, kẹp ≥ 0.55. */
    fun atmosphericLight(small: FloatArray, sr: FloatArray, sg: FloatArray, sb: FloatArray): FloatArray {
        val n = small.size
        val order = (0 until n).sortedByDescending { small[it] }
        val take = max(1, (n * 0.005f).roundToInt())
        var ar = 0f; var ag = 0f; var ab = 0f
        for (k in 0 until take) { val i = order[k]; ar += sr[i]; ag += sg[i]; ab += sb[i] }
        return floatArrayOf(max(0.55f, ar / take), max(0.55f, ag / take), max(0.55f, ab / take))
    }

    fun dehaze(px: IntArray, w: Int, h: Int, amount: Float): IntArray {
        val a = amount.coerceIn(-1f, 1f)
        if (abs(a) < 0.005f || px.size != w * h) return px
        val sm = shrink(px, w, h)
        val n = sm.w * sm.h
        val dark0 = FloatArray(n) { min(sm.r[it], min(sm.g[it], sm.b[it])) }
        val air = atmosphericLight(dark0, sm.r, sm.g, sm.b)
        val out = IntArray(px.size)
        if (a < 0f) {
            // thêm sương mù: kéo màu về ánh sáng khí quyển
            val k = -a * 0.55f
            for (i in px.indices) {
                val p = px[i]
                out[i] = pack(
                    p ushr 24,
                    cl(red(p) * (1f - k) + air[0] * 255f * k),
                    cl(green(p) * (1f - k) + air[1] * 255f * k),
                    cl(blue(p) * (1f - k) + air[2] * 255f * k)
                )
            }
            return out
        }
        // khử sương mù: dark channel của I/A -> truyền suất t (mượt) -> J = (I - A)/t + A
        val norm = FloatArray(n) { min(sm.r[it] / air[0], min(sm.g[it] / air[1], sm.b[it] / air[2])) }
        val rad = max(1, max(sm.w, sm.h) / 40)
        val dark = minFilter(norm, sm.w, sm.h, rad)
        val omega = 0.95f * a
        var t = FloatArray(n) { (1f - omega * dark[it]).coerceIn(DEHAZE_T0, 1f) }
        t = boxBlur(t, sm.w, sm.h, max(1, rad))
        for (y in 0 until h) {
            // nội suy song tuyến truyền suất từ ảnh nhỏ
            val fy = ((y + 0.5f) * sm.h / h - 0.5f).coerceIn(0f, (sm.h - 1).toFloat())
            val y0 = fy.toInt(); val y1 = min(sm.h - 1, y0 + 1); val wy = fy - y0
            for (x in 0 until w) {
                val fx = ((x + 0.5f) * sm.w / w - 0.5f).coerceIn(0f, (sm.w - 1).toFloat())
                val x0 = fx.toInt(); val x1 = min(sm.w - 1, x0 + 1); val wx = fx - x0
                val tt = (t[y0 * sm.w + x0] * (1f - wx) + t[y0 * sm.w + x1] * wx) * (1f - wy) +
                    (t[y1 * sm.w + x0] * (1f - wx) + t[y1 * sm.w + x1] * wx) * wy
                val tc = max(DEHAZE_T0, tt)
                val p = px[y * w + x]
                out[y * w + x] = pack(
                    p ushr 24,
                    cl(((red(p) / 255f - air[0]) / tc + air[0]) * 255f),
                    cl(((green(p) / 255f - air[1]) / tc + air[1]) * 255f),
                    cl(((blue(p) / 255f - air[2]) / tc + air[2]) * 255f)
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------------ Texture
    fun textureRadius(w: Int, h: Int): Int = max(1, (max(w, h) / 700f).roundToInt())

    /** Chi tiết mịn = độ chói − độ chói đã làm mờ; a > 0 khuếch đại có chặn quầng, a < 0 trừ bớt (làm mịn kết cấu). */
    fun texture(px: IntArray, w: Int, h: Int, amount: Float): IntArray {
        val a = amount.coerceIn(-1f, 1f)
        if (abs(a) < 0.005f) return px
        val blurred = Blur.gaussian(px, w, h, textureRadius(w, h))
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val d = lum(p) - lum(blurred[i])
            val delta = if (a > 0f) a * 1.2f * d / (1f + abs(d) / 40f) else a * 0.85f * d
            out[i] = pack(p ushr 24, cl(red(p) + delta), cl(green(p) + delta), cl(blue(p) + delta))
        }
        return out
    }
}
