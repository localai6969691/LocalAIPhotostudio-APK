package com.aiphoto.studio.doc

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max

/**
 * R11 — Lớp PHỦ (PDF: "Thêm chữ", "Phơi sáng kép"): chữ hoặc ảnh đặt lên ảnh, KHÔNG phá hủy như mọi lớp khác
 * (đổi nội dung / vị trí / cỡ / góc xoay / độ mờ / chế độ hòa trộn / mặt nạ bất cứ lúc nào).
 *
 * Tọa độ theo thang 0..1 của ảnh nên không phụ thuộc độ phân giải (xem trước thấp và xuất gốc ra cùng bố cục):
 *  - [cx], [cy]: tâm lớp.
 *  - [size]: chữ = chiều cao chữ so với CHIỀU RỘNG ảnh; ảnh = chiều rộng ảnh phủ so với chiều rộng ảnh nền.
 *  - [rotation]: độ, quanh tâm.
 * Phơi sáng kép = lớp ảnh với chế độ Screen/Lighten, độ mờ ~60–70%.
 */
data class OverlayLayer(
    override val id: Long,
    override val name: String,
    /** "text" | "image" */
    val kind: String,
    val text: String = "",
    val color: Int = -1,
    val bold: Boolean = true,
    /** Viền tương phản (đen trên chữ sáng, trắng trên chữ tối) để đọc được trên mọi nền. */
    val outline: Boolean = true,
    val image: Bitmap? = null,
    val cx: Float = 0.5f,
    val cy: Float = 0.5f,
    val size: Float = 0.12f,
    val rotation: Float = 0f,
    override val visible: Boolean = true,
    override val opacity: Float = 1f,
    override val blend: BlendMode = BlendMode.NORMAL,
    override val mask: LayerMask? = null,
    override val clip: Boolean = false,
    /** R25: 0..1 = mức hòa màu / độ sáng của ảnh phủ với nền ngay bên dưới (engine/Harmonize.kt); chỉ có tác dụng với kind = "image". */
    val harmonize: Float = 0f
) : Layer {
    override fun update(visible: Boolean, opacity: Float, blend: BlendMode, mask: LayerMask?, name: String, clip: Boolean): Layer =
        copy(visible = visible, opacity = opacity, blend = blend, mask = mask, name = name, clip = clip)

    /**
     * Biến đổi theo cử chỉ trên khung ảnh: [dx],[dy] = độ dịch theo thang 0..1 của ảnh, [zoom] = hệ số nhân cỡ (chụm/giãn),
     * [rotationDeg] = góc xoay thêm. Giá trị không hữu hạn bị bỏ qua; góc được chuẩn hóa về (−180, 180]; mọi tham số được kẹp an toàn.
     */
    fun transformed(dx: Float, dy: Float, zoom: Float, rotationDeg: Float): OverlayLayer {
        val sx = if (dx.isFinite()) dx else 0f
        val sy = if (dy.isFinite()) dy else 0f
        val z = if (zoom.isFinite() && zoom > 0f) zoom.coerceIn(0.2f, 5f) else 1f
        val r = if (rotationDeg.isFinite()) rotationDeg else 0f
        val wrapped = ((rotation + r + 180f) % 360f + 360f) % 360f - 180f
        return clampParams(copy(cx = cx + sx, cy = cy + sy, size = size * z, rotation = if (wrapped == -180f) 180f else wrapped))
    }

    companion object {
        const val MAX_TEXT = 200
        const val MAX_LINES = 6

        /** Kẹp mọi tham số về miền an toàn (dùng khi đọc phiên từ tệp / nhận giá trị từ giao diện). */
        fun clampParams(l: OverlayLayer): OverlayLayer = l.copy(
            text = l.text.take(MAX_TEXT),
            cx = l.cx.coerceIn(-0.5f, 1.5f),
            cy = l.cy.coerceIn(-0.5f, 1.5f),
            size = l.size.coerceIn(0.01f, 2f),
            rotation = l.rotation.coerceIn(-360f, 360f),
            harmonize = if (l.harmonize.isFinite()) l.harmonize.coerceIn(0f, 1f) else 0f
        )
    }
}

object OverlayRenderer {

    /** Vẽ lớp phủ lên một bitmap TRONG SUỐT cỡ w×h. Trả null nếu không có gì để vẽ (chữ rỗng / thiếu ảnh). */
    fun render(l: OverlayLayer, w: Int, h: Int): Bitmap? {
        if (w <= 0 || h <= 0) return null
        if (l.kind == "text" && l.text.isBlank()) return null
        if (l.kind == "image" && (l.image == null || l.image.isRecycled)) return null
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.save()
        canvas.translate(l.cx * w, l.cy * h)
        canvas.rotate(l.rotation)
        if (l.kind == "image") drawImage(canvas, l, w) else drawText(canvas, l, w)
        canvas.restore()
        return out
    }

    private fun drawImage(canvas: Canvas, l: OverlayLayer, w: Int) {
        val src = l.image ?: return
        val dw = max(1f, l.size * w)
        val dh = dw * src.height / max(1, src.width)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        canvas.drawBitmap(src, null, RectF(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f), paint)
    }

    private fun drawText(canvas: Canvas, l: OverlayLayer, w: Int) {
        val lines = l.text.take(OverlayLayer.MAX_TEXT).split('\n').take(OverlayLayer.MAX_LINES)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = max(4f, l.size * w)
            textAlign = Paint.Align.CENTER
            typeface = if (l.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            color = l.color
        }
        val lh = fill.fontSpacing
        val centerShift = -(fill.ascent() + fill.descent()) / 2f
        val r = (l.color shr 16) and 255
        val g = (l.color shr 8) and 255
        val b = l.color and 255
        val bright = 0.299f * r + 0.587f * g + 0.114f * b > 140f
        val stroke = if (l.outline) Paint(fill).apply {
            style = Paint.Style.STROKE
            strokeWidth = fill.textSize * 0.12f
            strokeJoin = Paint.Join.ROUND
            color = if (bright) 0xCC000000.toInt() else 0xCCFFFFFF.toInt()
        } else null
        for ((i, line) in lines.withIndex()) {
            val y = (i - (lines.size - 1) / 2f) * lh + centerShift
            if (stroke != null) canvas.drawText(line, 0f, y, stroke)
            canvas.drawText(line, 0f, y, fill)
        }
    }
}
