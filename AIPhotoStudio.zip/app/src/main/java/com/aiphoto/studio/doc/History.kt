package com.aiphoto.studio.doc

import com.aiphoto.studio.ai.EditOp
import kotlin.math.roundToInt

/**
 * R12 — Nhãn cho panel LỊCH SỬ (PDF: "Lịch sử (History/Stacks): xem lại và hoàn tác các bước").
 * Thay vì sửa hàng chục chỗ gọi pushUndo, nhãn mỗi bước được SUY RA bằng cách so hai trạng thái liền kề (ảnh nền + danh sách lớp):
 * thêm/xóa/đổi thứ tự lớp, ẩn/hiện, độ mờ, chế độ hòa trộn, mặt nạ, clipping, tên phép chỉnh đã đổi, sửa chữ/ảnh phủ...
 * Hàm thuần (không đụng Android) nên kiểm thử được trên JVM.
 */
object HistoryLabels {

    fun describe(bgChanged: Boolean, a: List<Layer>, b: List<Layer>): String {
        val aIds = a.map { it.id }
        val bIds = b.map { it.id }
        val aSet = aIds.toSet()
        val bSet = bIds.toSet()
        val added = b.filter { it.id !in aSet }
        val removed = a.filter { it.id !in bSet }
        val prefix = if (bgChanged) "Đổi ảnh nền (cắt / xoay / phóng to / xóa nền…)" else ""
        if (added.isNotEmpty() || removed.isNotEmpty()) {
            val parts = ArrayList<String>()
            if (added.size == 1) parts.add("Thêm lớp “${added[0].name}”") else if (added.size > 1) parts.add("Thêm ${added.size} lớp")
            if (removed.size == 1) parts.add("Xóa lớp “${removed[0].name}”") else if (removed.size > 1) parts.add("Xóa ${removed.size} lớp")
            return (listOf(prefix).filter { it.isNotEmpty() } + parts).joinToString(" · ")
        }
        if (aIds != bIds) return "Đổi thứ tự lớp"
        val changes = ArrayList<String>()
        for (i in a.indices) if (a[i] != b[i]) changes.add(describeLayerChange(a[i], b[i]))
        if (changes.isEmpty()) return if (bgChanged) prefix else "Không thay đổi"
        val text = changes.take(2).joinToString(" · ") + if (changes.size > 2) " …" else ""
        return if (bgChanged) "$prefix · $text" else text
    }

    private fun describeLayerChange(x: Layer, y: Layer): String {
        val n = "“${y.name}”"
        if (x.visible != y.visible) return if (y.visible) "Hiện lớp $n" else "Ẩn lớp $n"
        if (x.opacity != y.opacity) return "Độ mờ lớp $n: ${(y.opacity * 100).roundToInt()}%"
        if (x.blend != y.blend) return "Chế độ hòa trộn $n: ${y.blend.name.lowercase().replace('_', ' ')}"
        if (x.clip != y.clip) return if (y.clip) "Cắt $n theo lớp dưới" else "Bỏ cắt lớp $n"
        if (x.mask != y.mask) return "Sửa mặt nạ lớp $n"
        if (x is AdjustmentLayer && y is AdjustmentLayer && x.ops != y.ops) return "Chỉnh ${changedOps(x.ops, y.ops)}: ${y.name}"
        if (x is OverlayLayer && y is OverlayLayer && x.copy(name = y.name) != y) {
            return if (y.kind == "text") "Sửa lớp chữ $n" else "Sửa lớp ảnh phủ $n"
        }
        if (x is PatchLayer && y is PatchLayer) return "Sửa mảng vá $n"
        if (x.name != y.name) return "Đổi tên lớp ${"“${x.name}”"} → $n"
        return "Sửa lớp $n"
    }

    /** Tên các phép chỉnh khác nhau giữa hai danh sách (tối đa 2 tên + "…"). */
    private fun changedOps(a: List<EditOp>, b: List<EditOp>): String {
        val am = a.associateBy { it.type }
        val bm = b.associateBy { it.type }
        val labels = (am.keys + bm.keys).filter { am[it] != bm[it] }.map { it.label }
        if (labels.isEmpty()) return "phép chỉnh"
        return labels.take(2).joinToString(", ") + if (labels.size > 2) "…" else ""
    }
}
