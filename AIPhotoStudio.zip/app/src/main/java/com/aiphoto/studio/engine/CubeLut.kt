package com.aiphoto.studio.engine

import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * R11 — LUT màu 3D định dạng .cube (Adobe/Resolve/Iridas): chuẩn của "Looks/LUT" trong các phần mềm chỉnh ảnh chuyên nghiệp.
 * Hỗ trợ: TITLE, LUT_3D_SIZE (2..65), DOMAIN_MIN/MAX, chú thích '#'. LUT 1D → từ chối (có thông báo).
 * Dữ liệu: thứ tự file .cube = đỏ chạy nhanh nhất, rồi lục, rồi lam: chỉ số = ((b·N + g)·N + r)·3.
 * Nội suy TỨ DIỆN (tetrahedral). Bản port Python: tools/verify_ports/cube_lut.py.
 */
class Lut3d(
    val size: Int,
    /** size³ × 3 giá trị đầu ra (r,g,b) thang 0..1 (kể cả khi DOMAIN đầu vào khác 0..1). */
    val data: FloatArray,
    val domainMin: FloatArray = floatArrayOf(0f, 0f, 0f),
    val domainMax: FloatArray = floatArrayOf(1f, 1f, 1f),
    val title: String = ""
)

object CubeLut {

    const val MAX_SIZE = 65
    /** Giới hạn kích thước tệp .cube chấp nhận (65³ dòng ≈ 8 MB chữ). */
    const val MAX_BYTES = 12L * 1024 * 1024

    class ParseResult(val lut: Lut3d?, val error: String?)

    fun parse(text: String): ParseResult {
        var size = 0
        var oneD = false
        var title = ""
        val dmin = floatArrayOf(0f, 0f, 0f)
        val dmax = floatArrayOf(1f, 1f, 1f)
        var data: FloatArray? = null
        var count = 0
        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line[0] == '#') continue
            val first = line[0]
            if (first.isLetter()) {
                val parts = line.split(Regex("\\s+"))
                when (parts[0].uppercase()) {
                    "TITLE" -> title = line.substring(5).trim().trim('"')
                    "LUT_3D_SIZE" -> {
                        size = parts.getOrNull(1)?.toIntOrNull() ?: return ParseResult(null, "LUT_3D_SIZE không hợp lệ")
                        if (size < 2 || size > MAX_SIZE) return ParseResult(null, "LUT_3D_SIZE phải trong 2..$MAX_SIZE")
                        data = FloatArray(size * size * size * 3)
                    }
                    "LUT_1D_SIZE" -> oneD = true
                    "DOMAIN_MIN" -> for (k in 0 until 3) dmin[k] = parts.getOrNull(1 + k)?.toFloatOrNull() ?: 0f
                    "DOMAIN_MAX" -> for (k in 0 until 3) dmax[k] = parts.getOrNull(1 + k)?.toFloatOrNull() ?: 1f
                    else -> { /* từ khóa khác (LUT_1D_INPUT_RANGE...) bỏ qua */ }
                }
                continue
            }
            // dòng dữ liệu: 3 số
            val d = data ?: return ParseResult(null, if (oneD) "LUT 1D chưa được hỗ trợ (cần LUT 3D)" else "Thiếu LUT_3D_SIZE trước dữ liệu")
            val parts = line.split(Regex("\\s+"))
            if (parts.size < 3) return ParseResult(null, "Dòng dữ liệu thiếu giá trị")
            if (count * 3 + 3 > d.size) return ParseResult(null, "Dữ liệu LUT dư so với LUT_3D_SIZE")
            for (k in 0 until 3) {
                val v = parts[k].toFloatOrNull()
                if (v == null || v.isNaN() || v.isInfinite()) return ParseResult(null, "Giá trị LUT không hợp lệ")
                d[count * 3 + k] = v
            }
            count++
        }
        if (oneD && data == null) return ParseResult(null, "LUT 1D chưa được hỗ trợ (cần LUT 3D)")
        val d = data ?: return ParseResult(null, "Không có LUT_3D_SIZE")
        if (count != size * size * size) return ParseResult(null, "Số dòng dữ liệu ($count) khác $size³ = ${size * size * size}")
        for (k in 0 until 3) if (dmax[k] <= dmin[k]) return ParseResult(null, "DOMAIN_MAX phải lớn hơn DOMAIN_MIN")
        return ParseResult(Lut3d(size, d, dmin, dmax, title), null)
    }

    /** LUT đồng nhất (dùng để kiểm thử và làm mẫu). */
    fun identity(size: Int): Lut3d {
        val d = FloatArray(size * size * size * 3)
        var i = 0
        for (b in 0 until size) for (g in 0 until size) for (r in 0 until size) {
            d[i++] = r / (size - 1f)
            d[i++] = g / (size - 1f)
            d[i++] = b / (size - 1f)
        }
        return Lut3d(size, d)
    }

    /** Áp LUT bằng nội suy tứ diện, trộn với ảnh gốc theo [intensity] (0..1). Không đụng alpha. */
    fun apply(px: IntArray, lut: Lut3d, intensity: Float): IntArray {
        val k = intensity.coerceIn(0f, 1f)
        if (k <= 0.001f) return px
        val n = lut.size
        val nm = (n - 1).toFloat()
        val dm = lut.domainMin
        val dx = lut.domainMax
        val inv0 = 1f / (dx[0] - dm[0]); val inv1 = 1f / (dx[1] - dm[1]); val inv2 = 1f / (dx[2] - dm[2])
        val d = lut.data
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            val rf = ((r / 255f - dm[0]) * inv0 * nm).coerceIn(0f, nm)
            val gf = ((g / 255f - dm[1]) * inv1 * nm).coerceIn(0f, nm)
            val bf = ((b / 255f - dm[2]) * inv2 * nm).coerceIn(0f, nm)
            val r0 = rf.toInt(); val g0 = gf.toInt(); val b0 = bf.toInt()
            val r1 = min(r0 + 1, n - 1); val g1 = min(g0 + 1, n - 1); val b1 = min(b0 + 1, n - 1)
            val fr = rf - r0; val fg = gf - g0; val fb = bf - b0
            // NỘI SUY TỨ DIỆN (tetrahedral — chuẩn của DaVinci Resolve/OCIO): chỉ dùng 4 trong 8 đỉnh của ô lập phương, đi theo đường
            // c000 → c(trục lớn nhất) → c(hai trục lớn nhất) → c111. Trục xám (fr=fg=fb) chỉ dùng c000 và c111 nên LUT trung tính không ám màu.
            val c000 = ((b0 * n + g0) * n + r0) * 3
            val c100 = ((b0 * n + g0) * n + r1) * 3
            val c010 = ((b0 * n + g1) * n + r0) * 3
            val c110 = ((b0 * n + g1) * n + r1) * 3
            val c001 = ((b1 * n + g0) * n + r0) * 3
            val c101 = ((b1 * n + g0) * n + r1) * 3
            val c011 = ((b1 * n + g1) * n + r0) * 3
            val c111 = ((b1 * n + g1) * n + r1) * 3
            val pa: Int; val pb: Int; val w1: Float; val w2: Float; val w3: Float
            if (fr >= fg) {
                if (fg >= fb) { pa = c100; pb = c110; w1 = fr; w2 = fg; w3 = fb }        // r ≥ g ≥ b
                else if (fr >= fb) { pa = c100; pb = c101; w1 = fr; w2 = fb; w3 = fg }   // r ≥ b > g
                else { pa = c001; pb = c101; w1 = fb; w2 = fr; w3 = fg }                 // b > r ≥ g
            } else {
                if (fb >= fg) { pa = c001; pb = c011; w1 = fb; w2 = fg; w3 = fr }        // b ≥ g > r
                else if (fb >= fr) { pa = c010; pb = c011; w1 = fg; w2 = fb; w3 = fr }   // g > b ≥ r
                else { pa = c010; pb = c110; w1 = fg; w2 = fr; w3 = fb }                 // g > r > b
            }
            val sr = d[c000] + w1 * (d[pa] - d[c000]) + w2 * (d[pb] - d[pa]) + w3 * (d[c111] - d[pb])
            val sg = d[c000 + 1] + w1 * (d[pa + 1] - d[c000 + 1]) + w2 * (d[pb + 1] - d[pa + 1]) + w3 * (d[c111 + 1] - d[pb + 1])
            val sb = d[c000 + 2] + w1 * (d[pa + 2] - d[c000 + 2]) + w2 * (d[pb + 2] - d[pa + 2]) + w3 * (d[c111 + 2] - d[pb + 2])
            // DOMAIN_MIN/MAX chỉ là miền ĐẦU VÀO (đặc tả Adobe/Iridas); giá trị đầu ra luôn là 0..1 -> 0..255
            val lr = sr * 255f
            val lg = sg * 255f
            val lb = sb * 255f
            out[i] = (p and (255 shl 24)) or
                (clamp(r + (lr - r) * k) shl 16) or
                (clamp(g + (lg - g) * k) shl 8) or
                clamp(b + (lb - b) * k)
        }
        return out
    }

    private fun clamp(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()
}

/** Kho LUT trên máy: `filesDir/luts/<tên>.cube`. Phân tích một lần rồi nhớ (tối đa 4 LUT) — khóa theo tên + thời điểm sửa tệp. */
object LutStore {
    @Volatile var dir: File? = null

    private val NAME_RE = Regex("^[A-Za-z0-9_\\- ]{1,48}\\.cube$")
    private class Entry(val stamp: Long, val lut: Lut3d)
    private val cache = LinkedHashMap<String, Entry>()

    fun isValidName(name: String?): Boolean = name != null && NAME_RE.matches(name)

    /** Đổi tên tệp bất kỳ thành tên hợp lệ (bỏ ký tự lạ, ép đuôi .cube). */
    fun sanitizeName(raw: String): String {
        val base = raw.substringBeforeLast('.', raw).replace(Regex("[^A-Za-z0-9_\\- ]"), "_").trim().take(44)
        return (if (base.isBlank()) "lut" else base) + ".cube"
    }

    @Synchronized
    fun get(rawName: String?): Lut3d? {
        val name: String = rawName ?: return null
        if (!isValidName(name)) return null
        val folder = dir ?: return null
        val f = File(folder, name)
        if (!f.isFile || f.length() > CubeLut.MAX_BYTES) return null
        val stamp = f.lastModified() * 31 + f.length()
        val hit = cache[name]
        if (hit != null && hit.stamp == stamp) return hit.lut
        val res = runCatching { CubeLut.parse(f.readText()) }.getOrNull() ?: return null
        val lut = res.lut ?: return null
        cache[name] = Entry(stamp, lut)
        while (cache.size > 4) cache.remove(cache.keys.first())
        return lut
    }

    fun list(): List<String> =
        dir?.listFiles()?.filter { it.isFile && isValidName(it.name) }?.map { it.name }?.sorted().orEmpty()

    /** Kiểm tra rồi lưu LUT. Trả (tên đã lưu, null) hoặc (null, lỗi). */
    @Synchronized
    fun save(rawName: String, text: String): Pair<String?, String?> {
        val d = dir ?: return Pair(null, "Chưa khởi tạo kho LUT")
        if (text.length > CubeLut.MAX_BYTES) return Pair(null, "Tệp LUT quá lớn")
        val res = CubeLut.parse(text)
        if (res.lut == null) return Pair(null, res.error ?: "LUT không hợp lệ")
        d.mkdirs()
        val name = sanitizeName(rawName)
        File(d, name).writeText(text)
        cache.remove(name)
        return Pair(name, null)
    }

    @Synchronized
    fun delete(name: String) {
        if (!isValidName(name)) return
        File(dir ?: return, name).delete()
        cache.remove(name)
    }
}
