package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * "Filter Gallery" thuần Kotlin (kiểm thử được trên JVM): Posterize, Pixelate, Duotone, Emboss, Sketch, Glow (Orton),
 * Chromatic aberration, Matte (phai đen) và Colorize (đổi màu theo HSL - dùng để nhuộm tóc).
 * Bản port Python kiểm số học: tools/verify_ports/filter_fx.py. Đầu vào/ra là mảng ARGB; alpha luôn giữ nguyên.
 */
object FilterFx {

    private fun rd(p: Int) = (p shr 16) and 255
    private fun gr(p: Int) = (p shr 8) and 255
    private fun bl(p: Int) = p and 255
    private fun pk(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private fun cl(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()

    /** Đọc "#RRGGBB" -> 0xRRGGBB; sai định dạng thì trả [fallback]. */
    fun hexRgb(s: String?, fallback: Int): Int {
        val t = s?.trim().orEmpty()
        if (t.length != 7 || t[0] != '#') return fallback
        return t.substring(1).toIntOrNull(16) ?: fallback
    }

    // ------------------------------------------------------------------ Posterize
    fun posterLevels(v: Float): Int = (16f - v.coerceIn(0f, 1f) * 14f).roundToInt().coerceIn(2, 16)

    fun posterize(px: IntArray, v: Float): IntArray {
        val n = posterLevels(v)
        val lut = IntArray(256) { c -> cl((c / 255f * (n - 1)).roundToInt() * 255f / (n - 1)) }
        return IntArray(px.size) { i ->
            val p = px[i]
            pk(p ushr 24, lut[rd(p)], lut[gr(p)], lut[bl(p)])
        }
    }

    // ------------------------------------------------------------------ Pixelate (mosaic)
    fun pixelBlock(w: Int, h: Int, v: Float): Int = max(2, (v.coerceIn(0f, 1f) * max(w, h) / 20f).roundToInt())

    fun pixelate(px: IntArray, w: Int, h: Int, v: Float): IntArray {
        val bs = pixelBlock(w, h, v)
        val out = IntArray(px.size)
        var by = 0
        while (by < h) {
            val y1 = min(h, by + bs)
            var bx = 0
            while (bx < w) {
                val x1 = min(w, bx + bs)
                var sr = 0; var sg = 0; var sb = 0; var sa = 0
                for (y in by until y1) for (x in bx until x1) {
                    val p = px[y * w + x]
                    sr += rd(p); sg += gr(p); sb += bl(p); sa += p ushr 24
                }
                val cnt = (y1 - by) * (x1 - bx)
                val c = pk(sa / cnt, sr / cnt, sg / cnt, sb / cnt)
                for (y in by until y1) for (x in bx until x1) out[y * w + x] = c
                bx = x1
            }
            by = y1
        }
        return out
    }

    // ------------------------------------------------------------------ Duotone
    const val DUO_SHADOW = 0x20124D
    const val DUO_HIGH = 0xF6C177

    /** arg = "#bóng,#sáng" (mặc định tím đậm → vàng ấm). */
    fun duotone(px: IntArray, v: Float, arg: String?): IntArray {
        val parts = arg?.split(',').orEmpty()
        val sh = hexRgb(parts.getOrNull(0), DUO_SHADOW)
        val hi = hexRgb(parts.getOrNull(1), DUO_HIGH)
        val k = v.coerceIn(0f, 1f)
        return IntArray(px.size) { i ->
            val p = px[i]
            val l = (0.299f * rd(p) + 0.587f * gr(p) + 0.114f * bl(p)) / 255f
            val tr = rd(sh) + (rd(hi) - rd(sh)) * l
            val tg = gr(sh) + (gr(hi) - gr(sh)) * l
            val tb = bl(sh) + (bl(hi) - bl(sh)) * l
            pk(p ushr 24, cl(rd(p) * (1f - k) + tr * k), cl(gr(p) * (1f - k) + tg * k), cl(bl(p) * (1f - k) + tb * k))
        }
    }

    // ------------------------------------------------------------------ Emboss
    private fun grayOf(px: IntArray): FloatArray = FloatArray(px.size) { 0.299f * rd(px[it]) + 0.587f * gr(px[it]) + 0.114f * bl(px[it]) }

    fun emboss(px: IntArray, w: Int, h: Int, v: Float): IntArray {
        val g = grayOf(px)
        val k = v.coerceIn(0f, 1f)
        val out = IntArray(px.size)
        for (y in 0 until h) {
            val ya = max(0, y - 1)
            val yb = min(h - 1, y + 1)
            for (x in 0 until w) {
                val xa = max(0, x - 1)
                val xb = min(w - 1, x + 1)
                val e = 128f + 1.5f * (g[ya * w + xa] - g[yb * w + xb])
                val p = px[y * w + x]
                out[y * w + x] = pk(p ushr 24, cl(rd(p) * (1f - k) + e * k), cl(gr(p) * (1f - k) + e * k), cl(bl(p) * (1f - k) + e * k))
            }
        }
        return out
    }

    // ------------------------------------------------------------------ Sketch (bút chì: Color Dodge của xám với bản mờ của âm bản)
    fun sketch(px: IntArray, w: Int, h: Int, v: Float): IntArray {
        val gray = IntArray(px.size) { grayOf1(px[it]) }
        val inv = IntArray(px.size) { val g = 255 - gray[it]; (255 shl 24) or (g shl 16) or (g shl 8) or g }
        val blurred = Blur.gaussian(inv, w, h, max(2, max(w, h) / 150))
        val k = v.coerceIn(0f, 1f)
        return IntArray(px.size) { i ->
            val b = blurred[i] and 255
            val s = if (b >= 255) 255f else min(255f, gray[i] * 255f / (255 - b))
            val p = px[i]
            pk(p ushr 24, cl(rd(p) * (1f - k) + s * k), cl(gr(p) * (1f - k) + s * k), cl(bl(p) * (1f - k) + s * k))
        }
    }

    private fun grayOf1(p: Int): Int = (0.299f * rd(p) + 0.587f * gr(p) + 0.114f * bl(p) + 0.5f).toInt().coerceIn(0, 255)

    // ------------------------------------------------------------------ Glow (Orton): cộng kiểu Screen bản mờ của chính ảnh
    fun glow(px: IntArray, w: Int, h: Int, v: Float): IntArray {
        val blurred = Blur.gaussian(px, w, h, max(3, max(w, h) / 60))
        val k = v.coerceIn(0f, 1f) * 0.85f
        return IntArray(px.size) { i ->
            val p = px[i]
            val b = blurred[i]
            fun ch(o: Int, bb: Int): Int = cl(255f * (1f - (1f - o / 255f) * (1f - bb / 255f * k)))
            pk(p ushr 24, ch(rd(p), rd(b)), ch(gr(p), gr(b)), ch(bl(p), bl(b)))
        }
    }

    // ------------------------------------------------------------------ Chromatic aberration (lệch kênh đỏ/xanh theo hướng xuyên tâm)
    private fun bilinear(px: IntArray, w: Int, h: Int, fx: Float, fy: Float, shift: Int): Float {
        val x = fx.coerceIn(0f, (w - 1).toFloat())
        val y = fy.coerceIn(0f, (h - 1).toFloat())
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(w - 1, x0 + 1)
        val y1 = min(h - 1, y0 + 1)
        val tx = x - x0
        val ty = y - y0
        fun c(xx: Int, yy: Int): Float = ((px[yy * w + xx] shr shift) and 255).toFloat()
        val top = c(x0, y0) * (1f - tx) + c(x1, y0) * tx
        val bot = c(x0, y1) * (1f - tx) + c(x1, y1) * tx
        return top * (1f - ty) + bot * ty
    }

    fun chroma(px: IntArray, w: Int, h: Int, v: Float): IntArray {
        val s = v.coerceIn(0f, 1f) * max(w, h) * 0.008f
        val cx = (w - 1) / 2f
        val cy = (h - 1) / 2f
        val rMax = sqrt(cx * cx + cy * cy).coerceAtLeast(1f)
        val out = IntArray(px.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val tx = (x - cx) / rMax
                val ty = (y - cy) / rMax
                val p = px[y * w + x]
                val r = bilinear(px, w, h, x - s * tx, y - s * ty, 16)
                val b = bilinear(px, w, h, x + s * tx, y + s * ty, 0)
                out[y * w + x] = pk(p ushr 24, cl(r), gr(p), cl(b))
            }
        }
        return out
    }

    // ------------------------------------------------------------------ Matte (nâng vùng đen -> phai màu)
    fun matte(px: IntArray, v: Float): IntArray {
        val k = v.coerceIn(0f, 1f)
        val lut = IntArray(256) { c -> cl(c * (1f - k) + (36f + c * (219f / 255f)) * k) }
        return IntArray(px.size) { i ->
            val p = px[i]
            pk(p ushr 24, lut[rd(p)], lut[gr(p)], lut[bl(p)])
        }
    }

    // ------------------------------------------------------------------ Colorize (HSL): giữ cấu trúc sáng-tối, thay sắc độ + bão hòa theo màu đích
    private const val COLORIZE_LIFT = 0.45f

    private fun hue2rgb(p: Float, q: Float, t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 0.5f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }

    /** Trả về (h 0..1, s, l) của màu 0xRRGGBB. */
    fun rgbToHsl(r: Int, g: Int, b: Int): FloatArray {
        val rf = r / 255f; val gf = g / 255f; val bf = b / 255f
        val mx = max(rf, max(gf, bf)); val mn = min(rf, min(gf, bf))
        val l = (mx + mn) / 2f
        val d = mx - mn
        if (d < 1e-6f) return floatArrayOf(0f, 0f, l)
        val s = if (l > 0.5f) d / (2f - mx - mn) else d / (mx + mn)
        val h = when {
            mx == rf -> ((gf - bf) / d + (if (gf < bf) 6f else 0f)) / 6f
            mx == gf -> ((bf - rf) / d + 2f) / 6f
            else -> ((rf - gf) / d + 4f) / 6f
        }
        return floatArrayOf(h, s, l)
    }

    fun colorize(px: IntArray, rgb: Int, v: Float): IntArray {
        val k = v.coerceIn(0f, 1f)
        val t = rgbToHsl(rd(rgb), gr(rgb), bl(rgb))
        val th = t[0]; val ts = t[1]; val tl = t[2]
        return IntArray(px.size) { i ->
            val p = px[i]
            val c = rgbToHsl(rd(p), gr(p), bl(p))
            val l2 = (c[2] + (tl - c[2]) * COLORIZE_LIFT).coerceIn(0f, 1f)
            val s2 = ts
            val q = if (l2 < 0.5f) l2 * (1f + s2) else l2 + s2 - l2 * s2
            val pp = 2f * l2 - q
            val nr = hue2rgb(pp, q, th + 1f / 3f) * 255f
            val ng = hue2rgb(pp, q, th) * 255f
            val nb = hue2rgb(pp, q, th - 1f / 3f) * 255f
            pk(p ushr 24, cl(rd(p) * (1f - k) + nr * k), cl(gr(p) * (1f - k) + ng * k), cl(bl(p) * (1f - k) + nb * k))
        }
    }
}
