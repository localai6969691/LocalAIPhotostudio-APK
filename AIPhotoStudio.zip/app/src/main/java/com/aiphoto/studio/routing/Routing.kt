package com.aiphoto.studio.routing

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Định tuyến model theo CẤU HÌNH (JSON), không hardcode: mỗi tác vụ có danh sách nhà cung cấp theo thứ tự ưu tiên,
 * kèm điều kiện (model đã nạp, có API key, đủ RAM...). App thử lần lượt và tự rơi về phương án kế tiếp khi lỗi.
 *
 * Cấu hình lấy theo thứ tự: filesDir/routing.json (người dùng nhập / tải từ URL https) -> assets/routing_default.json.
 * Thêm/đổi nhà cung cấp *đã có code* chỉ cần sửa JSON, không cần phát hành lại app. Kind lạ sẽ bị bỏ qua (tương thích tiến).
 *
 * Kind hiện có code: gemma_mediapipe (= "LLM cục bộ": từ R15 chạy cả .task của MediaPipe lẫn .litertlm của LiteRT-LM, tùy tệp đã nạp), rules, u2net_onnx, lama_onnx, classic_fill, patchmatch_fill (PatchMatch không cần model), gemini_cloud, sd_webui.
 * Kind dự kiến (chưa có code, tự bị bỏ qua): migan_onnx, aot_gan, sd_turbo_qnn, esrgan_onnx, ...
 */
data class ProviderSpec(
    val id: String,
    val kind: String,
    val needs: List<String>,
    val minRamMb: Int,
    val tier: String,
    val params: Map<String, String>
)

data class RoutingConfig(
    val version: Int,
    val tasks: Map<String, List<ProviderSpec>>,
    val perf: Map<String, Map<String, String>> = emptyMap()
)

data class DeviceInfo(
    val ramMb: Int,
    val soc: String,
    val sdk: Int,
    val cores: Int = Runtime.getRuntime().availableProcessors()
) {
    companion object {
        fun read(ctx: Context): DeviceInfo {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE
            return DeviceInfo((mi.totalMem / (1024 * 1024)).toInt(), soc.orEmpty(), Build.VERSION.SDK_INT)
        }
    }
}

object Routing {

    /**
     * R32: tầng BẰNG CHỨNG cho RAM (số đo thật của các lần nạp trước + dấu app bị giết lúc nạp, xem [com.aiphoto.studio.engine.ModelMemory]),
     * áp THÊM vào ngưỡng tay `minRamMb`. Mặc định luôn cho qua (đơn vị test / chưa có app); `MainViewModel` gắn hàm thật khi khởi động.
     */
    @Volatile var memoryGuard: (ProviderSpec) -> Boolean = { true }

    val KNOWN_KINDS = setOf(
        "gemma_mediapipe", "rules", "u2net_onnx", "isnet_onnx", "modnet_onnx", "mp_face_landmarker", "mp_hair_segmenter", "mp_person_detector", "depth_onnx", "lama_onnx", "migan_onnx", "esrgan_onnx", "classic_fill",
        "gemini_cloud", "sd_webui", "proxy_cloud", "sdcpp_local", "patchmatch_fill"
    )

    fun parse(json: String): RoutingConfig {
        val root = JSONObject(json)
        val tasksObj = root.getJSONObject("tasks")
        val map = LinkedHashMap<String, List<ProviderSpec>>()
        for (task in tasksObj.keys()) {
            val arr = tasksObj.getJSONObject(task).getJSONArray("providers")
            val list = ArrayList<ProviderSpec>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val needsArr = o.optJSONArray("needs")
                val needs = ArrayList<String>()
                if (needsArr != null) for (k in 0 until needsArr.length()) needs.add(needsArr.getString(k))
                val params = HashMap<String, String>()
                o.optJSONObject("params")?.let { p ->
                    for (key in p.keys()) params[key] = p.optString(key)
                }
                list.add(
                    ProviderSpec(
                        id = o.getString("id"),
                        kind = o.getString("kind"),
                        needs = needs,
                        minRamMb = o.optInt("minRamMb", 0),
                        tier = o.optString("tier", "free"),
                        params = params
                    )
                )
            }
            map[task] = list
        }
        val perf = HashMap<String, Map<String, String>>()
        root.optJSONObject("perf")?.let { po ->
            for (tier in po.keys()) {
                val t = po.optJSONObject(tier) ?: continue
                val m = HashMap<String, String>()
                for (k in t.keys()) m[k] = t.optString(k)
                perf[tier.lowercase()] = m
            }
        }
        return RoutingConfig(root.optInt("version", 1), map, perf)
    }

    /**
     * Cấu hình đã lưu (đồng bộ từ máy chủ / nhập tay) được ưu tiên, TRỪ khi nó có `version` thấp hơn bản mặc định đi kèm app:
     * khi app thêm model/nhà cung cấp mới thì tăng `version` trong routing_default.json để cấu hình cũ không che mất chúng.
     */
    fun load(ctx: Context): RoutingConfig {
        val default = parse(ctx.assets.open("routing_default.json").bufferedReader().use { it.readText() })
        runCatching {
            val f = File(ctx.filesDir, "routing.json")
            if (f.exists()) {
                val stored = parse(f.readText())
                if (stored.version >= default.version) return stored
                f.delete()
            }
        }
        return default
    }

    /** Kiểm tra cú pháp rồi mới ghi đè cấu hình hiện tại. */
    fun saveValidated(ctx: Context, json: String): RoutingConfig {
        val cfg = parse(json)
        File(ctx.filesDir, "routing.json").writeText(json)
        return cfg
    }

    /** Tải cấu hình từ URL https (giới hạn 256 KB). */
    fun fetch(url: String): String {
        require(url.trim().startsWith("https://")) { "Chỉ chấp nhận địa chỉ https://" }
        val c = URL(url.trim()).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            val code = c.responseCode
            if (code !in 200..299) throw IOException("Máy chủ trả mã $code")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            require(text.length <= 262_144) { "Tệp cấu hình quá lớn" }
            return text
        } finally {
            c.disconnect()
        }
    }

    fun reset(ctx: Context): RoutingConfig {
        File(ctx.filesDir, "routing.json").delete()
        return load(ctx)
    }

    /** Danh sách nhà cung cấp khả dụng cho [task], đúng thứ tự ưu tiên trong cấu hình. */
    fun chain(
        cfg: RoutingConfig,
        task: String,
        device: DeviceInfo,
        userTier: String,
        available: (String) -> Boolean
    ): List<ProviderSpec> =
        cfg.tasks[task].orEmpty().filter { p ->
            p.kind in KNOWN_KINDS &&
                device.ramMb >= p.minRamMb &&
                (p.tier == "free" || userTier == "pro") &&
                p.needs.all(available) &&
                memoryGuard(p)
        }

    /**
     * Lọc chuỗi nhà cung cấp theo ĐỘ KHÓ của việc (0..1, ví dụ [com.aiphoto.studio.engine.InpaintComplexity]):
     * nhà cung cấp khai `params.max_difficulty` thấp hơn độ khó hiện tại bị bỏ (nó chỉ dành cho việc dễ, ví dụ PatchMatch
     * cho vùng xóa nhỏ); không khai thì luôn dùng được. Thứ tự giữ nguyên như trong cấu hình. Nếu lọc xong rỗng thì
     * trả nguyên chuỗi — thà thử còn hơn không có engine nào.
     */
    fun forDifficulty(chain: List<ProviderSpec>, difficulty: Float): List<ProviderSpec> {
        val ok = chain.filter { p ->
            val max = p.params["max_difficulty"]?.toFloatOrNull()
            max == null || difficulty <= max
        }
        return if (ok.isEmpty()) chain else ok
    }

    /** Mô tả để hiển thị cho người dùng: từng tác vụ -> nhà cung cấp nào dùng được / thiếu gì. */
    fun describe(
        cfg: RoutingConfig,
        device: DeviceInfo,
        userTier: String,
        available: (String) -> Boolean
    ): String = buildString {
        append("Thiết bị: RAM ${device.ramMb} MB, ${device.soc.ifBlank { "?" }}, Android SDK ${device.sdk}\n")
        for ((task, providers) in cfg.tasks) {
            append(task).append(": ")
            append(
                providers.joinToString(" → ") { p ->
                    val missing = buildList {
                        if (p.kind !in KNOWN_KINDS) add("chưa hỗ trợ")
                        if (device.ramMb < p.minRamMb) add("RAM<${p.minRamMb}")
                        else if (p.needs.all(available) && !memoryGuard(p)) add("RAM trống không đủ")
                        if (!(p.tier == "free" || userTier == "pro")) add("gói ${p.tier}")
                        p.needs.filterNot(available).forEach { add(it) }
                    }
                    if (missing.isEmpty()) "${p.id} ✓" else "${p.id} ✗(${missing.joinToString(", ")})"
                }
            )
            append('\n')
        }
    }.trimEnd()
}
