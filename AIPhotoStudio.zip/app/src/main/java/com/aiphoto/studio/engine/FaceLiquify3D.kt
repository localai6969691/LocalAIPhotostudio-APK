package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * R37 - LIQUIFY 3D theo "xương" khuôn mặt (3D bone mapping trong tài liệu AI_Photo_Studio nâng cấp).
 *
 * Khác [FaceLiquify] (2D, đối xứng, dùng trục trán-cằm trong ẢNH): ở đây dựng KHUNG ĐẦU 3D (trục ngang u, dọc v, sâu f) từ 478 điểm mốc CÓ z
 * rồi định nghĩa từng chỉnh sửa bằng vector trong khung đầu, sau đó chiếu xuống ảnh. Nhờ vậy:
 *  - xoay đầu (yaw) / ngẩng-cúi (pitch) / nghiêng (roll) đều được xử lý: foreshortening tự đúng, hướng đẩy quay theo roll;
 *  - chỉnh TỪNG BÊN (hàm, mắt) với cổng hiển thị riêng: bên XA camera (dễ bị che) giảm sớm hơn bên GẦN;
 *  - thêm "rút ngắn cằm" và "cân bằng hai bên" (đối xứng quanh mặt phẳng giữa trong 3D);
 *  - chuẩn hóa MẬT ĐỘ nhân (các đoạn đẩy chồng nhau được cộng bởi ToneOps.liquify) -> độ dời thật tại điểm mốc = giá trị ý định;
 *  - bộ bảo vệ GẤP NẾP: đo định thức Jacobian của ánh xạ biến dạng trên lưới thô, tự giảm biên độ nếu < [MIN_DET].
 * Các hằng số K_… và R_… được hiệu chuẩn trên ẢNH THẬT bằng vòng kín (tools/real_face_check.py: warp -> MediaPipe nhận diện lại -> đo; Jacobian > 0,5).
 * Bản tham chiếu Python: tools/verify_ports/face_liquify3d.py (test R37Test so khớp từng đoạn đẩy trên lưới khuôn mặt thật).
 *
 * Mảng điểm mốc: x0,y0,…,x477,y477 (chuẩn hóa 0..1) rồi khối z0..z477 (cùng thước với x, xem HeadPose). Thiếu z -> trả rỗng (dùng [FaceLiquify]).
 * A = bên TRÁI ảnh (x nhỏ, gò má 234), B = bên PHẢI ảnh (gò má 454).
 */
object FaceLiquify3D {
    const val POINTS = 478

    /** Số thanh trượt dáng khuôn mặt trong giao diện (0..3 cơ bản, 4..9 chi tiết 3D từng bên) - khớp MainViewModel.UiState.faceShape. */
    const val SLIDERS = 10

    private const val CHEEK_A = 234
    private const val CHEEK_B = 454
    private const val FOREHEAD = 10
    private const val CHIN = 152
    private val PAIRS_U_A = intArrayOf(234, 127, 93, 132, 58)
    private val PAIRS_U_B = intArrayOf(454, 356, 323, 361, 288)
    private val PAIRS_U_W = doubleArrayOf(1.0, 0.5, 0.5, 0.5, 0.5)
    private val MIDLINE = intArrayOf(10, 151, 9, 8, 168, 6, 197, 195, 5, 4, 1, 19, 94, 2, 164, 0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175, 152)
    private val JAW_A = intArrayOf(93, 132, 58, 172, 136, 150, 149, 176, 148)
    private val JAW_B = intArrayOf(323, 361, 288, 397, 365, 379, 378, 400, 377)
    private val EYE_A = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
    private val EYE_B = intArrayOf(263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249)
    private val NOSE_A = intArrayOf(129, 64, 98)
    private val NOSE_B = intArrayOf(358, 294, 327)
    private val NOSE_W = doubleArrayOf(1.0, 0.5, 0.5)
    private const val MOUTH_A = 61
    private const val MOUTH_B = 291
    private val CHIN_PTS = intArrayOf(152, 175, 199, 148, 377, 176, 400)
    private val CHIN_W = doubleArrayOf(1.0, 0.9, 0.6, 0.6, 0.6, 0.35, 0.35)

    // cặp đối xứng (A, B) + bán kính theo bề rộng mặt ảnh, dùng cho "Cân bằng hai bên"
    private val SYM_A = intArrayOf(33, 133, 159, 145, 70, 105, 66, 107, 129, 61, 234, 93, 58)
    private val SYM_B = intArrayOf(263, 362, 386, 374, 300, 334, 296, 336, 358, 291, 454, 323, 288)
    private val SYM_R = doubleArrayOf(0.09, 0.09, 0.08, 0.08, 0.09, 0.09, 0.09, 0.09, 0.08, 0.09, 0.14, 0.16, 0.16)

    // Hiệu chuẩn trên ảnh thật (xem tools/real_face_check.py). Sau chuẩn hóa mật độ, K_* = độ dời thật ở điểm mốc khi thanh trượt = 1.
    const val K_SLIM = 0.055
    const val K_EYES = 0.120
    const val K_NOSE = 0.040
    const val K_SMILE = 0.030
    const val K_CHIN = 0.050
    const val R_SLIM = 0.32
    const val R_EYE = 0.80
    const val R_NOSE = 0.12
    const val R_SMILE = 0.17
    const val R_CHIN = 0.34
    const val K_BAL = 0.60
    const val BAL_CAP = 0.045
    const val NEAR_FROM = 45.0
    const val NEAR_TO = 80.0
    const val FAR_FROM = 18.0
    const val FAR_TO = 50.0
    const val MIN_FACE_PX = 8.0
    /** Định thức Jacobian nhỏ nhất cho phép của ánh xạ biến dạng (< 0: ảnh bị lật/gấp nếp; ≈ 0: nén cực mạnh). */
    const val MIN_DET = 0.35

    class ShapeParams(
        val slim: Float = 0f, val slimA: Float = 0f, val slimB: Float = 0f,
        val eyes: Float = 0f, val eyesA: Float = 0f, val eyesB: Float = 0f,
        val nose: Float = 0f, val smile: Float = 0f, val chin: Float = 0f, val balance: Float = 0f
    ) {
        val isIdentity: Boolean
            get() = max(slim, max(slimA, slimB)) <= 0.005f && max(eyes, max(eyesA, eyesB)) <= 0.005f &&
                nose <= 0.005f && smile <= 0.005f && chin <= 0.005f && balance <= 0.005f
    }

    /** Một đoạn đẩy theo PIXEL (x, y tâm; dx, dy độ dời; r bán kính). */
    class Seg(val x: Double, val y: Double, val dx: Double, val dy: Double, val r: Double)

    class HeadFrame(
        val px: DoubleArray, val py: DoubleArray,
        val u: DoubleArray, val v: DoubleArray, val f: DoubleArray,
        val a: DoubleArray, val b: DoubleArray,
        val a0: Double, val w3: Double, val h3: Double, val fwImg: Double,
        /** > 0: bên B xa camera hơn. */
        val yawDeg: Double, val pitchDeg: Double, val rollDeg: Double
    )

    private fun smooth(t: Double): Double {
        val c = if (t < 0.0) 0.0 else if (t > 1.0) 1.0 else t
        return c * c * (3 - 2 * c)
    }

    /** Dựng khung đầu 3D. null nếu thiếu z / mặt quá nhỏ / điểm mốc suy biến. */
    fun frame(lm: FloatArray, w: Int, h: Int): HeadFrame? {
        if (w <= 0 || h <= 0 || lm.size < 3 * POINTS) return null
        val n = POINTS
        val px = DoubleArray(n) { lm[2 * it].toDouble() * w }
        val py = DoubleArray(n) { lm[2 * it + 1].toDouble() * h }
        val pz = DoubleArray(n) { lm[2 * n + it].toDouble() * w }
        for (i in 0 until n) if (!px[i].isFinite() || !py[i].isFinite() || !pz[i].isFinite()) return null
        var ux = 0.0; var uy = 0.0; var uz = 0.0
        for (k in PAIRS_U_A.indices) {
            val a = PAIRS_U_A[k]; val b = PAIRS_U_B[k]
            val dx = px[b] - px[a]; val dy = py[b] - py[a]; val dz = pz[b] - pz[a]
            val len = sqrt(dx * dx + dy * dy + dz * dz)
            if (len < 1e-9) return null
            val wt = PAIRS_U_W[k]
            ux += wt * dx / len; uy += wt * dy / len; uz += wt * dz / len
        }
        val un = sqrt(ux * ux + uy * uy + uz * uz)
        if (un < 1e-9) return null
        ux /= un; uy /= un; uz /= un
        val v0x = px[CHIN] - px[FOREHEAD]; val v0y = py[CHIN] - py[FOREHEAD]; val v0z = pz[CHIN] - pz[FOREHEAD]
        val dot = v0x * ux + v0y * uy + v0z * uz
        var vx = v0x - dot * ux; var vy = v0y - dot * uy; var vz = v0z - dot * uz
        val vn = sqrt(vx * vx + vy * vy + vz * vz)
        if (vn < 1e-9) return null
        vx /= vn; vy /= vn; vz /= vn
        val fx = uy * vz - uz * vy; val fy = uz * vx - ux * vz; val fz = ux * vy - uy * vx
        val ox = (px[CHEEK_A] + px[CHEEK_B]) / 2; val oy = (py[CHEEK_A] + py[CHEEK_B]) / 2; val oz = (pz[CHEEK_A] + pz[CHEEK_B]) / 2
        val cdx = px[CHEEK_B] - px[CHEEK_A]; val cdy = py[CHEEK_B] - py[CHEEK_A]; val cdz = pz[CHEEK_B] - pz[CHEEK_A]
        val w3 = sqrt(cdx * cdx + cdy * cdy + cdz * cdz)
        val h3 = sqrt(v0x * v0x + v0y * v0y + v0z * v0z)
        val fwImg = hypot(cdx, cdy)
        if (fwImg < MIN_FACE_PX || w3 < MIN_FACE_PX) return null
        val yaw = Math.toDegrees(atan2(uz, hypot(ux, uy)))
        val pitch = Math.toDegrees(atan2(-vz, hypot(vx, vy)))
        val roll = Math.toDegrees(atan2(uy, ux))
        val a = DoubleArray(n); val b = DoubleArray(n)
        for (i in 0 until n) {
            val rx = px[i] - ox; val ry = py[i] - oy; val rz = pz[i] - oz
            a[i] = rx * ux + ry * uy + rz * uz
            b[i] = rx * vx + ry * vy + rz * vz
        }
        var s = 0.0
        for (i in MIDLINE) s += a[i]
        val a0 = s / MIDLINE.size
        return HeadFrame(px, py, doubleArrayOf(ux, uy, uz), doubleArrayOf(vx, vy, vz), doubleArrayOf(fx, fy, fz), a, b, a0, w3, h3, fwImg, yaw, pitch, roll)
    }

    /** Cổng hiển thị từng bên: trả (gA, gB). yaw > 0: bên B xa camera. Bên GẦN giảm trong [NEAR_FROM, NEAR_TO]°, bên XA giảm sớm hơn trong [FAR_FROM, FAR_TO]°. */
    fun sideGains(yawDeg: Double): DoubleArray {
        val th = kotlin.math.abs(yawDeg)
        val near = 1 - smooth((th - NEAR_FROM) / (NEAR_TO - NEAR_FROM))
        val far = 1 - smooth((th - FAR_FROM) / (FAR_TO - FAR_FROM))
        return if (yawDeg > 0) doubleArrayOf(near, far) else doubleArrayOf(far, near)
    }

    private fun kernel(d: Double, r: Double): Double {
        if (d >= r) return 0.0
        val t = 1.0 - d / r
        return t * t * (3 - 2 * t)
    }

    /** Chia biên độ mỗi đoạn cho tổng trọng số nhân tại chỗ (kể cả chính nó = 1), vì ToneOps.liquify CỘNG các nhân chồng nhau. */
    private fun normalizeGroup(items: List<Seg>): List<Seg> {
        val out = ArrayList<Seg>(items.size)
        for (s in items) {
            var dens = 0.0
            for (o in items) dens += kernel(hypot(s.x - o.x, s.y - o.y), s.r)
            if (dens < 1.0) dens = 1.0
            out.add(Seg(s.x, s.y, s.dx / dens, s.dy / dens, s.r))
        }
        return out
    }

    /** Các đoạn đẩy theo pixel (CHƯA qua bộ bảo vệ gấp nếp). Rỗng nếu không dựng được khung hoặc không có gì để làm. */
    fun segments(lm: FloatArray, w: Int, h: Int, p: ShapeParams): List<Seg> {
        if (p.isIdentity) return emptyList()
        val fr = frame(lm, w, h) ?: return emptyList()
        val g = sideGains(fr.yawDeg)
        val gA = g[0]; val gB = g[1]
        val u = fr.u; val v = fr.v
        val out = ArrayList<Seg>()
        val cur = ArrayList<Seg>()
        fun flush() { out.addAll(normalizeGroup(cur)); cur.clear() }
        fun seg(i: Int, da: Double, db: Double, r: Double) {
            val dx = da * u[0] + db * v[0]
            val dy = da * u[1] + db * v[1]
            if (kotlin.math.abs(dx) + kotlin.math.abs(dy) < 1e-4) return
            cur.add(Seg(fr.px[i], fr.py[i], dx, dy, r))
        }

        val slimA = min(1.0, (p.slim + p.slimA).toDouble()) * gA
        val slimB = min(1.0, (p.slim + p.slimB).toDouble()) * gB
        for (side in 0..1) {
            val ids = if (side == 0) JAW_A else JAW_B
            val amt = if (side == 0) slimA else slimB
            val sgn = if (side == 0) 1.0 else -1.0
            if (amt > 0.005) {
                for (k in ids.indices) {
                    val bell = sin(PI * (k + 0.5) / ids.size)
                    seg(ids[k], sgn * amt * fr.w3 * K_SLIM * bell, 0.0, fr.fwImg * R_SLIM)
                }
                flush()
            }
        }
        for (side in 0..1) {
            val ring = if (side == 0) EYE_A else EYE_B
            val c0 = ring[0]; val c1 = ring[8]                       // hai khóe mắt (33,133 / 263,362)
            val amt = min(1.0, ((if (side == 0) p.eyes + p.eyesA else p.eyes + p.eyesB)).toDouble()) * (if (side == 0) gA else gB)
            if (amt > 0.005) {
                var ca = 0.0; var cb = 0.0
                for (i in ring) { ca += fr.a[i]; cb += fr.b[i] }
                ca /= ring.size; cb /= ring.size
                val ew3 = hypot(fr.a[c0] - fr.a[c1], fr.b[c0] - fr.b[c1])
                val ewImg = hypot(fr.px[c0] - fr.px[c1], fr.py[c0] - fr.py[c1])
                var k = 0
                while (k < ring.size) {
                    val i = ring[k]
                    val da = fr.a[i] - ca; val db = fr.b[i] - cb
                    val n = hypot(da, db)
                    if (n > 1e-6) seg(i, da / n * amt * ew3 * K_EYES, db / n * amt * ew3 * K_EYES, max(4.0, ewImg * R_EYE))
                    k += 2
                }
                flush()
            }
        }
        if (p.nose > 0.005f) {
            for (side in 0..1) {
                val ids = if (side == 0) NOSE_A else NOSE_B
                val sgn = if (side == 0) 1.0 else -1.0
                val gg = if (side == 0) gA else gB
                for (k in ids.indices) seg(ids[k], sgn * p.nose * gg * NOSE_W[k] * fr.w3 * K_NOSE, 0.0, fr.fwImg * R_NOSE)
                flush()
            }
        }
        if (p.smile > 0.005f) {
            seg(MOUTH_A, 0.0, -p.smile * gA * fr.w3 * K_SMILE, fr.fwImg * R_SMILE)
            seg(MOUTH_B, 0.0, -p.smile * gB * fr.w3 * K_SMILE, fr.fwImg * R_SMILE)
            flush()
        }
        if (p.chin > 0.005f) {
            val gg = min(gA, gB)
            for (k in CHIN_PTS.indices) seg(CHIN_PTS[k], 0.0, -p.chin * gg * CHIN_W[k] * fr.h3 * K_CHIN, fr.fwImg * R_CHIN)
            flush()
        }
        if (p.balance > 0.005f) {
            val gg = min(gA, gB) * p.balance * K_BAL
            val cap = BAL_CAP * fr.w3
            for (k in SYM_A.indices) {
                val ia = SYM_A[k]; val ib = SYM_B[k]
                val la = fr.a[ia] - fr.a0; val lb = fr.a[ib] - fr.a0
                val shift = -(la + lb) / 2                           // cả cặp dời cùng một đoạn ngang để tâm cặp nằm trên mặt phẳng giữa
                val dv = (fr.b[ib] - fr.b[ia]) / 2                   // A dời xuống dv, B dời lên dv -> ngang nhau
                for (side in 0..1) {
                    val i = if (side == 0) ia else ib
                    var da = shift * gg
                    var db = (if (side == 0) dv else -dv) * gg
                    val n = hypot(da, db)
                    if (n > cap) { da = da * cap / n; db = db * cap / n }
                    seg(i, da, db, fr.fwImg * SYM_R[k])
                }
            }
            flush()
        }
        return out
    }

    /**
     * Định thức Jacobian nhỏ nhất của ánh xạ ảnh-đích -> ảnh-nguồn (x - d(x)) trên lưới thô (bước ≈ bán kính nhỏ nhất / 4).
     * [scale] nhân mọi độ dời (trường là tuyến tính theo biên độ). 1.0 nếu không có đoạn nào.
     */
    fun minJacobian(segs: List<Seg>, w: Int, h: Int, scale: Double = 1.0): Double {
        if (segs.isEmpty() || w <= 0 || h <= 0) return 1.0
        val long = max(w, h).toDouble()
        var minR = Double.MAX_VALUE
        for (s in segs) minR = min(minR, s.r)
        val step = (minR / 4.0).coerceIn(1.0, long / 100.0)
        val nx = (w / step).toInt() + 1
        val ny = (h / step).toInt() + 1
        val fx = DoubleArray(nx * ny)
        val fy = DoubleArray(nx * ny)
        for (s in segs) {
            val x0 = max(0, ((s.x - s.r) / step).toInt()); val x1 = min(nx - 1, ((s.x + s.r) / step).toInt() + 1)
            val y0 = max(0, ((s.y - s.r) / step).toInt()); val y1 = min(ny - 1, ((s.y + s.r) / step).toInt() + 1)
            for (j in y0..y1) for (i in x0..x1) {
                val wgt = kernel(hypot(i * step - s.x, j * step - s.y), s.r)
                if (wgt > 0.0) {
                    fx[j * nx + i] += s.dx * scale * wgt
                    fy[j * nx + i] += s.dy * scale * wgt
                }
            }
        }
        var minDet = Double.MAX_VALUE
        for (j in 1 until ny - 1) for (i in 1 until nx - 1) {
            val ddxDx = (fx[j * nx + i + 1] - fx[j * nx + i - 1]) / (2 * step)
            val ddxDy = (fx[(j + 1) * nx + i] - fx[(j - 1) * nx + i]) / (2 * step)
            val ddyDx = (fy[j * nx + i + 1] - fy[j * nx + i - 1]) / (2 * step)
            val ddyDy = (fy[(j + 1) * nx + i] - fy[(j - 1) * nx + i]) / (2 * step)
            val det = (1 - ddxDx) * (1 - ddyDy) - ddxDy * ddyDx
            if (det < minDet) minDet = det
        }
        return if (minDet == Double.MAX_VALUE) 1.0 else minDet
    }

    /** Hệ số nhân (0..1] cần áp lên mọi độ dời để định thức Jacobian không dưới [MIN_DET]. 1.0 nếu đã an toàn. */
    fun foldGuardScale(segs: List<Seg>, w: Int, h: Int): Double {
        if (minJacobian(segs, w, h, 1.0) >= MIN_DET) return 1.0
        var lo = 0.0
        var hi = 1.0
        repeat(7) {
            val mid = (lo + hi) / 2
            if (minJacobian(segs, w, h, mid) >= MIN_DET) lo = mid else hi = mid
        }
        return lo
    }

    fun encode(segs: List<Seg>, w: Int, h: Int, scale: Double = 1.0): String {
        val long = max(w, h).toDouble()
        val sb = StringBuilder()
        for (s in segs) {
            if (sb.isNotEmpty()) sb.append(';')
            sb.append(
                String.format(
                    Locale.US, "%.5f,%.5f,%.5f,%.5f,%.5f",
                    s.x / w, s.y / h, s.dx * scale / w, s.dy * scale / h, s.r / long
                )
            )
        }
        return sb.toString()
    }

    /** Chuỗi đoạn đẩy cho phép LIQUIFY (cùng định dạng [FaceLiquify.args]); rỗng nếu không có gì làm / không dựng được khung. Đã qua bộ bảo vệ gấp nếp. */
    fun args(lm: FloatArray, w: Int, h: Int, p: ShapeParams): String {
        val segs = segments(lm, w, h, p)
        if (segs.isEmpty()) return ""
        return encode(segs, w, h, foldGuardScale(segs, w, h))
    }

    /** (gA, gB, yawDeg) để giao diện báo vì sao hiệu ứng nhẹ đi; null nếu không dựng được khung. */
    fun gateInfo(lm: FloatArray, w: Int, h: Int): DoubleArray? {
        val fr = frame(lm, w, h) ?: return null
        val g = sideGains(fr.yawDeg)
        return doubleArrayOf(g[0], g[1], fr.yawDeg)
    }
}
