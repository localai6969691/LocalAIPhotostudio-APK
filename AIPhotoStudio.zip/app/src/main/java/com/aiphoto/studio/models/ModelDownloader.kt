package com.aiphoto.studio.models

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * R43: tải MỘT tệp model qua HTTPS — thuần JVM (không dùng Android) nên kiểm bằng JUnit với máy chủ cục bộ.
 *  - tiếp tục tải: giữ tệp `.part`; lần sau gửi Range "bytes=N-" (GitHub Releases trả 206 + Content-Range sau khi chuyển hướng sang
 *    release-assets.githubusercontent.com; địa chỉ chuyển hướng có chữ ký hết hạn nhanh nên LUÔN xin lại từ địa chỉ gốc);
 *  - máy chủ bỏ qua Range (trả 200) ⇒ tải lại từ đầu; trả 206 lệch vị trí ⇒ xóa `.part` rồi báo lỗi để lần sau tải lại từ đầu;
 *  - kiểm kích thước và SHA-256 của TOÀN BỘ tệp rồi mới đổi tên thành tệp đích (nên không bao giờ có tệp model dở dang ở đích);
 *  - nhiều địa chỉ (bản sao): lỗi mạng / HTTP / SHA-256 sai ở địa chỉ này thì thử địa chỉ kế tiếp;
 *  - kiểm dung lượng trống trước khi tải; hủy giữa chừng thì GIỮ `.part` để tiếp tục.
 */
class ModelDownloader(
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 30_000,
    /** Chỉ để test với máy chủ cục bộ; bản chạy thật chỉ nhận https. */
    private val allowHttp: Boolean = false,
    private val spaceMarginBytes: Long = 64L shl 20
) {
    enum class Err { NETWORK, HTTP, SHA256, SIZE, SPACE, CANCELLED }

    /** [file] khác null = thành công. [detail]: mã HTTP, dung lượng cần (MB) hoặc thông điệp lỗi. */
    class Result(val file: File?, val err: Err?, val detail: String = "") {
        val ok: Boolean get() = file != null
    }

    fun download(
        urls: List<String>,
        dest: File,
        expectedSize: Long,
        expectedSha256: String,
        isCancelled: () -> Boolean = { false },
        onProgress: (done: Long, total: Long) -> Unit = { _, _ -> }
    ): Result {
        dest.absoluteFile.parentFile?.mkdirs()
        if (dest.exists()) {
            if (dest.length() == expectedSize && sha256(dest) == expectedSha256) {
                onProgress(expectedSize, expectedSize)
                return Result(dest, null)
            }
            dest.delete()
        }
        val part = File(dest.path + ".part")
        var last = Result(null, Err.NETWORK, "không có địa chỉ tải")
        for (u in urls) {
            if (isCancelled()) return Result(null, Err.CANCELLED)
            val r = tryUrl(u, part, dest, expectedSize, expectedSha256, isCancelled, onProgress)
            if (r.ok || r.err == Err.CANCELLED || r.err == Err.SPACE) return r
            last = r
        }
        return last
    }

    private fun tryUrl(
        url: String, part: File, dest: File, expectedSize: Long, expectedSha256: String,
        isCancelled: () -> Boolean, onProgress: (Long, Long) -> Unit
    ): Result {
        if (!(url.startsWith("https://") || (allowHttp && url.startsWith("http://")))) return Result(null, Err.HTTP, "địa chỉ không phải https")
        var have = if (part.exists()) part.length() else 0L
        if (have > expectedSize) { part.delete(); have = 0L }
        val free = part.absoluteFile.parentFile?.usableSpace ?: 0L
        val need = expectedSize - have
        if (free < need + spaceMarginBytes) return Result(null, Err.SPACE, ((need + spaceMarginBytes) shr 20).toString())
        var conn: HttpURLConnection? = null
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = connectTimeoutMs
            c.readTimeout = readTimeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "AIPhotoStudio-ModelDownloader/1")
            c.setRequestProperty("Accept-Encoding", "identity")
            if (have > 0L) c.setRequestProperty("Range", "bytes=$have-")
            val code = c.responseCode
            var append = false
            when (code) {
                206 -> {
                    val start = rangeStart(c.getHeaderField("Content-Range"))
                    if (start == have && have > 0L) append = true
                    else { part.delete(); return Result(null, Err.NETWORK, "máy chủ trả đoạn tải lệch vị trí") }
                }
                200 -> have = 0L
                416 -> { part.delete(); return Result(null, Err.NETWORK, "máy chủ từ chối đoạn tải tiếp") }
                else -> return Result(null, Err.HTTP, "HTTP $code")
            }
            c.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = if (append) have else 0L
                    var tick = 0L
                    while (true) {
                        if (isCancelled()) return Result(null, Err.CANCELLED)          // giữ .part để tiếp tục
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.nanoTime()
                        if (now - tick > 150_000_000L) { tick = now; onProgress(done, expectedSize) }
                    }
                }
            }
            val got = part.length()
            if (got < expectedSize) return Result(null, Err.NETWORK, "tải chưa đủ: $got / $expectedSize byte")
            if (got > expectedSize) { part.delete(); return Result(null, Err.SIZE, "$got / $expectedSize byte") }
            if (sha256(part) != expectedSha256) { part.delete(); return Result(null, Err.SHA256) }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) { part.copyTo(dest, overwrite = true); part.delete() }
            onProgress(expectedSize, expectedSize)
            return Result(dest, null)
        } catch (e: IOException) {
            return Result(null, Err.NETWORK, e.message ?: e.javaClass.simpleName)
        } finally {
            conn?.disconnect()
        }
    }

    private fun rangeStart(header: String?): Long {
        // "bytes 200000-599999/600000"
        val m = Regex("bytes\\s+(\\d+)-").find(header ?: return -1L) ?: return -1L
        return m.groupValues[1].toLongOrNull() ?: -1L
    }

    companion object {
        fun sha256(f: File): String {
            val md = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { ins ->
                val buf = ByteArray(1 shl 16)
                while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
