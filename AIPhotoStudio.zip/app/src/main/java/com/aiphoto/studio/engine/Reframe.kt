package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Reframe 2.5D (đổi góc nhìn nhẹ từ MỘT ảnh): dựng độ sâu GIẢ → dịch từng điểm theo độ sâu (cận cảnh dịch nhiều hơn hậu cảnh, như khi máy ảnh đi ngang) →
 * lấp chỗ trống lộ ra sau vật thể bằng màu của NỀN (không phải màu vật thể) → phóng nhẹ để che viền trống. THUẦN Kotlin, không model, kiểm thử được trên JVM.
 *
 * Độ sâu giả ([depthMap], 0 = xa, 1 = gần) không đo được độ sâu thật — chỉ là ba gợi ý đơn giản:
 *  - bầu trời (SkyFx.mask, tham số) ở xa nhất; đường chân trời = hàng cuối cùng còn nhiều trời;
 *  - mặt đất: càng thấp trong ảnh càng gần (rơi dần từ chân trời xuống đáy ảnh, tối đa [GROUND_MAX]);
 *  - chủ thể (mặt nạ của bộ tách nền nếu có) là MỘT tấm phẳng nằm ở độ sâu của chân nó (≥ [SUBJECT_MIN]);
 *  rồi tinh chỉnh bằng bộ lọc dẫn hướng (guided filter) theo độ chói ảnh để cạnh độ sâu bám cạnh ảnh thật (giảm quầng).
 *
 * Phép dịch: điểm nguồn u có độ sâu D(u) chuyển tới u + s·(D(u) − pivot) (s = [shift], pivot = [Depth.focus], độ sâu của chủ thể nên chủ thể đứng yên và nền
 * trượt quanh nó). Hai lượt: (1) "đẩy thuận" CHỈ độ sâu bằng z-buffer (điểm gần thắng) → độ sâu theo tọa độ đích, lấp vết nứt 1–2 điểm ảnh bằng trung bình hai bên;
 * (2) "kéo ngược" MÀU theo độ sâu đích bằng nội suy song tuyến tính (đúng điểm lẻ, không răng cưa); điểm đích không có nguồn là vùng lộ ra ([Frame.hole]) và được
 * lấp bằng push-pull CHỈ từ các điểm không gần hơn nền quanh chỗ trống (điểm quá gần = vật che bị loại khỏi nguồn lấp).
 *
 * R30: nếu đã nạp model đo độ sâu (tùy chọn, vd. Depth Anything V2 Small, Apache-2.0) thì [depthFromField] thay độ sâu giả bằng độ sâu TƯƠNG ĐỐI do model đo
 * (kéo giãn bất biến theo thang bằng [stretch], tinh chỉnh bằng bộ lọc dẫn hướng, chủ thể chỉ giữ [SUBJECT_KEEP] biến thiên bên trong); không có model hoặc model
 * lỗi thì chạy y như R29 bằng [depthMap]. Phần dịch / lấp / phóng dùng chung cho cả hai nguồn độ sâu.
 *
 * Giới hạn: độ sâu giả — mặt đất nghiêng, vật không chạm đất, cảnh không có chủ thể sẽ dịch "sai" so với thật (chỉ có tính thẩm mỹ); chủ thể là tấm phẳng
 * (mặt không tròn khối); vùng lộ ra được lấp mờ (push-pull, không dựng kết cấu mới) nên dịch càng xa càng thấy vệt mờ sau vật thể; không xoay quanh cảnh lớn.
 */
object Reframe {

    // ------------------------------------------------------------------ hằng số tinh chỉnh (ước đoán tay, chỉnh trên cảnh tổng hợp)
    /** Dịch tối đa (điểm ảnh) của điểm cách điểm xoay 1 đơn vị độ sâu = MAX_SHIFT_FRAC × cạnh dài, ở góc 1 và hệ số sâu 1. */
    const val MAX_SHIFT_FRAC = 0.03f
    /** Độ sâu tối đa của nền (mặt đất ở đáy ảnh). */
    const val GROUND_MAX = 0.65f
    /** Độ sâu thấp nhất của chủ thể (chân chủ thể ở chân trời). */
    const val SUBJECT_MIN = 0.62f
    /** Diện tích tối thiểu (tỉ lệ ảnh) để coi là có chủ thể / có trời. */
    const val SUBJECT_MIN_AREA = 0.01f
    const val SKY_MIN_AREA = 0.03f
    /**
     * Chân trời thấp hơn mức này (tỉ lệ chiều cao) ⇒ bỏ qua "trời": ảnh gần như toàn trời không có mặt đất để dốc, và bộ nhận trời (SkyFx) hay nhận NHẦM
     * mặt gỗ / tường / lông thú tông ấm hoặc xanh xám là trời (thấy trên ảnh thật: cốc cà phê trên bàn gỗ, mèo) — khi đó độ sâu theo vị trí còn hơn là phẳng.
     */
    const val SKY_MAX_HORIZON = 0.8f
    /** Phân vị thấp / cao dùng để kéo giãn độ sâu do model đo về 0..1 (bỏ 2 % điểm lạc mỗi đầu). */
    const val FIELD_LO_PCT = 0.02f
    const val FIELD_HI_PCT = 0.98f
    /**
     * Hệ số giữ biến thiên độ sâu bên trong chủ thể KHI KHÔNG BIẾT độ lệch ảnh (gọi [depthFromField] không truyền `shiftPx`) — dự phòng, ước đoán tay.
     * Khi biết độ lệch, hệ số được SUY RA bằng [reliefKeep] từ độ dốc độ sâu thực tế và dung sai khe nứt [MAX_CRACK] (không còn là con số đoán).
     */
    const val SUBJECT_KEEP = 0.25f
    /** Phép đo phân vị độ dốc: số ô của biểu đồ và độ dốc tối đa (độ sâu trên một điểm ảnh) được phân giải; trên mức này gom vào ô cuối. */
    const val GRADIENT_BINS = 4096
    const val GRADIENT_MAX = 0.25f
    const val GRADIENT_PCT = 0.99f
    /** Chênh độ sâu hai bên một khe nứt để coi là vết nứt (cùng một bề mặt) thay vì vùng lộ ra. */
    const val CRACK_TOL = 0.04f
    /** Điểm gần hơn nền quanh chỗ trống quá mức này bị loại khỏi nguồn lấp. */
    const val OCCLUDER_TOL = 0.08f
    /** Độ chênh độ sâu tối thiểu (max − min) để có thị sai đáng kể. */
    const val MIN_DEPTH_RANGE = 0.05f
    /** Dịch (điểm ảnh) nhỏ hơn mức này coi như không đổi. */
    const val MIN_SHIFT_PX = 0.5f
    /** Cạnh dài tối đa khi dựng độ sâu (rồi phóng song tuyến tính về cỡ ảnh) — tiết kiệm bộ nhớ ở máy yếu. */
    const val DEPTH_SIDE = 640
    /** Cạnh dài tối đa (điểm ảnh) khi chạy trong ứng dụng: bộ nhớ đỉnh ƯỚC ≈ 80 byte/điểm ảnh (đếm mảng, chưa đo trên máy thật) nên 1600 × 1200 ≈ 150 MB; ảnh lớn hơn được thu nhỏ rồi phóng kết quả lại. */
    const val WORK_SIDE = 1600
    private const val MAX_FILL_RADIUS = 96
    /** Khe nứt rộng nhất (điểm ảnh) được nội suy. */
    private const val MAX_CRACK = 2

    /** Độ sâu giả (cùng cỡ ảnh, 0..1) + điểm xoay + các cờ cho biết gợi ý nào đã dùng. */
    class Depth(val d: FloatArray, val focus: Float, val hasSubject: Boolean, val hasSky: Boolean, val horizon: Float, val fromModel: Boolean = false)

    /**
     * Độ sâu TƯƠNG ĐỐI do model đo từ MỘT ảnh: [v] cỡ [w]×[h] (thường nhỏ hơn ảnh; khác tỉ lệ ảnh nếu model nhận ảnh đã bị ép vuông), giá trị LỚN = GẦN camera
     * (nghịch đảo độ sâu), thang đo và điểm gốc tùy từng ảnh nên CHƯA dùng thẳng được — phải qua [stretch].
     */
    class Field(val v: FloatArray, val w: Int, val h: Int)

    /**
     * Kết quả dịch: [color], cờ [hole] (không có nguồn), độ sâu đích [dd] (−1 ở chỗ trống) và — nếu có — độ sâu NGUỒN [srcDepth] chưa dịch.
     * [srcDepth] cho [fill] biết nền thật ở quanh chỗ lộ ra ngay cả khi chính chỗ đó (hoặc dải ngoài ảnh) đang trống.
     */
    class Frame(val color: IntArray, val hole: BooleanArray, val dd: FloatArray, val srcDepth: FloatArray? = null)

    /** [px] đã dịch + phóng; [zoom] ≥ 1; [holeFrac] = tỉ lệ điểm trong khung cuối phải lấp vì vùng lộ ra. */
    class Result(val px: IntArray, val zoom: Float, val holeFrac: Float)

    /** Dịch (sx, sy) điểm ảnh cho mỗi 1 đơn vị (độ sâu − điểm xoay). [angleX], [angleY] ∈ [−1, 1], [gain] = hệ số sâu. */
    fun shift(angleX: Float, angleY: Float, gain: Float, w: Int, h: Int): FloatArray {
        val k = MAX_SHIFT_FRAC * max(w, h) * gain.coerceIn(0f, 2f)
        return floatArrayOf(angleX.coerceIn(-1f, 1f) * k, angleY.coerceIn(-1f, 1f) * k)
    }

    // ------------------------------------------------------------------ độ sâu giả
    fun depthMap(px: IntArray, w: Int, h: Int, subject: FloatArray?, sky: FloatArray?): Depth {
        require(px.size == w * h && w > 0 && h > 0)
        val scale = min(1f, DEPTH_SIDE.toFloat() / max(w, h))
        val dw = max(1, (w * scale).roundToInt())
        val dh = max(1, (h * scale).roundToInt())
        val n = dw * dh
        val luma = Resample.areaMap(px, w, h, dw, dh) { 0.299f * ((it shr 16) and 255) + 0.587f * ((it shr 8) and 255) + 0.114f * (it and 255) }
        for (i in 0 until n) luma[i] = luma[i] / 255f
        val sub = if (subject != null && subject.size == w * h) Resample.area(subject, w, h, dw, dh) else null
        val sk = if (sky != null && sky.size == w * h) Resample.area(sky, w, h, dw, dh) else null

        // trời: đủ diện tích mới dùng; chân trời = hàng cuối cùng có ≥ 30 % điểm là trời
        var hasSky = false
        var horizon = 0
        if (sk != null) {
            var cover = 0
            for (i in 0 until n) if (sk[i] > 0.5f) cover++
            if (cover >= SKY_MIN_AREA * n) {
                hasSky = true
                for (y in 0 until dh) {
                    var c = 0
                    for (x in 0 until dw) if (sk[y * dw + x] > 0.5f) c++
                    if (c >= 0.3f * dw) horizon = y + 1
                }
            }
        }
        if (hasSky && horizon > SKY_MAX_HORIZON * dh) { hasSky = false; horizon = 0 }
        fun ground(y: Float): Float = ((y - horizon) / (dh - horizon)).coerceIn(0f, 1f)

        val d = FloatArray(n)
        for (y in 0 until dh) {
            val g = GROUND_MAX * ground(y + 0.5f)
            for (x in 0 until dw) {
                val i = y * dw + x
                d[i] = if (hasSky) g * (1f - sk!![i].coerceIn(0f, 1f)) else g
            }
        }

        // chủ thể: một tấm phẳng ở độ sâu của chân nó (phân vị 98 % theo chiều dọc để bỏ qua điểm lạc)
        var hasSubject = false
        var subjD = 0f
        var subMask: FloatArray? = null
        if (sub != null) {
            var cover = 0
            val rows = IntArray(dh)
            for (y in 0 until dh) for (x in 0 until dw) if (sub[y * dw + x] > 0.5f) { cover++; rows[y]++ }
            if (cover >= SUBJECT_MIN_AREA * n) {
                hasSubject = true
                var acc = 0
                var foot = dh - 1
                val target = ceil(cover * 0.02).toInt()
                for (y in dh - 1 downTo 0) { acc += rows[y]; if (acc >= target) { foot = y; break } }
                subjD = (SUBJECT_MIN + (1f - SUBJECT_MIN) * ground(foot + 0.5f)).coerceIn(SUBJECT_MIN, 1f)
                val sm = FloatArray(n) { sub[it].coerceIn(0f, 1f) }
                subMask = sm
            }
        }

        // nền (trời + mặt đất): lọc dẫn hướng theo độ chói ở cỡ nhỏ rồi phóng về cỡ ảnh
        val r = max(2, max(dw, dh) / 120)
        val bg = guidedFilter(luma, d, dw, dh, r, 4e-3f)
        for (i in 0 until n) bg[i] = bg[i].coerceIn(0f, 1f)
        val full = if (dw == w && dh == h) bg else Resample.bilinear(bg, dw, dh, w, h)
        // chủ thể: mặt nạ cũng được lọc dẫn hướng để bám cạnh ảnh, phóng về cỡ ảnh rồi CẮT NHỊ PHÂN ở 0,5: độ sâu trung gian ở mép sẽ bị đẩy
        // thành những điểm lẻ mang màu chủ thể rơi vào vùng lộ ra (vệt lốm đốm); cạnh nhị phân thì mép sạch (màu vẫn lấy từ ảnh gốc nên không răng cưa màu)
        if (subMask != null) {
            val ms = guidedFilter(luma, subMask, dw, dh, r, 1e-3f)
            for (i in 0 until n) ms[i] = ms[i].coerceIn(0f, 1f)
            val up = if (dw == w && dh == h) ms else Resample.bilinear(ms, dw, dh, w, h)
            for (i in full.indices) {
                if (up[i] > 0.5f) full[i] = subjD
            }
        }
        val focus = if (hasSubject) subjD else {
            var s = 0.0
            for (v in full) s += v
            (s / full.size).toFloat()
        }
        return Depth(full, focus, hasSubject, hasSky, horizon.toFloat() / dh)
    }

    // ------------------------------------------------------------------ độ sâu do model đo (R30)
    /**
     * Hệ số GIỮ độ lồi bên trong chủ thể, SUY RA từ độ dịch ảnh thật thay vì một hằng số đoán. Hai điểm kề nhau trong ảnh nguồn rơi cách nhau thêm
     * `shiftPx · g` điểm ảnh với `g` = độ dốc độ sâu trên một điểm ảnh; khe nứt tới [MAX_CRACK] điểm thì [fillCracks] khép được, nên giữ
     * `k = min(1, MAX_CRACK / (shiftPx · g99))` với g99 = phân vị [GRADIENT_PCT] của độ dốc BÊN TRONG chủ thể (bỏ 1 % dốc nhất — mép tay / tóc — vốn đã do
     * cắt nhị phân xử lý). Nhân độ lồi với k nhân đúng độ dốc với k nên bảo đảm `shiftPx · g99' <= MAX_CRACK` là CHÍNH XÁC. Dịch nhỏ ⇒ k = 1 (giữ nguyên khối),
     * dịch lớn ⇒ k nhỏ (phẳng dần). [inside] là mặt nạ chủ thể cùng cỡ ảnh (> 0,5 = trong). Trả [SUBJECT_KEEP] nếu không đủ điểm để đo (< 100).
     * Phân vị lấy bằng biểu đồ [GRADIENT_BINS] ô trên [0, GRADIENT_MAX] và lấy cận TRÊN của ô nên chỉ lệch về phía an toàn (giữ ít hơn một chút).
     */
    fun reliefKeep(d: FloatArray, inside: FloatArray, w: Int, h: Int, shiftPx: Float): Float {
        if (shiftPx <= 0f || d.size != w * h || inside.size != w * h) return SUBJECT_KEEP
        val hist = IntArray(GRADIENT_BINS)
        var n = 0
        for (y in 0 until h - 1) {
            for (x in 0 until w - 1) {
                val i = y * w + x
                if (inside[i] > 0.5f && inside[i + 1] > 0.5f && inside[i + w] > 0.5f) {
                    val g = max(abs(d[i + 1] - d[i]), abs(d[i + w] - d[i]))
                    hist[min(GRADIENT_BINS - 1, (g / GRADIENT_MAX * GRADIENT_BINS).toInt())]++
                    n++
                }
            }
        }
        if (n < 100) return SUBJECT_KEEP
        val target = GRADIENT_PCT * n
        var acc = 0
        var bin = GRADIENT_BINS - 1
        for (b in 0 until GRADIENT_BINS) {
            acc += hist[b]
            if (acc >= target) { bin = b; break }
        }
        val g99 = (bin + 1) * GRADIENT_MAX / GRADIENT_BINS
        val gap = shiftPx * g99
        return if (gap <= MAX_CRACK) 1f else MAX_CRACK / gap
    }

    /**
     * Kéo giãn độ sâu thô của model về 0..1 bằng hai phân vị [lo], [hi] của chính ảnh đó: kết quả KHÔNG đổi khi nhân thang / dời gốc (a·x + b, a > 0) —
     * đúng bản chất độ sâu tương đối (mỗi ảnh một thang). null nếu rỗng, có giá trị không hữu hạn, hoặc gần như phẳng (không có thị sai để làm).
     */
    fun stretch(v: FloatArray, lo: Float = FIELD_LO_PCT, hi: Float = FIELD_HI_PCT): FloatArray? {
        if (v.isEmpty()) return null
        for (x in v) if (x.isNaN() || x.isInfinite()) return null
        val sorted = v.copyOf()
        sorted.sort()
        val last = sorted.size - 1
        val a = sorted[(lo * last).roundToInt().coerceIn(0, last)]
        val b = sorted[(hi * last).roundToInt().coerceIn(0, last)]
        if (b - a <= 1e-4f * max(max(abs(a), abs(b)), 1f)) return null
        val inv = 1f / (b - a)
        return FloatArray(v.size) { ((v[it] - a) * inv).coerceIn(0f, 1f) }
    }

    /**
     * Dựng [Depth] từ độ sâu do model đo ([field]) thay cho [depthMap]: (1) [stretch] về 0..1 (lớn = gần, cùng chiều với độ sâu giả); (2) đưa về cỡ làm việc
     * (≤ [DEPTH_SIDE]) rồi lọc dẫn hướng theo độ chói để cạnh độ sâu bám cạnh ảnh thật; (3) có chủ thể (mặt nạ [subject], cùng cỡ ảnh) thì điểm xoay = độ sâu
     * trung vị BÊN TRONG chủ thể và biến thiên bên trong chủ thể nhân với [reliefKeep] (suy từ độ dịch `shiftPx` và độ dốc thực tế; không truyền `shiftPx` thì dùng
     * [SUBJECT_KEEP]) để mũi / má không bị kéo rách, mép chủ thể cắt nhị phân như [depthMap];
     * không có chủ thể thì điểm xoay = trung vị cả ảnh. KHÔNG dùng bộ nhận trời: model đã tự đặt trời ở xa, còn bộ nhận trời hay nhận nhầm (xem [SKY_MAX_HORIZON]).
     * Trả null nếu [field] hỏng / phẳng — người gọi quay về [depthMap].
     */
    fun depthFromField(px: IntArray, w: Int, h: Int, field: Field, subject: FloatArray?, shiftPx: Float = 0f): Depth? {
        require(px.size == w * h && w > 0 && h > 0)
        if (field.w <= 0 || field.h <= 0 || field.v.size != field.w * field.h) return null
        val norm = stretch(field.v) ?: return null
        val scale = min(1f, DEPTH_SIDE.toFloat() / max(w, h))
        val dw = max(1, (w * scale).roundToInt())
        val dh = max(1, (h * scale).roundToInt())
        val n = dw * dh
        val luma = Resample.areaMap(px, w, h, dw, dh) { 0.299f * ((it shr 16) and 255) + 0.587f * ((it shr 8) and 255) + 0.114f * (it and 255) }
        for (i in 0 until n) luma[i] = luma[i] / 255f
        val raw = if (field.w >= dw && field.h >= dh) Resample.area(norm, field.w, field.h, dw, dh) else Resample.bilinear(norm, field.w, field.h, dw, dh)
        val r = max(2, max(dw, dh) / 120)
        val smooth = guidedFilter(luma, raw, dw, dh, r, 4e-3f)
        for (i in 0 until n) smooth[i] = smooth[i].coerceIn(0f, 1f)
        val full = if (dw == w && dh == h) smooth.copyOf() else Resample.bilinear(smooth, dw, dh, w, h)

        val sub = if (subject != null && subject.size == w * h) Resample.area(subject, w, h, dw, dh) else null
        var hasSubject = false
        var subjD = 0f
        if (sub != null) {
            var cover = 0
            for (i in 0 until n) if (sub[i] > 0.5f) cover++
            if (cover >= SUBJECT_MIN_AREA * n) {
                hasSubject = true
                val inside = FloatArray(cover)
                var k = 0
                for (i in 0 until n) if (sub[i] > 0.5f) inside[k++] = smooth[i]
                inside.sort()
                subjD = inside[cover / 2]
                val ms = guidedFilter(luma, FloatArray(n) { sub[it].coerceIn(0f, 1f) }, dw, dh, r, 1e-3f)
                for (i in 0 until n) ms[i] = ms[i].coerceIn(0f, 1f)
                val up = if (dw == w && dh == h) ms else Resample.bilinear(ms, dw, dh, w, h)
                val keep = reliefKeep(full, up, w, h, shiftPx)
                for (i in full.indices) {
                    if (up[i] > 0.5f) full[i] = (subjD + keep * (full[i] - subjD)).coerceIn(0f, 1f)
                }
            }
        }
        val focus = if (hasSubject) subjD else {
            val sorted = smooth.copyOf()
            sorted.sort()
            sorted[n / 2]
        }
        return Depth(full, focus, hasSubject, false, 0f, true)
    }

    /** Bộ lọc dẫn hướng (He và cs.): làm mượt [p] nhưng giữ cạnh theo ảnh dẫn [guide] (độ chói 0..1); [r] = bán kính hộp, [eps] = độ nhạy cạnh. */
    internal fun guidedFilter(guide: FloatArray, p: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val n = w * h
        val meanI = boxMean(guide, w, h, r)
        val meanP = boxMean(p, w, h, r)
        val ip = FloatArray(n) { guide[it] * p[it] }
        val ii = FloatArray(n) { guide[it] * guide[it] }
        val corrIp = boxMean(ip, w, h, r)
        val corrI = boxMean(ii, w, h, r)
        val a = FloatArray(n)
        val b = FloatArray(n)
        for (i in 0 until n) {
            val varI = corrI[i] - meanI[i] * meanI[i]
            val cov = corrIp[i] - meanI[i] * meanP[i]
            a[i] = cov / (varI + eps)
            b[i] = meanP[i] - a[i] * meanI[i]
        }
        val ma = boxMean(a, w, h, r)
        val mb = boxMean(b, w, h, r)
        return FloatArray(n) { ma[it] * guide[it] + mb[it] }
    }

    /** Trung bình hộp (2r+1)² có xử lý biên (chia theo số điểm thật có trong cửa sổ). */
    internal fun boxMean(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            var sum = 0.0
            var cnt = 0
            for (x in 0..min(r, w - 1)) { sum += src[row + x]; cnt++ }
            for (x in 0 until w) {
                tmp[row + x] = (sum / cnt).toFloat()
                val add = x + r + 1
                val rem = x - r
                if (add < w) { sum += src[row + add]; cnt++ }
                if (rem >= 0) { sum -= src[row + rem]; cnt-- }
            }
        }
        for (x in 0 until w) {
            var sum = 0.0
            var cnt = 0
            for (y in 0..min(r, h - 1)) { sum += tmp[y * w + x]; cnt++ }
            for (y in 0 until h) {
                out[y * w + x] = (sum / cnt).toFloat()
                val add = y + r + 1
                val rem = y - r
                if (add < h) { sum += tmp[add * w + x]; cnt++ }
                if (rem >= 0) { sum -= tmp[rem * w + x]; cnt-- }
            }
        }
        return out
    }

    /** Lọc cực trị trượt (cửa sổ vuông (2r+1)², tách hai chiều, O(N) bằng hàng đợi hai đầu): [wantMin] = nhỏ nhất, ngược lại lớn nhất. */
    internal fun extremeFilter(src: FloatArray, w: Int, h: Int, r: Int, wantMin: Boolean): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        val dq = IntArray(max(w, h) + 1)
        fun better(a: Float, b: Float) = if (wantMin) a <= b else a >= b
        for (y in 0 until h) {
            val base = y * w
            var head = 0
            var tail = 0
            var next = 0
            for (x in 0 until w) {
                while (next <= min(w - 1, x + r)) {
                    val v = src[base + next]
                    while (tail > head && better(v, src[base + dq[tail - 1]])) tail--
                    dq[tail++] = next
                    next++
                }
                while (dq[head] < x - r) head++
                tmp[base + x] = src[base + dq[head]]
            }
        }
        for (x in 0 until w) {
            var head = 0
            var tail = 0
            var next = 0
            for (y in 0 until h) {
                while (next <= min(h - 1, y + r)) {
                    val v = tmp[next * w + x]
                    while (tail > head && better(v, tmp[dq[tail - 1] * w + x])) tail--
                    dq[tail++] = next
                    next++
                }
                while (dq[head] < y - r) head++
                out[y * w + x] = tmp[dq[head] * w + x]
            }
        }
        return out
    }

    // ------------------------------------------------------------------ dịch theo độ sâu
    internal fun sample(px: IntArray, w: Int, h: Int, cx: Float, cy: Float): Int {
        val fx = cx - 0.5f
        val fy = cy - 0.5f
        val x0 = floor(fx).toInt()
        val y0 = floor(fy).toInt()
        val tx = fx - x0
        val ty = fy - y0
        val xa = x0.coerceIn(0, w - 1); val xb = (x0 + 1).coerceIn(0, w - 1)
        val ya = y0.coerceIn(0, h - 1); val yb = (y0 + 1).coerceIn(0, h - 1)
        val p00 = px[ya * w + xa]; val p10 = px[ya * w + xb]; val p01 = px[yb * w + xa]; val p11 = px[yb * w + xb]
        var out = 0xFF shl 24
        for (ch in 0..2) {
            val sh = 16 - 8 * ch
            val a = ((p00 shr sh) and 255) * (1 - tx) + ((p10 shr sh) and 255) * tx
            val b = ((p01 shr sh) and 255) * (1 - tx) + ((p11 shr sh) and 255) * tx
            out = out or ((a * (1 - ty) + b * ty + 0.5f).toInt().coerceIn(0, 255) shl sh)
        }
        return out
    }

    /**
     * Lấy mẫu song tuyến tính CÓ XÉT ĐỘ SÂU: chỉ trộn các điểm nguồn có độ sâu trong [OCCLUDER_TOL] của độ sâu đích [dt], trọng số chuẩn hóa lại; không điểm nào
     * thỏa thì lấy đúng điểm có độ sâu gần nhất. Không có bước này, điểm nền sát chỗ lộ ra lấy mẫu ở tọa độ lẻ sẽ trộn cả màu CHỦ THỂ bên kia cạnh độ sâu
     * ⇒ viền nhuốm màu chủ thể rồi lan vào vùng lấp (thấy trên ảnh thử với dịch lẻ).
     */
    internal fun sampleDepth(px: IntArray, depth: FloatArray, w: Int, h: Int, cx: Float, cy: Float, dt: Float): Int {
        val fx = cx - 0.5f
        val fy = cy - 0.5f
        val x0 = floor(fx).toInt()
        val y0 = floor(fy).toInt()
        val tx = fx - x0
        val ty = fy - y0
        val xa = x0.coerceIn(0, w - 1); val xb = (x0 + 1).coerceIn(0, w - 1)
        val ya = y0.coerceIn(0, h - 1); val yb = (y0 + 1).coerceIn(0, h - 1)
        val i0 = ya * w + xa; val i1 = ya * w + xb; val i2 = yb * w + xa; val i3 = yb * w + xb
        val e0 = abs(depth[i0] - dt); val e1 = abs(depth[i1] - dt); val e2 = abs(depth[i2] - dt); val e3 = abs(depth[i3] - dt)
        var w0 = if (e0 > OCCLUDER_TOL) 0f else (1 - tx) * (1 - ty)
        var w1 = if (e1 > OCCLUDER_TOL) 0f else tx * (1 - ty)
        var w2 = if (e2 > OCCLUDER_TOL) 0f else (1 - tx) * ty
        var w3 = if (e3 > OCCLUDER_TOL) 0f else tx * ty
        var sum = w0 + w1 + w2 + w3
        if (sum < 1e-6f) {
            // không điểm nào đủ gần độ sâu đích: lấy đúng điểm gần nhất (không trộn)
            var best = e0; w0 = 1f
            if (e1 < best) { best = e1; w0 = 0f; w1 = 1f }
            if (e2 < best) { best = e2; w0 = 0f; w1 = 0f; w2 = 1f }
            if (e3 < best) { w0 = 0f; w1 = 0f; w2 = 0f; w3 = 1f }
            sum = 1f
        }
        val p0 = px[i0]; val p1 = px[i1]; val p2 = px[i2]; val p3 = px[i3]
        var out = 0xFF shl 24
        for (ch in 0..2) {
            val sh = 16 - 8 * ch
            val v = ((p0 shr sh) and 255) * w0 + ((p1 shr sh) and 255) * w1 + ((p2 shr sh) and 255) * w2 + ((p3 shr sh) and 255) * w3
            out = out or ((v / sum + 0.5f).toInt().coerceIn(0, 255) shl sh)
        }
        return out
    }

    /**
     * Lấp một lượt các khe hẹp (1–2 điểm ảnh) của độ sâu đích [dd] (−1 = trống): khe ngang / dọc có hai đầu đều biết và chênh nhau ≤ [CRACK_TOL]
     * (cùng một bề mặt bị kéo giãn) được nội suy tuyến tính; khe giữa hai bề mặt khác nhau (chênh lớn) là vùng lộ ra thật nên để trống. Ghi sau khi quét hết nên
     * kết quả không phụ thuộc thứ tự quét.
     */
    internal fun fillCracks(dd: FloatArray, w: Int, h: Int) {
        val fillIdx = ArrayList<Int>()
        val fillVal = ArrayList<Float>()
        fun scan(i: Int, pos: Int, limit: Int, step: Int): Boolean {
            if (pos == 0 || dd[i - step] < 0f) return false
            var run = 1
            while (run <= MAX_CRACK && pos + run < limit && dd[i + run * step] < 0f) run++
            if (run > MAX_CRACK || pos + run >= limit) return false
            val a = dd[i - step]
            val b = dd[i + run * step]
            if (abs(a - b) > CRACK_TOL) return false
            for (k in 0 until run) { fillIdx.add(i + k * step); fillVal.add(a + (b - a) * (k + 1) / (run + 1)) }
            return true
        }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (dd[i] >= 0f) continue
            if (!scan(i, x, w, 1)) scan(i, y, h, w)
        }
        for (k in fillIdx.indices) dd[fillIdx[k]] = fillVal[k]
    }

    /** Hai lượt [fillCracks]: khe chữ L (một đoạn khe được lấp ở lượt 1 thì đoạn kề nó mới đủ hai đầu để lấp ở lượt 2). */
    internal fun closeCracks(dd: FloatArray, w: Int, h: Int) {
        repeat(2) { fillCracks(dd, w, h) }
    }

    /** Bán kính dải lấp: dịch lớn nhất (điểm ảnh) nhân dải độ sâu = bề rộng lớn nhất của chỗ lộ ra, cộng 2 điểm ảnh dư. */
    internal fun fillRadius(sx: Float, sy: Float, depthRange: Float): Int = ceil(max(abs(sx), abs(sy)) * depthRange).toInt() + 2

    /**
     * Hai lượt dịch (xem KDoc đối tượng): trả về màu đích, cờ "không có nguồn" và độ sâu theo tọa độ đích (−1 ở chỗ trống).
     * Điểm đích có độ sâu nhưng nguồn tương ứng nằm NGOÀI ảnh cũng bị coi là chỗ trống.
     */
    internal fun warp(px: IntArray, w: Int, h: Int, depth: FloatArray, focus: Float, sx: Float, sy: Float): Frame {
        val n = w * h
        val dd = FloatArray(n) { -1f }
        // (1) đẩy thuận độ sâu, điểm gần (độ sâu lớn) thắng
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val d = depth[row + x]
                val e = d - focus
                val ix = floor(x + sx * e + 0.5f).toInt()
                val iy = floor(y + sy * e + 0.5f).toInt()
                if (ix < 0 || iy < 0 || ix >= w || iy >= h) continue
                val j = iy * w + ix
                if (d > dd[j]) dd[j] = d
            }
        }
        // vết nứt (kéo giãn): khe 1–2 điểm ảnh kẹp giữa hai điểm CÙNG bề mặt (ngang hoặc dọc) được nội suy tuyến tính; làm 2 lượt cho khe chữ L
        closeCracks(dd, w, h)
        // (2) kéo ngược màu theo độ sâu đích
        val color = IntArray(n)
        val hole = BooleanArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val d = dd[i]
            if (d < 0f) { hole[i] = true; continue }
            val e = d - focus
            val cx = x + 0.5f - sx * e
            val cy = y + 0.5f - sy * e
            if (cx < 0f || cy < 0f || cx > w || cy > h) { hole[i] = true; dd[i] = -1f; continue }
            color[i] = sampleDepth(px, depth, w, h, cx, cy, d)
        }
        return Frame(color, hole, dd, depth)
    }

    /**
     * Lấp chỗ trống bằng màu NỀN. Nguồn của push-pull chỉ là các điểm (1) nằm trong dải [radius] quanh chỗ trống — điểm xa hơn không nên chi phối
     * màu ở khe hẹp, và nếu để lọt thì màu thân chủ thể "chảy" sang qua các mức thô — và (2) không gần hơn nền quanh đó quá [OCCLUDER_TOL]
     * (nền được tìm trong cửa sổ 2·radius vì từ điểm trong dải tới nền phía bên kia khe có thể dài tới radius + bề rộng khe; đo trên độ sâu nguồn
     * [Frame.srcDepth] khi có, nên chủ thể rộng hơn cửa sổ hay chỗ lộ nằm sát mép ảnh vẫn không bị nhận nhầm là nền).
     * Trả null nếu hầu như không có điểm nào biết.
     */
    internal fun fill(f: Frame, w: Int, h: Int, radius: Int): IntArray? {
        val n = w * h
        var holes = 0
        for (v in f.hole) if (v) holes++
        if (holes == 0) return f.color
        if (holes > 0.99 * n) return null
        val r = radius.coerceIn(2, MAX_FILL_RADIUS)
        // "nền xa nhất quanh đây": lấy từ độ sâu NGUỒN (đủ cả chỗ đang trống) để chủ thể rộng — nền ở bên kia chỗ lộ ra không có điểm nào "biết" trong cửa sổ — vẫn bị nhận là vật che
        val ref = f.srcDepth ?: FloatArray(n) { if (f.hole[it]) 2f else f.dd[it] }
        val farthest = extremeFilter(ref, w, h, 2 * r, true)
        val holeF = FloatArray(n) { if (f.hole[it]) 1f else 0f }
        val nearHole = extremeFilter(holeF, w, h, r, false)
        val src = BooleanArray(n)
        var known = 0
        for (i in 0 until n) {
            src[i] = f.hole[i] || nearHole[i] < 0.5f || f.dd[i] - farthest[i] > OCCLUDER_TOL
            if (!src[i]) known++
        }
        // không còn nguồn nào (vd. mọi điểm gần chỗ trống đều "gần hơn" nền): quay về chỉ loại chỗ trống
        if (known == 0) for (i in 0 until n) src[i] = f.hole[i]
        val filled = ClassicInpaint.pushPull(f.color, src, w, h)
        val out = f.color.copyOf()
        for (i in 0 until n) if (f.hole[i]) out[i] = filled[i]
        return out
    }

    /** Phóng nhẹ để che viền trống: vùng hợp lệ = ảnh trừ dải rộng bằng dịch dương lớn nhất ở mỗi phía; trả (cửa sổ [x0,y0,x1,y1] theo số thực, zoom). */
    internal fun cropWindow(depth: FloatArray, focus: Float, sx: Float, sy: Float, w: Int, h: Int): FloatArray {
        var eMin = Float.MAX_VALUE
        var eMax = -Float.MAX_VALUE
        for (d in depth) { if (d < eMin) eMin = d; if (d > eMax) eMax = d }
        val ax = floatArrayOf(sx * (eMin - focus), sx * (eMax - focus))
        val ay = floatArrayOf(sy * (eMin - focus), sy * (eMax - focus))
        val left = max(0f, max(ax[0], ax[1]))
        val right = max(0f, -min(ax[0], ax[1]))
        val top = max(0f, max(ay[0], ay[1]))
        val bottom = max(0f, -min(ay[0], ay[1]))
        val vw = max(1f, w - left - right)
        val vh = max(1f, h - top - bottom)
        val z = max(1f, max(w / vw, h / vh))
        val ww = w / z
        val wh = h / z
        val x0 = (w / 2f - ww / 2f).coerceIn(left, max(left, w - right - ww))
        val y0 = (h / 2f - wh / 2f).coerceIn(top, max(top, h - bottom - wh))
        return floatArrayOf(x0, y0, x0 + ww, y0 + wh, z)
    }

    /**
     * Dịch + lấp + phóng. null nếu không có gì để làm (dịch < [MIN_SHIFT_PX] điểm ảnh hoặc độ sâu gần như phẳng) hoặc không lấp được.
     * [depth] cùng cỡ ảnh. [holeFrac] tính trong khung cuối (sau khi phóng).
     */
    fun render(px: IntArray, w: Int, h: Int, depth: Depth, sx: Float, sy: Float): Result? {
        require(px.size == w * h && depth.d.size == w * h)
        if (max(abs(sx), abs(sy)) < MIN_SHIFT_PX) return null
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in depth.d) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (hi - lo < MIN_DEPTH_RANGE) return null
        val frame = warp(px, w, h, depth.d, depth.focus, sx, sy)
        val radius = fillRadius(sx, sy, hi - lo)
        val filled = fill(frame, w, h, radius) ?: return null
        val win = cropWindow(depth.d, depth.focus, sx, sy, w, h)
        val z = win[4]
        if (z <= 1.0005f) {
            var c = 0
            for (v in frame.hole) if (v) c++
            return Result(filled, 1f, c.toFloat() / (w * h))
        }
        val out = IntArray(w * h)
        var holes = 0
        for (y in 0 until h) for (x in 0 until w) {
            val cx = win[0] + (x + 0.5f) / z
            val cy = win[1] + (y + 0.5f) / z
            out[y * w + x] = sample(filled, w, h, cx, cy)
            val hx = floor(cx).toInt().coerceIn(0, w - 1)
            val hy = floor(cy).toInt().coerceIn(0, h - 1)
            if (frame.hole[hy * w + hx]) holes++
        }
        return Result(out, z, holes.toFloat() / (w * h))
    }

    /** Câu mô tả cho người dùng. */
    fun describe(angleX: Float, angleY: Float, gain: Float, r: Result, d: Depth): String {
        val parts = ArrayList<String>()
        parts.add("Reframe 2.5D: xoay ngang ${(angleX * 100).roundToInt()}%, dọc ${(angleY * 100).roundToInt()}%, độ sâu ${(gain * 100).roundToInt()}%")
        if (d.fromModel) {
            parts.add(if (d.hasSubject) "độ sâu do model đo (tương đối), xoay quanh chủ thể" else "độ sâu do model đo (tương đối), không thấy chủ thể nên xoay quanh độ sâu giữa của ảnh")
        } else {
            parts.add(if (d.hasSubject) "xoay quanh chủ thể" else "không thấy chủ thể — độ sâu chỉ theo vị trí trong ảnh")
            if (d.hasSky) parts.add("có trời ở xa")
        }
        parts.add("phóng ${"%.2f".format(r.zoom)}× để che viền")
        if (r.holeFrac >= 0.0005f) parts.add("lấp ${"%.1f".format(r.holeFrac * 100)}% chỗ lộ ra sau vật thể (mờ)")
        return parts.joinToString("; ") + "."
    }
}
