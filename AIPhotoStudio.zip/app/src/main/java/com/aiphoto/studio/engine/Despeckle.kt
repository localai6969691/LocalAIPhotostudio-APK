package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * R12 — Xóa BỤI, VẾT XƯỚC và SỢI MẢNH (sợi tóc lạc trên da/nền) kiểu bộ lọc "Dust & Scratches" của Photoshop:
 * điểm ảnh nào lệch khỏi TRUNG VỊ của cửa sổ quanh nó quá ngưỡng thì được thay bằng trung vị; còn lại giữ nguyên.
 * Vật mảnh hơn bán kính (bụi, xước, sợi tóc) biến mất; mảng lớn, cạnh sắc và kết cấu thật đều giữ vì trung vị bảo toàn cạnh.
 *
 * Để nhanh: bước 1 chỉ nghi ngờ các điểm lệch khỏi TRUNG BÌNH hộp nhiều hơn nửa ngưỡng; bước 2 mới tính trung vị
 * (theo độ chói) cho các điểm nghi ngờ rồi lấy điểm ảnh có độ chói bằng trung vị làm màu thay thế (giữ nguyên sắc độ thật).
 * Bản port Python: tools/verify_ports/despeckle.py.
 */
object Despeckle {

    /** Cường độ 0..1 → (bán kính, ngưỡng) theo cỡ ảnh: mạnh = vật to hơn bị xóa + ngưỡng thấp hơn. */
    fun params(w: Int, h: Int, strength: Float): Pair<Int, Int> {
        val s = strength.coerceIn(0f, 1f)
        val longSide = max(w, h)
        val radius = max(1, (longSide / 600f * (1f + 3f * s)).roundToInt()).coerceAtMost(8)
        val threshold = (30f - 20f * s).roundToInt()
        return Pair(radius, threshold)
    }

    private fun lumAt(p: Int): Int = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 151 + (p and 255) * 28) shr 8

    /** Mặt nạ các điểm bị coi là bụi/xước (true) — dùng để kiểm thử và để biết vùng sẽ bị thay. */
    fun detect(px: IntArray, w: Int, h: Int, radius: Int, threshold: Int): BooleanArray {
        val n = w * h
        val flagged = BooleanArray(n)
        if (px.size != n || w < 3 || h < 3 || radius < 1) return flagged
        val lum = IntArray(n) { lumAt(px[it]) }
        val meanBox = boxMean(lum, w, h, radius)
        val suspect = threshold / 2
        val window = IntArray((2 * radius + 1) * (2 * radius + 1))
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (abs(lum[i] - meanBox[i]) <= suspect) continue
            val med = medianAt(lum, w, h, x, y, radius, window)
            if (abs(lum[i] - med) > threshold) flagged[i] = true
        }
        return flagged
    }

    /** Thay các điểm lệch bằng điểm ảnh lân cận có độ chói bằng trung vị. Trả cùng mảng nếu không có gì để sửa. */
    fun apply(px: IntArray, w: Int, h: Int, strength: Float): IntArray {
        if (strength < 0.01f || px.size != w * h || w < 3 || h < 3) return px
        val (radius, threshold) = params(w, h, strength)
        val lum = IntArray(w * h) { lumAt(px[it]) }
        val meanBox = boxMean(lum, w, h, radius)
        val suspect = threshold / 2
        val window = IntArray((2 * radius + 1) * (2 * radius + 1))
        var out: IntArray? = null
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (abs(lum[i] - meanBox[i]) <= suspect) continue
            val med = medianAt(lum, w, h, x, y, radius, window)
            if (abs(lum[i] - med) <= threshold) continue
            val src = nearestWithLum(lum, px, w, h, x, y, radius, med)
            val o = out ?: px.copyOf().also { out = it }
            o[i] = (px[i] and (255 shl 24)) or (src and 0xFFFFFF)
        }
        return out ?: px
    }

    private fun medianAt(lum: IntArray, w: Int, h: Int, x: Int, y: Int, r: Int, buf: IntArray): Int {
        var k = 0
        for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) buf[k++] = lum[yy * w + xx]
        java.util.Arrays.sort(buf, 0, k)
        return buf[k / 2]
    }

    /** Điểm ảnh trong cửa sổ có độ chói gần [target] nhất (ưu tiên điểm gần tâm khi hòa) → màu thay thế có thật trong ảnh. */
    private fun nearestWithLum(lum: IntArray, px: IntArray, w: Int, h: Int, x: Int, y: Int, r: Int, target: Int): Int {
        var best = px[y * w + x]
        var bestD = Int.MAX_VALUE
        for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) {
            val j = yy * w + xx
            val d = abs(lum[j] - target) * 16 + abs(xx - x) + abs(yy - y)
            if (d < bestD) { bestD = d; best = px[j] }
        }
        return best
    }

    /** Trung bình hộp (nguyên), mép lặp lại — tích phân theo hai chiều. */
    private fun boxMean(src: IntArray, w: Int, h: Int, r: Int): IntArray {
        val tmp = IntArray(w * h)
        val win = 2 * r + 1
        for (y in 0 until h) {
            var s = 0
            for (k in -r..r) s += src[y * w + min(max(k, 0), w - 1)]
            tmp[y * w] = s
            for (x in 1 until w) {
                s += src[y * w + min(x + r, w - 1)] - src[y * w + max(x - r - 1, 0)]
                tmp[y * w + x] = s
            }
        }
        val out = IntArray(w * h)
        for (x in 0 until w) {
            var s = 0
            for (k in -r..r) s += tmp[min(max(k, 0), h - 1) * w + x]
            out[x] = s / (win * win)
            for (y in 1 until h) {
                s += tmp[min(y + r, h - 1) * w + x] - tmp[max(y - r - 1, 0) * w + x]
                out[y * w + x] = s / (win * win)
            }
        }
        return out
    }
}
