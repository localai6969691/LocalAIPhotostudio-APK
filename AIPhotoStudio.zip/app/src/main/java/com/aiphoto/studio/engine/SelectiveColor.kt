package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Màu chọn lọc (Selective Color) kiểu Photoshop: chỉnh lượng mực Cyan / Magenta / Vàng / Đen riêng cho từng DẢI MÀU
 * (Đỏ, Vàng, Lục, Lam nhạt, Lam, Hồng tím, Trắng, Trung tính, Đen) mà không động tới các dải khác.
 *
 * Đây là mô phỏng trên CMYK "ngây thơ" (k = 1 - max(R,G,B), không dùng hồ sơ màu ICC) nên KHÔNG trùng từng điểm ảnh với Photoshop,
 * nhưng giữ đúng ngữ nghĩa hai chế độ: Tương đối (đổi theo tỉ lệ lượng mực đang có, ví dụ +10% trên 50% magenta = 55%) và Tuyệt đối
 * (cộng thẳng điểm phần trăm). Thuần Kotlin để kiểm thử; có bản port Python ở tools/verify_ports/selective_color.py.
 *
 * Tham số: 36 số (9 dải x C,M,Y,K, mỗi số -1..1) + tùy chọn số thứ 37 (> 0.5 = Tuyệt đối).
 */
object SelectiveColor {
    const val RANGES = 9
    const val VALUES = RANGES * 4

    /** Tâm sắc độ của 6 dải màu (độ): đỏ, vàng, lục, lam nhạt, lam, hồng tím. */
    private val CENTERS = floatArrayOf(0f, 60f, 120f, 180f, 240f, 300f)

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    fun parse(arg: String?): List<Float>? {
        val v = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: return null
        return if (v.size >= VALUES) v else null
    }

    fun isIdentity(v: List<Float>): Boolean = v.take(VALUES).all { abs(it) < 0.005f }

    /** Trả về ARGB mới, hoặc null nếu tham số sai/đồng nhất (không đổi gì). */
    fun apply(px: IntArray, arg: String?): IntArray? {
        val v = parse(arg) ?: return null
        if (isIdentity(v)) return null
        val absolute = v.size > VALUES && v[VALUES] > 0.5f
        val out = IntArray(px.size)
        val w = FloatArray(RANGES)
        for (i in px.indices) {
            val p = px[i]
            val r = ((p shr 16) and 255) / 255f
            val g = ((p shr 8) and 255) / 255f
            val b = (p and 255) / 255f
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val d = mx - mn
            val k = 1f - mx
            val c: Float
            val m: Float
            val y: Float
            if (mx < 1e-6f) { c = 0f; m = 0f; y = 0f } else { c = (mx - r) / mx; m = (mx - g) / mx; y = (mx - b) / mx }

            val sw = smooth(0.03f, 0.25f, d)
            if (d < 1e-6f) {
                for (j in 0 until 6) w[j] = 0f
            } else {
                val t = when {
                    mx == r -> (g - b) / d
                    mx == g -> (b - r) / d + 2f
                    else -> (r - g) / d + 4f
                }
                val h = 60f * (if (t < 0f) t + 6f else t)
                for (j in 0 until 6) {
                    var diff = abs(h - CENTERS[j])
                    if (diff > 180f) diff = 360f - diff
                    w[j] = max(0f, 1f - diff / 60f) * sw
                }
            }
            val whites = smooth(0.55f, 0.95f, mn)
            val blacks = 1f - smooth(0.12f, 0.45f, mx)
            w[6] = whites
            w[7] = (1f - sw) * (1f - whites) * (1f - blacks)
            w[8] = blacks

            var dC = 0f
            var dM = 0f
            var dY = 0f
            var dK = 0f
            for (j in 0 until RANGES) {
                val wj = w[j]
                if (wj <= 0f) continue
                dC += wj * v[j * 4]
                dM += wj * v[j * 4 + 1]
                dY += wj * v[j * 4 + 2]
                dK += wj * v[j * 4 + 3]
            }
            val c2: Float
            val m2: Float
            val y2: Float
            val k2: Float
            if (absolute) {
                c2 = (c + dC).coerceIn(0f, 1f); m2 = (m + dM).coerceIn(0f, 1f)
                y2 = (y + dY).coerceIn(0f, 1f); k2 = (k + dK).coerceIn(0f, 1f)
            } else {
                c2 = (c * max(0f, 1f + dC)).coerceIn(0f, 1f); m2 = (m * max(0f, 1f + dM)).coerceIn(0f, 1f)
                y2 = (y * max(0f, 1f + dY)).coerceIn(0f, 1f); k2 = (k * max(0f, 1f + dK)).coerceIn(0f, 1f)
            }
            val keep = 1f - k2
            val nr = ((1f - c2) * keep * 255f + 0.5f).toInt().coerceIn(0, 255)
            val ng = ((1f - m2) * keep * 255f + 0.5f).toInt().coerceIn(0, 255)
            val nb = ((1f - y2) * keep * 255f + 0.5f).toInt().coerceIn(0, 255)
            out[i] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }
}
