package com.aiphoto.studio.engine

import android.graphics.Bitmap

fun readPixels(b: Bitmap): IntArray {
    val a = IntArray(b.width * b.height)
    b.getPixels(a, 0, b.width, 0, 0, b.width, b.height)
    return a
}

fun makeBitmap(px: IntArray, w: Int, h: Int): Bitmap {
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, w, 0, 0, w, h)
    return b
}
