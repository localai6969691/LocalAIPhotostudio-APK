package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Xóa vật thể bằng PatchMatch (Barnes 2009) + bỏ phiếu theo kiểu Wexler 2007, chạy đa tỷ lệ (tháp ảnh) — KHÔNG cần model.
 *
 * Khác push-pull của [ClassicInpaint] (chỉ nội suy màu → mờ): PatchMatch *sao chép mảnh ảnh thật* từ vùng đã biết
 * nên giữ được hoa văn, vân, hạt ảnh, và kéo dài đường biên thẳng. Hợp với vật thể nhỏ/vừa trên nền có kết cấu lặp
 * (cỏ, gạch, nước, tường sần). Vật thể lớn trên nền ngữ nghĩa phức tạp (người, mặt, kiến trúc) vẫn nên dùng
 * LaMa/MI-GAN — việc chọn engine theo [InpaintComplexity] do cấu hình định tuyến quyết định.
 *
 * Thuật toán (mỗi mức tháp, từ thô đến mịn):
 *  1. Mảnh nguồn hợp lệ = mảnh (2r+1)² nằm hẳn trong vùng ĐÃ BIẾT (kiểm tra O(1) bằng ảnh tích phân).
 *  2. Mảnh đích = mọi mảnh có chạm vùng trống; khoảng cách = SSD với phần đã biết + ước lượng hiện tại.
 *  3. PatchMatch: lan truyền theo hai chiều quét luân phiên + tìm ngẫu nhiên bán kính giảm dần.
 *  4. Bỏ phiếu: màu mỗi điểm trống = trung bình có trọng số exp(-d/2σ) của mọi mảnh phủ nó. Lặp E–M.
 *  Mức thô nhất khởi tạo bằng push-pull; mỗi mức mịn hơn khởi tạo từ mức thô (NNF + màu phóng to).
 *
 * Xác định (deterministic): bộ sinh số ngẫu nhiên cố định hạt giống → cùng đầu vào cho cùng kết quả (test được).
 * Chi phí tỷ lệ với số điểm trống: mức tháp nào có hơn [maxWorkHolePx] điểm trống chỉ chạy chế độ rẻ (phóng to NNF + chép điểm giữa).
 */
class PatchMatchInpaint(
    private val patchRadius: Int = 3,
    private val maxWorkHolePx: Int = 90_000,
    private val maxCropSide: Int = 1280,
    private val seed: Int = 0x5EED1234,
    /** Số điểm nới vùng trống ra ngoài mặt nạ (nuốt viền lệch/răng cưa). < 0 = tự chọn theo cỡ ảnh. 0 = đúng bằng mặt nạ (mở rộng ảnh). */
    private val growPx: Int = -1,
    /** Bề rộng chuyển mượt ở rìa vùng lấp (điểm). < 0 = tự chọn; 0 = thay hẳn, không hòa với nội dung cũ. */
    private val featherPx: Float = -1f
) : Inpainter {

    /** PatchMatch tự cắt vùng quanh mặt nạ và chạy tháp ảnh nhiều mức nên không cần chia ô (chia ô chỉ thêm đường nối). */
    override val needsTiling: Boolean get() = false

    /** Chế độ chính xác: không nới vùng trống, không hòa mép (cùng cấu hình dùng cho mở rộng ảnh). */
    override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap =
        PatchMatchInpaint(patchRadius, maxWorkHolePx, maxCropSide, seed, growPx = 0, featherPx = 0f).inpaint(src, mask)

    override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap {
        val w = src.width
        val h = src.height
        val px = readPixels(src)
        val out = inpaintPixels(px, w, h, mask)
        return if (out === px) src else makeBitmap(out, w, h)
    }

    /** Lõi thuần mảng (dễ test không cần Bitmap). Trả về CHÍNH [px] nếu mặt nạ rỗng. Mặt nạ: != 0 = vùng cần lấp. */
    fun inpaintPixels(px: IntArray, w: Int, h: Int, mask: ByteArray): IntArray {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (mask[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return px

        val grow = if (growPx >= 0) growPx else max(2, max(w, h) / 400)
        var rawPx = 0
        for (y in minY..maxY) for (x in minX..maxX) if (mask[y * w + x].toInt() != 0) rawPx++
        // vùng ngữ cảnh lấy mảnh nguồn: theo "độ dày" của vùng trống, không theo chiều dài (dây mảnh dài / dải mở rộng không cần cả ảnh)
        val extent = max(min(maxX - minX + 1, maxY - minY + 1), sqrt(rawPx.toFloat()).toInt())
        val margin = max(24, extent) + grow
        val x0 = max(0, minX - margin)
        val y0 = max(0, minY - margin)
        val x1 = min(w, maxX + 1 + margin)
        val y1 = min(h, maxY + 1 + margin)
        val cw = x1 - x0
        val ch = y1 - y0

        // Vùng trống trong khung cắt, nới ra `grow` pixel để nuốt viền mặt nạ bị lệch / khử răng cưa.
        val raw = BooleanArray(cw * ch) { mask[(y0 + it / cw) * w + (x0 + it % cw)].toInt() != 0 }
        val dFromHole = DistanceField.chamfer(raw, cw, ch)
        val hole = BooleanArray(cw * ch) { dFromHole[it] <= grow }
        // Khung ngữ cảnh quá lớn (tốn RAM) thì thu nhỏ nguyên f lần. Chi phí theo số điểm trống KHÔNG làm thu nhỏ nữa:
        // các mức tháp có quá nhiều điểm trống chạy chế độ rẻ (xem refine) nên vẫn giữ chi tiết ở độ phân giải đầy đủ.
        var f = 1
        while (f < 16 && max(cw, ch) / f > maxCropSide) f++

        val ww = (cw + f - 1) / f
        val wh = (ch + f - 1) / f
        val l0 = Level(ww, wh)
        for (y in 0 until wh) {
            for (x in 0 until ww) {
                var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
                var any = false
                for (dy in 0 until f) {
                    val yy = y * f + dy
                    if (yy >= ch) break
                    for (dx in 0 until f) {
                        val xx = x * f + dx
                        if (xx >= cw) break
                        if (hole[yy * cw + xx]) any = true else {
                            val p = px[(y0 + yy) * w + (x0 + xx)]
                            sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                            n++
                        }
                    }
                }
                val i = y * ww + x
                if (any || n == 0) l0.hole[i] = true else {
                    l0.img[3 * i] = sr / n; l0.img[3 * i + 1] = sg / n; l0.img[3 * i + 2] = sb / n
                }
            }
        }

        synthesize(l0)

        // Ghép lại: chỉ điểm trong vùng trống bị thay, chuyển mượt vài pixel ở rìa theo khoảng cách tới vùng đã biết.
        val out = px.copyOf()
        val dKnown = DistanceField.chamfer(BooleanArray(cw * ch) { !hole[it] }, cw, ch)
        val feather = if (featherPx >= 0f) featherPx * (if (f == 1) 1f else f.toFloat()) else if (f == 1) 2f else 1f + f
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                val i = y * cw + x
                if (!hole[i]) continue
                val a = if (feather <= 0f) 1f else min(1f, dKnown[i] / feather)
                val fr: Float; val fg: Float; val fb: Float
                if (f == 1) {
                    val j = 3 * i
                    fr = l0.img[j]; fg = l0.img[j + 1]; fb = l0.img[j + 2]
                } else {
                    val s = l0.sample((x + 0.5f) / f - 0.5f, (y + 0.5f) / f - 0.5f)
                    fr = s[0]; fg = s[1]; fb = s[2]
                }
                val o = px[(y0 + y) * w + (x0 + x)]
                val r = (((o shr 16) and 255) * (1f - a) + fr * a + 0.5f).toInt().coerceIn(0, 255)
                val g = (((o shr 8) and 255) * (1f - a) + fg * a + 0.5f).toInt().coerceIn(0, 255)
                val b = ((o and 255) * (1f - a) + fb * a + 0.5f).toInt().coerceIn(0, 255)
                out[(y0 + y) * w + (x0 + x)] = (o and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
            }
        }
        return out
    }

    // ------------------------------------------------------------------------------------------------ tháp ảnh

    /** Một mức của tháp: ảnh RGB float xen kẽ + cờ vùng trống. NNF chỉ tồn tại trong lúc xử lý mức đó và mức kế tiếp. */
    private class Level(val w: Int, val h: Int) {
        val img = FloatArray(w * h * 3)
        val hole = BooleanArray(w * h)
        var nnfX: IntArray? = null
        var nnfY: IntArray? = null
        var isTarget: BooleanArray? = null

        fun sample(fx: Float, fy: Float): FloatArray {
            val x = fx.coerceIn(0f, (w - 1).toFloat())
            val y = fy.coerceIn(0f, (h - 1).toFloat())
            val xi = min(x.toInt(), w - 1)
            val yi = min(y.toInt(), h - 1)
            val xj = min(xi + 1, w - 1)
            val yj = min(yi + 1, h - 1)
            val tx = x - xi
            val ty = y - yi
            val out = FloatArray(3)
            for (c in 0..2) {
                val a = img[3 * (yi * w + xi) + c] * (1f - tx) + img[3 * (yi * w + xj) + c] * tx
                val b = img[3 * (yj * w + xi) + c] * (1f - tx) + img[3 * (yj * w + xj) + c] * tx
                out[c] = a * (1f - ty) + b * ty
            }
            return out
        }

        fun holeCount(): Int {
            var n = 0
            for (b in hole) if (b) n++
            return n
        }

        fun holeSpan(): Int {
            var minX = w; var minY = h; var maxX = -1; var maxY = -1
            for (y in 0 until h) for (x in 0 until w) if (hole[y * w + x]) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
            return if (maxX < 0) 0 else max(maxX - minX + 1, maxY - minY + 1)
        }
    }

    private fun halve(cur: Level): Level {
        val nw = (cur.w + 1) / 2
        val nh = (cur.h + 1) / 2
        val nl = Level(nw, nh)
        for (y in 0 until nh) {
            for (x in 0 until nw) {
                var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
                var any = false
                for (dy in 0..1) for (dx in 0..1) {
                    val sx = 2 * x + dx
                    val sy = 2 * y + dy
                    if (sx >= cur.w || sy >= cur.h) continue
                    val i = sy * cur.w + sx
                    if (cur.hole[i]) any = true else {
                        sr += cur.img[3 * i]; sg += cur.img[3 * i + 1]; sb += cur.img[3 * i + 2]
                        n++
                    }
                }
                val j = y * nw + x
                if (any || n == 0) nl.hole[j] = true else {
                    nl.img[3 * j] = sr / n; nl.img[3 * j + 1] = sg / n; nl.img[3 * j + 2] = sb / n
                }
            }
        }
        return nl
    }

    private fun synthesize(l0: Level) {
        val levels = ArrayList<Level>()
        levels.add(l0)
        while (levels.size < MAX_LEVELS) {
            val cur = levels.last()
            if (cur.holeSpan() <= COARSE_SPAN || min(cur.w, cur.h) < MIN_COARSE_SIDE) break
            levels.add(halve(cur))
        }
        initialFill(levels.last())
        var prev: Level? = null
        for (li in levels.size - 1 downTo 0) {
            val lv = levels[li]
            if (prev != null) upsampleHole(prev, lv)
            refine(lv, prev, if (li == 0) EM_FINE else EM_COARSE, finest = li == 0, cheap = lv.holeCount() > maxWorkHolePx)
            if (prev != null) { prev.nnfX = null; prev.nnfY = null; prev.isTarget = null }
            prev = lv
        }
        prev?.let { it.nnfX = null; it.nnfY = null; it.isTarget = null }
    }

    /** Mức thô nhất: điền ban đầu bằng push-pull (vùng trống ở đây chỉ vài ô nên rẻ). */
    private fun initialFill(lv: Level) {
        val n = lv.w * lv.h
        val packed = IntArray(n) { i ->
            (255 shl 24) or (lv.img[3 * i].toInt().coerceIn(0, 255) shl 16) or
                (lv.img[3 * i + 1].toInt().coerceIn(0, 255) shl 8) or lv.img[3 * i + 2].toInt().coerceIn(0, 255)
        }
        val filled = ClassicInpaint.pushPull(packed, lv.hole, lv.w, lv.h)
        for (i in 0 until n) if (lv.hole[i]) {
            val p = filled[i]
            lv.img[3 * i] = ((p shr 16) and 255).toFloat()
            lv.img[3 * i + 1] = ((p shr 8) and 255).toFloat()
            lv.img[3 * i + 2] = (p and 255).toFloat()
        }
    }

    private fun upsampleHole(coarse: Level, fine: Level) {
        for (y in 0 until fine.h) for (x in 0 until fine.w) {
            val i = y * fine.w + x
            if (!fine.hole[i]) continue
            val s = coarse.sample((x + 0.5f) / 2f - 0.5f, (y + 0.5f) / 2f - 0.5f)
            fine.img[3 * i] = s[0]; fine.img[3 * i + 1] = s[1]; fine.img[3 * i + 2] = s[2]
        }
    }

    // ------------------------------------------------------------------------------------------------ PatchMatch + bỏ phiếu

    /**
     * [cheap] = mức có quá nhiều điểm trống để chạy đủ E–M (chi phí tỉ lệ số điểm trống): chỉ phóng to NNF từ mức thô, căn lại bằng
     * hai lượt lan truyền + tìm ngẫu nhiên bán kính nhỏ, rồi chép điểm giữa của mảnh nguồn. Chi tiết/hạt vẫn lấy từ ảnh thật ở độ
     * phân giải đầy đủ thay vì bị nhòe như khi chỉ phóng to ảnh đã lấp.
     */
    private fun refine(lv: Level, prev: Level?, emIters: Int, finest: Boolean, cheap: Boolean) {
        val side = 2 * patchRadius + 1
        if (lv.w < side || lv.h < side) return
        val em = Em(lv, patchRadius, seed + lv.w * 31 + lv.h)
        if (em.srcCount == 0 || em.targets.isEmpty()) return
        em.initNnf(prev)
        if (cheap) {
            // NNF phóng to lệch ≤ vài điểm: hai lượt lan truyền + tìm ngẫu nhiên bán kính nhỏ là đủ để căn lại
            em.sweep(forward = true, searchRadius = CHEAP_RADIUS)
            em.sweep(forward = false, searchRadius = CHEAP_RADIUS)
            em.copyCenters()
            lv.nnfX = em.nnfX
            lv.nnfY = em.nnfY
            lv.isTarget = em.isTarget
            return
        }
        for (it in 0 until emIters) {
            if (it > 0) em.recomputeDistances()
            val sweeps = if (prev == null && it == 0) PM_ITERS_FIRST else PM_ITERS
            for (s in 0 until sweeps) em.sweep(forward = s % 2 == 0)
            // Lần bỏ phiếu cuối ở mức mịn nhất dùng trọng số rất nhọn: trung bình mềm làm hạt/vân bị nhòe (giảm độ tương phản).
            if (finest && it == emIters - 1) {
                em.vote(1f)
                for (s in 0 until PM_ITERS) em.sweep(forward = s % 2 == 0)   // chốt lại NNF trên ước lượng đã bỏ phiếu
                em.copyCenters()
            } else em.vote(1f)
        }
        lv.nnfX = em.nnfX
        lv.nnfY = em.nnfY
        lv.isTarget = em.isTarget
    }

    private class Em(val lv: Level, val r: Int, seed: Int) {
        val w = lv.w
        val h = lv.h
        val img = lv.img
        private val iw = w + 1
        private val integ = IntArray(iw * (h + 1))
        val isTarget = BooleanArray(w * h)
        val nnfX = IntArray(w * h)
        val nnfY = IntArray(w * h)
        private val nnfD = FloatArray(w * h)
        val targets: IntArray
        private val srcList: IntArray
        val srcCount: Int
        private var rs = if (seed == 0) 0x1234567 else seed

        init {
            for (y in 0 until h) {
                var row = 0
                for (x in 0 until w) {
                    if (lv.hole[y * w + x]) row++
                    integ[(y + 1) * iw + x + 1] = integ[y * iw + x + 1] + row
                }
            }
            val t = ArrayList<Int>()
            var sc = 0
            val srcTmp = IntArray(max(0, (w - 2 * r) * (h - 2 * r)))
            for (y in r until h - r) for (x in r until w - r) {
                val c = holesIn(x - r, y - r, x + r, y + r)
                if (c > 0) { t.add(y * w + x); isTarget[y * w + x] = true } else srcTmp[sc++] = y * w + x
            }
            targets = t.toIntArray()
            srcList = srcTmp
            srcCount = sc
        }

        private fun holesIn(xa: Int, ya: Int, xb: Int, yb: Int): Int =
            integ[(yb + 1) * iw + xb + 1] - integ[ya * iw + xb + 1] - integ[(yb + 1) * iw + xa] + integ[ya * iw + xa]

        private fun validSrc(x: Int, y: Int): Boolean =
            x >= r && y >= r && x < w - r && y < h - r && holesIn(x - r, y - r, x + r, y + r) == 0

        private fun rnd(bound: Int): Int {
            var s = rs
            s = s xor (s shl 13); s = s xor (s ushr 17); s = s xor (s shl 5)
            rs = s
            return (s ushr 1) % bound
        }

        private fun dist(tx: Int, ty: Int, sx: Int, sy: Int, cutoff: Float): Float {
            var sum = 0f
            val len = (2 * r + 1) * 3
            for (dy in -r..r) {
                var ti = ((ty + dy) * w + tx - r) * 3
                var si = ((sy + dy) * w + sx - r) * 3
                for (k in 0 until len) {
                    val d = img[ti++] - img[si++]
                    sum += d * d
                }
                if (sum >= cutoff) return sum
            }
            return sum
        }

        fun initNnf(prev: Level?) {
            val px = prev?.nnfX
            val py = prev?.nnfY
            val pt = prev?.isTarget
            for (idx in targets) {
                val x = idx % w
                val y = idx / w
                var sx = -1
                var sy = -1
                if (prev != null && px != null && py != null && pt != null) {
                    val pi = min(y / 2, prev.h - 1) * prev.w + min(x / 2, prev.w - 1)
                    if (pt[pi]) {
                        val cx = 2 * px[pi] + (x and 1)
                        val cy = 2 * py[pi] + (y and 1)
                        if (validSrc(cx, cy)) { sx = cx; sy = cy }
                    }
                }
                if (sx < 0) {
                    val s = srcList[rnd(srcCount)]
                    sx = s % w; sy = s / w
                }
                nnfX[idx] = sx; nnfY[idx] = sy
            }
            recomputeDistances()
        }

        fun recomputeDistances() {
            for (idx in targets) nnfD[idx] = dist(idx % w, idx / w, nnfX[idx], nnfY[idx], Float.MAX_VALUE)
        }

        fun sweep(forward: Boolean, searchRadius: Int = Int.MAX_VALUE) {
            val n = targets.size
            val maxR = max(w, h)
            for (k in 0 until n) {
                val idx = if (forward) targets[k] else targets[n - 1 - k]
                val x = idx % w
                val y = idx / w
                var bx = nnfX[idx]
                var by = nnfY[idx]
                var bd = nnfD[idx]
                val step = if (forward) -1 else 1
                // lan truyền từ hai láng giềng đã duyệt
                var j = idx + step
                if (x + step in 0 until w && isTarget[j]) {
                    val cx = nnfX[j] - step
                    val cy = nnfY[j]
                    if (validSrc(cx, cy)) {
                        val d = dist(x, y, cx, cy, bd)
                        if (d < bd) { bd = d; bx = cx; by = cy }
                    }
                }
                j = idx + step * w
                if (y + step in 0 until h && isTarget[j]) {
                    val cx = nnfX[j]
                    val cy = nnfY[j] - step
                    if (validSrc(cx, cy)) {
                        val d = dist(x, y, cx, cy, bd)
                        if (d < bd) { bd = d; bx = cx; by = cy }
                    }
                }
                // tìm ngẫu nhiên quanh nghiệm hiện tại, bán kính giảm một nửa mỗi lần
                var rad = min(maxR, searchRadius)
                val cx0 = bx
                val cy0 = by
                while (rad >= 1) {
                    val cx = cx0 + rnd(2 * rad + 1) - rad
                    val cy = cy0 + rnd(2 * rad + 1) - rad
                    if (validSrc(cx, cy) && (cx != bx || cy != by)) {
                        val d = dist(x, y, cx, cy, bd)
                        if (d < bd) { bd = d; bx = cx; by = cy }
                    }
                    rad = rad shr 1
                }
                nnfX[idx] = bx; nnfY[idx] = by; nnfD[idx] = bd
            }
        }

        /**
         * Lần cuối: mỗi điểm trống lấy ĐÚNG điểm giữa của mảnh nguồn khớp nhất với mảnh đặt tại nó (không trung bình).
         * Trung bình 49 mảnh khác nguồn làm hạt/vân co về màu trung bình (mất ~60% độ tương phản trên kết cấu ngẫu nhiên);
         * sao chép thì giữ nguyên thống kê của kết cấu thật. Tính nhất quán đến từ lan truyền của PatchMatch.
         */
        fun copyCenters() {
            for (idx in targets) {
                if (!lv.hole[idx]) continue
                val si = (nnfY[idx] * w + nnfX[idx]) * 3
                img[3 * idx] = img[si]; img[3 * idx + 1] = img[si + 1]; img[3 * idx + 2] = img[si + 2]
            }
        }

        /** Mỗi điểm trống = trung bình có trọng số của các mảnh nguồn đang phủ nó. */
        fun vote(sharp: Float) {
            val n = targets.size
            val sample = FloatArray(min(n, 1024))
            val stride = max(1, n / sample.size)
            for (k in sample.indices) sample[k] = nnfD[targets[min(n - 1, k * stride)]]
            sample.sort()
            val p75 = max(1f, sample[min(sample.size - 1, sample.size * 3 / 4)])
            val inv = 1f / (2f * p75 * sharp)
            val acc = FloatArray(w * h * 3)
            val ws = FloatArray(w * h)
            for (idx in targets) {
                val x = idx % w
                val y = idx / w
                val sx = nnfX[idx]
                val sy = nnfY[idx]
                val wt = exp(-nnfD[idx] * inv)
                for (dy in -r..r) {
                    for (dx in -r..r) {
                        val ti = (y + dy) * w + x + dx
                        if (!lv.hole[ti]) continue
                        val si = ((sy + dy) * w + sx + dx) * 3
                        acc[3 * ti] += wt * img[si]
                        acc[3 * ti + 1] += wt * img[si + 1]
                        acc[3 * ti + 2] += wt * img[si + 2]
                        ws[ti] += wt
                    }
                }
            }
            for (i in 0 until w * h) {
                if (lv.hole[i] && ws[i] > 1e-12f) {
                    img[3 * i] = acc[3 * i] / ws[i]
                    img[3 * i + 1] = acc[3 * i + 1] / ws[i]
                    img[3 * i + 2] = acc[3 * i + 2] / ws[i]
                }
            }
        }
    }

    private companion object {
        const val MAX_LEVELS = 7
        const val COARSE_SPAN = 21
        const val MIN_COARSE_SIDE = 32
        const val EM_COARSE = 4
        const val EM_FINE = 2
        const val PM_ITERS = 3
        const val PM_ITERS_FIRST = 6
        const val CHEAP_RADIUS = 4
    }
}
