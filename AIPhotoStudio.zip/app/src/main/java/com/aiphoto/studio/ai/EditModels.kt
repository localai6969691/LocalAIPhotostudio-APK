package com.aiphoto.studio.ai

import java.util.Locale
import kotlin.math.roundToInt

/**
 * Các phép chỉnh sửa mà "bộ não" AI (LLM hoặc bộ quy tắc) có thể yêu cầu.
 * value:
 *  - signed (-1..1): BRIGHTNESS, CONTRAST, SATURATION, WARMTH
 *  - 0..1 : các phép còn lại có scalable = true
 *  - ROTATE: số độ (90/180/270), CROP_RATIO: rộng/cao, UPSCALE: hệ số (2..4)
 */
enum class OpType(
    val key: String,
    val label: String,
    val scalable: Boolean,
    val signed: Boolean = false
) {
    BRIGHTNESS("brightness", "Độ sáng", true, true),
    CONTRAST("contrast", "Tương phản", true, true),
    SATURATION("saturation", "Bão hòa màu", true, true),
    WARMTH("warmth", "Tông ấm/lạnh", true, true),
    SHADOWS("shadows", "Nâng vùng tối", true),
    SHARPEN("sharpen", "Làm nét", true),
    BLUR("blur", "Làm mờ", true),
    SKIN_SMOOTH("skin_smooth", "Làm mịn da", true),
    VIGNETTE("vignette", "Vignette", true),
    SEPIA("sepia", "Sepia", true),
    CINEMATIC("cinematic", "Tông điện ảnh", true),
    AUTO_ENHANCE("auto_enhance", "Tự động cải thiện", true),
    BG_BLUR("bg_blur", "Làm mờ phông", true),
    GRAYSCALE("grayscale", "Đen trắng", false),
    BG_REMOVE("bg_remove", "Tách nền", false),
    ROTATE("rotate", "Xoay", false),
    FLIP_H("flip_h", "Lật ngang", false),
    FLIP_V("flip_v", "Lật dọc", false),
    CROP_RATIO("crop_ratio", "Cắt tỉ lệ", false),
    UPSCALE("upscale", "Phóng to", false),
    CURVES("curves", "Đường cong (Curves)", false),   // arg = "m:x,y;x,y|r:..|g:..|b:.."
    LEVELS("levels", "Levels", false),                // arg = "đen,trắng,gamma"
    HSL("hsl", "HSL theo màu", false),                // arg = 24 số: 8 dải màu x (sắc độ, bão hòa, sáng)
    CLARITY("clarity", "Độ rõ nét cục bộ", true, true),
    GRAIN("grain", "Hạt film", true),
    FREQ_SEP("freq_sep", "Retouch da (tách tần số)", true),
    DENOISE("denoise", "Khử nhiễu", true),
    COLOR_BALANCE("color_balance", "Cân bằng màu", false),   // arg = 9 số: (bóng, giữa, sáng) x (đỏ, lục, lam)
    MOTION_BLUR("motion_blur", "Mờ chuyển động", true),      // value = độ dài, arg = góc (độ)
    RADIAL_BLUR("radial_blur", "Mờ xuyên tâm", true),
    COLOR_MATCH("color_match", "Khớp màu ảnh mẫu", false),   // arg = CDF 3x256 byte (base64) của ảnh mẫu
    LIQUIFY("liquify", "Liquify", false),                    // arg = "x,y,dx,dy,r;..." chuẩn hóa theo ảnh
    STRAIGHTEN("straighten", "Chỉnh thẳng", false),          // value = độ (-45..45), tự cắt viền trống
    HUE("hue", "Sắc độ", true),                             // value -1..1 = xoay ±180° (HSV, giữ bão hòa và độ sáng)
    LENS_FLARE("lens_flare", "Lens flare", true),            // value = cường độ, arg = "x,y" vị trí nguồn sáng chuẩn hóa 0..1
    SELECTIVE_COLOR("selective_color", "Màu chọn lọc (CMYK)", false), // arg = 36 số (9 dải x C,M,Y,K) [+ số 37: 1 = Tuyệt đối]
    PERSPECTIVE("perspective", "Phối cảnh", false),          // arg = "dọc,ngang" (-1..1), lấy hình thang trong ảnh kéo thành chữ nhật
    POSTERIZE("posterize", "Posterize", true),               // value 0..1 -> 16..2 mức mỗi kênh
    PIXELATE("pixelate", "Pixel hóa (mosaic)", true),        // value 0..1 -> kích thước khối
    DUOTONE("duotone", "Duotone", true),                     // arg = "#bóng,#sáng" (tùy chọn)
    EMBOSS("emboss", "Nổi khối (Emboss)", true),
    SKETCH("sketch", "Phác họa bút chì", true),
    GLOW("glow", "Phát sáng (Orton)", true),
    CHROMA("chroma", "Lệch màu (Chromatic)", true),
    MATTE("matte", "Matte (phai đen)", true),
    COLORIZE("colorize", "Đổi màu (Colorize)", true),        // arg = "#RRGGBB" màu đích (giữ sáng-tối); value = cường độ
    HIGHLIGHTS("highlights", "Vùng sáng", true, true),       // value -1..1: âm = cứu vùng cháy sáng, dương = làm sáng thêm
    VIBRANCE("vibrance", "Vibrance (màu thông minh)", true, true), // tăng nhiều ở màu nhạt, bảo vệ tông da
    TINT("tint", "Sắc thái xanh lá ↔ tím", true, true),       // value > 0 ngả tím (magenta), < 0 ngả xanh lá; giữ độ chói
    DEHAZE("dehaze", "Khử sương mù", true, true),            // value > 0 khử sương (Dark Channel Prior), < 0 thêm sương
    TEXTURE("texture", "Kết cấu (Texture)", true, true),     // chi tiết mịn; < 0 làm mịn kết cấu
    DUST("dust", "Xóa bụi & xước", true),                    // value 0..1 = cường độ (bán kính + ngưỡng của bộ lọc trung vị)
    SKY_REPLACE("sky_replace", "Thay bầu trời", true),
    SKY_RELIGHT("sky_relight", "Khớp ánh sáng tiền cảnh", true),  // value 0..1; chỉ có tác dụng cùng SKY_REPLACE (đất ấm/tối theo trời mới)       // arg = trời mẫu (blue/sunset/dusk/overcast/night), value = cường độ 0..1
    LUT("lut", "LUT màu (.cube)", true),                     // arg = tên tệp trong kho LUT (LutStore), value = cường độ 0..1
    MESH_WARP("mesh_warp", "Biến dạng lưới (Warp)", false),
    SPLIT_TONE("split_tone", "Chia tông (vùng sáng/tối)", false), // arg = "hueBóng,satBóng,hueSáng,satSáng,balance" (hue 0..360°, sat 0..1, balance -1..1); xem engine/SplitTone.kt
    OUTPAINT("outpaint", "Mở rộng ảnh", false),             // phép "bake": nới khung rồi lấp phần mới; arg = "l=0.2,r=0.2,t=0,b=0" hoặc "ratio=1.7778[,a=r]" (xem engine/Outpaint.kt)
    UNBLUR("unblur", "Làm nét lại (khử nhòe)", true),        // phép "bake" (R25): value 0..1 = mức khôi phục; arg = PSF "g:σ" hoặc "m:độ_dài,góc" (chia theo cạnh dài; bỏ trống = tự ước lượng); xem engine/Deblur.kt
    MOIRE("moire", "Khử moiré", true),                       // phép "bake" (R25): value 0..1 = phần vân bị trừ (lọc khuyết đỉnh phổ FFT); xem engine/Moire.kt
    STYLE("style", "Phong cách tranh", true),                // R25: arg = "oil" | "cartoon" | "watercolor"; value 0..1 = hòa với ảnh gốc; xem engine/Stylize.kt
    HAIR_VOLUME("hair_volume", "Tóc phồng", true);          // value 0..1 = độ phồng (tối đa 2% cạnh dài); phép "bake": cần model tóc, đổi điểm ảnh nền  // arg = "gx,gy;dx,dy,..." độ dời chuẩn hóa của (gx+1)*(gy+1) nút (4 góc = Free Transform)

    companion object {
        fun fromKey(key: String): OpType? {
            val k = key.trim().lowercase(Locale.ROOT).replace('-', '_').replace(' ', '_')
            return values().firstOrNull { it.key == k }
        }
    }
}

data class EditOp(val type: OpType, val value: Float = 1f, val arg: String? = null) {

    fun scaled(k: Float): EditOp = if (type.scalable) copy(value = value * k) else this

    fun describe(): String = when (type) {
        OpType.GRAYSCALE, OpType.FLIP_H, OpType.FLIP_V, OpType.CURVES, OpType.LEVELS, OpType.HSL,
        OpType.COLOR_BALANCE, OpType.COLOR_MATCH, OpType.LIQUIFY, OpType.SELECTIVE_COLOR, OpType.MESH_WARP -> type.label
        OpType.STRAIGHTEN -> "${type.label} ${String.format(Locale.US, "%.1f", value)}°"
        OpType.PERSPECTIVE -> type.label
        OpType.OUTPAINT -> "${type.label}: ${com.aiphoto.studio.engine.Outpaint.describe(arg)}"
        OpType.SPLIT_TONE -> com.aiphoto.studio.engine.SplitTone.parse(arg)?.let { p ->
            val parts = ArrayList<String>()
            if (p.highSat >= 0.005f) parts.add("sáng ${p.highHue.roundToInt()}° ${(p.highSat * 100).roundToInt()}%")
            if (p.shadowSat >= 0.005f) parts.add("tối ${p.shadowHue.roundToInt()}° ${(p.shadowSat * 100).roundToInt()}%")
            "${type.label}: ${parts.joinToString(", ")}"
        } ?: type.label
        OpType.LUT -> "LUT ${arg?.removeSuffix(".cube").orEmpty()} ${(value * 100).roundToInt()}%"
        OpType.SKY_REPLACE -> {
            val own = com.aiphoto.studio.engine.SkyStore.nameFromArg(arg)
            "Thay trời: ${if (own != null) "ảnh của tôi (${own.removeSuffix(".jpg")})" else com.aiphoto.studio.engine.SkyFx.label(arg ?: "blue")} ${(value * 100).roundToInt()}%"
        }
        OpType.ROTATE -> "${type.label} ${value.roundToInt()}°"
        OpType.CROP_RATIO -> "${type.label} ${String.format(Locale.US, "%.2f", value)}" + if (com.aiphoto.studio.engine.AutoFrame.parseArg(arg) != null) " (Auto Frame)" else ""
        OpType.UPSCALE -> "${type.label} x${value.roundToInt()}"
        OpType.STYLE -> "${type.label}: ${com.aiphoto.studio.engine.Stylize.label(arg)} ${(value * 100).roundToInt()}%"
        OpType.UNBLUR -> "${type.label} ${(value * 100).roundToInt()}%" + (arg?.let { com.aiphoto.studio.engine.Deblur.parse(it) }?.let { " (" + com.aiphoto.studio.engine.Deblur.describe(arg) + ")" } ?: "")
        OpType.BG_REMOVE ->
            "${type.label} → ${if (arg == null || arg == "transparent") "trong suốt" else arg}"
        else -> {
            val pct = (value * 100).roundToInt()
            val sign = if (type.signed && pct > 0) "+" else ""
            "${type.label} $sign$pct%"
        }
    }
}

/** Vùng áp dụng của một nhóm phép chỉnh trong kế hoạch ("agent" lập kế hoạch cục bộ: da, mắt, răng, bầu trời, chủ thể…). */
object Scope {
    const val SKIN = "skin"
    const val EYES = "eyes"
    const val TEETH = "teeth"
    const val DARK_CIRCLES = "dark_circles"
    const val SKY = "sky"
    const val SUBJECT = "subject"
    const val BACKGROUND = "background"
    /** Dodge & Burn tự động trên da mặt: vùng SÁNG của da được nâng thêm, vùng TỐI được đào sâu thêm → mặt nổi khối. */
    const val FACE_LIGHT = "face_light"
    const val FACE_SHADOW = "face_shadow"
    /** Tóc: mặt nạ từ MediaPipe Hair Segmenter (hair_segmenter.tflite). */
    const val HAIR = "hair"

    val ALL = setOf(SKIN, EYES, TEETH, DARK_CIRCLES, SKY, SUBJECT, BACKGROUND, FACE_LIGHT, FACE_SHADOW, HAIR)

    /**
     * R27: vùng BẢO VỆ ("giữ nguyên X"): chuỗi `not:<vùng>[+<vùng>…]` = phần NGOÀI hợp các vùng đó. Chỉ dùng cho [AdjustmentLayer.scope]
     * (và công thức); mặt nạ dựng bởi MainViewModel.maskForScope. Xem [ProtectIntent].
     */
    const val NOT_PREFIX = "not:"

    /** Chuỗi vùng bảo vệ cho các vùng [scopes] hợp lệ (không trùng, theo thứ tự); không có vùng hợp lệ nào ⇒ null. */
    fun protect(scopes: Collection<String>): String? {
        val ok = scopes.filter { it in ALL }.distinct()
        return if (ok.isEmpty()) null else NOT_PREFIX + ok.joinToString("+")
    }

    fun isProtect(scope: String): Boolean = scope.startsWith(NOT_PREFIX)

    /** Các vùng được bảo vệ trong chuỗi `not:…`; chuỗi không phải vùng bảo vệ hoặc có phần không hợp lệ ⇒ danh sách rỗng. */
    fun protectedOf(scope: String): List<String> {
        if (!isProtect(scope)) return emptyList()
        val parts = scope.removePrefix(NOT_PREFIX).split('+')
        return if (parts.isNotEmpty() && parts.all { it in ALL }) parts.distinct() else emptyList()
    }

    /** Vùng hợp lệ: vùng thường hoặc vùng bảo vệ đúng cú pháp. */
    fun valid(scope: String): Boolean = scope in ALL || protectedOf(scope).isNotEmpty()

    /** Vùng cần nhận diện khuôn mặt (MediaPipe Face Landmarker). */
    fun needsFace(scope: String): Boolean =
        if (isProtect(scope)) protectedOf(scope).any { needsFace(it) }
        else scope == SKIN || scope == EYES || scope == TEETH || scope == DARK_CIRCLES || scope == FACE_LIGHT || scope == FACE_SHADOW

    fun label(scope: String): String = when (scope) {
        SKIN -> "Da mặt"
        EYES -> "Mắt"
        TEETH -> "Răng"
        DARK_CIRCLES -> "Quầng thâm"
        SKY -> "Bầu trời"
        SUBJECT -> "Chủ thể"
        BACKGROUND -> "Nền"
        FACE_LIGHT -> "Nổi khối: vùng sáng"
        FACE_SHADOW -> "Nổi khối: vùng tối"
        HAIR -> "Tóc"
        else -> if (isProtect(scope) && protectedOf(scope).isNotEmpty()) "Trừ " + protectedOf(scope).joinToString(", ") { label(it).lowercase() } else scope
    }
}

data class ScopedOps(val scope: String, val ops: List<EditOp>)

data class EditPlan(
    val ops: List<EditOp>,
    val source: String,
    val notes: List<String> = emptyList(),
    /** Các nhóm phép chỉnh chỉ áp dụng cho một vùng (mỗi nhóm thành một lớp có mặt nạ riêng). */
    val scoped: List<ScopedOps> = emptyList()
) {
    fun scaled(k: Float): EditPlan =
        copy(ops = ops.map { it.scaled(k) }, scoped = scoped.map { s -> s.copy(ops = s.ops.map { it.scaled(k) }) })
}

/** Gộp, ép giá trị hợp lệ, bỏ vùng lạ/rỗng và gộp các nhóm cùng vùng. */
fun normalizeScoped(list: List<ScopedOps>): List<ScopedOps> {
    val byScope = LinkedHashMap<String, MutableList<EditOp>>()
    for (s in list) {
        if (!Scope.valid(s.scope)) continue
        byScope.getOrPut(s.scope) { ArrayList() }.addAll(s.ops)
    }
    return byScope.mapNotNull { (scope, ops) ->
        val clean = mergeOps(ops).mapNotNull { it.sanitized() }
        if (clean.isEmpty()) null else ScopedOps(scope, clean)
    }
}

private val HEX_COLOR = Regex("^#[0-9a-fA-F]{6}$")

private fun normalizeColorArg(arg: String?): String {
    val a = arg?.trim().orEmpty()
    if (HEX_COLOR.matches(a)) return a.uppercase(Locale.ROOT)
    return when (a.lowercase(Locale.ROOT)) {
        "white", "trang", "trắng" -> "#FFFFFF"
        "black", "den", "đen" -> "#000000"
        "blue", "xanh" -> "#2D6CDF"
        "red", "do", "đỏ" -> "#D32F2F"
        "green" -> "#2E9E57"
        "gray", "grey", "xam", "xám" -> "#9E9E9E"
        else -> "transparent"
    }
}

/** Ép giá trị về khoảng hợp lệ; trả về null nếu phép chỉnh vô nghĩa (≈ 0). */
fun EditOp.sanitized(): EditOp? = when (type) {
    OpType.BRIGHTNESS, OpType.CONTRAST, OpType.SATURATION, OpType.WARMTH, OpType.CLARITY, OpType.HUE,
    OpType.HIGHLIGHTS, OpType.VIBRANCE, OpType.TINT, OpType.DEHAZE, OpType.TEXTURE -> {
        val v = value.coerceIn(-1f, 1f)
        if (kotlin.math.abs(v) < 0.01f) null else copy(value = v, arg = null)
    }
    OpType.CURVES, OpType.LEVELS, OpType.HSL, OpType.COLOR_BALANCE, OpType.COLOR_MATCH, OpType.LIQUIFY ->
        if (arg.isNullOrBlank()) null else copy(value = 1f)
    OpType.LENS_FLARE -> {
        val v = value.coerceIn(0f, 1f)
        val xy = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }
        val x = (xy?.getOrNull(0) ?: 0.78f).coerceIn(0f, 1f)
        val y = (xy?.getOrNull(1) ?: 0.2f).coerceIn(0f, 1f)
        if (v < 0.01f) null else copy(value = v, arg = String.format(Locale.US, "%.3f,%.3f", x, y))
    }
    OpType.SKY_REPLACE -> {
        val v = value.coerceIn(0f, 1f)
        if (v < 0.01f) null else copy(value = v, arg = arg?.takeIf { it in com.aiphoto.studio.engine.SkyFx.PRESETS || com.aiphoto.studio.engine.SkyStore.nameFromArg(it) != null } ?: "blue")
    }
    OpType.LUT -> {
        val v = value.coerceIn(0f, 1f)
        if (v < 0.01f || !com.aiphoto.studio.engine.LutStore.isValidName(arg)) null else copy(value = v)
    }
    OpType.COLORIZE -> {
        val v = value.coerceIn(0f, 1f)
        val c = arg?.trim().orEmpty()
        if (v < 0.01f || !HEX_COLOR.matches(c)) null else copy(value = v, arg = c.uppercase(Locale.ROOT))
    }
    OpType.DUOTONE -> {
        val v = value.coerceIn(0f, 1f)
        val parts = arg?.split(',')?.map { it.trim() }.orEmpty()
        val ok = parts.size == 2 && parts.all { HEX_COLOR.matches(it) }
        if (v < 0.01f) null else copy(value = v, arg = if (ok) parts.joinToString(",") { it.uppercase(Locale.ROOT) } else null)
    }
    OpType.MESH_WARP -> {
        val m = com.aiphoto.studio.engine.MeshWarp.parse(arg)
        if (m == null || com.aiphoto.studio.engine.MeshWarp.isIdentity(m)) null else copy(value = 1f)
    }
    OpType.SELECTIVE_COLOR -> {
        val v = com.aiphoto.studio.engine.SelectiveColor.parse(arg)
        if (v == null || com.aiphoto.studio.engine.SelectiveColor.isIdentity(v)) null else copy(value = 1f)
    }
    OpType.MOTION_BLUR -> {
        val v = value.coerceIn(0f, 1f)
        if (v < 0.01f) null else copy(value = v, arg = arg?.takeIf { it.toFloatOrNull() != null } ?: "0")
    }
    OpType.PERSPECTIVE -> {
        val kv = com.aiphoto.studio.engine.Keystone.parse(arg)
        if (kv == null || (kotlin.math.abs(kv.first) < 0.01f && kotlin.math.abs(kv.second) < 0.01f)) null
        else copy(value = 1f, arg = String.format(Locale.US, "%.3f,%.3f", kv.first, kv.second))
    }
    OpType.OUTPAINT -> com.aiphoto.studio.engine.Outpaint.canonical(arg)?.let { copy(value = 1f, arg = it) }
    OpType.SPLIT_TONE -> com.aiphoto.studio.engine.SplitTone.canonical(arg)?.let { copy(value = 1f, arg = it) }
    OpType.STRAIGHTEN -> {
        val v = value.coerceIn(-45f, 45f)
        if (kotlin.math.abs(v) < 0.05f) null else copy(value = v, arg = null)
    }
    OpType.GRAYSCALE, OpType.FLIP_H, OpType.FLIP_V -> copy(value = 1f, arg = null)
    OpType.ROTATE -> {
        val d = (((value / 90f).roundToInt() * 90) % 360 + 360) % 360
        if (d == 0) null else copy(value = d.toFloat(), arg = null)
    }
    OpType.CROP_RATIO ->
        if (value.isNaN()) null else copy(value = value.coerceIn(0.2f, 5f), arg = com.aiphoto.studio.engine.AutoFrame.normalizeArg(arg))
    OpType.UPSCALE -> copy(value = value.roundToInt().coerceIn(2, 4).toFloat(), arg = null)
    OpType.STYLE -> {
        val v = value.coerceIn(0f, 1f)
        val s = com.aiphoto.studio.engine.Stylize.canonical(arg)
        if (v < 0.01f || s == null) null else copy(value = v, arg = s)
    }
    OpType.UNBLUR -> {
        val v = value.coerceIn(0f, 1f)
        if (v < 0.01f) null else copy(value = v, arg = com.aiphoto.studio.engine.Deblur.canonical(arg))
    }
    OpType.BG_REMOVE -> copy(value = 1f, arg = normalizeColorArg(arg))
    else -> {
        val v = value.coerceIn(0f, 1f)
        if (v < 0.01f) null else copy(value = v, arg = if (arg == "reduce") "reduce" else null)
    }
}

/** Gộp các phép trùng loại (cộng giá trị với phép có thể scale, phép còn lại lấy cái sau cùng). */
fun mergeOps(ops: List<EditOp>): List<EditOp> {
    val result = LinkedHashMap<Pair<OpType, Boolean>, EditOp>()
    for (op in ops) {
        val key = Pair(op.type, op.arg == "reduce")
        val prev = result[key]
        // đổi màu / duotone: hai phép khác màu không cộng gộp được -> lấy phép sau cùng
        val replace = op.type == OpType.COLORIZE || op.type == OpType.DUOTONE || op.type == OpType.LUT || op.type == OpType.SKY_REPLACE || op.type == OpType.STYLE
        // chia tông: "highlight màu cam" và "shadow màu xanh" nằm ở hai mệnh đề riêng -> gộp hai nửa thành một phép
        val splitMerged = if (op.type == OpType.SPLIT_TONE && prev != null) {
            val a = com.aiphoto.studio.engine.SplitTone.parse(prev.arg)
            val b = com.aiphoto.studio.engine.SplitTone.parse(op.arg)
            if (a != null && b != null) op.copy(arg = com.aiphoto.studio.engine.SplitTone.format(com.aiphoto.studio.engine.SplitTone.merge(a, b))) else null
        } else null
        result[key] =
            splitMerged ?: if (prev != null && op.type.scalable && !replace) prev.copy(value = prev.value + op.value) else op
    }
    return result.values.toList()
}
