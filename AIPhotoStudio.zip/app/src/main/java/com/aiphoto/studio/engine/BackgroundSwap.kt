package com.aiphoto.studio.engine

import kotlin.math.max

/**
 * Thay nền bằng cảnh tạo sinh mà GIỮ NGUYÊN chủ thể (PDF: "thay nền thành bãi biển"):
 *  1. [backgroundMask]: vùng NỀN (chủ thể do model tách nền cho) nới sát vào chủ thể vài điểm để nuốt viền cũ → đưa cho dịch vụ sinh ảnh.
 *  2. [composite]: ghép lại chủ thể GỐC đè lên ảnh nền mới theo matte mềm — dịch vụ sinh ảnh dù có làm lệch nhẹ cả khung,
 *     điểm ảnh lõi của chủ thể vẫn nguyên vẹn.
 * Thuần mảng, không phụ thuộc Android/model cụ thể.
 */
object BackgroundSwap {

    /** Nền nếu tỉ lệ chủ thể ngoài khoảng này thì không có gì để thay / không tin được kết quả tách. */
    const val MIN_SUBJECT = 0.01f
    const val MAX_SUBJECT = 0.95f

    fun subjectCoverage(fg: FloatArray): Float {
        var n = 0
        for (v in fg) if (v >= 0.5f) n++
        return n / fg.size.toFloat()
    }

    /** Điểm nền = chủ thể < 0,5, nới thêm [grow] điểm vào phía chủ thể. 255 = cần sinh. */
    fun backgroundMask(fg: FloatArray, w: Int, h: Int, grow: Int): ByteArray {
        val bg = BooleanArray(w * h) { fg[it] < 0.5f }
        if (grow <= 0) return ByteArray(w * h) { if (bg[it]) 255.toByte() else 0 }
        val d = DistanceField.chamfer(bg, w, h)             // khoảng cách tới điểm nền gần nhất
        return ByteArray(w * h) { if (d[it] <= grow) 255.toByte() else 0 }
    }

    /**
     * Matte mềm 0..1: LÕI chủ thể = điểm cách nền hơn [choke] điểm (đúng phần bù của [backgroundMask] cùng giá trị) rồi làm mờ [feather] điểm.
     * Nhờ thu vào trong [choke] điểm, viền cũ lẫn màu nền gốc (quầng sáng) nằm hẳn trong vùng được vẽ lại, không rò sang ảnh cuối.
     */
    fun matte(fg: FloatArray, w: Int, h: Int, choke: Int, feather: Int): FloatArray {
        val d = DistanceField.chamfer(BooleanArray(w * h) { fg[it] < 0.5f }, w, h)   // khoảng cách tới điểm nền gần nhất
        val hard = IntArray(w * h) { i -> if (d[i] > choke) -1 else (255 shl 24) }   // trắng = giữ gốc, đen = lấy ảnh sinh
        val soft = if (feather >= 1) Blur.gaussian(hard, w, h, feather) else hard
        return FloatArray(w * h) { (soft[it] and 255) / 255f }
    }

    /** Ảnh cuối = matte·gốc + (1−matte)·ảnh có nền mới. Alpha lấy từ ảnh gốc. [choke] phải bằng [grow] đã dùng cho [backgroundMask]. */
    fun composite(original: IntArray, generated: IntArray, fg: FloatArray, w: Int, h: Int, choke: Int, feather: Int): IntArray {
        val a = matte(fg, w, h, choke, feather)
        val out = IntArray(w * h)
        for (i in out.indices) {
            val o = original[i]
            val g = generated[i]
            val t = a[i]
            if (t >= 0.999f) { out[i] = o; continue }
            if (t <= 0.001f) { out[i] = (o and (0xFF shl 24)) or (g and 0xFFFFFF); continue }
            val r = (((o shr 16) and 255) * t + ((g shr 16) and 255) * (1f - t) + 0.5f).toInt().coerceIn(0, 255)
            val gr = (((o shr 8) and 255) * t + ((g shr 8) and 255) * (1f - t) + 0.5f).toInt().coerceIn(0, 255)
            val b = ((o and 255) * t + (g and 255) * (1f - t) + 0.5f).toInt().coerceIn(0, 255)
            out[i] = (o and (0xFF shl 24)) or (r shl 16) or (gr shl 8) or b
        }
        return out
    }

    /** Điểm cạnh matte, số điểm nới/hòa theo cỡ ảnh (không cố định theo thiết bị). */
    fun growFor(w: Int, h: Int): Int = max(2, max(w, h) / 300)
    fun featherFor(w: Int, h: Int): Int = max(1, growFor(w, h) / 3)
}
