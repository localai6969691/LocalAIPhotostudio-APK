package com.aiphoto.studio.util

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Mã hóa các bí mật lưu trong SharedPreferences (khóa API Gemini, token máy chủ) bằng AES-256-GCM với khóa nằm trong
 * Android Keystore (khóa không rời khỏi chip bảo mật, không xuất ra được). Định dạng lưu: "enc1:" + Base64(IV 12 byte + bản mã).
 *
 * - Giá trị cũ chưa mã hóa (không có tiền tố) vẫn đọc được để di chuyển sang dạng mã hóa ở lần đọc đầu.
 * - Nếu Keystore hỏng trên một số máy (lỗi hiếm) thì [encrypt] trả về nguyên văn để không mất khóa của người dùng.
 * - Sao lưu tự động có thể khôi phục bản mã sang máy mới nơi không còn khóa Keystore -> [decrypt] trả chuỗi rỗng,
 *   người dùng chỉ cần nhập lại khóa.
 */
object SecretStore {
    private const val ALIAS = "aiphoto_secret_v1"
    private const val PROVIDER = "AndroidKeyStore"
    private const val PREFIX = "enc1:"
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128

    fun isEncrypted(s: String): Boolean = s.startsWith(PREFIX)

    @Synchronized
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        if (plain.isEmpty() || isEncrypted(plain)) return plain
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            PREFIX + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (e: Throwable) {
            plain
        }
    }

    /** Giải mã; chuỗi không có tiền tố (dữ liệu cũ) trả về nguyên văn; lỗi giải mã trả về chuỗi rỗng. */
    fun decrypt(stored: String): String {
        if (!isEncrypted(stored)) return stored
        return try {
            val raw = Base64.decode(stored.substring(PREFIX.length), Base64.NO_WRAP)
            if (raw.size <= IV_BYTES) return ""
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, raw, 0, IV_BYTES))
            String(c.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Throwable) {
            ""
        }
    }
}
