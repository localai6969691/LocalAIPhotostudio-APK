package com.aiphoto.studio.models

/** R44: loại mạng đang dùng, theo cách hệ điều hành phân loại (không tự đoán "Wi-Fi" bằng tên giao thức). */
enum class NetKind {
    /** Có Internet và KHÔNG tính cước (Wi-Fi thường, Ethernet, gói di động không giới hạn mà hệ điều hành đánh dấu không tính cước). */
    UNMETERED,

    /** Có Internet nhưng tính cước (dữ liệu di động, Wi-Fi phát từ điện thoại khác — hệ điều hành đánh dấu có tính cước). */
    METERED,

    /** Không có mạng dùng được. */
    OFFLINE
}

/**
 * R44: quy tắc "chỉ tải bằng Wi-Fi" — thuần Kotlin (không Android) nên kiểm được bằng JUnit.
 *
 * Vì sao dựa vào "không tính cước" mà không dựa vào "giao thức Wi-Fi": một điểm phát Wi-Fi từ điện thoại khác vẫn là Wi-Fi nhưng tính cước
 * theo gói di động của người cho mượn; ngược lại một số gói di động không giới hạn được hệ điều hành đánh dấu không tính cước. Cờ
 * `NET_CAPABILITY_NOT_METERED` là cách Android khuyên dùng để quyết định có tải tệp lớn hay không.
 */
object NetworkPolicy {
    /** Phân loại từ hai cờ của `NetworkCapabilities`: có `NET_CAPABILITY_INTERNET` và có `NET_CAPABILITY_NOT_METERED`. */
    fun classify(hasInternet: Boolean, notMetered: Boolean): NetKind = when {
        !hasInternet -> NetKind.OFFLINE
        notMetered -> NetKind.UNMETERED
        else -> NetKind.METERED
    }

    /**
     * Có được tải ngay lúc này không.
     * @param wifiOnly cài đặt "Chỉ tải bằng Wi-Fi" (mạng không tính cước)
     * @param allowMeteredNow người dùng vừa bấm "Tải bằng dữ liệu di động lần này" (chỉ hiệu lực cho đợt tải hiện tại)
     */
    fun allows(wifiOnly: Boolean, allowMeteredNow: Boolean, kind: NetKind): Boolean = when (kind) {
        NetKind.OFFLINE -> false
        NetKind.UNMETERED -> true
        NetKind.METERED -> !wifiOnly || allowMeteredNow
    }

    /** Lý do đang chờ (để giao diện / thông báo nói đúng): null = không phải chờ. */
    fun waitReason(wifiOnly: Boolean, allowMeteredNow: Boolean, kind: NetKind): Wait? = when {
        allows(wifiOnly, allowMeteredNow, kind) -> null
        kind == NetKind.OFFLINE -> Wait.NETWORK
        else -> Wait.WIFI
    }

    enum class Wait {
        /** Chờ mạng không tính cước vì đang bật "Chỉ Wi-Fi" mà chỉ có dữ liệu di động. */
        WIFI,

        /** Không có mạng. */
        NETWORK
    }
}
