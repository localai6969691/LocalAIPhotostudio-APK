package com.aiphoto.studio.ai

/** Hội thoại nhiều lượt: câu ngắn kiểu "nhẹ hơn", "mạnh hơn", "bớt đi" điều chỉnh lớp AI gần nhất. */
object Refine {
    private val LESS = listOf("bot", "nhe hon", "it hon", "giam bot", "nhe nhe", "qua roi", "less", "subtle", "too much", "weaker")
    private val MORE = listOf("manh hon", "nhieu hon", "dam hon", "ro hon", "more", "stronger", "tang them")

    /** 0.6 = giảm ~40%, 1.4 = tăng ~40%, null = không phải câu tinh chỉnh. */
    fun factor(prompt: String): Float? {
        val t = GenIntent.fold(prompt)
        if (t.isEmpty() || t.split(' ').size > 5) return null
        if (LESS.any { t.contains(it) }) return 0.6f
        if (MORE.any { t.contains(it) }) return 1.4f
        return null
    }
}
