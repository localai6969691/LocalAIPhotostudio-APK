package com.aiphoto.studio.ai

/**
 * Bộ sinh văn bản của LLM cục bộ - tách khỏi [LlmPlanner] để đổi backend (MediaPipe LLM Inference <-> LiteRT-LM) mà không đụng
 * logic prompt/JSON. Lớp triển khai tự lo MẪU HỘI THOẠI của model (Gemma .task: bọc <start_of_turn>; .litertlm: model tự áp mẫu),
 * nên [generate] nhận NỘI DUNG THUẦN. Phải đóng được ([close]) để trả RAM.
 */
interface TextGen : AutoCloseable {
    /** true = model đa phương thức và đã nạp bộ mã hóa ảnh (chỉ LiteRT-LM + Gemma 3n/4). */
    val supportsImage: Boolean

    /** Bộ tăng tốc ĐANG chạy thực tế (NPU / GPU / CPU...) để hiển thị và đo đạc; "?" nếu không biết. */
    val backendName: String get() = "?"

    /** Sinh văn bản. [imagePath] != null = kèm ảnh (chỉ khi [supportsImage]); ném lỗi nếu backend không hỗ trợ. */
    fun generate(prompt: String, imagePath: String? = null): String
}
