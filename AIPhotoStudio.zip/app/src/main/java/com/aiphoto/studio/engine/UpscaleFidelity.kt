package com.aiphoto.studio.engine

import kotlin.math.floor

/**
 * R51 - KIỂM SOÁT "BỊA CHI TIẾT" khi phóng to bằng AI (Real-ESRGAN). Mọi model phóng to đều phải đoán chi tiết mà ảnh gốc không có; hai bước sau chạy SAU khi
 * model dựng xong ảnh ra [out], lấy ảnh vào của model [lr] làm chuẩn (cùng thuật toán với bản port tools/verify_ports/upscale_fidelity.py):
 *
 *  1. HIỆU CHỈNH NHẤT QUÁN (back-projection, [ITERATIONS] lần): thu nhỏ [out] bằng trung bình ô k×k, lấy phần dư so với [lr], phóng phần dư bằng song tuyến tính
 *     rồi cộng vào [out]. Kết quả: thu nhỏ ảnh ra lại thì khớp ảnh vào — màu và hình khối bị khóa vào ảnh gốc, chỉ chi tiết nhỏ do AI sinh.
 *  2. THANH "ĐỘ TRUNG THỰC" α: trộn (1−α)·AI + α·bicubic(lr) (Catmull-Rom, biên kẹp). α = 0 là AI thuần (nét nhất); α lớn bám ảnh gốc hơn nhưng mềm hơn.
 *
 * Số đo trên model thật (4 ảnh × 4 kiểu thu nhỏ, xem PROJECT_STATUS R51): PSNR trung bình 24,50 dB (AI thô) → 25,51 (nhất quán) → 25,80 (α = 15%);
 * độ khớp ảnh đầu vào 30,7 → 44,9 dB; độ nét giữ 0,26 → 0,25 (so với ảnh thật = 1).
 *
 * Bộ nhớ: chỉ mảng phần dư cỡ ẢNH VÀO (3 × lrW × lrH số thực) + vài hàng đệm — không có mảng số thực cỡ ảnh ra, nên không đổi trần phóng
 * ([ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL]). Mọi vòng lặp kiểm [isCancelled] theo hàng.
 */
object UpscaleFidelity {
    /** Mặc định của thanh trượt: 15% nội suy — nét còn ~3/4 so với AI thuần, PSNR cao hơn ~0,3 dB. */
    const val DEFAULT = 0.15f

    /** Trần của thanh trượt (60%): quá mức này AI gần như không còn tác dụng. */
    const val MAX_BLEND = 0.6f

    const val ITERATIONS = 2

    /** Kẹp về [0, MAX_BLEND]; không phải số ⇒ mặc định. */
    fun clamp(f: Float): Float = if (f.isNaN()) DEFAULT else f.coerceIn(0f, MAX_BLEND)

    /** Hệ số nguyên k = ảnh ra / ảnh vào (≥ 2, hai chiều giống nhau), 0 nếu hai kích thước không chia hết — khi đó không thể hiệu chỉnh. */
    fun ratio(outW: Int, outH: Int, lrW: Int, lrH: Int): Int {
        if (lrW <= 0 || lrH <= 0 || outW % lrW != 0 || outH % lrH != 0) return 0
        val kx = outW / lrW
        val ky = outH / lrH
        return if (kx == ky && kx >= 2) kx else 0
    }

    /**
     * Hiệu chỉnh [out] (ARGB, sửa tại chỗ). Trả true nếu đã áp dụng; false nếu kích thước không khớp hoặc mảng sai cỡ (để nguyên [out]).
     * [fidelity] = α của thanh trượt (đã kẹp bởi [clamp]). Ném [UpscaleCancelled] khi [isCancelled] — [out] có thể đã sửa dở, người gọi bỏ kết quả.
     */
    fun refine(
        out: IntArray, outW: Int, outH: Int,
        lr: IntArray, lrW: Int, lrH: Int,
        fidelity: Float,
        iterations: Int = ITERATIONS,
        isCancelled: () -> Boolean = { false }
    ): Boolean {
        val k = ratio(outW, outH, lrW, lrH)
        if (k == 0 || out.size != outW * outH || lr.size != lrW * lrH) return false
        val res = FloatArray(3 * lrW * lrH)
        for (pass in 0 until iterations.coerceAtLeast(0)) backProject(out, outW, outH, lr, lrW, lrH, k, res, isCancelled)
        val a = clamp(fidelity)
        if (a > 0f) blendBicubic(out, outW, outH, lr, lrW, lrH, k, a, isCancelled)
        return true
    }

    /** Một lượt back-projection: [res] là mảng phần dư dùng lại (3 × lrW × lrH). */
    private fun backProject(
        out: IntArray, outW: Int, outH: Int, lr: IntArray, lrW: Int, lrH: Int, k: Int,
        res: FloatArray, isCancelled: () -> Boolean
    ) {
        val plane = lrW * lrH
        val inv = 1f / (k * k)
        for (y in 0 until lrH) {
            if (isCancelled()) throw UpscaleCancelled()
            for (x in 0 until lrW) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in 0 until k) {
                    var idx = (y * k + dy) * outW + x * k
                    for (dx in 0 until k) {
                        val p = out[idx++]
                        r += (p shr 16) and 255
                        g += (p shr 8) and 255
                        b += p and 255
                    }
                }
                val i = y * lrW + x
                val q = lr[i]
                res[i] = ((q shr 16) and 255) - r * inv
                res[plane + i] = ((q shr 8) and 255) - g * inv
                res[2 * plane + i] = (q and 255) - b * inv
            }
        }
        // phóng phần dư (song tuyến tính, theo tâm điểm ảnh, kẹp biên) rồi cộng vào ảnh ra
        val xa = IntArray(outW)
        val xb = IntArray(outW)
        val tx = FloatArray(outW)
        for (x in 0 until outW) {
            val fx = (x + 0.5f) / k - 0.5f
            val x0 = floor(fx).toInt()
            tx[x] = fx - x0
            xa[x] = x0.coerceIn(0, lrW - 1)
            xb[x] = (x0 + 1).coerceIn(0, lrW - 1)
        }
        for (y in 0 until outH) {
            if ((y and 31) == 0 && isCancelled()) throw UpscaleCancelled()
            val fy = (y + 0.5f) / k - 0.5f
            val y0 = floor(fy).toInt()
            val ty = fy - y0
            val ra = y0.coerceIn(0, lrH - 1) * lrW
            val rb = (y0 + 1).coerceIn(0, lrH - 1) * lrW
            val row = y * outW
            for (x in 0 until outW) {
                val a = xa[x]
                val b = xb[x]
                val t = tx[x]
                val p = out[row + x]
                val dr = (1 - ty) * (res[ra + a] * (1 - t) + res[ra + b] * t) + ty * (res[rb + a] * (1 - t) + res[rb + b] * t)
                val dg = (1 - ty) * (res[plane + ra + a] * (1 - t) + res[plane + ra + b] * t) + ty * (res[plane + rb + a] * (1 - t) + res[plane + rb + b] * t)
                val db = (1 - ty) * (res[2 * plane + ra + a] * (1 - t) + res[2 * plane + ra + b] * t) + ty * (res[2 * plane + rb + a] * (1 - t) + res[2 * plane + rb + b] * t)
                val rr = clamp255(((p shr 16) and 255) + dr)
                val gg = clamp255(((p shr 8) and 255) + dg)
                val bb = clamp255((p and 255) + db)
                out[row + x] = (255 shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
        }
    }

    /** Trộn (1−α)·out + α·bicubic(lr): nội suy tách hai chiều, mỗi hàng ảnh vào chỉ nội suy ngang MỘT lần (bộ nhớ đệm vài hàng). */
    private fun blendBicubic(
        out: IntArray, outW: Int, outH: Int, lr: IntArray, lrW: Int, lrH: Int, k: Int, alpha: Float,
        isCancelled: () -> Boolean
    ) {
        val xi = IntArray(4 * outW)
        val xw = FloatArray(4 * outW)
        for (x in 0 until outW) {
            val fx = (x + 0.5f) / k - 0.5f
            val x0 = floor(fx).toInt()
            catmullRom(fx - x0, xw, 4 * x)
            for (j in 0 until 4) xi[4 * x + j] = (x0 + j - 1).coerceIn(0, lrW - 1)
        }
        val cache = arrayOfNulls<FloatArray>(lrH)        // hàng ảnh vào đã nội suy ngang: 3 × outW số thực
        val wy = FloatArray(4)
        val rows = arrayOfNulls<FloatArray>(4)
        val keep = 1f - alpha
        for (y in 0 until outH) {
            if ((y and 15) == 0 && isCancelled()) throw UpscaleCancelled()
            val fy = (y + 0.5f) / k - 0.5f
            val y0 = floor(fy).toInt()
            catmullRom(fy - y0, wy, 0)
            for (j in 0 until 4) {
                val ry = (y0 + j - 1).coerceIn(0, lrH - 1)
                rows[j] = cache[ry] ?: horizontal(lr, lrW, ry, outW, xi, xw).also { cache[ry] = it }
            }
            val lo = y0 - 2                               // hàng nhỏ hơn mọi hàng còn cần ở các y sau
            if (lo >= 0 && lo < lrH) cache[lo] = null
            val row = y * outW
            for (x in 0 until outW) {
                var br = 0f
                var bg = 0f
                var bb = 0f
                for (j in 0 until 4) {
                    val h = rows[j]!!
                    val w = wy[j]
                    br += w * h[x]
                    bg += w * h[outW + x]
                    bb += w * h[2 * outW + x]
                }
                val p = out[row + x]
                val rr = clamp255(keep * ((p shr 16) and 255) + alpha * br)
                val gg = clamp255(keep * ((p shr 8) and 255) + alpha * bg)
                val b2 = clamp255(keep * (p and 255) + alpha * bb)
                out[row + x] = (255 shl 24) or (rr shl 16) or (gg shl 8) or b2
            }
        }
    }

    private fun horizontal(lr: IntArray, lrW: Int, ry: Int, outW: Int, xi: IntArray, xw: FloatArray): FloatArray {
        val h = FloatArray(3 * outW)
        val base = ry * lrW
        for (x in 0 until outW) {
            var r = 0f
            var g = 0f
            var b = 0f
            for (j in 0 until 4) {
                val p = lr[base + xi[4 * x + j]]
                val w = xw[4 * x + j]
                r += w * ((p shr 16) and 255)
                g += w * ((p shr 8) and 255)
                b += w * (p and 255)
            }
            h[x] = r
            h[outW + x] = g
            h[2 * outW + x] = b
        }
        return h
    }

    /** Trọng số Catmull-Rom (a = −0,5) cho 4 điểm lân cận ở khoảng cách phân số [t] ∈ [0,1): ghi vào [w][off..off+3]. Tổng luôn = 1. */
    internal fun catmullRom(t: Float, w: FloatArray, off: Int) {
        val t2 = t * t
        val t3 = t2 * t
        w[off] = -0.5f * t3 + t2 - 0.5f * t
        w[off + 1] = 1.5f * t3 - 2.5f * t2 + 1f
        w[off + 2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        w[off + 3] = 0.5f * t3 - 0.5f * t2
    }

    private fun clamp255(v: Float): Int {
        val r = floor(v + 0.5f).toInt()
        return if (r < 0) 0 else if (r > 255) 255 else r
    }
}
