package com.aiphoto.studio.engine

import android.graphics.Bitmap
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Warp lưới (mesh warp) không phá hủy: lưới (gx × gy ô, (gx+1)·(gy+1) nút) phủ toàn ảnh; mỗi nút bị kéo đi một độ dời chuẩn hóa
 * (tỉ lệ rộng/cao). Kéo 4 nút góc = Free Transform (co giãn/nghiêng), kéo nút giữa = biến dạng cục bộ.
 * Nút là điểm NGUỒN dời đi d: với điểm ra x tìm s thỏa s + D(s) = x bằng lặp điểm cố định (4 lần) rồi lấy ảnh nguồn tại s,
 * nhờ đó nội dung đi đúng theo nút dưới ngón tay (ánh xạ ngược bậc 1 chỉ dời ~66% quãng kéo - xem tools/verify_ports/geo_ports.py).
 * Giải bằng Newton (Jacobian lấy từ nội suy song tuyến của chính ô lưới) thay vì lặp điểm cố định cố định 4 lần: lặp cố định chỉ hội tụ
 * nhanh khi độ dời nhỏ (hệ số co = |R - I| = 2·sin(θ/2) với phép xoay), nên xoay tự do 30° để lại sai số ~27 px; Newton chính xác
 * ngay bước đầu với phép biến đổi afin (xoay, co giãn, nghiêng) và vẫn ổn khi lưới bị kéo méo (có đường lùi về lặp điểm cố định).
 * Xoay tự do: [rotated] xoay toàn bộ lưới quanh tâm ảnh (tính trong không gian điểm ảnh, nên không méo ảnh chữ nhật).
 * arg = "gx,gy;dx0,dy0,dx1,dy1,..." (nút theo hàng, trái→phải, trên→dưới).
 */
object MeshWarp {
    const val MAX_GRID = 12
    const val DEFAULT_GRID = 4
    private const val MAX_ITERS = 12
    private const val TOL2 = 1e-4f      // |F|² < 0.01 px² thì dừng
    private const val MIN_DET = 0.2f     // Jacobian gần suy biến (lưới gập) -> lùi về bước lặp điểm cố định

    class Mesh(val gx: Int, val gy: Int, val d: FloatArray)

    fun identity(gx: Int, gy: Int): Mesh = Mesh(gx, gy, FloatArray(2 * (gx + 1) * (gy + 1)))

    fun parse(arg: String?): Mesh? {
        if (arg.isNullOrBlank()) return null
        val sp = arg.split(';')
        if (sp.size != 2) return null
        val g = sp[0].split(',').mapNotNull { it.trim().toIntOrNull() }
        if (g.size != 2 || g[0] !in 1..MAX_GRID || g[1] !in 1..MAX_GRID) return null
        val v = sp[1].split(',').mapNotNull { it.trim().toFloatOrNull() }
        if (v.size != 2 * (g[0] + 1) * (g[1] + 1)) return null
        return Mesh(g[0], g[1], FloatArray(v.size) { v[it].coerceIn(-0.5f, 0.5f) })
    }

    fun encode(m: Mesh): String =
        "${m.gx},${m.gy};" + m.d.joinToString(",") { String.format(Locale.US, "%.4f", it) }

    fun isIdentity(m: Mesh): Boolean = m.d.all { abs(it) < 0.0005f }

    /** Dời nút (i, j) thêm (dx, dy) chuẩn hóa; trả lưới mới (bất biến). */
    fun moved(m: Mesh, i: Int, j: Int, dx: Float, dy: Float): Mesh {
        val d = m.d.copyOf()
        val n = j * (m.gx + 1) + i
        d[2 * n] = (d[2 * n] + dx).coerceIn(-0.5f, 0.5f)
        d[2 * n + 1] = (d[2 * n + 1] + dy).coerceIn(-0.5f, 0.5f)
        return Mesh(m.gx, m.gy, d)
    }

    /**
     * Độ dời (điểm ảnh) tại tọa độ NGUỒN (x, y) -> out[0], out[1]; đạo hàm của độ dời theo (x, y) -> out[2..5] = (∂Dx/∂x, ∂Dx/∂y, ∂Dy/∂x, ∂Dy/∂y).
     * Ngoài mép ảnh trường bị kẹp nên đạo hàm = 0.
     */
    private fun fieldAt(m: Mesh, w: Int, h: Int, x: Float, y: Float, out: FloatArray) {
        val uRaw = x / max(1, w - 1) * m.gx
        val vRaw = y / max(1, h - 1) * m.gy
        val u = uRaw.coerceIn(0f, m.gx.toFloat())
        val v = vRaw.coerceIn(0f, m.gy.toFloat())
        val i0 = min(floor(u).toInt(), m.gx - 1)
        val j0 = min(floor(v).toInt(), m.gy - 1)
        val fu = u - i0
        val fv = v - j0
        val stride = m.gx + 1
        val n00 = j0 * stride + i0
        val n10 = n00 + 1
        val n01 = n00 + stride
        val n11 = n01 + 1
        val w00 = (1f - fu) * (1f - fv)
        val w10 = fu * (1f - fv)
        val w01 = (1f - fu) * fv
        val w11 = fu * fv
        out[0] = (m.d[2 * n00] * w00 + m.d[2 * n10] * w10 + m.d[2 * n01] * w01 + m.d[2 * n11] * w11) * w
        out[1] = (m.d[2 * n00 + 1] * w00 + m.d[2 * n10 + 1] * w10 + m.d[2 * n01 + 1] * w01 + m.d[2 * n11 + 1] * w11) * h
        val duDx = if (uRaw < 0f || uRaw > m.gx) 0f else m.gx / max(1, w - 1).toFloat()
        val dvDy = if (vRaw < 0f || vRaw > m.gy) 0f else m.gy / max(1, h - 1).toFloat()
        val dxdu = ((m.d[2 * n10] - m.d[2 * n00]) * (1f - fv) + (m.d[2 * n11] - m.d[2 * n01]) * fv) * w
        val dxdv = ((m.d[2 * n01] - m.d[2 * n00]) * (1f - fu) + (m.d[2 * n11] - m.d[2 * n10]) * fu) * w
        val dydu = ((m.d[2 * n10 + 1] - m.d[2 * n00 + 1]) * (1f - fv) + (m.d[2 * n11 + 1] - m.d[2 * n01 + 1]) * fv) * h
        val dydv = ((m.d[2 * n01 + 1] - m.d[2 * n00 + 1]) * (1f - fu) + (m.d[2 * n11 + 1] - m.d[2 * n10 + 1]) * fu) * h
        out[2] = dxdu * duDx
        out[3] = dxdv * dvDy
        out[4] = dydu * duDx
        out[5] = dydv * dvDy
    }

    /**
     * Tìm điểm NGUỒN s sao cho s + D(s) = (x, y); trả (sx, sy) qua out[0..1]. [f] là bộ đệm 6 phần tử.
     * Newton có dò lùi (backtracking) theo |F|²: trường độ dời là hàm song tuyến từng ô nên đạo hàm GÃY ở mỗi nút; Newton thuần
     * có thể nhảy qua lại hai bên nút lưới mà không hội tụ (đã gặp khi kéo một nút giữa: điểm ra cạnh nút bị lấy nhầm nguồn).
     * Bước nào không làm giảm |F|² thì thu nửa tới 4 lần; vẫn không được thì dùng bước lặp điểm cố định.
     */
    private fun invert(m: Mesh, w: Int, h: Int, x: Float, y: Float, f: FloatArray, out: FloatArray) {
        var sx = x
        var sy = y
        fieldAt(m, w, h, sx, sy, f)
        var fx = sx + f[0] - x
        var fy = sy + f[1] - y
        var e2 = fx * fx + fy * fy
        var k = 0
        while (e2 >= TOL2 && k < MAX_ITERS) {
            k++
            val a = 1f + f[2]
            val b = f[3]
            val c = f[4]
            val d = 1f + f[5]
            val det = a * d - b * c
            val dx: Float
            val dy: Float
            if (abs(det) < MIN_DET) {
                dx = -fx
                dy = -fy
            } else {
                dx = -(d * fx - b * fy) / det
                dy = -(-c * fx + a * fy) / det
            }
            val ox = sx
            val oy = sy
            var t = 1f
            var accepted = false
            for (tries in 0 until 5) {
                val tx = ox + t * dx
                val ty = oy + t * dy
                fieldAt(m, w, h, tx, ty, f)
                val gx = tx + f[0] - x
                val gy = ty + f[1] - y
                val g2 = gx * gx + gy * gy
                if (g2 < e2) {
                    sx = tx; sy = ty; fx = gx; fy = gy; e2 = g2
                    accepted = true
                    break
                }
                t *= 0.5f
            }
            if (!accepted) {
                fieldAt(m, w, h, ox, oy, f)
                sx = x - f[0]
                sy = y - f[1]
                fieldAt(m, w, h, sx, sy, f)
                fx = sx + f[0] - x
                fy = sy + f[1] - y
                e2 = fx * fx + fy * fy
            }
        }
        out[0] = sx
        out[1] = sy
    }

    fun sampleArgb(src: IntArray, w: Int, h: Int, fx: Float, fy: Float): Int {
        val x = fx.coerceIn(0f, (w - 1).toFloat())
        val y = fy.coerceIn(0f, (h - 1).toFloat())
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(w - 1, x0 + 1)
        val y1 = min(h - 1, y0 + 1)
        val tx = x - x0
        val ty = y - y0
        val p00 = src[y0 * w + x0]
        val p10 = src[y0 * w + x1]
        val p01 = src[y1 * w + x0]
        val p11 = src[y1 * w + x1]
        var res = 0
        for (shift in intArrayOf(24, 16, 8, 0)) {
            val a = ((p00 shr shift) and 255) * (1f - tx) + ((p10 shr shift) and 255) * tx
            val b = ((p01 shr shift) and 255) * (1f - tx) + ((p11 shr shift) and 255) * tx
            val c = (a * (1f - ty) + b * ty + 0.5f).toInt().coerceIn(0, 255)
            res = res or (c shl shift)
        }
        return res
    }

    fun warp(src: IntArray, w: Int, h: Int, m: Mesh): IntArray {
        val out = IntArray(src.size)
        val f = FloatArray(6)
        val s = FloatArray(2)
        for (y in 0 until h) {
            for (x in 0 until w) {
                invert(m, w, h, x.toFloat(), y.toFloat(), f, s)
                out[y * w + x] =
                    if (abs(x - s[0]) < 0.01f && abs(y - s[1]) < 0.01f) src[y * w + x] else sampleArgb(src, w, h, s[0], s[1])
            }
        }
        return out
    }

    // ------------------------------------------------------------------ xoay tự do (Free Transform)

    /** Kết quả xoay: lưới mới và góc THỰC SỰ đã xoay (rad) - nhỏ hơn góc yêu cầu khi một nút chạm giới hạn ±0.5 của độ dời. */
    class Rotated(val mesh: Mesh, val appliedRad: Double)

    /**
     * Xoay toàn bộ lưới (kể cả các biến dạng cục bộ đã có) quanh tâm ảnh thêm [rad] (dương = theo chiều kim đồng hồ trên màn hình, trục y hướng xuống).
     * Tính trong không gian điểm ảnh của ảnh w × h (cùng quy ước với [warp]: nút ở i/gx·(w-1), độ dời nhân w / h) nên là phép xoay cứng thật sự,
     * không làm méo ảnh chữ nhật; chỉ phụ thuộc tỉ lệ khung (độ phân giải khác nhau lệch < 0,2%).
     * Độ dời mỗi nút bị giới hạn ±0.5 (định dạng lưu), nên góc quá lớn sẽ được thu nhỏ bằng chia đôi tới góc lớn nhất xoay được,
     * thay vì kẹp từng nút (kẹp sẽ làm lưới méo).
     */
    fun rotated(m: Mesh, w: Int, h: Int, rad: Double): Rotated {
        if (abs(rad) < 1e-9 || w < 2 || h < 2) return Rotated(m, 0.0)
        tryRotate(m, w, h, rad)?.let { return Rotated(it, rad) }
        var lo = 0.0
        var hi = 1.0
        repeat(24) {
            val mid = (lo + hi) / 2
            if (tryRotate(m, w, h, rad * mid) != null) lo = mid else hi = mid
        }
        val ok = if (lo > 0.0) tryRotate(m, w, h, rad * lo) else null
        return if (ok != null) Rotated(ok, rad * lo) else Rotated(m, 0.0)
    }

    private fun tryRotate(m: Mesh, w: Int, h: Int, rad: Double): Mesh? {
        val c = cos(rad)
        val sn = sin(rad)
        val cx = (w - 1) / 2.0
        val cy = (h - 1) / 2.0
        val d = FloatArray(m.d.size)
        for (j in 0..m.gy) for (i in 0..m.gx) {
            val n = j * (m.gx + 1) + i
            val bx = i.toDouble() / m.gx * (w - 1)
            val by = j.toDouble() / m.gy * (h - 1)
            val px = bx + m.d[2 * n] * w - cx
            val py = by + m.d[2 * n + 1] * h - cy
            val qx = cx + c * px - sn * py
            val qy = cy + sn * px + c * py
            val dx = ((qx - bx) / w).toFloat()
            val dy = ((qy - by) / h).toFloat()
            if (abs(dx) > 0.5f || abs(dy) > 0.5f) return null
            d[2 * n] = dx
            d[2 * n + 1] = dy
        }
        return Mesh(m.gx, m.gy, d)
    }

    fun apply(b: Bitmap, arg: String?): Bitmap {
        val m = parse(arg) ?: return b
        if (isIdentity(m)) return b
        return makeBitmap(warp(readPixels(b), b.width, b.height, m), b.width, b.height)
    }
}
