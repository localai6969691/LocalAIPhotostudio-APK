package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import java.nio.FloatBuffer
import kotlin.math.max

/**
 * CHẠM ĐỂ CHỌN VẬT THỂ bằng MobileSAM (ViT-T) dạng ONNX tách đôi: bộ mã hóa ảnh (chạy 1 lần/ảnh, ~27 MB)
 * + bộ giải mã mặt nạ (chạy mỗi lần chạm, ~16 MB). Giao diện đã đối chiếu với script xuất ONNX chính thức của SAM/MobileSAM:
 * decoder nhận image_embeddings, point_coords [1,N,2] (toạ độ trên ảnh đã resize cạnh dài = 1024), point_labels [1,N]
 * (1 = điểm dương, -1 = điểm đệm), mask_input [1,1,256,256], (has_mask_input [1]), orig_im_size [2] = (cao, rộng);
 * đầu ra đầu tiên là mặt nạ logit ở kích thước gốc (> 0 là vật thể). Tên input đọc từ model lúc chạy nên chịu được khác biệt nhỏ.
 */
class SamSegmenter(encoderPath: String, decoderPath: String) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val enc: OrtSession = OrtTuning.createSession(env, encoderPath)
    private val dec: OrtSession = OrtTuning.createSession(env, decoderPath)
    private val encIn: String = enc.inputNames.iterator().next()

    private var embKey = 0
    private var embData: FloatArray? = null
    private var embShape: LongArray = longArrayOf(1, 256, 64, 64)

    private fun ensureEmbedding(b: Bitmap) {
        val key = System.identityHashCode(b) * 31 + b.width * 7 + b.height
        if (embData != null && key == embKey) return

        val w = b.width
        val h = b.height
        val scale = 1024f / max(w, h)
        val nw = (w * scale + 0.5f).toInt().coerceIn(1, 1024)
        val nh = (h * scale + 0.5f).toInt().coerceIn(1, 1024)
        val small = Bitmap.createScaledBitmap(b, nw, nh, true)
        val px = readPixels(small)
        val plane = 1024 * 1024
        val data = FloatArray(3 * plane) // phần đệm = 0 (sau chuẩn hóa), đúng chuẩn tiền xử lý của SAM
        val mean = floatArrayOf(123.675f, 116.28f, 103.53f)
        val std = floatArrayOf(58.395f, 57.12f, 57.375f)
        for (y in 0 until nh) {
            for (x in 0 until nw) {
                val p = px[y * nw + x]
                val i = y * 1024 + x
                data[i] = (((p shr 16) and 255) - mean[0]) / std[0]
                data[plane + i] = (((p shr 8) and 255) - mean[1]) / std[1]
                data[2 * plane + i] = ((p and 255) - mean[2]) / std[2]
            }
        }
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, 1024, 1024)).use { t ->
            enc.run(mapOf(encIn to t)).use { r ->
                val out = r.get(0) as OnnxTensor
                val fb = out.floatBuffer
                val arr = FloatArray(fb.remaining())
                fb.get(arr)
                embData = arr
                embShape = out.info.shape
            }
        }
        embKey = key
    }

    /** points: toạ độ chuẩn hóa 0..1 theo ảnh. Trả về mặt nạ w*h (255 = vật thể) hoặc null nếu không có điểm nào. */
    @Synchronized
    fun select(b: Bitmap, points: List<Pt>): ByteArray? {
        if (points.isEmpty()) return null
        ensureEmbedding(b)
        val emb = embData ?: return null
        val w = b.width
        val h = b.height
        val scale = 1024f / max(w, h)

        val n = points.size + 1
        val coords = FloatArray(n * 2)
        val labels = FloatArray(n)
        points.forEachIndexed { i, p ->
            coords[2 * i] = p.x * w * scale
            coords[2 * i + 1] = p.y * h * scale
            labels[i] = 1f
        }
        labels[n - 1] = -1f // điểm đệm khi không dùng hộp chọn (theo ví dụ ONNX chính thức của SAM)

        val opened = ArrayList<OnnxTensor>()
        try {
            val feeds = LinkedHashMap<String, OnnxTensor>()
            for (name in dec.inputNames) {
                val t: OnnxTensor = when (name) {
                    "image_embeddings" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(emb), embShape)
                    "point_coords" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(coords), longArrayOf(1, n.toLong(), 2))
                    "point_labels" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(labels), longArrayOf(1, n.toLong()))
                    "mask_input" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(FloatArray(256 * 256)), longArrayOf(1, 1, 256, 256))
                    "has_mask_input" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArrayOf(0f)), longArrayOf(1))
                    "orig_im_size" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArrayOf(h.toFloat(), w.toFloat())), longArrayOf(2))
                    else -> throw IllegalStateException("Decoder SAM có input lạ: $name")
                }
                opened.add(t)
                feeds[name] = t
            }
            return dec.run(feeds).use { r ->
                val fb = (r.get(0) as OnnxTensor).floatBuffer
                val out = ByteArray(w * h)
                for (i in 0 until w * h) out[i] = if (fb.get(i) > 0f) 255.toByte() else 0.toByte()
                out
            }
        } finally {
            for (t in opened) { try { t.close() } catch (e: Throwable) { } }
        }
    }

    override fun close() {
        try { enc.close() } catch (e: Throwable) { }
        try { dec.close() } catch (e: Throwable) { }
    }
}
