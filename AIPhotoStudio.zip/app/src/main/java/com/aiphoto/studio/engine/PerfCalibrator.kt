package com.aiphoto.studio.engine

import android.graphics.Bitmap
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType

/**
 * Đo TỐC ĐỘ THẬT của máy bằng chính bộ máy dựng ảnh của app (không phải con số tra bảng): chạy một chuỗi toán tử đại diện (một lượt ma trận màu gộp + làm nét có làm mờ Gauss) trên
 * ảnh tổng hợp ~0,8 MP và trả về ms cho mỗi megapixel (lần ngắn nhất sau một lần khởi động). Chạy MỘT LẦN ở luồng nền khi mở app (xem `MainViewModel`); kết quả được gộp bằng
 * `PerfModel.blend` và lưu lại. Chi phí tỉ lệ với điểm ảnh nên một ảnh nhỏ đủ đại diện cho ảnh lớn.
 */
object PerfCalibrator {
    const val W = 1024
    const val H = 768
    const val WARMUP = 1
    const val RUNS = 3

    private val CHAIN = listOf(
        EditOp(OpType.BRIGHTNESS, 0.1f), EditOp(OpType.CONTRAST, 0.1f), EditOp(OpType.SATURATION, 0.1f), EditOp(OpType.SHARPEN, 0.4f)
    )

    /** Ảnh tổng hợp có cả vùng phẳng, dải chuyển và chi tiết (để làm nét / làm mờ làm việc thật), tất định. */
    fun sample(): Bitmap {
        val px = IntArray(W * H)
        var seed = 12345
        for (y in 0 until H) {
            for (x in 0 until W) {
                seed = seed * 1103515245 + 12345
                val noise = (seed ushr 16) and 31
                val r = (x * 255 / W + noise) and 255
                val g = (y * 255 / H + (noise shr 1)) and 255
                val b = ((x + y) * 255 / (W + H) + (if ((x / 64 + y / 64) % 2 == 0) 40 else 0)) and 255
                px[y * W + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return makeBitmap(px, W, H)
    }

    /** ms cho mỗi megapixel của chuỗi hiệu chuẩn trên máy này; null nếu đo lỗi (hết bộ nhớ…) — người gọi giữ hồ sơ khởi đầu. */
    fun measureMsPerMp(): Double? {
        val bmp = sample()
        repeat(WARMUP) { ImageEngine.process(bmp, CHAIN, null, false, ArrayList()) }
        var best = Long.MAX_VALUE
        repeat(RUNS) {
            val t0 = System.nanoTime()
            ImageEngine.process(bmp, CHAIN, null, false, ArrayList())
            best = minOf(best, System.nanoTime() - t0)
        }
        val ms = best / 1e6
        val mp = W.toDouble() * H / 1e6
        return if (ms > 0.0) ms / mp else null
    }
}
