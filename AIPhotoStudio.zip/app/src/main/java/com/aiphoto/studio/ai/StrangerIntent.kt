package com.aiphoto.studio.ai

/**
 * Nhận biết yêu cầu "xóa người lạ / người qua đường / người phía sau" (PDF): cần ĐỘNG TỪ xóa + ĐỐI TƯỢNG là người ngoài chủ thể.
 * Không nhận "xóa người" trần (không rõ người nào) và không nhận "xóa mọi người" (sẽ xóa cả chủ thể).
 */
object StrangerIntent {

    private val REMOVE = listOf(
        "xoa", "loai bo", "go bo", "bo di", "cat bo", "lam bien mat", "remove", "erase", "delete", "get rid of", "clean up", "take out", "eliminate"
    )
    private val TARGET = listOf(
        "nguoi la", "nguoi qua duong", "nguoi di duong", "nguoi phia sau", "nguoi o phia sau", "nguoi o nen", "nguoi nen sau",
        "nguoi dung sau", "nguoi khac", "nguoi thua", "nhung nguoi con lai", "khach du lich", "du khach", "dam dong", "nguoi ngoai cuoc",
        "stranger", "strangers", "bystander", "bystanders", "passerby", "passersby", "tourist", "tourists", "crowd", "photobomber", "photobombers",
        "other people", "extra people", "people in the background", "people behind", "background people", "unknown people", "random people", "random person"
    )

    private fun has(t: String, key: String): Boolean =
        Regex("(?<![a-z0-9])" + Regex.escape(key) + "(?![a-z0-9])").containsMatchIn(t)

    fun isStrangerRemoval(prompt: String): Boolean {
        val t = GenIntent.fold(prompt)
        if (t.isEmpty()) return false
        return REMOVE.any { has(t, it) } && TARGET.any { has(t, it) }
    }
}
