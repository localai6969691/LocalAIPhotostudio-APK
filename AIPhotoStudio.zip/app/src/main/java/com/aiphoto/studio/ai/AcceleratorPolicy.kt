package com.aiphoto.studio.ai

/**
 * Chính sách thử NPU cho LLM, TRUNG LẬP theo hãng chip (R18): mã nguồn không nêu Qualcomm/MediaTek/Tensor/Samsung/Intel nào cả.
 *
 * Cơ sở (tài liệu LiteRT / LiteRT-LM, cập nhật 09-10/2026): LiteRT cho một giao diện NPU thống nhất, runtime tự chọn bộ điều phối
 * của hãng tương ứng theo thiết bị. Phần RIÊNG THEO CHIP duy nhất là tệp model đã biên dịch trước (AOT), đặt tên theo quy ước
 * `<tên model>_<ro.soc.model viết thường>.litertlm`, ví dụ `Gemma3-1B-IT_q4_ekv1280_sm8750.litertlm` (Qualcomm), `..._mt6989` (MediaTek),
 * `gemma-4-E2B-it_Google_tensor_g6.litertlm` (Google Tensor). Một tệp như vậy CHỈ chạy trên đúng SoC của nó -> chỉ thử NPU khi tệp đang nạp
 * được biên dịch cho CHÍNH chip của máy này. Model chung (không có hậu tố SoC khớp) không bao giờ kích hoạt đường NPU: chạy GPU rồi CPU.
 *
 * Điều kiện nền của NPU (tài liệu LiteRT): Android API 31+ và arm64-v8a. Dự án có minSdk 26 nên phải kiểm tra LÚC CHẠY.
 */
object AcceleratorPolicy {

    const val MIN_NPU_SDK = 31
    const val NPU_ABI = "arm64-v8a"
    private const val EXT = ".litertlm"

    /** `Build.SOC_MODEL` trả "unknown" (hoặc rỗng) khi máy không khai báo. */
    fun normalizeSoc(socModel: String?): String {
        val s = socModel?.trim()?.lowercase().orEmpty()
        return if (s == "unknown") "" else s
    }

    /** Tệp .litertlm có hậu tố `_<soc>` khớp ĐÚNG SoC của máy (và còn tên model phía trước) = bản biên dịch sẵn cho chip này. */
    fun isModelCompiledForSoc(fileName: String?, socModel: String?): Boolean {
        val soc = normalizeSoc(socModel)
        if (fileName == null || soc.isEmpty()) return false
        val suffix = "_$soc$EXT"
        val n = fileName.trim().lowercase()
        return n.endsWith(suffix) && n.length > suffix.length
    }

    fun mayUseNpu(sdkInt: Int, abis: List<String>, fileName: String?, socModel: String?): Boolean =
        sdkInt >= MIN_NPU_SDK && abis.any { it == NPU_ABI } && isModelCompiledForSoc(fileName, socModel)
}
