package com.aiphoto.studio.engine

import org.json.JSONObject

/**
 * Gói Team/Enterprise (R22) phía app: CHỈ đọc và hiển thị những gì máy chủ quyết định (ghế, quỹ chung, hạn Pro, vai trò) và gửi lệnh.
 * Không có con số kinh doanh nào ở đây; không có quyết định gì ở máy khách (máy chủ kiểm quyền từng lệnh).
 */
class TeamMember(
    /** Mã BĂM ẩn danh do máy chủ cấp: quản trị viên KHÔNG thấy mã thiết bị thật của thành viên. */
    val memberId: String,
    val role: String,
    val joined: Long,
    val isYou: Boolean
) {
    val isAdmin: Boolean get() = role == "admin"
}

class TeamInfo(
    val teamId: String,
    val name: String,
    /** "admin" | "member". */
    val role: String,
    val seats: Int,
    val members: Int,
    /** Quỹ credits dùng chung của nhóm. */
    val credits: Int,
    /** Giây Unix; 0 = nhóm không có Pro (còn hạn). */
    val planUntil: Long,
    /** Chỉ quản trị viên mới nhận danh sách này. */
    val memberList: List<TeamMember>
) {
    val isAdmin: Boolean get() = role == "admin"
    val seatsLeft: Int get() = (seats - members).coerceAtLeast(0)
    fun hasPlan(nowSec: Long): Boolean = planUntil > nowSec

    companion object {
        /** `null` khi tài khoản không thuộc nhóm nào (máy chủ gửi `"team": null`) hoặc dữ liệu không đúng dạng. */
        fun fromJson(o: JSONObject?): TeamInfo? {
            if (o == null) return null
            val id = o.optString("team_id")
            if (id.isEmpty()) return null
            val you = o.optString("you")
            val list = ArrayList<TeamMember>()
            val arr = o.optJSONArray("member_list")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val m = arr.optJSONObject(i) ?: continue
                    val mid = m.optString("member_id")
                    if (mid.isEmpty()) continue
                    list.add(TeamMember(mid, m.optString("role", "member"), m.optLong("joined"), you.isNotEmpty() && mid == you))
                }
            }
            return TeamInfo(
                id, o.optString("name"), o.optString("role", "member").ifEmpty { "member" },
                o.optInt("seats"), o.optInt("members"), o.optInt("credits"), o.optLong("plan_until"), list
            )
        }
    }
}

object TeamText {
    private val STATUS = Regex("""Máy chủ trả mã (\d+):""")
    private val ERROR_FIELD = Regex(""""error"\s*:\s*"((?:[^"\\]|\\.)*)""")

    /** Giải mã các dấu thoát JSON (\\uXXXX, \\", \\\\, \\n…) trong một đoạn có thể BỊ CẮT: dấu thoát dở dang ở cuối bị bỏ, không để rác. */
    internal fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '\\') { sb.append(c); i++; continue }
            if (i + 1 >= s.length) break
            val n = s[i + 1]
            if (n == 'u') {
                if (i + 6 > s.length) break
                val h = s.substring(i + 2, i + 6).toIntOrNull(16) ?: break
                sb.append(h.toChar()); i += 6
            } else {
                sb.append(when (n) { 'n' -> '\n'; 't' -> '\t'; 'r' -> '\r'; 'b' -> '\b'; 'f' -> '\u000C'; else -> n })
                i += 2
            }
        }
        return sb.toString()
    }

    /**
     * Lấy trường "error" từ thân JSON bằng regex (không cần thân còn nguyên): dùng khi `JSONObject` không đọc được vì thân bị cắt.
     * Tách riêng để kiểm thẳng, không phụ thuộc bộ đọc JSON của nền tảng (Android báo lỗi với chuỗi chưa đóng, bản giả trên JVM thì dễ tính hơn).
     */
    internal fun extractErrorField(body: String): String? =
        ERROR_FIELD.find(body)?.groupValues?.get(1)?.let { unescape(it) }?.trim()?.ifEmpty { null }

    /**
     * Thông báo lỗi của máy chủ -> câu đọc được. `ProxyBackend.call` ném IOException "Máy chủ trả mã N: <thân JSON>"; thân có thể bị CẮT
     * giữa chừng và máy chủ gửi tiếng Việt dưới dạng \\uXXXX, nên đọc bằng JSON nếu đủ, không thì tách trường "error" bằng regex.
     */
    fun friendlyError(raw: String?): String {
        if (raw.isNullOrBlank()) return "Không thực hiện được."
        val code = STATUS.find(raw)?.groupValues?.get(1)?.toIntOrNull()
        val body = raw.substringAfter(": ", raw).let { b -> val i = b.indexOf('{'); if (i >= 0) b.substring(i) else b }
        var msg: String? = runCatching { JSONObject(body).optString("error").ifEmpty { null } }.getOrNull()
        if (msg == null) msg = extractErrorField(body)
        if (!msg.isNullOrBlank()) return msg
        return when (code) {
            401 -> "Chưa đăng nhập máy chủ."
            429 -> "Thử quá nhiều lần, hãy đợi một lúc."
            503 -> "Máy chủ chưa bật gói Team."
            null -> raw.take(160)
            else -> "Máy chủ báo lỗi (mã $code)."
        }
    }

    /** Chuẩn hóa mã mời người dùng gõ/dán: bỏ khoảng trắng và dấu gạch, IN HOA (máy chủ cũng chuẩn hóa như vậy). */
    fun normalizeCode(input: String): String = input.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }

    /** Mã mời hợp lệ về hình thức: 10 ký tự (bảng chữ cái của máy chủ bỏ 0/O/1/I). Chỉ để bật/tắt nút; quyết định thật ở máy chủ. */
    fun isPlausibleCode(input: String): Boolean {
        val c = normalizeCode(input)
        return c.length == 10 && c.none { it == '0' || it == 'O' || it == '1' || it == 'I' }
    }

    fun displayCode(input: String): String {
        val c = normalizeCode(input)
        return if (c.length == 10) c.substring(0, 5) + "-" + c.substring(5) else c
    }

    fun roleLabel(role: String): String = if (role == "admin") "quản trị viên" else "thành viên"

    /** Một dòng tóm tắt hiển thị trong Cài đặt. */
    fun summary(t: TeamInfo, nowSec: Long): String {
        val plan = if (t.hasPlan(nowSec)) "Pro đến " + java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US).format(java.util.Date(t.planUntil * 1000)) else "không có Pro"
        return "Nhóm \"${t.name}\" (bạn là ${roleLabel(t.role)}) · ghế ${t.members}/${t.seats} · quỹ chung ${t.credits} credits · $plan"
    }
}
