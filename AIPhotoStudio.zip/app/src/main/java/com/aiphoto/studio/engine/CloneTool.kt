package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.max

/**
 * Clone Stamp / Heal Brush: chép điểm ảnh từ vị trí nguồn (lệch (dx,dy)) vào vùng mặt nạ, biên mềm.
 * Heal: ngoài chép chi tiết (kết cấu) còn bù chênh lệch màu/ánh sáng "tần số thấp" giữa vùng đích và vùng nguồn
 * để mảng vá hòa vào xung quanh thay vì lộ màu nguồn.
 */
object CloneTool {

    fun apply(base: Bitmap, mask: ByteArray, dx: Int, dy: Int, heal: Boolean): Bitmap {
        val w = base.width
        val h = base.height
        val src = readPixels(base)
        val out = src.copyOf()
        val gray = IntArray(w * h) { if (mask[it].toInt() != 0) -1 else (255 shl 24) }
        val soft = Blur.gaussian(gray, w, h, max(2, max(w, h) / 300))
        val low = if (heal) Blur.gaussian(src, w, h, max(4, max(w, h) / 120)) else null

        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val a = (soft[i] and 255) / 255f
                if (a <= 0.003f) continue
                val sx = (x - dx).coerceIn(0, w - 1)
                val sy = (y - dy).coerceIn(0, h - 1)
                val si = sy * w + sx
                val s = src[si]
                var r = ((s shr 16) and 255).toFloat()
                var g = ((s shr 8) and 255).toFloat()
                var b = (s and 255).toFloat()
                if (low != null) {
                    val ld = low[i]
                    val ls = low[si]
                    r += ((ld shr 16) and 255) - ((ls shr 16) and 255)
                    g += ((ld shr 8) and 255) - ((ls shr 8) and 255)
                    b += (ld and 255) - (ls and 255)
                }
                val d = src[i]
                val nr = (((d shr 16) and 255) * (1f - a) + r * a + 0.5f).toInt().coerceIn(0, 255)
                val ng = (((d shr 8) and 255) * (1f - a) + g * a + 0.5f).toInt().coerceIn(0, 255)
                val nb = ((d and 255) * (1f - a) + b * a + 0.5f).toInt().coerceIn(0, 255)
                out[i] = (d and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        return makeBitmap(out, w, h)
    }
}
