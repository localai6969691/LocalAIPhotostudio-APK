package com.aiphoto.studio.doc

import android.content.Context
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Looks dựng sẵn (một chạm). Cường độ của look = độ mờ (opacity) của lớp. */
object Looks {
    /** Chia tông: bóng tối nghiêng về màu [shHue]°, vùng sáng về [hiHue]° (độ bão hòa 0..1 mỗi bên; bảng màu: 0 đỏ · 28 cam · 45 vàng · 120 lục · 185 xanh ngọc · 215 lam · 270 tím · 320 hồng sẫm). */
    private fun st(shHue: Float, shSat: Float, hiHue: Float, hiSat: Float, balance: Float = 0f) =
        EditOp(OpType.SPLIT_TONE, 1f, com.aiphoto.studio.engine.SplitTone.format(com.aiphoto.studio.engine.SplitTone.Params(shHue, shSat, hiHue, hiSat, balance)))

    private fun e(t: OpType, v: Float) = EditOp(t, v)

    /** Duotone: bóng tối → [shadow], vùng sáng → [high] (hex "#RRGGBB"). */
    private fun duo(shadow: String, high: String) = EditOp(OpType.DUOTONE, 1f, "$shadow,$high")

    /** HSL theo dải màu: mỗi mục = (dải 0..7: đỏ, cam, vàng, lục, lam nhạt, lam, tím, hồng; sắc độ; bão hòa; độ sáng) trong -1..1. */
    private fun hsl(vararg adj: FloatArray): EditOp {
        val v = FloatArray(24)
        for (a in adj) { val b = a[0].toInt(); v[3 * b] = a[1]; v[3 * b + 1] = a[2]; v[3 * b + 2] = a[3] }
        return EditOp(OpType.HSL, 1f, v.joinToString(",") { "%.3f".format(java.util.Locale.ROOT, it) })
    }
    private fun band(b: Int, hue: Float, sat: Float, light: Float) = floatArrayOf(b.toFloat(), hue, sat, light)

    /** Looks mở rộng (R20): phong cách phim / mùa / thời đại / thẩm mỹ mạng xã hội — chỉ là DỮ LIỆU (chuỗi phép chỉnh), không cần model. */
    private val more: List<Pair<String, List<EditOp>>> = listOf(
        "Film ấm (Kodak)" to listOf(e(OpType.WARMTH, 0.25f), e(OpType.SATURATION, 0.1f), e(OpType.CONTRAST, 0.08f), e(OpType.GRAIN, 0.25f), st(220f, 0.25f, 40f, 0.35f), e(OpType.MATTE, 0.15f)),
        "Film xanh (Fuji)" to listOf(e(OpType.SATURATION, 0.05f), e(OpType.CONTRAST, 0.1f), e(OpType.GRAIN, 0.2f), st(175f, 0.3f, 95f, 0.2f), e(OpType.TINT, -0.1f)),
        "Matte nhạt" to listOf(e(OpType.MATTE, 0.6f), e(OpType.CONTRAST, -0.05f), e(OpType.SATURATION, -0.1f)),
        "Cyberpunk" to listOf(st(270f, 0.6f, 185f, 0.6f), e(OpType.CONTRAST, 0.2f), e(OpType.SATURATION, 0.25f), e(OpType.GLOW, 0.25f)),
        "Neon đêm" to listOf(st(300f, 0.5f, 190f, 0.4f), e(OpType.CONTRAST, 0.25f), e(OpType.VIBRANCE, 0.3f), e(OpType.GLOW, 0.3f), e(OpType.VIGNETTE, 0.3f)),
        "Vaporwave" to listOf(st(270f, 0.5f, 330f, 0.5f), e(OpType.SATURATION, 0.2f), e(OpType.CONTRAST, 0.1f), e(OpType.GLOW, 0.3f), e(OpType.MATTE, 0.2f)),
        "Nâu cổ điển" to listOf(e(OpType.SEPIA, 0.8f), e(OpType.VIGNETTE, 0.3f), e(OpType.GRAIN, 0.2f)),
        "Đen trắng gắt" to listOf(e(OpType.GRAYSCALE, 1f), e(OpType.CONTRAST, 0.4f), e(OpType.CLARITY, 0.4f), e(OpType.VIGNETTE, 0.2f)),
        "Đen trắng mềm" to listOf(e(OpType.GRAYSCALE, 1f), e(OpType.CONTRAST, -0.05f), e(OpType.MATTE, 0.3f), e(OpType.GLOW, 0.2f)),
        "Noir" to listOf(e(OpType.GRAYSCALE, 1f), e(OpType.CONTRAST, 0.5f), e(OpType.VIGNETTE, 0.5f), e(OpType.GRAIN, 0.35f)),
        "Pastel" to listOf(e(OpType.SATURATION, -0.15f), e(OpType.BRIGHTNESS, 0.12f), e(OpType.CONTRAST, -0.15f), e(OpType.MATTE, 0.3f), st(220f, 0.15f, 350f, 0.25f)),
        "Mơ màng" to listOf(e(OpType.GLOW, 0.6f), e(OpType.BRIGHTNESS, 0.06f), e(OpType.SATURATION, 0.1f), e(OpType.CONTRAST, -0.08f), e(OpType.WARMTH, 0.1f)),
        "Giờ vàng" to listOf(e(OpType.WARMTH, 0.5f), st(215f, 0.2f, 40f, 0.55f), e(OpType.HIGHLIGHTS, -0.1f), e(OpType.VIGNETTE, 0.2f), e(OpType.GLOW, 0.2f)),
        "Bình minh hồng" to listOf(st(250f, 0.3f, 15f, 0.45f), e(OpType.WARMTH, 0.15f), e(OpType.SATURATION, 0.1f), e(OpType.GLOW, 0.15f)),
        "Rừng xanh" to listOf(st(160f, 0.35f, 85f, 0.35f), e(OpType.SATURATION, 0.1f), e(OpType.CONTRAST, 0.1f), e(OpType.CLARITY, 0.2f)),
        "Biển xanh ngọc" to listOf(st(190f, 0.4f, 175f, 0.25f), e(OpType.VIBRANCE, 0.3f), e(OpType.CONTRAST, 0.1f), e(OpType.DEHAZE, 0.2f)),
        "Mùa thu" to listOf(e(OpType.WARMTH, 0.35f), st(20f, 0.3f, 38f, 0.45f), e(OpType.SATURATION, 0.15f), e(OpType.CONTRAST, 0.1f), e(OpType.VIGNETTE, 0.2f)),
        "Mùa đông" to listOf(e(OpType.WARMTH, -0.35f), e(OpType.SATURATION, -0.15f), st(215f, 0.3f, 200f, 0.2f), e(OpType.BRIGHTNESS, 0.05f), e(OpType.CLARITY, 0.15f)),
        "Retro 70s" to listOf(e(OpType.WARMTH, 0.3f), e(OpType.SATURATION, -0.1f), e(OpType.CONTRAST, -0.1f), e(OpType.MATTE, 0.35f), st(40f, 0.3f, 55f, 0.35f), e(OpType.GRAIN, 0.3f), e(OpType.VIGNETTE, 0.3f)),
        "Retro 90s" to listOf(e(OpType.SATURATION, 0.1f), e(OpType.WARMTH, 0.1f), e(OpType.CONTRAST, 0.15f), e(OpType.GRAIN, 0.35f), st(150f, 0.2f, 340f, 0.25f), e(OpType.VIGNETTE, 0.2f)),
        "Polaroid" to listOf(e(OpType.MATTE, 0.35f), e(OpType.WARMTH, 0.15f), e(OpType.SATURATION, -0.05f), e(OpType.CONTRAST, -0.1f), st(160f, 0.2f, 45f, 0.3f), e(OpType.VIGNETTE, 0.35f)),
        "Chân dung sạch" to listOf(e(OpType.BRIGHTNESS, 0.08f), e(OpType.FREQ_SEP, 0.5f), e(OpType.AUTO_ENHANCE, 0.4f), e(OpType.VIBRANCE, 0.15f)),
        "Da sáng trong" to listOf(e(OpType.BRIGHTNESS, 0.12f), e(OpType.CONTRAST, -0.05f), e(OpType.SATURATION, -0.05f), e(OpType.FREQ_SEP, 0.6f), e(OpType.WARMTH, -0.05f), e(OpType.GLOW, 0.2f)),
        "Nổi bật (Punch)" to listOf(e(OpType.CONTRAST, 0.3f), e(OpType.CLARITY, 0.35f), e(OpType.VIBRANCE, 0.35f), e(OpType.SHARPEN, 0.3f)),
        "Dịu nhẹ" to listOf(e(OpType.CONTRAST, -0.15f), e(OpType.HIGHLIGHTS, -0.2f), e(OpType.SHADOWS, 0.2f), e(OpType.SATURATION, -0.05f)),
        "Kịch tính" to listOf(e(OpType.DEHAZE, 0.3f), e(OpType.CLARITY, 0.5f), e(OpType.SATURATION, -0.15f), e(OpType.CONTRAST, 0.25f), e(OpType.VIGNETTE, 0.35f)),
        "Phim tài liệu" to listOf(e(OpType.SATURATION, -0.2f), e(OpType.CONTRAST, 0.12f), e(OpType.GRAIN, 0.25f), st(200f, 0.15f, 50f, 0.2f)),
        "Xanh lục ma trận" to listOf(st(120f, 0.5f, 125f, 0.3f), e(OpType.SATURATION, -0.2f), e(OpType.CONTRAST, 0.25f), e(OpType.VIGNETTE, 0.3f)),
        "Trầm lắng" to listOf(e(OpType.SATURATION, -0.3f), e(OpType.CONTRAST, -0.05f), e(OpType.MATTE, 0.25f), e(OpType.WARMTH, 0.05f))
    )

    /**
     * Looks mở rộng đợt 2 (R21): 40 look nữa cho đủ "80+" của PDF — phim cổ điển, duotone, theo cảnh (ẩm thực, biển, sa mạc…), phong cách mạng xã hội,
     * hiệu ứng nghệ thuật (pop-art, pixel, phác họa, glitch…). Vẫn chỉ là DỮ LIỆU: thêm look = thêm một dòng, không cần mã mới.
     */
    private val extra: List<Pair<String, List<EditOp>>> = listOf(
        // --- phim & kỹ thuật rửa ảnh
        "Portra mịn da" to listOf(e(OpType.WARMTH, 0.15f), e(OpType.CONTRAST, -0.08f), e(OpType.SATURATION, -0.08f), e(OpType.MATTE, 0.2f), st(200f, 0.15f, 35f, 0.25f), e(OpType.GRAIN, 0.15f)),
        "Ektar rực rỡ" to listOf(e(OpType.SATURATION, 0.3f), e(OpType.CONTRAST, 0.18f), e(OpType.VIBRANCE, 0.2f), e(OpType.CLARITY, 0.15f), st(210f, 0.15f, 35f, 0.2f)),
        "Cross-process" to listOf(st(150f, 0.45f, 50f, 0.5f), e(OpType.CONTRAST, 0.25f), e(OpType.SATURATION, 0.2f), e(OpType.GRAIN, 0.15f)),
        "Bleach bypass" to listOf(e(OpType.SATURATION, -0.45f), e(OpType.CONTRAST, 0.4f), e(OpType.CLARITY, 0.3f), e(OpType.GRAIN, 0.2f)),
        "Ilford hạt thô" to listOf(e(OpType.GRAYSCALE, 1f), e(OpType.CONTRAST, 0.3f), e(OpType.GRAIN, 0.6f), e(OpType.CLARITY, 0.25f)),
        "Tintype xám ấm" to listOf(duo("#1a1713", "#cfc6b4"), e(OpType.GRAIN, 0.4f), e(OpType.VIGNETTE, 0.5f), e(OpType.CONTRAST, 0.1f)),
        "Lo-fi" to listOf(e(OpType.SATURATION, 0.3f), e(OpType.CONTRAST, 0.3f), e(OpType.VIGNETTE, 0.4f), st(25f, 0.2f, 45f, 0.25f)),
        "Nashville" to listOf(e(OpType.WARMTH, 0.2f), e(OpType.CONTRAST, 0.1f), e(OpType.MATTE, 0.3f), st(340f, 0.3f, 45f, 0.3f), e(OpType.VIGNETTE, 0.25f)),
        "Clarendon" to listOf(e(OpType.CONTRAST, 0.2f), e(OpType.SATURATION, 0.25f), e(OpType.BRIGHTNESS, 0.05f), st(210f, 0.2f, 40f, 0.15f)),
        // --- duotone / một màu
        "Cyanotype" to listOf(duo("#0b2a4a", "#d6ecff")),
        "Duotone lửa" to listOf(duo("#2b0a3d", "#ffb347"), e(OpType.CONTRAST, 0.1f)),
        "Duotone đại dương" to listOf(duo("#012a4a", "#a9d6e5")),
        "Duotone hồng tím" to listOf(duo("#3a0ca3", "#f72585"), e(OpType.GLOW, 0.15f)),
        "Duotone rêu" to listOf(duo("#1b2a12", "#e2d9a2"), e(OpType.GRAIN, 0.2f)),
        // --- theo cảnh
        "Ẩm thực" to listOf(e(OpType.WARMTH, 0.2f), e(OpType.SATURATION, 0.25f), e(OpType.CONTRAST, 0.15f), e(OpType.CLARITY, 0.25f), e(OpType.VIBRANCE, 0.2f), e(OpType.SHARPEN, 0.2f)),
        "Bờ biển mùa hè" to listOf(e(OpType.WARMTH, 0.1f), e(OpType.SATURATION, 0.2f), e(OpType.VIBRANCE, 0.25f), st(190f, 0.3f, 45f, 0.3f), e(OpType.DEHAZE, 0.15f), e(OpType.CONTRAST, 0.1f)),
        "Sa mạc nắng" to listOf(e(OpType.WARMTH, 0.4f), st(20f, 0.25f, 40f, 0.4f), e(OpType.CONTRAST, 0.15f), e(OpType.VIBRANCE, 0.1f), e(OpType.DEHAZE, 0.15f)),
        "Rừng sương mù" to listOf(e(OpType.DEHAZE, -0.25f), st(170f, 0.25f, 95f, 0.2f), e(OpType.SATURATION, -0.1f), e(OpType.MATTE, 0.2f)),
        "Sương sớm" to listOf(e(OpType.DEHAZE, -0.35f), e(OpType.BRIGHTNESS, 0.08f), e(OpType.WARMTH, -0.05f), e(OpType.MATTE, 0.25f), e(OpType.GLOW, 0.2f), e(OpType.CONTRAST, -0.1f)),
        "Trời xanh sâu" to listOf(hsl(band(5, 0f, 0.4f, -0.25f), band(4, 0f, 0.25f, -0.15f)), e(OpType.CONTRAST, 0.12f)),
        "Lá xanh tươi" to listOf(hsl(band(3, 0f, 0.4f, 0.1f), band(2, 0f, 0.2f, 0f)), e(OpType.CLARITY, 0.2f), e(OpType.VIBRANCE, 0.1f)),
        "Nắng xuyên lá" to listOf(e(OpType.LENS_FLARE, 0.5f), e(OpType.WARMTH, 0.3f), e(OpType.GLOW, 0.2f), st(215f, 0.15f, 45f, 0.4f)),
        "Flare cam" to listOf(EditOp(OpType.LENS_FLARE, 0.7f, "0.2,0.2"), e(OpType.WARMTH, 0.25f), e(OpType.SATURATION, 0.1f)),
        "Hoàng hôn đỏ lửa" to listOf(e(OpType.WARMTH, 0.5f), st(280f, 0.3f, 15f, 0.6f), e(OpType.SATURATION, 0.25f), e(OpType.CONTRAST, 0.15f), e(OpType.VIGNETTE, 0.25f)),
        "Đêm xanh" to listOf(e(OpType.BRIGHTNESS, -0.2f), e(OpType.WARMTH, -0.4f), st(220f, 0.5f, 200f, 0.3f), e(OpType.CONTRAST, 0.15f), e(OpType.SATURATION, -0.1f), e(OpType.VIGNETTE, 0.4f)),
        // --- không khí / thẩm mỹ
        "Moody xanh trầm" to listOf(e(OpType.SATURATION, -0.25f), e(OpType.CONTRAST, 0.2f), st(200f, 0.4f, 30f, 0.15f), e(OpType.VIGNETTE, 0.4f)),
        "Moody nâu" to listOf(e(OpType.SEPIA, 0.15f), e(OpType.SATURATION, -0.2f), e(OpType.CONTRAST, 0.2f), e(OpType.VIGNETTE, 0.4f), st(25f, 0.3f, 40f, 0.25f)),
        "High-key sáng" to listOf(e(OpType.BRIGHTNESS, 0.2f), e(OpType.CONTRAST, -0.15f), e(OpType.SHADOWS, 0.3f), e(OpType.SATURATION, -0.1f), e(OpType.GLOW, 0.15f)),
        "Low-key tối" to listOf(e(OpType.BRIGHTNESS, -0.15f), e(OpType.CONTRAST, 0.3f), e(OpType.VIGNETTE, 0.5f), e(OpType.HIGHLIGHTS, -0.2f), e(OpType.SATURATION, -0.1f)),
        "Tối giản mát" to listOf(e(OpType.SATURATION, -0.35f), e(OpType.WARMTH, -0.15f), e(OpType.BRIGHTNESS, 0.08f), e(OpType.CONTRAST, -0.05f), e(OpType.MATTE, 0.15f)),
        "Ảnh cưới trắng mịn" to listOf(e(OpType.BRIGHTNESS, 0.12f), e(OpType.CONTRAST, -0.1f), e(OpType.SATURATION, -0.15f), e(OpType.GLOW, 0.35f), e(OpType.FREQ_SEP, 0.4f), e(OpType.WARMTH, 0.05f), e(OpType.MATTE, 0.15f)),
        "Da ấm nắng" to listOf(e(OpType.WARMTH, 0.2f), st(25f, 0.2f, 35f, 0.3f), e(OpType.SATURATION, 0.05f), e(OpType.GLOW, 0.1f), e(OpType.BRIGHTNESS, 0.05f)),
        // --- hiệu ứng nghệ thuật
        "Pop-art" to listOf(e(OpType.POSTERIZE, 0.6f), e(OpType.SATURATION, 0.5f), e(OpType.CONTRAST, 0.3f)),
        "Pixel 8-bit" to listOf(e(OpType.PIXELATE, 0.5f), e(OpType.POSTERIZE, 0.5f), e(OpType.SATURATION, 0.3f)),
        "Bút chì" to listOf(e(OpType.SKETCH, 0.55f), e(OpType.CONTRAST, 0.1f)),
        "Chạm nổi" to listOf(e(OpType.EMBOSS, 0.7f), e(OpType.SATURATION, -0.3f)),
        "Glitch RGB" to listOf(e(OpType.CHROMA, 0.7f), e(OpType.CONTRAST, 0.2f), e(OpType.SATURATION, 0.15f), e(OpType.GRAIN, 0.2f)),
        "Tốc độ ngang" to listOf(EditOp(OpType.MOTION_BLUR, 0.7f, "0"), e(OpType.CONTRAST, 0.15f), st(215f, 0.25f, 40f, 0.2f)),
        "Zoom xuyên tâm" to listOf(e(OpType.RADIAL_BLUR, 0.6f), e(OpType.VIBRANCE, 0.3f), e(OpType.GLOW, 0.15f)),
        "Lục bảo" to listOf(hsl(band(3, 0.05f, 0.3f, -0.1f), band(4, -0.05f, 0.25f, -0.1f)), st(165f, 0.35f, 140f, 0.2f), e(OpType.CONTRAST, 0.15f), e(OpType.VIGNETTE, 0.2f))
    )

    val all: List<Pair<String, List<EditOp>>> = listOf(
        "Điện ảnh" to listOf(EditOp(OpType.CINEMATIC, 0.8f), EditOp(OpType.CONTRAST, 0.1f), EditOp(OpType.VIGNETTE, 0.25f)),
        "Vintage" to listOf(
            EditOp(OpType.SATURATION, -0.2f), EditOp(OpType.WARMTH, 0.3f), EditOp(OpType.CONTRAST, -0.1f),
            EditOp(OpType.SEPIA, 0.25f), EditOp(OpType.VIGNETTE, 0.4f), EditOp(OpType.GRAIN, 0.3f)
        ),
        "Đen trắng" to listOf(EditOp(OpType.GRAYSCALE, 1f), EditOp(OpType.CONTRAST, 0.15f), EditOp(OpType.CLARITY, 0.2f)),
        "Chân dung" to listOf(EditOp(OpType.FREQ_SEP, 0.55f), EditOp(OpType.AUTO_ENHANCE, 0.4f), EditOp(OpType.WARMTH, 0.1f)),
        "Phong cảnh" to listOf(
            EditOp(OpType.SATURATION, 0.25f), EditOp(OpType.CONTRAST, 0.15f),
            EditOp(OpType.AUTO_ENHANCE, 0.5f), EditOp(OpType.CLARITY, 0.3f)
        ),
        "Tươi sáng" to listOf(EditOp(OpType.BRIGHTNESS, 0.1f), EditOp(OpType.SATURATION, 0.2f), EditOp(OpType.AUTO_ENHANCE, 0.5f)),
        "Ấm áp" to listOf(EditOp(OpType.WARMTH, 0.4f), EditOp(OpType.SATURATION, 0.1f), EditOp(OpType.VIGNETTE, 0.2f)),
        "Lạnh" to listOf(EditOp(OpType.WARMTH, -0.4f), EditOp(OpType.CONTRAST, 0.1f)),
        "Teal & Orange" to listOf(
            EditOp(OpType.SPLIT_TONE, 1f, "185.0,0.550,28.0,0.550,0.000"), EditOp(OpType.CONTRAST, 0.12f), EditOp(OpType.SATURATION, 0.08f)
        ),
        "Hoàng hôn tím–vàng" to listOf(
            EditOp(OpType.SPLIT_TONE, 1f, "270.0,0.450,42.0,0.500,0.100"), EditOp(OpType.WARMTH, 0.12f), EditOp(OpType.VIGNETTE, 0.2f)
        ),
        "HDR" to listOf(
            EditOp(OpType.AUTO_ENHANCE, 0.8f), EditOp(OpType.SHADOWS, 0.5f), EditOp(OpType.CONTRAST, 0.2f),
            EditOp(OpType.CLARITY, 0.5f), EditOp(OpType.SATURATION, 0.2f)
        )
    ) + more + extra

    fun byName(name: String): List<EditOp>? = all.firstOrNull { it.first == name }?.second
}

internal fun opToJson(op: EditOp): JSONObject =
    JSONObject().put("op", op.type.key).put("value", op.value.toDouble()).apply { if (op.arg != null) put("arg", op.arg) }

internal fun opFromJson(o: JSONObject): EditOp? {
    val t = OpType.fromKey(o.optString("op")) ?: return null
    return EditOp(t, o.optDouble("value", 1.0).toFloat(), o.optString("arg", "").ifBlank { null })
}

internal fun maskToJson(m: LayerMask): JSONObject {
    val o = JSONObject().put("invert", m.invert).put("feather", m.feather.toDouble()).put("shift", m.shift.toDouble())
    when (val sp = m.spec) {
        is MaskSpec.Luminance -> o.put("t", "lum").put("lo", sp.lo.toDouble()).put("hi", sp.hi.toDouble())
        is MaskSpec.ColorRange -> o.put("t", "color").put("hue", sp.hue.toDouble()).put("tol", sp.tolerance.toDouble()).put("sat", sp.satMin.toDouble())
        is MaskSpec.Radial -> o.put("t", "radial").put("cx", sp.cx.toDouble()).put("cy", sp.cy.toDouble()).put("r", sp.radius.toDouble())
        is MaskSpec.Linear -> o.put("t", "linear").put("a", sp.angleDeg.toDouble()).put("p", sp.pos.toDouble())
        is MaskSpec.Channel -> o.put("t", "chan").put("sp", sp.space).put("ch", sp.channel).put("lo", sp.lo.toDouble()).put("hi", sp.hi.toDouble())
        is MaskSpec.Focus -> o.put("t", "focus").put("lo", sp.lo.toDouble()).put("hi", sp.hi.toDouble())
        is MaskSpec.Sky -> o.put("t", "sky").put("sens", sp.sensitivity.toDouble())
        is MaskSpec.Polygon -> {
            val a = JSONArray()
            sp.pts.forEach { a.put(it.x.toDouble()); a.put(it.y.toDouble()) }
            o.put("t", "polygon").put("pts", a)
        }
        is MaskSpec.Painted -> Unit // không chuyển giao được giữa các ảnh (đã lọc ở RecipeCodec.portable)
    }
    return o
}

internal fun maskFromJson(o: JSONObject): LayerMask? {
    val spec: MaskSpec = when (o.optString("t")) {
        "lum" -> MaskSpec.Luminance(o.optDouble("lo", 0.0).toFloat(), o.optDouble("hi", 1.0).toFloat())
        "color" -> MaskSpec.ColorRange(o.optDouble("hue", 0.0).toFloat(), o.optDouble("tol", 30.0).toFloat(), o.optDouble("sat", 0.1).toFloat())
        "radial" -> MaskSpec.Radial(o.optDouble("cx", 0.5).toFloat(), o.optDouble("cy", 0.5).toFloat(), o.optDouble("r", 0.3).toFloat())
        "linear" -> MaskSpec.Linear(o.optDouble("a", 90.0).toFloat(), o.optDouble("p", 0.5).toFloat())
        "chan" -> MaskSpec.Channel(o.optInt("sp", 0), o.optInt("ch", 0), o.optDouble("lo", 0.0).toFloat(), o.optDouble("hi", 1.0).toFloat())
        "focus" -> MaskSpec.Focus(o.optDouble("lo", 0.35).toFloat(), o.optDouble("hi", 1.0).toFloat())
        "sky" -> MaskSpec.Sky(o.optDouble("sens", 0.5).toFloat())
        "polygon" -> {
            val a = o.optJSONArray("pts") ?: return null
            if (a.length() < 6 || a.length() % 2 != 0 || a.length() > 2 * com.aiphoto.studio.engine.PolygonFill.MAX_POINTS) return null
            val pts = ArrayList<com.aiphoto.studio.engine.Pt>()
            var i = 0
            while (i < a.length()) {
                pts.add(com.aiphoto.studio.engine.Pt(a.optDouble(i, 0.0).toFloat().coerceIn(0f, 1f), a.optDouble(i + 1, 0.0).toFloat().coerceIn(0f, 1f)))
                i += 2
            }
            MaskSpec.Polygon(pts)
        }
        else -> return null
    }
    return LayerMask(spec, o.optBoolean("invert", false), o.optDouble("feather", 0.02).toFloat(), o.optDouble("shift", 0.0).toFloat())
}

/**
 * Mã hóa / giải mã công thức <-> JSON (thuần org.json, kiểm thử được trên JVM).
 * Lớp CHUYỂN GIAO được giữa các ảnh: không mặt nạ; mặt nạ tham số (độ sáng, dải màu, tròn, tuyến tính) lưu nguyên;
 * lớp theo vùng AI ([AdjustmentLayer.scope]: khuôn mặt, răng, bầu trời, chủ thể...) chỉ lưu tên vùng và được dựng lại mặt nạ riêng cho từng ảnh.
 * Mặt nạ tô tay không gắn vùng thì KHÔNG chuyển giao được (gắn với từng ảnh) nên bị bỏ.
 */
object RecipeCodec {
    fun portable(l: AdjustmentLayer): Boolean {
        val m = l.mask ?: return true
        return l.scope != null || m.spec !is MaskSpec.Painted
    }

    fun encode(layers: List<AdjustmentLayer>): JSONArray {
        val arr = JSONArray()
        for (l in layers) {
            if (!portable(l)) continue
            val ops = JSONArray()
            l.ops.forEach { ops.put(opToJson(it)) }
            val o = JSONObject().put("name", l.name).put("opacity", l.opacity.toDouble())
                .put("blend", l.blend.name).put("ops", ops)
            if (l.scope != null) o.put("scope", l.scope)
            val m = l.mask
            if (m != null && l.scope == null) o.put("mask", maskToJson(m))
            arr.put(o)
        }
        return arr
    }

    fun decode(arr: JSONArray): List<AdjustmentLayer> {
        val out = ArrayList<AdjustmentLayer>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ops = ArrayList<EditOp>()
            val oa = o.optJSONArray("ops") ?: JSONArray()
            for (j in 0 until oa.length()) opFromJson(oa.getJSONObject(j))?.let { ops.add(it) }
            val blend = runCatching { BlendMode.valueOf(o.optString("blend", "NORMAL")) }.getOrDefault(BlendMode.NORMAL)
            // mặt nạ có mặt nhưng không đọc được (hỏng / phiên bản mới hơn): BỎ lớp thay vì áp phép chỉnh lên toàn ảnh
            val mo = o.optJSONObject("mask")
            val mask = if (mo == null) null else (maskFromJson(mo) ?: continue)
            out.add(
                AdjustmentLayer(
                    id = 0L, name = o.optString("name", "Lớp"), ops = ops,
                    opacity = o.optDouble("opacity", 1.0).toFloat(), blend = blend,
                    mask = mask, kind = "recipe", scope = o.optString("scope", "").ifBlank { null }
                )
            )
        }
        return out
    }
}

/**
 * Công thức chỉnh sửa người dùng lưu lại (xem [RecipeCodec] về những lớp nào chuyển giao được) để dùng lại / áp dụng hàng loạt.
 * Lưu ở filesDir/recipes.json.
 */
class RecipeStore(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "recipes.json")

    private fun readAll(): JSONObject = runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject())

    fun names(): List<String> {
        val keys = readAll().keys()
        val out = ArrayList<String>()
        while (keys.hasNext()) out.add(keys.next())
        return out.sorted()
    }

    fun get(name: String): List<AdjustmentLayer>? {
        val arr = readAll().optJSONArray(name) ?: return null
        val out = RecipeCodec.decode(arr)
        return if (out.isEmpty()) null else out
    }

    fun save(name: String, layers: List<AdjustmentLayer>) {
        val root = readAll()
        root.put(name, RecipeCodec.encode(layers))
        file.writeText(root.toString())
    }

    fun delete(name: String) {
        val root = readAll()
        root.remove(name)
        file.writeText(root.toString())
    }
}
