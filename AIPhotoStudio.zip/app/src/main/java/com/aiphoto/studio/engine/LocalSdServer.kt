package com.aiphoto.studio.engine

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Chạy stable-diffusion.cpp (giấy phép MIT) dạng tiến trình con `sd-server` TRÊN ĐIỆN THOẠI, chỉ lắng nghe 127.0.0.1.
 * `sd-server` nói giao thức giống AUTOMATIC1111 (`/sdapi/v1/img2img`) nên không cần JNI. Tệp thực thi được CI biên dịch bằng NDK
 * (arm64) và đóng gói thành `libsd_server.so` trong APK; app chạy trực tiếp từ thư mục thư viện native (cần `useLegacyPackaging`).
 *
 * Cờ dòng lệnh đã đối chiếu với mã nguồn upstream (examples/server/runtime.cpp) qua gói của bản phân phối Linux:
 * `-m/--model`, `-t/--threads`, `--listen-ip` (mặc định 127.0.0.1), `--listen-port`, `--lora-model-dir`.
 * Mẫu lệnh có thể được thay từ xa bằng tham số `cmd` trong cấu hình định tuyến phòng khi cờ đổi ở bản mới.
 */
class LocalSdServer(private val ctx: Context) {

    companion object {
        const val PORT = 18188
        private const val DEFAULT_CMD =
            "{bin} -m {model} --listen-ip 127.0.0.1 --listen-port {port} -t {threads} {lora_arg}"
    }

    @Volatile private var proc: Process? = null
    @Volatile private var runningModel: String? = null
    private val logTail = ArrayDeque<String>()

    fun binary(): File = File(ctx.applicationInfo.nativeLibraryDir, "libsd_server.so")

    fun binaryPresent(): Boolean = binary().exists()

    fun isRunning(): Boolean = proc?.isAlive == true

    private fun tail(): String = synchronized(logTail) { logTail.takeLast(6).joinToString(" | ") }

    private fun healthy(): Boolean = try {
        val c = URL("http://127.0.0.1:$PORT/sdapi/v1/sd-models").openConnection() as HttpURLConnection
        c.connectTimeout = 800
        c.readTimeout = 1500
        val ok = c.responseCode in 200..299
        c.disconnect()
        ok
    } catch (e: Throwable) {
        false
    }

    /** Bật tiến trình nếu chưa chạy với đúng model này; chờ tới khi nhận được yêu cầu (nạp model có thể mất vài chục giây). */
    @Synchronized
    fun ensureRunning(
        modelPath: String, threads: Int, loraDir: String?, extraDir: String?, cmdTemplate: String?, timeoutMs: Long = 180_000
    ) {
        val key = modelPath + "|" + cmdTemplate.orEmpty()
        val running = proc
        if (running != null && running.isAlive && runningModel == key && healthy()) return
        stop()

        val bin = binary()
        check(bin.exists()) { "APK này chưa kèm sd-server (job build-sd-server của CI chưa tạo được tệp)." }
        val template = cmdTemplate?.takeIf { it.isNotBlank() } ?: DEFAULT_CMD
        val cmd = template
            .replace("{bin}", bin.absolutePath)
            .replace("{model}", modelPath)
            .replace("{port}", PORT.toString())
            .replace("{threads}", threads.toString())
            .replace("{lora_arg}", if (loraDir != null) "--lora-model-dir $loraDir" else "")
            .replace("{lora_dir}", loraDir.orEmpty())
            .replace("{extra_dir}", extraDir.orEmpty())
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }

        synchronized(logTail) { logTail.clear() }
        val p = ProcessBuilder(cmd).redirectErrorStream(true).directory(ctx.filesDir).start()
        proc = p
        runningModel = key
        thread(isDaemon = true, name = "sd-server-log") {
            try {
                p.inputStream.bufferedReader().forEachLine { line ->
                    synchronized(logTail) {
                        logTail.addLast(line)
                        if (logTail.size > 40) logTail.removeFirst()
                    }
                }
            } catch (e: Throwable) { }
        }

        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (!p.isAlive) {
                val code = try { p.exitValue() } catch (e: Throwable) { -1 }
                stop()
                throw IllegalStateException("sd-server dừng sớm (mã $code): ${tail()}")
            }
            if (healthy()) return
            Thread.sleep(500)
        }
        stop()
        throw IllegalStateException("sd-server không sẵn sàng sau ${timeoutMs / 1000}s: ${tail()}")
    }

    @Synchronized
    fun stop() {
        val p = proc
        proc = null
        runningModel = null
        if (p != null) {
            try { p.destroy() } catch (e: Throwable) { }
            thread(isDaemon = true) {
                try { Thread.sleep(2000); if (p.isAlive) p.destroyForcibly() } catch (e: Throwable) { }
            }
        }
    }
}
