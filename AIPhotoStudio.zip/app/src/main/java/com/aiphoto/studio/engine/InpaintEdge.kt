package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min

/**
 * Xử lý RÌA vùng lấp dùng chung cho các engine xóa vật thể (cổ điển, LaMa; MI-GAN và dịch vụ sinh ảnh qua [RegionCrop.composite]).
 *
 * Hai chế độ:
 *  - THƯỜNG (exact = false): nới vùng trống ra `grow` điểm (nuốt viền răng cưa / bóng đổ / quầng sáng quanh vật thể) rồi hòa mép
 *    `featherRadius` điểm với nội dung cũ → ít lộ đường nối nhất, nhưng vùng bị đổi RỘNG HƠN nét tô vài điểm ảnh.
 *  - CHÍNH XÁC (exact = true): vùng trống = ĐÚNG mặt nạ, rìa thay hẳn (không hòa) → điểm ngoài mặt nạ giữ nguyên từng bit
 *    (dùng khi người dùng muốn chỉ đổi đúng chỗ đã tô; mở rộng ảnh dùng để không đụng vào ảnh gốc). Đổi lại: nếu mặt nạ tô hụt
 *    viền của vật thể thì viền đó còn sót lại.
 */
internal object InpaintEdge {

    /** [hole] = điểm cần lấp trong khung cắt; [alpha] = độ thay thế 0..1 từng điểm (1 = lấy hoàn toàn nội dung mới). */
    class Edge(val hole: BooleanArray, val alpha: FloatArray)

    /**
     * Dựng vùng trống + độ hòa trong khung cắt (x0, y0, cw, ch) của ảnh rộng [w].
     * Chế độ thường giữ NGUYÊN công thức cũ (Gauss nới + ngưỡng 10 + Gauss hòa mép) nên kết quả không đổi so với trước.
     */
    fun build(mask: ByteArray, w: Int, x0: Int, y0: Int, cw: Int, ch: Int, grow: Int, featherRadius: Int, exact: Boolean): Edge {
        val n = cw * ch
        if (exact) {
            val hole = BooleanArray(n) { mask[(y0 + it / cw) * w + (x0 + it % cw)].toInt() != 0 }
            return Edge(hole, FloatArray(n) { if (hole[it]) 1f else 0f })
        }
        val gray = IntArray(n) { i ->
            if (mask[(y0 + i / cw) * w + (x0 + i % cw)].toInt() != 0) -1 else (255 shl 24)
        }
        val grown = Blur.gaussian(gray, cw, ch, grow)
        val hole = BooleanArray(n) { (grown[it] and 255) > 10 }
        val holeGray = IntArray(n) { if (hole[it]) -1 else (255 shl 24) }
        val feather = Blur.gaussian(holeGray, cw, ch, featherRadius)
        return Edge(hole, FloatArray(n) { (feather[it] and 255) / 255f })
    }

    /** Trộn [fill] (cw×ch) vào [dst] (ảnh rộng [w]) tại (x0, y0) theo [alpha]. Giữ kênh alpha của ảnh gốc. */
    fun paste(dst: IntArray, w: Int, x0: Int, y0: Int, cw: Int, ch: Int, fill: IntArray, alpha: FloatArray) {
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                val a = alpha[y * cw + x]
                if (a <= 0.003f) continue
                val i = (y0 + y) * w + (x0 + x)
                val o = dst[i]
                val f = fill[y * cw + x]
                if (a >= 1f) {
                    dst[i] = (o and (0xFF shl 24)) or (f and 0xFFFFFF)
                    continue
                }
                val r = (((o shr 16) and 255) * (1f - a) + ((f shr 16) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                val g = (((o shr 8) and 255) * (1f - a) + ((f shr 8) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                val b = ((o and 255) * (1f - a) + (f and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                dst[i] = (o and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
            }
        }
    }

    /**
     * Thu mặt nạ khung cắt (cw×ch) về kích thước đầu vào model (mw×mh) sao cho KHÔNG làm rớt nét mảnh: điểm model nào phủ
     * BẤT KỲ điểm trống nào của ảnh gốc đều là trống. (Lấy mẫu "gần nhất" có thể bỏ sót nét tô mảnh khi thu nhỏ nhiều lần; ở
     * chế độ chính xác không có phần nới để bù, và điểm bị sót sẽ được model "giữ nguyên" = dán lại chính vật thể.)
     * Mọi điểm trống của ảnh gốc luôn rơi vào ít nhất một điểm trống của kết quả (cả khi thu nhỏ lẫn phóng to).
     */
    fun shrinkAny(hole: BooleanArray, cw: Int, ch: Int, mw: Int, mh: Int): BooleanArray {
        val out = BooleanArray(mw * mh)
        for (ty in 0 until mh) {
            val sy0 = (ty.toLong() * ch / mh).toInt()
            val sy1 = min(ch, max(sy0 + 1, ((ty + 1).toLong() * ch + mh - 1).div(mh).toInt()))
            for (tx in 0 until mw) {
                val sx0 = (tx.toLong() * cw / mw).toInt()
                val sx1 = min(cw, max(sx0 + 1, ((tx + 1).toLong() * cw + mw - 1).div(mw).toInt()))
                var any = false
                var sy = sy0
                while (sy < sy1 && !any) {
                    val row = sy * cw
                    var sx = sx0
                    while (sx < sx1) {
                        if (hole[row + sx]) { any = true; break }
                        sx++
                    }
                    sy++
                }
                out[ty * mw + tx] = any
            }
        }
        return out
    }
}
