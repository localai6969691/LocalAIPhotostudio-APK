package com.aiphoto.studio.util

import android.content.Intent
import android.speech.RecognizerIntent
import com.aiphoto.studio.ai.VoiceInput

/**
 * Dựng / đọc Intent của hộp nhận dạng giọng nói CỦA HỆ THỐNG (R35, xem [VoiceInput]).
 * Không cần quyền micro: hộp thoại thu âm do dịch vụ nhận dạng của hệ thống hiển thị, app chỉ nhận lại danh sách chữ đã chép.
 * Lưu ý quyền riêng tư: dịch vụ nhận dạng (thường là Google) có thể gửi âm thanh lên máy chủ của nó — việc này nằm ngoài app, đã ghi ở Trợ giúp.
 */
object VoiceIntents {
    /** [languageTag] = thẻ BCP-47 từ [VoiceInput.languageTag]; [promptText] = dòng nhắc hiện trong hộp thoại (đã dịch). */
    fun recognize(languageTag: String, promptText: String): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, promptText)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, VoiceInput.MAX_RESULTS)
        return i
    }

    /** Các bản chép (đã xếp theo độ tin cậy giảm dần) trong kết quả của hộp thoại; null nếu không có. */
    fun results(data: Intent?): List<String>? = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
}
