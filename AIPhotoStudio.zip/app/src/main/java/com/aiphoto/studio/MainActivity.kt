package com.aiphoto.studio

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import com.aiphoto.studio.i18n.I18n
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import com.aiphoto.studio.ui.EditorScreen
import com.aiphoto.studio.util.CrashHandler
import com.aiphoto.studio.util.CrashStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // R24: ghi lại lỗi làm app đóng đột ngột để lần mở sau hiện hộp thoại "Gửi thông tin lỗi" (rồi vẫn để hệ thống xử lý như cũ)
        CrashHandler.install(CrashStore.at(filesDir))
        // R31: Android 15+ BẮT BUỘC vẽ tràn viền (edge-to-edge) với ứng dụng nhắm API 35+ — và Google Play đòi nhắm API 36 từ 31/8/2026.
        // Làm đồng nhất ở MỌI mức API (kể cả bản tester đang nhắm 34): thanh hệ thống trong suốt, chữ/biểu tượng sáng (giao diện tối), còn
        // nội dung được đệm theo `safeDrawing` (thanh trạng thái + thanh điều hướng + khuyết màn hình + bàn phím) để không bị che.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        I18n.init(this)   // R33: nạp ngôn ngữ đã chọn (hoặc theo hệ thống) trước khi vẽ giao diện
        setContent {
            // R33: tiếng Ả Rập viết từ phải sang trái ⇒ đảo hướng bố cục; I18n.active là state nên đổi ngôn ngữ áp dụng ngay
            CompositionLocalProvider(LocalLayoutDirection provides (if (I18n.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        Box(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                            EditorScreen()
                        }
                    }
                }
            }
        }
    }
}
