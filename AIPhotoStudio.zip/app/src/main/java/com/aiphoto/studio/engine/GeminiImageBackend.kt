package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * THÊM / THAY vật thể bằng API Gemini image (họ "Nano Banana": gemini-3.1-flash-image, gemini-3-pro-image…).
 *
 * Kết hợp cloud + cục bộ:
 *  - Cục bộ: cắt vùng quanh mặt nạ (đỡ gửi cả ảnh lớn, vật thể sinh ra nét hơn), gửi ảnh + mặt nạ,
 *  - Cloud: sinh ảnh theo chỉ dẫn,
 *  - Cục bộ: dán kết quả về đúng vùng mặt nạ (làm mềm biên) -> phần còn lại của ảnh giữ nguyên điểm ảnh gốc.
 *
 * LƯU Ý QUYỀN RIÊNG TƯ: phần ảnh được cắt (kèm ngữ cảnh) và mặt nạ được gửi tới Google. API key lưu trong SharedPreferences
 * riêng của app (chưa mã hóa).
 */
class GeminiImageBackend(private val apiKey: String, model: String) : GenerativeFill {

    companion object {
        const val DEFAULT_MODEL = "gemini-3.1-flash-image"
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
        private const val SEND_LONG_SIDE = 1024
    }

    private val model = model.trim().ifEmpty { DEFAULT_MODEL }
    @Volatile private var conn: HttpURLConnection? = null

    override fun cancel() {
        try { conn?.disconnect() } catch (e: Throwable) { }
    }

    fun ping(): String {
        val text = request("GET", model, null, 20_000)
        val name = JSONObject(text).optString("displayName", model)
        return "Khóa hợp lệ - model: $name ($model)"
    }

    override fun inpaint(image: Bitmap, mask: ByteArray, prompt: String, size: Int, opts: GenOptions): Bitmap {
        val avoid = if (opts.negative.isNotBlank()) " Avoid: ${opts.negative}." else ""
        val w = image.width
        val h = image.height
        val rect = RegionCrop.compute(mask, w, h) ?: return image

        // 1. Cắt vùng làm việc và thu về tối đa ~1024px để gửi
        val crop = Bitmap.createBitmap(image, rect.x, rect.y, rect.w, rect.h)
        val scale = min(1f, SEND_LONG_SIDE.toFloat() / max(rect.w, rect.h))
        val sw = max(1, (rect.w * scale).roundToInt())
        val sh = max(1, (rect.h * scale).roundToInt())
        val sendImg = if (scale < 1f) Bitmap.createScaledBitmap(crop, sw, sh, true) else crop

        val maskPx = RegionCrop.maskGray(mask, w, rect)
        val maskFull = Bitmap.createBitmap(rect.w, rect.h, Bitmap.Config.ARGB_8888)
        maskFull.setPixels(maskPx, 0, rect.w, 0, 0, rect.w, rect.h)
        val sendMask = if (scale < 1f) Bitmap.createScaledBitmap(maskFull, sw, sh, true) else maskFull

        // 2. Gọi API
        val instruction =
            "You are a precise photo editor. The first image is the photo. The second image is a mask: " +
            "the WHITE area is the only region you may change; every pixel in the BLACK area must stay exactly as it is. " +
            "Task for the white area: $prompt.$avoid " +
            "If the task is to remove something, fill the white area with a natural continuation of the surrounding background. " +
            "If it is to add or replace something, make it photorealistic and match the photo's lighting, perspective, " +
            "shadows, colors and grain. Return the edited photo with the same framing and aspect ratio as the first image."

        val parts = JSONArray()
            .put(JSONObject().put("text", instruction))
            .put(inline(sendImg))
            .put(inline(sendMask))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
            )
        val text = request("POST", "$model:generateContent", body.toString(), 180_000)

        // 3. Lấy ảnh trả về
        val root = JSONObject(text)
        var b64: String? = null
        var note = ""
        val cands = root.optJSONArray("candidates")
        if (cands != null) {
            for (i in 0 until cands.length()) {
                val ps = cands.getJSONObject(i).optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (d != null && d.optString("data").isNotEmpty()) {
                        b64 = d.optString("data")
                        break
                    }
                    if (p.has("text")) note = p.optString("text")
                }
                if (b64 != null) break
            }
        }
        if (b64 == null) {
            val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            val why = when {
                block.isNotEmpty() -> "bị chặn ($block)"
                note.isNotBlank() -> note.take(160)
                else -> "không có ảnh trong phản hồi"
            }
            throw IOException("Dịch vụ không trả ảnh: $why")
        }
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val result = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IOException("Không giải mã được ảnh trả về")

        // 4. Đưa về đúng khung vùng cắt rồi dán theo mặt nạ
        val generated = Bitmap.createScaledBitmap(result, rect.w, rect.h, true)
        return RegionCrop.composite(image, mask, rect, generated)
    }

    private fun inline(b: Bitmap): JSONObject {
        val bytes = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        return JSONObject().put(
            "inlineData",
            JSONObject().put("mimeType", "image/png").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
        )
    }

    private fun request(method: String, path: String, json: String?, readTimeoutMs: Int): String {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = readTimeoutMs
            c.setRequestProperty("x-goog-api-key", apiKey)
            if (json != null) {
                val data = json.toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setFixedLengthStreamingMode(data.size)
                c.outputStream.use { it.write(data) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val hint = when (code) {
                    400 -> " (kiểm tra tên model / yêu cầu)"
                    401, 403 -> " (API key sai hoặc chưa được cấp quyền)"
                    404 -> " (tên model không tồn tại)"
                    429 -> " (hết hạn mức hoặc gọi quá nhanh)"
                    else -> ""
                }
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault(text.take(200))
                throw IOException("Gemini trả mã $code$hint: ${msg.take(200)}")
            }
            return text
        } finally {
            c.disconnect()
            if (conn === c) conn = null
        }
    }
}
