package com.aiphoto.studio.engine

import kotlin.math.abs

/**
 * Đũa thần (Magic Wand) cổ điển: chọn vùng LIỀN KỀ có màu gần màu tại điểm chạm.
 * Dùng làm đường dự phòng cho "Chạm chọn" khi chưa nạp MobileSAM (nguyên tắc "mọi tác vụ AI đều có fallback" trong PDF).
 * Thuần Kotlin, không phụ thuộc Android.
 */
object MagicWand {

    /**
     * [px] ARGB (w*h); (sx, sy) là điểm chạm theo điểm ảnh; [tolerance] = sai khác TRUNG BÌNH ba kênh màu so với màu tại
     * điểm chạm (trung bình 5x5 để bớt nhiễu), 0..255, mặc định 28. So với màu cố định tại điểm chạm (không trôi theo
     * dải chuyển sắc nên không "chảy" sang vùng khác). Trả về mặt nạ 0/255 kích thước w*h.
     */
    fun select(px: IntArray, w: Int, h: Int, sx: Int, sy: Int, tolerance: Int = 28): ByteArray {
        val out = ByteArray(w * h)
        if (w <= 0 || h <= 0 || px.size < w * h) return out
        val x0 = sx.coerceIn(0, w - 1)
        val y0 = sy.coerceIn(0, h - 1)

        var sr = 0
        var sg = 0
        var sb = 0
        var n = 0
        for (dy in -2..2) {
            for (dx in -2..2) {
                val p = px[(y0 + dy).coerceIn(0, h - 1) * w + (x0 + dx).coerceIn(0, w - 1)]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
                n++
            }
        }
        val r0 = sr / n
        val g0 = sg / n
        val b0 = sb / n
        val limit = tolerance.coerceIn(0, 255) * 3

        val queue = IntArray(w * h)
        var head = 0
        var tail = 0
        val start = y0 * w + x0
        out[start] = 255.toByte()
        queue[tail++] = start
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            // 4 láng giềng: trái, phải, trên, dưới
            if (x > 0) tail = visit(px, out, queue, tail, i - 1, r0, g0, b0, limit)
            if (x < w - 1) tail = visit(px, out, queue, tail, i + 1, r0, g0, b0, limit)
            if (y > 0) tail = visit(px, out, queue, tail, i - w, r0, g0, b0, limit)
            if (y < h - 1) tail = visit(px, out, queue, tail, i + w, r0, g0, b0, limit)
        }
        return out
    }

    private fun visit(
        px: IntArray, out: ByteArray, queue: IntArray, tail: Int, j: Int,
        r0: Int, g0: Int, b0: Int, limit: Int
    ): Int {
        if (out[j].toInt() != 0) return tail
        val p = px[j]
        val d = abs(((p shr 16) and 255) - r0) + abs(((p shr 8) and 255) - g0) + abs((p and 255) - b0)
        if (d > limit) return tail
        out[j] = 255.toByte()
        queue[tail] = j
        return tail + 1
    }
}
