package com.aiphoto.studio.util

/**
 * R42: logic THUẦN (kiểm bằng JUnit, không phụ thuộc Android) cho KÉO-THẢ ảnh từ ứng dụng khác vào app — ví dụ trình quản lý tệp mở ở cửa sổ nhỏ /
 * chia đôi màn hình. Phần dính Android nằm ở [ImageDropTarget].
 *
 * Quy tắc nhận một mục: MIME dạng `image/…` (image/jpeg, image/png…) thì nhận; MIME rỗng hoặc chung chung (kiểu "mọi loại" `*` hoặc `application/octet-stream`) thì dựa vào ĐUÔI tên tệp;
 * MIME cụ thể mà không phải ảnh (video, pdf, văn bản…) thì loại dù tên có đuôi .jpg — nhà cung cấp biết rõ hơn cái tên.
 */
object ImageDrop {
    /** Đuôi tệp ảnh app thử mở (giải mã bằng bộ giải mã của hệ thống; định dạng máy không giải mã được sẽ báo lỗi mở ảnh như bình thường). */
    private val EXT = setOf("jpg", "jpeg", "jpe", "png", "webp", "heic", "heif", "avif", "bmp", "gif")

    /** Một mục thả vào: [uri] (kiểu bất kỳ để test không cần Android), MIME do nhà cung cấp báo (có thể null), tên tệp nếu biết. */
    class Item<T>(val uri: T, val mime: String?, val name: String?)

    fun isImageMime(mime: String?): Boolean = mime != null && mime.trim().startsWith("image/", ignoreCase = true)

    /** MIME không nói được gì về nội dung (null / rỗng / kiểu "mọi loại" / octet-stream). */
    fun isGenericMime(mime: String?): Boolean {
        val m = mime?.trim()?.lowercase() ?: return true
        return m.isEmpty() || m == "*/*" || m == "application/octet-stream" || m == "binary/octet-stream"
    }

    fun isImageName(name: String?): Boolean {
        val n = name?.trim() ?: return false
        val dot = n.lastIndexOf('.')
        if (dot < 0 || dot == n.length - 1) return false
        return n.substring(dot + 1).lowercase() in EXT
    }

    /**
     * Lúc BẮT ĐẦU kéo mới chỉ biết danh sách MIME của clip: có thể chứa ảnh nếu có MIME dạng `image/…`, MIME chung chung, hoặc `text/uri-list`
     * (nhà cung cấp không báo được kiểu thì clip mang MIME này). Danh sách rỗng ⇒ không nhận.
     */
    fun mayContainImage(mimes: List<String>): Boolean =
        mimes.any { isImageMime(it) || (it.isNotBlank() && isGenericMime(it)) || it.trim().equals("text/uri-list", ignoreCase = true) }

    /** Một mục có phải ảnh để mở không (xem quy tắc ở đầu tệp). */
    fun accepts(mime: String?, name: String?): Boolean = when {
        isImageMime(mime) -> true
        isGenericMime(mime) -> isImageName(name)
        else -> false
    }

    /** Lọc các mục ảnh, GIỮ NGUYÊN THỨ TỰ thả. */
    fun <T> pickImages(items: List<Item<T>>): List<T> = items.filter { accepts(it.mime, it.name) }.map { it.uri }
}
