package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min

/** Làm mờ Gauss xấp xỉ bằng 3 lần box blur (O(n) mỗi lần, không phụ thuộc bán kính). Giữ nguyên kênh alpha. */
object Blur {

    fun gaussian(src: IntArray, w: Int, h: Int, radius: Int): IntArray {
        if (radius < 1) return src.copyOf()
        var a = src.copyOf()
        var b = IntArray(w * h)
        val tmp = IntArray(w * h)
        repeat(3) {
            horizontal(a, tmp, w, h, radius)
            vertical(tmp, b, w, h, radius)
            val t = a; a = b; b = t
        }
        return a
    }

    private fun horizontal(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[row + min(max(i, 0), w - 1)]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (x in 0 until w) {
                val alpha = src[row + x] ushr 24
                dst[row + x] = (alpha shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[row + min(x + r + 1, w - 1)]
                val sub = src[row + max(x - r, 0)]
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }

    private fun vertical(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[min(max(i, 0), h - 1) * w + x]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (y in 0 until h) {
                val alpha = src[y * w + x] ushr 24
                dst[y * w + x] = (alpha shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[min(y + r + 1, h - 1) * w + x]
                val sub = src[max(y - r, 0) * w + x]
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }
}
