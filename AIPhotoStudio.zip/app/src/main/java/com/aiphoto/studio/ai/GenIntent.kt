package com.aiphoto.studio.ai

import java.text.Normalizer
import java.util.Locale

enum class GenKind { REMOVE, FILL, CLONE }

/**
 * Nhận biết yêu cầu "thêm / thay / xóa vật thể" (tạo sinh) so với chỉnh sửa thường.
 *  - Đã tô vùng: prompt trống hoặc có "xóa/remove" -> REMOVE; còn lại -> FILL (thêm/thay vật thể).
 *  - Chưa tô vùng: chỉ coi là tạo sinh khi có từ khóa xóa/thêm/thay; vị trí lấy từ "bên trái/phải/giữa…".
 */
object GenIntent {

    private val BG_OR_SKIN = listOf(
        "xoa nen", "xoa phong", "tach nen", "tach phong", "bo nen", "bo phong", "xoa background",
        "remove background", "remove bg", "mo phong", "mo nen", "anh the"
    )
    private val BG_SWAP_KEYS = listOf("thay nen", "doi nen", "thay phong", "doi phong", "change background", "replace background")
    private val SKIN_ONLY = listOf("xoa mun", "tri mun")
    // Chuyển phong cách tranh (sơn dầu / hoạt hình / màu nước...) là chỉnh CẢ ảnh (OpType.STYLE hoặc WholeEditIntent), không phải thêm vật thể ("biến thành" ≠ FILL)
    private val STYLE_CONVERT = listOf("phong cach", "son dau", "oil painting", "oil paint", "hoat hinh", "cartoon", "mau nuoc", "watercolor", "watercolour", "water color", "style of")
    // Mở rộng KHUNG ảnh (outpainting) là phép hình học đi đường chỉnh thường (RuleBasedPlanner), không phải tạo vật thể
    private val EXTEND_FRAME = listOf("mo rong", "keo dai", "outpaint", "uncrop", "extend", "expand", "widen", "zoom out")

    // Chỉnh theo VÙNG khuôn mặt (răng, quầng thâm...) - không phải xóa/thêm vật thể, nên đi đường chỉnh thường (RuleBasedPlanner/Scope)
    private val FACE_SCOPED = listOf(
        "quang tham", "bong mat", "tham mat", "dark circle", "dark circles", "under eye", "under eyes", "eye bag", "eye bags", "eyebag",
        "trang rang", "rang trang", "whiten", "teeth", "tooth", "noi khoi", "tao khoi", "contour", "sculpt", "dodge burn"
    )
    private val REMOVE = listOf("xoa", "loai bo", "go bo", "bo di", "remove", "erase", "delete", "clean up", "get rid")
    private val FILL = listOf("them", "chen", "add", "insert", "put", "place", "doi thanh", "thay", "replace", "bien thanh", "turn into")

    // "xóa chính xác / xóa đúng vùng tô / erase exactly": chỉ đổi đúng điểm đã tô (không nới, không hòa mép)
    private val EXACT_PHRASES = listOf(
        "chinh xac", "dung vung to", "dung vung chon", "dung vung", "dung cho to", "dung net to", "dung theo net to", "chi vung to",
        "chi xoa vung to", "exactly", "exact", "precisely", "precise", "only the painted area", "only painted area", "just the painted area"
    )

    private fun stripExact(t: String): String {
        var r = t
        for (k in EXACT_PHRASES) r = r.replace(Regex("(?<![a-z0-9])" + Regex.escape(k) + "(?![a-z0-9])"), " ")
        return r.replace(Regex("\\s+"), " ").trim()
    }

    /** Người dùng đòi xóa CHÍNH XÁC vùng đã tô (xem [EXACT_PHRASES]). Chỉ có nghĩa khi đang xóa vật thể. */
    fun wantsExact(prompt: String): Boolean {
        val t = fold(prompt)
        return EXACT_PHRASES.any { has(t, it) }
    }

    fun fold(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun has(t: String, key: String): Boolean =
        Regex("(?<![a-z0-9])" + Regex.escape(key) + "(?![a-z0-9])").containsMatchIn(t)

    fun detect(prompt: String, hasMask: Boolean): GenKind? {
        val t = fold(prompt)
        if (BG_OR_SKIN.any { has(t, it) }) return null
        // "thay nền thành bãi biển" / "đặt tôi vào bãi biển": thay NỀN (không phải thêm vật thể vào vùng tô) → MainViewModel.run xử lý riêng;
        // nền màu trơn ("đổi nền thành màu trắng") đi đường tách nền ở RuleBasedPlanner
        if (!hasMask && (BackgroundScene.isBackgroundSwap(prompt) || BG_SWAP_KEYS.any { has(t, it) })) return null
        if (!hasMask && EXTEND_FRAME.any { has(t, it) }) return null
        if (!hasMask && SKIN_ONLY.any { has(t, it) }) return null
        if (!hasMask && STYLE_CONVERT.any { has(t, it) }) return null
        if (!hasMask && FACE_SCOPED.any { has(t, it) }) return null
        // "làm bầu trời xanh hơn" là chỉnh màu vùng trời; còn "xóa chim trên bầu trời" / "thay bầu trời" vẫn là tạo sinh
        if (!hasMask && (has(t, "bau troi") || has(t, "sky")) &&
            REMOVE.none { has(t, it) } && FILL.none { has(t, it) }
        ) return null
        // chữ chỉ độ chính xác ("chính xác", "đúng vùng tô") không phải mô tả vật thể: bỏ đi rồi mới phân loại xóa / thêm
        if (hasMask) {
            val core = stripExact(t)
            return if (core.isEmpty() || REMOVE.any { has(core, it) }) GenKind.REMOVE else GenKind.FILL
        }
        if (t.isEmpty()) return null
        if (REMOVE.any { has(t, it) }) return GenKind.REMOVE
        if (FILL.any { has(t, it) }) return GenKind.FILL
        return null
    }

    /** Vị trí gợi ý trong prompt -> (cx, cy) chuẩn hóa 0..1, hoặc null nếu không nêu vị trí. */
    fun regionHint(prompt: String): Pair<Float, Float>? {
        val t = fold(prompt)
        val x = when {
            has(t, "trai") || has(t, "left") -> 0.25f
            has(t, "phai") || has(t, "right") -> 0.75f
            has(t, "giua") || has(t, "trung tam") || has(t, "center") || has(t, "middle") -> 0.5f
            else -> null
        }
        val y = when {
            has(t, "tren") || has(t, "top") -> 0.25f
            has(t, "duoi") || has(t, "bottom") -> 0.75f
            else -> null
        }
        if (x == null && y == null) return null
        return Pair(x ?: 0.5f, y ?: 0.55f)
    }
}
