package com.aiphoto.studio.routing

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class Tier { LOW, MID, HIGH }

/**
 * Hồ sơ hiệu năng theo thiết bị để app chạy mượt trên MỌI dòng máy: kích thước ảnh làm việc, kích thước xem trước
 * (cao khi thả tay, thấp khi đang kéo thanh trượt), số luồng ONNX, bộ tăng tốc muốn thử.
 * Hồ sơ thật do [derive] suy ra từ phép đo máy (R30g); [from] (bảng theo RAM) chỉ là giá trị khởi đầu trước khi đo xong. Có thể ghi đè từ xa bằng mục "perf" trong cấu hình định tuyến (không cần phát hành lại app).
 */
data class PerfProfile(
    val tier: Tier,
    val maxSide: Int,
    val previewHi: Int,
    val previewLo: Int,
    val threads: Int,
    val accel: List<String>,
    val poolCapacity: Int = 4
) {
    fun describe(): String =
        "Hạng ${tier.name}: ảnh ≤${maxSide}px, xem trước ${previewHi}px (kéo: ${previewLo}px), ${threads} luồng, hồ model ${poolCapacity}, " +
            "tăng tốc: ${if (accel.isEmpty()) "CPU" else accel.joinToString(",")}"

    companion object {
        /**
         * Hồ sơ SUY RA từ số đo thật của máy ([PerfMeasure], do `PerfCalibrator` đo) thay cho bảng ba hạng theo tổng RAM của [from]: kích thước xem trước theo ngân sách thời gian
         * (khung hình của màn hình + ngưỡng "tức thì"), cạnh làm việc theo ngân sách áp dụng và heap còn trống, hồ model theo RAM còn trống. [overrides] từ cấu hình định tuyến
         * vẫn áp dụng (khóa theo tên hạng suy ra). Công thức và hằng số: [PerfModel].
         */
        fun derive(d: DeviceInfo, m: PerfMeasure, overrides: Map<String, Map<String, String>>): PerfProfile {
            val maxSide = PerfModel.maxSide(m)
            val hi = min(PerfModel.previewHi(m), maxSide)
            val lo = min(PerfModel.previewLo(m), hi)
            val base = PerfProfile(PerfModel.tierOf(maxSide), maxSide, hi, lo, PerfModel.threads(d.cores), emptyList(), PerfModel.poolSlots(m.availMb))
            return applyOverrides(base, overrides)
        }

        private fun applyOverrides(base: PerfProfile, overrides: Map<String, Map<String, String>>): PerfProfile {
            val o = overrides[base.tier.name.lowercase()] ?: return base
            return base.copy(
                maxSide = o["maxSide"]?.toIntOrNull()?.coerceIn(1024, 4096) ?: base.maxSide,
                previewHi = o["previewHi"]?.toIntOrNull()?.coerceIn(512, 2048) ?: base.previewHi,
                previewLo = o["previewLo"]?.toIntOrNull()?.coerceIn(320, 1024) ?: base.previewLo,
                threads = o["threads"]?.toIntOrNull()?.coerceIn(1, 8) ?: base.threads,
                poolCapacity = o["pool"]?.toIntOrNull()?.coerceIn(1, 12) ?: base.poolCapacity,
                accel = o["accel"]?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: base.accel
            )
        }

        /** Bảng theo tổng RAM: CHỈ là giá trị KHỞI ĐẦU trước khi app đo xong máy (và cho các bài kiểm cũ); hồ sơ thật dùng [derive]. */
        fun from(d: DeviceInfo, overrides: Map<String, Map<String, String>>): PerfProfile {
            val tier = when {
                d.ramMb < 3500 -> Tier.LOW
                d.ramMb < 7000 -> Tier.MID
                else -> Tier.HIGH
            }
            val base = when (tier) {
                Tier.LOW -> PerfProfile(tier, 1536, 768, 448, min(d.cores, 3), emptyList(), 2)
                Tier.MID -> PerfProfile(tier, 2048, 1024, 576, min(d.cores, 4), emptyList(), 4)
                Tier.HIGH -> PerfProfile(tier, 2560, 1280, 640, min(d.cores, 4), emptyList(), 6)
            }
            val o = overrides[tier.name.lowercase()] ?: return base
            return base.copy(
                maxSide = o["maxSide"]?.toIntOrNull()?.coerceIn(1024, 4096) ?: base.maxSide,
                previewHi = o["previewHi"]?.toIntOrNull()?.coerceIn(512, 2048) ?: base.previewHi,
                previewLo = o["previewLo"]?.toIntOrNull()?.coerceIn(320, 1024) ?: base.previewLo,
                threads = o["threads"]?.toIntOrNull()?.coerceIn(1, 8) ?: base.threads,
                poolCapacity = o["pool"]?.toIntOrNull()?.coerceIn(1, 12) ?: base.poolCapacity,
                accel = o["accel"]?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: base.accel
            )
        }
    }
}

/** Số đo THỰC của máy lúc chạy: ms để chạy chuỗi hiệu chuẩn cho mỗi megapixel, tần số làm tươi màn hình (Hz), heap Java còn trống (byte), RAM hệ thống còn trống (MB). */
data class PerfMeasure(val msPerMp: Double, val refreshHz: Float, val heapHeadroomBytes: Long, val availMb: Int)

/**
 * Mô hình hiệu năng SUY RA từ phép đo (thay cho ngưỡng RAM viết cứng). Chi phí dựng ảnh tỉ lệ với SỐ ĐIỂM ẢNH (mọi toán tử trong `ImageEngine` đều tuyến tính theo điểm ảnh), nên từ
 * `msPerMp` đo được và một NGÂN SÁCH THỜI GIAN suy ra cạnh ảnh lớn nhất còn trong ngân sách. Các ngân sách là quyết định TRẢI NGHIỆM, không phụ thuộc máy:
 *  - xem trước khi KÉO thanh trượt: [FRAME_COUNT] khung hình của màn hình (1000 / tần số làm tươi THẬT: 3 khung = 50 ms ở 60 Hz, 25 ms ở 120 Hz ⇒ ≥ 20 cập nhật / giây ở 60 Hz);
 *  - xem trước khi THẢ tay: [INSTANT_MS] = 100 ms (ngưỡng "tức thì" 0,1 s của Nielsen);
 *  - một lần áp dụng / xuất ở cỡ làm việc: [BAKE_MS] = 3 s (cùng ngân sách với `Adaptive`); chuỗi áp dụng thật dài [BAKE_CHAIN_FACTOR] = 3 lần chuỗi hiệu chuẩn (≈ 12 / 4 lượt xử lý tương đương:
 *    chuỗi hiệu chuẩn gộp ma trận màu + một lần làm nét có làm mờ ≈ 4 lượt; một chỉnh sửa nặng có vài toán tử dựa trên làm mờ ≈ 12 lượt — ƯỚC TÍNH, chưa đo trên chuỗi thật).
 * Bộ nhớ — cạnh làm việc là NHỎ NHẤT của ba chặn: (1) thời gian ở trên; (2) heap Java còn trống: [HEAP_BYTES_PER_PIXEL] = 20 B / điểm ảnh (năm mảng Int của `sharpen`, bằng
 * `ImageEngine.UPSCALE_HEAP_BYTES_PER_PIXEL`) × [HEAP_SAFETY]; (3) bộ nhớ NATIVE còn trống: lịch sử hoàn tác giữ tới 15 bản nền (`undoStack` trong `MainViewModel`, `if (undoStack.size > 15)`)
 * cộng ~5 bản đang dùng (hiện tại, kết quả áp dụng, bộ đệm gộp lớp, một lớp vá AI, một mặt nạ) = [NATIVE_BITMAPS] = 20 bitmap × 4 B = [NATIVE_BYTES_PER_PIXEL] = 80 B / điểm ảnh, dùng tối đa
 * [NATIVE_SHARE] RAM còn trống. Kẹp trong [[SIDE_FLOOR], [SIDE_CEIL]] — trần 2560 là phạm vi sản phẩm đã thiết kế / thử (bảng cũ chỉ dùng tới 2560), KHÔNG phải kết luận của phép đo.
 * Hồ model lấy [POOL_SHARE] RAM còn trống chia cho [POOL_SLOT_MB] MB mỗi khe (= bộ nhớ đỉnh ONNX 511 MB Qualcomm AI Hub đo cho Depth-Anything-V2 ở Galaxy S25 × 1,3 dự phòng).
 * Số luồng = số nhân, tối đa [MAX_THREADS] (nghiên cứu ORT trên big.LITTLE: nhiều hơn 4 luồng intra-op bắt đầu tranh chấp). Hạng [Tier] chỉ là NHÃN phân loại hồ sơ đã đo (dùng chọn cấu hình
 * định tuyến phía máy chủ và giới hạn moiré), cắt tại điểm giữa các cạnh của bảng cũ (1536 / 2048 / 2560 ⇒ 1792 / 2304).
 * Kiểm bằng `tools/verify_ports/perf_model.py` (đọc hằng số từ mã Kotlin).
 */
object PerfModel {
    const val INSTANT_MS = 100.0
    const val FRAME_COUNT = 3
    const val BAKE_MS = 3000.0
    const val BAKE_CHAIN_FACTOR = 3.0
    const val HEAP_BYTES_PER_PIXEL = 20
    const val HEAP_SAFETY = 0.6
    const val NATIVE_BITMAPS = 20
    const val NATIVE_BYTES_PER_PIXEL = 4 * NATIVE_BITMAPS
    const val NATIVE_SHARE = 0.25
    const val POOL_SLOT_MB = 660
    const val POOL_SHARE = 0.4
    const val ASPECT = 4.0 / 3.0
    const val MAX_THREADS = 4
    const val BLEND_UP = 1.05
    const val SIDE_FLOOR = 1024
    const val SIDE_CEIL = 2560
    const val TIER_LOW_BELOW = 1792
    const val TIER_HIGH_FROM = 2304

    /** Cạnh dài (tỉ lệ khung 4:3) mà một chuỗi tốn [msPerMp] ms cho mỗi megapixel vẫn xong trong [budgetMs]. 0 nếu số đo không hợp lệ. */
    fun sideForBudget(msPerMp: Double, budgetMs: Double): Int {
        if (!(msPerMp > 0.0) || !(budgetMs > 0.0)) return 0
        return sqrt(budgetMs / msPerMp * 1e6 * ASPECT).toInt()
    }

    /** Cạnh dài (4:3) mà [bytesPerPixel] byte cho mỗi điểm ảnh vừa trong [bytes] × [safety]. */
    fun sideForMemory(bytes: Double, safety: Double, bytesPerPixel: Int): Int {
        if (!(bytes > 0.0)) return 0
        return sqrt(bytes * safety / bytesPerPixel * ASPECT).toInt()
    }

    fun previewLo(m: PerfMeasure): Int = sideForBudget(m.msPerMp, 1000.0 / max(1f, m.refreshHz) * FRAME_COUNT).coerceIn(320, 1024)

    fun previewHi(m: PerfMeasure): Int = sideForBudget(m.msPerMp, INSTANT_MS).coerceIn(512, 2048)

    fun maxSide(m: PerfMeasure): Int {
        val time = sideForBudget(m.msPerMp * BAKE_CHAIN_FACTOR, BAKE_MS)
        val heap = sideForMemory(max(0L, m.heapHeadroomBytes).toDouble(), HEAP_SAFETY, HEAP_BYTES_PER_PIXEL)
        val nativeSide = sideForMemory(max(0, m.availMb).toDouble() * 1024.0 * 1024.0, NATIVE_SHARE, NATIVE_BYTES_PER_PIXEL)
        return minOf(time, heap, nativeSide).coerceIn(SIDE_FLOOR, SIDE_CEIL)
    }

    fun poolSlots(availMb: Int): Int = (max(0, availMb) * POOL_SHARE / POOL_SLOT_MB).roundToInt().coerceIn(1, 12)

    fun threads(cores: Int): Int = cores.coerceIn(1, MAX_THREADS)

    fun tierOf(maxSide: Int): Tier = when {
        maxSide < TIER_LOW_BELOW -> Tier.LOW
        maxSide >= TIER_HIGH_FROM -> Tier.HIGH
        else -> Tier.MID
    }

    /**
     * Gộp số đo mới vào số đã lưu: lấy giá trị NHANH hơn ngay (số đo thấp phản ánh máy khi rảnh), còn số đo chậm hơn chỉ được đẩy lên tối đa [BLEND_UP]× mỗi lần mở app —
     * một lần đo trúng lúc máy bận không làm hồ sơ kém đi hẳn, máy thật sự chậm đi (nóng, pin yếu) vẫn dần được phản ánh.
     */
    fun blend(stored: Double, measured: Double): Double = if (!(stored > 0.0)) measured else min(measured, stored * BLEND_UP)
}
