package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Best Take (chọn khuôn mặt đẹp nhất từ nhiều ảnh cùng cảnh): với MỖI người trong ảnh gốc, tìm trong các ảnh phụ (chụp liên tiếp) khuôn mặt
 * mắt mở + cười đẹp nhất rồi ghép nó vào ảnh gốc. THUẦN Kotlin (không phụ thuộc Android / MediaPipe) nên kiểm thử được trên JVM.
 * Đầu vào là các mảng điểm mốc 478 điểm chuẩn hóa 0..1 như [FaceGeometry] (x0,y0,x1,y1,…; khối chiều sâu nối đuôi nếu có thì bị bỏ qua).
 *
 * Các bước:
 *  1. [metrics] / [score]: độ mở mắt = tỉ số mở mí (EAR) trung bình 3 cặp điểm mí trên–dưới / bề rộng mắt, nhân thang [EAR_CLOSED]..[EAR_OPEN];
 *     nụ cười = độ rộng miệng / khoảng cách hai khóe mắt ngoài và độ nhếch khóe miệng so với tâm môi; phạt nhắm một mắt, quay mặt đi, há miệng quá rộng
 *     và (nhẹ) mặt bị nhòe so với các khung còn lại. Mắt chiếm trọng số lớn nhất vì mắt nhắm là lỗi chính của ảnh nhóm.
 *  2. [alignShift]: dịch chuyển toàn cục giữa hai khung bằng tương quan pha (FFT, trọng số Gauss theo tần số [ALIGN_BAND] để chịu nhiễu) trên ảnh độ chói thu nhỏ — chỉ để KHỚP khuôn mặt giữa các khung;
 *     [matchFaces]: ghép mặt theo tâm (đã trừ dịch chuyển) và cỡ mặt, tham lam từ cặp gần nhất, bán kính tối đa [MATCH_RADIUS] bề rộng mặt.
 *  3. [plan]: mỗi mặt của ảnh gốc chọn khung có điểm cao nhất; chỉ đổi khi hơn ảnh gốc ít nhất [SWITCH_MARGIN] (tránh đổi vô ích).
 *  4. [applyFace]: căn khuôn mặt nguồn vào mặt gốc bằng phép đồng dạng (xoay + tỉ lệ + tịnh tiến, bình phương tối thiểu trên các điểm "cứng" không đổi
 *     theo biểu cảm), cắt theo đường viền mặt của ảnh GỐC, viền mềm theo khoảng cách vào trong, rồi hiệu chỉnh màu/độ sáng kiểu Poisson: độ lệch giữa
 *     hai ảnh ở viền được lan vào trong theo nghiệm điều hòa (giải thô trên lưới thưa) nên mối ghép không lộ dù hai khung lệch phơi sáng.
 * Giới hạn: không tạo biểu cảm mới — chỉ chọn trong những gì đã chụp; ngưỡng mắt / nụ cười là ước đoán tay (chưa đo trên mặt thật); người đổi dáng
 * mạnh (quay đầu, cúi, hàm lệch nhiều) thì mối ghép có thể lộ; không ghép tóc / tai / cổ (chỉ vùng trong đường viền mặt).
 */
object BestTake {

    const val MIN_POINTS = 468

    /** Số ảnh phụ tối đa (cùng cảnh, chụp liên tiếp) — nhiều hơn chỉ tốn thời gian: mỗi ảnh phụ phải giải mã + nhận mặt. */
    const val MAX_FRAMES = 8

    // ------------------------------------------------------------------ chỉ số điểm (MediaPipe Face Mesh)
    private val R_UP = intArrayOf(160, 159, 158)
    private val R_LO = intArrayOf(144, 145, 153)
    private const val R_OUT = 33
    private const val R_IN = 133
    private val L_UP = intArrayOf(387, 386, 385)
    private val L_LO = intArrayOf(373, 374, 380)
    private const val L_OUT = 263
    private const val L_IN = 362
    private const val MOUTH_R = 61
    private const val MOUTH_L = 291
    private const val LIP_UP = 13
    private const val LIP_LO = 14
    private const val NOSE = 1
    private const val CHEEK_R = 234
    private const val CHEEK_L = 454

    /** Điểm "cứng" (xương mặt, không đổi theo biểu cảm) dùng để căn hai khuôn mặt: khóe mắt, sống mũi, mũi, gò má, trán. */
    val RIGID = intArrayOf(33, 133, 362, 263, 168, 6, 1, 234, 454, 10, 127, 356)

    // ------------------------------------------------------------------ hằng số tinh chỉnh (ước đoán tay — xem giới hạn ở KDoc)
    const val EAR_CLOSED = 0.13f
    const val EAR_OPEN = 0.27f
    const val SMILE_WIDTH_NEUTRAL = 0.55f
    const val SMILE_WIDTH_SPAN = 0.15f
    const val SMILE_LIFT_SPAN = 0.08f
    const val W_EYES = 0.55f
    const val W_SMILE = 0.30f
    const val W_SHARP = 0.15f
    const val BLINK_GATE = 0.35f
    const val BLINK_PENALTY = 0.30f
    const val YAW_FREE = 0.12f
    const val YAW_SPAN = 0.25f
    const val YAW_PENALTY = 0.25f
    const val MOUTH_FREE = 0.28f
    const val MOUTH_SPAN = 0.25f
    const val MOUTH_PENALTY = 0.20f
    const val SWITCH_MARGIN = 0.10f
    const val MATCH_RADIUS = 0.6f
    const val MAX_SCALE_RATIO = 1.8f
    const val FEATHER = 0.12f
    private const val ALIGN_N = 256
    private const val ALIGN_MIN_PSR = 8f

    /**
     * Độ rộng Gauss (chu kỳ / điểm ảnh của ảnh thu nhỏ) của trọng số tần số trong tương quan pha. Tương quan pha thuần túy chuẩn hóa MỌI tần số về cùng biên độ nên
     * nhiễu cảm biến ở tần số cao (không nhất quán giữa hai khung) ngang quyền với cấu trúc thật: đo trên cảnh đốm Gauss + nhiễu độc lập σ = 5 thì chỉ 7/20 dịch chuyển
     * đúng; thêm trọng số này ⇒ 20/20 (kể cả σ = 30), ảnh khác cảnh vẫn dưới ngưỡng PSR. Đánh đổi: đỉnh rộng hơn (≈ 3 điểm ảnh lưới) — đủ cho việc chỉ để KHỚP mặt.
     */
    const val ALIGN_BAND = 0.05f
    private const val COARSE_CELLS = 40

    // ------------------------------------------------------------------ đo biểu cảm
    class Metrics(
        /** Độ mở mắt phải / trái (người trong ảnh), 0 = nhắm, 1 = mở. */
        val eyeR: Float, val eyeL: Float,
        /** Nụ cười 0..1. */
        val smile: Float,
        /** Độ há miệng (khoảng hai môi trong / khoảng cách hai khóe mắt ngoài). */
        val mouthOpen: Float,
        /** Độ lệch mặt khỏi chính diện, có dấu (mũi so với giữa hai gò má / bề rộng mặt). */
        val yaw: Float
    ) {
        /** Mắt: nghiêng về mắt nhắm hơn (cả hai mắt phải mở). */
        val eyes: Float get() = 0.7f * min(eyeR, eyeL) + 0.3f * (eyeR + eyeL) / 2f
    }

    private fun dx(lm: FloatArray, a: Int, b: Int, w: Int) = (lm[2 * a] - lm[2 * b]) * w
    private fun dy(lm: FloatArray, a: Int, b: Int, h: Int) = (lm[2 * a + 1] - lm[2 * b + 1]) * h
    private fun dist(lm: FloatArray, a: Int, b: Int, w: Int, h: Int) = hypot(dx(lm, a, b, w), dy(lm, a, b, h))

    private fun eyeOpen(lm: FloatArray, up: IntArray, lo: IntArray, out: Int, inn: Int, w: Int, h: Int): Float {
        val hz = dist(lm, out, inn, w, h)
        if (hz < 1e-3f) return 0f
        var s = 0f
        for (k in up.indices) s += dist(lm, up[k], lo[k], w, h)
        val ear = s / up.size / hz
        return ((ear - EAR_CLOSED) / (EAR_OPEN - EAR_CLOSED)).coerceIn(0f, 1f)
    }

    /** Chỉ số biểu cảm của một khuôn mặt; null nếu thiếu điểm mốc hoặc mặt quá nhỏ để đo. */
    fun metrics(lm: FloatArray, w: Int, h: Int): Metrics? {
        if (lm.size < 2 * MIN_POINTS || w <= 0 || h <= 0) return null
        val d = dist(lm, R_OUT, L_OUT, w, h)
        if (d < 4f) return null
        val eyeR = eyeOpen(lm, R_UP, R_LO, R_OUT, R_IN, w, h)
        val eyeL = eyeOpen(lm, L_UP, L_LO, L_OUT, L_IN, w, h)
        val width = dist(lm, MOUTH_R, MOUTH_L, w, h) / d
        val midY = (lm[2 * LIP_UP + 1] + lm[2 * LIP_LO + 1]) / 2f
        val cornerY = (lm[2 * MOUTH_R + 1] + lm[2 * MOUTH_L + 1]) / 2f
        val lift = (midY - cornerY) * h / d                  // dương = khóe miệng cao hơn tâm môi (cười)
        val smile = (0.5f * ((width - SMILE_WIDTH_NEUTRAL) / SMILE_WIDTH_SPAN).coerceIn(0f, 1f) +
            0.5f * (lift / SMILE_LIFT_SPAN).coerceIn(0f, 1f))
        val open = dist(lm, LIP_UP, LIP_LO, w, h) / d
        val faceW = dist(lm, CHEEK_R, CHEEK_L, w, h)
        val yaw = if (faceW < 1e-3f) 0f else (lm[2 * NOSE] - (lm[2 * CHEEK_R] + lm[2 * CHEEK_L]) / 2f) * w / faceW
        return Metrics(eyeR, eyeL, smile, open, yaw)
    }

    /** Điểm tổng 0..~1 của một khuôn mặt; [sharpRel] = độ nét so với khung nét nhất của CÙNG khuôn mặt (0..1). */
    fun score(m: Metrics, sharpRel: Float): Float {
        var s = W_EYES * m.eyes + W_SMILE * m.smile + W_SHARP * sharpRel.coerceIn(0f, 1f)
        if (min(m.eyeR, m.eyeL) < BLINK_GATE) s -= BLINK_PENALTY
        s -= ((abs(m.yaw) - YAW_FREE) / YAW_SPAN).coerceIn(0f, 1f) * YAW_PENALTY
        s -= ((m.mouthOpen - MOUTH_FREE) / MOUTH_SPAN).coerceIn(0f, 1f) * MOUTH_PENALTY
        return s
    }

    // ------------------------------------------------------------------ hình học khuôn mặt
    /** Tâm (điểm ảnh) khuôn mặt = trung bình các điểm viền mặt. */
    fun center(lm: FloatArray, w: Int, h: Int): FloatArray {
        var sx = 0f
        var sy = 0f
        for (i in FaceGeometry.FACE_OVAL) { sx += lm[2 * i]; sy += lm[2 * i + 1] }
        val n = FaceGeometry.FACE_OVAL.size
        return floatArrayOf(sx / n * w, sy / n * h)
    }

    /** Cỡ khuôn mặt = bề rộng giữa hai gò má (điểm ảnh). */
    fun faceWidth(lm: FloatArray, w: Int, h: Int): Float = dist(lm, CHEEK_R, CHEEK_L, w, h)

    /** Độ nét (phương sai Laplace của độ chói) trong khung bao khuôn mặt; 0 nếu khung quá nhỏ. */
    fun sharpness(px: IntArray, w: Int, h: Int, lm: FloatArray): Float {
        if (lm.size < 2 * MIN_POINTS || px.size != w * h) return 0f
        val box = faceBox(lm, w, h, 0) ?: return 0f
        val x0 = box[0]; val y0 = box[1]; val x1 = box[2]; val y1 = box[3]
        if (x1 - x0 < 8 || y1 - y0 < 8) return 0f
        var acc = 0.0
        var n = 0
        for (y in y0 + 1 until y1) for (x in x0 + 1 until x1) {
            val c = luma(px[y * w + x])
            val l = 4f * c - luma(px[y * w + x - 1]) - luma(px[y * w + x + 1]) - luma(px[(y - 1) * w + x]) - luma(px[(y + 1) * w + x])
            acc += l.toDouble() * l; n++
        }
        return if (n == 0) 0f else (acc / n).toFloat()
    }

    private fun luma(p: Int): Float = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)

    /** Khung bao viền mặt [x0, y0, x1, y1] (x1/y1 không gồm), nới [margin] điểm ảnh, kẹp trong ảnh; null nếu rỗng. */
    fun faceBox(lm: FloatArray, w: Int, h: Int, margin: Int): IntArray? {
        if (lm.size < 2 * MIN_POINTS) return null
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (i in FaceGeometry.FACE_OVAL) {
            val x = lm[2 * i] * w; val y = lm[2 * i + 1] * h
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val x0 = max(0, floor(minX).toInt() - margin); val y0 = max(0, floor(minY).toInt() - margin)
        val x1 = min(w, ceil(maxX).toInt() + margin); val y1 = min(h, ceil(maxY).toInt() + margin)
        return if (x1 > x0 && y1 > y0) intArrayOf(x0, y0, x1, y1) else null
    }

    // ------------------------------------------------------------------ khớp mặt giữa các khung
    /**
     * [out][i] = chỉ số mặt trong [other] khớp với mặt thứ i của [baseLm], hoặc −1. ([dx],[dy]) cộng vào tọa độ ảnh phụ để ra tọa độ ảnh gốc.
     * Cặp phải có tâm cách nhau ≤ [MATCH_RADIUS] × bề rộng mặt lớn hơn và cỡ mặt chênh không quá [MAX_SCALE_RATIO] lần; ghép tham lam từ cặp gần nhất.
     */
    fun matchFaces(baseLm: List<FloatArray>, other: List<FloatArray>, w: Int, h: Int, dx: Float, dy: Float): IntArray {
        val out = IntArray(baseLm.size) { -1 }
        class Cand2(val d: Float, val b: Int, val o: Int)
        val pairs = ArrayList<Cand2>()
        for (bi in baseLm.indices) {
            val b = baseLm[bi]
            if (b.size < 2 * MIN_POINTS) continue
            val cb = center(b, w, h); val sb = faceWidth(b, w, h)
            if (sb < 4f) continue
            for (oi in other.indices) {
                val o = other[oi]
                if (o.size < 2 * MIN_POINTS) continue
                val co = center(o, w, h); val so = faceWidth(o, w, h)
                if (so < 4f) continue
                val ratio = if (sb > so) sb / so else so / sb
                if (ratio > MAX_SCALE_RATIO) continue
                val d = hypot(cb[0] - (co[0] + dx), cb[1] - (co[1] + dy))
                if (d <= MATCH_RADIUS * max(sb, so)) pairs.add(Cand2(d, bi, oi))
            }
        }
        pairs.sortBy { it.d }
        val usedO = BooleanArray(other.size)
        for (p in pairs) {
            if (out[p.b] != -1 || usedO[p.o]) continue
            out[p.b] = p.o; usedO[p.o] = true
        }
        return out
    }

    // ------------------------------------------------------------------ chọn khung đẹp nhất cho từng mặt
    /** Một khung ảnh: các khuôn mặt thấy được, độ nét từng mặt, và dịch chuyển (dx, dy) cộng vào tọa độ khung này để ra tọa độ ảnh gốc. Khung 0 = ảnh gốc. */
    class FaceFrame(val lm: List<FloatArray>, val sharp: FloatArray, val dx: Float, val dy: Float)

    /** Kết quả chọn cho mặt thứ [face] của ảnh gốc: dùng khuôn mặt [frameFace] của khung [frame] (0 = giữ nguyên ảnh gốc). */
    class Pick(
        val face: Int, val frame: Int, val frameFace: Int,
        val baseScore: Float, val bestScore: Float, val baseMetrics: Metrics?, val bestMetrics: Metrics?
    ) {
        val changed: Boolean get() = frame != 0
    }

    private class Cand(val frame: Int, val face: Int, val m: Metrics, val sharp: Float)

    fun plan(frames: List<FaceFrame>, w: Int, h: Int): List<Pick> {
        if (frames.isEmpty()) return emptyList()
        val base = frames[0]
        val n = base.lm.size
        val matches = Array(frames.size) { f ->
            if (f == 0) IntArray(n) { it } else matchFaces(base.lm, frames[f].lm, w, h, frames[f].dx, frames[f].dy)
        }
        val picks = ArrayList<Pick>()
        for (i in 0 until n) {
            val cands = ArrayList<Cand>()
            for (f in frames.indices) {
                val j = matches[f][i]
                if (j < 0 || j >= frames[f].lm.size) continue
                val m = metrics(frames[f].lm[j], w, h) ?: continue
                cands.add(Cand(f, j, m, frames[f].sharp.getOrElse(j) { 0f }))
            }
            val baseC = cands.firstOrNull { it.frame == 0 }
            if (baseC == null) { picks.add(Pick(i, 0, i, 0f, 0f, null, null)); continue }
            val sharpMax = cands.maxOf { it.sharp }
            val scores = cands.map { score(it.m, if (sharpMax > 0f) it.sharp / sharpMax else 1f) }
            var best = 0
            for (k in cands.indices) if (scores[k] > scores[best]) best = k
            val baseScore = scores[cands.indexOf(baseC)]
            val c = cands[best]
            if (c.frame != 0 && scores[best] - baseScore >= SWITCH_MARGIN) picks.add(Pick(i, c.frame, c.face, baseScore, scores[best], baseC.m, c.m))
            else picks.add(Pick(i, 0, i, baseScore, baseScore, baseC.m, baseC.m))
        }
        return picks
    }

    /** Câu mô tả một lựa chọn cho người dùng, vd. "Mặt 2 ← ảnh phụ 1 (mắt mở 5% → 100%, cười 30% → 80%)". [label] = tên khung được chọn. */
    fun describe(p: Pick, label: String): String {
        val a = p.baseMetrics ?: return "Mặt ${p.face + 1}: không đo được."
        if (!p.changed) return "Mặt ${p.face + 1}: giữ ảnh gốc."
        val b = p.bestMetrics ?: return "Mặt ${p.face + 1}: không đo được."
        fun pct(v: Float) = "${Math.round(v * 100f)}%"
        return "Mặt ${p.face + 1} ← $label (mắt mở ${pct(a.eyes)} → ${pct(b.eyes)}, cười ${pct(a.smile)} → ${pct(b.smile)})"
    }

    // ------------------------------------------------------------------ căn khung toàn cục (tương quan pha)
    /** Ảnh độ chói thu nhỏ ALIGN_N × ALIGN_N (chia vùng, không giữ tỉ lệ) để dò dịch chuyển giữa hai khung cùng kích thước. */
    fun thumb(px: IntArray, w: Int, h: Int): FloatArray = Resample.areaMap(px, w, h, ALIGN_N, ALIGN_N) { luma(it) }

    class Shift(val dx: Float, val dy: Float, val psr: Float)

    /**
     * Dịch chuyển (a → b) theo điểm ảnh của lưới [n]×[n] sao cho b(x, y) ≈ a(x − dx, y − dy), kèm độ tin cậy PSR
     * (đỉnh − trung bình) / độ lệch chuẩn của mặt tương quan. Hai mảng phải cùng cỡ n×n, n là lũy thừa của 2.
     */
    fun phaseShift(a: FloatArray, b: FloatArray, n: Int): Shift {
        require(a.size == n * n && b.size == n * n && Fft.isPow2(n))
        val ar = prepare(a, n); val ai = FloatArray(n * n)
        val br = prepare(b, n); val bi = FloatArray(n * n)
        Fft.transform2d(ar, ai, n, n, false)
        Fft.transform2d(br, bi, n, n, false)
        // công suất chéo chuẩn hóa B · conj(A), nhân trọng số Gauss theo tần số (xem ALIGN_BAND)
        for (i in 0 until n * n) {
            val re = br[i] * ar[i] + bi[i] * ai[i]
            val im = bi[i] * ar[i] - br[i] * ai[i]
            val mag = sqrt(re * re + im * im)
            if (mag < 1e-9f) { ar[i] = 0f; ai[i] = 0f } else {
                val kx = i % n; val ky = i / n
                val fx = (if (kx >= n / 2) kx - n else kx).toFloat() / n
                val fy = (if (ky >= n / 2) ky - n else ky).toFloat() / n
                val wgt = exp(-(fx * fx + fy * fy) / (2f * ALIGN_BAND * ALIGN_BAND))
                ar[i] = re / mag * wgt; ai[i] = im / mag * wgt
            }
        }
        Fft.transform2d(ar, ai, n, n, true)
        var peak = -Float.MAX_VALUE; var pi = 0
        var sum = 0.0; var sq = 0.0
        for (i in 0 until n * n) {
            val v = ar[i]
            if (v > peak) { peak = v; pi = i }
            sum += v; sq += v.toDouble() * v
        }
        val mean = sum / (n * n)
        val std = sqrt(max(1e-12, sq / (n * n) - mean * mean))
        var px = pi % n; var py = pi / n
        if (px >= n / 2) px -= n
        if (py >= n / 2) py -= n
        return Shift(px.toFloat(), py.toFloat(), ((peak - mean) / std).toFloat())
    }

    private fun prepare(src: FloatArray, n: Int): FloatArray {
        var mean = 0.0
        for (v in src) mean += v
        mean /= src.size
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * Math.PI * it / (n - 1))).toFloat() }
        val out = FloatArray(n * n)
        for (y in 0 until n) for (x in 0 until n) out[y * n + x] = ((src[y * n + x] - mean) * win[x] * win[y]).toFloat()
        return out
    }

    /**
     * Dịch chuyển điểm ảnh (dx, dy) CỘNG VÀO tọa độ khung phụ để ra tọa độ ảnh gốc, từ hai ảnh [thumb] của khung gốc và khung phụ.
     * Độ tin cậy thấp (ảnh trơn, khác cảnh) ⇒ (0, 0). [w],[h] là kích thước ảnh đầy đủ để đổi từ lưới nhỏ về điểm ảnh.
     */
    fun alignShift(baseThumb: FloatArray, otherThumb: FloatArray, w: Int, h: Int): FloatArray {
        val s = phaseShift(baseThumb, otherThumb, ALIGN_N)
        if (s.psr < ALIGN_MIN_PSR) return floatArrayOf(0f, 0f)
        // b(x) = a(x − d) ⇒ nội dung ở x_gốc nằm ở x_gốc + d trong khung phụ ⇒ x_gốc = x_phụ − d
        return floatArrayOf(-s.dx * w / ALIGN_N, -s.dy * h / ALIGN_N)
    }

    /** Hai ảnh có cùng khung hình không (tỉ lệ cạnh lệch ≤ 2%) để co về cùng kích thước rồi so khuôn mặt. */
    fun sameFraming(w: Int, h: Int, bw: Int, bh: Int): Boolean {
        if (w <= 0 || h <= 0 || bw <= 0 || bh <= 0) return false
        val a = w.toFloat() / h
        val b = bw.toFloat() / bh
        return abs(a - b) / a <= 0.02f
    }

    // ------------------------------------------------------------------ phép đồng dạng
    /** Phép đồng dạng 2D: đích = [[a, −b], [b, a]] · nguồn + (tx, ty); tỉ lệ = √(a²+b²), góc quay = atan2(b, a). */
    class Sim(val a: Float, val b: Float, val tx: Float, val ty: Float) {
        val scale: Float get() = hypot(a, b)
        val angle: Float get() = atan2(b, a)
        fun mapX(x: Float, y: Float) = a * x - b * y + tx
        fun mapY(x: Float, y: Float) = b * x + a * y + ty
        fun inverse(): Sim? {
            val d = a * a + b * b
            if (d < 1e-12f) return null
            val ia = a / d
            val ib = -b / d
            return Sim(ia, ib, -(ia * tx - ib * ty), -(ib * tx + ia * ty))
        }
    }

    /** Phép đồng dạng bình phương tối thiểu ánh xạ các điểm [src] (x0,y0,x1,y1,…) lên [dst]; null nếu < 2 điểm hoặc nguồn suy biến. */
    fun similarity(src: FloatArray, dst: FloatArray): Sim? {
        val n = min(src.size, dst.size) / 2
        if (n < 2) return null
        var msx = 0f; var msy = 0f; var mdx = 0f; var mdy = 0f
        for (i in 0 until n) { msx += src[2 * i]; msy += src[2 * i + 1]; mdx += dst[2 * i]; mdy += dst[2 * i + 1] }
        msx /= n; msy /= n; mdx /= n; mdy /= n
        var num1 = 0.0; var num2 = 0.0; var den = 0.0
        for (i in 0 until n) {
            val sx = src[2 * i] - msx; val sy = src[2 * i + 1] - msy
            val ex = dst[2 * i] - mdx; val ey = dst[2 * i + 1] - mdy
            num1 += sx * ex + sy * ey
            num2 += sx * ey - sy * ex
            den += sx * sx + sy * sy
        }
        if (den < 1e-9) return null
        val a = (num1 / den).toFloat(); val b = (num2 / den).toFloat()
        return Sim(a, b, mdx - (a * msx - b * msy), mdy - (b * msx + a * msy))
    }

    private fun rigidPoints(lm: FloatArray, w: Int, h: Int) = FloatArray(RIGID.size * 2).also {
        for (k in RIGID.indices) { it[2 * k] = lm[2 * RIGID[k]] * w; it[2 * k + 1] = lm[2 * RIGID[k] + 1] * h }
    }

    /** Phép đồng dạng đưa khuôn mặt nguồn [srcLm] vào đúng chỗ của khuôn mặt gốc [baseLm] (cả hai trên ảnh w×h); null nếu không hợp lý. */
    fun faceSim(srcLm: FloatArray, baseLm: FloatArray, w: Int, h: Int): Sim? {
        if (srcLm.size < 2 * MIN_POINTS || baseLm.size < 2 * MIN_POINTS) return null
        val s = similarity(rigidPoints(srcLm, w, h), rigidPoints(baseLm, w, h)) ?: return null
        val k = s.scale
        return if (k in (1f / MAX_SCALE_RATIO)..MAX_SCALE_RATIO) s else null
    }

    // ------------------------------------------------------------------ ghép
    private fun smoothstep(t: Float): Float { val x = t.coerceIn(0f, 1f); return x * x * (3f - 2f * x) }

    /** Khoảng cách (điểm ảnh, xấp xỉ chamfer 3-4) từ mỗi điểm TRONG vùng tới điểm ngoài gần nhất; 0 ở ngoài. */
    internal fun insideDistance(inside: BooleanArray, bw: Int, bh: Int): FloatArray {
        val inf = 1e9f
        val d = FloatArray(bw * bh) { if (inside[it]) inf else 0f }
        fun at(x: Int, y: Int): Float = if (x < 0 || y < 0 || x >= bw || y >= bh) 0f else d[y * bw + x]
        for (y in 0 until bh) for (x in 0 until bw) {
            val i = y * bw + x
            if (d[i] == 0f) continue
            d[i] = min(d[i], min(min(at(x - 1, y) + 3f, at(x, y - 1) + 3f), min(at(x - 1, y - 1) + 4f, at(x + 1, y - 1) + 4f)))
        }
        for (y in bh - 1 downTo 0) for (x in bw - 1 downTo 0) {
            val i = y * bw + x
            if (d[i] == 0f) continue
            d[i] = min(d[i], min(min(at(x + 1, y) + 3f, at(x, y + 1) + 3f), min(at(x + 1, y + 1) + 4f, at(x - 1, y + 1) + 4f)))
        }
        for (i in d.indices) d[i] = if (d[i] >= inf) 0f else d[i] / 3f
        return d
    }

    private fun sampleArgb(src: IntArray, sw: Int, sh: Int, sx: Float, sy: Float): Int {
        val fx = sx - 0.5f; val fy = sy - 0.5f
        val x0 = floor(fx).toInt(); val y0 = floor(fy).toInt()
        val tx = fx - x0; val ty = fy - y0
        val xa = x0.coerceIn(0, sw - 1); val xb = (x0 + 1).coerceIn(0, sw - 1)
        val ya = y0.coerceIn(0, sh - 1); val yb = (y0 + 1).coerceIn(0, sh - 1)
        val p00 = src[ya * sw + xa]; val p10 = src[ya * sw + xb]; val p01 = src[yb * sw + xa]; val p11 = src[yb * sw + xb]
        var out = 0xFF shl 24
        for (sh8 in intArrayOf(16, 8, 0)) {
            val a = ((p00 shr sh8) and 255) * (1 - tx) + ((p10 shr sh8) and 255) * tx
            val b = ((p01 shr sh8) and 255) * (1 - tx) + ((p11 shr sh8) and 255) * tx
            out = out or ((a * (1 - ty) + b * ty + 0.5f).toInt().coerceIn(0, 255) shl sh8)
        }
        return out
    }

    /**
     * Hiệu chỉnh điều hòa: [diff] (3 kênh, xen kẽ r,g,b theo điểm) là (ảnh đích − ảnh nguồn đã căn) trong vùng [inside]; trả về trường hiệu chỉnh h cùng cỡ
     * sao cho h = diff ở viền vùng và trơn (nghiệm Laplace) bên trong. Giải trên lưới thưa ≤ ~[COARSE_CELLS] ô mỗi chiều rồi nội suy song tuyến tính.
     */
    internal fun harmonicOffset(diff: FloatArray, inside: BooleanArray, bw: Int, bh: Int): FloatArray {
        val out = FloatArray(3 * bw * bh)
        val g = max(1, ceil(max(bw, bh) / COARSE_CELLS.toFloat()).toInt())
        val cw = (bw + g - 1) / g
        val ch = (bh + g - 1) / g
        val cnt = IntArray(cw * ch)
        val area = IntArray(cw * ch)
        val sum = FloatArray(3 * cw * ch)
        // giá trị điều kiện biên lấy từ các điểm VIỀN thật của vùng (điểm trong vùng có láng giềng ngoài vùng), không lấy trung bình cả ô — nếu không, chi tiết
        // bên trong vùng lọt vào ô biên sẽ nhiễm vào điều kiện biên
        val rimCnt = IntArray(cw * ch)
        val rimSum = FloatArray(3 * cw * ch)
        for (y in 0 until bh) for (x in 0 until bw) {
            val c = (y / g) * cw + (x / g)
            area[c]++
            if (!inside[y * bw + x]) continue
            cnt[c]++
            for (k in 0 until 3) sum[3 * c + k] += diff[3 * (y * bw + x) + k]
            val rim = x == 0 || y == 0 || x == bw - 1 || y == bh - 1 ||
                !inside[y * bw + x - 1] || !inside[y * bw + x + 1] || !inside[(y - 1) * bw + x] || !inside[(y + 1) * bw + x]
            if (rim) {
                rimCnt[c]++
                for (k in 0 until 3) rimSum[3 * c + k] += diff[3 * (y * bw + x) + k]
            }
        }
        val cin = BooleanArray(cw * ch) { cnt[it] > 0 && cnt[it] * 2 >= area[it] }
        if (cin.none { it }) return out
        fun inC(x: Int, y: Int) = x in 0 until cw && y in 0 until ch && cin[y * cw + x]
        val h = FloatArray(3 * cw * ch)
        val fixed = BooleanArray(cw * ch)
        val bsum = FloatArray(3); var bn = 0
        for (cy in 0 until ch) for (cx in 0 until cw) {
            val c = cy * cw + cx
            if (!cin[c]) continue
            val edge = !inC(cx - 1, cy) || !inC(cx + 1, cy) || !inC(cx, cy - 1) || !inC(cx, cy + 1)
            if (edge) {
                fixed[c] = true
                for (k in 0 until 3) { h[3 * c + k] = if (rimCnt[c] > 0) rimSum[3 * c + k] / rimCnt[c] else sum[3 * c + k] / cnt[c]; bsum[k] += h[3 * c + k] }
                bn++
            }
        }
        for (c in 0 until cw * ch) if (cin[c] && !fixed[c]) for (k in 0 until 3) h[3 * c + k] = if (bn > 0) bsum[k] / bn else 0f
        for (iter in 0 until 600) {
            var change = 0f
            for (cy in 0 until ch) for (cx in 0 until cw) {
                val c = cy * cw + cx
                if (!cin[c] || fixed[c]) continue
                for (k in 0 until 3) {
                    val v = (h[3 * (c - 1) + k] + h[3 * (c + 1) + k] + h[3 * (c - cw) + k] + h[3 * (c + cw) + k]) / 4f
                    change = max(change, abs(v - h[3 * c + k]))
                    h[3 * c + k] = v
                }
            }
            if (change < 0.02f) break
        }
        // lan giá trị ra ô ngoài vùng (2 vòng) để nội suy ở rìa không kéo về 0
        val known = cin.copyOf()
        repeat(2) {
            val add = ArrayList<Int>()
            val vals = ArrayList<FloatArray>()
            for (cy in 0 until ch) for (cx in 0 until cw) {
                val c = cy * cw + cx
                if (known[c]) continue
                val acc = FloatArray(3); var m = 0
                for ((ox, oy) in listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)) {
                    val x = cx + ox; val y = cy + oy
                    if (x in 0 until cw && y in 0 until ch && known[y * cw + x]) { for (k in 0 until 3) acc[k] += h[3 * (y * cw + x) + k]; m++ }
                }
                if (m > 0) { add.add(c); vals.add(FloatArray(3) { acc[it] / m }) }
            }
            for (i in add.indices) { known[add[i]] = true; for (k in 0 until 3) h[3 * add[i] + k] = vals[i][k] }
        }
        for (y in 0 until bh) {
            val gy = ((y + 0.5f) / g - 0.5f).coerceIn(0f, (ch - 1).toFloat())
            val y0 = gy.toInt(); val y1 = min(ch - 1, y0 + 1); val ty = gy - y0
            for (x in 0 until bw) {
                val gx = ((x + 0.5f) / g - 0.5f).coerceIn(0f, (cw - 1).toFloat())
                val x0 = gx.toInt(); val x1 = min(cw - 1, x0 + 1); val tx = gx - x0
                for (k in 0 until 3) {
                    val a = h[3 * (y0 * cw + x0) + k] * (1 - tx) + h[3 * (y0 * cw + x1) + k] * tx
                    val b = h[3 * (y1 * cw + x0) + k] * (1 - tx) + h[3 * (y1 * cw + x1) + k] * tx
                    out[3 * (y * bw + x) + k] = a * (1 - ty) + b * ty
                }
            }
        }
        return out
    }

    /**
     * Ghép khuôn mặt [srcLm] của ảnh nguồn [src] (cùng cỡ w×h với [dst]) vào chỗ khuôn mặt [baseLm] của [dst], GHI TẠI CHỖ vào [dst].
     * Chỉ điểm trong đường viền mặt của [baseLm] bị đổi (cộng viền mềm vào trong); mọi điểm ngoài khung bao khuôn mặt giữ nguyên từng bit.
     * Trả về false (không đổi gì) nếu không căn được (thiếu điểm mốc, tỉ lệ khác quá [MAX_SCALE_RATIO] lần, khuôn mặt ngoài ảnh).
     */
    fun applyFace(dst: IntArray, w: Int, h: Int, src: IntArray, srcLm: FloatArray, baseLm: FloatArray): Boolean {
        if (dst.size != w * h || src.size != w * h) return false
        val sim = faceSim(srcLm, baseLm, w, h) ?: return false
        val inv = sim.inverse() ?: return false
        val box = faceBox(baseLm, w, h, 2) ?: return false
        val x0 = box[0]; val y0 = box[1]; val bw = box[2] - x0; val bh = box[3] - y0
        if (bw < 8 || bh < 8) return false
        val xs = FloatArray(FaceGeometry.FACE_OVAL.size) { baseLm[2 * FaceGeometry.FACE_OVAL[it]] * w - x0 }
        val ys = FloatArray(FaceGeometry.FACE_OVAL.size) { baseLm[2 * FaceGeometry.FACE_OVAL[it] + 1] * h - y0 }
        val poly = ByteArray(bw * bh)
        FaceGeometry.fillPolygon(xs, ys, bw, bh, poly)
        val warped = IntArray(bw * bh)
        val inside = BooleanArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            val i = y * bw + x
            if (poly[i].toInt() == 0) continue
            val cx = x + x0 + 0.5f; val cy = y + y0 + 0.5f
            val sx = inv.mapX(cx, cy); val sy = inv.mapY(cx, cy)
            if (sx < 0f || sy < 0f || sx > w || sy > h) continue
            warped[i] = sampleArgb(src, w, h, sx, sy)
            inside[i] = true
        }
        val dist = insideDistance(inside, bw, bh)
        val feather = max(3f, FEATHER * faceWidth(baseLm, w, h))
        val diff = FloatArray(3 * bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            val i = y * bw + x
            if (!inside[i]) continue
            val p = dst[(y + y0) * w + x + x0]; val q = warped[i]
            diff[3 * i] = (((p shr 16) and 255) - ((q shr 16) and 255)).toFloat()
            diff[3 * i + 1] = (((p shr 8) and 255) - ((q shr 8) and 255)).toFloat()
            diff[3 * i + 2] = ((p and 255) - (q and 255)).toFloat()
        }
        val off = harmonicOffset(diff, inside, bw, bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            val i = y * bw + x
            if (!inside[i]) continue
            val a = smoothstep((dist[i] - 0.5f) / feather)
            if (a <= 0f) continue
            val di = (y + y0) * w + x + x0
            val p = dst[di]; val q = warped[i]
            var res = p and (0xFF shl 24).toInt()
            for ((k, sh8) in intArrayOf(16, 8, 0).withIndex()) {
                val pv = (p shr sh8) and 255
                val qv = (((q shr sh8) and 255) + off[3 * i + k]).coerceIn(0f, 255f)
                res = res or ((pv + (qv - pv) * a + 0.5f).toInt().coerceIn(0, 255) shl sh8)
            }
            dst[di] = res
        }
        return true
    }
}
