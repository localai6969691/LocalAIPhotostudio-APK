package com.aiphoto.studio.ai

/**
 * Nhận biết yêu cầu "cắt theo chủ thể / Auto Frame / cắt thông minh" (R24). Không nhận "cắt 16:9" trần (đó vẫn là cắt giữa của bộ quy tắc).
 * [Request.ratio] = rộng/cao nếu người dùng nêu tỉ lệ ("vuông" = 1), null = giữ tỉ lệ ảnh hiện tại và chỉ siết khung vào chủ thể.
 */
object AutoFrameIntent {
    class Request(val ratio: Float?)

    private val STRONG = listOf(
        "tu dong cat", "cat tu dong", "cat thong minh", "cat theo chu the", "cat theo bo cuc", "cat bo cuc", "cat khung dep", "tu dong khung",
        "tu dong bo cuc", "bo cuc dep hon", "bo cuc lai", "auto frame", "autoframe", "auto crop", "autocrop", "smart crop", "reframe", "recompose",
        "frame the subject", "crop to subject", "crop to the subject", "crop around the subject", "crop around subject"
    )
    private val CROP = listOf("cat", "crop", "khung")
    private val SUBJECT = listOf("chu the", "nhan vat", "subject", "bo cuc", "composition", "quy tac 1 3", "rule of thirds", "quy tac mot phan ba")
    private val RATIO = Regex("""(?<!\d)(\d{1,2})\s*[:/]\s*(\d{1,2})(?!\d)""")

    private fun has(t: String, key: String): Boolean =
        Regex("(?<![a-z0-9])" + Regex.escape(key) + "(?![a-z0-9])").containsMatchIn(t)

    fun detect(prompt: String): Request? {
        val t = GenIntent.fold(prompt)
        if (t.isEmpty()) return null
        val hit = STRONG.any { has(t, it) } || (CROP.any { has(t, it) } && SUBJECT.any { has(t, it) })
        if (!hit) return null
        val m = RATIO.find(prompt)   // tìm trên câu gốc: GenIntent.fold biến "4:5" thành "4 5"
        val ratio = when {
            m != null -> {
                val a = m.groupValues[1].toFloat()
                val b = m.groupValues[2].toFloat()
                if (a > 0f && b > 0f) (a / b).coerceIn(0.2f, 5f) else null
            }
            has(t, "vuong") || has(t, "square") -> 1f
            else -> null
        }
        return Request(ratio)
    }
}
