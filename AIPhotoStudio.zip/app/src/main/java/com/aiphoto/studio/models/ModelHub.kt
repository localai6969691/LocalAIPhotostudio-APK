package com.aiphoto.studio.models

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * R43: bộ điều phối "Tải model AI" — giữ danh mục, trạng thái tải, ghi nhận người dùng đã đồng ý điều khoản, và giao tệp đã tải cho
 * hàm nạp model có sẵn của app ([install] = `importX(uri)` của MainViewModel: sao chép vào filesDir/models rồi nạp).
 * Không dùng Android trực tiếp (Context, SharedPreferences) nên kiểm được bằng JUnit.
 *
 * R44 thêm:
 *  - HÀNG ĐỢI (tải lần lượt từng model, lưu vào [queueFile] để tiếp tục sau khi tiến trình bị hệ điều hành tắt);
 *  - chế độ "chỉ tải bằng Wi-Fi" ([setWifiOnly]; mạng KHÔNG tính cước, xem [NetworkPolicy]): đang tải mà chuyển sang dữ liệu di động thì
 *    tạm dừng (giữ phần đã tải) và tự tải tiếp khi có Wi-Fi ([onNetworkChanged]); [allowMeteredOnce] cho phép dùng dữ liệu di động "lần này";
 *  - mất mạng giữa chừng: chờ mạng quay lại rồi tải tiếp; lỗi mạng thoáng qua: thử lại vài lần với độ trễ tăng dần;
 *  - [onKeepAlive] / [onResult]: móc cho dịch vụ nền (thông báo tiến độ, giữ tiến trình sống khi thoát app) — xem ModelServices / DownloadService.
 */
class ModelHub(
    private val scope: CoroutineScope,
    private val workDir: File,
    private val consentFile: File,
    private val catalogCache: File,
    private val bundledJson: () -> String,
    /** Tệp model cuối cùng của một slot trong thư mục model của app; null = bản app này chưa hỗ trợ slot đó. */
    private val slotFile: (String) -> File?,
    private val install: (slot: String, file: File) -> Unit,
    private val say: (String) -> Unit,
    private val allowHttp: Boolean = false,
    private val downloader: ModelDownloader = ModelDownloader(allowHttp = allowHttp),
    private val fetchText: (String) -> String? = { httpGetText(it) },
    /** R44: loại mạng hiện tại (đọc nhanh, không chặn). Mặc định coi là không tính cước (test và máy không đọc được trạng thái mạng). */
    private val network: () -> NetKind = { NetKind.UNMETERED },
    /** R44: giá trị ban đầu của cài đặt "Chỉ tải bằng Wi-Fi". */
    wifiOnly: Boolean = false,
    private val saveWifiOnly: (Boolean) -> Unit = {},
    /** R44: tệp lưu hàng đợi (mỗi dòng một id model); null = không lưu. */
    private val queueFile: File? = null,
    /** R44: độ trễ giữa các lần tự thử lại khi gặp lỗi mạng thoáng qua (hết danh sách thì báo lỗi). */
    private val retryDelaysMs: List<Long> = listOf(2_000L, 6_000L, 15_000L)
) {
    data class State(
        val entries: List<ModelEntry> = emptyList(),
        val note: String = "",
        /** id model đang chờ người dùng đồng ý điều khoản (hiện hộp thoại). */
        val pendingConsent: String? = null,
        val activeId: String? = null,
        val progress: Float = 0f,
        /** R44: id các model trong hàng đợi (phần tử đầu có thể đang tải). */
        val queue: List<String> = emptyList(),
        /** R44: đang chờ vì chính sách mạng (không có model nào đang tải mà hàng đợi chưa rỗng). */
        val waiting: NetworkPolicy.Wait? = null,
        val wifiOnly: Boolean = false,
        val network: NetKind = NetKind.UNMETERED,
        /** R44: người dùng đã cho phép dùng dữ liệu di động cho đợt tải này. */
        val meteredAllowed: Boolean = false
    )

    private val _state = MutableStateFlow(State(wifiOnly = wifiOnly, network = runCatching { network() }.getOrDefault(NetKind.UNMETERED)))
    val state: StateFlow<State> = _state.asStateFlow()

    private var releaseBase = ""
    private var remoteUrl: String? = null

    private val lock = Any()
    private val queue = ArrayList<String>()
    private var job: Job? = null
    @Volatile private var cancelActive = false
    @Volatile private var wifiOnlyNow = wifiOnly
    @Volatile private var allowMeteredNow = false

    /** Gọi (true) mỗi khi có việc cần giữ tiến trình sống (hàng đợi chưa rỗng) và (false) khi hàng đợi rỗng. Idempotent. */
    @Volatile var onKeepAlive: ((Boolean) -> Unit)? = null

    /** Gọi sau khi MỘT model tải xong hoặc thất bại thật sự (không gọi khi người dùng hủy hay tạm dừng chờ mạng): (model, thành công, thông điệp). */
    @Volatile var onResult: ((ModelEntry, Boolean, String) -> Unit)? = null

    init {
        val bundled = runCatching { ModelCatalogs.parse(bundledJson(), "bundled") }.getOrNull()
        remoteUrl = bundled?.let { ModelCatalogs.remoteUrl(it, allowHttp) }
        val cached = runCatching { ModelCatalogs.parse(catalogCache.readText(), "cache") }.getOrNull()
        val first = cached ?: bundled
        if (first != null) apply(first)
        restoreQueue()
        scope.launch(Dispatchers.IO) { purgeStale() }
    }

    private fun apply(c: ModelCatalog) {
        releaseBase = c.releaseBase
        val visible = c.models.filter { slotFile(it.slot) != null }
        _state.update { it.copy(entries = visible, note = "Danh mục model: ${visible.size} mục") }
    }

    /** Lấy danh mục mới nhất từ máy chủ (nếu đã cấu hình); lỗi thì dùng bản đã lưu hoặc bản có sẵn trong app. */
    fun refresh() {
        val url = remoteUrl ?: return
        scope.launch(Dispatchers.IO) {
            val txt = fetchText(url)
            val cat = txt?.let { runCatching { ModelCatalogs.parse(it, "remote") }.getOrNull() }
            if (cat != null && txt != null) {
                runCatching { catalogCache.absoluteFile.parentFile?.mkdirs(); catalogCache.writeText(txt) }
                apply(cat)
            } else if (!catalogCache.exists()) {
                _state.update { it.copy(note = "Chưa lấy được danh mục mới từ máy chủ — đang dùng danh mục có sẵn trong app.") }
            }
        }
    }

    fun entry(id: String): ModelEntry? = _state.value.entries.firstOrNull { it.id == id }

    // ------------------------------------------------------------------ yêu cầu của người dùng

    /** Người dùng bấm Tải: đã đồng ý điều khoản của model này rồi thì xếp vào hàng đợi (tải ngay nếu rảnh), chưa thì hiện hộp thoại điều khoản. */
    fun request(id: String) {
        val e = entry(id) ?: return
        if (inQueue(id)) return
        if (accepted(id)) enqueue(e) else _state.update { it.copy(pendingConsent = id) }
    }

    fun confirm(id: String) {
        val e = entry(id) ?: return
        remember(id)
        _state.update { it.copy(pendingConsent = null) }
        if (!inQueue(id)) enqueue(e)
    }

    fun dismissConsent() { _state.update { it.copy(pendingConsent = null) } }

    /**
     * Hủy: [id] = null hủy TẤT CẢ (xóa hàng đợi); khác null chỉ bỏ model đó. Phần đã tải dở (.part) được GIỮ để lần sau tiếp tục
     * (muốn xóa hẳn dùng [discardPartial]).
     */
    fun cancel(id: String? = null) {
        var hitActive = false
        synchronized(lock) {
            val active = _state.value.activeId
            if (id == null) {
                hitActive = active != null && job != null
                queue.clear()
            } else {
                queue.remove(id)
                hitActive = id == active && job != null
            }
            if (hitActive) cancelActive = true
        }
        persistQueue()
        syncQueue()
        if (!hitActive) pump()      // đang tải thì tác vụ tải kết thúc sẽ tự gọi pump()
    }

    /** Hủy (nếu đang tải / đang chờ) và xóa phần đã tải dở của model — dùng khi gỡ model. */
    fun discardPartial(id: String) {
        cancel(id)
        val e = entry(id) ?: return
        runCatching {
            File(workDir, e.file).delete()
            File(workDir, e.file + ".part").delete()
        }
    }

    /** Bật / tắt "Chỉ tải bằng Wi-Fi". Bật lúc đang tải bằng dữ liệu di động ⇒ tạm dừng; tắt lúc đang chờ Wi-Fi ⇒ tải ngay. */
    fun setWifiOnly(on: Boolean) {
        wifiOnlyNow = on
        if (on) allowMeteredNow = false
        runCatching { saveWifiOnly(on) }
        _state.update { it.copy(wifiOnly = on, meteredAllowed = if (on) false else it.meteredAllowed) }
        pump()
    }

    /** "Tải bằng dữ liệu di động lần này": bỏ qua chế độ chỉ Wi-Fi cho tới khi hàng đợi hiện tại tải xong. */
    fun allowMeteredOnce() {
        allowMeteredNow = true
        _state.update { it.copy(meteredAllowed = true) }
        pump()
    }

    /** Mạng đổi (gọi từ bộ theo dõi mạng): cập nhật trạng thái và tiếp tục tải nếu đang chờ. */
    fun onNetworkChanged() {
        _state.update { it.copy(network = runCatching { network() }.getOrDefault(NetKind.UNMETERED)) }
        pump()
    }

    /** Mở app / dịch vụ được hệ điều hành dựng lại: tiếp tục hàng đợi đã lưu (nếu chính sách mạng cho phép). */
    fun resumeIfWanted() {
        if (synchronized(lock) { queue.isEmpty() }) return
        notifyKeepAlive(true)
        pump()
    }

    private fun inQueue(id: String): Boolean = synchronized(lock) { id in queue }

    private fun enqueue(e: ModelEntry) {
        if (slotFile(e.slot) == null) return
        if (ModelCatalogs.resolveUrls(e, releaseBase, allowHttp).isEmpty()) { say("Chưa có địa chỉ tải cho model này."); return }
        synchronized(lock) { queue.add(e.id) }
        persistQueue()
        syncQueue()
        notifyKeepAlive(true)
        pump()
    }

    // ------------------------------------------------------------------ hàng đợi

    /** Bắt đầu model đầu hàng nếu rảnh và mạng cho phép; ngược lại đặt trạng thái chờ. An toàn khi gọi nhiều lần / từ nhiều luồng. */
    private fun pump() {
        var started = false
        var wait: NetworkPolicy.Wait? = null
        var waitName = ""
        var drained = false
        synchronized(lock) {
            if (job != null) return
            while (queue.isNotEmpty()) {
                val e = entry(queue[0])
                val urls = e?.let { ModelCatalogs.resolveUrls(it, releaseBase, allowHttp) }.orEmpty()
                if (e == null || slotFile(e.slot) == null || urls.isEmpty()) { queue.removeAt(0); continue }   // danh mục đổi / slot lạ
                wait = NetworkPolicy.waitReason(wifiOnlyNow, allowMeteredNow, network())
                if (wait == null) {
                    started = true
                    cancelActive = false
                    _state.update { it.copy(activeId = e.id, progress = 0f, waiting = null, queue = queue.toList()) }
                    say("Đang tải ${e.name}…")
                    job = scope.launch(Dispatchers.IO) { finish(e, runWithRetries(e, urls)) }
                } else {
                    waitName = e.name
                }
                break
            }
            drained = queue.isEmpty()
        }
        if (started) return
        val before = _state.value.waiting
        _state.update { it.copy(activeId = null, progress = 0f, waiting = if (drained) null else wait, queue = snapshotQueue()) }
        if (drained) {
            allowMeteredNow = false
            _state.update { it.copy(meteredAllowed = false) }
            persistQueue()
            notifyKeepAlive(false)
        } else if (wait != before) {
            when (wait) {
                NetworkPolicy.Wait.WIFI -> say("Đang chờ Wi-Fi để tải $waitName — hoặc bấm \"Tải bằng dữ liệu di động lần này\".")
                NetworkPolicy.Wait.NETWORK -> say("Không có mạng — sẽ tải tiếp $waitName khi có mạng.")
                null -> {}
            }
        }
    }

    private suspend fun runWithRetries(e: ModelEntry, urls: List<String>): ModelDownloader.Result {
        val tmp = File(workDir, e.file)
        var attempt = 0
        while (true) {
            val r = try {
                downloader.download(urls, tmp, e.sizeBytes, e.sha256, { cancelActive || !NetworkPolicy.allows(wifiOnlyNow, allowMeteredNow, network()) }) { done, total ->
                    _state.update { s -> s.copy(progress = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f) }
                }
            } catch (x: CancellationException) {
                throw x
            } catch (x: Exception) {
                ModelDownloader.Result(null, ModelDownloader.Err.NETWORK, x.message ?: x.javaClass.simpleName)
            }
            // lỗi mạng thoáng qua: thử lại (tải tiếp từ .part). Mất hẳn mạng / bị chính sách chặn / người dùng hủy ⇒ trả về để finish() quyết định.
            if (r.err != ModelDownloader.Err.NETWORK || attempt >= retryDelaysMs.size || cancelActive) return r
            if (!NetworkPolicy.allows(wifiOnlyNow, allowMeteredNow, network())) return r
            delay(retryDelaysMs[attempt++])
        }
    }

    private fun finish(e: ModelEntry, r: ModelDownloader.Result) {
        var message: String? = null
        var report = false
        var ok = r.ok
        synchronized(lock) {
            job = null
            val userCancelled = cancelActive
            cancelActive = false
            when {
                r.ok -> { queue.remove(e.id); report = true; message = "Đã tải xong ${e.name}." }
                // chính sách mạng làm dừng (đổi sang dữ liệu di động khi đang chỉ Wi-Fi, hoặc mất mạng): GIỮ trong hàng đợi;
                // pump() đặt trạng thái chờ + nói lý do, rồi tải tiếp khi mạng cho phép (onNetworkChanged)
                r.err == ModelDownloader.Err.CANCELLED -> if (userCancelled) message = "Đã hủy tải ${e.name}."
                r.err == ModelDownloader.Err.NETWORK && network() == NetKind.OFFLINE -> {}
                else -> {
                    queue.remove(e.id)
                    report = true
                    message = when (r.err) {
                        ModelDownloader.Err.SHA256 -> "Tệp tải về không khớp mã SHA-256 — đã xóa, hãy thử lại sau."
                        ModelDownloader.Err.SPACE -> "Không đủ dung lượng trống (cần khoảng ${r.detail} MB)."
                        ModelDownloader.Err.NETWORK -> "Mất kết nối khi tải ${e.name} — bấm Tải để tải tiếp từ chỗ đã tải."
                        else -> "Tải ${e.name} lỗi: ${r.detail}"
                    }
                }
            }
        }
        _state.update { it.copy(activeId = null, progress = 0f) }
        persistQueue()
        message?.let { say(it) }
        if (r.ok) {
            try {
                install(e.slot, r.file!!)
            } catch (x: Exception) {
                ok = false
                message = "Không nạp được ${e.name}: ${x.message ?: x.javaClass.simpleName}"
                say(message!!)
            }
        }
        if (report) runCatching { onResult?.invoke(e, ok, message.orEmpty()) }
        pump()
    }

    private fun snapshotQueue(): List<String> = synchronized(lock) { queue.toList() }

    private fun syncQueue() {
        val q = snapshotQueue()
        _state.update { it.copy(queue = q, waiting = if (q.isEmpty()) null else it.waiting) }
    }

    private fun notifyKeepAlive(on: Boolean) {
        runCatching { onKeepAlive?.invoke(on) }
    }

    private fun persistQueue() {
        val f = queueFile ?: return
        runCatching {
            val ids = snapshotQueue()
            if (ids.isEmpty()) f.delete() else { f.absoluteFile.parentFile?.mkdirs(); f.writeText(ids.joinToString("\n")) }
        }
    }

    private fun restoreQueue() {
        val f = queueFile ?: return
        val ids = runCatching { f.readLines().map { it.trim() }.filter { it.isNotEmpty() } }.getOrDefault(emptyList())
        if (ids.isEmpty()) return
        synchronized(lock) { for (id in ids) if (entry(id) != null && id !in queue) queue.add(id) }
        syncQueue()
    }

    // ------------------------------------------------------------------ điều khoản

    private fun accepted(id: String): Boolean =
        runCatching { consentFile.readLines().any { it.trim() == id } }.getOrDefault(false)

    private fun remember(id: String) {
        runCatching {
            consentFile.absoluteFile.parentFile?.mkdirs()
            if (!accepted(id)) consentFile.appendText(id + "\n")
        }
    }

    /** Dọn tệp tạm: tệp đã tải xong quá 1 giờ (đã được nạp) và `.part` bỏ dở quá 3 ngày. */
    private fun purgeStale() {
        val now = System.currentTimeMillis()
        workDir.listFiles()?.forEach { f ->
            val age = now - f.lastModified()
            if (f.name.endsWith(".part")) { if (age > 3L * 24 * 3600 * 1000) f.delete() } else if (age > 3600L * 1000) f.delete()
        }
    }

    companion object {
        /** Tải một tệp văn bản nhỏ (danh mục) — null nếu lỗi hoặc quá lớn. */
        fun httpGetText(url: String, maxBytes: Int = 512 * 1024): String? {
            var c: HttpURLConnection? = null
            return try {
                c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10_000
                c.readTimeout = 15_000
                c.setRequestProperty("User-Agent", "AIPhotoStudio-ModelCatalog/1")
                if (c.responseCode != 200) return null
                val out = ByteArrayOutputStream()
                c.inputStream.use { ins ->
                    val buf = ByteArray(8192)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > maxBytes) return null
                    }
                }
                String(out.toByteArray(), Charsets.UTF_8)
            } catch (e: Exception) {
                null
            } finally {
                c?.disconnect()
            }
        }
    }
}
