package com.aiphoto.studio.util

import android.app.Activity
import android.content.ClipDescription
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.view.DragAndDropPermissions
import android.view.DragEvent
import android.view.View

/**
 * R42: nhận ảnh KÉO-THẢ từ ứng dụng khác — vd. trình quản lý tệp ở cửa sổ nhỏ / chia đôi màn hình (Android 7.0+ cho kéo thả giữa hai ứng dụng
 * khi cả hai cùng hiện trên màn hình). Gắn vào view GỐC của cửa sổ (`rootView.setOnDragListener(...)`): view Compose không đăng ký đích thả nên
 * sự kiện rơi xuống view gốc. `MainActivity` đã `resizeableActivity="true"` nên chạy được trong cửa sổ nhỏ / chia đôi.
 *
 * Quyền đọc URI `content://` của ứng dụng kia chỉ có khi gọi `Activity.requestDragAndDropPermissions(event)` TRONG lúc xử lý ACTION_DROP;
 * quyền kéo dài tới khi `release()` hoặc activity bị hủy ⇒ giữ lại cho đến lần thả sau để việc giải mã ảnh (chạy bất đồng bộ) vẫn đọc được.
 */
class ImageDropTarget(
    private val context: Context,
    private val onHover: (Boolean) -> Unit,
    private val onImages: (List<Uri>) -> Unit
) : View.OnDragListener {
    private var held: DragAndDropPermissions? = null

    override fun onDrag(v: View, event: DragEvent): Boolean = when (event.action) {
        DragEvent.ACTION_DRAG_STARTED -> ImageDrop.mayContainImage(mimeTypes(event.clipDescription))   // true = muốn nhận các sự kiện tiếp theo
        DragEvent.ACTION_DRAG_ENTERED -> { onHover(true); true }
        DragEvent.ACTION_DRAG_LOCATION -> true
        DragEvent.ACTION_DRAG_EXITED -> { onHover(false); true }
        DragEvent.ACTION_DROP -> { onHover(false); drop(event) }
        DragEvent.ACTION_DRAG_ENDED -> { onHover(false); true }
        else -> false
    }

    private fun mimeTypes(d: ClipDescription?): List<String> =
        if (d == null) emptyList() else (0 until d.mimeTypeCount).mapNotNull { d.getMimeType(it) }

    private fun drop(event: DragEvent): Boolean {
        val clip = event.clipData ?: return false
        val perms = runCatching { activityOf(context)?.requestDragAndDropPermissions(event) }.getOrNull()
        val items = ArrayList<ImageDrop.Item<Uri>>()
        for (i in 0 until clip.itemCount) {
            val u = clip.getItemAt(i)?.uri ?: continue
            val scheme = u.scheme
            if (scheme != "content" && scheme != "file") continue                     // liên kết web (http…) không phải tệp ảnh
            val mime = runCatching { context.contentResolver.getType(u) }.getOrNull()
            items.add(ImageDrop.Item(u, mime, u.lastPathSegment))
        }
        val images = ImageDrop.pickImages(items)
        if (images.isNotEmpty()) { release(); held = perms } else runCatching { perms?.release() }
        onImages(images)
        return true
    }

    /** Trả quyền đọc đã nhận (gọi khi giao diện bị hủy). */
    fun release() {
        runCatching { held?.release() }
        held = null
    }

    private fun activityOf(c: Context?): Activity? {
        var cur: Context? = c
        var n = 0
        while (cur != null && n < 8) {
            if (cur is Activity) return cur
            cur = (cur as? ContextWrapper)?.baseContext
            n++
        }
        return null
    }
}
