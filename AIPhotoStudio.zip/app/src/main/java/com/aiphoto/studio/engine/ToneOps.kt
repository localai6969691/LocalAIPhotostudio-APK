package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Các phép chỉnh "chuyên nghiệp" có tham số dạng chuỗi (arg): Levels, Curves, HSL + Clarity, Grain, tách tần số. */
object ToneOps {

    private fun red(p: Int) = (p shr 16) and 255
    private fun green(p: Int) = (p shr 8) and 255
    private fun blue(p: Int) = p and 255
    private fun cl(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()
    private fun pack(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private fun lum(p: Int): Float = 0.299f * red(p) + 0.587f * green(p) + 0.114f * blue(p)
    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun applyLut(b: Bitmap, lr: IntArray, lg: IntArray, lb: IntArray): Bitmap {
        val px = readPixels(b)
        for (i in px.indices) {
            val p = px[i]
            px[i] = pack(p ushr 24, lr[red(p)], lg[green(p)], lb[blue(p)])
        }
        return makeBitmap(px, b.width, b.height)
    }

    // ------------------------------------------------------------------ Levels
    /** arg = "đen,trắng,gamma" (0..1, 0..1, 0.2..5). gamma > 1 làm sáng vùng giữa. */
    fun levels(b: Bitmap, arg: String?): Bitmap {
        val p = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: return b
        if (p.size < 3) return b
        val black = p[0].coerceIn(0f, 0.95f)
        val white = p[1].coerceIn(black + 0.02f, 1f)
        val gamma = p[2].coerceIn(0.2f, 5f)
        val lut = IntArray(256) { v ->
            val x = ((v / 255f - black) / (white - black)).coerceIn(0f, 1f)
            (x.pow(1f / gamma) * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return applyLut(b, lut, lut, lut)
    }

    // ------------------------------------------------------------------ Curves
    fun parsePoints(s: String): List<Pair<Float, Float>> =
        s.split(';').mapNotNull { seg ->
            val xy = seg.split(',')
            if (xy.size != 2) null else {
                val x = xy[0].trim().toFloatOrNull()
                val y = xy[1].trim().toFloatOrNull()
                if (x == null || y == null) null else Pair(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))
            }
        }.sortedBy { it.first }

    /** Nội suy khối đơn điệu (Fritsch–Carlson) qua các điểm điều khiển -> LUT 256 giá trị. */
    fun curveLut(raw: List<Pair<Float, Float>>): IntArray {
        val pts = ArrayList<Pair<Float, Float>>()
        for (p in raw.sortedBy { it.first }) if (pts.isEmpty() || p.first - pts.last().first > 1e-3f) pts.add(p)
        if (pts.isEmpty() || pts.first().first > 1e-3f) pts.add(0, Pair(0f, 0f))
        if (pts.last().first < 1f - 1e-3f) pts.add(Pair(1f, 1f))
        val n = pts.size
        if (n < 2) return IntArray(256) { it }
        val x = FloatArray(n) { pts[it].first }
        val y = FloatArray(n) { pts[it].second }
        val d = FloatArray(n - 1) { (y[it + 1] - y[it]) / (x[it + 1] - x[it]) }
        val m = FloatArray(n)
        m[0] = d[0]
        m[n - 1] = d[n - 2]
        for (k in 1 until n - 1) m[k] = if (d[k - 1] * d[k] <= 0f) 0f else (d[k - 1] + d[k]) / 2f
        for (k in 0 until n - 1) {
            if (d[k] == 0f) {
                m[k] = 0f; m[k + 1] = 0f
            } else {
                val a = m[k] / d[k]
                val bb = m[k + 1] / d[k]
                val s = a * a + bb * bb
                if (s > 9f) {
                    val t = 3f / sqrt(s)
                    m[k] = t * a * d[k]
                    m[k + 1] = t * bb * d[k]
                }
            }
        }
        val lut = IntArray(256)
        var seg = 0
        for (i in 0..255) {
            val xv = i / 255f
            while (seg < n - 2 && xv > x[seg + 1]) seg++
            val h = x[seg + 1] - x[seg]
            val t = ((xv - x[seg]) / h).coerceIn(0f, 1f)
            val t2 = t * t
            val t3 = t2 * t
            val v = (2 * t3 - 3 * t2 + 1) * y[seg] + (t3 - 2 * t2 + t) * h * m[seg] +
                (-2 * t3 + 3 * t2) * y[seg + 1] + (t3 - t2) * h * m[seg + 1]
            lut[i] = (v.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        }
        return lut
    }

    private fun parseCurves(arg: String): Map<String, IntArray> {
        val out = HashMap<String, IntArray>()
        for (part in arg.split('|')) {
            val kv = part.split(':', limit = 2)
            if (kv.size == 2) out[kv[0].trim()] = curveLut(parsePoints(kv[1]))
        }
        return out
    }

    fun isIdentityCurves(arg: String?): Boolean {
        if (arg.isNullOrBlank()) return true
        return parseCurves(arg).values.all { lut -> lut.indices.all { abs(lut[it] - it) <= 1 } }
    }

    /** arg = "m:0,0;0.5,0.62;1,1|r:...|g:...|b:..." (m = RGB tổng, r/g/b = từng kênh). */
    fun curves(b: Bitmap, arg: String?): Bitmap {
        if (arg.isNullOrBlank()) return b
        val luts = parseCurves(arg)
        val id = IntArray(256) { it }
        val mm = luts["m"] ?: id
        val rr = luts["r"] ?: id
        val gg = luts["g"] ?: id
        val bb = luts["b"] ?: id
        return applyLut(b, IntArray(256) { mm[rr[it]] }, IntArray(256) { mm[gg[it]] }, IntArray(256) { mm[bb[it]] })
    }

    // ------------------------------------------------------------------ HSL theo 8 dải màu
    /** arg = 24 số: với mỗi dải (đỏ, cam, vàng, lục, lam nhạt, lam, tím, hồng) -> sắc độ, bão hòa, độ sáng (-1..1). */
    fun hsl(b: Bitmap, arg: String?): Bitmap {
        val v = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: return b
        if (v.size < 24 || v.all { abs(it) < 0.005f }) return b
        val centers = floatArrayOf(0f, 30f, 60f, 120f, 180f, 240f, 270f, 300f)
        val px = readPixels(b)
        for (i in px.indices) {
            val p = px[i]
            val r = red(p) / 255f
            val g = green(p) / 255f
            val bl = blue(p) / 255f
            val mx = max(r, max(g, bl))
            val mn = min(r, min(g, bl))
            val d = mx - mn
            if (d < 0.02f) continue
            var h = when {
                mx == r -> { val t = (g - bl) / d; 60f * (if (t < 0f) t + 6f else t) }
                mx == g -> 60f * ((bl - r) / d + 2f)
                else -> 60f * ((r - g) / d + 4f)
            }
            val s = d / mx
            var dh = 0f
            var ds = 0f
            var dl = 0f
            for (k in 0 until 8) {
                var diff = abs(h - centers[k])
                if (diff > 180f) diff = 360f - diff
                val wgt = 1f - diff / 50f
                if (wgt > 0f) {
                    dh += wgt * v[k * 3] * 30f
                    ds += wgt * v[k * 3 + 1]
                    dl += wgt * v[k * 3 + 2]
                }
            }
            val sw = smooth(0.05f, 0.3f, s)
            h = (h + dh * sw + 360f) % 360f
            val ns = (s * (1f + ds.coerceIn(-1f, 1f) * sw)).coerceIn(0f, 1f)
            val nv = (mx * (1f + dl.coerceIn(-1f, 1f) * 0.5f * sw)).coerceIn(0f, 1f)
            val c = nv * ns
            val hp = h / 60f
            val x = c * (1f - abs(hp % 2f - 1f))
            val m0 = nv - c
            val rr: Float
            val gg: Float
            val bb: Float
            when (hp.toInt()) {
                0 -> { rr = c; gg = x; bb = 0f }
                1 -> { rr = x; gg = c; bb = 0f }
                2 -> { rr = 0f; gg = c; bb = x }
                3 -> { rr = 0f; gg = x; bb = c }
                4 -> { rr = x; gg = 0f; bb = c }
                else -> { rr = c; gg = 0f; bb = x }
            }
            px[i] = pack(p ushr 24, cl((rr + m0) * 255f), cl((gg + m0) * 255f), cl((bb + m0) * 255f))
        }
        return makeBitmap(px, b.width, b.height)
    }

    // ------------------------------------------------------------------ Clarity / Grain
    /** Tương phản cục bộ vùng giữa (bán kính lớn). v < 0 = làm mềm. */
    fun clarity(b: Bitmap, v: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = readPixels(b)
        val bl = Blur.gaussian(src, w, h, max(6, max(w, h) / 80))
        val amount = 1.1f * v
        val out = IntArray(src.size)
        for (i in src.indices) {
            val p = src[i]
            val q = bl[i]
            val l = lum(p) / 255f
            val mid = 1f - (2f * l - 1f) * (2f * l - 1f) * 0.7f
            val k = amount * mid
            out[i] = pack(
                p ushr 24,
                cl(red(p) + k * (red(p) - red(q))),
                cl(green(p) + k * (green(p) - green(q))),
                cl(blue(p) + k * (blue(p) - blue(q)))
            )
        }
        return makeBitmap(out, w, h)
    }

    fun grain(b: Bitmap, amount: Float): Bitmap {
        val px = readPixels(b)
        val rnd = java.util.Random(1234L)
        val amp = 38f * amount
        for (i in px.indices) {
            val p = px[i]
            val l = lum(p) / 255f
            val wgt = 1f - abs(2f * l - 1f) * 0.6f
            val n = ((rnd.nextFloat() + rnd.nextFloat() + rnd.nextFloat()) / 3f - 0.5f) * 2f * amp * wgt
            px[i] = pack(p ushr 24, cl(red(p) + n), cl(green(p) + n), cl(blue(p) + n))
        }
        return makeBitmap(px, b.width, b.height)
    }

    // ------------------------------------------------------------------ Tách tần số (retouch da)
    private fun skinMask(src: IntArray, w: Int, h: Int): IntArray {
        val mask = IntArray(w * h)
        for (i in src.indices) {
            val p = src[i]
            val r = red(p).toFloat()
            val g = green(p).toFloat()
            val bl = blue(p).toFloat()
            val cb = 128f - 0.168736f * r - 0.331264f * g + 0.5f * bl
            val cr = 128f + 0.5f * r - 0.418688f * g - 0.081312f * bl
            val y = 0.299f * r + 0.587f * g + 0.114f * bl
            val m = if (cb in 77f..127f && cr in 133f..173f && y > 40f) 255 else 0
            mask[i] = pack(255, m, m, m)
        }
        return Blur.gaussian(mask, w, h, max(2, max(w, h) / 250))
    }

    /**
     * Frequency separation: low = ảnh mờ nhẹ (màu/ánh sáng), high = ảnh - low (kết cấu: lỗ chân lông...).
     * Làm mịn CHỈ tầng low trong vùng da rồi cộng lại high -> da đều màu nhưng vẫn còn kết cấu, không "da nhựa".
     */
    fun freqSep(b: Bitmap, strength: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = readPixels(b)
        val long = max(w, h)
        val low = Blur.gaussian(src, w, h, max(2, (long * 0.003f).toInt()))
        val low2 = Blur.gaussian(low, w, h, max(5, (long * 0.012f).toInt()))
        val mask = skinMask(src, w, h)
        val out = IntArray(src.size)
        for (i in src.indices) {
            val k = (strength * ((mask[i] and 255) / 255f)).coerceIn(0f, 1f)
            val p = src[i]
            val l = low[i]
            val l2 = low2[i]
            val tex = 1f - 0.2f * k
            val r = red(l) + (red(l2) - red(l)) * k + (red(p) - red(l)) * tex
            val g = green(l) + (green(l2) - green(l)) * k + (green(p) - green(l)) * tex
            val bl = blue(l) + (blue(l2) - blue(l)) * k + (blue(p) - blue(l)) * tex
            out[i] = pack(p ushr 24, cl(r), cl(g), cl(bl))
        }
        return makeBitmap(out, w, h)
    }

    // ------------------------------------------------------------------ Khử nhiễu giữ cạnh
    fun denoise(b: Bitmap, s: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = readPixels(b)
        val bl = Blur.gaussian(src, w, h, max(1, (max(w, h) * 0.0025f).toInt()))
        val out = IntArray(src.size)
        for (i in src.indices) {
            val p = src[i]
            val q = bl[i]
            val d = abs(lum(p) - lum(q)) / 12f
            val k = (s * 1.4f / (1f + d * d)).coerceIn(0f, 1f) // vùng phẳng: mờ mạnh; cạnh: giữ nguyên
            out[i] = pack(
                p ushr 24,
                cl(red(p) + (red(q) - red(p)) * k),
                cl(green(p) + (green(q) - green(p)) * k),
                cl(blue(p) + (blue(q) - blue(p)) * k)
            )
        }
        return makeBitmap(out, w, h)
    }

    // ------------------------------------------------------------------ Cân bằng màu (bóng / giữa / sáng)
    /** arg = 9 số trong [-1,1]: (bóng: R,G,B), (giữa: R,G,B), (sáng: R,G,B). */
    fun colorBalance(b: Bitmap, arg: String?): Bitmap {
        val v = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() } ?: return b
        if (v.size < 9 || v.all { abs(it) < 0.005f }) return b
        val px = readPixels(b)
        for (i in px.indices) {
            val p = px[i]
            val l = lum(p) / 255f
            val sh = (1f - l) * (1f - l)
            val hi = l * l
            val mid = 4f * l * (1f - l)
            val dr = 48f * (sh * v[0] + mid * v[3] + hi * v[6])
            val dg = 48f * (sh * v[1] + mid * v[4] + hi * v[7])
            val db = 48f * (sh * v[2] + mid * v[5] + hi * v[8])
            px[i] = pack(p ushr 24, cl(red(p) + dr), cl(green(p) + dg), cl(blue(p) + db))
        }
        return makeBitmap(px, b.width, b.height)
    }

    // ------------------------------------------------------------------ Mờ chuyển động / xuyên tâm
    fun motionBlur(b: Bitmap, amount: Float, angleDeg: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = readPixels(b)
        val len = max(2f, amount * 0.05f * max(w, h))
        val n = 15
        val a = Math.toRadians(angleDeg.toDouble())
        val ux = cos(a).toFloat()
        val uy = sin(a).toFloat()
        val out = IntArray(src.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in 0 until n) {
                    val t = (k / (n - 1f) - 0.5f) * len
                    val sx = (x + t * ux + 0.5f).toInt().coerceIn(0, w - 1)
                    val sy = (y + t * uy + 0.5f).toInt().coerceIn(0, h - 1)
                    val p = src[sy * w + sx]
                    sr += red(p); sg += green(p); sb += blue(p)
                }
                out[y * w + x] = pack(src[y * w + x] ushr 24, sr / n, sg / n, sb / n)
            }
        }
        return makeBitmap(out, w, h)
    }

    fun radialBlur(b: Bitmap, amount: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = readPixels(b)
        val cx = w / 2f
        val cy = h / 2f
        val zoom = amount * 0.12f
        val n = 13
        val out = IntArray(src.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in 0 until n) {
                    val f = 1f - zoom * (k / (n - 1f))
                    val sx = (cx + (x - cx) * f + 0.5f).toInt().coerceIn(0, w - 1)
                    val sy = (cy + (y - cy) * f + 0.5f).toInt().coerceIn(0, h - 1)
                    val p = src[sy * w + sx]
                    sr += red(p); sg += green(p); sb += blue(p)
                }
                out[y * w + x] = pack(src[y * w + x] ushr 24, sr / n, sg / n, sb / n)
            }
        }
        return makeBitmap(out, w, h)
    }

    // ------------------------------------------------------------------ Khớp màu với ảnh mẫu (đặc tả histogram từng kênh)
    /** CDF 3×256 (R,G,B) mỗi giá trị 0..255 - dùng làm `arg` (base64) của COLOR_MATCH. */
    fun histogramCdf(b: Bitmap): ByteArray {
        val px = readPixels(b)
        val step = max(1, px.size / 250_000)
        val hist = Array(3) { IntArray(256) }
        var n = 0
        var i = 0
        while (i < px.size) {
            val p = px[i]
            hist[0][red(p)]++; hist[1][green(p)]++; hist[2][blue(p)]++
            n++
            i += step
        }
        val out = ByteArray(768)
        for (c in 0 until 3) {
            var acc = 0
            for (v in 0..255) {
                acc += hist[c][v]
                out[c * 256 + v] = ((acc.toFloat() / n) * 255f + 0.5f).toInt().coerceIn(0, 255).toByte()
            }
        }
        return out
    }

    fun colorMatch(b: Bitmap, arg: String?): Bitmap {
        val ref = try {
            java.util.Base64.getDecoder().decode(arg ?: return b)
        } catch (e: IllegalArgumentException) {
            return b
        }
        if (ref.size < 768) return b
        val cur = histogramCdf(b)
        val luts = Array(3) { c ->
            val lut = IntArray(256)
            var u = 0
            for (v in 0..255) {
                val target = cur[c * 256 + v].toInt() and 255
                while (u < 255 && (ref[c * 256 + u].toInt() and 255) < target) u++
                lut[v] = u
            }
            lut
        }
        return applyLut(b, luts[0], luts[1], luts[2])
    }

    // ------------------------------------------------------------------ Liquify (đẩy điểm ảnh theo nét kéo)
    private fun sample(src: IntArray, w: Int, h: Int, fx: Float, fy: Float): Int {
        val x = fx.coerceIn(0f, w - 1f)
        val y = fy.coerceIn(0f, h - 1f)
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(x0 + 1, w - 1)
        val y1 = min(y0 + 1, h - 1)
        val tx = x - x0
        val ty = y - y0
        val p00 = src[y0 * w + x0]; val p10 = src[y0 * w + x1]
        val p01 = src[y1 * w + x0]; val p11 = src[y1 * w + x1]
        fun ch(shift: Int): Int {
            val a = (p00 shr shift) and 255
            val b = (p10 shr shift) and 255
            val c = (p01 shr shift) and 255
            val d = (p11 shr shift) and 255
            return cl((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty)
        }
        return pack(p00 ushr 24, ch(16), ch(8), ch(0))
    }

    /** arg = "x,y,dx,dy,r;..." (x,y,dx,dy theo tỉ lệ ảnh; r theo tỉ lệ cạnh dài). Nội dung bị đẩy theo (dx,dy). */
    fun liquify(b: Bitmap, arg: String?): Bitmap {
        if (arg.isNullOrBlank()) return b
        val w = b.width
        val h = b.height
        val long = max(w, h)
        val dx = FloatArray(w * h)
        val dy = FloatArray(w * h)
        var any = false
        for (seg in arg.split(';')) {
            val f = seg.split(',').mapNotNull { it.trim().toFloatOrNull() }
            if (f.size < 5) continue
            val cx = f[0] * w
            val cy = f[1] * h
            val mx = f[2] * w
            val my = f[3] * h
            val r = max(4f, f[4] * long)
            val x0 = max(0, (cx - r).toInt())
            val x1 = min(w - 1, (cx + r).toInt())
            val y0 = max(0, (cy - r).toInt())
            val y1 = min(h - 1, (cy + r).toInt())
            for (y in y0..y1) {
                for (x in x0..x1) {
                    val ddx = x - cx
                    val ddy = y - cy
                    val d2 = ddx * ddx + ddy * ddy
                    if (d2 >= r * r) continue
                    val t = 1f - sqrt(d2) / r
                    val wgt = t * t * (3f - 2f * t)
                    dx[y * w + x] += mx * wgt
                    dy[y * w + x] += my * wgt
                    }
            }
            any = true
        }
        if (!any) return b
        val src = readPixels(b)
        val out = IntArray(src.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                out[i] = if (dx[i] == 0f && dy[i] == 0f) src[i] else sample(src, w, h, x - dx[i], y - dy[i])
            }
        }
        return makeBitmap(out, w, h)
    }
}
