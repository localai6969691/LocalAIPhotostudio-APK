package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

enum class GenQuality { FAST, HIGH }

/** Tùy chọn chung khi tạo ảnh (nhanh/chất lượng, seed, prompt phủ định, độ mạnh); 0/rỗng = tự động. */
data class GenOptions(
    val quality: GenQuality = GenQuality.FAST,
    val seed: Long = -1L,
    val negative: String = "",
    val strength: Float? = null
)

/** Nơi xử lý "thêm / thay vật thể". Mặt nạ: 255 = vùng được phép thay đổi. Ảnh trả về cùng kích thước ảnh vào. */
interface GenerativeFill {
    fun inpaint(image: Bitmap, mask: ByteArray, prompt: String, size: Int, opts: GenOptions = GenOptions()): Bitmap
    fun cancel()
}

enum class GenProvider { CLOUD_GEMINI, LAN_SD }

data class CropRect(val x: Int, val y: Int, val w: Int, val h: Int)

/**
 * Cắt vùng quanh mặt nạ (kèm ngữ cảnh) rồi dán kết quả sinh ảnh về ĐÚNG vùng mặt nạ.
 * Nhờ bước dán cục bộ này, phần ngoài mặt nạ luôn giữ nguyên điểm ảnh gốc và độ phân giải gốc,
 * dù dịch vụ sinh ảnh (cloud) có đổi kích thước/chỉnh sửa lan ra ngoài vùng chọn.
 */
object RegionCrop {

    fun compute(mask: ByteArray, w: Int, h: Int): CropRect? {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (mask[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return null

        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        val margin = max(64, (max(bw, bh) * 0.8f).toInt())
        var x0 = max(0, minX - margin)
        var y0 = max(0, minY - margin)
        var x1 = min(w, maxX + 1 + margin)
        var y1 = min(h, maxY + 1 + margin)
        var cw = x1 - x0
        var ch = y1 - y0
        val side = max(max(cw, ch), min(min(w, h), 384))
        if (side <= min(w, h)) {
            val cx = (x0 + x1) / 2
            val cy = (y0 + y1) / 2
            x0 = (cx - side / 2).coerceIn(0, w - side)
            y0 = (cy - side / 2).coerceIn(0, h - side)
            cw = side
            ch = side
        }
        return CropRect(x0, y0, cw, ch)
    }

    /** Mặt nạ trong vùng cắt dưới dạng ảnh xám ARGB (trắng = sửa). */
    fun maskGray(mask: ByteArray, w: Int, r: CropRect): IntArray =
        IntArray(r.w * r.h) { i ->
            val x = i % r.w
            val y = i / r.w
            if (mask[(r.y + y) * w + (r.x + x)].toInt() != 0) -1 else (255 shl 24)
        }

    /**
     * Dán [generated] (đã đúng kích thước r.w×r.h) vào [src] theo mặt nạ mềm.
     * [exact] = chỉ thay đúng các điểm có mặt nạ (rìa cứng, không nới) → điểm ngoài mặt nạ giữ nguyên từng bit.
     */
    fun composite(src: Bitmap, mask: ByteArray, r: CropRect, generated: Bitmap, exact: Boolean = false): Bitmap {
        val w = src.width
        val h = src.height
        if (exact) {
            val gpx = IntArray(r.w * r.h)
            generated.getPixels(gpx, 0, r.w, 0, 0, r.w, r.h)
            val px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            val alpha = FloatArray(r.w * r.h) { if (mask[(r.y + it / r.w) * w + (r.x + it % r.w)].toInt() != 0) 1f else 0f }
            InpaintEdge.paste(px, w, r.x, r.y, r.w, r.h, gpx, alpha)
            val exactBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            exactBmp.setPixels(px, 0, w, 0, 0, w, h)
            return exactBmp
        }
        val gray = maskGray(mask, w, r)
        val side = max(r.w, r.h)
        val grown = Blur.gaussian(gray, r.w, r.h, max(2, side / 200))
        val hard = IntArray(gray.size) { if ((grown[it] and 255) > 10) -1 else (255 shl 24) }
        val feather = Blur.gaussian(hard, r.w, r.h, max(2, side / 100))

        val gp = IntArray(r.w * r.h)
        generated.getPixels(gp, 0, r.w, 0, 0, r.w, r.h)
        val out = IntArray(w * h)
        src.getPixels(out, 0, w, 0, 0, w, h)
        for (y in 0 until r.h) {
            for (x in 0 until r.w) {
                val a = (feather[y * r.w + x] and 255) / 255f
                if (a <= 0.003f) continue
                val i = (r.y + y) * w + (r.x + x)
                val o = out[i]
                val g = gp[y * r.w + x]
                val rr = (((o shr 16) and 255) * (1f - a) + ((g shr 16) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                val gg = (((o shr 8) and 255) * (1f - a) + ((g shr 8) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                val bb = ((o and 255) * (1f - a) + (g and 255) * a + 0.5f).toInt().coerceIn(0, 255)
                out[i] = (o and (0xFF shl 24)) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }
}
