package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Chuyển ảnh sang phong cách tranh (tranh sơn dầu / hoạt hình / màu nước) KHÔNG cần model, hoàn toàn bằng thuật toán cổ điển trên ARGB.
 *  - Nền tảng chung là bộ lọc Kuwahara 4 góc (làm phẳng vùng đồng màu nhưng GIỮ cạnh): mỗi điểm lấy màu trung bình của góc
 *    (trong 4 ô vuông (r+1)×(r+1) chung đỉnh tại điểm đó) có phương sai độ chói NHỎ nhất. Tích phân ảnh cho chi phí O(1) / điểm, làm theo
 *    từng dải hàng nên bộ nhớ tạm không phụ thuộc chiều cao ảnh.
 *  - Sơn dầu = Kuwahara bán kính lớn. Hoạt hình = Kuwahara nhẹ + lượng tử hóa độ chói mềm (giữ sắc độ) + nét viền tối theo Sobel.
 *    Màu nước = Kuwahara + hòa nhẹ sắc tố + sáng/nhạt như giấy + viền đậm màu ở mép + vân giấy (nhiễu giá trị xác định).
 *  - Mọi bán kính tính theo CẠNH DÀI ảnh nên ảnh xem trước và ảnh đầy đủ trông cùng một kiểu; nhiễu giấy theo toạ độ chuẩn hóa nên
 *    kết quả xác định (cùng đầu vào → cùng đầu ra).
 * Giới hạn: đây là bộ lọc phong cách "kiểu", không hiểu nội dung (không vẽ lại khuôn mặt thành anime); muốn kiểu nghệ thuật phức tạp hơn
 * thì dùng đường sinh ảnh AI (xem GenIntent / "restyle"). Các hằng số do ước lượng bằng mắt trên ảnh tổng hợp, chưa chỉnh trên ảnh thật.
 */
object Stylize {

    const val OIL = "oil"
    const val CARTOON = "cartoon"
    const val WATERCOLOR = "watercolor"
    val NAMES = listOf(OIL, CARTOON, WATERCOLOR)

    /** Tên phong cách chuẩn (chữ thường) hoặc null nếu không hợp lệ. */
    fun canonical(arg: String?): String? = arg?.trim()?.lowercase(Locale.ROOT)?.takeIf { it in NAMES }

    fun label(arg: String?): String = when (canonical(arg)) {
        OIL -> "tranh sơn dầu"
        CARTOON -> "hoạt hình"
        WATERCOLOR -> "màu nước"
        else -> "phong cách"
    }

    private fun rd(p: Int) = (p shr 16) and 255
    private fun gr(p: Int) = (p shr 8) and 255
    private fun bl(p: Int) = p and 255
    private fun lumaI(p: Int) = (299 * rd(p) + 587 * gr(p) + 114 * bl(p)) / 1000
    private fun clamp8(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()
    private fun smooth01(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    /** Bán kính theo cạnh dài: [long]/[div], kẹp trong [lo, hi]. */
    fun radius(w: Int, h: Int, div: Float, lo: Int = 2, hi: Int = 14): Int = (max(w, h) / div).roundToInt().coerceIn(lo, hi)

    // ------------------------------------------------------------------ Kuwahara
    /** Bộ lọc Kuwahara 4 góc bán kính [r] (ô (r+1)×(r+1)). Alpha giữ nguyên. */
    fun kuwahara(px: IntArray, w: Int, h: Int, r: Int): IntArray {
        require(px.size == w * h && r >= 1)
        val out = IntArray(px.size)
        val iw = w + 1
        // số hàng nguồn mỗi dải: giữ mỗi mảng tích phân ≲ 1,6 triệu phần tử
        val bandRows = max(16, min(h, 1_600_000 / iw - 2 * r - 2))
        var y0 = 0
        while (y0 < h) {
            val y1 = min(h, y0 + bandRows)
            val sy0 = max(0, y0 - r)
            val sy1 = min(h, y1 + r + 1)
            val rows = sy1 - sy0
            val sr = LongArray(iw * (rows + 1))
            val sg = LongArray(iw * (rows + 1))
            val sb = LongArray(iw * (rows + 1))
            val sl = LongArray(iw * (rows + 1))
            val sq = LongArray(iw * (rows + 1))
            for (yy in 0 until rows) {
                var ar = 0L; var ag = 0L; var ab = 0L; var al = 0L; var aq = 0L
                val src = (sy0 + yy) * w
                for (x in 0 until w) {
                    val p = px[src + x]
                    val l = lumaI(p).toLong()
                    ar += rd(p); ag += gr(p); ab += bl(p); al += l; aq += l * l
                    val i = (yy + 1) * iw + x + 1
                    val up = yy * iw + x + 1
                    sr[i] = sr[up] + ar; sg[i] = sg[up] + ag; sb[i] = sb[up] + ab; sl[i] = sl[up] + al; sq[i] = sq[up] + aq
                }
            }
            for (y in y0 until y1) {
                val ry = y - sy0
                for (x in 0 until w) {
                    var bestVar = Double.MAX_VALUE
                    var bR = 0L; var bG = 0L; var bB = 0L; var bN = 1L
                    for (quad in 0 until 4) {
                        val xa = if (quad and 1 == 0) max(0, x - r) else x
                        val xb = if (quad and 1 == 0) x else min(w - 1, x + r)
                        val ya = if (quad and 2 == 0) max(sy0, y - r) - sy0 else ry
                        val yb = if (quad and 2 == 0) ry else min(sy1 - 1, y + r) - sy0
                        val a = ya * iw + xa
                        val b = ya * iw + xb + 1
                        val c = (yb + 1) * iw + xa
                        val d = (yb + 1) * iw + xb + 1
                        val n = ((xb - xa + 1) * (yb - ya + 1)).toLong()
                        val ml = (sl[d] - sl[b] - sl[c] + sl[a]).toDouble() / n
                        val v = (sq[d] - sq[b] - sq[c] + sq[a]).toDouble() / n - ml * ml
                        if (v < bestVar) {
                            bestVar = v; bN = n
                            bR = sr[d] - sr[b] - sr[c] + sr[a]
                            bG = sg[d] - sg[b] - sg[c] + sg[a]
                            bB = sb[d] - sb[b] - sb[c] + sb[a]
                        }
                    }
                    val o = y * w + x
                    out[o] = (px[o] and (0xFF shl 24)) or (((bR + bN / 2) / bN).toInt() shl 16) or (((bG + bN / 2) / bN).toInt() shl 8) or ((bB + bN / 2) / bN).toInt()
                }
            }
            y0 = y1
        }
        return out
    }

    // ------------------------------------------------------------------ tiện ích
    private fun lumaF(px: IntArray): FloatArray = FloatArray(px.size) { lumaI(px[it]).toFloat() }

    /** Độ lớn gradient Sobel (0..~1440) của kênh [l]; viền ngoài lấy 0. */
    fun sobel(l: FloatArray, w: Int, h: Int): FloatArray {
        val m = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = (l[i - w + 1] + 2 * l[i + 1] + l[i + w + 1]) - (l[i - w - 1] + 2 * l[i - 1] + l[i + w - 1])
            val gy = (l[i + w - 1] + 2 * l[i + w] + l[i + w + 1]) - (l[i - w - 1] + 2 * l[i - w] + l[i - w + 1])
            m[i] = sqrt(gx * gx + gy * gy)
        }
        return m
    }

    /** Làm mờ hộp tách được (một lượt) bán kính [rad], viền lặp. */
    fun boxBlur(src: FloatArray, w: Int, h: Int, rad: Int): FloatArray {
        if (rad <= 0) return src.copyOf()
        val t = FloatArray(w * h)
        val o = FloatArray(w * h)
        val k = 2 * rad + 1
        for (y in 0 until h) {
            var acc = 0f
            for (i in -rad..rad) acc += src[y * w + i.coerceIn(0, w - 1)]
            t[y * w] = acc / k
            for (x in 1 until w) {
                acc += src[y * w + (x + rad).coerceIn(0, w - 1)] - src[y * w + (x - rad - 1).coerceIn(0, w - 1)]
                t[y * w + x] = acc / k
            }
        }
        for (x in 0 until w) {
            var acc = 0f
            for (i in -rad..rad) acc += t[i.coerceIn(0, h - 1) * w + x]
            o[x] = acc / k
            for (y in 1 until h) {
                acc += t[(y + rad).coerceIn(0, h - 1) * w + x] - t[(y - rad - 1).coerceIn(0, h - 1) * w + x]
                o[y * w + x] = acc / k
            }
        }
        return o
    }

    private fun hash01(x: Int, y: Int, seed: Int): Float {
        var v = x * 374761393 + y * 668265263 + seed * 1442695041
        v = (v xor (v ushr 13)) * 1274126177
        v = v xor (v ushr 16)
        return (v and 0xFFFFFF) / 16777215f
    }

    /** Nhiễu giá trị trơn 0..1 tại toạ độ lưới ([u],[v]) (xác định theo [seed]). */
    fun valueNoise(u: Float, v: Float, seed: Int): Float {
        val x0 = floor(u).toInt(); val y0 = floor(v).toInt()
        val fx = u - x0; val fy = v - y0
        val sx = fx * fx * (3f - 2f * fx); val sy = fy * fy * (3f - 2f * fy)
        val a = hash01(x0, y0, seed); val b = hash01(x0 + 1, y0, seed)
        val c = hash01(x0, y0 + 1, seed); val d = hash01(x0 + 1, y0 + 1, seed)
        return (a * (1 - sx) + b * sx) * (1 - sy) + (c * (1 - sx) + d * sx) * sy
    }

    // ------------------------------------------------------------------ ba phong cách
    /** Sơn dầu: Kuwahara bán kính ≈ cạnh dài/380 (2..10 điểm ảnh). */
    fun oil(px: IntArray, w: Int, h: Int): IntArray = kuwahara(px, w, h, radius(w, h, 380f, 2, 10))

    /** Hoạt hình: làm phẳng + lượng tử độ chói mềm (7 mức, giữ tỉ lệ màu, tăng nhẹ bão hòa) + viền tối Sobel. */
    fun cartoon(px: IntArray, w: Int, h: Int): IntArray {
        val flat = kuwahara(px, w, h, radius(w, h, 520f, 2, 8))
        val lum = lumaF(flat)
        val edge = sobel(boxBlur(lum, w, h, if (max(w, h) >= 1400) 1 else 0), w, h)
        val levels = 7f
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = flat[i]
            val y = max(1f, lum[i])
            val t = y / 255f * levels
            val f = floor(t)
            val yq = (f + smooth01(0.35f, 0.65f, t - f)) / levels * 255f
            val k = (yq / y).coerceIn(0.5f, 1.6f)
            val ink = 1f - 0.9f * smooth01(60f, 150f, edge[i])
            val r = rd(p) * k; val g = gr(p) * k; val b = bl(p) * k
            val gray = 0.299f * r + 0.587f * g + 0.114f * b
            val sat = 1.15f
            out[i] = (px[i] and (0xFF shl 24)) or (clamp8((gray + (r - gray) * sat) * ink) shl 16) or (clamp8((gray + (g - gray) * sat) * ink) shl 8) or clamp8((gray + (b - gray) * sat) * ink)
        }
        return out
    }

    /** Màu nước: làm phẳng, hòa sắc tố, nhạt + sáng như giấy, viền sắc tố đậm ở mép, vân giấy. */
    fun watercolor(px: IntArray, w: Int, h: Int): IntArray {
        val flat = kuwahara(px, w, h, radius(w, h, 480f, 2, 9))
        val long = max(w, h).toFloat()
        val rad = radius(w, h, 700f, 1, 4)
        val ch = Array(3) { c -> FloatArray(px.size) { ((flat[it] shr (16 - 8 * c)) and 255).toFloat() } }
        val soft = Array(3) { boxBlur(ch[it], w, h, rad) }
        val lum = lumaF(flat)
        val edge = sobel(boxBlur(lum, w, h, rad), w, h)
        val out = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            var r = ch[0][i] * 0.6f + soft[0][i] * 0.4f
            var g = ch[1][i] * 0.6f + soft[1][i] * 0.4f
            var b = ch[2][i] * 0.6f + soft[2][i] * 0.4f
            // nhạt: đẩy về trắng giấy 14% và giảm bão hòa 12%
            val gray = 0.299f * r + 0.587f * g + 0.114f * b
            r = gray + (r - gray) * 0.88f; g = gray + (g - gray) * 0.88f; b = gray + (b - gray) * 0.88f
            r += (250f - r) * 0.14f; g += (248f - g) * 0.14f; b += (242f - b) * 0.14f
            // sắc tố dồn ở mép: tối + đậm màu hơn nơi gradient mạnh
            val pool = smooth01(25f, 130f, edge[i])
            r *= 1f - 0.30f * pool; g *= 1f - 0.26f * pool; b *= 1f - 0.20f * pool
            // vân giấy: hai tầng nhiễu theo toạ độ chuẩn hóa (không phụ thuộc kích thước ảnh)
            val u = x / long; val v = y / long
            val n = (valueNoise(u * 60f, v * 60f, 11) - 0.5f) * 0.7f + (valueNoise(u * 210f, v * 210f, 29) - 0.5f) * 0.3f
            val tex = 1f + n * 0.09f
            out[i] = (px[i] and (0xFF shl 24)) or (clamp8(r * tex) shl 16) or (clamp8(g * tex) shl 8) or clamp8(b * tex)
        }
        return out
    }

    /**
     * Áp phong cách [arg] lên ảnh ARGB [px] (w×h); [strength] 0..1 = tỉ lệ hòa kết quả với ảnh gốc.
     * arg không hợp lệ hoặc cường độ quá nhỏ → trả lại [px] nguyên vẹn.
     */
    fun apply(px: IntArray, w: Int, h: Int, strength: Float, arg: String?): IntArray {
        val s = strength.coerceIn(0f, 1f)
        val style = canonical(arg)
        if (style == null || s < 0.01f || w < 4 || h < 4 || px.size != w * h) return px
        val styled = when (style) {
            OIL -> oil(px, w, h)
            CARTOON -> cartoon(px, w, h)
            else -> watercolor(px, w, h)
        }
        if (s >= 0.995f) return styled
        return IntArray(px.size) { i ->
            val a = px[i]; val b = styled[i]
            (a and (0xFF shl 24)) or
                (clamp8(rd(a) + (rd(b) - rd(a)) * s) shl 16) or (clamp8(gr(a) + (gr(b) - gr(a)) * s) shl 8) or clamp8(bl(a) + (bl(b) - bl(a)) * s)
        }
    }
}
