package com.aiphoto.studio.doc

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Chế độ hòa trộn. 9 chế độ đầu (R5) giữ nguyên thứ tự; R14 thêm 12 chế độ còn thiếu so với Photoshop / đặc tả W3C
 * Compositing & Blending Level 1 (gồm 4 chế độ KHÔNG tách kênh: Hue, Saturation, Color, Luminosity - cần cho retouch).
 * Lưu theo TÊN (ProjectCodec/Recipes) nên thêm chế độ mới không làm hỏng phiên/công thức cũ.
 */
enum class BlendMode(val label: String, val separable: Boolean = true) {
    NORMAL("Thường"),
    MULTIPLY("Multiply"),
    SCREEN("Screen"),
    OVERLAY("Overlay"),
    SOFT_LIGHT("Soft Light"),
    COLOR_DODGE("Color Dodge"),
    COLOR_BURN("Color Burn"),
    DARKEN("Darken"),
    LIGHTEN("Lighten"),
    HARD_LIGHT("Hard Light"),
    VIVID_LIGHT("Vivid Light"),
    LINEAR_LIGHT("Linear Light"),
    PIN_LIGHT("Pin Light"),
    LINEAR_BURN("Linear Burn"),
    LINEAR_DODGE("Linear Dodge (Add)"),
    DIFFERENCE("Difference"),
    EXCLUSION("Exclusion"),
    HUE("Hue", false),
    SATURATION("Saturation", false),
    COLOR("Color", false),
    LUMINOSITY("Luminosity", false);

    fun next(): BlendMode = values()[(ordinal + 1) % values().size]
}

object Blend {

    private fun clamp01(v: Float): Float = if (v < 0f) 0f else if (v > 1f) 1f else v

    /** Color Dodge theo W3C: b = 0 -> 0 (kể cả khi t = 1), t = 1 -> 1. */
    private fun dodge(b: Float, t: Float): Float =
        if (b <= 0f) 0f else if (t >= 1f) 1f else min(1f, b / (1f - t))

    /** Color Burn theo W3C: b = 1 -> 1 (kể cả khi t = 0), t = 0 -> 0. */
    private fun burn(b: Float, t: Float): Float =
        if (b >= 1f) 1f else if (t <= 0f) 0f else 1f - min(1f, (1f - b) / t)

    /** Chế độ TÁCH KÊNH: b = nền, t = lớp trên (0..1) -> kết quả đã kẹp 0..1 (Photoshop kẹp TRƯỚC khi trộn theo độ mờ). */
    private fun mixCh(mode: BlendMode, b: Float, t: Float): Float = clamp01(when (mode) {
        BlendMode.NORMAL -> t
        BlendMode.MULTIPLY -> b * t
        BlendMode.SCREEN -> 1f - (1f - b) * (1f - t)
        BlendMode.OVERLAY -> if (b < 0.5f) 2f * b * t else 1f - 2f * (1f - b) * (1f - t)
        BlendMode.SOFT_LIGHT ->
            if (t <= 0.5f) b - (1f - 2f * t) * b * (1f - b)
            else {
                val d = if (b <= 0.25f) ((16f * b - 12f) * b + 4f) * b else sqrt(b)
                b + (2f * t - 1f) * (d - b)
            }
        BlendMode.COLOR_DODGE -> dodge(b, t)
        BlendMode.COLOR_BURN -> burn(b, t)
        BlendMode.DARKEN -> min(b, t)
        BlendMode.LIGHTEN -> max(b, t)
        BlendMode.HARD_LIGHT ->
            if (t <= 0.5f) b * 2f * t
            else { val s = 2f * t - 1f; b + s - b * s }                       // Screen(b, 2t-1)
        BlendMode.VIVID_LIGHT -> if (t < 0.5f) burn(b, 2f * t) else dodge(b, 2f * t - 1f)
        BlendMode.LINEAR_LIGHT -> b + 2f * t - 1f
        BlendMode.PIN_LIGHT -> if (t < 0.5f) min(b, 2f * t) else max(b, 2f * t - 1f)
        BlendMode.LINEAR_BURN -> b + t - 1f
        BlendMode.LINEAR_DODGE -> b + t
        BlendMode.DIFFERENCE -> abs(b - t)
        BlendMode.EXCLUSION -> b + t - 2f * b * t
        // 4 chế độ không tách kênh được xử lý ở nonSep(); nhánh này không bao giờ chạy cho chúng
        BlendMode.HUE, BlendMode.SATURATION, BlendMode.COLOR, BlendMode.LUMINOSITY -> t
    })

    // ---- chế độ KHÔNG tách kênh: công thức W3C (Lum / Sat / SetLum / SetSat / ClipColor), hệ số 0.3/0.59/0.11 ----

    private fun lum(r: Float, g: Float, b: Float): Float = 0.3f * r + 0.59f * g + 0.11f * b

    private fun sat(r: Float, g: Float, b: Float): Float = max(r, max(g, b)) - min(r, min(g, b))

    /** SetSat: kênh nhỏ nhất -> 0, lớn nhất -> s, kênh giữa tỉ lệ; ba kênh bằng nhau -> xám 0. Ghi vào out[0..2]. */
    private fun setSat(r: Float, g: Float, b: Float, s: Float, out: FloatArray) {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        if (mx > mn) {
            val k = s / (mx - mn)
            out[0] = (r - mn) * k; out[1] = (g - mn) * k; out[2] = (b - mn) * k
        } else {
            out[0] = 0f; out[1] = 0f; out[2] = 0f
        }
    }

    /** SetLum + ClipColor (n và x tính MỘT lần trước khi chỉnh, đúng đặc tả). Ghi vào out[0..2]. */
    private fun setLum(r: Float, g: Float, b: Float, l: Float, out: FloatArray) {
        val d = l - lum(r, g, b)
        var cr = r + d
        var cg = g + d
        var cb = b + d
        val ll = lum(cr, cg, cb)
        val n = min(cr, min(cg, cb))
        val x = max(cr, max(cg, cb))
        if (n < 0f) {
            val den = ll - n
            if (den > 1e-6f) {
                val k = ll / den
                cr = ll + (cr - ll) * k; cg = ll + (cg - ll) * k; cb = ll + (cb - ll) * k
            } else { cr = ll; cg = ll; cb = ll }
        }
        if (x > 1f) {
            val den = x - ll
            if (den > 1e-6f) {
                val k = (1f - ll) / den
                cr = ll + (cr - ll) * k; cg = ll + (cg - ll) * k; cb = ll + (cb - ll) * k
            } else { cr = ll; cg = ll; cb = ll }
        }
        out[0] = cr; out[1] = cg; out[2] = cb
    }

    private fun nonSep(mode: BlendMode, br: Float, bg: Float, bb: Float, tr: Float, tg: Float, tb: Float, out: FloatArray) {
        when (mode) {
            BlendMode.HUE -> {
                setSat(tr, tg, tb, sat(br, bg, bb), out)
                setLum(out[0], out[1], out[2], lum(br, bg, bb), out)
            }
            BlendMode.SATURATION -> {
                setSat(br, bg, bb, sat(tr, tg, tb), out)
                setLum(out[0], out[1], out[2], lum(br, bg, bb), out)
            }
            BlendMode.COLOR -> setLum(tr, tg, tb, lum(br, bg, bb), out)
            else -> setLum(br, bg, bb, lum(tr, tg, tb), out)          // LUMINOSITY
        }
        out[0] = clamp01(out[0]); out[1] = clamp01(out[1]); out[2] = clamp01(out[2])
    }

    private fun ch(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()

    /** Trộn [top] lên [base] theo chế độ hòa trộn, độ mờ lớp và mặt nạ (0..1) từng điểm ảnh. */
    fun blend(base: IntArray, top: IntArray, mode: BlendMode, opacity: Float, mask: FloatArray?): IntArray {
        val out = IntArray(base.size)
        val sep = mode.separable
        val tmp = FloatArray(3)
        for (i in base.indices) {
            val a = opacity * (if (mask != null) mask[i] else 1f)
            val b = base[i]
            if (a <= 0.001f) { out[i] = b; continue }
            val t = top[i]
            val br = ((b shr 16) and 255) / 255f
            val bg = ((b shr 8) and 255) / 255f
            val bb = (b and 255) / 255f
            val tr = ((t shr 16) and 255) / 255f
            val tg = ((t shr 8) and 255) / 255f
            val tb = (t and 255) / 255f
            val mr: Float
            val mg: Float
            val mb: Float
            if (sep) {
                mr = mixCh(mode, br, tr); mg = mixCh(mode, bg, tg); mb = mixCh(mode, bb, tb)
            } else {
                nonSep(mode, br, bg, bb, tr, tg, tb, tmp)
                mr = tmp[0]; mg = tmp[1]; mb = tmp[2]
            }
            val r = (br + (mr - br) * a) * 255f
            val g = (bg + (mg - bg) * a) * 255f
            val bl = (bb + (mb - bb) * a) * 255f
            out[i] = ((b ushr 24) shl 24) or (ch(r) shl 16) or (ch(g) shl 8) or ch(bl)
        }
        return out
    }
}
