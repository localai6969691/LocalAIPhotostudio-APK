@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aiphoto.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import com.aiphoto.studio.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.engine.ToneOps
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Nền caro để thấy rõ vùng trong suốt. */
fun Modifier.checkerboard(): Modifier = drawBehind {
    val tile = 24.dp.toPx()
    val cols = (size.width / tile).toInt() + 1
    val rows = (size.height / tile).toInt() + 1
    for (r in 0 until rows) {
        for (c in 0 until cols) {
            drawRect(
                color = if ((r + c) % 2 == 0) Color(0xFF3A3A3A) else Color(0xFF4A4A4A),
                topLeft = Offset(c * tile, r * tile),
                size = Size(tile, tile)
            )
        }
    }
}

private fun formatValue(v: Float, percent: Boolean): String =
    if (percent) "${(v * 100).roundToInt()}" else String.format(Locale.US, "%.2f", v)

fun fmt3(v: Float): String = String.format(Locale.US, "%.3f", v)

/** Thanh trượt cho di động: phản hồi rung khi thả, bấm vào số để nhập chính xác. */
@Composable
fun ParamSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinish: () -> Unit,
    percent: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    var editing by remember { mutableStateOf(false) }
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(92.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onFinish()
            },
            valueRange = range,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { editing = true }) { Text(formatValue(value, percent)) }
    }
    if (editing) {
        var text by remember { mutableStateOf(formatValue(value, percent)) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text(label) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val v = text.replace(',', '.').toFloatOrNull()
                    if (v != null) {
                        onChange(if (percent) v / 100f else v)
                        onFinish()
                    }
                    editing = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("Hủy") } }
        )
    }
}

object CurveCodec {
    val CHANNELS = listOf("m" to "RGB", "r" to "Đỏ", "g" to "Lục", "b" to "Lam")

    fun parse(arg: String?): Map<String, List<Pair<Float, Float>>> {
        val out = HashMap<String, List<Pair<Float, Float>>>()
        arg?.split('|')?.forEach { part ->
            val kv = part.split(':', limit = 2)
            if (kv.size == 2) out[kv[0].trim()] = ToneOps.parsePoints(kv[1])
        }
        return out
    }

    fun encode(map: Map<String, List<Pair<Float, Float>>>): String =
        map.entries.filter { it.value.size >= 2 }.joinToString("|") { e ->
            e.key + ":" + e.value.joinToString(";") { fmt3(it.first) + "," + fmt3(it.second) }
        }
}

/** Trình chỉnh Curves: chạm/kéo để thêm hoặc di chuyển điểm, nhấn giữ để xóa điểm. Có kênh RGB/R/G/B. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurveEditor(arg: String?, onChange: (String) -> Unit, onFinish: () -> Unit) {
    var channel by remember { mutableStateOf("m") }
    var sel by remember { mutableStateOf(-1) }
    val curves = CurveCodec.parse(arg)
    val identity = listOf(Pair(0f, 0f), Pair(1f, 1f))
    val pts = curves[channel]?.takeIf { it.size >= 2 } ?: identity

    val ptsState by rememberUpdatedState(pts)
    val curvesState by rememberUpdatedState(curves)
    val channelState by rememberUpdatedState(channel)
    val onChangeState by rememberUpdatedState(onChange)
    val onFinishState by rememberUpdatedState(onFinish)

    fun commit(newPts: List<Pair<Float, Float>>) {
        val m = HashMap<String, List<Pair<Float, Float>>>(curvesState)
        m[channelState] = newPts
        onChangeState(CurveCodec.encode(m))
    }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CurveCodec.CHANNELS.forEach { ch ->
                FilterChip(
                    selected = channel == ch.first,
                    onClick = { channel = ch.first; sel = -1 },
                    label = { Text(ch.second) }
                )
            }
            TextButton(onClick = { commit(identity); onFinish() }) { Text("Đặt lại kênh") }
        }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { o ->
                        val p = ptsState
                        val nx = (o.x / size.width).coerceIn(0f, 1f)
                        val ny = (1f - o.y / size.height).coerceIn(0f, 1f)
                        var best = -1
                        var bd = 0.08f
                        p.forEachIndexed { i, q ->
                            val d = hypot(q.first - nx, q.second - ny)
                            if (d < bd && i != 0 && i != p.lastIndex) { bd = d; best = i }
                        }
                        if (best >= 0) {
                            commit(p.filterIndexed { i, _ -> i != best })
                            onFinishState()
                        }
                    })
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o ->
                            val p = ptsState
                            val nx = (o.x / size.width).coerceIn(0f, 1f)
                            val ny = (1f - o.y / size.height).coerceIn(0f, 1f)
                            var best = -1
                            var bd = 0.08f
                            p.forEachIndexed { i, q ->
                                val d = hypot(q.first - nx, q.second - ny)
                                if (d < bd) { bd = d; best = i }
                            }
                            if (best < 0) {
                                val np = (p + Pair(nx, ny)).sortedBy { it.first }
                                sel = np.indexOfFirst { it.first == nx && it.second == ny }
                                commit(np)
                            } else {
                                sel = best
                            }
                        },
                        onDrag = { change, _ ->
                            val p = ptsState
                            val i = sel
                            if (i in p.indices) {
                                val nx0 = (change.position.x / size.width).coerceIn(0f, 1f)
                                val ny = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                                val nx = when (i) {
                                    0 -> 0f
                                    p.lastIndex -> 1f
                                    else -> nx0.coerceIn(p[i - 1].first + 0.02f, p[i + 1].first - 0.02f)
                                }
                                val np = p.toMutableList()
                                np[i] = Pair(nx, ny)
                                commit(np)
                            }
                        },
                        onDragEnd = {
                            sel = -1
                            onFinishState()
                        },
                        onDragCancel = { sel = -1 }
                    )
                }
        ) {
            val w = size.width
            val h = size.height
            drawRect(Color(0xFF1E1E1E))
            for (i in 1..3) {
                drawLine(Color(0xFF3A3A3A), Offset(w * i / 4f, 0f), Offset(w * i / 4f, h))
                drawLine(Color(0xFF3A3A3A), Offset(0f, h * i / 4f), Offset(w, h * i / 4f))
            }
            drawLine(Color(0xFF666666), Offset(0f, h), Offset(w, 0f))
            val lut = ToneOps.curveLut(pts)
            val path = Path()
            for (i in 0..255) {
                val x = i / 255f * w
                val y = h - lut[i] / 255f * h
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val lineColor = when (channel) {
                "r" -> Color(0xFFFF6B6B)
                "g" -> Color(0xFF6BFF8A)
                "b" -> Color(0xFF6BA8FF)
                else -> Color.White
            }
            drawPath(path, lineColor, style = Stroke(width = 3f))
            pts.forEach { drawCircle(Color(0xFFFFC107), 8.dp.toPx(), Offset(it.first * w, h - it.second * h)) }
        }
    }
}

/** Cân bằng màu: chọn vùng (tối / giữa / sáng) rồi chỉnh Đỏ / Lục / Lam. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BalanceEditor(arg: String?, onChange: (String) -> Unit, onFinish: () -> Unit) {
    val parsed = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }.orEmpty()
    val vals = if (parsed.size >= 9) parsed else List(9) { 0f }
    var range by remember { mutableStateOf(0) }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Vùng tối", "Vùng giữa", "Vùng sáng").forEachIndexed { i, n ->
                FilterChip(selected = range == i, onClick = { range = i }, label = { Text(n) })
            }
        }
        listOf("Đỏ", "Lục", "Lam").forEachIndexed { k, label ->
            ParamSlider(
                label = label,
                value = vals[range * 3 + k],
                range = -1f..1f,
                onChange = { v ->
                    val m = vals.toMutableList()
                    m[range * 3 + k] = v
                    onChange(m.joinToString(",") { fmt3(it) })
                },
                onFinish = onFinish
            )
        }
    }
}

/**
 * Màu chọn lọc kiểu Photoshop (CMYK theo 9 dải màu): chọn dải rồi chỉnh Cyan / Magenta / Vàng / Đen.
 * Tương đối = đổi theo tỉ lệ lượng mực đang có; Tuyệt đối = cộng thẳng điểm phần trăm (xem engine/SelectiveColor.kt).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectiveColorEditor(arg: String?, onChange: (String) -> Unit, onFinish: () -> Unit) {
    val parsed = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }.orEmpty()
    val vals = if (parsed.size >= 36) parsed.take(36) else List(36) { 0f }
    val absolute = parsed.size >= 37 && parsed[36] > 0.5f
    var range by remember { mutableStateOf(0) }
    val names = listOf("Đỏ", "Vàng", "Lục", "Lam nhạt", "Lam", "Hồng tím", "Trắng", "Trung tính", "Đen")
    fun emit(v: List<Float>, abs: Boolean) = onChange((v + listOf(if (abs) 1f else 0f)).joinToString(",") { fmt3(it) })
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            names.forEachIndexed { i, n ->
                FilterChip(selected = range == i, onClick = { range = i }, label = { Text(n) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = !absolute, onClick = { emit(vals, false); onFinish() }, label = { Text("Tương đối") })
            FilterChip(selected = absolute, onClick = { emit(vals, true); onFinish() }, label = { Text("Tuyệt đối") })
        }
        listOf("Cyan", "Magenta", "Vàng", "Đen").forEachIndexed { k, label ->
            ParamSlider(
                label = label,
                value = vals[range * 4 + k],
                range = -1f..1f,
                onChange = { v ->
                    val m = vals.toMutableList()
                    m[range * 4 + k] = v
                    emit(m, absolute)
                },
                onFinish = onFinish
            )
        }
    }
}

/** HSL theo 8 dải màu: chọn dải rồi chỉnh Sắc độ / Bão hòa / Độ sáng. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HslEditor(arg: String?, onChange: (String) -> Unit, onFinish: () -> Unit) {
    val parsed = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }.orEmpty()
    val vals = if (parsed.size >= 24) parsed else List(24) { 0f }
    var band by remember { mutableStateOf(0) }
    val names = listOf("Đỏ", "Cam", "Vàng", "Lục", "Lam nhạt", "Lam", "Tím", "Hồng")
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            names.forEachIndexed { i, n ->
                FilterChip(selected = band == i, onClick = { band = i }, label = { Text(n) })
            }
        }
        listOf("Sắc độ", "Bão hòa", "Độ sáng").forEachIndexed { k, label ->
            ParamSlider(
                label = label,
                value = vals[band * 3 + k],
                range = -1f..1f,
                onChange = { v ->
                    val m = vals.toMutableList()
                    m[band * 3 + k] = v
                    onChange(m.joinToString(",") { fmt3(it) })
                },
                onFinish = onFinish
            )
        }
    }
}
