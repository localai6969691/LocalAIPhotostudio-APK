package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Hiệu ứng điểm ảnh thuần Kotlin (kiểm thử được): xoay SẮC ĐỘ (Hue) và Lens Flare.
 * Bản port Python kiểm số học: tools/verify_ports/color_fx.py.
 */
object ColorFx {

    /** Xoay sắc độ [deg] độ trong không gian HSV, giữ nguyên bão hòa và độ sáng (V). Điểm ảnh xám không đổi. */
    fun hueShift(px: IntArray, deg: Float): IntArray {
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val r = ((p shr 16) and 255) / 255f
            val g = ((p shr 8) and 255) / 255f
            val b = (p and 255) / 255f
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val d = mx - mn
            if (d < 1e-6f) {
                out[i] = p
                continue
            }
            val t = when {
                mx == r -> (g - b) / d
                mx == g -> (b - r) / d + 2f
                else -> (r - g) / d + 4f
            }
            var h = 60f * (if (t < 0f) t + 6f else t)
            h = ((h + deg) % 360f + 360f) % 360f
            val c = d // = v * s
            val hp = h / 60f
            val x = c * (1f - abs(hp % 2f - 1f))
            val m0 = mx - c
            val rr: Float
            val gg: Float
            val bb: Float
            when (hp.toInt()) {
                0 -> { rr = c; gg = x; bb = 0f }
                1 -> { rr = x; gg = c; bb = 0f }
                2 -> { rr = 0f; gg = c; bb = x }
                3 -> { rr = 0f; gg = x; bb = c }
                4 -> { rr = x; gg = 0f; bb = c }
                else -> { rr = c; gg = 0f; bb = x }
            }
            val nr = ((rr + m0) * 255f + 0.5f).toInt().coerceIn(0, 255)
            val ng = ((gg + m0) * 255f + 0.5f).toInt().coerceIn(0, 255)
            val nb = ((bb + m0) * 255f + 0.5f).toInt().coerceIn(0, 255)
            out[i] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    private class Blob(
        val cx: Float, val cy: Float, val sigma: Float, val amp: Float,
        val tr: Float, val tg: Float, val tb: Float, val disc: Boolean
    )

    /**
     * Lens flare: ánh chói sáng tại nguồn sáng (cx, cy chuẩn hóa 0..1) + quầng + vệt ngang + 3 "bóng ma" nằm trên đường nối nguồn sáng với
     * tâm ảnh; cộng ánh sáng theo kiểu Screen (không bao giờ làm tối ảnh).
     */
    fun lensFlare(px: IntArray, w: Int, h: Int, intensity: Float, cx: Float, cy: Float): IntArray {
        val k = intensity.coerceIn(0f, 1f)
        if (k <= 0f) return px
        val s = max(w, h).toFloat()
        val lx = cx.coerceIn(0f, 1f) * w
        val ly = cy.coerceIn(0f, 1f) * h
        val ax = w / 2f - lx
        val ay = h / 2f - ly
        val blobs = listOf(
            Blob(lx, ly, 0.05f * s, 1.00f * k, 1.00f, 0.93f, 0.78f, false),
            Blob(lx, ly, 0.18f * s, 0.25f * k, 1.00f, 0.85f, 0.60f, false),
            Blob(lx + ax * 0.5f, ly + ay * 0.5f, 0.030f * s, 0.35f * k, 0.60f, 0.85f, 1.00f, true),
            Blob(lx + ax * 1.0f, ly + ay * 1.0f, 0.045f * s, 0.25f * k, 1.00f, 0.55f, 0.45f, true),
            Blob(lx + ax * 1.6f, ly + ay * 1.6f, 0.070f * s, 0.20f * k, 0.65f, 1.00f, 0.70f, true)
        )
        val streakSx = 0.35f * s
        val streakSy = 0.004f * s
        val streakAmp = 0.5f * k
        val out = IntArray(px.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                var fr = 0f
                var fg = 0f
                var fb = 0f
                for (bl in blobs) {
                    val dx = x - bl.cx
                    val dy = y - bl.cy
                    val d2 = dx * dx + dy * dy
                    val a: Float
                    if (bl.disc) {
                        val rad = bl.sigma
                        if (d2 > rad * rad) continue
                        val t = sqrt(d2) / rad
                        a = bl.amp * (if (t < 0.6f) 1f else (1f - t) / 0.4f)
                    } else {
                        val lim = 4f * bl.sigma
                        if (d2 > lim * lim) continue
                        a = bl.amp * exp(-d2 / (2f * bl.sigma * bl.sigma))
                    }
                    fr += a * bl.tr
                    fg += a * bl.tg
                    fb += a * bl.tb
                }
                val sx = x - lx
                val sy = y - ly
                if (abs(sy) < 5f * streakSy && abs(sx) < 3f * streakSx) {
                    val a = streakAmp * exp(-(sx * sx) / (2f * streakSx * streakSx) - (sy * sy) / (2f * streakSy * streakSy))
                    fr += a * 0.70f
                    fg += a * 0.80f
                    fb += a * 1.00f
                }
                val p = px[i]
                if (fr <= 0f && fg <= 0f && fb <= 0f) {
                    out[i] = p
                    continue
                }
                val r = ((p shr 16) and 255) / 255f
                val g = ((p shr 8) and 255) / 255f
                val b = (p and 255) / 255f
                val nr = ((1f - (1f - r) * (1f - fr.coerceIn(0f, 1f))) * 255f + 0.5f).toInt().coerceIn(0, 255)
                val ng = ((1f - (1f - g) * (1f - fg.coerceIn(0f, 1f))) * 255f + 0.5f).toInt().coerceIn(0, 255)
                val nb = ((1f - (1f - b) * (1f - fb.coerceIn(0f, 1f))) * 255f + 0.5f).toInt().coerceIn(0, 255)
                out[i] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        return out
    }
}
