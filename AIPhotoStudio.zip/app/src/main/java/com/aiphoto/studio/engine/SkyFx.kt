package com.aiphoto.studio.engine

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * R11 — "Select Sky" + "Thay bầu trời" (PDF: Thay thế nền & bầu trời — Luminar/Picsart) KHÔNG cần model.
 *
 * Phát hiện: ảnh được thu nhỏ (≤ [SIDE] px). Điểm ảnh ứng viên = MỊN (độ dốc độ chói nhỏ), đủ sáng, không thiên lục (loại cây cối).
 * Vùng trời = các ứng viên liên thông với mép TRÊN ảnh, lan theo từng bước có màu liên tục (bầu trời chuyển sắc không bị đứt,
 * tường trắng/vật xanh nằm dưới mà không nối liền thì không bị lấy). Lỗ bên trong (mây có kết cấu, mặt trời) được điền.
 * Mặt nạ được phóng lên kích thước gốc, co nhẹ viền (tránh viền xanh) rồi làm mềm.
 *
 * Thay trời: dựng bầu trời thủ tục (gradient thiên đỉnh→chân trời + mây fBm + sao cho "night") rồi trộn theo mặt nạ.
 * Bản port Python kiểm chứng: tools/verify_ports/sky_fx.py.
 */
object SkyFx {

    const val SIDE = 320
    /** Tái chiếu sáng chỉ dịch tiền cảnh một PHẦN (35%) chênh lệch sắc giữa trời cũ và trời mới — đủ để ăn khớp, không biến đất thành cam rực. */
    const val CHROMA_GAIN = 0.35f
    val PRESETS = listOf("blue", "sunset", "dusk", "overcast", "night")

    fun label(preset: String): String = when (preset) {
        "blue" -> "Trời xanh"
        "sunset" -> "Hoàng hôn"
        "dusk" -> "Chạng vạng"
        "overcast" -> "Âm u"
        "night" -> "Đêm sao"
        else -> preset
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private class Small(val w: Int, val h: Int, val r: FloatArray, val g: FloatArray, val b: FloatArray)

    private fun shrink(px: IntArray, w: Int, h: Int): Small {
        val f = max(1, (max(w, h) + SIDE - 1) / SIDE)
        val sw = max(1, w / f)
        val sh = max(1, h / f)
        val r = FloatArray(sw * sh); val g = FloatArray(sw * sh); val b = FloatArray(sw * sh)
        for (y in 0 until sh) for (x in 0 until sw) {
            var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
            for (dy in 0 until f) {
                val yy = y * f + dy
                if (yy >= h) break
                for (dx in 0 until f) {
                    val xx = x * f + dx
                    if (xx >= w) break
                    val p = px[yy * w + xx]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; n++
                }
            }
            val i = y * sw + x
            r[i] = sr / (255f * n); g[i] = sg / (255f * n); b[i] = sb / (255f * n)
        }
        return Small(sw, sh, r, g, b)
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, rad: Int): FloatArray {
        if (rad < 1) return src.copyOf()
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -rad..rad) s += src[y * w + min(max(x + k, 0), w - 1)]
            tmp[y * w + x] = s / (2 * rad + 1)
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -rad..rad) s += tmp[min(max(y + k, 0), h - 1) * w + x]
            out[y * w + x] = s / (2 * rad + 1)
        }
        return out
    }

    /** Vùng trời ở độ phân giải nhỏ (true = trời) hoặc null nếu không thấy trời nối với mép trên. */
    internal fun detectSmall(sw: Int, sh: Int, r: FloatArray, g: FloatArray, b: FloatArray, sensitivity: Float): BooleanArray? {
        val n = sw * sh
        val sens = sensitivity.coerceIn(0f, 1f)
        val lum = FloatArray(n) { 0.299f * r[it] + 0.587f * g[it] + 0.114f * b[it] }
        val ls = boxBlur(lum, sw, sh, 1)
        val grad = FloatArray(n)
        for (y in 0 until sh) for (x in 0 until sw) {
            val xl = max(0, x - 1); val xr = min(sw - 1, x + 1)
            val yu = max(0, y - 1); val yd = min(sh - 1, y + 1)
            val gx = (ls[y * sw + xr] - ls[y * sw + xl]) / max(1, xr - xl)
            val gy = (ls[yd * sw + x] - ls[yu * sw + x]) / max(1, yd - yu)
            grad[y * sw + x] = sqrt(gx * gx + gy * gy)
        }
        val gs = boxBlur(grad, sw, sh, 1)
        val tTex = 0.02f + 0.05f * sens
        val step = 0.06f + 0.10f * sens
        val cand = BooleanArray(n) { i ->
            val mx = max(r[i], max(g[i], b[i]))
            val veg = g[i] > r[i] * 1.08f + 0.02f && g[i] > b[i] * 1.08f + 0.02f
            gs[i] < tTex && mx > 0.30f && !veg
        }
        // xói mòn 1 điểm: điểm ứng viên rời rạc (nhiễu) biến mất, vùng trời liền khối giữ nguyên
        val core = BooleanArray(n) { i ->
            val x = i % sw
            val y = i / sw
            cand[i] && (x == 0 || cand[i - 1]) && (x == sw - 1 || cand[i + 1]) && (y == 0 || cand[i - sw]) && (y == sh - 1 || cand[i + sw])
        }
        val region = BooleanArray(n)
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        val seedRows = max(1, (sh * 0.04f).toInt())
        var seeds = 0
        for (y in 0 until seedRows) for (x in 0 until sw) {
            val i = y * sw + x
            if (core[i]) { region[i] = true; queue[tail++] = i; seeds++ }
        }
        if (seeds < 0.05f * sw) return null
        while (head < tail) {
            val i = queue[head++]
            val x = i % sw
            val y = i / sw
            for (d in 0 until 4) {
                val nx = x + (if (d == 0) -1 else if (d == 1) 1 else 0)
                val ny = y + (if (d == 2) -1 else if (d == 3) 1 else 0)
                if (nx < 0 || ny < 0 || nx >= sw || ny >= sh) continue
                val j = ny * sw + nx
                if (region[j] || !core[j]) continue
                val dr = r[i] - r[j]; val dg = g[i] - g[j]; val db = b[i] - b[j]
                if (sqrt(dr * dr + dg * dg + db * db) >= step) continue
                region[j] = true
                queue[tail++] = j
            }
        }
        // chỉ giữ các thành phần liên thông đủ lớn (loại các cụm hạt giống rời rạc nằm trong vùng có kết cấu)
        val label = IntArray(n)
        val sizes = ArrayList<Int>()
        for (i in 0 until n) {
            if (!region[i] || label[i] != 0) continue
            val id = sizes.size + 1
            var qh = 0
            var qt = 0
            queue[qt++] = i
            label[i] = id
            while (qh < qt) {
                val c = queue[qh++]
                val cx = c % sw
                val cy = c / sw
                for (d in 0 until 4) {
                    val nx = cx + (if (d == 0) -1 else if (d == 1) 1 else 0)
                    val ny = cy + (if (d == 2) -1 else if (d == 3) 1 else 0)
                    if (nx < 0 || ny < 0 || nx >= sw || ny >= sh) continue
                    val j = ny * sw + nx
                    if (!region[j] || label[j] != 0) continue
                    label[j] = id
                    queue[qt++] = j
                }
            }
            sizes.add(qt)
        }
        val largest = sizes.maxOrNull() ?: 0
        val minSize = max((0.01f * n).toInt(), (0.15f * largest).toInt())
        for (i in 0 until n) if (region[i] && sizes[label[i] - 1] < minSize) region[i] = false
        // nở lại 1 điểm trong tập ứng viên gốc để trả lại phần biên đã bị xói mòn
        val grown = region.copyOf()
        for (i in 0 until n) {
            if (region[i] || !cand[i]) continue
            val x = i % sw
            val y = i / sw
            if ((x > 0 && region[i - 1]) || (x < sw - 1 && region[i + 1]) || (y > 0 && region[i - sw]) || (y < sh - 1 && region[i + sw])) grown[i] = true
        }
        for (i in 0 until n) region[i] = grown[i]
        // điền lỗ: phần bù không nối được tới mép trái/phải/dưới = lỗ nằm trong trời
        val outside = BooleanArray(n)
        head = 0; tail = 0
        fun seed(x: Int, y: Int) {
            val i = y * sw + x
            if (!region[i] && !outside[i]) { outside[i] = true; queue[tail++] = i }
        }
        for (y in 0 until sh) { seed(0, y); seed(sw - 1, y) }
        for (x in 0 until sw) seed(x, sh - 1)
        while (head < tail) {
            val i = queue[head++]
            val x = i % sw
            val y = i / sw
            for (d in 0 until 4) {
                val nx = x + (if (d == 0) -1 else if (d == 1) 1 else 0)
                val ny = y + (if (d == 2) -1 else if (d == 3) 1 else 0)
                if (nx < 0 || ny < 0 || nx >= sw || ny >= sh) continue
                val j = ny * sw + nx
                if (region[j] || outside[j]) continue
                outside[j] = true
                queue[tail++] = j
            }
        }
        var count = 0
        for (i in 0 until n) {
            if (!outside[i]) { region[i] = true }
            if (region[i]) count++
        }
        if (count < 0.03f * n) return null
        return region
    }

    /** Mặt nạ trời 0..1 cỡ w×h (toàn 0 nếu không có trời). */
    fun mask(px: IntArray, w: Int, h: Int, sensitivity: Float = 0.5f): FloatArray {
        val out = FloatArray(max(0, w * h))
        if (px.size != w * h || w < 8 || h < 8) return out
        val s = shrink(px, w, h)
        val region = detectSmall(s.w, s.h, s.r, s.g, s.b, sensitivity) ?: return out
        val m = FloatArray(w * h)
        val rv = FloatArray(s.w * s.h) { if (region[it]) 1f else 0f }
        for (y in 0 until h) {
            val fy = ((y + 0.5f) * s.h / h - 0.5f).coerceIn(0f, (s.h - 1).toFloat())
            val y0 = fy.toInt(); val y1 = min(s.h - 1, y0 + 1); val wy = fy - y0
            for (x in 0 until w) {
                val fx = ((x + 0.5f) * s.w / w - 0.5f).coerceIn(0f, (s.w - 1).toFloat())
                val x0 = fx.toInt(); val x1 = min(s.w - 1, x0 + 1); val wx = fx - x0
                val t = (rv[y0 * s.w + x0] * (1f - wx) + rv[y0 * s.w + x1] * wx) * (1f - wy) +
                    (rv[y1 * s.w + x0] * (1f - wx) + rv[y1 * s.w + x1] * wx) * wy
                m[y * w + x] = smooth(0.35f, 0.85f, t) // co nhẹ viền để không còn viền xanh quanh vật thể
            }
        }
        val rad = max(1, (max(w, h) * 0.003f).roundToInt())
        val gray = IntArray(w * h) { i ->
            val gv = (m[i] * 255f + 0.5f).toInt().coerceIn(0, 255)
            (255 shl 24) or (gv shl 16) or (gv shl 8) or gv
        }
        val blurred = Blur.gaussian(gray, w, h, rad)
        for (i in out.indices) out[i] = (blurred[i] and 255) / 255f
        return out
    }

    // ------------------------------------------------------------------ bầu trời thủ tục
    private class Preset(val zenith: IntArray, val horizon: IntArray, val cover: Float, val cloud: IntArray, val stars: Boolean)

    private fun preset(name: String): Preset = when (name) {
        "sunset" -> Preset(intArrayOf(58, 58, 128), intArrayOf(255, 153, 72), 0.45f, intArrayOf(255, 196, 176), false)
        "dusk" -> Preset(intArrayOf(22, 26, 70), intArrayOf(205, 112, 122), 0.30f, intArrayOf(190, 130, 150), false)
        "overcast" -> Preset(intArrayOf(148, 156, 168), intArrayOf(208, 213, 219), 0.65f, intArrayOf(232, 235, 238), false)
        "night" -> Preset(intArrayOf(3, 7, 24), intArrayOf(30, 44, 88), 0f, intArrayOf(0, 0, 0), true)
        else -> Preset(intArrayOf(36, 107, 206), intArrayOf(165, 208, 246), 0.40f, intArrayOf(255, 255, 255), false)
    }

    private fun hash(ix: Int, iy: Int, seed: Int): Float {
        var h = ix * 374761393 + iy * 668265263 + seed * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777215f
    }

    private fun valueNoise(x: Float, y: Float, seed: Int): Float {
        val x0 = floor(x).toInt(); val y0 = floor(y).toInt()
        val fx = x - x0; val fy = y - y0
        val sx = fx * fx * (3f - 2f * fx); val sy = fy * fy * (3f - 2f * fy)
        val a = hash(x0, y0, seed); val b = hash(x0 + 1, y0, seed)
        val c = hash(x0, y0 + 1, seed); val d = hash(x0 + 1, y0 + 1, seed)
        return (a + (b - a) * sx) * (1f - sy) + (c + (d - c) * sx) * sy
    }

    private fun fbm(x: Float, y: Float, seed: Int): Float {
        var amp = 0.5f; var f = 1f; var sum = 0f; var norm = 0f
        for (o in 0 until 4) {
            sum += amp * valueNoise(x * f, y * f, seed + o)
            norm += amp
            amp *= 0.5f; f *= 2f
        }
        return sum / norm
    }

    /** Dựng ảnh trời cỡ w×h; [bottom] = hàng thấp nhất của vùng trời (chân trời). */
    fun render(w: Int, h: Int, presetName: String, bottom: Int): IntArray {
        val p = preset(presetName)
        val out = IntArray(w * h)
        val bm = max(1, bottom).toFloat()
        for (y in 0 until h) {
            val tt = (y / bm).coerceIn(0f, 1f).pow(1.15f)
            val v = y.toFloat() / h
            for (x in 0 until w) {
                val u = x.toFloat() / w
                var r = p.zenith[0] + (p.horizon[0] - p.zenith[0]) * tt
                var g = p.zenith[1] + (p.horizon[1] - p.zenith[1]) * tt
                var b = p.zenith[2] + (p.horizon[2] - p.zenith[2]) * tt
                if (p.cover > 0f) {
                    val n = fbm(u * 4f, v * 2.4f, 7)
                    val cloud = smooth(1f - p.cover - 0.10f, 1f - p.cover + 0.10f, n) * 0.85f * (0.6f + 0.4f * (1f - tt))
                    r += (p.cloud[0] - r) * cloud
                    g += (p.cloud[1] - g) * cloud
                    b += (p.cloud[2] - b) * cloud
                }
                if (p.stars) {
                    val hv = hash((u * 600f).toInt(), (v * 600f).toInt(), 99)
                    if (hv > 0.9965f) {
                        val s = (hv - 0.9965f) / 0.0035f * 255f * (1f - tt)
                        r += s; g += s; b += s
                    }
                }
                out[y * w + x] = (255 shl 24) or
                    (r.coerceIn(0f, 255f).roundToInt() shl 16) or
                    (g.coerceIn(0f, 255f).roundToInt() shl 8) or
                    b.coerceIn(0f, 255f).roundToInt()
            }
        }
        return out
    }

    /** Thay bầu trời bằng bầu trời [preset] với cường độ 0..1 (1 = thay hoàn toàn). Không thấy trời → trả nguyên ảnh. */
    fun replace(px: IntArray, w: Int, h: Int, preset: String, intensity: Float, relight: Float = 0f): IntArray =
        replaceUsing(px, w, h, intensity, relight) { bottom -> render(w, h, preset, bottom) }

    /**
     * Thay bầu trời bằng ẢNH của người dùng ([sky] ARGB cỡ sw×sh). Ảnh được phủ kín vùng trời (cover): phóng tới khi đủ cả hai chiều,
     * căn MÉP TRÊN (phần cao của ảnh trời là trời thuần), cắt giữa theo chiều ngang. Không có trời → trả nguyên ảnh.
     */
    fun replaceWithImage(px: IntArray, w: Int, h: Int, sky: IntArray, sw: Int, sh: Int, intensity: Float, relight: Float = 0f): IntArray {
        if (sw < 2 || sh < 2 || sky.size != sw * sh) return px
        return replaceUsing(px, w, h, intensity, relight) { bottom -> fitCover(sky, sw, sh, w, h, bottom) }
    }

    private fun bilin(a: Int, b: Int, c: Int, d: Int, shift: Int, wx: Float, wy: Float): Int {
        val top = ((a shr shift) and 255) * (1f - wx) + ((b shr shift) and 255) * wx
        val bot = ((c shr shift) and 255) * (1f - wx) + ((d shr shift) and 255) * wx
        return (top * (1f - wy) + bot * wy + 0.5f).toInt().coerceIn(0, 255)
    }

    /** Ảnh nền cỡ w×h: ảnh trời phóng kiểu cover cho vùng [0,w)×[0,bottom], nội suy song tuyến. */
    fun fitCover(sky: IntArray, sw: Int, sh: Int, w: Int, h: Int, bottom: Int): IntArray {
        val regionH = max(1, bottom + 1)
        val scale = max(w.toFloat() / sw, regionH.toFloat() / sh)
        val ox = (w - sw * scale) / 2f
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val v = ((y + 0.5f) / scale - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = v.toInt(); val y1 = min(sh - 1, y0 + 1); val wy = v - y0
            for (x in 0 until w) {
                val u = ((x + 0.5f - ox) / scale - 0.5f).coerceIn(0f, (sw - 1).toFloat())
                val x0 = u.toInt(); val x1 = min(sw - 1, x0 + 1); val wx = u - x0
                val a = sky[y0 * sw + x0]; val b = sky[y0 * sw + x1]; val c = sky[y1 * sw + x0]; val d = sky[y1 * sw + x1]
                out[y * w + x] = (255 shl 24) or (bilin(a, b, c, d, 16, wx, wy) shl 16) or
                    (bilin(a, b, c, d, 8, wx, wy) shl 8) or bilin(a, b, c, d, 0, wx, wy)
            }
        }
        return out
    }

    /**
     * Tái chiếu sáng tiền cảnh ([relight] 0..1): so trung bình màu trời cũ và trời mới (có trọng số theo mặt nạ):
     *  - dịch màu của tiền cảnh theo SẮC của trời mới (35% chênh lệch, đã bỏ thành phần độ chói → hoàng hôn làm đất ấm lên, trời xanh thì gần như không đổi);
     *  - nhân độ sáng tiền cảnh với hệ số 1 + 0,5·(độ chói mới / cũ − 1) kẹp 0,5..1,3 (trời đêm làm đất tối đi).
     * Chỉ tác dụng lên phần NGOÀI mặt nạ trời (trọng số 1 − mặt nạ), nên trời mới và đường biên không bị đụng.
     */
    private inline fun replaceUsing(px: IntArray, w: Int, h: Int, intensity: Float, relight: Float, build: (Int) -> IntArray): IntArray {
        val k = intensity.coerceIn(0f, 1f)
        if (k <= 0.005f || px.size != w * h) return px
        val m = mask(px, w, h)
        var bottom = -1
        var y = h - 1
        while (y >= 0 && bottom < 0) {
            for (x in 0 until w) if (m[y * w + x] > 0.5f) { bottom = y; break }
            y--
        }
        if (bottom < 0) return px
        val sky = build(bottom)
        val rl = relight.coerceIn(0f, 1f)
        var dR = 0f; var dG = 0f; var dB = 0f; var lumFactor = 1f
        if (rl > 0.005f) {
            var wsum = 0.0
            var oR = 0.0; var oG = 0.0; var oB = 0.0; var nR = 0.0; var nG = 0.0; var nB = 0.0
            for (i in px.indices) {
                val a = m[i]
                if (a <= 0.5f) continue
                wsum += a
                oR += a * ((px[i] shr 16) and 255); oG += a * ((px[i] shr 8) and 255); oB += a * (px[i] and 255)
                nR += a * ((sky[i] shr 16) and 255); nG += a * ((sky[i] shr 8) and 255); nB += a * (sky[i] and 255)
            }
            if (wsum > 1.0) {
                oR /= wsum; oG /= wsum; oB /= wsum; nR /= wsum; nG /= wsum; nB /= wsum
                val dr = nR - oR; val dg = nG - oG; val db = nB - oB
                val l = 0.299 * dr + 0.587 * dg + 0.114 * db
                dR = ((dr - l) * CHROMA_GAIN).toFloat(); dG = ((dg - l) * CHROMA_GAIN).toFloat(); dB = ((db - l) * CHROMA_GAIN).toFloat()
                val lo = 0.299 * oR + 0.587 * oG + 0.114 * oB
                val ln = 0.299 * nR + 0.587 * nG + 0.114 * nB
                lumFactor = (1.0 + 0.5 * (ln / max(lo, 1.0) - 1.0)).coerceIn(0.5, 1.3).toFloat()
            }
        }
        val out = IntArray(px.size)
        for (i in px.indices) {
            val a = m[i] * k
            val fw = rl * k * (1f - m[i])
            if (a <= 0.003f && fw <= 0.003f) { out[i] = px[i]; continue }
            val p = px[i]
            val s = sky[i]
            var r = ((p shr 16) and 255).toFloat()
            var g = ((p shr 8) and 255).toFloat()
            var b = (p and 255).toFloat()
            if (a > 0.003f) {
                r += (((s shr 16) and 255) - r) * a
                g += (((s shr 8) and 255) - g) * a
                b += ((s and 255) - b) * a
            }
            if (fw > 0.003f) {
                r += (((r + dR) * lumFactor).coerceIn(0f, 255f) - r) * fw
                g += (((g + dG) * lumFactor).coerceIn(0f, 255f) - g) * fw
                b += (((b + dB) * lumFactor).coerceIn(0f, 255f) - b) * fw
            }
            out[i] = (p and (255 shl 24)) or
                (r.coerceIn(0f, 255f).roundToInt() shl 16) or
                (g.coerceIn(0f, 255f).roundToInt() shl 8) or
                b.coerceIn(0f, 255f).roundToInt()
        }
        return out
    }
}
