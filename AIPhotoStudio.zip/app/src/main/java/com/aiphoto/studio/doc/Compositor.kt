package com.aiphoto.studio.doc

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.aiphoto.studio.engine.Harmonize
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.Segmenter
import com.aiphoto.studio.engine.makeBitmap
import com.aiphoto.studio.engine.readPixels
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Bộ nhớ đệm kết quả ghép theo "tiền tố" danh sách lớp: kết quả sau lớp 0..k được giữ lại, nên khi chỉnh lớp trên cùng
 * (kéo thanh trượt) chỉ phải tính lại ĐÚNG lớp đó thay vì cả chồng lớp. Mỗi độ dài tiền tố chỉ giữ bản mới nhất.
 * Khóa so sánh bằng `==` trên dữ liệu lớp bất biến (ops, mặt nạ, độ mờ, chế độ hòa trộn...).
 */
class RenderCache(private val maxEntries: Int = 14) {
    private class Entry(val bg: Bitmap, val layers: List<Layer>, val result: Bitmap)

    private val entries = ArrayList<Entry>()

    /** Trả về (số lớp đã gộp, ảnh kết quả) của tiền tố khớp dài nhất. */
    @Synchronized
    fun longestPrefix(bg: Bitmap, layers: List<Layer>): Pair<Int, Bitmap>? {
        var best: Entry? = null
        for (e in entries) {
            if (e.bg !== bg || e.layers.size > layers.size) continue
            var ok = true
            for (i in e.layers.indices) {
                if (e.layers[i] != layers[i]) { ok = false; break }
            }
            if (ok && (best == null || e.layers.size > best.layers.size)) best = e
        }
        return best?.let { Pair(it.layers.size, it.result) }
    }

    @Synchronized
    fun put(bg: Bitmap, prefix: List<Layer>, result: Bitmap) {
        entries.removeAll { it.bg === bg && it.layers.size == prefix.size }
        entries.add(Entry(bg, ArrayList(prefix), result))
        while (entries.size > maxEntries) entries.removeAt(0)
    }

    @Synchronized
    fun clear() {
        entries.clear()
    }
}

object Compositor {

    /** Ghép đầy đủ, không cache (dùng khi xuất ảnh / gộp / áp dụng ở độ phân giải gốc). */
    fun render(
        bg: Bitmap,
        layers: List<Layer>,
        fullW: Int,
        segmenter: Segmenter?,
        preview: Boolean,
        notes: MutableList<String>
    ): Bitmap {
        val scale = bg.width.toFloat() / fullW
        var cur = bg
        for ((i, l) in layers.withIndex()) {
            if (!l.visible || l.opacity <= 0.001f) continue
            val clip = clipFor(layers, i, cur, scale, useMaskCache = false)
            if (clip.skip) continue
            cur = applyLayer(cur, l, scale, segmenter, preview, notes, useMaskCache = false, clipCover = clip.cover)
        }
        return cur
    }

    /**
     * Ghép xem trước có cache + có thể bị hủy giữa chừng: [isStale] trả true khi đã có yêu cầu mới hơn
     * (người dùng vẫn đang kéo) -> dừng ngay và trả null để không tốn công tính bản đã cũ.
     */
    fun renderCached(
        bg: Bitmap,
        layers: List<Layer>,
        fullW: Int,
        segmenter: Segmenter?,
        notes: MutableList<String>,
        cache: RenderCache,
        isStale: () -> Boolean
    ): Bitmap? {
        val scale = bg.width.toFloat() / fullW
        var cur = bg
        var start = 0
        cache.longestPrefix(bg, layers)?.let { (n, bmp) ->
            start = n
            cur = bmp
        }
        for (i in start until layers.size) {
            if (isStale()) return null
            val l = layers[i]
            if (l.visible && l.opacity > 0.001f) {
                val clip = clipFor(layers, i, cur, scale, useMaskCache = true)
                if (!clip.skip) cur = applyLayer(cur, l, scale, segmenter, true, notes, useMaskCache = true, clipCover = clip.cover)
            }
            cache.put(bg, layers.subList(0, i + 1), cur)
        }
        return cur
    }

    private fun applyLayer(
        cur: Bitmap,
        l: Layer,
        scale: Float,
        segmenter: Segmenter?,
        preview: Boolean,
        notes: MutableList<String>,
        useMaskCache: Boolean,
        clipCover: FloatArray?
    ): Bitmap {
        if (l is OverlayLayer) return applyOverlay(cur, l, useMaskCache, clipCover)
        val top: Bitmap = when (l) {
            is AdjustmentLayer -> ImageEngine.process(cur, l.ops, segmenter, preview, notes)
            is PatchLayer -> drawPatch(cur, l, scale)
            is OverlayLayer -> cur
        }
        if (top === cur) return cur
        return combine(cur, top, l, useMaskCache, clipCover)
    }

    // ------------------------------------------------------------------ clipping mask
    private class Clip(val skip: Boolean, val cover: FloatArray?)
    private val NO_CLIP = Clip(false, null)

    /**
     * Phạm vi của lớp bị cắt = độ phủ của lớp gần nhất bên dưới KHÔNG bị cắt (mặt nạ × alpha của mảng vá / chữ / ảnh phủ).
     * Lớp gốc là lớp chỉnh không mặt nạ → phủ toàn ảnh (không hạn chế). Lớp gốc bị ẩn → lớp bị cắt cũng không hiện.
     * Mặt nạ phụ thuộc ảnh (độ sáng, màu, trời...) được dựng trên ảnh ngay trước lớp bị cắt (đã gồm lớp gốc) — xấp xỉ chấp nhận được.
     */
    private fun clipFor(layers: List<Layer>, i: Int, cur: Bitmap, scale: Float, useMaskCache: Boolean): Clip {
        val j = ClipLogic.baseIndex(layers, i)
        if (j < 0) return NO_CLIP
        val base = layers[j]
        if (!base.visible || base.opacity <= 0.001f) return Clip(true, null)
        val own = base.mask?.let { MaskRenderer.render(it, cur, useMaskCache) }
        val shape: FloatArray? = when (base) {
            is AdjustmentLayer -> null
            is PatchLayer -> patchAlpha(base, cur.width, cur.height, scale)
            is OverlayLayer -> overlayAlpha(base, cur.width, cur.height)
        }
        return Clip(false, mulMasks(own, shape))
    }

    private fun mulMasks(a: FloatArray?, b: FloatArray?): FloatArray? = when {
        a == null -> b
        b == null -> a
        else -> FloatArray(a.size) { a[it] * b[it] }
    }

    private fun patchAlpha(l: PatchLayer, w: Int, h: Int, scale: Float): FloatArray {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawBitmap(scaledPatch(l, scale), (l.x * scale).roundToInt().toFloat(), (l.y * scale).roundToInt().toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
        val px = readPixels(bmp)
        bmp.recycle()
        return FloatArray(px.size) { (px[it] ushr 24) / 255f }
    }

    private fun overlayAlpha(l: OverlayLayer, w: Int, h: Int): FloatArray {
        val bmp = OverlayRenderer.render(l, w, h) ?: return FloatArray(w * h)   // không có nội dung → phạm vi rỗng
        val px = readPixels(bmp)
        bmp.recycle()
        return FloatArray(px.size) { (px[it] ushr 24) / 255f }
    }

    private fun scaledPatch(l: PatchLayer, scale: Float): Bitmap =
        if (scale >= 0.999f) l.patch else Bitmap.createScaledBitmap(
            l.patch, max(1, (l.patch.width * scale).roundToInt()), max(1, (l.patch.height * scale).roundToInt()), true
        )

    /**
     * Lớp phủ (chữ/ảnh): độ trong suốt của chính lớp phủ được nhân vào mặt nạ, nên chế độ hòa trộn (vd. Screen cho phơi sáng kép)
     * chỉ tác dụng nơi có nội dung — chỗ trong suốt giữ nguyên ảnh nền.
     */
    private fun applyOverlay(cur: Bitmap, l: OverlayLayer, useMaskCache: Boolean, clipCover: FloatArray?): Bitmap {
        val ov = OverlayRenderer.render(l, cur.width, cur.height) ?: return cur
        val ovRaw = readPixels(ov)
        ov.recycle()
        val curPx = readPixels(cur)
        // R25: hòa màu / độ sáng ảnh phủ với nền ngay dưới nó (alpha giữ nguyên nên mặt nạ / viền không đổi)
        val ovPx = if (l.kind == "image" && l.harmonize > 0.01f) Harmonize.match(ovRaw, curPx, cur.width, cur.height, l.harmonize) else ovRaw
        val userMask = l.mask?.let { MaskRenderer.render(it, cur, useMaskCache) }
        val eff = FloatArray(ovPx.size) { i -> ((ovPx[i] ushr 24) / 255f) * (userMask?.get(i) ?: 1f) * (clipCover?.get(i) ?: 1f) }
        val top = IntArray(ovPx.size) { i -> ovPx[i] or (255 shl 24) }
        val out = Blend.blend(curPx, top, l.blend, l.opacity, eff)
        return makeBitmap(out, cur.width, cur.height)
    }

    private fun drawPatch(cur: Bitmap, l: PatchLayer, scale: Float): Bitmap {
        val out = cur.copy(Bitmap.Config.ARGB_8888, true)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)
        val src = scaledPatch(l, scale)
        Canvas(out).drawBitmap(src, (l.x * scale).roundToInt().toFloat(), (l.y * scale).roundToInt().toFloat(), paint)
        return out
    }

    private fun combine(base: Bitmap, top: Bitmap, l: Layer, useMaskCache: Boolean, clipCover: FloatArray?): Bitmap {
        val maskArr = mulMasks(l.mask?.let { MaskRenderer.render(it, base, useMaskCache) }, clipCover)
        if (l.blend == BlendMode.NORMAL && l.opacity >= 0.999f && maskArr == null) return top
        val out = Blend.blend(readPixels(base), readPixels(top), l.blend, l.opacity, maskArr)
        return makeBitmap(out, base.width, base.height)
    }
}
