package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.graphics.Bitmap
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Tham số tiền xử lý theo "hồ sơ" model (thuần Kotlin để kiểm thử).
 *  - U²-Net / IS-Net: kiểu rembg (chia cho giá trị lớn nhất, mean ImageNet; std ImageNet với U²-Net, std = 1 với IS-Net), ảnh VUÔNG,
 *    đầu ra min-max về 0..1.
 *  - MODNet (chân dung, Apache-2.0): theo `onnx/inference_onnx.py` chính thức - (ảnh - 127.5) / 127.5, KHÔNG chia theo giá trị lớn nhất,
 *    giữ TỈ LỆ với cạnh ngắn ≈ 512 và hai cạnh chia hết cho 32; đầu ra đã là matte 0..1.
 */
object SegProfile {
    const val U2NET = "u2net"
    const val ISNET = "isnet"
    const val MODNET = "modnet"

    private const val MODNET_REF = 512

    val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)

    fun mean(profile: String): FloatArray = if (profile == MODNET) floatArrayOf(0.5f, 0.5f, 0.5f) else MEAN

    fun std(profile: String): FloatArray = when (profile) {
        ISNET -> floatArrayOf(1f, 1f, 1f)
        MODNET -> floatArrayOf(0.5f, 0.5f, 0.5f)
        else -> floatArrayOf(0.229f, 0.224f, 0.225f)
    }

    /** true: chia cho giá trị lớn nhất của ảnh (rembg); false: chia 255 (MODNet). */
    fun divideByMax(profile: String): Boolean = profile != MODNET

    /** true: kéo giãn đầu ra min-max về 0..1; false: đầu ra đã là matte 0..1 (MODNet). */
    fun minMaxOutput(profile: String): Boolean = profile != MODNET

    /** Kích thước input khi model khai báo shape động: U²-Net 320, IS-Net 1024, MODNet 512 (cạnh ngắn). */
    fun defaultSize(profile: String): Int = when (profile) {
        ISNET -> 1024
        MODNET -> MODNET_REF
        else -> 320
    }

    /**
     * Kích thước (cao, rộng) đưa vào MODNet theo hàm `get_scale_factor` của bản chính thức: nếu cả ảnh nhỏ hơn 512 hoặc cạnh ngắn
     * lớn hơn 512 thì co/giãn để cạnh ngắn = 512 (giữ tỉ lệ), ngược lại giữ nguyên; sau đó mỗi cạnh làm tròn xuống bội của 32.
     */
    fun modnetSize(h: Int, w: Int, ref: Int = MODNET_REF): Pair<Int, Int> {
        var rh = h
        var rw = w
        if (max(h, w) < ref || min(h, w) > ref) {
            if (w >= h) {
                rh = ref
                rw = (w.toDouble() / h * ref).toInt()
            } else {
                rw = ref
                rh = (h.toDouble() / w * ref).toInt()
            }
        }
        rw -= rw % 32
        rh -= rh % 32
        return Pair(max(32, rh), max(32, rw))
    }
}

/**
 * Tách nền bằng model ONNX họ U²-Net (u2netp.onnx ~4.7MB, u2net.onnx, silueta...), IS-Net (isnet-general-use.onnx;
 * chất lượng cao hơn nhưng input 1024px nên tốn RAM/thời gian hơn - định tuyến chỉ chọn khi máy đủ RAM) hoặc MODNet
 * (chỉ dành cho CHÂN DUNG; input/output theo hợp đồng `input [batch,3,H,W]` → `output [batch,1,H,W]`). Chi tiết tiền xử lý ở [SegProfile].
 */
class OnnxSegmenter(modelPath: String, private val profile: String = SegProfile.U2NET) : Segmenter, AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String
    private val size: Int
    /** Kích thước cố định (cao, rộng) nếu model khai báo shape tĩnh không vuông/không phải `size`; 0 = động. */
    private val fixedH: Int
    private val fixedW: Int
    private val mean = SegProfile.mean(profile)
    private val std = SegProfile.std(profile)

    init {
        session = OrtTuning.createSession(env, modelPath)
        inputName = session.inputNames.iterator().next()
        val info = session.inputInfo[inputName]?.info as? TensorInfo
        val shape = info?.shape
        size = if (shape != null && shape.size == 4 && shape[2] > 0) shape[2].toInt() else SegProfile.defaultSize(profile)
        fixedH = if (shape != null && shape.size == 4 && shape[2] > 0) shape[2].toInt() else 0
        fixedW = if (shape != null && shape.size == 4 && shape[3] > 0) shape[3].toInt() else 0
    }

    @Synchronized
    override fun foregroundMask(bitmap: Bitmap): FloatArray {
        val w = bitmap.width
        val h = bitmap.height
        val inH: Int
        val inW: Int
        if (profile == SegProfile.MODNET) {
            if (fixedH > 0 && fixedW > 0) {
                inH = fixedH
                inW = fixedW
            } else {
                val s = SegProfile.modnetSize(h, w)
                inH = s.first
                inW = s.second
            }
        } else {
            inH = size
            inW = size
        }
        val small = Bitmap.createScaledBitmap(bitmap, inW, inH, true)
        val plane = inW * inH
        val px = IntArray(plane)
        small.getPixels(px, 0, inW, 0, 0, inW, inH)

        var maxV = 255f
        if (SegProfile.divideByMax(profile)) {
            maxV = 1f
            for (p in px) {
                maxV = max(maxV, max(((p shr 16) and 255).toFloat(), max(((p shr 8) and 255).toFloat(), (p and 255).toFloat())))
            }
        }
        val data = FloatArray(3 * plane)
        for (i in px.indices) {
            val p = px[i]
            data[i] = (((p shr 16) and 255) / maxV - mean[0]) / std[0]
            data[plane + i] = (((p shr 8) and 255) / maxV - mean[1]) / std[1]
            data[2 * plane + i] = ((p and 255) / maxV - mean[2]) / std[2]
        }

        val rows = ArrayList<FloatArray>()
        val shape = longArrayOf(1, 3, inH.toLong(), inW.toLong())
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { tensor ->
            session.run(mapOf(inputName to tensor)).use { result ->
                collectRows(result.get(0).value, rows)
            }
        }
        require(rows.isNotEmpty()) { "Model không trả về mặt nạ hợp lệ" }

        val mh = rows.size
        val mw = rows[0].size
        var mn = 0f
        var range = 1f
        if (SegProfile.minMaxOutput(profile)) {
            mn = Float.MAX_VALUE
            var mx = -Float.MAX_VALUE
            for (row in rows) for (v in row) { if (v < mn) mn = v; if (v > mx) mx = v }
            range = if (mx - mn < 1e-6f) 1f else mx - mn
        }

        val maskPx = IntArray(mw * mh)
        for (y in 0 until mh) for (x in 0 until mw) {
            val g = (((rows[y][x] - mn) / range).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            maskPx[y * mw + x] = (255 shl 24) or (g shl 16) or (g shl 8) or g
        }
        val maskSmall = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888)
        maskSmall.setPixels(maskPx, 0, mw, 0, 0, mw, mh)
        val big = Bitmap.createScaledBitmap(maskSmall, w, h, true)
        val bp = IntArray(w * h)
        big.getPixels(bp, 0, w, 0, 0, w, h)
        return FloatArray(w * h) { (bp[it] and 255) / 255f }
    }

    private fun collectRows(v: Any?, acc: MutableList<FloatArray>) {
        when (v) {
            is FloatArray -> acc.add(v)
            is Array<*> -> for (e in v) collectRows(e, acc)
        }
    }

    override fun close() {
        try { session.close() } catch (e: Throwable) { }
    }
}
