package com.aiphoto.studio.engine

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Tách TÓC bằng MediaPipe Image Segmenter (tasks-vision, Apache-2.0). Model do người dùng nạp (`hair_segmenter.tflite`, 512×512,
 * 0 = nền, 1 = tóc; hoặc `selfie_multiclass_256x256.tflite` - lớp 1 cũng là tóc) và lưu trong filesDir/models.
 * Dùng category mask (uint8, mỗi điểm = chỉ số lớp) rồi phóng to (lân cận) về kích thước ảnh; độ mềm biên do LayerMask.feather lo.
 */
class HairSegmenterEngine(context: Context, modelPath: String) : AutoCloseable {

    private val segmenter: ImageSegmenter
    private val mapped: MappedByteBuffer

    init {
        mapped = RandomAccessFile(File(modelPath), "r").use { raf ->
            raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length())
        }
        val base = BaseOptions.builder().setModelAssetBuffer(mapped).build()
        val options = ImageSegmenter.ImageSegmenterOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setOutputCategoryMask(true)
            .setOutputConfidenceMasks(false)
            .build()
        segmenter = ImageSegmenter.createFromOptions(context.applicationContext, options)
    }

    /** Mặt nạ tóc 0/255 kích thước bằng ảnh; null nếu model không trả về category mask dạng 1 byte/điểm. */
    @Synchronized
    fun hairMask(bitmap: Bitmap): ByteArray? {
        val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val result = segmenter.segment(BitmapImageBuilder(argb).build())
        val opt = result.categoryMask()
        if (!opt.isPresent) return null
        val mp = opt.get()
        val mw = mp.width
        val mh = mp.height
        val bb = ByteBufferExtractor.extract(mp)
        if (mw <= 0 || mh <= 0 || bb.remaining() / (mw * mh) != 1) return null
        val w = argb.width
        val h = argb.height
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            val sy = minOf(mh - 1, y * mh / h)
            for (x in 0 until w) {
                val sx = minOf(mw - 1, x * mw / w)
                if (bb.get(sy * mw + sx).toInt() == HAIR_CLASS) out[y * w + x] = 255.toByte()
            }
        }
        return out
    }

    override fun close() {
        try { segmenter.close() } catch (e: Throwable) { }
    }

    private companion object {
        const val HAIR_CLASS = 1
    }
}
