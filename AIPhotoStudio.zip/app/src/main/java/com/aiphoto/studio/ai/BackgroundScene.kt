package com.aiphoto.studio.ai

import java.text.Normalizer
import java.util.Locale

/**
 * Hiểu yêu cầu THAY NỀN (PDF: "thay nền thành bãi biển"): tách phần mô tả cảnh mới ra khỏi câu lệnh.
 *  - [extract] trả về mô tả cảnh (giữ nguyên chữ người dùng gõ, để model sinh ảnh / bộ dịch hiểu), hoặc null nếu không phải
 *    yêu cầu thay nền BẰNG MỘT CẢNH (nền màu trơn đã có đường riêng: tách nền → tô màu).
 *  - [isBackgroundSwap] dùng cho bộ phân loại ý định: mọi yêu cầu đổi nền (cảnh hoặc màu) KHÔNG phải "thêm vật thể vào vùng tô".
 * Thuần Kotlin, không phụ thuộc thiết bị/model.
 */
object BackgroundScene {

    private const val BG = "(?:phông nền|phong nen|nền|nen|phông|phong|hậu cảnh|hau canh|background|backdrop)"
    private const val OF_PHOTO = "(?:\\s+(?:của\\s+)?(?:bức ảnh|buc anh|ảnh|anh|hình|hinh|photo|picture|image))?"
    private const val END = "(?![\\p{L}\\p{N}])"
    // tối đa MỘT từ nối: "đổi nền sang thành phố ban đêm" → từ nối "sang", cảnh = "thành phố ban đêm"
    private const val LINK = "(?:\\s+(?:thành|thanh|sang|bằng|bang|là|la|qua|ra|to|into|with|by|for|as)$END)?"

    private val SWAP_VI = Regex("(?:thay|đổi|doi|chuyển|chuyen|biến|bien)\\s+(?:cái\\s+|lại\\s+)?$BG$END$OF_PHOTO$LINK\\s*[:=]?\\s*(.+)")
    private val SWAP_EN = Regex("(?:replace|change|swap|switch|turn)\\s+(?:the\\s+|my\\s+|this\\s+)?(?:photo\\s+|picture\\s+|image\\s+)?$BG$END$LINK\\s*[:=]?\\s*(.+)")
    private val PUT_VI = Regex(
        "(?:đặt|dat|đưa|dua|bỏ|bo|chuyển|chuyen)\\s+(?:tôi|toi|mình|minh|em|anh ấy|anh ay|cô ấy|co ay|người|nguoi|chủ thể|chu the|nhân vật|nhan vat|bé|be)\\s+" +
            "(?:vào|vao|ra|ở|tại|tai|lên|len|trên|tren|giữa|giua)$END\\s+(.+)"
    )
    private val PUT_EN = Regex("(?:put|place|move|set|drop)\\s+(?:me|him|her|them|the subject|the person|us)\\s+(?:in front of|inside|into|onto|in|on|at)\\s+(.+)")

    /** "đặt cô ấy vào chiếc váy đỏ" là thay trang phục chứ không phải thay nền: câu "đặt…vào X" chỉ tính khi X là nơi chốn. */
    private val NOT_A_PLACE = Regex(
        "(?:^|\\s)(?:vay|ao|quan|non|mu|kinh|giay|dep|tui|khan|nhan|day chuyen|dress|shirt|jacket|coat|hat|cap|glasses|shoes|bag|scarf|necklace|ring|suit|skirt|pants)(?:\\s|$)"
    )

    /** "đổi nền mờ hơn", "make the background darker": chỉnh độ sáng/mờ của nền, không phải thay bằng cảnh khác. */
    private val COMPARATIVE_VI = Regex("(?:^|\\s)hơn$")
    private val COMPARATIVE_EN = Regex("(?:^|\\s)(?:darker|lighter|brighter|blurrier|blurry|blurred|sharper|softer|more|less)(?:\\s|$)")

    /** Gõ không dấu thì "mo hon" (mờ hơn) khác "hoang hon" (hoàng hôn) ở chỗ nào? → loại riêng "hoang hon". */
    private fun isAdjustment(scene: String, folded: String): Boolean =
        COMPARATIVE_VI.containsMatchIn(scene) || COMPARATIVE_EN.containsMatchIn(folded) ||
            (folded.endsWith(" hon") && !folded.endsWith("hoang hon") && scene == folded)

    private val COLOR_ONLY = Regex(
        "^(?:mau\\s+)?(?:trang|den|do|vang|hong|xam|tim|cam|nau|xanh(?:\\s+(?:duong|la|ngoc|lam|luc|nhat|dam|reu))?|" +
            "white|black|red|yellow|pink|gray|grey|purple|orange|brown|blue|green|transparent|trong suot|solid)" +
            "(?:\\s+(?:nhat|dam|sang|toi|light|dark|pastel|tron|solid|color|colour|background))*$"
    )

    // phần sau "và / , / ;" chỉ là yêu cầu khác khi nó mở đầu bằng động từ chỉnh sửa ("…bãi biển, tăng sáng"), còn "bãi biển, hoàng hôn" vẫn là cảnh
    private const val EDIT_VERB = "(?:tăng|tang|giảm|giam|làm|lam|thêm|them|xóa|xoa|chỉnh|chinh|cho|đổi|doi|làm cho|make|increase|decrease|brighten|darken|add|remove|apply|smooth|sharpen|blur|crop|rotate|enhance)"
    private val SOFT_SPLIT = Regex("(?:\\s*[,;]\\s*|\\s+(?:và|va|and)\\s+)(?=$EDIT_VERB$END)")
    private val HARD_SPLIT = Regex("[.!?\\n]|\\s+(?:rồi|roi|then|đồng thời|dong thoi|also)\\s+")
    private val LEAD_ARTICLE = Regex("^(?:một|mot|cảnh|canh|khung cảnh|khung canh|a|an|the|nền|nen|background)\\s+")

    private fun fold(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "").replace('đ', 'd')
            .replace(Regex("[^a-z0-9\\s]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun capture(prompt: String): String? {
        val text = Normalizer.normalize(prompt.lowercase(Locale.ROOT), Normalizer.Form.NFC).trim()
        for ((rx, isPut) in listOf(SWAP_VI to false, SWAP_EN to false, PUT_VI to true, PUT_EN to true)) {
            val m = rx.find(text) ?: continue
            var scene = m.groupValues[1].trim()
            scene = scene.split(HARD_SPLIT)[0].split(SOFT_SPLIT)[0].trim()
            scene = scene.replace(LEAD_ARTICLE, "").trim()
            if (scene.isEmpty()) continue
            val f = fold(scene)
            if (isAdjustment(scene, f)) continue
            if (isPut && NOT_A_PLACE.containsMatchIn(f)) continue
            return scene
        }
        return null
    }

    /** true nếu là yêu cầu đổi nền (bằng cảnh HOẶC màu trơn). */
    fun isBackgroundSwap(prompt: String): Boolean = capture(prompt) != null

    /** Mô tả cảnh mới, hoặc null nếu không phải yêu cầu thay nền / đích chỉ là màu trơn. */
    fun extract(prompt: String): String? {
        val scene = capture(prompt) ?: return null
        return if (COLOR_ONLY.matches(fold(scene))) null else scene
    }

    /** Câu mô tả gửi cho dịch vụ sinh ảnh: cảnh mới + ràng buộc cho khớp ánh sáng với chủ thể. */
    fun generationPrompt(scene: String): String =
        "$scene. Photorealistic background scene behind the subject, lighting and color temperature matching the subject, " +
            "natural depth of field, no people added, no text."
}
