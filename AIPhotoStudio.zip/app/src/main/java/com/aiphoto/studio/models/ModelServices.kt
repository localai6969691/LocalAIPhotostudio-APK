package com.aiphoto.studio.models

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.aiphoto.studio.MainViewModel
import com.aiphoto.studio.i18n.I18n
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.File

/**
 * R44: "cổng" dùng chung toàn tiến trình cho việc tải model — để tải KHÔNG gắn với vòng đời của màn hình:
 *  - [ModelHub] sống trong phạm vi ứng dụng (không phải viewModelScope) nên thoát app / đóng Activity không làm dừng tải;
 *  - [DownloadService] (dịch vụ nền có thông báo) giữ tiến trình sống khi app ra nền;
 *  - lúc tải xong, nếu màn hình đang mở thì giao tệp cho MainViewModel ([installer]) như cũ; nếu app đã đóng thì đặt thẳng vào thư mục model
 *    ([placeOnDisk]) và lần mở sau `restoreModels()` sẽ nhận (tệp đã qua kiểm SHA-256 nên toàn vẹn).
 */
object ModelServices {
    const val CHANNEL_ID = "model_download"
    const val RESULT_NOTIFICATION_ID = 4402

    private const val PREFS = "model_download"
    private const val KEY_WIFI_ONLY = "wifi_only"
    private const val KEY_NOTIF_ASKED = "notif_asked"

    @Volatile private var hubRef: ModelHub? = null
    @Volatile private var monitor: NetworkMonitor? = null

    /** MainViewModel đang sống đặt vào đây để nhận tệp tải xong (và gỡ ra ở onCleared). */
    @Volatile var installer: ((slot: String, file: File) -> Unit)? = null

    /** Thông điệp trạng thái hiển thị trên màn hình (MainViewModel đặt / gỡ). */
    @Volatile var sayListener: ((String) -> Unit)? = null

    /** MainActivity đặt true ở onStart, false ở onStop — để không báo "đã tải xong" bằng thông báo khi người dùng đang nhìn app. */
    @Volatile var uiVisible: Boolean = false

    fun modelDir(ctx: Context): File = File(ctx.applicationContext.filesDir, "models").apply { mkdirs() }

    /** Tên tệp của một ô model trong thư mục model của app (null = bản này không có ô đó). */
    fun slotFile(ctx: Context, slot: String): File? {
        val name = when (slot) {
            "seg" -> MainViewModel.SEG_FILE
            "seg_hq" -> MainViewModel.SEG_HQ_FILE
            "portrait" -> MainViewModel.SEG_PORTRAIT_FILE
            "lama" -> MainViewModel.LAMA_FILE
            "migan" -> MainViewModel.MIGAN_FILE
            "esrgan" -> MainViewModel.ESRGAN_FILE
            "sam_encoder" -> MainViewModel.SAM_ENC_FILE
            "sam_decoder" -> MainViewModel.SAM_DEC_FILE
            "face" -> MainViewModel.FACE_FILE
            "hair" -> MainViewModel.HAIR_FILE
            "person" -> MainViewModel.PERSON_FILE
            "depth" -> MainViewModel.DEPTH_FILE
            else -> return null
        }
        return File(modelDir(ctx), name)
    }

    /** Tạo (một lần) và trả về bộ điều phối tải duy nhất của tiến trình. */
    fun hub(ctx: Context): ModelHub {
        hubRef?.let { return it }
        synchronized(this) {
            hubRef?.let { return it }
            val app = ctx.applicationContext
            val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val mon = NetworkMonitor(app) { hubRef?.onNetworkChanged() }
            val h = ModelHub(
                scope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
                workDir = File(app.cacheDir, "model_dl"),
                consentFile = File(modelDir(app), "licenses_accepted.txt"),
                catalogCache = File(app.filesDir, "model_catalog_cache.json"),
                bundledJson = { app.assets.open("model_catalog.json").bufferedReader().use { it.readText() } },
                slotFile = { slotFile(app, it) },
                install = { slot, f -> deliver(app, slot, f) },
                say = { msg -> sayListener?.invoke(msg) },
                network = { mon.kind },
                wifiOnly = prefs.getBoolean(KEY_WIFI_ONLY, true),      // mặc định BẬT: không tự tốn dữ liệu di động của người dùng
                saveWifiOnly = { prefs.edit().putBoolean(KEY_WIFI_ONLY, it).apply() },
                queueFile = File(app.filesDir, "model_download_queue.txt")
            )
            h.onKeepAlive = { on -> if (on) DownloadService.start(app) }      // tắt: dịch vụ tự dừng khi thấy hàng đợi rỗng
            h.onResult = { e, ok, msg -> if (!uiVisible) notifyResult(app, e, ok, msg) }
            monitor = mon
            hubRef = h
            mon.start()
            return h
        }
    }

    /** Đã hỏi quyền hiện thông báo (Android 13+) chưa — hỏi đúng một lần, không làm phiền. */
    fun notificationsAsked(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_NOTIF_ASKED, false)

    fun markNotificationsAsked(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_NOTIF_ASKED, true).apply()
    }

    private fun deliver(app: Context, slot: String, f: File) {
        val inst = installer
        if (inst != null) { inst(slot, f); return }
        placeOnDisk(app, slot, f)
    }

    /** App đã đóng: đặt tệp đã kiểm SHA-256 vào thư mục model (ghi tạm rồi đổi tên); lần mở sau app tự nhận. */
    private fun placeOnDisk(app: Context, slot: String, f: File) {
        val dest = slotFile(app, slot) ?: return
        dest.absoluteFile.parentFile?.mkdirs()
        val tmp = File(dest.path + ".new")
        f.copyTo(tmp, overwrite = true)
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
        f.delete()
    }

    private fun notifyResult(app: Context, e: ModelEntry, ok: Boolean, msg: String) {
        runCatching {
            I18n.init(app)
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            DownloadService.ensureChannel(app, nm)
            val open = app.packageManager.getLaunchIntentForPackage(app.packageName)
            val pi = open?.let { PendingIntent.getActivity(app, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
            val n = Notification.Builder(app, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(I18n.tr("Tải model AI"))
                .setContentText(I18n.tr(msg))
                .setAutoCancel(true)
                .apply { if (pi != null) setContentIntent(pi) }
                .build()
            nm.notify(RESULT_NOTIFICATION_ID, n)
        }
    }
}
