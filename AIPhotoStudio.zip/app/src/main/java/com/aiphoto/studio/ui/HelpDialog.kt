package com.aiphoto.studio.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.i18n.AppLanguages
import com.aiphoto.studio.i18n.HelpContent
import com.aiphoto.studio.i18n.I18n
import com.aiphoto.studio.i18n.Text

/**
 * Trợ giúp (R33): hướng dẫn đầy đủ chức năng, có ô tìm kiếm, bấm tiêu đề để mở / gập nội dung. Nội dung nằm ở assets/help/<ngôn ngữ>.json
 * (cùng cấu trúc ở mọi ngôn ngữ) và theo ngôn ngữ giao diện đang chọn; thiếu thì dùng tiếng Anh, rồi tiếng Việt.
 */
@Composable
fun HelpDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lang = I18n.active
    val all = remember(lang) { I18n.helpSections(ctx) }
    var query by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(setOf<String>()) }
    val shown = HelpContent.filter(all, query)
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Đóng") } },
        title = { Text("Trợ giúp") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    label = { Text("Tìm trong trợ giúp") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (shown.isEmpty()) Text("Không tìm thấy mục nào khớp.")
                for (section in shown) {
                    Text(section.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 10.dp))
                    for (item in section.items) {
                        val id = section.title + "/" + item.title
                        val expanded = query.isNotBlank() || id in open
                        Text(
                            (if (expanded) "▾ " else "▸ ") + item.title,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { open = if (id in open) open - id else open + id }
                                .padding(vertical = 6.dp)
                        )
                        if (expanded) Text(item.body, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 14.dp, bottom = 4.dp))
                    }
                }
            }
        }
    )
}

/** Chọn ngôn ngữ giao diện; đổi là áp dụng ngay (mọi chữ vẽ lại), không cần khởi động lại app. */
@Composable
fun LanguageDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pref = I18n.preference
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Đóng") } },
        title = { Text("Ngôn ngữ") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                LanguageRow("Tự động (theo hệ thống)", pref == AppLanguages.AUTO) { I18n.setLanguage(ctx, AppLanguages.AUTO) }
                for (l in AppLanguages.ALL) {
                    val pct = I18n.coveragePercent(l.code)
                    LanguageRow(l.nativeName + (if (pct < 100) " · $pct%" else ""), pref == l.code) { I18n.setLanguage(ctx, l.code) }
                }
                Text(
                    "Tỉ lệ ghi cạnh tên ngôn ngữ là phần giao diện đã dịch; phần chưa dịch hiện bằng tiếng Anh. Ngôn ngữ giao diện không đổi cách app hiểu câu lệnh bạn gõ (xem Trợ giúp, mục Gõ yêu cầu).",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    )
}

@Composable
private fun LanguageRow(label: String, selected: Boolean, onPick: () -> Unit) {
    TextButton(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
        Text(if (selected) "✓ " else "   ")
        Text(label)
    }
}

/** Hộp thoại chào lần đầu mở app: nói rõ đây là bản thử nghiệm miễn phí, cho đổi ngôn ngữ và dẫn tới Trợ giúp. */
@Composable
fun WelcomeDialog(beta: Boolean, onStart: () -> Unit, onHelp: () -> Unit, onLanguage: () -> Unit) {
    val name = AppLanguages.byCode(I18n.active)?.nativeName ?: ""
    AlertDialog(
        onDismissRequest = onStart,
        confirmButton = { TextButton(onClick = onStart) { Text("Bắt đầu") } },
        dismissButton = { TextButton(onClick = onHelp) { Text("Xem hướng dẫn") } },
        title = { Text("Chào mừng bạn đến với AI Photo Studio!") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (beta) {
                    Text("Đây là bản dùng thử MIỄN PHÍ dành cho tester: không tính phí, ảnh xuất ra không có watermark. Bạn đang giúp tìm lỗi và hoàn thiện ứng dụng — cảm ơn bạn!")
                } else {
                    Text("Cảm ơn bạn đã dùng AI Photo Studio.")
                }
                Text("Bấm ? ở thanh trên để xem hướng dẫn đầy đủ. Gặp lỗi: bấm ⚙ rồi chọn \"Gửi thông tin lỗi\".")
                OutlinedButton(onClick = onLanguage) { Text("Ngôn ngữ: $name") }
            }
        }
    )
}
