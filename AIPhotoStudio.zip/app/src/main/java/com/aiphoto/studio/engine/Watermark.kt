package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/** Dấu mờ góc phải-dưới khi xuất ảnh ở gói Free (chỉ khi dùng máy chủ thương mại; chế độ cá nhân không có watermark). */
object Watermark {
    const val TEXT = "AI Photo Studio"

    fun textSize(w: Int, h: Int): Float = max(18f, min(w, h) * 0.035f)

    fun apply(src: Bitmap): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val size = textSize(out.width, out.height)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            color = Color.WHITE
            alpha = 190
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(size * 0.12f, 0f, 0f, Color.BLACK)
        }
        val w = paint.measureText(TEXT)
        Canvas(out).drawText(TEXT, out.width - w - size, out.height - size, paint)
        return out
    }
}
