package com.aiphoto.studio.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Backend MediaPipe LLM Inference (tasks-genai) cho model .task/.bin. Dùng mẫu hội thoại Gemma nên khuyến nghị Gemma; muốn model khác
 * đổi [wrapChat]. Chỉ văn bản (không nhận ảnh). MediaPipe LLM Inference đang ở chế độ bảo trì - dùng LiteRT-LM cho dự án mới.
 */
class MediaPipeTextGen(context: Context, modelPath: String) : TextGen {

    override val supportsImage: Boolean = false

    override val backendName: String get() = "MediaPipe"

    private val llm: LlmInference

    init {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .build()
        llm = LlmInference.createFromOptions(context.applicationContext, options)
    }

    override fun generate(prompt: String, imagePath: String?): String {
        require(imagePath == null) { "MediaPipe LLM Inference (.task) không nhận ảnh; dùng model .litertlm đa phương thức." }
        return llm.generateResponse(wrapChat(prompt))
    }

    override fun close() {
        try { llm.close() } catch (e: Throwable) { }
    }

    private fun wrapChat(body: String): String =
        "<start_of_turn>user\n$body<end_of_turn>\n<start_of_turn>model\n"
}
