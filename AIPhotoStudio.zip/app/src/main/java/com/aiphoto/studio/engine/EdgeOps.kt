package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * "Refine Edge" của Photoshop (PDF mục "Mask & selection chuyên nghiệp"): làm mềm (feather - đã có ở MaskRenderer),
 * DỊCH BIÊN (shift edge) và KHỬ MÀU VIỀN (decontaminate colors). Thuần Kotlin để kiểm thử trên JVM.
 */
object EdgeOps {

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Hàm phân phối chuẩn (xấp xỉ erf của Abramowitz-Stegun 7.1.26, sai số < 1.5e-7). */
    fun normalCdf(x: Float): Float {
        val z = abs(x) / 1.41421356f
        val t = 1f / (1f + 0.3275911f * z)
        val poly = ((((1.061405429f * t - 1.453152027f) * t) + 1.421413741f) * t - 0.284496736f) * t + 0.254829592f
        val erf = 1f - poly * t * exp(-z * z)
        return 0.5f * (1f + (if (x >= 0f) erf else -erf))
    }

    /**
     * Dịch biên mặt nạ [mask] (0..1): [shift] > 0 nở ra, < 0 co vào; ±1 tương ứng ±2% cạnh dài ảnh.
     * Làm mờ Gauss rồi lấy ngưỡng: ngưỡng t = Φ(-d/σ) làm đường đồng mức dịch đúng d điểm ảnh.
     */
    fun shiftEdge(mask: FloatArray, w: Int, h: Int, shift: Float): FloatArray {
        val d = shift.coerceIn(-1f, 1f) * 0.02f * max(w, h)
        if (abs(d) < 0.5f) return mask
        val r = max(2, abs(d).roundToInt())
        val gray = IntArray(w * h) {
            val g = (mask[it] * 255f + 0.5f).toInt().coerceIn(0, 255)
            (255 shl 24) or (g shl 16) or (g shl 8) or g
        }
        val blurred = Blur.gaussian(gray, w, h, r)
        val sigma = sqrt(r.toFloat() * (r + 1))
        val t = normalCdf(-d / sigma)
        val out = FloatArray(mask.size)
        for (i in out.indices) out[i] = smooth(t - 0.15f, t + 0.15f, (blurred[i] and 255) / 255f)
        return out
    }

    /**
     * Khử màu viền: điểm ảnh bán trong suốt (alpha < 0.98) thường còn lẫn màu của nền cũ. Thay màu của chúng bằng màu
     * trung bình có trọng số alpha^4 của vùng lân cận ("normalized convolution"), nên viền lấy màu của chủ thể.
     * Trả về ARGB mới (alpha giữ nguyên từ [px]); [alpha] là mặt nạ 0..1 của chủ thể.
     */
    fun decontaminate(px: IntArray, alpha: FloatArray, w: Int, h: Int, radius: Int): IntArray {
        val r = max(1, radius)
        val num = IntArray(w * h)
        val den = IntArray(w * h)
        for (i in px.indices) {
            val a = alpha[i].coerceIn(0f, 1f)
            val m = a * a * a * a // trọng số alpha^4: điểm gần đặc quyết định màu (thử nghiệm: sai số màu viền giảm ~10 lần so với trọng số tuyến tính)
            val p = px[i]
            val cr = (((p shr 16) and 255) * m + 0.5f).toInt()
            val cg = (((p shr 8) and 255) * m + 0.5f).toInt()
            val cb = ((p and 255) * m + 0.5f).toInt()
            num[i] = (255 shl 24) or (cr shl 16) or (cg shl 8) or cb
            val g = (m * 255f + 0.5f).toInt()
            den[i] = (255 shl 24) or (g shl 16) or (g shl 8) or g
        }
        val bn = Blur.gaussian(num, w, h, r)
        val bd = Blur.gaussian(den, w, h, r)
        val out = px.copyOf()
        for (i in px.indices) {
            if (alpha[i] >= 0.98f) continue
            val dd = bd[i] and 255
            if (dd < 8) continue // lân cận gần như không có chủ thể -> giữ nguyên
            val nr = (((bn[i] shr 16) and 255) * 255f / dd).roundToInt().coerceIn(0, 255)
            val ng = (((bn[i] shr 8) and 255) * 255f / dd).roundToInt().coerceIn(0, 255)
            val nb = ((bn[i] and 255) * 255f / dd).roundToInt().coerceIn(0, 255)
            out[i] = (px[i] and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }
}
