package com.aiphoto.studio.util

import java.io.File
import java.time.Instant
import java.util.Locale

/**
 * Kênh báo lỗi cho tester (R24). Toàn bộ logic ở đây là Kotlin thuần (không đụng android.*) nên kiểm thử được trên JVM:
 *  - [DiagLog]: nhật ký vòng tròn trong bộ nhớ (trạng thái, việc nền, lỗi) - không ghi ra đĩa, không có nội dung ảnh.
 *  - [DiagReport]: ẩn khóa/token/email/đường dẫn ảnh, ghép báo cáo gửi đi.
 *  - [CrashStore] + [CrashHandler]: lưu lỗi làm app đóng đột ngột để lần mở sau báo lại.
 *  - [ExitRecord]: lần tiến trình bị hệ thống kết thúc (thiếu bộ nhớ, treo, lỗi native... mà CrashHandler không bắt được).
 * Không có gì tự gửi đi: báo cáo chỉ rời máy khi người dùng bấm Gửi và chọn ứng dụng nhận.
 */
object DiagLog {
    const val CAPACITY = 200
    const val MAX_LINE = 300

    private class Entry(val ts: Long, val tag: String, val msg: String)

    private val lock = Any()
    private val buf = ArrayDeque<Entry>()
    @Volatile private var clock: () -> Long = { System.currentTimeMillis() }
    @Volatile private var t0 = clock()

    /** Đặt lại nhật ký (và đồng hồ, để kiểm thử giả lập thời gian). */
    fun reset(clock: () -> Long = { System.currentTimeMillis() }) {
        synchronized(lock) {
            buf.clear()
            this.clock = clock
            t0 = clock()
        }
    }

    fun add(tag: String, msg: String, maxLen: Int = MAX_LINE) {
        val line = msg.trim().replace('\n', '|').replace('\r', ' ')
        if (line.isEmpty()) return
        val cut = if (line.length > maxLen) line.substring(0, maxLen) + "…" else line
        synchronized(lock) {
            val last = buf.lastOrNull()
            if (last != null && last.tag == tag && last.msg == cut) return   // cùng trạng thái lặp liên tiếp: bỏ
            buf.addLast(Entry(clock(), tag, cut))
            while (buf.size > CAPACITY) buf.removeFirst()
        }
    }

    /** Các dòng mới nhất (cũ → mới), dạng "+  12.3s [tag] nội dung" (giây tính từ lúc mở app). */
    fun snapshot(max: Int = CAPACITY): List<String> = synchronized(lock) {
        buf.toList().takeLast(max.coerceAtLeast(0)).map { e ->
            String.format(Locale.ROOT, "+%7.1fs [%s] %s", (e.ts - t0) / 1000.0, e.tag, e.msg)
        }
    }

    fun size(): Int = synchronized(lock) { buf.size }
}

/** Một lần tiến trình bị kết thúc, lấy từ ApplicationExitInfo (Android 11+). */
data class ExitRecord(
    val reason: Int,
    val importance: Int,
    val timestampMs: Long,
    val pssKb: Long = 0,
    val rssKb: Long = 0,
    val description: String = "",
    val status: Int = 0
)

object DiagReport {
    const val MAX_CHARS = 30_000
    const val NOTE_MAX = 600
    private const val MASK = "[đã ẩn]"

    /** Mỗi quy tắc chạy theo thứ tự. Mục tiêu: tester không vô tình gửi khóa AI, token máy chủ, email, đường dẫn ảnh cá nhân. */
    private val RULES: List<Pair<Regex, String>> = listOf(
        Regex("""(?i)\bbearer\s+[A-Za-z0-9._~+/=\-]{6,}""") to "Bearer $MASK",
        Regex("""(?i)\b(authorization|x-goog-api-key|x-api-key|api[-_ ]?key|apikey|access[-_ ]?token|refresh[-_ ]?token|id[-_ ]?token|token|secret|password|passwd|key|sig|signature)(["']?)\s*[=:]\s*("[^"]*"|'[^']*'|[^\s,;&"')\]}]+)""") to "$1=$MASK",
        Regex("""\bAIza[0-9A-Za-z_\-]{16,}""") to "AIza$MASK",
        Regex("""\benc1:\S+""") to "enc1:$MASK",
        Regex("""(?i)\b(?:content|file)://\S+""") to "uri://$MASK",
        Regex("""(?i)(https?://)[^/\s:@]+:[^/\s@]+@""") to "$1$MASK@",
        Regex("""(/storage/emulated/\d+|/sdcard|/mnt/sdcard)/[^\s"')\]]+""") to "$1/$MASK",
        Regex("""[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}""") to "[email]",
        Regex("""(?<![A-Za-z0-9_\-])(?=[A-Za-z0-9_\-]*\d)(?=[A-Za-z0-9_\-]*[A-Za-z])[A-Za-z0-9_\-]{32,}(?![A-Za-z0-9_\-])""") to MASK
    )

    fun scrub(text: String): String {
        var s = text
        for ((re, rep) in RULES) s = re.replace(s, rep)
        return s
    }

    /** Chỉ lấy "máy chủ:cổng" của một URL (bỏ giao thức, tài khoản:mật khẩu, đường dẫn, tham số); rỗng nếu URL trống. */
    fun hostOf(url: String): String {
        var s = url.trim()
        if (s.isEmpty()) return ""
        s = s.substringAfter("://", s)
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
        s = s.substringAfterLast('@')
        return s
    }

    /** Ngăn xếp lỗi gọn: tên lớp + thông điệp (≤300 ký tự) + tối đa [maxFrames] khung, kèm chuỗi "Caused by" (≤[maxCauses]). */
    fun formatThrowable(t: Throwable, maxFrames: Int = 25, maxCauses: Int = 3): String {
        val sb = StringBuilder()
        var cur: Throwable? = t
        var depth = 0
        val seen = HashSet<Throwable>()
        while (cur != null && depth <= maxCauses && seen.add(cur)) {
            if (depth > 0) sb.append("Caused by: ")
            sb.append(cur.javaClass.name)
            val m = runCatching { cur!!.message }.getOrNull()
            if (!m.isNullOrEmpty()) sb.append(": ").append(m.take(300))
            sb.append('\n')
            val st = cur.stackTrace
            val n = minOf(st.size, maxFrames)
            for (i in 0 until n) sb.append("  at ").append(st[i]).append('\n')
            if (st.size > n) sb.append("  … +").append(st.size - n).append(" khung nữa\n")
            cur = cur.cause
            depth++
        }
        return sb.toString().trimEnd()
    }

    // ------------------------------------------------------------------ ApplicationExitInfo
    fun reasonName(reason: Int): String = when (reason) {
        0 -> "UNKNOWN"
        1 -> "EXIT_SELF"
        2 -> "SIGNALED"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "REASON_$reason"
    }

    private val ABNORMAL = setOf(2, 3, 4, 5, 6, 7, 9, 12, 14)

    /** Kết thúc bất thường (không phải người dùng vuốt tắt, tự thoát, cài bản mới...). */
    fun isAbnormal(reason: Int): Boolean = reason in ABNORMAL

    /** Lúc bị tắt, người dùng có đang nhìn thấy app không (importance < 300: foreground/visible/perceptible); bị tắt khi chạy nền thì không báo gây khó chịu. */
    fun wasVisible(importance: Int): Boolean = importance in 1 until 300

    fun explainExit(reason: Int): String = when (reason) {
        3 -> "Hệ thống tắt app vì thiếu bộ nhớ. Thử ảnh nhỏ hơn, đóng bớt app khác hoặc gỡ bớt model lớn."
        4 -> "App gặp lỗi và tự đóng."
        5 -> "Lỗi ở thư viện gốc (native), thường liên quan model/ONNX/GPU. Hãy ghi lại thao tác vừa làm."
        6 -> "App không phản hồi quá lâu nên bị tắt (treo)."
        2 -> "Tiến trình bị tín hiệu hệ thống kết thúc (thường do trình quản lý pin/bộ nhớ của hãng máy)."
        7 -> "App không khởi động được."
        9 -> "App dùng tài nguyên quá mức nên bị tắt."
        12, 14 -> "Hệ thống kết thúc app do thành phần phụ thuộc/đóng băng tiến trình."
        else -> ""
    }

    fun describeExit(r: ExitRecord): String {
        val sb = StringBuilder()
        sb.append(Instant.ofEpochMilli(r.timestampMs)).append(' ').append(reasonName(r.reason))
        sb.append(" · mức ưu tiên ").append(r.importance).append(if (wasVisible(r.importance)) " (đang hiển thị)" else " (chạy nền)")
        if (r.pssKb > 0) sb.append(" · pss ").append(r.pssKb / 1024).append(" MB")
        if (r.rssKb > 0) sb.append(" · rss ").append(r.rssKb / 1024).append(" MB")
        if (r.description.isNotBlank()) sb.append(" · ").append(r.description.take(160))
        return sb.toString()
    }

    /**
     * Lần bị kết thúc bất thường GẦN NHẤT mà người dùng đã thấy app lúc đó và chưa được báo ([seenTs] = mốc đã xử lý lần trước), hoặc null.
     */
    fun pickUnseen(exits: List<ExitRecord>, seenTs: Long): ExitRecord? =
        exits.filter { it.timestampMs > seenTs && isAbnormal(it.reason) && wasVisible(it.importance) }.maxByOrNull { it.timestampMs }

    fun latestTs(exits: List<ExitRecord>): Long = exits.maxOfOrNull { it.timestampMs } ?: 0L

    // ------------------------------------------------------------------ ghép báo cáo
    class Section(val title: String, val lines: List<String>, val elastic: Boolean = false)

    /** Toàn bộ dữ kiện cho một báo cáo; VM chỉ việc thu thập, mọi định dạng/ẩn dữ liệu nằm ở [compose]. */
    class Input(
        val appVersion: String,
        val device: List<Pair<String, String>>,
        val perf: String,
        val modelsReady: List<String>,
        val modelsMissing: List<String>,
        val modelFiles: List<Pair<String, Long>>,
        val settings: List<Pair<String, String>>,
        val doc: List<Pair<String, String>>,
        val status: String,
        val recentPrompts: List<String>,
        val log: List<String>,
        val crash: String?,
        val exits: List<ExitRecord>
    )

    fun compose(input: Input, nowMs: Long = System.currentTimeMillis()): String {
        val sections = ArrayList<Section>()
        sections += Section("Ứng dụng", listOf("phiên bản: ${input.appVersion}", "thời điểm lập báo cáo (UTC): ${Instant.ofEpochMilli(nowMs)}"))
        sections += Section("Máy", input.device.map { "${it.first}: ${it.second}" } + listOf("hạng hiệu năng: ${input.perf}"))
        sections += Section(
            "Model",
            listOf("đã nạp: " + input.modelsReady.ifEmpty { listOf("(không có)") }.joinToString(", "),
                "chưa nạp: " + input.modelsMissing.ifEmpty { listOf("(không có)") }.joinToString(", ")) +
                input.modelFiles.map { "tệp ${it.first}: ${mb(it.second)}" }
        )
        sections += Section("Cài đặt (không kèm khóa/token)", input.settings.map { "${it.first}: ${it.second}" })
        sections += Section("Ảnh và lớp", input.doc.map { "${it.first}: ${it.second}" })
        sections += Section("Trạng thái cuối", listOf(input.status.ifBlank { "(trống)" }) + input.recentPrompts.map { "lời nhắc gần đây: ${it.take(160)}" })
        if (input.crash != null) sections += Section("Lỗi làm app đóng ở lần chạy trước", input.crash.lines().take(120))
        if (input.exits.isNotEmpty()) sections += Section("Lần app bị hệ thống kết thúc (gần nhất trước)", input.exits.sortedByDescending { it.timestampMs }.map { describeExit(it) })
        sections += Section("Nhật ký gần nhất (cũ → mới)", input.log, elastic = true)
        return render("AI Photo Studio - thông tin lỗi (tester)", sections)
    }

    /** Thêm ghi chú của tester lên đầu báo cáo (đã ẩn dữ liệu nhạy cảm, cắt gọn). */
    fun withNote(note: String, report: String): String {
        val n = scrub(note.trim()).take(NOTE_MAX)
        return if (n.isEmpty()) report else "Ghi chú của tester: $n\n\n$report"
    }

    private class Work(val title: String, val lines: MutableList<String>, val elastic: Boolean)

    private fun render(header: String, sections: List<Section>, maxChars: Int = MAX_CHARS): String {
        val work = sections.map { s -> Work(s.title, s.lines.flatMap { scrub(it).lines() }.toMutableList(), s.elastic) }
        fun size(): Int = header.length + work.sumOf { w -> w.title.length + 8 + w.lines.sumOf { it.length + 1 } }
        while (size() > maxChars) {
            val big = work.filter { it.elastic && it.lines.size > 20 }.maxByOrNull { it.lines.size } ?: break
            big.lines.removeAt(0)   // bỏ dòng cũ nhất, giữ phần cuối là phần quan trọng nhất
        }
        val sb = StringBuilder(header).append('\n')
        for (w in work) {
            sb.append("\n== ").append(w.title).append(" ==\n")
            for (l in w.lines) sb.append(l).append('\n')
        }
        val out = sb.toString().trimEnd()
        return if (out.length > maxChars) out.substring(0, maxChars - 20) + "\n…(đã cắt bớt)" else out
    }

    private fun mb(bytes: Long): String = if (bytes < 1024 * 1024) "${bytes / 1024} KB" else String.format(Locale.ROOT, "%.1f MB", bytes / 1048576.0)
}

/** Lưu lỗi làm app đóng đột ngột (một tệp trong thư mục riêng của app) để lần mở sau hiện hộp thoại báo lại. */
class CrashStore(private val dir: File) {
    companion object {
        /** Vị trí chuẩn trong bộ nhớ riêng của app; MainActivity (cài móc) và MainViewModel (đọc lại) phải dùng chung. */
        fun at(filesDir: File): CrashStore = CrashStore(File(filesDir, "diag"))
    }

    private val file get() = File(dir, "last_crash.txt")
    private val shown get() = File(dir, "last_crash.shown")

    fun save(thread: String, t: Throwable, nowMs: Long = System.currentTimeMillis(), log: List<String> = DiagLog.snapshot(40)) {
        try {
            dir.mkdirs()
            val sb = StringBuilder()
            sb.append("thời điểm (UTC): ").append(Instant.ofEpochMilli(nowMs)).append('\n')
            sb.append("luồng: ").append(thread).append('\n').append('\n')
            sb.append(DiagReport.formatThrowable(t)).append('\n')
            if (log.isNotEmpty()) {
                sb.append("\n-- nhật ký ngay trước lỗi --\n")
                for (l in log) sb.append(l).append('\n')
            }
            val tmp = File(dir, "last_crash.tmp")
            tmp.writeText(sb.toString())
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
            shown.delete()
        } catch (_: Throwable) {
            // hết bộ nhớ / hết dung lượng: không được làm lỗi nặng thêm
        }
    }

    /** Nội dung lỗi đã lưu (luôn trả về nếu còn tệp), cắt ≤ 20 000 ký tự. */
    fun peek(): String? = runCatching { if (file.isFile) file.readText().take(20_000) else null }.getOrNull()

    /** Lỗi chưa từng được hiện cho người dùng ở lần mở app. */
    fun pendingUnseen(): String? = if (shown.exists()) null else peek()

    fun markShown() {
        runCatching { if (file.isFile) { dir.mkdirs(); shown.writeText("1") } }
    }

    fun clear() {
        runCatching { file.delete() }
        runCatching { shown.delete() }
    }
}

/** Móc bắt ngoại lệ không ai bắt: ghi vào [CrashStore] rồi giao tiếp cho bộ xử lý cũ của hệ thống (app vẫn đóng như bình thường). */
object CrashHandler {
    class Hook(val store: CrashStore, val previous: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                store.save(t.name, e)
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    /** Cài một lần (gọi lại không cài chồng). Trả về hàm gỡ, khôi phục bộ xử lý trước đó. */
    fun install(store: CrashStore): () -> Unit {
        val cur = Thread.getDefaultUncaughtExceptionHandler()
        if (cur is Hook) return {}
        val hook = Hook(store, cur)
        Thread.setDefaultUncaughtExceptionHandler(hook)
        return { if (Thread.getDefaultUncaughtExceptionHandler() === hook) Thread.setDefaultUncaughtExceptionHandler(cur) }
    }
}
