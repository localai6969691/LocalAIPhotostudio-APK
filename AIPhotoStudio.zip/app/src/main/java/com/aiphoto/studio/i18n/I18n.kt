package com.aiphoto.studio.i18n

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.util.Locale

/**
 * Ngôn ngữ giao diện (R33). Mã nguồn viết bằng tiếng Việt; [tr] tra chuỗi sắp hiển thị trong gói dịch `assets/i18n/<mã>.json` của ngôn ngữ đang chọn,
 * thiếu thì rơi về gói TIẾNG ANH (người dùng nước ngoài hiểu được nhiều hơn tiếng Việt), thiếu nữa thì giữ nguyên chuỗi tiếng Việt.
 * `Text(...)` của dự án đã được bọc (i18n/Text.kt) để gọi [tr] — không phải sửa từng chuỗi.
 *
 * Trạng thái [active] là state của Compose: đổi ngôn ngữ làm mọi `Text` tự vẽ lại ngay, không cần khởi động lại app.
 */
object I18n {
    private const val PREFS = "i18n"
    private const val KEY_LANG = "language"
    private const val KEY_WELCOME = "welcome_done"

    /** Lựa chọn của người dùng: [AppLanguages.AUTO] (theo hệ thống) hoặc một mã. */
    var preference by mutableStateOf(AppLanguages.AUTO)
        private set

    /** Mã ngôn ngữ ĐANG DÙNG (đã giải quyết "tự động"). */
    var active by mutableStateOf(AppLanguages.SOURCE)
        private set

    @Volatile private var primary: Translator? = null
    @Volatile private var english: Translator? = null
    @Volatile private var coverage: Map<String, Int> = emptyMap()
    @Volatile private var totalKeys = 0

    val isRtl: Boolean get() = AppLanguages.byCode(active)?.rtl == true

    /** Gọi MỘT LẦN khi mở app (trước setContent). */
    fun init(context: Context) {
        val app = context.applicationContext
        loadIndex(app)
        preference = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANG, AppLanguages.AUTO) ?: AppLanguages.AUTO
        apply(app)
    }

    /** Đổi ngôn ngữ ([pref] = [AppLanguages.AUTO] hoặc một mã) và nhớ lại cho lần mở sau. */
    fun setLanguage(context: Context, pref: String) {
        val app = context.applicationContext
        val p = if (pref == AppLanguages.AUTO || AppLanguages.byCode(pref) != null) pref else AppLanguages.AUTO
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANG, p).apply()
        preference = p
        apply(app)
    }

    private fun apply(app: Context) {
        val code = AppLanguages.resolve(preference, Locale.getDefault().language)
        primary = if (code == AppLanguages.SOURCE) null else loadPack(app, code)
        english = if (code == AppLanguages.SOURCE || code == "en") null else loadPack(app, "en")
        active = code // đặt SAU CÙNG: các Text đang theo dõi state này sẽ thấy gói mới
    }

    /** Dịch [s] theo ngôn ngữ đang dùng. Gọi trong composable thì tự theo dõi [active]. */
    fun tr(s: String): String {
        if (active == AppLanguages.SOURCE) return s
        return primary?.lookup(s) ?: english?.lookup(s) ?: s
    }

    /** Phần trăm khóa giao diện đã có bản dịch của [code] (tiếng Việt = 100). */
    fun coveragePercent(code: String): Int {
        if (code == AppLanguages.SOURCE) return 100
        val n = coverage[code] ?: return 0
        return if (totalKeys <= 0) 0 else (n * 100 / totalKeys).coerceIn(0, 100)
    }

    /** Mã ngôn ngữ cho nội dung Trợ giúp: ngôn ngữ đang dùng nếu có tệp, không thì "en", không thì "vi". */
    fun helpSections(context: Context): List<HelpSection> {
        val app = context.applicationContext
        for (c in listOf(active, "en", AppLanguages.SOURCE).distinct()) {
            val parsed = runCatching {
                app.assets.open("help/$c.json").bufferedReader(Charsets.UTF_8).use { HelpContent.parse(it.readText()) }
            }.getOrNull()
            if (parsed != null && parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    fun welcomeDone(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_WELCOME, false)

    fun markWelcomeDone(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_WELCOME, true).apply()
    }

    private fun loadPack(app: Context, code: String): Translator? = runCatching {
        val o = JSONObject(app.assets.open("i18n/$code.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
        val m = HashMap<String, String>(o.length() * 2)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            m[k] = o.getString(k)
        }
        Translator(m)
    }.getOrNull()

    private fun loadIndex(app: Context) {
        runCatching {
            val o = JSONObject(app.assets.open("i18n/index.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
            totalKeys = o.getInt("keys")
            val packs = o.getJSONObject("packs")
            val m = HashMap<String, Int>()
            val ks = packs.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                m[k] = packs.getInt(k)
            }
            coverage = m
        }
    }
}
