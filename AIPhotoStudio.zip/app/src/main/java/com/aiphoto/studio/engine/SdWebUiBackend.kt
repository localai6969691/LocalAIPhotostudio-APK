package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * THÊM / THAY vật thể bằng Stable Diffusion inpainting, gọi tới máy chủ do bạn tự chạy
 * (AUTOMATIC1111 WebUI / Forge / SD.Next khởi động với --api --listen) - ví dụ PC trong cùng mạng Wi-Fi.
 * Ảnh chỉ được gửi tới địa chỉ bạn cấu hình, không đi đâu khác.
 *
 * Dùng chế độ "only masked" (inpaint_full_res): server tự cắt vùng quanh mặt nạ, xử lý ở [size]x[size]
 * rồi dán lại vào ảnh gốc nên giữ nguyên độ phân giải.
 */
class SdWebUiBackend(baseUrl: String) : GenerativeFill {

    private val base = baseUrl.trim().trimEnd('/')
    @Volatile private var conn: HttpURLConnection? = null

    override fun cancel() {
        try { conn?.disconnect() } catch (e: Throwable) { }
    }

    fun ping(): String {
        val text = request("GET", "/sdapi/v1/sd-models", null, readTimeoutMs = 10_000)
        val n = JSONArray(text).length()
        return "Kết nối OK - máy chủ có $n checkpoint. Nên chọn model *inpainting* để kết quả tốt nhất."
    }

    override fun inpaint(image: Bitmap, mask: ByteArray, prompt: String, size: Int, opts: GenOptions): Bitmap =
        inpaint(
            image, mask, prompt, size, opts.strength ?: 0.85f, if (opts.quality == GenQuality.HIGH) 35 else 25,
            opts.seed, opts.negative.ifBlank { "blurry, low quality, deformed, extra limbs, watermark, text" }
        )

    fun inpaint(
        image: Bitmap, mask: ByteArray, prompt: String, size: Int, denoise: Float, steps: Int,
        seed: Long = -1L, negative: String = "blurry, low quality, deformed, extra limbs, watermark, text"
    ): Bitmap {
        val w = image.width
        val h = image.height

        val imgBytes = ByteArrayOutputStream().also { image.compress(Bitmap.CompressFormat.JPEG, 92, it) }.toByteArray()
        val maskPx = IntArray(w * h) { if (mask[it].toInt() != 0) -1 else (255 shl 24) }
        val maskBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        maskBmp.setPixels(maskPx, 0, w, 0, 0, w, h)
        val maskBytes = ByteArrayOutputStream().also { maskBmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()

        val body = JSONObject().apply {
            put("init_images", JSONArray().put(Base64.encodeToString(imgBytes, Base64.NO_WRAP)))
            put("mask", Base64.encodeToString(maskBytes, Base64.NO_WRAP))
            put("prompt", prompt)
            put("negative_prompt", negative)
            put("denoising_strength", denoise.toDouble())
            put("inpainting_fill", 1)               // 1 = original
            put("inpaint_full_res", true)           // only masked
            put("inpaint_full_res_padding", 48)
            put("inpainting_mask_invert", 0)
            put("mask_blur", 6)
            put("resize_mode", 0)
            put("steps", steps)
            put("cfg_scale", 7)
            put("width", size)
            put("height", size)
            put("seed", seed)
            put("batch_size", 1)
            put("n_iter", 1)
        }

        val text = request("POST", "/sdapi/v1/img2img", body.toString(), readTimeoutMs = 600_000)
        val images = JSONObject(text).optJSONArray("images")
        if (images == null || images.length() == 0) throw IOException("Máy chủ không trả về ảnh nào")
        var b64 = images.getString(0)
        val comma = b64.indexOf(',')
        if (comma in 0..64) b64 = b64.substring(comma + 1)
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val result = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IOException("Không giải mã được ảnh từ máy chủ")
        return if (result.width == w && result.height == h) result
        else Bitmap.createScaledBitmap(result, w, h, true)
    }

    private fun request(method: String, path: String, json: String?, readTimeoutMs: Int): String {
        val c = URL(base + path).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = readTimeoutMs
            if (json != null) {
                val data = json.toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setFixedLengthStreamingMode(data.size)
                c.outputStream.use { it.write(data) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val hint = if (code == 404) " (hãy chạy WebUI với tham số --api)" else ""
                throw IOException("Máy chủ trả mã $code$hint: ${text.take(200)}")
            }
            return text
        } finally {
            c.disconnect()
            if (conn === c) conn = null
        }
    }
}
