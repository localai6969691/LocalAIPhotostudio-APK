package com.aiphoto.studio.engine

import java.io.File
import java.security.MessageDigest
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * R46 - mục tiêu của tính năng PHÓNG TO (Upscale): hệ số cố định ×2 / ×3 / ×4, hoặc "đạt cạnh dài" Full HD / 2K / 4K như các app khác.
 * [factor] > 0 là hệ số cố định; ngược lại [longSide] là cạnh dài (điểm ảnh) cần đạt.
 */
enum class UpscaleTarget(val label: String, val factor: Int, val longSide: Int) {
    X2("×2", 2, 0),
    X3("×3", 3, 0),
    X4("×4", 4, 0),
    FHD("Full HD", 0, 1920),
    QHD("2K", 0, 2560),
    UHD("4K", 0, 3840)
}

/**
 * R46 - kế hoạch phóng một ảnh [srcW]×[srcH]: hệ số xin ([wantFactor], nguyên 2..4), hệ số THỰC TẾ sau khi bị giới hạn ([factor], theo bộ nhớ và trần cạnh dài),
 * và kích thước ra. [needed] = false khi ảnh đã đạt cạnh dài mục tiêu (không cần phóng).
 */
data class UpscalePlan(
    val srcW: Int,
    val srcH: Int,
    val wantFactor: Int,
    val factor: Float,
    val outW: Int,
    val outH: Int,
    val needed: Boolean,
    val limited: Boolean
) {
    val megapixels: Double get() = outW.toDouble() * outH / 1_000_000.0

    /** Có đáng chạy không: cần phóng và hệ số thực tế đủ lớn (dưới ×1,25 thì `OnnxUpscaler` trả nguyên ảnh). */
    val canRun: Boolean get() = needed && factor >= Upscale.MIN_FACTOR
}

object Upscale {
    /** Dưới hệ số này `OnnxUpscaler.upscale` trả nguyên ảnh, nên không coi là phóng được. */
    const val MIN_FACTOR = 1.25f

    /** Viền chồng của mỗi ô (điểm ảnh) — khớp `OnnxUpscaler`. */
    const val TILE_PAD = 10

    /** Hệ số gốc của model Real-ESRGAN-General-x4v3. */
    const val MODEL_SCALE = 4

    /** Kích thước ô đầu vào của model (điểm ảnh). */
    const val DEFAULT_TILE = 128

    /** Hệ số nguyên (2..4) cần xin để đạt [t]; 0 = không cần phóng (ảnh đã đạt cạnh dài mục tiêu) hoặc kích thước không hợp lệ. */
    fun wantFactor(t: UpscaleTarget, w: Int, h: Int): Int {
        if (w <= 0 || h <= 0) return 0
        if (t.factor > 0) return t.factor
        val long = max(w, h)
        if (long >= t.longSide) return 0
        return ceil(t.longSide.toDouble() / long).toInt().coerceIn(2, 4)
    }

    /** Lập kế hoạch; [maxSide] = cạnh dài tối đa cho phép (`ImageEngine.upscaleMaxSide` theo heap còn trống). */
    fun plan(t: UpscaleTarget, w: Int, h: Int, maxSide: Int): UpscalePlan {
        val want = wantFactor(t, w, h)
        if (want == 0) return UpscalePlan(w, h, 0, 1f, w, h, needed = false, limited = false)
        val f = ImageEngine.upscaleFactor(w, h, want.toFloat(), maxSide)
        val limited = f < want - 0.01f
        return UpscalePlan(w, h, want, f, (w * f).roundToInt(), (h * f).roundToInt(), needed = true, limited = limited)
    }

    /** Số ô model phải chạy để phóng ảnh [srcW]×[srcH] theo [factor] — đúng cách `OnnxUpscaler` chia ô (ảnh vào = ảnh đích / [scale]). */
    fun tileCount(srcW: Int, srcH: Int, factor: Float, tile: Int = DEFAULT_TILE, pad: Int = TILE_PAD, scale: Int = MODEL_SCALE): Int {
        if (srcW <= 0 || srcH <= 0 || factor < MIN_FACTOR) return 0
        val inW = max(8, (srcW * factor / scale).roundToInt())
        val inH = max(8, (srcH * factor / scale).roundToInt())
        val core = max(1, tile - 2 * pad)
        return ceil(inW.toDouble() / core).toInt() * ceil(inH.toDouble() / core).toInt()
    }

    /** Số giây còn lại ước theo tốc độ trung bình đến giờ; -1 = chưa đủ dữ liệu (chưa xong ô nào). */
    fun etaSeconds(done: Int, total: Int, elapsedMs: Long): Int {
        if (total <= 0 || done >= total) return if (total > 0) 0 else -1
        if (done <= 0 || elapsedMs <= 0) return -1
        return (elapsedMs.toDouble() / done * (total - done) / 1000.0).roundToInt()
    }
}

/** R46 - model đi kèm trong assets của app (không cần tải). */
object BuiltInModels {
    const val ASSET_DIR = "models"
    const val ESRGAN_ASSET = "realesr-general-x4v3.onnx"
    const val ESRGAN_BYTES = 4_859_831L

    /** SHA-256 của tệp trong assets (dựng bằng tools/export_realesrgan_onnx.py từ trọng số chính thức v0.2.5.0, SHA-256 8dc7edb9…96292). */
    const val ESRGAN_SHA256 = "873417e1800a331e95fd6f53ec7662a86cd4c659793c542965f283ccad7a13c0"

    /** Giấy phép BSD-3 của Real-ESRGAN (phải đi kèm khi phát hành nhị phân). */
    const val ESRGAN_LICENSE_ASSET = "licenses/Real-ESRGAN-BSD-3-Clause.txt"

    fun sha256Hex(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
