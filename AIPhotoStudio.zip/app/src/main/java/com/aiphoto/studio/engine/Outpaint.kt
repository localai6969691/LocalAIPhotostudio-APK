package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mở rộng ảnh (outpainting, PDF mục "Mở rộng ảnh"): nới khung ảnh ra rồi để engine lấp phần mới sao cho nối liền cảnh.
 *
 * Phần này là LÕI THUẦN MẢNG (không Android) gồm: đọc/chuẩn hóa yêu cầu, tính khung mới, dựng khung có phần trống,
 * và ghép kết quả. Engine lấp CẢ phần mới trong một lần (đo thực tế tốt hơn lấp tuần tự từng dải: các góc và mép nhìn thấy nhau).
 * Việc CHỌN engine lấp (đám mây / SD cục bộ / LaMa / MI-GAN / PatchMatch) do MainViewModel + cấu hình định tuyến quyết định.
 *
 * Chuỗi yêu cầu (arg của EditOp OUTPAINT), đối số cách nhau bằng dấu phẩy:
 *   "l=0.2,r=0.2,t=0,b=0"        thêm 20% chiều rộng mỗi bên trái/phải (t,b tính theo chiều cao)
 *   "ratio=1.7778"               mở tối thiểu để đạt tỉ lệ rộng/cao; mặc định chia đều hai phía
 *   "ratio=1.7778,a=r"           như trên nhưng chỉ mở về phía phải (a = l | r | t | b | c)
 */
object Outpaint {

    /** Mỗi phía tối đa thêm 100% kích thước (ảnh lớn nhất = gấp 3 mỗi chiều) — chặn tiêu tốn RAM do yêu cầu quá đà. */
    const val MAX_PER_SIDE = 1f
    const val MIN_RATIO = 0.2f
    const val MAX_RATIO = 5f

    /** Phần thêm của từng phía, theo tỉ lệ của chiều tương ứng (trái/phải theo rộng, trên/dưới theo cao). */
    data class Spec(val left: Float, val right: Float, val top: Float, val bottom: Float) {
        val isEmpty: Boolean get() = left <= 0f && right <= 0f && top <= 0f && bottom <= 0f
    }

    private class Parsed(val spec: Spec?, val ratio: Float?, val anchor: Char)

    private fun parse(arg: String?): Parsed? {
        if (arg.isNullOrBlank()) return null
        val kv = HashMap<String, String>()
        for (part in arg.split(',')) {
            val i = part.indexOf('=')
            if (i <= 0) continue
            kv[part.substring(0, i).trim().lowercase(Locale.ROOT)] = part.substring(i + 1).trim()
        }
        fun side(k: String): Float = (kv[k]?.toFloatOrNull() ?: 0f).let { if (it.isNaN()) 0f else it.coerceIn(0f, MAX_PER_SIDE) }
        val ratio = kv["ratio"]?.toFloatOrNull()
        val anchor = kv["a"]?.lowercase(Locale.ROOT)?.firstOrNull()?.takeIf { it in "lrtbc" } ?: 'c'
        if (ratio != null) {
            if (ratio.isNaN() || ratio < MIN_RATIO || ratio > MAX_RATIO) return null
            return Parsed(null, ratio, anchor)
        }
        val spec = Spec(side("l"), side("r"), side("t"), side("b"))
        return if (spec.isEmpty) null else Parsed(spec, null, anchor)
    }

    /** Chuẩn hóa chuỗi yêu cầu (dùng khi lọc kế hoạch do LLM trả về). Null nếu không hợp lệ / không mở gì cả. */
    fun canonical(arg: String?): String? {
        val p = parse(arg) ?: return null
        return if (p.ratio != null) {
            String.format(Locale.US, "ratio=%.4f,a=%c", p.ratio, p.anchor)
        } else {
            val s = p.spec!!
            String.format(Locale.US, "l=%.3f,r=%.3f,t=%.3f,b=%.3f", s.left, s.right, s.top, s.bottom)
        }
    }

    fun format(spec: Spec): String = String.format(Locale.US, "l=%.3f,r=%.3f,t=%.3f,b=%.3f", spec.left, spec.right, spec.top, spec.bottom)

    /** Mô tả ngắn cho người dùng, ví dụ "trái 20%, phải 20%" hoặc "tỉ lệ 1.78 (về phía phải)". */
    fun describe(arg: String?): String {
        val p = parse(arg) ?: return "?"
        if (p.ratio != null) {
            val side = when (p.anchor) { 'l' -> " (về phía trái)"; 'r' -> " (về phía phải)"; 't' -> " (lên trên)"; 'b' -> " (xuống dưới)"; else -> "" }
            return "tỉ lệ ${String.format(Locale.US, "%.2f", p.ratio)}$side"
        }
        val s = p.spec!!
        return listOf("trái" to s.left, "phải" to s.right, "trên" to s.top, "dưới" to s.bottom)
            .filter { it.second > 0f }.joinToString(", ") { "${it.first} ${(it.second * 100).roundToInt()}%" }
    }

    /** Quy yêu cầu về phần thêm cho từng phía với ảnh [w]×[h]. Null nếu không có gì để mở (đã đúng tỉ lệ / yêu cầu rỗng). */
    fun resolve(arg: String?, w: Int, h: Int): Spec? {
        val p = parse(arg) ?: return null
        if (p.spec != null) return p.spec
        val target = p.ratio!!
        val cur = w.toFloat() / h
        if (abs(target - cur) / cur < 0.005f) return null
        return if (target > cur) {
            val extra = ((target * h - w) / w).coerceAtMost(2f * MAX_PER_SIDE)
            when (p.anchor) {
                'l' -> Spec(min(extra, MAX_PER_SIDE), 0f, 0f, 0f)
                'r' -> Spec(0f, min(extra, MAX_PER_SIDE), 0f, 0f)
                else -> Spec(extra / 2, extra / 2, 0f, 0f)
            }
        } else {
            val extra = ((w / target - h) / h).coerceAtMost(2f * MAX_PER_SIDE)
            when (p.anchor) {
                't' -> Spec(0f, 0f, min(extra, MAX_PER_SIDE), 0f)
                'b' -> Spec(0f, 0f, 0f, min(extra, MAX_PER_SIDE))
                else -> Spec(0f, 0f, extra / 2, extra / 2)
            }
        }
    }

    /**
     * Khung mới: ảnh gốc đặt ở ([offX],[offY]) với kích thước [drawW]×[drawH] (nhỏ hơn gốc nếu cả khung vượt [maxSide]:
     * khi đó cả ảnh được thu nhỏ đều để kết quả vẫn ≤ maxSide, giống giới hạn chung của app).
     */
    data class Plan(val newW: Int, val newH: Int, val offX: Int, val offY: Int, val drawW: Int, val drawH: Int)

    fun plan(w: Int, h: Int, spec: Spec, maxSide: Int): Plan? {
        val aL = (spec.left * w).roundToInt()
        val aR = (spec.right * w).roundToInt()
        val aT = (spec.top * h).roundToInt()
        val aB = (spec.bottom * h).roundToInt()
        if (aL + aR + aT + aB <= 0) return null
        val fullW = w + aL + aR
        val fullH = h + aT + aB
        val s = min(1f, maxSide.toFloat() / max(fullW, fullH))
        if (s >= 1f) return Plan(fullW, fullH, aL, aT, w, h)
        val dw = max(1, (w * s).roundToInt())
        val dh = max(1, (h * s).roundToInt())
        val l = (aL * s).roundToInt()
        val t = (aT * s).roundToInt()
        val r = (aR * s).roundToInt()
        val b = (aB * s).roundToInt()
        return Plan(l + dw + r, t + dh + b, l, t, dw, dh)
    }

    /** Khung đã dựng: [px] có ảnh gốc ở giữa + phần mới được điền tạm (phản chiếu); [mask] != 0 tại phần mới. */
    class Canvas(val px: IntArray, val w: Int, val h: Int, val mask: ByteArray, val ox: Int, val oy: Int, val dw: Int, val dh: Int)

    /** Thu nhỏ trung bình theo diện tích (dùng khi khung mới vượt giới hạn). */
    private fun resizeArea(px: IntArray, w: Int, h: Int, nw: Int, nh: Int): IntArray {
        if (nw == w && nh == h) return px
        val out = IntArray(nw * nh)
        for (y in 0 until nh) {
            val y0 = (y.toLong() * h / nh).toInt()
            val y1 = max(y0 + 1, ((y + 1).toLong() * h / nh).toInt())
            for (x in 0 until nw) {
                val x0 = (x.toLong() * w / nw).toInt()
                val x1 = max(x0 + 1, ((x + 1).toLong() * w / nw).toInt())
                var a = 0; var r = 0; var g = 0; var b = 0; var n = 0
                for (yy in y0 until min(y1, h)) for (xx in x0 until min(x1, w)) {
                    val p = px[yy * w + xx]
                    a += p ushr 24; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
                }
                out[y * nw + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        return out
    }

    private fun reflect(v: Int, n: Int): Int {
        if (n <= 1) return 0
        val period = 2 * n
        val m = ((v % period) + period) % period
        return if (m < n) m else period - 1 - m
    }

    /**
     * Dựng khung mới. Phần mới được điền tạm bằng ảnh phản chiếu (giữ nguyên hạt/kết cấu gần mép); nếu [blurPrefill] thì làm
     * mờ nhẹ phần này — hợp để gửi cho dịch vụ sinh ảnh (bố cục màu hợp lý, không lặp chi tiết); engine cục bộ dùng bản không mờ.
     */
    fun makeCanvas(px: IntArray, w: Int, h: Int, plan: Plan, blurPrefill: Boolean): Canvas {
        val src = resizeArea(px, w, h, plan.drawW, plan.drawH)
        val nw = plan.newW
        val nh = plan.newH
        val out = IntArray(nw * nh)
        val mask = ByteArray(nw * nh)
        for (y in 0 until nh) {
            val inY = y >= plan.offY && y < plan.offY + plan.drawH
            val sy = reflect(y - plan.offY, plan.drawH)
            for (x in 0 until nw) {
                val i = y * nw + x
                if (inY && x >= plan.offX && x < plan.offX + plan.drawW) {
                    out[i] = src[(y - plan.offY) * plan.drawW + (x - plan.offX)]
                } else {
                    out[i] = src[sy * plan.drawW + reflect(x - plan.offX, plan.drawW)]
                    mask[i] = 255.toByte()
                }
            }
        }
        if (blurPrefill) {
            val blurred = Blur.gaussian(out, nw, nh, max(3, max(nw, nh) / 150))
            for (i in out.indices) if (mask[i].toInt() != 0) out[i] = (out[i] and (0xFF shl 24)) or (blurred[i] and 0xFFFFFF)
        }
        return Canvas(out, nw, nh, mask, plan.offX, plan.offY, plan.drawW, plan.drawH)
    }

    /**
     * Ghép kết quả của dịch vụ sinh ảnh (có thể đã chỉnh nhẹ cả phần ảnh gốc): phần mới lấy từ [filled], phần ảnh gốc giữ
     * NGUYÊN VẸN trừ một dải [band] điểm sát mép mới, nơi hai bản được hòa dần để không lộ đường nối.
     */
    fun composite(original: IntArray, filled: IntArray, mask: ByteArray, w: Int, h: Int, band: Int): IntArray {
        val hole = BooleanArray(w * h) { mask[it].toInt() != 0 }
        val d = if (band > 0) DistanceField.chamfer(hole, w, h) else null
        val out = original.copyOf()
        for (i in 0 until w * h) {
            if (hole[i]) { out[i] = filled[i]; continue }
            val dist = d?.get(i) ?: continue
            if (dist > band) continue
            val a = 1f - (dist - 1f).coerceAtLeast(0f) / band          // 1 sát mép mới → 0 ở cuối dải
            if (a <= 0f) continue
            val o = original[i]
            val f = filled[i]
            val r = (((o shr 16) and 255) * (1f - a) + ((f shr 16) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
            val g = (((o shr 8) and 255) * (1f - a) + ((f shr 8) and 255) * a + 0.5f).toInt().coerceIn(0, 255)
            val b = ((o and 255) * (1f - a) + (f and 255) * a + 0.5f).toInt().coerceIn(0, 255)
            out[i] = (o and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
        return out
    }
}
