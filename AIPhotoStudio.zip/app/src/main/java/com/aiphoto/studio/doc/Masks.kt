package com.aiphoto.studio.doc

import android.graphics.Bitmap
import com.aiphoto.studio.engine.Blur
import com.aiphoto.studio.engine.EdgeOps
import com.aiphoto.studio.engine.MaskMath
import com.aiphoto.studio.engine.PolygonFill
import com.aiphoto.studio.engine.Pt
import com.aiphoto.studio.engine.SkyFx
import com.aiphoto.studio.engine.readPixels
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Cách sinh mặt nạ. Mặt nạ "tham số" (Luminance/ColorRange/Radial/Linear) tính lại theo ảnh bên dưới -> không phá hủy. */
sealed interface MaskSpec {
    /** Mặt nạ tô tay / chủ thể AI: dữ liệu 0..255 ở độ phân giải gốc (w×h). */
    class Painted(val data: ByteArray, val w: Int, val h: Int) : MaskSpec
    /** Dải độ sáng lo..hi (0..1). */
    data class Luminance(val lo: Float, val hi: Float) : MaskSpec
    /** Dải màu: hue (độ 0..360), dung sai (độ), độ bão hòa tối thiểu (0..1). */
    data class ColorRange(val hue: Float, val tolerance: Float, val satMin: Float) : MaskSpec
    /** Vùng tròn: tâm (0..1), bán kính theo cạnh ngắn. Bên trong = 1. */
    data class Radial(val cx: Float, val cy: Float, val radius: Float) : MaskSpec
    /** Gradient tuyến tính: góc hướng (độ; 90 = từ trên xuống dưới), vị trí chuyển (0..1). */
    data class Linear(val angleDeg: Float, val pos: Float) : MaskSpec
    /** Mặt nạ theo KÊNH màu: space 0=RGB (R,G,B), 1=HSV (H,S,V), 2=Lab (L,a,b); channel 0..2; dải lo..hi chuẩn hóa 0..1. */
    data class Channel(val space: Int, val channel: Int, val lo: Float, val hi: Float) : MaskSpec
    /** Focus Area: vùng NÉT (độ tương phản cục bộ cao) lo..hi trên thang 0..1. */
    data class Focus(val lo: Float, val hi: Float) : MaskSpec
    /** Select Sky: vùng trời nối với mép trên ảnh (không cần model), độ nhạy 0..1. Không thấy trời → dự phòng theo dải màu xanh. */
    data class Sky(val sensitivity: Float) : MaskSpec
    /** Mặt nạ VECTOR (lasso): đa giác theo thang 0..1 — nhẹ, độc lập độ phân giải, lưu được trong công thức. */
    data class Polygon(val pts: List<Pt>) : MaskSpec
}

/** [shift] = dịch biên (Refine Edge): -1..1, > 0 nở ra, < 0 co vào (±1 ≈ ±2% cạnh dài ảnh). */
data class LayerMask(val spec: MaskSpec, val invert: Boolean = false, val feather: Float = 0.02f, val shift: Float = 0f)

object MaskRenderer {

    // Bộ nhớ đệm mặt nạ đã dựng (chỉ dùng cho xem trước): mặt nạ tô tay/tham số không đổi khi kéo thanh trượt lớp khác.
    private data class CacheKey(val mask: LayerMask, val w: Int, val h: Int, val refId: Int)
    private val cache = LinkedHashMap<CacheKey, FloatArray>()

    @Synchronized
    private fun cacheGet(k: CacheKey): FloatArray? = cache[k]

    @Synchronized
    private fun cachePut(k: CacheKey, v: FloatArray) {
        cache[k] = v
        while (cache.size > 6) cache.remove(cache.keys.first())
    }

    @Synchronized
    fun clearCache() {
        cache.clear()
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Mặt nạ theo dải màu (HSV): [hue] độ 0..360, [tolerance] độ, [satMin] bão hòa tối thiểu. */
    private fun colorRangeMask(px: IntArray, hue: Float, tolerance: Float, satMin: Float): FloatArray {
        val out = FloatArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val r = ((p shr 16) and 255) / 255f
            val g = ((p shr 8) and 255) / 255f
            val b = (p and 255) / 255f
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val d = mx - mn
            if (d < 0.01f || mx <= 0f) continue
            val hh = when {
                mx == r -> { val t = (g - b) / d; 60f * (if (t < 0f) t + 6f else t) }
                mx == g -> 60f * ((b - r) / d + 2f)
                else -> 60f * ((r - g) / d + 4f)
            }
            val sat = d / mx
            var dh = abs(hh - hue)
            if (dh > 180f) dh = 360f - dh
            out[i] = (1f - smooth(tolerance * 0.5f, tolerance, dh)) * smooth(satMin * 0.5f, max(satMin, 0.01f), sat)
        }
        return out
    }

    /** Tạo mặt nạ 0..1 có kích thước bằng [ref] (ảnh nằm bên dưới lớp). */
    fun render(m: LayerMask, ref: Bitmap, useCache: Boolean = false): FloatArray {
        val refDependent = m.spec is MaskSpec.Luminance || m.spec is MaskSpec.ColorRange || m.spec is MaskSpec.Channel ||
            m.spec is MaskSpec.Focus || m.spec is MaskSpec.Sky
        val key = CacheKey(m, ref.width, ref.height, if (refDependent) System.identityHashCode(ref) else 0)
        if (useCache) cacheGet(key)?.let { return it }
        val result = build(m, ref)
        if (useCache) cachePut(key, result)
        return result
    }

    private fun build(m: LayerMask, ref: Bitmap): FloatArray {
        val w = ref.width
        val h = ref.height
        var out = FloatArray(w * h)
        when (val s = m.spec) {
            is MaskSpec.Painted -> {
                for (y in 0 until h) {
                    val sy = min(s.h - 1, y * s.h / h)
                    for (x in 0 until w) {
                        val sx = min(s.w - 1, x * s.w / w)
                        out[y * w + x] = (s.data[sy * s.w + sx].toInt() and 255) / 255f
                    }
                }
            }
            is MaskSpec.Luminance -> {
                val px = readPixels(ref)
                for (i in px.indices) {
                    val p = px[i]
                    val l = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
                    out[i] = smooth(s.lo - 0.1f, s.lo, l) * (1f - smooth(s.hi, s.hi + 0.1f, l))
                }
            }
            is MaskSpec.Polygon -> out = PolygonFill.rasterize(s.pts, w, h)
            is MaskSpec.ColorRange -> out = colorRangeMask(readPixels(ref), s.hue, s.tolerance, s.satMin)
            is MaskSpec.Sky -> {
                val px = readPixels(ref)
                val sky = SkyFx.mask(px, w, h, s.sensitivity)
                var found = false
                for (v in sky) if (v > 0.5f) { found = true; break }
                // không thấy trời nối với mép trên (vd. cành cây che mép) → dự phòng theo dải màu xanh như trước
                out = if (found) sky else colorRangeMask(px, 210f, 45f, 0.12f)
            }
            is MaskSpec.Channel -> out = MaskMath.channelMask(readPixels(ref), s.space, s.channel, s.lo, s.hi)
            is MaskSpec.Focus -> out = MaskMath.focusMask(readPixels(ref), w, h, s.lo, s.hi)
            is MaskSpec.Radial -> {
                val rad = max(0.01f, s.radius) * min(w, h)
                for (y in 0 until h) {
                    val ny = (y - s.cy * h) / rad
                    for (x in 0 until w) {
                        val nx = (x - s.cx * w) / rad
                        out[y * w + x] = 1f - smooth(0.6f, 1f, sqrt(nx * nx + ny * ny))
                    }
                }
            }
            is MaskSpec.Linear -> {
                val a = Math.toRadians(s.angleDeg.toDouble())
                val dx = cos(a).toFloat()
                val dy = sin(a).toFloat()
                for (y in 0 until h) {
                    for (x in 0 until w) {
                        val t = ((x / w.toFloat() - 0.5f) * dx + (y / h.toFloat() - 0.5f) * dy) + 0.5f
                        out[y * w + x] = smooth(s.pos - 0.15f, s.pos + 0.15f, t)
                    }
                }
            }
        }

        // Dịch biên (nở/co) rồi mới làm mềm
        if (m.shift != 0f) out = EdgeOps.shiftEdge(out, w, h, m.shift)

        // Làm mềm biên
        val r = (m.feather * 0.05f * max(w, h)).toInt()
        if (r >= 1) {
            val gray = IntArray(w * h) { i ->
                val g = (out[i] * 255f + 0.5f).toInt().coerceIn(0, 255)
                (255 shl 24) or (g shl 16) or (g shl 8) or g
            }
            val blurred = Blur.gaussian(gray, w, h, r)
            for (i in out.indices) out[i] = (blurred[i] and 255) / 255f
        }
        if (m.invert) for (i in out.indices) out[i] = 1f - out[i]
        return out
    }
}
