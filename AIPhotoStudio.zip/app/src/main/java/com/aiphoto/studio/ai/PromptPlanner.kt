package com.aiphoto.studio.ai

/**
 * Điểm vào duy nhất để biến prompt thành kế hoạch chỉnh sửa:
 *  1. Nếu đã nạp LLM cục bộ -> dùng LLM.
 *  2. Nếu LLM lỗi / trả JSON không hợp lệ / chưa nạp -> dùng bộ quy tắc offline.
 * Các yêu cầu THEO VÙNG (răng, mắt, quầng thâm, bầu trời, chủ thể, nền) do bộ quy tắc bắt chắc chắn nên luôn được bổ sung
 * vào kế hoạch của LLM nếu LLM không tự đưa ra.
 */
object PromptPlanner {
    fun plan(prompt: String, llm: LlmPlanner?): EditPlan {
        val rules = RuleBasedPlanner.plan(prompt)
        if (llm != null) {
            val parsed = runCatching { llm.planFull(prompt) }.getOrNull()
            val ops = parsed?.let { p -> mergeOps(p.ops).mapNotNull { it.sanitized() } }.orEmpty()
            val llmScoped = parsed?.let { normalizeScoped(it.scoped) }.orEmpty()
            if (ops.isNotEmpty() || llmScoped.isNotEmpty()) {
                val known = llmScoped.map { it.scope }.toSet()
                val extra = rules.scoped.filter { it.scope !in known }
                return EditPlan(ops, "LLM cục bộ", emptyList(), llmScoped + extra)
            }
            return rules.copy(
                notes = listOf("LLM không trả về kế hoạch hợp lệ - đã dùng bộ quy tắc offline.") + rules.notes
            )
        }
        return rules
    }
}
