package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Liquify thông minh theo khuôn mặt: từ các điểm mốc MediaPipe (478 điểm, chuẩn hóa 0..1) sinh ra chuỗi đoạn đẩy cho phép LIQUIFY
 * ("x,y,dx,dy,r;..." - cùng định dạng với cọ Liquify) để: thon hàm/mặt, to mắt, thu cánh mũi, nâng khóe môi (cười).
 * Hằng số K_* hiệu chỉnh bằng khuôn mặt tổng hợp (tools/verify_ports/geo_ports.py): slim=1 thu hàm ~11%, eyes=1 tăng diện tích mắt ~42%.
 * CHƯA thử trên ảnh thật (xem A60 trong PROJECT_STATUS.md).
 */
object FaceLiquify {
    private val RIGHT_EYE = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
    private val LEFT_EYE = intArrayOf(263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249)
    private val JAW_A = intArrayOf(323, 361, 288, 397, 365, 379, 378, 400, 377)
    private val JAW_B = intArrayOf(93, 132, 58, 172, 136, 150, 149, 176, 148)
    private const val NOSE_L = 129
    private const val NOSE_R = 358
    private const val MOUTH_R = 61
    private const val MOUTH_L = 291
    private const val FOREHEAD = 10
    private const val CHIN = 152
    private const val CHEEK_A = 234
    private const val CHEEK_B = 454

    private const val K_SLIM = 0.034f
    private const val K_EYES = 0.050f
    private const val K_NOSE = 0.030f
    private const val K_SMILE = 0.030f

    /**
     * Cần đủ 468 điểm. Trả chuỗi rỗng nếu mọi tham số ≈ 0, thiếu điểm hoặc mặt quay nghiêng hẳn. R17: nếu có chiều sâu z, mọi tham số được nhân
     * với [HeadPose.liquifyGain] (1 khi mặt gần thẳng, giảm mượt về 0 khi yaw tiến tới 55°) để không méo hàm/mũi ở mặt nghiêng.
     * Không có z (mô hình cũ / mảng chỉ x,y) -> hành vi y như trước.
     */
    fun args(lm: FloatArray, w: Int, h: Int, slim: Float, eyes: Float, nose: Float, smile: Float): String {
        val g = HeadPose.liquifyGain(HeadPose.yawAbsDeg(lm, w, h))
        if (g <= 0.01f) return ""
        return argsRaw(lm, w, h, slim * g, eyes * g, nose * g, smile * g)
    }

    private fun argsRaw(lm: FloatArray, w: Int, h: Int, slim: Float, eyes: Float, nose: Float, smile: Float): String {
        if (lm.size < 2 * FaceGeometry.MIN_POINTS) return ""
        fun px(i: Int) = lm[2 * i] * w
        fun py(i: Int) = lm[2 * i + 1] * h
        val fw = hypot(px(CHEEK_A) - px(CHEEK_B), py(CHEEK_A) - py(CHEEK_B))
        if (fw < 8f) return ""
        val fx = px(FOREHEAD); val fy = py(FOREHEAD)
        var ax = px(CHIN) - fx; var ay = py(CHIN) - fy
        val al = hypot(ax, ay).coerceAtLeast(1e-6f)
        ax /= al; ay /= al
        val nx = -ay; val ny = ax
        val long = max(w, h).toFloat()
        val sb = StringBuilder()
        fun seg(x: Float, y: Float, vx: Float, vy: Float, r: Float) {
            if (sb.isNotEmpty()) sb.append(';')
            sb.append(String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f,%.5f", x / w, y / h, vx / w, vy / h, r / long))
        }
        // đẩy một điểm về phía trục trán-cằm
        fun towardAxis(i: Int, mag: Float, r: Float) {
            val x = px(i); val y = py(i)
            val side = (x - fx) * nx + (y - fy) * ny
            val s = if (side > 0f) -1f else 1f
            seg(x, y, nx * s * mag, ny * s * mag, r)
        }
        if (slim > 0.005f) {
            for (ids in arrayOf(JAW_A, JAW_B)) {
                for (k in ids.indices) {
                    val bell = sin(PI * (k + 0.5) / ids.size).toFloat()
                    towardAxis(ids[k], slim * fw * K_SLIM * bell, fw * 0.20f)
                }
            }
        }
        if (eyes > 0.005f) {
            for ((ring, corners) in arrayOf(RIGHT_EYE to intArrayOf(33, 133), LEFT_EYE to intArrayOf(263, 362))) {
                var cx = 0f; var cy = 0f
                for (i in ring) { cx += px(i); cy += py(i) }
                cx /= ring.size; cy /= ring.size
                val ew = hypot(px(corners[0]) - px(corners[1]), py(corners[0]) - py(corners[1]))
                var k = 0
                while (k < ring.size) {
                    val x = px(ring[k]); val y = py(ring[k])
                    val dx = x - cx; val dy = y - cy
                    val dn = hypot(dx, dy)
                    if (dn > 1e-6f) seg(x, y, dx / dn * eyes * ew * K_EYES, dy / dn * eyes * ew * K_EYES, ew * 0.7f)
                    k += 2
                }
            }
        }
        if (nose > 0.005f) {
            towardAxis(NOSE_L, nose * fw * K_NOSE, fw * 0.12f)
            towardAxis(NOSE_R, nose * fw * K_NOSE, fw * 0.12f)
        }
        if (smile > 0.005f) {
            for (i in intArrayOf(MOUTH_R, MOUTH_L)) {
                val m = smile * fw * K_SMILE
                seg(px(i), py(i), -ax * m, -ay * m, fw * 0.13f)
            }
        }
        return sb.toString()
    }
}
