package com.aiphoto.studio.engine

/**
 * Công tắc tính phí phía app (R23). Giai đoạn đầu app cho MỌI người dùng dùng miễn phí như tester để bắt lỗi:
 * không watermark, không hiện credits/gói/giá/Team, Agent AI và chất lượng cao dùng thoải mái.
 *
 * Các module tính phí (Google Play Billing, gói Pro, Team/Enterprise, trừ credits ở máy chủ) VẪN NGUYÊN trong mã, chỉ bị ẩn/bỏ qua.
 * Muốn bán thật: đổi [ENABLED] thành `true` ở đây VÀ đặt `OPEN_BETA=0` ở máy chủ (hai công tắc đi cùng nhau).
 * Mọi quyết định "có hiện / có đóng dấu / nhãn gì" nằm ở các hàm thuần dưới đây để kiểm thử được mà không cần giao diện.
 */
object Monetization {
    const val ENABLED: Boolean = false

    /** Có hiện giao diện tiền (credits, gói, bảng giá, đăng ký, Team) không. */
    fun showPaidUi(enabled: Boolean = ENABLED): Boolean = enabled

    /** Đóng dấu khi xuất ảnh? Chỉ khi đang bán thật + dùng máy chủ thương mại + chưa Pro (chế độ cá nhân không bao giờ đóng dấu). */
    fun needsWatermark(proxyConfigured: Boolean, isPro: Boolean, enabled: Boolean = ENABLED): Boolean = enabled && proxyConfigured && !isPro

    /**
     * Có được gọi AI đám mây qua máy chủ của chủ app không. Ở bản dùng thử, mặc định máy chủ KHÔNG dùng khóa AI của chủ app
     * (`server_ai=false` trong /v1/account): khi đó đừng thử (chỉ tốn một lượt mạng rồi bị 403), dùng model trên máy / khóa của chính người dùng.
     * [serverAi] mặc định true để máy chủ cũ (chưa báo trường này) chạy y như trước.
     */
    fun proxyAiUsable(proxyUrl: String, proxyToken: String, serverAi: Boolean): Boolean = proxyUrl.isNotBlank() && proxyToken.isNotBlank() && serverAi

    fun byokHint(enabled: Boolean = ENABLED): String? =
        if (enabled) null else "Dùng thử miễn phí: khóa của bạn lưu mã hóa trên máy và gọi thẳng tới Google, không qua máy chủ của chủ app; chi phí (nếu có) tính vào tài khoản Google của bạn."

    fun agentChipLabel(isPro: Boolean, enabled: Boolean = ENABLED, serverAi: Boolean = true): String = when {
        !enabled && !serverAi -> "Agent AI nhìn ảnh (chạy trên máy, cần model đa phương thức)"
        !enabled -> "Agent AI nhìn ảnh (dùng thử miễn phí)"
        isPro -> "Agent AI nhìn ảnh (Pro: miễn phí)"
        else -> "Agent AI nhìn ảnh (1 credit/lần)"
    }

    fun agentModeStatus(on: Boolean, enabled: Boolean = ENABLED, serverAi: Boolean = true): String = when {
        !on -> "Agent AI tắt."
        !enabled && !serverAi -> "Agent AI bật: nhìn ảnh thu nhỏ để lập kế hoạch chỉnh ngay trên máy nếu đã nạp model đa phương thức (.litertlm); chưa có model thì dùng bộ hiểu prompt trên máy."
        !enabled -> "Agent AI bật: nhìn ảnh thu nhỏ để lập kế hoạch chỉnh - ngay trên máy nếu đã nạp model đa phương thức (.litertlm), không thì ở máy chủ (dùng thử miễn phí)."
        else -> "Agent AI bật: nhìn ảnh thu nhỏ để lập kế hoạch chỉnh - ngay trên máy nếu đã nạp model đa phương thức (.litertlm), không thì ở máy chủ (gói Pro miễn phí, gói Free 1 credit/lần)."
    }

    fun serverSectionTitle(enabled: Boolean = ENABLED): String =
        if (enabled) "Máy chủ của bạn (bản thương mại: giữ khóa AI + credits)" else "Máy chủ của bạn (giữ khóa AI)"

    fun refreshButtonLabel(enabled: Boolean = ENABLED): String = if (enabled) "Cập nhật credits" else "Cập nhật lượt dùng"

    fun registeredMessage(credits: Int, enabled: Boolean = ENABLED): String =
        if (enabled) "Đã đăng ký. Credits: $credits" else "Đã đăng ký. Bạn đang dùng thử miễn phí."

    /**
     * Dòng báo tình trạng dùng thử trong Cài đặt. [used] < 0 = chưa biết (chưa hỏi máy chủ hoặc máy chủ cũ).
     * [limit] <= 0 = máy chủ không đặt trần. Trả về null khi không có gì đáng hiện (đang bán thật, hoặc chưa có số liệu).
     */
    fun betaLine(used: Int, limit: Int, enabled: Boolean = ENABLED, serverAi: Boolean = true): String? {
        if (enabled) return null
        if (!serverAi) return "Đang dùng thử miễn phí: máy chủ không dùng khóa AI của chủ app. Tạo ảnh AI bằng khóa của chính bạn (mục Tạo ảnh bên dưới) hoặc model chạy trên máy; xóa vật thể, chỉnh màu, làm đẹp… chạy ngay trên máy, không cần khóa."
        if (used < 0) return "Đang dùng thử miễn phí: đủ tính năng, không đóng dấu, không tính phí."
        val quota = if (limit > 0) "$used/$limit lượt" else "$used lượt (không giới hạn)"
        return "Đang dùng thử miễn phí · hôm nay đã dùng $quota AI trên máy chủ."
    }
}
