package com.aiphoto.studio.engine

import kotlin.math.ceil
import kotlin.math.max

/**
 * R32 — tầng BẰNG CHỨNG cho việc "đủ RAM để nạp model chưa", cộng thêm (không thay) ngưỡng tay `minRamMb` trong cấu hình định tuyến.
 *
 * VÌ SAO KHÔNG BỎ HẲN `minRamMb`: nó là ngưỡng khởi đầu (prior) chặn nạp model quá nặng ngay lần đầu; kích thước tệp không đủ để suy ra RAM thật
 * (CNN như IS-Net tốn RAM vì ĐỆM TRUNG GIAN ở độ phân giải cao chứ không phải vì trọng số; LLM ánh xạ bộ nhớ thì ngược lại), nên đoán công thức
 * từ tệp sẽ chặn nhầm model hợp lệ hoặc cho qua nhầm model nặng — đúng kiểu "số đoán" cần tránh. Thay vào đó app TỰ HỌC và chỉ chặn khi có bằng chứng:
 *  1. ĐÃ ĐO: sau lần nạp thành công app ghi mức tăng PSS ([MemoryLedger.endLoad]); từ đó cần RAM còn trống ≥ số đo × [LEARN_MARGIN], kẹp trong [tệp, tệp × [LOAD_FACTOR] + [WORKING_MB]];
 *  2. ĐÃ TỪNG BỊ GIẾT KHI NẠP (app chết giữa lúc nạp, thường do bộ diệt tiến trình): lần sau chỉ nạp khi còn trống ≥ (tệp × [LOAD_FACTOR] + [WORKING_MB])
 *     × [KILL_FACTOR]^(số lần) (hoặc số đo × biên × [KILL_FACTOR]^(số lần) nếu đã có số đo) — chặn VÒNG LẶP SẬP mỗi lần mở app;
 *  3. CHƯA CÓ BẰNG CHỨNG: ước lượng 0 = không chặn thêm (ngưỡng tay vẫn áp).
 * So với RAM CÒN TRỐNG lúc hỏi, sau khi chừa [RESERVE_FRACTION] RAM tổng cho hệ thống. Các hằng là biên an toàn, không phải số đo trên một máy.
 */
object ModelMemory {
    const val LOAD_FACTOR = 2.0f
    const val WORKING_MB = 256
    const val RESERVE_FRACTION = 0.15f
    const val LEARN_MARGIN = 1.25f
    const val KILL_FACTOR = 1.5f
    const val MAX_KILLS = 2
    /** Bằng chứng "bị giết" hết hạn sau 7 ngày: không có hạn thì model đã bị chặn sẽ không bao giờ nạp lại để được xóa đếm (khóa vĩnh viễn). */
    const val KILL_TTL_MS = 7L * 24 * 60 * 60 * 1000
    const val MIN_ESTIMATE_MB = 64

    /** MB cần trống để nạp model có tổng tệp [fileMb]; 0 = chưa có bằng chứng (không chặn). [learnedMb] <= 0 = chưa đo; [kills] = số lần app chết lúc nạp model này. */
    fun estimateMb(fileMb: Long, learnedMb: Int, kills: Int): Int {
        val k = kills.coerceIn(0, MAX_KILLS)
        if (learnedMb <= 0 && k == 0) return 0
        val file = max(0L, fileMb).toDouble()
        val formula = file * LOAD_FACTOR + WORKING_MB
        // số đo bị kẹp trong [tệp, công thức]: đo lẫn các cấp phát khác của app thì không làm model bị khóa vĩnh viễn (nó không nạp lại nên không bao giờ được đo lại)
        var e = if (learnedMb > 0) minOf(max(learnedMb * LEARN_MARGIN.toDouble(), file), formula) else formula
        repeat(k) { e *= KILL_FACTOR }
        return max(MIN_ESTIMATE_MB, ceil(e).toInt())
    }

    /** Đủ chỗ không: ước lượng 0 (chưa có bằng chứng) luôn cho qua; ngược lại RAM còn trống trừ phần chừa cho hệ thống phải >= ước lượng. */
    fun fits(estimateMb: Int, availMb: Long, totalMb: Int): Boolean =
        estimateMb <= 0 || availMb - (totalMb * RESERVE_FRACTION).toLong() >= estimateMb
}

/**
 * Sổ ghi nhớ bộ nhớ từng model (lưu bền qua [Store], ví dụ SharedPreferences). Chống chết lúc nạp bằng DẤU: ghi dấu trước khi nạp, xóa dấu khi nạp xong.
 * Lần mở app sau nếu thấy dấu còn đó nghĩa là tiến trình đã chết giữa lúc nạp (thường do bộ diệt tiến trình vì thiếu RAM) → tăng đếm "bị giết" của model đó.
 */
class MemoryLedger(private val store: Store, private val clock: () -> Long = { System.currentTimeMillis() }) {
    interface Store {
        fun getInt(key: String, def: Int): Int
        fun putInt(key: String, value: Int)
        fun getString(key: String, def: String): String
        fun putString(key: String, value: String)
    }

    private fun keyLearned(id: String) = "mem.learned.$id"
    private fun keyKills(id: String) = "mem.kills.$id"
    private fun keyKillAt(id: String) = "mem.killAt.$id"

    fun learnedMb(id: String): Int = store.getInt(keyLearned(id), 0)
    /** Số lần app chết lúc nạp model [id] trong [ModelMemory.KILL_TTL_MS] gần đây (quá hạn thì tính 0). */
    fun kills(id: String): Int {
        val n = store.getInt(keyKills(id), 0)
        if (n <= 0) return 0
        val at = store.getString(keyKillAt(id), "").toLongOrNull() ?: return 0
        return if (clock() - at <= ModelMemory.KILL_TTL_MS) n else 0
    }

    /** Gọi MỘT LẦN khi mở app. */
    fun recoverAfterCrash() {
        val id = store.getString(KEY_LOADING, "")
        if (id.isNotEmpty()) {
            store.putInt(keyKills(id), kills(id) + 1)
            store.putString(keyKillAt(id), clock().toString())
            store.putString(KEY_LOADING, "")
        }
    }

    fun beginLoad(id: String) = store.putString(KEY_LOADING, id)

    /** Nạp xong: xóa dấu + đếm bị giết; [measuredMb] > 0 thì ghi làm số đo mới (số đo nhỏ vô lý bị loại bởi sàn kích thước tệp trong [ModelMemory.estimateMb]). */
    fun endLoad(id: String, measuredMb: Int) {
        store.putString(KEY_LOADING, "")
        store.putInt(keyKills(id), 0)
        if (measuredMb > 0) store.putInt(keyLearned(id), measuredMb)
    }

    /** Nạp lỗi bằng ngoại lệ (không phải bị giết): chỉ xóa dấu, không phạt. */
    fun abortLoad() = store.putString(KEY_LOADING, "")

    companion object { const val KEY_LOADING = "mem.loading" }
}
