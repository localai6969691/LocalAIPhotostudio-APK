package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Di chuyển vật thể (R24): chọn vật thể (chạm chọn) → TÁCH thành lớp ảnh có nền trong suốt (kéo/chụm/xoay trực tiếp được như mọi lớp phủ ảnh)
 * + XÓA chỗ cũ bằng engine xóa vật thể có sẵn. Phần thuần ở đây (hộp bao, cắt có viền mềm, nới vùng xóa, tham số lớp phủ) kiểm thử được trên JVM.
 *
 * Lớp phủ ảnh vẽ chiều rộng = size × rộng ảnh nền, tâm (cx, cy) chuẩn hóa -> [cutout] trả đúng cx, cy, size để vật thể hiện NGAY tại vị trí cũ,
 * không nhảy chỗ khi vừa tách.
 */
object MoveObject {
    /** Vùng chọn chiếm < 0.05% hoặc > 85% ảnh thì không di chuyển (gần như chắc chắn chọn nhầm). */
    const val MIN_COVER = 0.0005
    const val MAX_COVER = 0.85
    /** Chừa lề trong suốt quanh hộp bao để viền mềm không bị cắt cụt. */
    const val PAD = 2

    /**
     * Vật thể đã tách: [x],[y],[w],[h] = hộp (đã chừa lề) trên ảnh nền; [pixels] ARGB (alpha = mặt nạ làm mềm viền); [cx],[cy],[size] = tham số lớp phủ ảnh
     * đặt đúng tại chỗ cũ.
     */
    class Cut(val x: Int, val y: Int, val w: Int, val h: Int, val pixels: IntArray, val cx: Float, val cy: Float, val size: Float, val coverage: Double)

    private fun v(m: ByteArray, i: Int): Int = m[i].toInt() and 255

    /** Tỉ lệ điểm ảnh được chọn (mặt nạ khác 0). */
    fun coverage(mask: ByteArray): Double {
        if (mask.isEmpty()) return 0.0
        var n = 0
        for (b in mask) if (b.toInt() != 0) n++
        return n.toDouble() / mask.size
    }

    /** Hộp bao [x0, y0, x1, y1) của các điểm được chọn; null nếu không có điểm nào. */
    fun bbox(mask: ByteArray, w: Int, h: Int): IntArray? {
        if (w <= 0 || h <= 0 || mask.size != w * h) return null
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (mask[y * w + x].toInt() != 0) {
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
        }
        return if (x1 < 0) null else intArrayOf(x0, y0, x1 + 1, y1 + 1)
    }

    /** Tách vật thể theo mặt nạ [mask] từ ảnh [px] (ARGB, w×h). Null nếu vùng chọn rỗng / nhỏ quá / lớn quá. */
    fun cutout(px: IntArray, w: Int, h: Int, mask: ByteArray): Cut? {
        if (w <= 0 || h <= 0 || px.size != w * h || mask.size != w * h) return null
        val cover = coverage(mask)
        if (cover < MIN_COVER || cover > MAX_COVER) return null
        val b = bbox(mask, w, h) ?: return null
        val x0 = max(0, b[0] - PAD)
        val y0 = max(0, b[1] - PAD)
        val x1 = min(w, b[2] + PAD)
        val y1 = min(h, b[3] + PAD)
        val cw = x1 - x0
        val ch = y1 - y0
        // alpha trong hộp: co 1 điểm (bỏ viền dính màu nền cũ) rồi làm mềm 3×3; vật thể nhỏ (< 12 điểm) chỉ làm mềm để không biến mất
        val big = min(b[2] - b[0], b[3] - b[1]) >= 12
        var a = FloatArray(cw * ch) { v(mask, (y0 + it / cw) * w + x0 + it % cw) / 255f }
        if (big) a = filter3x3(a, cw, ch, erode = true)
        a = filter3x3(a, cw, ch, erode = false)
        val out = IntArray(cw * ch)
        for (i in out.indices) {
            val src = px[(y0 + i / cw) * w + x0 + i % cw]
            val alpha = (a[i] * 255f).roundToInt().coerceIn(0, 255)
            out[i] = (alpha shl 24) or (src and 0x00FFFFFF)
        }
        return Cut(x0, y0, cw, ch, out, (x0 + cw / 2f) / w, (y0 + ch / 2f) / h, cw.toFloat() / w, cover)
    }

    /** Bán kính nới vùng xóa chỗ cũ (điểm ảnh): bù viền mềm / bóng sát vật thể, tỉ lệ theo cạnh dài của ảnh. */
    fun growFor(w: Int, h: Int): Int = max(2, (max(w, h) / 400.0).roundToInt())

    /** Nới mặt nạ [r] điểm ảnh theo mọi hướng (phần tử cấu trúc vuông, hai lượt lọc cực đại); không sửa mảng gốc. Kết quả 0/255. */
    fun dilate(mask: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        if (r <= 0 || mask.size != w * h) return ByteArray(mask.size) { if (mask[it].toInt() != 0) 255.toByte() else 0 }
        val tmp = ByteArray(mask.size)
        for (y in 0 until h) {
            val row = y * w
            var last = -1000000
            // gần nhất bên trái / bên phải trong bán kính r
            for (x in 0 until w) { if (mask[row + x].toInt() != 0) last = x; if (x - last <= r) tmp[row + x] = 255.toByte() }
            last = 1000000
            for (x in w - 1 downTo 0) { if (mask[row + x].toInt() != 0) last = x; if (last - x <= r) tmp[row + x] = 255.toByte() }
        }
        val out = ByteArray(mask.size)
        for (x in 0 until w) {
            var last = -1000000
            for (y in 0 until h) { if (tmp[y * w + x].toInt() != 0) last = y; if (y - last <= r) out[y * w + x] = 255.toByte() }
            last = 1000000
            for (y in h - 1 downTo 0) { if (tmp[y * w + x].toInt() != 0) last = y; if (last - y <= r) out[y * w + x] = 255.toByte() }
        }
        return out
    }

    private fun filter3x3(a: FloatArray, w: Int, h: Int, erode: Boolean): FloatArray {
        val out = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            var mn = Float.MAX_VALUE
            var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                val value = if (xx in 0 until w && yy in 0 until h) a[yy * w + xx] else 0f   // ngoài hộp = trong suốt
                s += value; mn = min(mn, value); c++
            }
            out[y * w + x] = if (erode) mn else s / c
        }
        return out
    }
}
