package com.aiphoto.studio.i18n

import org.json.JSONObject
import java.text.Normalizer

/** Một mục hướng dẫn: tiêu đề + nội dung. */
data class HelpItem(val title: String, val body: String)

/** Một nhóm mục hướng dẫn. */
data class HelpSection(val title: String, val items: List<HelpItem>)

/**
 * Nội dung Trợ giúp (R33), đọc từ `assets/help/<mã>.json`:
 * `{"sections":[{"title":"…","items":[{"t":"…","b":"…"}]}]}`. Cấu trúc (số nhóm, số mục, thứ tự) GIỐNG HỆT giữa các ngôn ngữ — `tools/i18n_build.py` kiểm.
 */
object HelpContent {
    fun parse(json: String): List<HelpSection> {
        val root = JSONObject(json)
        val arr = root.getJSONArray("sections")
        val out = ArrayList<HelpSection>(arr.length())
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val items = s.getJSONArray("items")
            val list = ArrayList<HelpItem>(items.length())
            for (j in 0 until items.length()) {
                val o = items.getJSONObject(j)
                list.add(HelpItem(o.getString("t"), o.getString("b")))
            }
            out.add(HelpSection(s.getString("title"), list))
        }
        return out
    }

    private val MARKS = Regex("\\p{Mn}+")

    /**
     * Chuẩn hóa để so khớp KHÔNG phân biệt hoa thường VÀ dấu: "mo anh" tìm được "Mở ảnh", "camara" tìm được "cámara". NFD tách dấu thành ký tự kết hợp (Mn) rồi bỏ;
     * "đ" không tách được nên đổi riêng. Cả từ khóa lẫn nội dung đều qua hàm này nên cách gõ dựng sẵn / tổ hợp của bàn phím không còn quan trọng.
     */
    fun fold(s: String): String =
        MARKS.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "").replace('đ', 'd').replace('Đ', 'D').lowercase()

    /** Lọc theo từ khóa (tìm trong tiêu đề nhóm / mục / nội dung, xem [fold]); nhóm không còn mục nào thì bỏ. Từ khóa trống ⇒ nguyên bản. */
    fun filter(sections: List<HelpSection>, query: String): List<HelpSection> {
        val q = fold(query.trim())
        if (q.isEmpty()) return sections
        return sections.mapNotNull { s ->
            val sectionHit = fold(s.title).contains(q)
            val items = if (sectionHit) s.items else s.items.filter { fold(it.title).contains(q) || fold(it.body).contains(q) }
            if (items.isEmpty()) null else HelpSection(s.title, items)
        }
    }
}
