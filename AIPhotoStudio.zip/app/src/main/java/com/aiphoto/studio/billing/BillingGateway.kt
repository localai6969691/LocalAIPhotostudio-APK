package com.aiphoto.studio.billing

import android.app.Activity
import java.security.MessageDigest

/** Sản phẩm bán trong ứng dụng (mua một lần, tiêu thụ được): gói credits hoặc "N ngày Pro". Mã khai báo trong Play Console + PLAN_PRODUCTS/CREDIT_PACKS ở backend. */
val BILLING_PRODUCTS = listOf("credits_20", "credits_100", "pro_30d", "pro_365d")

/** Mã gói ĐĂNG KÝ định kỳ (Play Console → Subscriptions); PHẢI khớp SUBSCRIPTION_PRODUCTS ở backend (tools/static_check.py kiểm tra). */
val BILLING_SUBSCRIPTIONS = listOf("pro_monthly", "pro_yearly")

data class BillingProduct(val id: String, val title: String, val price: String)

sealed class BillingEvent {
    class Purchased(val productId: String, val token: String) : BillingEvent()
    object Pending : BillingEvent()
    object Cancelled : BillingEvent()
    class Error(val message: String) : BillingEvent()
}

/** Mã tài khoản ẩn danh gắn vào giao dịch (setObfuscatedAccountId); PHẢI trùng backend `account_hash`: sha256(device_id) hex, 32 ký tự đầu. */
fun accountHash(deviceId: String): String =
    MessageDigest.getInstance("SHA-256").digest(deviceId.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }.take(32)

/**
 * Cổng thanh toán. Bản MẶC ĐỊNH (src/billingStub) không làm gì: app vẫn build và chạy như cũ, chỉ không bán được.
 * Bản THẬT (src/billingReal, Google Play Billing 8.x) chỉ được biên dịch khi build với  -PuseBilling=true  - tách riêng vì
 * APK chưa từng được biên dịch/chạy thử nên không để thư viện mới làm hỏng bản build mặc định.
 */
interface BillingGateway {
    val available: Boolean
    fun connect(onReady: () -> Unit, onError: (String) -> Unit)
    fun products(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit)
    fun purchase(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit)
    /** Giao dịch đã trả tiền nhưng chưa tiêu thụ (app bị tắt giữa chừng) -> (productId, token). */
    fun unconsumed(onResult: (List<Pair<String, String>>) -> Unit)
    fun consume(token: String, onDone: (Boolean) -> Unit)

    // ---- đăng ký định kỳ (R14). Máy chủ mặc định tự acknowledge (SUBSCRIPTION_ACK=server); `acknowledge` chỉ dùng khi máy chủ báo "client".
    fun subscriptions(ids: List<String>, onResult: (List<BillingProduct>) -> Unit, onError: (String) -> Unit)
    fun purchaseSubscription(activity: Activity, productId: String, accountId: String, onResult: (BillingEvent) -> Unit)
    /** Đăng ký đang có trên tài khoản Google (để khôi phục sau khi cài lại / đổi máy) -> (productId, token). */
    fun activeSubscriptions(onResult: (List<Pair<String, String>>) -> Unit)
    fun acknowledge(token: String, onDone: (Boolean) -> Unit)
    fun close()
}
