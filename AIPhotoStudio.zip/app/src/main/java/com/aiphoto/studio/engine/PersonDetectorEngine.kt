package com.aiphoto.studio.engine

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Phát hiện NGƯỜI (hộp bao cả người, kể cả người quay lưng / che mặt) bằng MediaPipe Object Detector (tasks-vision, Apache-2.0) —
 * cùng thư viện với Face Landmarker nên không thêm phụ thuộc. Model do người dùng nạp: `efficientdet_lite0.tflite` (COCO, 320×320; tải từ kho
 * `mediapipe-models/object_detector/efficientdet_lite0`, bản int8/float16/float32 đều dùng được) — lớp "person" nằm trong 80 nhãn COCO.
 * Dùng cho "Xóa người lạ": khuôn mặt chỉ thấy người nhìn thẳng, còn hộp người thấy cả người quay lưng (xem [StrangerMask]).
 *
 * Giới hạn: đầu vào 320×320 nên người rất nhỏ (cỡ vài chục điểm ảnh trên ảnh lớn) có thể bị bỏ sót.
 * Model nằm ngoài thư mục assets nên nạp qua `setModelAssetBuffer` (như [FaceLandmarkerEngine]).
 */
class PersonDetectorEngine(context: Context, modelPath: String) : AutoCloseable {

    private val detector: ObjectDetector
    private val mapped: MappedByteBuffer

    init {
        mapped = RandomAccessFile(File(modelPath), "r").use { raf ->
            raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length())
        }
        val base = BaseOptions.builder().setModelAssetBuffer(mapped).build()
        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setMaxResults(MAX_PEOPLE)
            .setScoreThreshold(MIN_SCORE)
            .build()
        detector = ObjectDetector.createFromOptions(context.applicationContext, options)
    }

    /**
     * Mỗi người = [x0, y0, x1, y1, điểm] chuẩn hóa 0..1 theo kích thước ảnh (cùng quy ước như mốc khuôn mặt). Danh sách rỗng nếu không thấy ai.
     * Lọc nhãn "person" ở đây (không dùng allowlist của model) để cấu hình model khác nhãn vẫn chạy được; hộp MediaPipe trả về là pixel của ảnh đầu vào.
     */
    @Synchronized
    fun detect(bitmap: Bitmap): List<FloatArray> {
        val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val w = argb.width.toFloat()
        val h = argb.height.toFloat()
        val result = detector.detect(BitmapImageBuilder(argb).build())
        val out = ArrayList<FloatArray>()
        for (d in result.detections()) {
            val top = d.categories().firstOrNull() ?: continue
            if (!PERSON.equals(top.categoryName(), ignoreCase = true)) continue
            val b = d.boundingBox()
            out.add(floatArrayOf(b.left / w, b.top / h, b.right / w, b.bottom / h, top.score()))
        }
        return out
    }

    override fun close() {
        try { detector.close() } catch (e: Throwable) { }
    }

    private companion object {
        const val PERSON = "person"
        const val MAX_PEOPLE = 20
        const val MIN_SCORE = 0.4f
    }
}
