package com.aiphoto.studio.doc

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.WeakHashMap

data class ProjectInfo(val savedAt: Long, val layerCount: Int, val w: Int, val h: Int)
class LoadedProject(val background: Bitmap, val layers: List<Layer>, val idCounter: Long, val skipped: Int)

/**
 * Lưu PHIÊN LÀM VIỆC của ảnh đang mở ở filesDir/projects/<ngăn>/ (R19: mỗi ảnh một ngăn, giữ tối đa [ProjectSlots.MAX_SLOTS] ngăn mới nhất;
 * bản cũ chỉ có một phiên ở filesDir/project nên được chuyển thành ngăn "default"): meta.json + ảnh nền (PNG) + mảng vá (PNG) + mặt nạ tô tay (.bin).
 *  - Ghi tăng dần: tệp nhị phân chỉ ghi lần đầu (mỗi tên tệp gắn với một phiên chạy nên không đụng tệp cũ),
 *    meta.json ghi qua tệp tạm rồi đổi tên (nguyên tử) → mất điện giữa chừng vẫn còn bản cũ đọc được.
 *  - Sau mỗi lần lưu dọn các tệp không còn được meta tham chiếu.
 */
class ProjectStore(private val ctx: Context, slot: String = ProjectSlots.DEFAULT) {
    private var slotId: String = if (ProjectSlots.validId(slot)) slot else ProjectSlots.DEFAULT
    private val dir get() = File(ProjectSlots.root(ctx.filesDir), slotId)
    private val metaFile get() = File(dir, "meta.json")

    init { ProjectSlots.migrateLegacy(ctx.filesDir) }

    @Synchronized
    fun currentSlot(): String = slotId

    private fun resetCaches() {
        lastBg = null
        lastBgName = null
        patchNames.clear()
        overlayNames.clear()
        maskNames.clear()
    }

    /** Chuyển sang ngăn có sẵn (để tiếp tục lưu vào đó sau khi khôi phục). */
    @Synchronized
    fun switchTo(id: String) {
        require(ProjectSlots.validId(id)) { "Mã phiên không hợp lệ" }
        if (id != slotId) {
            slotId = id
            resetCaches()
        }
    }

    /** Bắt đầu một phiên MỚI (mở ảnh khác) mà không đụng các phiên cũ; trả mã ngăn mới. */
    @Synchronized
    fun startNew(): String {
        val id = ProjectSlots.newId(System.currentTimeMillis(), ProjectSlots.ids(ctx.filesDir) + slotId)
        switchTo(id)
        return id
    }

    @Synchronized
    fun list(): List<ProjectSlots.Item> = ProjectSlots.list(ctx.filesDir)

    @Synchronized
    fun delete(id: String) {
        ProjectSlots.delete(ctx.filesDir, id)
        if (id == slotId) resetCaches()
    }

    private val session = System.currentTimeMillis().toString(36)
    private var seq = 0
    private var lastBg: Bitmap? = null
    private var lastBgName: String? = null
    private val patchNames = HashMap<Long, Pair<Bitmap, String>>()
    private val overlayNames = HashMap<Long, Pair<Bitmap, String>>()
    private val maskNames = WeakHashMap<ByteArray, String>() // ByteArray so khớp theo định danh (không ghi đè equals)

    private fun writeText(f: File, text: String) = FileOutputStream(f).use { it.write(text.toByteArray(Charsets.UTF_8)) }

    @Synchronized
    fun info(): ProjectInfo? = ProjectSlots.infoOf(dir)

    /**
     * [forSlot] != null: chỉ ghi nếu ngăn hiện tại vẫn là [forSlot] - bản lưu tự động chụp trạng thái rồi mới ghi, nếu giữa chừng người dùng
     * mở ảnh khác (đổi ngăn) thì KHÔNG được ghi trạng thái cũ vào ngăn mới.
     */
    @Synchronized
    fun save(bg: Bitmap, layers: List<Layer>, idCounter: Long, forSlot: String? = null) {
        if (forSlot != null && forSlot != slotId) return
        dir.mkdirs()
        if (bg !== lastBg || lastBgName == null || !File(dir, lastBgName!!).isFile) {
            val name = "bg_${session}_${++seq}.png"
            FileOutputStream(File(dir, name)).use { bg.compress(Bitmap.CompressFormat.PNG, 100, it) }
            lastBg = bg
            lastBgName = name
        }
        val json = ProjectCodec.encode(
            ProjectCodec.Meta(System.currentTimeMillis(), bg.width, bg.height, lastBgName!!, idCounter),
            layers,
            patchFile = { l ->
                val known = patchNames[l.id]
                if (known != null && known.first === l.patch && File(dir, known.second).isFile) known.second
                else {
                    val name = "patch_${session}_${l.id}_${++seq}.png"
                    FileOutputStream(File(dir, name)).use { l.patch.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    patchNames[l.id] = Pair(l.patch, name)
                    name
                }
            },
            imageFile = { l ->
                val img = l.image!!
                val known = overlayNames[l.id]
                if (known != null && known.first === img && File(dir, known.second).isFile) known.second
                else {
                    val name = "overlay_${session}_${l.id}_${++seq}.png"
                    FileOutputStream(File(dir, name)).use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    overlayNames[l.id] = Pair(img, name)
                    name
                }
            },
            maskFile = { _, m ->
                val known = maskNames[m.data]
                if (known != null && File(dir, known).isFile) known
                else {
                    val name = "mask_${session}_${++seq}.bin"
                    FileOutputStream(File(dir, name)).use { it.write(m.data) }
                    maskNames[m.data] = name
                    name
                }
            }
        )
        val tmp = File(dir, "meta.json.tmp")
        writeText(tmp, json.toString())
        if (!tmp.renameTo(metaFile)) { // một số hệ thống không cho đè khi đổi tên
            metaFile.delete()
            check(tmp.renameTo(metaFile)) { "Không ghi được meta.json" }
        }
        val keep = ProjectCodec.referencedFiles(json) + setOf("meta.json", "meta.json.tmp")
        dir.listFiles()?.forEach { if (it.name !in keep) it.delete() }
        patchNames.keys.retainAll(layers.filterIsInstance<PatchLayer>().map { it.id }.toSet())
        overlayNames.keys.retainAll(layers.filterIsInstance<OverlayLayer>().map { it.id }.toSet())
        ProjectSlots.evict(ctx.filesDir, ProjectSlots.MAX_SLOTS, slotId)
    }

    @Synchronized
    fun load(): LoadedProject? = runCatching {
        val json = JSONObject(metaFile.readText())
        val m = ProjectCodec.meta(json) ?: return@runCatching null
        val bg = BitmapFactory.decodeFile(File(dir, m.bgFile).absolutePath, BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: return@runCatching null
        if (bg.width != m.w || bg.height != m.h) return@runCatching null
        val dec = ProjectCodec.decode(
            json, bg.width, bg.height,
            loadPatch = { name ->
                if (name.isBlank() || name.contains('/') || name.contains('\\')) null
                else runCatching {
                    BitmapFactory.decodeFile(File(dir, name).absolutePath, BitmapFactory.Options().apply {
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    })
                }.getOrNull()
            },
            loadMask = { name, w, h ->
                if (name.isBlank() || name.contains('/') || name.contains('\\')) null
                else runCatching { File(dir, name).readBytes() }.getOrNull()?.takeIf { it.size == w * h }
            }
        )
        // nhớ lại tên tệp đã ghi để lần lưu kế tiếp không ghi lại những gì đã có
        lastBg = bg
        lastBgName = m.bgFile
        LoadedProject(bg, dec.layers, maxOf(m.idCounter, dec.maxId + 1), dec.skipped)
    }.getOrNull()

    /** Xóa phiên ở ngăn hiện tại. */
    @Synchronized
    fun clear() {
        dir.deleteRecursively()
        resetCaches()
    }
}
