package com.aiphoto.studio.i18n

/** Một ngôn ngữ giao diện. [nativeName] luôn viết bằng chính ngôn ngữ đó (người dùng nhận ra ngôn ngữ của mình dù đang ở giao diện nào). */
data class AppLanguage(val code: String, val nativeName: String, val rtl: Boolean = false)

object AppLanguages {
    const val AUTO = "auto"

    /** Ngôn ngữ nguồn của mã là tiếng Việt: luôn đầy đủ, không cần gói dịch. */
    const val SOURCE = "vi"

    /** Các ngôn ngữ phổ biến, theo thứ tự hiển thị. Mỗi mã (trừ [SOURCE]) có gói `assets/i18n/<mã>.json` và `assets/help/<mã>.json`. */
    val ALL: List<AppLanguage> = listOf(
        AppLanguage("vi", "Tiếng Việt"),
        AppLanguage("en", "English"),
        AppLanguage("zh", "简体中文"),
        AppLanguage("es", "Español"),
        AppLanguage("hi", "हिन्दी"),
        AppLanguage("ar", "العربية", rtl = true),
        AppLanguage("pt", "Português (Brasil)"),
        AppLanguage("ru", "Русский"),
        AppLanguage("ja", "日本語"),
        AppLanguage("ko", "한국어"),
        AppLanguage("fr", "Français"),
        AppLanguage("de", "Deutsch"),
        AppLanguage("id", "Bahasa Indonesia")
    )

    fun byCode(code: String): AppLanguage? = ALL.firstOrNull { it.code == code }

    /** Mã ngôn ngữ của hệ thống (Locale.getDefault().language) → mã được hỗ trợ; không hỗ trợ → tiếng Anh (ngôn ngữ chung dễ hiểu nhất). */
    fun resolveAuto(systemLanguage: String): String {
        val l = when (systemLanguage.lowercase()) {
            "in" -> "id"     // Android cũ trả "in" cho tiếng Indonesia
            "iw" -> "he"
            else -> systemLanguage.lowercase()
        }
        return if (byCode(l) != null) l else "en"
    }

    /** [pref] là [AUTO] hoặc một mã; mã lạ (ví dụ lưu từ bản cũ) ⇒ như [AUTO]. */
    fun resolve(pref: String, systemLanguage: String): String =
        if (pref != AUTO && byCode(pref) != null) pref else resolveAuto(systemLanguage)
}
