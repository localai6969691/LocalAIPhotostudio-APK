package com.aiphoto.studio.ai

/**
 * Nhập yêu cầu bằng GIỌNG NÓI (R35). PDF DeepSeek: "người dùng chỉ cần gõ hoặc nói yêu cầu của mình" — trước R35 app chỉ nhận chữ gõ.
 *
 * Thiết kế: dùng HỘP NHẬN DẠNG GIỌNG NÓI CỦA HỆ THỐNG (`RecognizerIntent.ACTION_RECOGNIZE_SPEECH`, xem `util/VoiceIntents.kt`) thay vì tự thu âm:
 *  - app KHÔNG xin quyền micro (manifest không có RECORD_AUDIO) và không bao giờ nhận âm thanh, chỉ nhận CHỮ đã chép;
 *  - không thêm thư viện; ngôn ngữ nhận dạng theo ngôn ngữ giao diện (13 ngôn ngữ của [com.aiphoto.studio.i18n.AppLanguages]);
 *  - máy không có dịch vụ nhận dạng (thường là ứng dụng Google) ⇒ báo và để người dùng gõ.
 *
 * Tệp này là phần THUẦN Kotlin (không Android, kiểm được trên JVM): chọn bản chép hợp lý nhất, làm sạch, ghép vào ô yêu cầu.
 * Bản port Python tương đương ở tools/verify_ports/voice_input.py.
 */
object VoiceInput {
    /** Số bản chép tối đa xin từ bộ nhận dạng (đã xếp theo độ tin cậy giảm dần). */
    const val MAX_RESULTS = 3

    /** Độ dài tối đa của ô yêu cầu sau khi ghép (cùng cỡ với giới hạn ghi chú / câu lệnh khác trong app). */
    const val MAX_CHARS = 600

    /** Mã ngôn ngữ giao diện → thẻ BCP-47 cho bộ nhận dạng. Mã nào trong `AppLanguages.ALL` cũng phải có ở đây (static_check [36]). */
    private val TAGS: Map<String, String> = mapOf(
        "vi" to "vi-VN", "en" to "en-US", "zh" to "zh-CN", "es" to "es-ES", "hi" to "hi-IN", "ar" to "ar-SA",
        "pt" to "pt-BR", "ru" to "ru-RU", "ja" to "ja-JP", "ko" to "ko-KR", "fr" to "fr-FR", "de" to "de-DE", "id" to "id-ID"
    )

    /** Dấu cuối câu mà bộ nhận dạng hay thêm; bỏ đi cho gọn (`?` và `!` giữ nguyên vì có thể mang nghĩa). */
    private const val TRAILING = ".。…,，、;；"

    /** Thẻ ngôn ngữ cho bộ nhận dạng; mã lạ ⇒ tiếng Anh (như [com.aiphoto.studio.i18n.AppLanguages.resolveAuto]). */
    fun languageTag(appLanguage: String): String = TAGS[appLanguage.trim().lowercase()] ?: "en-US"

    /** Ký tự rộng-0 vô hình (ZWSP, word joiner, BOM). KHÔNG bỏ ZWNJ / ZWJ vì tiếng Hindi, Ả Rập dùng chúng để viết đúng chữ. */
    private fun isInvisible(c: Char): Boolean = c == '\u200B' || c == '\u2060' || c == '\uFEFF'

    private fun cap(s: String): String {
        if (s.length <= MAX_CHARS) return s
        var cut = MAX_CHARS
        if (Character.isHighSurrogate(s[cut - 1])) cut-- // không cắt đôi một cặp thay thế (emoji, chữ Hán hiếm)
        return s.substring(0, cut).trimEnd()
    }

    /** Làm sạch một bản chép: bỏ ký tự vô hình, gộp khoảng trắng / xuống dòng, bỏ dấu cuối câu, cắt tối đa [MAX_CHARS]. */
    fun normalize(raw: String?): String {
        if (raw == null) return ""
        val sb = StringBuilder(raw.length)
        var pendingSpace = false
        for (c in raw) {
            if (isInvisible(c)) continue
            if (c.isWhitespace()) {
                pendingSpace = sb.isNotEmpty()
            } else {
                if (pendingSpace) {
                    sb.append(' ')
                    pendingSpace = false
                }
                sb.append(c)
            }
        }
        var end = sb.length
        while (end > 0 && (sb[end - 1] == ' ' || TRAILING.indexOf(sb[end - 1]) >= 0)) end--
        return cap(sb.substring(0, end))
    }

    /**
     * Chọn bản chép dùng được trong các bản bộ nhận dạng trả về. Bản đầu (tin cậy nhất) được ưu tiên; nhưng nếu bản đầu KHÔNG
     * phải một lệnh app hiểu mà có bản sau hiểu được thì lấy bản sau (nhận dạng hay nhầm chữ gần âm: "làm sáng ảnh" ↔ "làm sáng anh").
     * [understands] do nơi gọi truyền vào (bộ hiểu lệnh offline) nên tệp này không phụ thuộc bộ hiểu; lỗi trong nó coi như "không hiểu".
     * Không có bản nào dùng được (rỗng / chỉ dấu câu) ⇒ null.
     */
    fun pick(candidates: List<String>?, understands: (String) -> Boolean): String? {
        if (candidates == null) return null
        val cleaned = ArrayList<String>()
        for (c in candidates) {
            if (cleaned.size >= MAX_RESULTS) break
            val n = normalize(c)
            if (n.isNotEmpty() && n !in cleaned) cleaned.add(n)
        }
        if (cleaned.isEmpty()) return null
        for (n in cleaned) {
            val ok = try {
                understands(n)
            } catch (e: Exception) {
                false
            }
            if (ok) return n
        }
        return cleaned[0]
    }

    /**
     * Ghép lời nói vào ô yêu cầu đang có chữ: ô trống ⇒ thay bằng lời nói; đã có chữ ⇒ nối thêm, ngăn bằng ", " (bộ hiểu lệnh tách mệnh đề ở dấu phẩy)
     * hoặc một khoảng trắng nếu chữ cũ đã kết thúc bằng dấu câu. Lời nói rỗng ⇒ giữ nguyên ô. Tổng không quá [MAX_CHARS].
     */
    fun merge(existing: String, spoken: String): String {
        val add = normalize(spoken)
        if (add.isEmpty()) return existing
        val base = existing.trimEnd()
        if (base.isEmpty()) return add
        val sep = if (base.last() in ",;.!?") " " else ", "
        return cap(base + sep + add)
    }
}
