package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.abs

/**
 * Color Grading kiểu "split toning" (PDF: "highlight cam, shadow xanh", teal & orange): nhuộm VÙNG TỐI và VÙNG SÁNG
 * bằng hai màu riêng, giữ nguyên độ chói của từng điểm.
 *
 * Mỗi điểm có độ chói L (Rec.709). Trọng số vùng sáng wh = smoothstep(m−0,4; m+0,4; L), vùng tối ws = 1 − wh, với điểm giao
 * m = 0,5 − 0,25·balance (balance > 0 dành nhiều dải tông hơn cho vùng sáng — giống thanh Balance của Lightroom).
 * Màu nhuộm = (màu tinh khiết theo hue) − (độ chói của chính nó) → dịch chuyển có TỔNG CHÓI BẰNG 0, nên cộng vào điểm ảnh
 * không làm đổi độ sáng (chỉ sai lệch nhỏ khi bị cắt ở 0/255).
 *
 * arg = "hueBóng,satBóng,hueSáng,satSáng,balance" — hue 0..360°, sat 0..1, balance −1..1.
 */
object SplitTone {

    data class Params(val shadowHue: Float, val shadowSat: Float, val highHue: Float, val highSat: Float, val balance: Float = 0f) {
        val isIdentity: Boolean get() = shadowSat < 0.005f && highSat < 0.005f
    }

    /** Độ mạnh tối đa của dịch chuyển màu khi sat = 1 (đơn vị: thang 0..1 của kênh). */
    private const val GAIN = 0.35f
    private const val SOFT = 0.4f

    fun parse(arg: String?): Params? {
        val v = arg?.split(',')?.map { it.trim().toFloatOrNull() ?: return null } ?: return null
        if (v.size < 4 || v.any { it.isNaN() }) return null
        return Params(
            normHue(v[0]), v[1].coerceIn(0f, 1f), normHue(v[2]), v[3].coerceIn(0f, 1f),
            (v.getOrNull(4) ?: 0f).coerceIn(-1f, 1f)
        )
    }

    fun format(p: Params): String = String.format(
        Locale.US, "%.1f,%.3f,%.1f,%.3f,%.3f", p.shadowHue, p.shadowSat, p.highHue, p.highSat, p.balance
    )

    /** Chuẩn hóa chuỗi (dùng ở sanitized). Null nếu không hợp lệ hoặc không có tác dụng. */
    fun canonical(arg: String?): String? = parse(arg)?.takeIf { !it.isIdentity }?.let { format(it) }

    /**
     * Gộp hai yêu cầu từ hai mệnh đề ("highlight màu cam" + "shadow màu xanh"): mỗi nửa lấy từ yêu cầu nào thực sự đặt nó
     * (sat > 0); cả hai đặt thì lấy yêu cầu sau.
     */
    fun merge(a: Params, b: Params): Params {
        val sh = if (b.shadowSat >= 0.005f) b else if (a.shadowSat >= 0.005f) a else b
        val hi = if (b.highSat >= 0.005f) b else if (a.highSat >= 0.005f) a else b
        val bal = if (abs(b.balance) > 0.005f) b.balance else a.balance
        return Params(sh.shadowHue, sh.shadowSat, hi.highHue, hi.highSat, bal)
    }

    private fun normHue(h: Float): Float = ((h % 360f) + 360f) % 360f

    /** Màu hue thuần (S = V = 1) → RGB 0..1. */
    internal fun hueRgb(h: Float): FloatArray {
        val x = normHue(h) / 60f
        val i = x.toInt() % 6
        val f = x - x.toInt()
        return when (i) {
            0 -> floatArrayOf(1f, f, 0f)
            1 -> floatArrayOf(1f - f, 1f, 0f)
            2 -> floatArrayOf(0f, 1f, f)
            3 -> floatArrayOf(0f, 1f - f, 1f)
            4 -> floatArrayOf(f, 0f, 1f)
            else -> floatArrayOf(1f, 0f, 1f - f)
        }
    }

    private fun luma(r: Float, g: Float, b: Float) = 0.2126f * r + 0.7152f * g + 0.0722f * b

    /** Dịch chuyển màu (tổng chói = 0) ứng với hue [h] và độ bão hòa [s]. */
    internal fun offset(h: Float, s: Float): FloatArray {
        val c = hueRgb(h)
        val l = luma(c[0], c[1], c[2])
        return floatArrayOf((c[0] - l) * s * GAIN, (c[1] - l) * s * GAIN, (c[2] - l) * s * GAIN)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    fun apply(px: IntArray, w: Int, h: Int, p: Params): IntArray {
        if (p.isIdentity) return px
        val os = offset(p.shadowHue, p.shadowSat)
        val oh = offset(p.highHue, p.highSat)
        val mid = 0.5f - 0.25f * p.balance
        val out = IntArray(px.size)
        // bảng trọng số theo độ chói 0..255 (rẻ hơn tính smoothstep cho từng điểm)
        val wh = FloatArray(256) { smooth(mid - SOFT, mid + SOFT, it / 255f) }
        for (i in px.indices) {
            val c = px[i]
            val r = ((c shr 16) and 255) / 255f
            val g = ((c shr 8) and 255) / 255f
            val b = (c and 255) / 255f
            val l = luma(r, g, b)
            val whi = wh[(l * 255f + 0.5f).toInt().coerceIn(0, 255)]
            val wsh = 1f - whi
            val nr = r + wsh * os[0] + whi * oh[0]
            val ng = g + wsh * os[1] + whi * oh[1]
            val nb = b + wsh * os[2] + whi * oh[2]
            out[i] = (c and (0xFF shl 24)) or
                ((nr * 255f + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                ((ng * 255f + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                (nb * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return out
    }

    /** Hue (độ) của một màu tên gọi; null nếu không nhận ra. Dùng cho bộ hiểu prompt. */
    fun hueOf(name: String): Float? = HUES.firstOrNull { (keys, _) -> keys.any { it == name } }?.second

    private val HUES: List<Pair<List<String>, Float>> = listOf(
        listOf("cam", "orange") to 28f,
        listOf("vang", "yellow", "gold", "golden") to 50f,
        listOf("xanh duong", "blue", "xanh") to 215f,
        listOf("xanh ngoc", "xanh lo", "xanh lam nhat", "teal", "cyan", "turquoise") to 185f,
        listOf("xanh la", "xanh luc", "green") to 125f,
        listOf("tim", "purple", "violet") to 275f,
        listOf("magenta") to 310f,
        listOf("hong", "pink") to 335f,
        listOf("do", "red") to 5f
    )

    /** Màu và dạng viết cho phép bộ hiểu prompt tự dò: trả về danh sách từ khóa (dài trước để "xanh la" thắng "xanh"). */
    val COLOR_WORDS: List<String> = HUES.flatMap { it.first }.sortedByDescending { it.length }

}
