package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Khoảng cách xấp xỉ (chamfer 3-4, đơn vị pixel) tới ô "seed" gần nhất; ô seed có khoảng cách 0. */
internal object DistanceField {
    private const val INF = 1_000_000_000

    fun chamfer(seed: BooleanArray, w: Int, h: Int): FloatArray {
        val d = IntArray(w * h) { if (seed[it]) 0 else INF }
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                var v = d[i]
                if (x > 0) v = min(v, d[i - 1] + 3)
                if (y > 0) {
                    v = min(v, d[i - w] + 3)
                    if (x > 0) v = min(v, d[i - w - 1] + 4)
                    if (x < w - 1) v = min(v, d[i - w + 1] + 4)
                }
                d[i] = v
            }
        }
        for (y in h - 1 downTo 0) {
            for (x in w - 1 downTo 0) {
                val i = y * w + x
                var v = d[i]
                if (x < w - 1) v = min(v, d[i + 1] + 3)
                if (y < h - 1) {
                    v = min(v, d[i + w] + 3)
                    if (x < w - 1) v = min(v, d[i + w + 1] + 4)
                    if (x > 0) v = min(v, d[i + w - 1] + 4)
                }
                d[i] = v
            }
        }
        return FloatArray(w * h) { d[it] / 3f }
    }
}

/**
 * Đo "độ khó" của một vùng cần xóa, để chọn engine hợp lý (PDF mục 4: chọn thuật toán theo độ phức tạp vùng xóa).
 *
 * Hai yếu tố, đều tính trên bản thu nhỏ nên rẻ ngay cả với ảnh lớn:
 *  - KÍCH THƯỚC hiệu dụng: đường kính hình tròn lớn nhất nằm lọt trong vùng xóa (độ dày), không phải diện tích —
 *    một sợi dây điện dài nhưng mảnh thì dễ, một khối to thì khó. Có thêm một phần nhỏ theo tổng diện tích.
 *  - CẤU TRÚC của nền quanh vùng xóa: tỷ lệ điểm có biên/độ chi tiết mạnh trong một vành đai quanh lỗ.
 *    Nền phẳng (trời, tường) → vùng lớn vẫn dễ; nền nhiều chi tiết/biên → vùng càng lớn càng cần model thần kinh.
 *
 * difficulty = size × (0.25 + 0.75 × structure), thuộc [0, 1]. Không phụ thuộc thiết bị hay model cụ thể;
 * ngưỡng dùng nó nằm trong cấu hình định tuyến (params.max_difficulty).
 */
object InpaintComplexity {

    data class Report(
        val difficulty: Float,
        /** Đường kính vùng xóa (độ dày lớn nhất) so với cạnh dài của ảnh. */
        val thicknessFrac: Float,
        val areaFrac: Float,
        /** 0 = nền phẳng, 1 = rất nhiều biên/chi tiết quanh vùng xóa. */
        val structure: Float,
        val holePx: Int
    ) {
        fun describe(): String {
            val size = when {
                thicknessFrac < 0.05f -> "nhỏ"
                thicknessFrac < 0.15f -> "vừa"
                else -> "lớn"
            }
            val bg = when {
                structure < 0.25f -> "nền đơn giản"
                structure < 0.6f -> "nền có chi tiết"
                else -> "nền phức tạp"
            }
            return "Vùng xóa $size, $bg (độ khó ${"%.2f".format(difficulty)})."
        }
    }

    private const val ANALYSIS_SIDE = 512
    private const val SIZE_THICK_LO = 0.01f
    private const val SIZE_THICK_SPAN = 0.30f
    private const val SIZE_AREA_LO = 0.02f
    private const val SIZE_AREA_SPAN = 0.45f
    private const val EDGE_LO = 6f
    private const val EDGE_SPAN = 24f
    private const val STRUCT_FULL = 0.35f

    fun analyze(src: Bitmap, mask: ByteArray): Report = analyze(readPixels(src), src.width, src.height, mask)

    fun analyze(px: IntArray, w: Int, h: Int, mask: ByteArray): Report {
        var holePx = 0
        for (i in 0 until w * h) if (mask[i].toInt() != 0) holePx++
        if (holePx == 0) return Report(0f, 0f, 0f, 0f, 0)
        val longSide = max(w, h)
        val k = max(1, ceil(longSide / ANALYSIS_SIDE.toFloat()).toInt())
        val aw = (w + k - 1) / k
        val ah = (h + k - 1) / k

        val hole = BooleanArray(aw * ah)
        val luma = FloatArray(aw * ah)
        for (ay in 0 until ah) {
            for (ax in 0 until aw) {
                var sum = 0f
                var n = 0
                var any = false
                val yEnd = min(h, (ay + 1) * k)
                val xEnd = min(w, (ax + 1) * k)
                for (y in ay * k until yEnd) {
                    val row = y * w
                    for (x in ax * k until xEnd) {
                        if (mask[row + x].toInt() != 0) { any = true } else {
                            val p = px[row + x]
                            sum += 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
                            n++
                        }
                    }
                }
                val i = ay * aw + ax
                hole[i] = any || n == 0
                luma[i] = if (n > 0) sum / n else 0f
            }
        }

        // 1) độ dày: khoảng cách lớn nhất từ một ô trong lỗ tới ô đã biết
        val known = BooleanArray(aw * ah) { !hole[it] }
        val dIn = DistanceField.chamfer(known, aw, ah)
        var maxIn = 0f
        for (i in hole.indices) if (hole[i] && dIn[i] < 1e6f && dIn[i] > maxIn) maxIn = dIn[i]
        if (known.none { it }) maxIn = max(aw, ah) / 2f
        val thicknessPx = 2f * maxIn * k
        val thicknessFrac = min(1f, thicknessPx / longSide)

        val areaFrac = holePx / (w.toFloat() * h)
        val sizeThick = ((thicknessFrac - SIZE_THICK_LO) / SIZE_THICK_SPAN).coerceIn(0f, 1f)
        val sizeArea = ((sqrt(areaFrac) - SIZE_AREA_LO) / SIZE_AREA_SPAN).coerceIn(0f, 1f)
        val size = max(sizeThick, 0.6f * sizeArea)

        // 2) cấu trúc nền trong vành đai quanh lỗ
        val dOut = DistanceField.chamfer(hole, aw, ah)
        val ringR = (maxIn * 0.5f).coerceIn(4f, 24f)
        var total = 0
        var acc = 0f
        for (y in 1 until ah - 1) {
            for (x in 1 until aw - 1) {
                val i = y * aw + x
                if (hole[i] || dOut[i] > ringR) continue
                if (hole[i - 1] || hole[i + 1] || hole[i - aw] || hole[i + aw]) continue
                val g = abs(luma[i + 1] - luma[i - 1]) * 0.5f + abs(luma[i + aw] - luma[i - aw]) * 0.5f
                acc += ((g - EDGE_LO) / EDGE_SPAN).coerceIn(0f, 1f)
                total++
            }
        }
        val structure = if (total < 8) 1f else (acc / total / STRUCT_FULL).coerceIn(0f, 1f)

        val difficulty = (size * (0.25f + 0.75f * structure)).coerceIn(0f, 1f)
        return Report(difficulty, thicknessFrac, areaFrac, structure, holePx)
    }
}
