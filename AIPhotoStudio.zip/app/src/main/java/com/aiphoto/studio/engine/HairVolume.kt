package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.sqrt

/**
 * Tăng volume tóc KHÔNG cần model sinh ảnh (R16): biến dạng ngược (backward warp) theo trường khoảng cách của mặt nạ tóc.
 *
 * Ý tưởng: mép tóc được đẩy ra ngoài đúng [growPx] điểm ảnh. Điểm p nằm ngoài tóc, cách mép tóc d (px), lấy màu từ điểm
 * p + hướng_về_tóc × dịch(d); dịch(d) = grow khi d ≤ grow (lấy mẫu từ BÊN TRONG tóc → vùng mới mang kết cấu tóc) rồi giảm mượt
 * (smoothstep) về 0 tại d = band = BAND_FACTOR × grow (ngoài dải ảnh không đổi, phần nền bị đẩy nhẹ ra xa chứ không bị nhân đôi).
 * Nguồn gốc d - dịch(d) tăng nghiêm ngặt nên ánh xạ không gập/không tạo vùng trùng lặp.
 *
 * Đầu vào mặt nạ tóc của MediaPipe là nearest-neighbour từ ảnh nhỏ (răng cưa) nên được làm mịn (hộp 2 lần) rồi nhị phân hóa ở 0,5;
 * hướng lấy từ gradient của khoảng cách đã làm mờ. [protect] (vd. da mặt) không bị phủ tóc; biên vùng bảo vệ được làm mềm.
 * Hạn chế đã biết: phồng ĐỀU quanh tóc (không có biến thiên hữu cơ) và không dựng thêm sợi tóc mảnh; tóc chạm vai/áo vẫn phồng sang đó.
 * Bản port kiểm tra số học: tools/verify_ports/hair_volume.py.
 */
object HairVolume {

    /** Độ phồng tối đa (px) = 2% cạnh dài ở cường độ 1. */
    const val MAX_GROW_FRAC = 0.02f

    /** Dải ảnh hưởng = 2,5 × độ phồng. */
    const val BAND_FACTOR = 2.5f

    /** Dưới ngưỡng này (px) coi như không làm gì. */
    const val MIN_GROW_PX = 0.75f

    private const val INF = 1e20f

    fun growPx(w: Int, h: Int, strength: Float): Float {
        val s = if (strength.isNaN()) 0f else strength.coerceIn(0f, 1f)
        return s * MAX_GROW_FRAC * max(w, h)
    }

    private fun smooth(t: Float): Float {
        val c = if (t < 0f) 0f else if (t > 1f) 1f else t
        return c * c * (3f - 2f * c)
    }

    /** Độ dịch (px) hướng về phía tóc tại khoảng cách d tính từ mép tóc. Đúng bằng [grow] khi d ≤ grow, về 0 tại d ≥ band. */
    fun shiftAt(d: Float, grow: Float, band: Float): Float =
        if (d >= band) 0f else grow * (1f - smooth((d - grow) / (band - grow)))

    /**
     * @param src ảnh ARGB (w×h), @param hair mặt nạ tóc 0/255 (w×h), @param protect vùng không được phủ tóc (0/255, hoặc null),
     * @param strength 0..1. Trả về mảng MỚI; không đổi gì thì trả bản sao của [src].
     */
    fun apply(src: IntArray, w: Int, h: Int, hair: ByteArray, protect: ByteArray?, strength: Float): IntArray {
        val n = w * h
        val grow = growPx(w, h, strength)
        if (grow < MIN_GROW_PX || w < 3 || h < 3 || src.size != n || hair.size != n) return src.copyOf()
        val r = max(1, max(w, h) / 300)

        // 1) làm mịn mặt nạ rồi nhị phân hóa
        val raw = FloatArray(n) { if (hair[it].toInt() != 0) 1f else 0f }
        val ms = boxBlur(boxBlur(raw, w, h, r), w, h, r)
        val inHair = BooleanArray(n) { ms[it] >= 0.5f }
        var any = false
        for (i in 0 until n) if (inHair[i]) { any = true; break }
        if (!any) return src.copyOf()

        // 2) khoảng cách Euclid chính xác tới tóc, rồi bản làm mờ để lấy hướng
        val d = distanceToHair(inHair, w, h)
        val dsm = boxBlur(d, w, h, 2)
        val band = grow * BAND_FACTOR

        // 3) trọng số bảo vệ (1 = được phép đổi)
        var keep: FloatArray? = null
        if (protect != null && protect.size == n) {
            val p = FloatArray(n) { if (protect[it].toInt() != 0) 1f else 0f }
            val pb = boxBlur(boxBlur(p, w, h, r), w, h, r)
            keep = FloatArray(n) { 1f - pb[it] }
        }

        val out = src.copyOf()
        for (y in 0 until h) {
            val yu = if (y > 0) y - 1 else y
            val yd = if (y < h - 1) y + 1 else y
            for (x in 0 until w) {
                val i = y * w + x
                if (inHair[i]) continue
                val di = d[i]
                if (di >= band) continue
                val wgt = if (keep != null) keep[i] else 1f
                if (wgt <= 0.001f) continue
                val xl = if (x > 0) x - 1 else x
                val xr = if (x < w - 1) x + 1 else x
                val gx = (dsm[y * w + xr] - dsm[y * w + xl]) / (xr - xl).toFloat()
                val gy = (dsm[yd * w + x] - dsm[yu * w + x]) / (yd - yu).toFloat()
                val gl = sqrt(gx * gx + gy * gy)
                if (gl < 1e-3f) continue
                val sh = shiftAt(di, grow, band)
                val sx = x - gx / gl * sh          // hướng VỀ phía tóc = -gradient của khoảng cách
                val sy = y - gy / gl * sh
                val c = sampleRgb(src, w, h, sx, sy)
                out[i] = if (wgt >= 0.999f) {
                    (src[i] and 0xFF000000.toInt()) or c
                } else {
                    (src[i] and 0xFF000000.toInt()) or mixRgb(src[i], c, wgt)
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ hạ tầng

    /** Hộp trượt (2r+1) tách trục, biên lặp lại (giống scipy uniform_filter mode='nearest'). */
    internal fun boxBlur(f: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(f.size)
        val out = FloatArray(f.size)
        val inv = 1f / (2 * r + 1)
        for (y in 0 until h) {
            val o = y * w
            var sum = 0f
            for (k in -r..r) sum += f[o + clampI(k, w)]
            for (x in 0 until w) {
                tmp[o + x] = sum * inv
                sum += f[o + clampI(x + r + 1, w)] - f[o + clampI(x - r, w)]
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (k in -r..r) sum += tmp[clampI(k, h) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum * inv
                sum += tmp[clampI(y + r + 1, h) * w + x] - tmp[clampI(y - r, h) * w + x]
            }
        }
        return out
    }

    private fun clampI(v: Int, n: Int): Int = if (v < 0) 0 else if (v > n - 1) n - 1 else v

    /** Khoảng cách Euclid (px) từ mỗi điểm tới điểm tóc gần nhất (Felzenszwalb & Huttenlocher); 0 trong tóc. Cần ít nhất một điểm tóc. */
    internal fun distanceToHair(inHair: BooleanArray, w: Int, h: Int): FloatArray {
        val f = FloatArray(w * h) { if (inHair[it]) 0f else INF }
        val m = max(w, h)
        val line = FloatArray(m)
        val res = FloatArray(m)
        val v = IntArray(m)
        val z = FloatArray(m + 1)
        for (x in 0 until w) {
            for (y in 0 until h) line[y] = f[y * w + x]
            dt1d(line, h, res, v, z)
            for (y in 0 until h) f[y * w + x] = res[y]
        }
        for (y in 0 until h) {
            for (x in 0 until w) line[x] = f[y * w + x]
            dt1d(line, w, res, v, z)
            for (x in 0 until w) f[y * w + x] = res[x]
        }
        for (i in f.indices) f[i] = sqrt(f[i])
        return f
    }

    private fun dt1d(f: FloatArray, n: Int, d: FloatArray, v: IntArray, z: FloatArray) {
        var k = 0
        v[0] = 0
        z[0] = -INF
        z[1] = INF
        for (q in 1 until n) {
            val fq = f[q] + q.toFloat() * q
            var s = (fq - (f[v[k]] + v[k].toFloat() * v[k])) / (2f * q - 2f * v[k])
            while (s <= z[k]) {
                k--
                s = (fq - (f[v[k]] + v[k].toFloat() * v[k])) / (2f * q - 2f * v[k])
            }
            k++
            v[k] = q
            z[k] = s
            z[k + 1] = INF
        }
        k = 0
        for (q in 0 until n) {
            while (z[k + 1] < q) k++
            val dx = (q - v[k]).toFloat()
            d[q] = dx * dx + f[v[k]]
        }
    }

    private fun ch(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()

    /** Nội suy song tuyến RGB (biên kẹp) -> 0xRRGGBB. */
    private fun sampleRgb(px: IntArray, w: Int, h: Int, sx: Float, sy: Float): Int {
        val fx = if (sx < 0f) 0f else if (sx > w - 1f) w - 1f else sx
        val fy = if (sy < 0f) 0f else if (sy > h - 1f) h - 1f else sy
        val x0 = fx.toInt()
        val y0 = fy.toInt()
        val x1 = if (x0 < w - 1) x0 + 1 else x0
        val y1 = if (y0 < h - 1) y0 + 1 else y0
        val tx = fx - x0
        val ty = fy - y0
        val a = px[y0 * w + x0]
        val b = px[y0 * w + x1]
        val c = px[y1 * w + x0]
        val e = px[y1 * w + x1]
        var rgb = 0
        var shift = 16
        while (shift >= 0) {
            val ca = (a shr shift) and 255
            val cb = (b shr shift) and 255
            val cc = (c shr shift) and 255
            val ce = (e shr shift) and 255
            val top = ca + (cb - ca) * tx
            val bot = cc + (ce - cc) * tx
            rgb = rgb or (ch(top + (bot - top) * ty) shl shift)
            shift -= 8
        }
        return rgb
    }

    private fun mixRgb(a: Int, rgbB: Int, t: Float): Int {
        var rgb = 0
        var shift = 16
        while (shift >= 0) {
            val ca = ((a shr shift) and 255).toFloat()
            val cb = ((rgbB shr shift) and 255).toFloat()
            rgb = rgb or (ch(ca + (cb - ca) * t) shl shift)
            shift -= 8
        }
        return rgb
    }
}
