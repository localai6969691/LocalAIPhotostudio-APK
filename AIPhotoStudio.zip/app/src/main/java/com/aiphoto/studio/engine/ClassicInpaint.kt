package com.aiphoto.studio.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** Giao diện chung cho mọi engine xóa vật thể (LaMa, thuật toán cổ điển, MI-GAN... sau này). Mặt nạ: != 0 = vùng cần lấp. */
interface Inpainter {
    /** Chế độ THƯỜNG: vùng lấp được nới vài điểm ảnh ra ngoài mặt nạ và hòa mép (ít lộ đường nối, nuốt viền/bóng của vật thể). */
    fun inpaint(src: Bitmap, mask: ByteArray): Bitmap

    /**
     * Chế độ CHÍNH XÁC: chỉ đổi ĐÚNG các điểm có mặt nạ != 0 (không nới, không hòa mép) → mọi điểm ngoài mặt nạ giữ nguyên từng bit.
     * Nội dung lấp vẫn là nội dung được sinh ra, không phải khôi phục lại thứ từng ở đó.
     */
    fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap

    /**
     * true = engine này chạy ở độ phân giải CỐ ĐỊNH nên mặt nạ lớn nên được chia ô ([TiledInpaint]) để mỗi lần nhìn vùng nhỏ → giữ chi tiết.
     * false = engine tự xử lý mặt nạ lớn (cắt vùng + tháp ảnh) nên chia ô chỉ thêm đường nối.
     */
    val needsTiling: Boolean get() = true
}

/**
 * Phương án dự phòng KHÔNG cần model: lấp vùng trống bằng push-pull (từ thô đến mịn) rồi khuếch tán làm mượt.
 * Hợp với nền đơn giản (trời, tường, cỏ); với vật thể lớn trên nền phức tạp sẽ bị mờ - khi đó nên nạp LaMa.
 */
object ClassicInpaint : Inpainter {

    override val needsTiling: Boolean get() = false

    override fun inpaint(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = false)

    override fun inpaintExact(src: Bitmap, mask: ByteArray): Bitmap = run(src, mask, exact = true)

    private fun run(src: Bitmap, mask: ByteArray, exact: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (mask[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return src

        val grow = if (exact) 0 else max(2, max(w, h) / 400)
        val margin = max(12, max(maxX - minX, maxY - minY) / 3) + grow
        val x0 = max(0, minX - margin)
        val y0 = max(0, minY - margin)
        val x1 = min(w, maxX + 1 + margin)
        val y1 = min(h, maxY + 1 + margin)
        val cw = x1 - x0
        val ch = y1 - y0

        val crop = IntArray(cw * ch)
        src.getPixels(crop, 0, cw, x0, y0, cw, ch)
        val edge = InpaintEdge.build(mask, w, x0, y0, cw, ch, grow, max(2, max(cw, ch) / 150), exact)
        val filled = pushPull(crop, edge.hole, cw, ch)

        val out = IntArray(w * h)
        src.getPixels(out, 0, w, 0, 0, w, h)
        InpaintEdge.paste(out, w, x0, y0, cw, ch, filled, edge.alpha)
        return makeBitmap(out, w, h)
    }

    private class Lv(val w: Int, val h: Int) {
        val r = FloatArray(w * h)
        val g = FloatArray(w * h)
        val b = FloatArray(w * h)
        val ok = BooleanArray(w * h)
    }

    internal fun pushPull(px: IntArray, hole: BooleanArray, w: Int, h: Int): IntArray {
        val l0 = Lv(w, h)
        for (i in px.indices) {
            if (!hole[i]) {
                l0.r[i] = ((px[i] shr 16) and 255).toFloat()
                l0.g[i] = ((px[i] shr 8) and 255).toFloat()
                l0.b[i] = (px[i] and 255).toFloat()
                l0.ok[i] = true
            }
        }
        val levels = ArrayList<Lv>()
        levels.add(l0)
        var cur = l0
        // Pull: thu nhỏ dần, mỗi ô thô = trung bình các ô con đã biết
        while (cur.w > 1 || cur.h > 1) {
            val nw = (cur.w + 1) / 2
            val nh = (cur.h + 1) / 2
            val nl = Lv(nw, nh)
            for (y in 0 until nh) {
                for (x in 0 until nw) {
                    var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
                    for (dy in 0..1) for (dx in 0..1) {
                        val sx = 2 * x + dx
                        val sy = 2 * y + dy
                        if (sx < cur.w && sy < cur.h) {
                            val i = sy * cur.w + sx
                            if (cur.ok[i]) { sr += cur.r[i]; sg += cur.g[i]; sb += cur.b[i]; n++ }
                        }
                    }
                    if (n > 0) {
                        val j = y * nw + x
                        nl.r[j] = sr / n; nl.g[j] = sg / n; nl.b[j] = sb / n; nl.ok[j] = true
                    }
                }
            }
            levels.add(nl)
            cur = nl
        }
        // Push: từ thô xuống mịn, ô trống lấy màu từ ô thô tương ứng
        for (k in levels.size - 2 downTo 0) {
            val f = levels[k]
            val c = levels[k + 1]
            for (y in 0 until f.h) {
                for (x in 0 until f.w) {
                    val i = y * f.w + x
                    if (!f.ok[i]) {
                        val j = (y / 2) * c.w + (x / 2)
                        if (c.ok[j]) { f.r[i] = c.r[j]; f.g[i] = c.g[j]; f.b[i] = c.b[j]; f.ok[i] = true }
                    }
                }
            }
        }
        // Làm mượt (Gauss-Seidel) chỉ trên vùng trống
        repeat(40) {
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val i = y * w + x
                    if (!hole[i]) continue
                    var sr = 0f; var sg = 0f; var sb = 0f; var n = 0
                    if (x > 0) { val j = i - 1; sr += l0.r[j]; sg += l0.g[j]; sb += l0.b[j]; n++ }
                    if (x < w - 1) { val j = i + 1; sr += l0.r[j]; sg += l0.g[j]; sb += l0.b[j]; n++ }
                    if (y > 0) { val j = i - w; sr += l0.r[j]; sg += l0.g[j]; sb += l0.b[j]; n++ }
                    if (y < h - 1) { val j = i + w; sr += l0.r[j]; sg += l0.g[j]; sb += l0.b[j]; n++ }
                    if (n > 0) { l0.r[i] = sr / n; l0.g[i] = sg / n; l0.b[i] = sb / n }
                }
            }
        }
        val out = IntArray(px.size)
        for (i in px.indices) {
            out[i] = if (hole[i]) {
                (255 shl 24) or
                    (l0.r[i].toInt().coerceIn(0, 255) shl 16) or
                    (l0.g[i].toInt().coerceIn(0, 255) shl 8) or
                    l0.b[i].toInt().coerceIn(0, 255)
            } else px[i]
        }
        return out
    }
}

/**
 * Xử lý mặt nạ lớn theo từng ô (tile) để mỗi lần model chỉ nhìn vùng nhỏ -> chi tiết tốt hơn, ít tràn RAM.
 * Mỗi ô nhìn thấy kết quả của các ô trước (lấp tuần tự).
 *
 * Trước khi chạy, các điểm mặt nạ được điền TẠM bằng ước lượng nền thô (push-pull). Nếu không, mỗi ô chỉ che đúng phần của nó và
 * để nguyên phần vật thể còn lại của các ô sau trong ảnh: engine coi đó là nền hợp lệ và lấp bằng chính màu vật thể
 * (đo: xóa đĩa đỏ bán kính 300 trên nền xanh, vùng lấp vẫn đỏ ~83–107/190 khi chia ô, ~0 khi không chia).
 */
object TiledInpaint {
    /** [exact] = gọi [Inpainter.inpaintExact] cho từng ô (chỉ đổi đúng điểm có mặt nạ). */
    fun run(src: Bitmap, mask: ByteArray, engine: Inpainter, tile: Int = 384, maxTiles: Int = 16, exact: Boolean = false): Bitmap {
        fun fill(img: Bitmap, m: ByteArray): Bitmap = if (exact) engine.inpaintExact(img, m) else engine.inpaint(img, m)
        val w = src.width
        val h = src.height
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (mask[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return src
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        val nx = (bw + tile - 1) / tile
        val ny = (bh + tile - 1) / tile
        if (!engine.needsTiling || max(bw, bh) <= tile * 5 / 4 || nx * ny > maxTiles) return fill(src, mask)

        // Che vật thể ở các ô chưa xử lý bằng ước lượng nền thô để engine không "nhìn" thấy nó như nền hợp lệ.
        var cur = ClassicInpaint.inpaintExact(src, mask)
        for (ty in 0 until ny) {
            for (tx in 0 until nx) {
                val xa = minX + tx * tile
                val ya = minY + ty * tile
                val xb = min(xa + tile, maxX + 1)
                val yb = min(ya + tile, maxY + 1)
                val sub = ByteArray(w * h)
                var any = false
                for (y in ya until yb) for (x in xa until xb) {
                    val i = y * w + x
                    if (mask[i].toInt() != 0) { sub[i] = 255.toByte(); any = true }
                }
                if (any) cur = fill(cur, sub)
            }
        }
        return cur
    }
}
