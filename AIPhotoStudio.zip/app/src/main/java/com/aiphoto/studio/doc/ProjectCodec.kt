package com.aiphoto.studio.doc

import android.graphics.Bitmap
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.sanitized
import org.json.JSONArray
import org.json.JSONObject

/**
 * R11 — Lưu / khôi phục PHIÊN LÀM VIỆC không phá hủy (PDF: "quay lại và thay đổi bất kỳ thông số nào mà không làm hỏng ảnh gốc").
 * Phần này chỉ làm việc với JSON (org.json) nên kiểm thử được trên JVM; dữ liệu nhị phân (ảnh nền, mảng vá, mặt nạ tô tay)
 * nằm ở tệp riêng do [ProjectStore] ghi, JSON chỉ giữ TÊN tệp.
 *
 * Định dạng: { "v":1, "savedAt":ms, "w":W, "h":H, "bg":"tệp", "idCounter":N, "layers":[ ... ] }
 *  - lớp chỉnh: { "t":"adj", id, name, visible, opacity, blend, kind, scope?, ops:[...], mask? }
 *  - lớp vá:    { "t":"patch", id, name, x, y, file, visible, opacity, blend, mask? }
 *  - mặt nạ tô tay: { "t":"painted", file, w, h, invert, feather, shift }
 */
object ProjectCodec {
    const val VERSION = 1

    class Meta(val savedAt: Long, val w: Int, val h: Int, val bgFile: String, val idCounter: Long)

    /** Tên các tệp nhị phân mà JSON này tham chiếu (để dọn tệp thừa). */
    fun referencedFiles(json: JSONObject): Set<String> {
        val out = HashSet<String>()
        json.optString("bg", "").takeIf { it.isNotBlank() }?.let { out.add(it) }
        val arr = json.optJSONArray("layers") ?: return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            o.optString("file", "").takeIf { it.isNotBlank() }?.let { out.add(it) }
            o.optJSONObject("mask")?.optString("file", "")?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        }
        return out
    }

    fun encode(
        meta: Meta,
        layers: List<Layer>,
        patchFile: (PatchLayer) -> String,
        maskFile: (Long, MaskSpec.Painted) -> String,
        imageFile: (OverlayLayer) -> String
    ): JSONObject {
        val arr = JSONArray()
        for (l in layers) {
            val o = JSONObject()
                .put("id", l.id).put("name", l.name).put("visible", l.visible)
                .put("opacity", l.opacity.toDouble()).put("blend", l.blend.name).put("clip", l.clip)
            when (l) {
                is AdjustmentLayer -> {
                    o.put("t", "adj").put("kind", l.kind)
                    if (l.scope != null) o.put("scope", l.scope)
                    val ops = JSONArray()
                    l.ops.forEach { ops.put(opToJson(it)) }
                    o.put("ops", ops)
                }
                is PatchLayer -> o.put("t", "patch").put("x", l.x).put("y", l.y).put("file", patchFile(l))
                is OverlayLayer -> {
                    o.put("t", "overlay").put("kind", l.kind).put("text", l.text).put("color", l.color)
                        .put("bold", l.bold).put("outline", l.outline)
                        .put("cx", l.cx.toDouble()).put("cy", l.cy.toDouble())
                        .put("size", l.size.toDouble()).put("rotation", l.rotation.toDouble())
                        .put("harmonize", l.harmonize.toDouble())
                    if (l.kind == "image" && l.image != null) o.put("file", imageFile(l))
                }
            }
            l.mask?.let { o.put("mask", maskJson(it, l.id, maskFile)) }
            arr.put(o)
        }
        return JSONObject().put("v", VERSION).put("savedAt", meta.savedAt).put("w", meta.w).put("h", meta.h)
            .put("bg", meta.bgFile).put("idCounter", meta.idCounter).put("layers", arr)
    }

    private fun maskJson(m: LayerMask, layerId: Long, maskFile: (Long, MaskSpec.Painted) -> String): JSONObject {
        val sp = m.spec
        if (sp is MaskSpec.Painted) {
            return JSONObject().put("t", "painted").put("file", maskFile(layerId, sp)).put("w", sp.w).put("h", sp.h)
                .put("invert", m.invert).put("feather", m.feather.toDouble()).put("shift", m.shift.toDouble())
        }
        return maskToJson(m)
    }

    fun meta(json: JSONObject): Meta? {
        if (json.optInt("v", 0) != VERSION) return null
        val bg = json.optString("bg", "")
        val w = json.optInt("w", 0)
        val h = json.optInt("h", 0)
        if (bg.isBlank() || w <= 0 || h <= 0) return null
        return Meta(json.optLong("savedAt", 0L), w, h, bg, json.optLong("idCounter", 1L))
    }

    fun layerCount(json: JSONObject): Int = json.optJSONArray("layers")?.length() ?: 0

    /**
     * Dựng lại danh sách lớp. [loadPatch] / [loadMask] đọc tệp nhị phân (trả null nếu mất/hỏng → lớp đó bị bỏ qua, không làm hỏng cả phiên).
     * Phép chỉnh được [sanitized] lại; id trùng bị loại; [maxId] trả id lớn nhất để phía gọi đặt lại bộ đếm id.
     */
    fun decode(
        json: JSONObject,
        bgW: Int,
        bgH: Int,
        loadPatch: (String) -> Bitmap?,
        loadMask: (String, Int, Int) -> ByteArray?
    ): Decoded {
        val out = ArrayList<Layer>()
        val seen = HashSet<Long>()
        var maxId = 0L
        var skipped = 0
        val arr = json.optJSONArray("layers") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o == null) { skipped++; continue }
            val id = o.optLong("id", -1L)
            if (id <= 0L || !seen.add(id)) { skipped++; continue }
            val blend = runCatching { BlendMode.valueOf(o.optString("blend", "NORMAL")) }.getOrDefault(BlendMode.NORMAL)
            val opacity = o.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f)
            val visible = o.optBoolean("visible", true)
            val clip = o.optBoolean("clip", false)
            val name = o.optString("name", "Lớp").take(80)
            var mask: LayerMask? = null
            val mo = o.optJSONObject("mask")
            if (mo != null) {
                mask = if (mo.optString("t") == "painted") {
                    val w = mo.optInt("w", 0)
                    val h = mo.optInt("h", 0)
                    val data = if (w > 0 && h > 0) loadMask(mo.optString("file", ""), w, h) else null
                    if (data == null || data.size != w * h) null
                    else LayerMask(
                        MaskSpec.Painted(data, w, h), mo.optBoolean("invert", false),
                        mo.optDouble("feather", 0.02).toFloat(), mo.optDouble("shift", 0.0).toFloat()
                    )
                } else maskFromJson(mo)
                if (mask == null) { skipped++; continue } // mặt nạ hỏng: bỏ cả lớp thay vì áp phép chỉnh lên toàn ảnh
            }
            val layer: Layer? = when (o.optString("t")) {
                "adj" -> {
                    val ops = ArrayList<EditOp>()
                    val oa = o.optJSONArray("ops") ?: JSONArray()
                    for (j in 0 until oa.length()) {
                        val op = oa.optJSONObject(j)?.let { opFromJson(it) }?.sanitized() ?: continue
                        ops.add(op)
                    }
                    AdjustmentLayer(
                        id, name, ops, visible, opacity, blend, mask,
                        kind = o.optString("kind", "basic"),
                        scope = o.optString("scope", "").ifBlank { null },
                        clip = clip
                    )
                }
                "patch" -> {
                    val bmp = loadPatch(o.optString("file", ""))
                    val x = o.optInt("x", 0)
                    val y = o.optInt("y", 0)
                    if (bmp == null || x < 0 || y < 0 || x + bmp.width > bgW || y + bmp.height > bgH) null
                    else PatchLayer(id, name, x, y, bmp, visible, opacity, blend, mask, clip = clip)
                }
                "overlay" -> {
                    val kind = o.optString("kind", "text")
                    val img = if (kind == "image") loadPatch(o.optString("file", "")) else null
                    if (kind != "text" && kind != "image") null
                    else if (kind == "image" && img == null) null
                    else OverlayLayer.clampParams(
                        OverlayLayer(
                            id, name, kind,
                            text = o.optString("text", ""), color = o.optInt("color", -1),
                            bold = o.optBoolean("bold", true), outline = o.optBoolean("outline", true), image = img,
                            cx = o.optDouble("cx", 0.5).toFloat(), cy = o.optDouble("cy", 0.5).toFloat(),
                            size = o.optDouble("size", 0.12).toFloat(), rotation = o.optDouble("rotation", 0.0).toFloat(),
                            visible = visible, opacity = opacity, blend = blend, mask = mask, clip = clip,
                            harmonize = o.optDouble("harmonize", 0.0).toFloat()
                        )
                    )
                }
                else -> null
            }
            if (layer == null) { skipped++; continue }
            out.add(layer)
            if (id > maxId) maxId = id
        }
        return Decoded(out, maxId, skipped)
    }

    class Decoded(val layers: List<Layer>, val maxId: Long, val skipped: Int)
}
