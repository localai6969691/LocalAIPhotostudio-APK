package com.aiphoto.studio.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * R12 — Quick Selection (PDF: Quick Selection / Object Selection của Photoshop): người dùng tô một nét NGẮN bên trong vật,
 * vùng chọn tự lan ra toàn bộ phần liên thông có màu giống nét tô và dừng ở cạnh. Không cần model.
 *
 * Mô hình màu = trung vị + MAD (độ lệch bền vững) từng kênh của các điểm nét tô (ảnh đã làm mờ hộp 3x3 để bớt nhiễu).
 * Điểm q được nhận nếu: (1) khoảng cách màu chuẩn hóa tới mô hình ≤ k(tolerance), và (2) bước màu từ điểm liền kề đã nhận
 * ≤ ngưỡng cạnh (không trượt qua cạnh mạnh dù hai bên có màu gần nhau). Sau đó điền lỗ kín và làm mượt biên bằng lọc đa số 3x3.
 * Bản port Python: tools/verify_ports/quick_select.py.
 */
object QuickSelect {

    private const val SIGMA_MIN = 7f
    private const val SIGMA_MAX = 40f

    /** Trung vị từ histogram 256 mức. */
    private fun median(hist: IntArray, cnt: Int): Int {
        var acc = 0
        for (v in 0..255) { acc += hist[v]; if (acc * 2 >= cnt) return v }
        return 255
    }

    /** Độ lệch tuyệt đối trung vị (MAD) quanh [med] từ histogram. */
    private fun mad(hist: IntArray, cnt: Int, med: Int): Float {
        val dev = IntArray(256)
        for (v in 0..255) dev[kotlin.math.abs(v - med)] += hist[v]
        return median(dev, cnt).toFloat()
    }

    fun select(px: IntArray, w: Int, h: Int, seeds: ByteArray, tolerance: Float): ByteArray {
        val n = w * h
        val out = ByteArray(max(0, n))
        if (px.size != n || seeds.size != n || w < 3 || h < 3) return out
        val tol = tolerance.coerceIn(0f, 1f)

        // làm mờ hộp 3x3 từng kênh
        val br = IntArray(n); val bg = IntArray(n); val bb = IntArray(n)
        for (y in 0 until h) {
            val y0 = max(0, y - 1); val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1); val x1 = min(w - 1, x + 1)
                var sr = 0; var sg = 0; var sb = 0; var c = 0
                for (yy in y0..y1) for (xx in x0..x1) {
                    val p = px[yy * w + xx]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; c++
                }
                val i = y * w + x
                br[i] = sr / c; bg[i] = sg / c; bb[i] = sb / c
            }
        }

        // mô hình màu từ điểm hạt giống: trung vị + MAD (bền vững — nét tô lỡ chạm vài điểm ngoại lai không phá mô hình)
        val hr = IntArray(256); val hg = IntArray(256); val hb = IntArray(256)
        var cnt = 0
        for (i in 0 until n) if (seeds[i].toInt() != 0) { hr[br[i]]++; hg[bg[i]]++; hb[bb[i]]++; cnt++ }
        if (cnt == 0) return out
        val mr = median(hr, cnt); val mg = median(hg, cnt); val mb = median(hb, cnt)
        val sr = max(SIGMA_MIN, min(SIGMA_MAX, 1.4826f * mad(hr, cnt, mr)))
        val sg = max(SIGMA_MIN, min(SIGMA_MAX, 1.4826f * mad(hg, cnt, mg)))
        val sb = max(SIGMA_MIN, min(SIGMA_MAX, 1.4826f * mad(hb, cnt, mb)))
        val k = 1.5f + 3.5f * tol
        val stepMax = 20f + 50f * tol
        val inv3 = 1f / 3f

        fun near(i: Int): Boolean {
            val a = (br[i] - mr) / sr
            val b = (bg[i] - mg) / sg
            val c = (bb[i] - mb) / sb
            return sqrt((a * a + b * b + c * c) * inv3) <= k
        }

        val sel = BooleanArray(n)
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        for (i in 0 until n) if (seeds[i].toInt() != 0) { sel[i] = true; queue[tail++] = i }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            for (d in 0 until 4) {
                val nx = x + (if (d == 0) -1 else if (d == 1) 1 else 0)
                val ny = y + (if (d == 2) -1 else if (d == 3) 1 else 0)
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (sel[j] || !near(j)) continue
                val dr = (br[i] - br[j]).toFloat(); val dg = (bg[i] - bg[j]).toFloat(); val db = (bb[i] - bb[j]).toFloat()
                if (sqrt(dr * dr + dg * dg + db * db) > stepMax) continue
                sel[j] = true
                queue[tail++] = j
            }
        }

        // điền lỗ kín: phần bù không nối tới viền ảnh
        val outside = BooleanArray(n)
        head = 0; tail = 0
        fun seedOutside(x: Int, y: Int) {
            val i = y * w + x
            if (!sel[i] && !outside[i]) { outside[i] = true; queue[tail++] = i }
        }
        for (y in 0 until h) { seedOutside(0, y); seedOutside(w - 1, y) }
        for (x in 0 until w) { seedOutside(x, 0); seedOutside(x, h - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            for (d in 0 until 4) {
                val nx = x + (if (d == 0) -1 else if (d == 1) 1 else 0)
                val ny = y + (if (d == 2) -1 else if (d == 3) 1 else 0)
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (sel[j] || outside[j]) continue
                outside[j] = true
                queue[tail++] = j
            }
        }
        // chỉ điền lỗ NHỎ (≤ 4% vùng chọn): đồng tử, chấm sáng... Vật lớn nằm lọt trong vùng chọn (vd. tô nền) không bị nuốt
        var selCount = 0
        for (i in 0 until n) if (sel[i]) selCount++
        val holeLimit = (0.04f * selCount).toInt()
        for (i in 0 until n) {
            if (sel[i] || outside[i]) continue
            var qh = 0
            var qt = 0
            queue[qt++] = i
            outside[i] = true
            while (qh < qt) {
                val c = queue[qh++]
                val cx = c % w
                val cy = c / w
                for (d in 0 until 4) {
                    val nx = cx + (if (d == 0) -1 else if (d == 1) 1 else 0)
                    val ny = cy + (if (d == 2) -1 else if (d == 3) 1 else 0)
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (sel[j] || outside[j]) continue
                    outside[j] = true
                    queue[qt++] = j
                }
            }
            if (qt <= holeLimit) for (m in 0 until qt) sel[queue[m]] = true
        }

        // lọc đa số 3x3 làm mượt biên (điểm được giữ nếu ≥ 5/9 lân cận thuộc vùng chọn; mép ảnh tính phần ngoài là "chưa chọn")
        for (y in 0 until h) for (x in 0 until w) {
            var c = 0
            for (yy in max(0, y - 1)..min(h - 1, y + 1)) for (xx in max(0, x - 1)..min(w - 1, x + 1)) if (sel[yy * w + xx]) c++
            if (c >= 5) out[y * w + x] = 255.toByte()
        }
        // hạt giống luôn nằm trong vùng chọn dù lọc đa số có thể làm mòn nét tô rất mảnh
        for (i in 0 until n) if (seeds[i].toInt() != 0) out[i] = 255.toByte()
        return out
    }
}
