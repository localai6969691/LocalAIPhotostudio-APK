package com.aiphoto.studio.ai

import android.content.Context
import java.io.File

/** Chọn backend theo ĐUÔI tệp model: .litertlm -> LiteRT-LM (cần -PuseLiteRtLm=true), còn lại -> MediaPipe (.task/.bin). */
object LlmBackends {

    fun isLiteRtLm(modelPath: String): Boolean = modelPath.endsWith(".litertlm", ignoreCase = true)

    /**
     * Model được sao chép về tên cố định (llm.litertlm) nên tên tệp GỐC - có hậu tố SoC cho biết đây có phải bản biên dịch NPU cho đúng chip
     * này không ([AcceleratorPolicy]) - được lưu cạnh model trong `<đường dẫn>.name`. Null nếu không có.
     */
    fun originalName(modelPath: String): String? = runCatching {
        File("$modelPath.name").takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotEmpty() }
    }.getOrNull()

    fun writeOriginalName(modelPath: String, name: String?) {
        val f = File("$modelPath.name")
        runCatching { if (name.isNullOrBlank()) f.delete() else f.writeText(name.trim()) }
    }

    fun create(context: Context, modelPath: String): TextGen =
        if (isLiteRtLm(modelPath)) {
            LiteRtLmFactory.create(context, modelPath, originalName(modelPath))
                ?: throw IllegalStateException("Model .litertlm cần bản build có LiteRT-LM (build với -PuseLiteRtLm=true).")
        } else {
            MediaPipeTextGen(context, modelPath)
        }
}
