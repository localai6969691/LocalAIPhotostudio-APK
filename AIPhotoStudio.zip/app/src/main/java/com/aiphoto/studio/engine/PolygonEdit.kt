package com.aiphoto.studio.engine

import kotlin.math.hypot
import kotlin.math.max

/**
 * R19 — Sửa điểm của vùng lasso (mặt nạ vector [PolygonFill]): chọn điểm gần ngón tay, kéo điểm, chèn điểm lên cạnh, xóa điểm.
 * Thuần Kotlin, bất biến (mỗi hàm trả danh sách mới). Khoảng cách tính theo điểm ảnh tương đối ([aspect] = rộng / cao) nên "bán kính chạm"
 * là hình tròn thật, không bị bầu theo khung ảnh. Tọa độ theo thang 0..1 như [PolygonFill].
 */
object PolygonEdit {
    const val MIN_POINTS = 3

    private fun dist(a: Pt, b: Pt, aspect: Float) = hypot((a.x - b.x) * aspect, a.y - b.y)

    /** Chỉ số điểm gần [p] nhất trong bán kính [radius] (theo đơn vị chiều CAO ảnh); -1 nếu không có. */
    fun nearestVertex(pts: List<Pt>, p: Pt, radius: Float, aspect: Float = 1f): Int {
        var best = -1
        var bd = radius
        for (i in pts.indices) {
            val d = dist(pts[i], p, aspect)
            if (d <= bd) { bd = d; best = i }
        }
        return best
    }

    /** Cạnh i nối pts[i] → pts[(i+1)%n]; kết quả cạnh gần [p] nhất trong bán kính [radius] kèm hình chiếu của p lên cạnh. */
    class EdgeHit(val edge: Int, val at: Pt)

    fun nearestEdge(pts: List<Pt>, p: Pt, radius: Float, aspect: Float = 1f): EdgeHit? {
        var best: EdgeHit? = null
        var bd = radius
        val n = pts.size
        if (n < 2) return null
        for (i in 0 until n) {
            val a = pts[i]
            val b = pts[(i + 1) % n]
            val ax = a.x * aspect
            val bx = b.x * aspect
            val px = p.x * aspect
            val dx = bx - ax
            val dy = b.y - a.y
            val len2 = dx * dx + dy * dy
            val t = if (len2 <= 1e-12f) 0f else (((px - ax) * dx + (p.y - a.y) * dy) / len2).coerceIn(0f, 1f)
            val cx = ax + t * dx
            val cy = a.y + t * dy
            val d = hypot(px - cx, p.y - cy)
            if (d <= bd) { bd = d; best = EdgeHit(i, Pt(cx / max(aspect, 1e-6f), cy)) }
        }
        return best
    }

    /** Đặt điểm [i] về [to] (kẹp trong ảnh). */
    fun moved(pts: List<Pt>, i: Int, to: Pt): List<Pt> {
        if (i !in pts.indices) return pts
        val out = ArrayList(pts)
        out[i] = Pt(to.x.coerceIn(0f, 1f), to.y.coerceIn(0f, 1f))
        return out
    }

    /** Chèn điểm [at] lên cạnh [edge] (thành điểm có chỉ số edge+1); quá [PolygonFill.MAX_POINTS] thì giữ nguyên. */
    fun inserted(pts: List<Pt>, edge: Int, at: Pt): List<Pt> {
        if (edge !in pts.indices || pts.size >= PolygonFill.MAX_POINTS) return pts
        val out = ArrayList(pts)
        out.add(edge + 1, Pt(at.x.coerceIn(0f, 1f), at.y.coerceIn(0f, 1f)))
        return out
    }

    /** Xóa điểm [i]; trả null nếu chỉ còn dưới [MIN_POINTS] điểm (không còn là vùng). */
    fun removed(pts: List<Pt>, i: Int): List<Pt>? {
        if (i !in pts.indices || pts.size <= MIN_POINTS) return null
        val out = ArrayList(pts)
        out.removeAt(i)
        return out
    }
}
