package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.graphics.Bitmap
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * PHÓNG TO bằng AI (super-resolution) với Real-ESRGAN-General-x4v3 dạng ONNX (≈1.2M tham số, ~4.7 MB, nhập tĩnh 128×128,
 * hệ số ×4; checkpoint gốc giấy phép BSD-3 - bản ONNX dựng sẵn của Qualcomm AI Hub có giấy phép riêng, cần đọc kỹ trước khi
 * dùng thương mại, hoặc tự xuất ONNX từ checkpoint BSD-3). Nhập/xuất float32 NCHW trong [0,1].
 * Xử lý theo ô (tile) có viền chồng 10px như script chính thức để vừa mọi dung lượng RAM; kích thước ô và hệ số ×N đọc từ
 * model lúc chạy. Muốn phóng ×2: thu nhỏ ảnh về 1/2 rồi cho model ×4 -> ra đúng ×2 mà vẫn dùng chi tiết do AI tạo ra.
 */
class OnnxUpscaler(modelPath: String) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession = OrtTuning.createSession(env, modelPath)
    private val inName: String = session.inputNames.iterator().next()
    private val tile: Int
    private var scale: Int = 4

    init {
        val shape = (session.inputInfo[inName]?.info as? TensorInfo)?.shape
        tile = if (shape != null && shape.size == 4 && shape[2] > 0) shape[2].toInt() else 128
    }

    /** factor: hệ số mong muốn (2..4). Kết quả có cạnh dài tối đa [maxLongSide]. */
    @Synchronized
    fun upscale(src: Bitmap, factor: Int, maxLongSide: Int = 4096): Bitmap {
        val f = min(factor.toFloat(), maxLongSide.toFloat() / max(src.width, src.height))
        if (f < 1.25f) return src

        // 1) đưa ảnh vào kích thước mà ×scale của model cho ra đúng ảnh đích
        val inW = max(8, (src.width * f / scale).roundToInt())
        val inH = max(8, (src.height * f / scale).roundToInt())
        val input = if (inW == src.width && inH == src.height) src else Bitmap.createScaledBitmap(src, inW, inH, true)
        val px = readPixels(input)

        val pad = 10
        val core = tile - 2 * pad
        val outW = inW * scale
        val outH = inH * scale
        val out = IntArray(outW * outH)
        val plane = tile * tile
        val data = FloatArray(3 * plane)
        val shape = longArrayOf(1, 3, tile.toLong(), tile.toLong())

        var y0 = 0
        while (y0 < inH) {
            val ch = min(core, inH - y0)
            var x0 = 0
            while (x0 < inW) {
                val cw = min(core, inW - x0)
                // ô đầu vào 128×128, lấy mẫu có kẹp biên (lặp pixel mép) để ô cuối không bị đệm đen
                for (j in 0 until tile) {
                    val sy = (y0 - pad + j).coerceIn(0, inH - 1)
                    for (i in 0 until tile) {
                        val sx = (x0 - pad + i).coerceIn(0, inW - 1)
                        val p = px[sy * inW + sx]
                        val k = j * tile + i
                        data[k] = ((p shr 16) and 255) / 255f
                        data[plane + k] = ((p shr 8) and 255) / 255f
                        data[2 * plane + k] = (p and 255) / 255f
                    }
                }
                OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { t ->
                    session.run(mapOf(inName to t)).use { r ->
                        val o = r.get(0) as OnnxTensor
                        val fb = o.floatBuffer
                        val os = o.info.shape                       // [1,3,tile*scale,tile*scale]
                        val oh = os[2].toInt()
                        val ow = os[3].toInt()
                        scale = max(1, ow / tile)
                        val oplane = oh * ow
                        // chỉ chép phần lõi (bỏ viền đệm)
                        for (yy in 0 until ch * scale) {
                            val oy = pad * scale + yy
                            val dy = y0 * scale + yy
                            if (dy >= outH) break
                            for (xx in 0 until cw * scale) {
                                val ox = pad * scale + xx
                                val dx = x0 * scale + xx
                                if (dx >= outW) break
                                val idx = oy * ow + ox
                                val rr = (fb.get(idx) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                val gg = (fb.get(oplane + idx) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                val bb = (fb.get(2 * oplane + idx) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                out[dy * outW + dx] = (255 shl 24) or (rr shl 16) or (gg shl 8) or bb
                            }
                        }
                    }
                }
                x0 += core
            }
            y0 += core
        }
        return makeBitmap(out, outW, outH)
    }

    override fun close() {
        try { session.close() } catch (e: Throwable) { }
    }
}
