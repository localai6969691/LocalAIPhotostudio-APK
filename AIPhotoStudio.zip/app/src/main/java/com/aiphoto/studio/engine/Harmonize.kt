package com.aiphoto.studio.engine

import kotlin.math.cbrt
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Hòa vật thể được chèn / di chuyển vào nền ("Object blending"): khớp màu + độ sáng của vật với ánh sáng quanh nó, KHÔNG cần model.
 *  1. Vùng vật = điểm có alpha ≥ 50% của lớp phủ [top]. Vành nền = các điểm của ảnh nền [base] nằm ngoài vật trong khoảng
 *     ≈ 12% cạnh dài của khung bao vật (tối thiểu 6 điểm ảnh) — ánh sáng và tông màu đang chiếu lên chỗ vật được đặt.
 *  2. Trong không gian CIELAB, mỗi kênh (L, a, b) của vật được chuyển thống kê kiểu Reinhard: x' = (x − μvật)·k + μvành, với
 *     k = (σvành/σvật)^0,5 kẹp [0,6; 1,6] (L) và [0,5; 1,8] (a,b) — chỉ đẩy NỬA đường về độ tương phản của vành để không phá chi tiết vật.
 *  3. Viền: điểm alpha một phần (rìa cắt) bị nhiễm màu nền cũ → pha về màu vành trung bình theo (1 − alpha), tối đa 50%.
 *  4. Kết quả = hòa [strength] giữa màu gốc và màu đã chuyển; alpha giữ nguyên, điểm ngoài vật (alpha 0) không đổi.
 * Giới hạn: chỉ khớp màu / độ sáng TOÀN CỤC của vật (không có bóng đổ, phản chiếu hay hướng sáng); vật có nhiều vùng màu rất khác nhau
 * (vd. người mặc đồ đỏ đứng trước nền xanh) bị kéo cả khối về tông vành nên nên dùng cường độ vừa phải.
 */
object Harmonize {

    const val MIN_PIXELS = 50
    private const val ALPHA_ON = 128

    // ------------------------------------------------------------------ sRGB ↔ CIELAB (D65)
    private fun lin(c: Int): Float { val v = c / 255f; return if (v <= 0.04045f) v / 12.92f else ((v + 0.055f) / 1.055f).pow(2.4f) }
    private fun gam(v: Float): Int {
        val x = if (v <= 0.0031308f) v * 12.92f else 1.055f * v.pow(1f / 2.4f) - 0.055f
        return (x * 255f + 0.5f).toInt().coerceIn(0, 255)
    }
    private fun f(t: Float): Float = if (t > 0.008856f) cbrt(t) else 7.787f * t + 16f / 116f
    private fun finv(t: Float): Float { val t3 = t * t * t; return if (t3 > 0.008856f) t3 else (t - 16f / 116f) / 7.787f }

    private const val XN = 0.95047f
    private const val YN = 1.0f
    private const val ZN = 1.08883f

    /** [out] = [L, a, b] của màu ARGB [p]. */
    fun toLab(p: Int, out: FloatArray) {
        val r = lin((p shr 16) and 255); val g = lin((p shr 8) and 255); val b = lin(p and 255)
        val x = 0.4124564f * r + 0.3575761f * g + 0.1804375f * b
        val y = 0.2126729f * r + 0.7151522f * g + 0.0721750f * b
        val z = 0.0193339f * r + 0.1191920f * g + 0.9503041f * b
        val fx = f(x / XN); val fy = f(y / YN); val fz = f(z / ZN)
        out[0] = 116f * fy - 16f; out[1] = 500f * (fx - fy); out[2] = 200f * (fy - fz)
    }

    /** ARGB (alpha [a]) từ Lab. */
    fun fromLab(l: Float, aa: Float, bb: Float, alpha: Int): Int {
        val fy = (l + 16f) / 116f
        val fx = fy + aa / 500f
        val fz = fy - bb / 200f
        val x = XN * finv(fx); val y = YN * finv(fy); val z = ZN * finv(fz)
        val r = 3.2404542f * x - 1.5371385f * y - 0.4985314f * z
        val g = -0.9692660f * x + 1.8760108f * y + 0.0415560f * z
        val b = 0.0556434f * x - 0.2040259f * y + 1.0572252f * z
        return (alpha shl 24) or (gam(r.coerceIn(0f, 1f)) shl 16) or (gam(g.coerceIn(0f, 1f)) shl 8) or gam(b.coerceIn(0f, 1f))
    }

    class Stats(val mean: FloatArray, val std: FloatArray, val count: Int)

    private fun accumulate(px: IntArray, sel: (Int) -> Boolean, weight: ((Int) -> Float)? = null): Stats? {
        val lab = FloatArray(3)
        val sum = DoubleArray(3); val sq = DoubleArray(3)
        var wsum = 0.0
        var n = 0
        for (i in px.indices) {
            if (!sel(i)) continue
            val wt = weight?.invoke(i)?.toDouble() ?: 1.0
            toLab(px[i], lab)
            for (c in 0 until 3) { sum[c] += lab[c] * wt; sq[c] += lab[c].toDouble() * lab[c] * wt }
            wsum += wt; n++
        }
        if (n < MIN_PIXELS || wsum <= 0.0) return null
        val mean = FloatArray(3) { (sum[it] / wsum).toFloat() }
        val std = FloatArray(3) { sqrt(max(0.0, sq[it] / wsum - (sum[it] / wsum) * (sum[it] / wsum))).toFloat() }
        return Stats(mean, std, n)
    }

    /**
     * Hòa màu lớp phủ [top] (ARGB w×h, alpha = độ phủ của vật) vào ảnh nền [base] (cùng kích thước, KHÔNG gồm vật).
     * Không đủ điểm ảnh ở vật hoặc vành, hoặc [strength] ≈ 0 → trả lại đúng mảng [top].
     */
    fun match(top: IntArray, base: IntArray, w: Int, h: Int, strength: Float): IntArray {
        val s = strength.coerceIn(0f, 1f)
        if (s < 0.01f || top.size != w * h || base.size != w * h) return top
        // khung bao của vật
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) if ((top[y * w + x] ushr 24) >= ALPHA_ON) {
            if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
        }
        if (x1 < x0) return top
        val band = max(6, (0.12f * max(x1 - x0 + 1, y1 - y0 + 1)).toInt())
        val rx0 = max(0, x0 - band); val ry0 = max(0, y0 - band); val rx1 = min(w - 1, x1 + band); val ry1 = min(h - 1, y1 + band)
        // vành = ô khung bao mở rộng nhưng ngoài vật; "ngoài vật" tính bằng alpha thấp để tránh vòng lặp khoảng cách
        val ringIdx = IntArray((rx1 - rx0 + 1) * (ry1 - ry0 + 1))
        var rn = 0
        for (y in ry0..ry1) for (x in rx0..rx1) {
            val i = y * w + x
            if ((top[i] ushr 24) < 8) ringIdx[rn++] = i
        }
        val ring = IntArray(rn) { base[ringIdx[it]] }
        val rs = accumulate(ring, { true }) ?: return top
        val os = accumulate(top, { (top[it] ushr 24) >= ALPHA_ON }) ?: return top
        // hệ số nửa đường
        val k = FloatArray(3) { c ->
            val ratio = if (os.std[c] < 1e-3f) 1f else sqrt(rs.std[c] / os.std[c])
            if (c == 0) ratio.coerceIn(0.6f, 1.6f) else ratio.coerceIn(0.5f, 1.8f)
        }
        // màu vành trung bình (để pha viền)
        val ringMeanArgb = fromLab(rs.mean[0], rs.mean[1], rs.mean[2], 255)
        val out = top.copyOf()
        val lab = FloatArray(3)
        for (i in top.indices) {
            val p = top[i]
            val a = p ushr 24
            if (a == 0) continue
            toLab(p, lab)
            val l2 = (lab[0] - os.mean[0]) * k[0] + rs.mean[0]
            val a2 = (lab[1] - os.mean[1]) * k[1] + rs.mean[1]
            val b2 = (lab[2] - os.mean[2]) * k[2] + rs.mean[2]
            var q = fromLab(
                lab[0] + (l2 - lab[0]) * s, lab[1] + (a2 - lab[1]) * s, lab[2] + (b2 - lab[2]) * s, a
            )
            if (a < 255) {
                // rìa bán trong suốt: pha về màu vành (loại bỏ quầng màu của nền cũ)
                val t = (1f - a / 255f) * 0.5f * s
                val rr = ((q shr 16) and 255) + (((ringMeanArgb shr 16) and 255) - ((q shr 16) and 255)) * t
                val gg = ((q shr 8) and 255) + (((ringMeanArgb shr 8) and 255) - ((q shr 8) and 255)) * t
                val bb = (q and 255) + ((ringMeanArgb and 255) - (q and 255)) * t
                q = (a shl 24) or (rr.toInt().coerceIn(0, 255) shl 16) or (gg.toInt().coerceIn(0, 255) shl 8) or bb.toInt().coerceIn(0, 255)
            }
            out[i] = q
        }
        return out
    }
}
