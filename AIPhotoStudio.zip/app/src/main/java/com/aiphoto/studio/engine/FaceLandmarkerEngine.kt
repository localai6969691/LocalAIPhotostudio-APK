package com.aiphoto.studio.engine

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Nhận diện 478 điểm khuôn mặt bằng MediaPipe Face Landmarker (tasks-vision, Apache-2.0).
 * Model `face_landmarker.task` do người dùng nạp (tải từ trang MediaPipe) và lưu trong filesDir/models.
 *
 * Model nằm ở tệp ngoài thư mục assets nên nạp qua `setModelAssetBuffer` (MappedByteBuffer) - theo tài liệu MediaPipe,
 * `setModelAssetPath` chỉ đọc từ thư mục assets của app.
 */
class FaceLandmarkerEngine(context: Context, modelPath: String) : AutoCloseable {

    private val landmarker: FaceLandmarker
    private val mapped: MappedByteBuffer

    init {
        // ánh xạ bộ nhớ vẫn còn hiệu lực sau khi đóng tệp
        mapped = RandomAccessFile(File(modelPath), "r").use { raf ->
            raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length())
        }
        val base = BaseOptions.builder().setModelAssetBuffer(mapped).build()
        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setNumFaces(MAX_FACES)
            .setMinFaceDetectionConfidence(0.4f)
            .setMinFacePresenceConfidence(0.4f)
            .build()
        landmarker = FaceLandmarker.createFromOptions(context.applicationContext, options)
    }

    /**
     * Mỗi khuôn mặt = x0,y0,x1,y1,... chuẩn hóa 0..1 (xem [FaceGeometry]); với mô hình 478 điểm có thêm khối chiều sâu z0..z477 NỐI VÀO CUỐI
     * (kích thước 3×478, xem [HeadPose]) - mã cũ chỉ so `size >= 2*468` nên không bị ảnh hưởng. Danh sách rỗng nếu không thấy mặt.
     */
    @Synchronized
    fun detect(bitmap: Bitmap): List<FloatArray> {
        val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val result = landmarker.detect(BitmapImageBuilder(argb).build())
        val out = ArrayList<FloatArray>()
        for (face in result.faceLandmarks()) {
            val n = face.size
            val withDepth = n == HeadPose.POINTS
            val arr = FloatArray(if (withDepth) 3 * n else 2 * n)
            for (i in face.indices) {
                arr[2 * i] = face[i].x()
                arr[2 * i + 1] = face[i].y()
                if (withDepth) arr[2 * n + i] = face[i].z()
            }
            out.add(arr)
        }
        return out
    }

    override fun close() {
        try { landmarker.close() } catch (e: Throwable) { }
    }

    private companion object {
        const val MAX_FACES = 8   // ảnh nhóm / nhiều người lạ phía sau (xem StrangerMask)
    }
}
