package com.aiphoto.studio.integrity

import java.security.MessageDigest

/**
 * Cổng tới Play Integrity (R32) — CHỨNG THỰC thiết bị/ứng dụng với máy chủ (xem backend/integrity.py). Mặc định là bản stub [integrityStub] không làm gì và
 * không thêm thư viện; bật bản thật bằng  -PuseIntegrity=true -PintegrityCloudProject=<số dự án Google Cloud>  (số, KHÔNG phải tên dự án).
 */
interface IntegrityGateway {
    /** Có thể xin token không (bản stub, hoặc chưa cấu hình số dự án Cloud ⇒ false và app chạy như trước). */
    val available: Boolean

    /** Xin token CHUẨN gắn với [requestHash]; gọi [onResult] đúng một lần: (token, null) hoặc (null, lý do lỗi). Có thể chạy ở luồng bất kỳ. */
    fun requestToken(requestHash: String, onResult: (String?, String?) -> Unit)
}

object IntegrityHash {
    /**
     * requestHash app PHẢI dùng = SHA-256 (hex thường) của "device_id|thử thách" — máy chủ tự tính lại đúng chuỗi này (backend/integrity.py
     * `expected_request_hash`). Dài 64 ký tự, nằm trong giới hạn 500 byte của requestHash; không chứa dữ liệu nhạy cảm dạng chữ thường.
     */
    fun forChallenge(deviceId: String, challenge: String): String =
        MessageDigest.getInstance("SHA-256").digest("$deviceId|$challenge".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
}

/**
 * Gộp các lần chứng thực đồng thời: nhiều lệnh cùng gặp 403 `integrity_required` chỉ chạy MỘT lần chứng thực (mỗi lần xin thử thách mới sẽ hủy thử thách
 * cũ nên chạy song song làm hỏng nhau), và trong [freshMs] sau một lần thành công thì cho thử lại ngay không chứng thực nữa (tránh vòng lặp khi máy chủ
 * vẫn từ chối vì lý do khác). Google còn giới hạn số lần chuẩn bị token (5 lần/phút/ứng dụng) nên càng không nên chứng thực dồn dập.
 */
class IntegrityCoordinator(private val now: () -> Long = { System.currentTimeMillis() }, private val freshMs: Long = 60_000L) {
    private val lock = Any()
    private var lastOkAt = Long.MIN_VALUE / 2

    /** [attest] chạy khi cần; trả true nếu đã (hoặc vừa) chứng thực — khi đó người gọi thử lại lệnh gốc MỘT lần. */
    fun ensure(attest: () -> Boolean): Boolean = synchronized(lock) {
        if (now() - lastOkAt < freshMs) return@synchronized true
        val ok = try { attest() } catch (t: Throwable) { false }
        if (ok) lastOkAt = now()
        ok
    }
}
