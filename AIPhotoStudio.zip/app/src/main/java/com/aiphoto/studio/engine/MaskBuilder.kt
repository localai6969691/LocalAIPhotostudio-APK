package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.aiphoto.studio.ai.GenIntent
import kotlin.math.max
import kotlin.math.min

/** Điểm chuẩn hóa 0..1 theo ảnh (độc lập độ phân giải). */
data class Pt(val x: Float, val y: Float)

object MaskBuilder {

    /**
     * Dựng mặt nạ (255 = vùng cần xử lý) ở độ phân giải w*h từ các nét tô.
     * brush = bán kính cọ, tính theo tỉ lệ cạnh dài của ảnh.
     * Nếu không có nét tô, thử dựng vùng elip từ vị trí nêu trong prompt ("bên phải"...).
     */
    fun build(strokes: List<List<Pt>>, brush: Float, w: Int, h: Int, prompt: String): ByteArray? {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val radius = brush * max(w, h)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = radius * 2f
        }
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        var any = false
        for (s in strokes) {
            if (s.isEmpty()) continue
            any = true
            if (s.size == 1) {
                canvas.drawCircle(s[0].x * w, s[0].y * h, radius, dot)
            } else {
                val path = Path()
                s.forEachIndexed { i, p ->
                    if (i == 0) path.moveTo(p.x * w, p.y * h) else path.lineTo(p.x * w, p.y * h)
                }
                canvas.drawPath(path, line)
            }
        }
        if (!any) {
            val hint = GenIntent.regionHint(prompt) ?: return null
            val r = 0.22f * min(w, h)
            canvas.drawOval(
                RectF(hint.first * w - r, hint.second * h - r * 1.2f, hint.first * w + r, hint.second * h + r * 1.2f),
                dot
            )
        }

        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h)
        var count = 0
        for (i in px.indices) {
            if ((px[i] ushr 24) > 127) { out[i] = 255.toByte(); count++ }
        }
        return if (count == 0) null else out
    }
}
