package com.aiphoto.studio.engine

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Hình học khuôn mặt từ 478 điểm của MediaPipe Face Landmarker -> mặt nạ 0/255 theo từng vùng (da, mắt, miệng, quầng thâm).
 * THUẦN Kotlin (không phụ thuộc Android/MediaPipe) để kiểm thử được trên JVM (xem LogicTest).
 *
 * Chỉ số điểm lấy từ bảng MESH_ANNOTATIONS của MediaPipe (silhouette, lipsUpper/LowerOuter/Inner, rightEye*, leftEye*, eyebrow*);
 * các vòng đa giác dưới đây đã sắp theo thứ tự đi vòng quanh. Đầu vào [landmarks] = x0,y0,x1,y1,... CHUẨN HÓA 0..1 theo ảnh.
 */
object FaceGeometry {

    const val MIN_POINTS = 468

    /** 36 điểm đường viền khuôn mặt (silhouette). */
    val FACE_OVAL = intArrayOf(
        10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377,
        152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109
    )
    val RIGHT_EYE = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
    val LEFT_EYE = intArrayOf(263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249)
    val LIPS_OUTER = intArrayOf(61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 375, 321, 405, 314, 17, 84, 181, 91, 146)
    val LIPS_INNER = intArrayOf(78, 191, 80, 81, 82, 13, 312, 311, 310, 415, 308, 324, 318, 402, 317, 14, 87, 178, 88, 95)

    /** Lông mày: tập điểm (bao lồi của chúng là hình lông mày). */
    val RIGHT_BROW = intArrayOf(70, 63, 105, 66, 107, 46, 53, 52, 65, 55)
    val LEFT_BROW = intArrayOf(300, 293, 334, 296, 336, 276, 283, 282, 295, 285)

    /** Mí dưới (từ khóe ngoài vào khóe trong) để dựng vùng quầng thâm. */
    val RIGHT_LOWER_LID = intArrayOf(33, 7, 163, 144, 145, 153, 154, 155, 133)
    val LEFT_LOWER_LID = intArrayOf(263, 249, 390, 373, 374, 380, 381, 382, 362)

    private const val FOREHEAD = 10
    private const val CHIN = 152

    class Parts(val w: Int, val h: Int) {
        /** Da mặt = đường viền khuôn mặt trừ mắt, lông mày, môi. */
        val skin = ByteArray(w * h)
        val eyes = ByteArray(w * h)
        /** Phần trong miệng (trong vòng môi trong): dùng làm vùng ứng viên của răng. */
        val mouth = ByteArray(w * h)
        val underEyes = ByteArray(w * h)
        var faces = 0
    }

    /** Tô đa giác (even-odd, tâm điểm ảnh tại x+0.5) vào [out] (w*h) bằng giá trị [value]. */
    fun fillPolygon(xs: FloatArray, ys: FloatArray, w: Int, h: Int, out: ByteArray, value: Int = 255) {
        val n = xs.size
        if (n < 3 || ys.size != n) return
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (v in ys) {
            if (v < minY) minY = v
            if (v > maxY) maxY = v
        }
        val y0 = max(0, floor(minY).toInt())
        val y1 = min(h - 1, ceil(maxY).toInt())
        val cross = FloatArray(n)
        val b = value.toByte()
        for (y in y0..y1) {
            val sy = y + 0.5f
            var c = 0
            var j = n - 1
            for (i in 0 until n) {
                val yi = ys[i]
                val yj = ys[j]
                if ((yi <= sy && yj > sy) || (yj <= sy && yi > sy)) {
                    cross[c++] = xs[i] + (sy - yi) / (yj - yi) * (xs[j] - xs[i])
                }
                j = i
            }
            for (a in 1 until c) {
                val v = cross[a]
                var k = a - 1
                while (k >= 0 && cross[k] > v) {
                    cross[k + 1] = cross[k]
                    k--
                }
                cross[k + 1] = v
            }
            var k = 0
            while (k + 1 < c) {
                val xa = max(0, ceil(cross[k] - 0.5f).toInt())
                val xb = min(w - 1, floor(cross[k + 1] - 0.5f).toInt())
                val row = y * w
                for (x in xa..xb) out[row + x] = b
                k += 2
            }
        }
    }

    /** Bao lồi (monotone chain) của tập điểm; trả về các đỉnh theo thứ tự đi vòng. */
    fun convexHull(px: FloatArray, py: FloatArray): Pair<FloatArray, FloatArray> {
        val n = px.size
        if (n < 3) return Pair(px, py)
        val idx = (0 until n).sortedWith(compareBy<Int>({ px[it] }, { py[it] }))
        fun cross(o: Int, a: Int, b: Int): Float =
            (px[a] - px[o]) * (py[b] - py[o]) - (py[a] - py[o]) * (px[b] - px[o])
        val hull = ArrayList<Int>()
        for (i in idx) {
            while (hull.size >= 2 && cross(hull[hull.size - 2], hull[hull.size - 1], i) <= 0f) hull.removeAt(hull.size - 1)
            hull.add(i)
        }
        val lowerSize = hull.size + 1
        for (t in n - 2 downTo 0) {
            val i = idx[t]
            while (hull.size >= lowerSize && cross(hull[hull.size - 2], hull[hull.size - 1], i) <= 0f) hull.removeAt(hull.size - 1)
            hull.add(i)
        }
        hull.removeAt(hull.size - 1)
        return Pair(FloatArray(hull.size) { px[hull[it]] }, FloatArray(hull.size) { py[hull[it]] })
    }

    private fun xsOf(lm: FloatArray, ids: IntArray, w: Int) = FloatArray(ids.size) { lm[2 * ids[it]] * w }
    private fun ysOf(lm: FloatArray, ids: IntArray, h: Int) = FloatArray(ids.size) { lm[2 * ids[it] + 1] * h }

    private fun fillRing(lm: FloatArray, ids: IntArray, w: Int, h: Int, out: ByteArray, value: Int) =
        fillPolygon(xsOf(lm, ids, w), ysOf(lm, ids, h), w, h, out, value)

    private fun fillHull(lm: FloatArray, ids: IntArray, w: Int, h: Int, out: ByteArray, value: Int) {
        val hull = convexHull(xsOf(lm, ids, w), ysOf(lm, ids, h))
        fillPolygon(hull.first, hull.second, w, h, out, value)
    }

    /** Vùng quầng thâm: dải dưới mí dưới, dịch xuống (theo trục mặt) 0.5 × bề rộng mắt. */
    private fun fillUnderEye(lm: FloatArray, lid: IntArray, w: Int, h: Int, out: ByteArray) {
        val n = lid.size
        val ex = FloatArray(n) { lm[2 * lid[it]] * w }
        val ey = FloatArray(n) { lm[2 * lid[it] + 1] * h }
        // trục "xuống" của khuôn mặt = từ trán đến cằm (đúng cả khi ảnh nghiêng)
        var dx = (lm[2 * CHIN] - lm[2 * FOREHEAD]) * w
        var dy = (lm[2 * CHIN + 1] - lm[2 * FOREHEAD + 1]) * h
        val len = sqrt(dx * dx + dy * dy)
        if (len < 1e-3f) return
        dx /= len
        dy /= len
        val eyeW = sqrt((ex[0] - ex[n - 1]) * (ex[0] - ex[n - 1]) + (ey[0] - ey[n - 1]) * (ey[0] - ey[n - 1]))
        val depth = 0.5f * eyeW
        val px = FloatArray(2 * n)
        val py = FloatArray(2 * n)
        for (i in 0 until n) {
            px[i] = ex[i]
            py[i] = ey[i]
            px[2 * n - 1 - i] = ex[i] + dx * depth
            py[2 * n - 1 - i] = ey[i] + dy * depth
        }
        fillPolygon(px, py, w, h, out, 255)
    }

    /**
     * Dựng mặt nạ các vùng cho mọi khuôn mặt. Bước 1: tô đường viền của tất cả khuôn mặt; bước 2: khoét mắt/mày/môi
     * (làm 2 lượt để khuôn mặt sau không tô đè phần đã khoét của khuôn mặt trước).
     */
    fun parts(faces: List<FloatArray>, w: Int, h: Int): Parts {
        val p = Parts(w, h)
        val valid = faces.filter { it.size >= 2 * MIN_POINTS }
        for (lm in valid) fillRing(lm, FACE_OVAL, w, h, p.skin, 255)
        for (lm in valid) {
            fillRing(lm, RIGHT_EYE, w, h, p.skin, 0)
            fillRing(lm, LEFT_EYE, w, h, p.skin, 0)
            fillHull(lm, RIGHT_BROW, w, h, p.skin, 0)
            fillHull(lm, LEFT_BROW, w, h, p.skin, 0)
            fillRing(lm, LIPS_OUTER, w, h, p.skin, 0)
            fillRing(lm, RIGHT_EYE, w, h, p.eyes, 255)
            fillRing(lm, LEFT_EYE, w, h, p.eyes, 255)
            fillRing(lm, LIPS_INNER, w, h, p.mouth, 255)
            fillUnderEye(lm, RIGHT_LOWER_LID, w, h, p.underEyes)
            fillUnderEye(lm, LEFT_LOWER_LID, w, h, p.underEyes)
            p.faces++
        }
        return p
    }

    /**
     * Mặt nạ "tông" cho Dodge & Burn tự động: trong vùng da [skin], [light] = true giữ phần SÁNG (nâng thêm),
     * false giữ phần TỐI (đào sâu). Trọng số mềm theo độ sáng điểm ảnh; ngoài vùng da luôn 0.
     */
    fun tonalMask(skin: ByteArray, argb: IntArray, light: Boolean): ByteArray {
        val out = ByteArray(skin.size)
        for (i in skin.indices) {
            if (skin[i].toInt() == 0) continue
            val p = argb[i]
            val l = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
            val wgt = if (light) smooth(0.45f, 0.80f, l) else 1f - smooth(0.25f, 0.55f, l)
            out[i] = (wgt * 255f + 0.5f).toInt().coerceIn(0, 255).toByte()
        }
        return out
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /**
     * Trong vùng miệng chỉ giữ phần giống RĂNG: sáng và ít bão hòa (loại lưỡi, nướu, môi, bóng tối).
     * Trả về mặt nạ mềm 0..255.
     */
    fun teethMask(mouth: ByteArray, argb: IntArray): ByteArray {
        val out = ByteArray(mouth.size)
        for (i in mouth.indices) {
            if (mouth[i].toInt() == 0) continue
            val p = argb[i]
            val r = ((p shr 16) and 255) / 255f
            val g = ((p shr 8) and 255) / 255f
            val b = (p and 255) / 255f
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val l = 0.299f * r + 0.587f * g + 0.114f * b
            val s = if (mx <= 0f) 0f else (mx - mn) / mx
            val wgt = smooth(0.30f, 0.55f, l) * (1f - smooth(0.35f, 0.65f, s))
            out[i] = (wgt * 255f + 0.5f).toInt().coerceIn(0, 255).toByte()
        }
        return out
    }
}
