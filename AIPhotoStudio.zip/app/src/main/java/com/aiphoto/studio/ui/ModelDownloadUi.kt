package com.aiphoto.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.UiState
import com.aiphoto.studio.i18n.Text
import com.aiphoto.studio.models.ModelEntry
import com.aiphoto.studio.models.ModelHub
import com.aiphoto.studio.models.NetKind
import com.aiphoto.studio.models.NetworkPolicy

/** R43: model đã nạp xong (theo cờ của UiState) ứng với "ô" model trong danh mục. MobileSAM cần cả encoder lẫn decoder nên cùng một cờ. */
fun modelReady(slot: String, st: UiState): Boolean = when (slot) {
    "seg" -> st.segReady
    "seg_hq" -> st.segHqReady
    "portrait" -> st.portraitReady
    "lama" -> st.lamaReady
    "migan" -> st.miganReady
    "esrgan" -> st.esrganReady
    "sam_encoder", "sam_decoder" -> st.samReady
    "face" -> st.faceReady
    "hair" -> st.hairReady
    "person" -> st.personReady
    "depth" -> st.depthReady
    else -> false
}

/**
 * R43: mục "Tải model AI" trong Cài đặt — danh sách model có dung lượng, mô tả, giấy phép; bấm Tải ⇒ hộp thoại điều khoản (một lần cho mỗi model)
 * ⇒ tải, kiểm SHA-256, tự nạp. Danh mục và logic nằm ở models/ModelHub.kt.
 *
 * R44: công tắc "Chỉ tải bằng Wi-Fi" (mặc định bật), hàng đợi (bấm Tải nhiều model, tải lần lượt), tải tiếp tục khi thoát app (dịch vụ nền + thông báo),
 * nút "Gỡ" từng model (có hộp thoại xác nhận) và "Tải bằng dữ liệu di động lần này" khi đang chờ Wi-Fi.
 *
 * @param onRemove gỡ một model theo ô (slot) — MainViewModel.removeModel
 * @param askNotifications có nên hỏi quyền hiện thông báo (Android 13+, hỏi đúng một lần) không
 * @param onNotificationsAsked ghi nhận đã hỏi
 */
@Composable
fun ModelDownloadSection(
    hub: ModelHub,
    st: UiState,
    lang: String,
    onRemove: (String) -> Unit = {},
    askNotifications: () -> Boolean = { false },
    onNotificationsAsked: () -> Unit = {}
) {
    val hs by hub.state.collectAsState()
    var removing by remember { mutableStateOf<ModelEntry?>(null) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }
    LaunchedEffect(Unit) { hub.refresh() }

    fun download(id: String) {
        // quyền thông báo chỉ để thấy tiến độ khi thoát app: từ chối thì vẫn tải bình thường
        if (askNotifications()) {
            onNotificationsAsked()
            notifLauncher.launch("android.permission.POST_NOTIFICATIONS")
        }
        hub.request(id)
    }

    Text("Tải model AI (khuyên dùng)", style = MaterialTheme.typography.titleSmall)
    Text(
        "Chọn model rồi bấm Tải: app tải về, kiểm tra toàn vẹn (SHA-256) và tự nạp. Không có model vẫn dùng được chức năng cơ bản.",
        style = MaterialTheme.typography.bodySmall
    )
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Chỉ tải bằng Wi-Fi (mạng không tính cước)", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Bật: gặp dữ liệu di động thì tạm dừng, giữ phần đã tải và tự tải tiếp khi có Wi-Fi. Tắt: tải bằng mọi loại mạng.",
                style = MaterialTheme.typography.labelSmall
            )
        }
        Switch(checked = hs.wifiOnly, onCheckedChange = { hub.setWifiOnly(it) })
    }
    val netLabel = when (hs.network) {
        NetKind.UNMETERED -> "Wi-Fi / mạng không tính cước"
        NetKind.METERED -> "dữ liệu di động (tính cước)"
        NetKind.OFFLINE -> "không có mạng"
    }
    Text("Mạng hiện tại: $netLabel", style = MaterialTheme.typography.labelSmall)
    Text(
        "Tải vẫn tiếp tục khi bạn thoát khỏi app (có thông báo tiến độ; bấm Hủy trên thông báo để dừng).",
        style = MaterialTheme.typography.labelSmall
    )
    if (hs.note.isNotBlank()) Text(hs.note, style = MaterialTheme.typography.labelSmall)

    when (hs.waiting) {
        NetworkPolicy.Wait.WIFI -> {
            Text("Đang chờ Wi-Fi: các model trong hàng đợi sẽ tự tải tiếp khi có Wi-Fi.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { hub.allowMeteredOnce() }) { Text("Tải bằng dữ liệu di động lần này") }
        }
        NetworkPolicy.Wait.NETWORK -> Text("Không có mạng: sẽ tự tải tiếp khi có mạng.", style = MaterialTheme.typography.bodySmall)
        null -> {}
    }
    if (hs.queue.size > 1) OutlinedButton(onClick = { hub.cancel() }) { Text("Hủy tất cả") }

    for (e in hs.entries) {
        val active = hs.activeId == e.id
        val queued = e.id in hs.queue
        val head = hs.queue.firstOrNull() == e.id
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("${e.name} · ${e.sizeMb} MB", style = MaterialTheme.typography.bodyMedium)
                Text(e.desc(lang), style = MaterialTheme.typography.labelSmall)
                when {
                    active -> Text("Đang tải ${(hs.progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                    queued && head && hs.waiting == NetworkPolicy.Wait.WIFI -> Text("Đang chờ Wi-Fi", style = MaterialTheme.typography.labelSmall)
                    queued && head && hs.waiting == NetworkPolicy.Wait.NETWORK -> Text("Đang chờ mạng", style = MaterialTheme.typography.labelSmall)
                    queued -> Text("Trong hàng đợi", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (active || queued) {
                OutlinedButton(onClick = { hub.cancel(e.id) }) { Text("Hủy") }
            } else if (modelReady(e.slot, st)) {
                Text("Đã có", style = MaterialTheme.typography.labelSmall)
                TextButton(onClick = { removing = e }) { Text("Gỡ") }
            } else {
                OutlinedButton(onClick = { download(e.id) }) { Text("Tải") }
            }
        }
    }
    OutlinedButton(onClick = { hub.refresh() }) { Text("Làm mới danh mục") }

    val pending = hs.pendingConsent?.let { hub.entry(it) }
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { hub.dismissConsent() },
            title = { Text("Điều khoản của model") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(pending.name, style = MaterialTheme.typography.titleSmall)
                    Text(pending.desc(lang), style = MaterialTheme.typography.bodySmall)
                    Text("Giấy phép: ${pending.license}", style = MaterialTheme.typography.bodySmall)
                    Text(pending.licenseUrl, style = MaterialTheme.typography.labelSmall)
                    if (pending.risk(lang).isNotBlank()) Text(pending.risk(lang), style = MaterialTheme.typography.bodySmall)
                    Text("Dung lượng: ${pending.sizeMb} MB — nên dùng Wi-Fi.", style = MaterialTheme.typography.bodySmall)
                    if (hs.wifiOnly) Text("Đang bật chế độ chỉ Wi-Fi: nếu chỉ có dữ liệu di động, app sẽ chờ Wi-Fi.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { hub.confirm(pending.id) }) { Text("Đồng ý và tải") } },
            dismissButton = { TextButton(onClick = { hub.dismissConsent() }) { Text("Hủy") } }
        )
    }

    val rm = removing
    if (rm != null) {
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Gỡ model này?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${rm.name} · ${rm.sizeMb} MB", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Tệp model sẽ bị xóa khỏi máy. Chức năng dùng model này chuyển sang cách dự phòng; bạn có thể tải lại bất cứ lúc nào.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (rm.slot == "sam_encoder" || rm.slot == "sam_decoder") {
                        Text("MobileSAM gồm hai tệp (encoder và decoder) nên gỡ một thì cả hai bị xóa.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { onRemove(rm.slot); removing = null }) { Text("Gỡ model") } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Hủy") } }
        )
    }
}
