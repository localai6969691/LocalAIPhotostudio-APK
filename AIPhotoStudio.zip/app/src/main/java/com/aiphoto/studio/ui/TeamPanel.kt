package com.aiphoto.studio.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import com.aiphoto.studio.i18n.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.MainViewModel
import com.aiphoto.studio.UiState
import com.aiphoto.studio.engine.TeamText

/**
 * Gói Team/Enterprise (R22) trong Cài đặt. App chỉ hiển thị và gửi lệnh; máy chủ kiểm quyền từng lệnh (ghế, vai trò, quỹ chung, Pro của nhóm).
 * Thao tác không đảo ngược được (rời nhóm, xóa thành viên, chuyển quyền) cần bấm HAI LẦN.
 */
@Composable
fun TeamSection(st: UiState, vm: MainViewModel) {
    var code by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var fund by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }      // "leave" | "remove:<id>" | "transfer:<id>" đang chờ bấm lần hai
    val team = st.team

    Text("Nhóm (Team / Enterprise)", style = MaterialTheme.typography.titleSmall)
    if (team == null) {
        Text("Chưa thuộc nhóm nào. Nhập mã mời do quản trị viên nhóm gửi để dùng chung credits và gói Pro của nhóm.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = code,
            onValueChange = { code = it.take(14) },
            label = { Text("Mã mời (XXXXX-XXXXX)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { vm.teamJoin(code); code = "" }, enabled = !st.teamBusy && TeamText.isPlausibleCode(code)) { Text("Vào nhóm") }
            OutlinedButton(onClick = { vm.refreshTeam() }, enabled = !st.teamBusy) { Text("Làm mới") }
        }
        OutlinedTextField(
            value = newName,
            onValueChange = { newName = it.take(60) },
            label = { Text("Tên nhóm mới (nếu máy chủ cho tự tạo)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { vm.teamCreate(newName) }, enabled = !st.teamBusy && newName.isNotBlank()) { Text("Tạo nhóm") }
    } else {
        val nowSec = System.currentTimeMillis() / 1000L
        Text(TeamText.summary(team, nowSec), style = MaterialTheme.typography.bodySmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(onClick = { vm.refreshTeam() }, enabled = !st.teamBusy) { Text("Làm mới") }
            OutlinedButton(
                onClick = { if (confirm == "leave") { confirm = ""; vm.teamLeave() } else confirm = "leave" },
                enabled = !st.teamBusy
            ) { Text(if (confirm == "leave") "Bấm lại để rời nhóm" else "Rời nhóm") }
            if (team.isAdmin) {
                OutlinedButton(onClick = { vm.teamNewInvite() }, enabled = !st.teamBusy) { Text("Đổi mã mời") }
            }
        }
        if (st.teamInviteCode.isNotBlank()) {
            Text("Mã mời: ${TeamText.displayCode(st.teamInviteCode)} (chỉ hiện một lần - hãy chép lại)", style = MaterialTheme.typography.bodyMedium)
        }
        if (team.isAdmin) {
            Text("Thành viên (mã ẩn danh):", style = MaterialTheme.typography.labelMedium)
            team.memberList.forEachIndexed { i, m ->
                Column {
                    Text(
                        (if (m.isYou) "Bạn" else "Thành viên ${i + 1}") + " · " + TeamText.roleLabel(m.role) + " · #" + m.memberId.take(6),
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!m.isYou && !m.isAdmin) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val rm = "remove:" + m.memberId
                            val tr = "transfer:" + m.memberId
                            OutlinedButton(
                                onClick = { if (confirm == rm) { confirm = ""; vm.teamRemove(m.memberId) } else confirm = rm },
                                enabled = !st.teamBusy
                            ) { Text(if (confirm == rm) "Bấm lại để xóa" else "Xóa khỏi nhóm") }
                            OutlinedButton(
                                onClick = { if (confirm == tr) { confirm = ""; vm.teamTransfer(m.memberId) } else confirm = tr },
                                enabled = !st.teamBusy
                            ) { Text(if (confirm == tr) "Bấm lại để chuyển quyền" else "Chuyển quyền") }
                        }
                    }
                }
            }
            OutlinedTextField(
                value = fund,
                onValueChange = { fund = it.filter { c -> c.isDigit() }.take(6) },
                label = { Text("Nạp credits cá nhân vào quỹ nhóm (một chiều)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = { fund.toIntOrNull()?.let { n -> if (n > 0) { vm.teamFund(n); fund = "" } } },
                enabled = !st.teamBusy && (fund.toIntOrNull() ?: 0) > 0
            ) { Text("Nạp vào quỹ nhóm") }
        }
    }
    if (st.teamMessage.isNotBlank()) Text(st.teamMessage, style = MaterialTheme.typography.bodySmall)
}
