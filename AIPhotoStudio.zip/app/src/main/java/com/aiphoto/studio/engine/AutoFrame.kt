package com.aiphoto.studio.engine

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Auto Frame (R24): gợi ý khung cắt theo CHỦ THỂ cho một tỉ lệ cho trước - giữ trọn khuôn mặt, chừa lề quanh chủ thể,
 * đặt chủ thể gần điểm 1/3 (quy tắc một phần ba) và phóng khung vừa phải khi chủ thể nhỏ.
 *
 * Toàn bộ là Kotlin thuần trên "bản đồ quan trọng" (lưới nhỏ, cùng tỉ lệ khung với ảnh) nên kiểm thử được trên JVM không cần ảnh thật:
 *  - [saliency]: bản đồ nổi bật cổ điển (khác biệt màu so với màu trung bình, không cần model) - dùng khi máy chưa nạp model nào.
 *  - [combine]: trộn thêm mặt nạ chủ thể của model tách nền và mặt nạ khuôn mặt (nếu có) cho kết quả tốt hơn hẳn.
 *  - [suggest]: tìm khung (vị trí + mức phóng) có chi phí thấp nhất.
 *  - [cropRect] / [encodeArg] / [parseArg]: cùng một hình học dùng cho gợi ý và cho phép cắt thật (`CROP_RATIO`, arg = "cx,cy,scale"),
 *    nên khung xem trước luôn trùng khung được cắt; không có arg = cắt giữa như cũ.
 */
object AutoFrame {
    /** Không phóng khung quá 2× theo chiều dài để giữ độ phân giải. */
    const val MIN_SCALE = 0.5f
    private val SCALES = floatArrayOf(1f, 0.88f, 0.76f, 0.64f, 0.52f)
    /** Tỉ lệ diện tích chủ thể (đã chừa lề) / khung được coi là vừa đủ chặt. */
    private const val FILL_TARGET = 0.3

    /** [importance] và [faces] (tùy chọn) là lưới w*h giá trị 0..1; faces = nơi có khuôn mặt (phải giữ trọn). */
    class Maps(val w: Int, val h: Int, val importance: FloatArray, val faces: FloatArray? = null) {
        init {
            require(w > 0 && h > 0 && importance.size == w * h && (faces == null || faces.size == w * h)) { "bản đồ sai kích thước" }
        }
    }

    /** Khung đề xuất: tọa độ chuẩn hóa 0..1 theo ảnh. [coversAll] = khung phủ cả ảnh (không cắt gì). */
    class Frame(
        val cx: Float, val cy: Float, val scale: Float,
        val x0: Float, val y0: Float, val x1: Float, val y1: Float,
        val cost: Float, val note: String
    ) {
        val coversAll: Boolean get() = (x1 - x0) >= 0.995f && (y1 - y0) >= 0.995f
    }

    // ------------------------------------------------------------------ hình học cắt (dùng chung với ImageEngine.cropRatio)
    /** Hình chữ nhật cắt [x, y, rộng, cao] theo điểm ảnh: cửa sổ lớn nhất có tỉ lệ [ratio] nhân [scale], tâm tại ([cx],[cy]) chuẩn hóa, kẹp trong ảnh. */
    fun cropRect(w: Int, h: Int, ratio: Float, cx: Float = 0.5f, cy: Float = 0.5f, scale: Float = 1f): IntArray {
        val cur = w.toFloat() / h
        var nw: Int
        var nh: Int
        if (cur > ratio) { nh = h; nw = (h * ratio).roundToInt() } else { nw = w; nh = (w / ratio).roundToInt() }
        val s = scale.coerceIn(MIN_SCALE, 1f)
        if (s < 1f) { nw = (nw * s).roundToInt(); nh = (nh * s).roundToInt() }
        val cw = nw.coerceIn(1, w)
        val ch = nh.coerceIn(1, h)
        val x = floor(cx.toDouble() * w - cw / 2.0 + 1e-6).toInt().coerceIn(0, w - cw)
        val y = floor(cy.toDouble() * h - ch / 2.0 + 1e-6).toInt().coerceIn(0, h - ch)
        return intArrayOf(x, y, cw, ch)
    }

    fun encodeArg(f: Frame): String = String.format(java.util.Locale.US, "%.4f,%.4f,%.3f", f.cx, f.cy, f.scale)

    /** (cx, cy, scale) từ arg; null nếu rỗng/hỏng. */
    fun parseArg(arg: String?): Triple<Float, Float, Float>? {
        if (arg.isNullOrBlank()) return null
        val p = arg.split(',').map { it.trim().toFloatOrNull() }
        if (p.size != 3 || p.any { it == null || it.isNaN() || it.isInfinite() }) return null
        return Triple(p[0]!!.coerceIn(0f, 1f), p[1]!!.coerceIn(0f, 1f), p[2]!!.coerceIn(MIN_SCALE, 1f))
    }

    /** arg chuẩn hóa để lưu (null nếu hỏng hoặc chính là cắt giữa mặc định). */
    fun normalizeArg(arg: String?): String? {
        val t = parseArg(arg) ?: return null
        if (abs(t.first - 0.5f) < 1e-4f && abs(t.second - 0.5f) < 1e-4f && t.third >= 0.9999f) return null
        return String.format(java.util.Locale.US, "%.4f,%.4f,%.3f", t.first, t.second, t.third)
    }

    // ------------------------------------------------------------------ bản đồ quan trọng
    /**
     * Độ nổi bật kiểu "frequency-tuned": khác biệt giữa điểm ảnh (làm mờ nhẹ) và màu trung bình của cả ảnh (độ sáng + màu), hạ nhẹ ở sát viền,
     * chuẩn hóa theo phân vị 98. Ảnh gần như đồng nhất -> toàn 0 (không có chủ thể rõ). Là phép gần đúng: cảnh nền nhiều chi tiết/màu sặc sỡ có thể đánh lừa,
     * nên khi có model tách nền / khuôn mặt thì [combine] dựa vào chúng nhiều hơn.
     */
    fun saliency(px: IntArray, w: Int, h: Int): FloatArray {
        val n = w * h
        if (n == 0 || px.size < n) return FloatArray(n)
        val y = FloatArray(n)
        val u = FloatArray(n)
        val v = FloatArray(n)
        for (i in 0 until n) {
            val p = px[i]
            val r = ((p shr 16) and 255).toFloat()
            val g = ((p shr 8) and 255).toFloat()
            val b = (p and 255).toFloat()
            val l = 0.299f * r + 0.587f * g + 0.114f * b
            y[i] = l
            u[i] = (b - l) * 0.564f
            v[i] = (r - l) * 0.713f
        }
        val by = boxBlur(y, w, h)
        val bu = boxBlur(u, w, h)
        val bv = boxBlur(v, w, h)
        var my = 0.0
        var mu = 0.0
        var mv = 0.0
        for (i in 0 until n) { my += by[i]; mu += bu[i]; mv += bv[i] }
        my /= n; mu /= n; mv /= n
        val d = FloatArray(n)
        for (yy in 0 until h) {
            for (xx in 0 until w) {
                val i = yy * w + xx
                val dy = by[i] - my
                val du = bu[i] - mu
                val dv = bv[i] - mv
                var s = sqrt(dy * dy + 2f * du * du + 2f * dv * dv).toFloat()
                val edge = min(min(xx, w - 1 - xx).toFloat() / w, min(yy, h - 1 - yy).toFloat() / h)   // 0 ở viền → 0.5 giữa
                if (edge < 0.08f) s *= 0.7f + 0.3f * (edge / 0.08f)
                d[i] = s
            }
        }
        val sorted = d.copyOf().also { it.sort() }
        val p98 = sorted[((n - 1) * 0.98f).toInt().coerceIn(0, n - 1)]
        if (p98 < 6f) return FloatArray(n)   // ảnh gần như một màu: không có chủ thể nổi bật
        val out = FloatArray(n)
        for (i in 0 until n) {
            val s = (d[i] / p98).coerceIn(0f, 1f)
            out[i] = s * s
        }
        return out
    }

    /**
     * Trộn các nguồn: [sal] luôn có; [fg] = mặt nạ chủ thể của model tách nền (bỏ qua nếu hỏng: gần như trống hoặc phủ gần hết ảnh); [faces] = khuôn mặt.
     * Chủ thể từ model chiếm 70% (nổi bật cổ điển 30%); khuôn mặt luôn được nâng tối thiểu 0.9.
     */
    fun combine(sal: FloatArray, fg: FloatArray?, faces: FloatArray?): FloatArray {
        val useFg = fg != null && fg.size == sal.size && fgUsable(fg)
        val out = FloatArray(sal.size)
        for (i in sal.indices) {
            var v = if (useFg) 0.3f * sal[i] + 0.7f * fg!![i] else sal[i]
            if (faces != null && faces.size == sal.size) v = max(v, 0.9f * faces[i])
            out[i] = v.coerceIn(0f, 1f)
        }
        return out
    }

    /** Mặt nạ chủ thể đáng tin: chiếm 2%..80% diện tích ảnh (ngoài khoảng đó thường là model hỏng / không thấy gì). */
    fun fgUsable(fg: FloatArray): Boolean {
        if (fg.isEmpty()) return false
        var s = 0.0
        for (v in fg) s += v
        val f = s / fg.size
        return f in 0.02..0.8
    }

    /** Thu nhỏ lưới bằng trung bình theo ô (dùng đưa mặt nạ kích thước bất kỳ về lưới gợi ý). */
    fun resizeMean(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        require(src.size == sw * sh && dw > 0 && dh > 0)
        val out = FloatArray(dw * dh)
        for (dy in 0 until dh) {
            val y0 = dy * sh / dh
            val y1 = max(y0 + 1, (dy + 1) * sh / dh).coerceAtMost(sh)
            for (dx in 0 until dw) {
                val x0 = dx * sw / dw
                val x1 = max(x0 + 1, (dx + 1) * sw / dw).coerceAtMost(sw)
                var s = 0f
                var c = 0
                for (yy in y0 until y1) for (xx in x0 until x1) { s += src[yy * sw + xx]; c++ }
                out[dy * dw + dx] = if (c == 0) 0f else s / c
            }
        }
        return out
    }

    private fun boxBlur(a: FloatArray, w: Int, h: Int): FloatArray {
        val out = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) { s += a[yy * w + xx]; c++ }
            }
            out[y * w + x] = s / c
        }
        return out
    }

    // ------------------------------------------------------------------ tìm khung
    private class Integral(val w: Int, val h: Int, cell: (Int, Int) -> Double) {
        val s = DoubleArray((w + 1) * (h + 1))
        init {
            for (y in 0 until h) {
                var row = 0.0
                for (x in 0 until w) {
                    row += cell(x, y)
                    s[(y + 1) * (w + 1) + x + 1] = s[y * (w + 1) + x + 1] + row
                }
            }
        }
        fun sum(x0: Int, y0: Int, x1: Int, y1: Int): Double =
            s[y1 * (w + 1) + x1] - s[y0 * (w + 1) + x1] - s[y1 * (w + 1) + x0] + s[y0 * (w + 1) + x0]
    }

    private val THIRDS = arrayOf(floatArrayOf(1f / 3, 1f / 3), floatArrayOf(2f / 3, 1f / 3), floatArrayOf(1f / 3, 2f / 3), floatArrayOf(2f / 3, 2f / 3))

    /**
     * Khung tốt nhất cho tỉ lệ [ratio] (rộng/cao tính theo điểm ảnh) của ảnh [imgW]×[imgH]. Chi phí:
     * phần chủ thể bị cắt mất, khuôn mặt bị cắt (phạt nặng nhất), hộp chủ thể (đã chừa lề) lọt ngoài, phần khung thừa không có gì (chủ thể chiếm < 30% khung),
     * xa điểm 1/3 (chỉ khi chủ thể nhỏ hơn khung), và một chút ưu tiên khung lớn/gần giữa. Không thấy chủ thể rõ -> giữ khung giữa lớn nhất.
     */
    fun suggest(m: Maps, imgW: Int, imgH: Int, ratio: Float): Frame {
        val gw = m.w
        val gh = m.h
        val aspect = imgW.toDouble() / imgH
        val wn1: Double
        val hn1: Double
        if (aspect > ratio) { hn1 = 1.0; wn1 = ratio / aspect } else { wn1 = 1.0; hn1 = aspect / ratio }
        fun centered(note: String): Frame {
            val x0 = ((1 - wn1) / 2).toFloat()
            val y0 = ((1 - hn1) / 2).toFloat()
            return Frame(0.5f, 0.5f, 1f, x0, y0, x0 + wn1.toFloat(), y0 + hn1.toFloat(), 0f, note)
        }

        var mean = 0.0
        for (v in m.importance) mean += v
        mean /= m.importance.size
        // trừ "nền" để vùng không có gì (nhiễu đều) không át chủ thể nhỏ: ít nhất 60% trung bình, hoặc trung vị (tối đa nửa giá trị lớn nhất để chủ thể chiếm > nửa ảnh không bị xóa)
        val sortedImp = m.importance.copyOf().also { it.sort() }
        val median = sortedImp[sortedImp.size / 2]
        val floorV = max((mean * 0.6).toFloat(), min(median, 0.5f * sortedImp[sortedImp.size - 1]))
        val imp = FloatArray(m.importance.size) { max(0f, m.importance[it] - floorV) }
        val iMass = Integral(gw, gh) { x, y -> imp[y * gw + x].toDouble() }
        val total = iMass.sum(0, 0, gw, gh)
        if (total < 1e-6) return centered("không thấy chủ thể rõ nên giữ khung ở giữa")
        val iX = Integral(gw, gh) { x, y -> imp[y * gw + x] * (x + 0.5) / gw }
        val iY = Integral(gw, gh) { x, y -> imp[y * gw + x] * (y + 0.5) / gh }
        val faces = m.faces
        var iF: Integral? = null
        var iFX: Integral? = null
        var iFY: Integral? = null
        var faceTotal = 0.0
        if (faces != null) {
            iF = Integral(gw, gh) { x, y -> faces[y * gw + x].toDouble() }
            faceTotal = iF.sum(0, 0, gw, gh)
            if (faceTotal > 1e-6) {
                iFX = Integral(gw, gh) { x, y -> faces[y * gw + x] * (x + 0.5) / gw }
                iFY = Integral(gw, gh) { x, y -> faces[y * gw + x] * (y + 0.5) / gh }
            }
        }
        val hasFaces = iF != null && faceTotal > 1e-6

        // hộp chủ thể = chứa 90% khối lượng quan trọng (5%..95% theo từng trục), nới 10% mỗi phía
        fun extent(axisX: Boolean): Pair<Float, Float> {
            val cells = if (axisX) gw else gh
            val cum = DoubleArray(cells)
            var run = 0.0
            for (i in 0 until cells) {
                run += if (axisX) iMass.sum(i, 0, i + 1, gh) else iMass.sum(0, i, gw, i + 1)
                cum[i] = run
            }
            var lo = 0
            while (lo < cells - 1 && cum[lo] < 0.05 * total) lo++
            var hi = lo
            while (hi < cells - 1 && cum[hi] < 0.95 * total) hi++
            val a = lo.toFloat() / cells
            val b = (hi + 1).toFloat() / cells
            val pad = max(0.02f, 0.1f * (b - a))
            return Pair((a - pad).coerceAtLeast(0f), (b + pad).coerceAtMost(1f))
        }
        val (tx0, tx1) = extent(true)
        val (ty0, ty1) = extent(false)
        val tArea = ((tx1 - tx0) * (ty1 - ty0)).toDouble().coerceAtLeast(1e-4)

        var best: Frame? = null
        var bestZoom = 1f
        for (s in SCALES) {
            val wn = wn1 * s
            val hn = hn1 * s
            val nx = if (wn >= 0.999) 1 else min(gw, 41)
            val ny = if (hn >= 0.999) 1 else min(gh, 41)
            for (ix in 0 until nx) {
                val x0 = if (nx == 1) (1 - wn) / 2 else ix * (1 - wn) / (nx - 1)
                for (iy in 0 until ny) {
                    val y0 = if (ny == 1) (1 - hn) / 2 else iy * (1 - hn) / (ny - 1)
                    val x1 = x0 + wn
                    val y1 = y0 + hn
                    val gx0 = (x0 * gw).roundToInt().coerceIn(0, gw - 1)
                    val gy0 = (y0 * gh).roundToInt().coerceIn(0, gh - 1)
                    val gx1 = (x1 * gw).roundToInt().coerceIn(gx0 + 1, gw)
                    val gy1 = (y1 * gh).roundToInt().coerceIn(gy0 + 1, gh)
                    val inside = iMass.sum(gx0, gy0, gx1, gy1) / total
                    val outside = 1 - inside
                    val faceOut = if (hasFaces) 1 - iF!!.sum(gx0, gy0, gx1, gy1) / faceTotal else 0.0
                    val ox = max(0.0, min(x1, tx1.toDouble()) - max(x0, tx0.toDouble()))
                    val oy = max(0.0, min(y1, ty1.toDouble()) - max(y0, ty0.toDouble()))
                    val boxOut = 1 - ox * oy / tArea
                    val area = wn * hn
                    // khung thừa: chủ thể nên chiếm khoảng ≥30% khung; thấp hơn thì phạt theo log tỉ lệ (chủ thể nhỏ xíu giữa khung rộng -> siết khung lại)
                    val waste = max(0.0, kotlin.math.ln(FILL_TARGET / (tArea / area))) / 3.0
                    // trọng tâm chủ thể trong khung (ưu tiên mặt nếu có) so với bốn điểm 1/3
                    var thirds = 0.0
                    val mass = if (hasFaces) iF!!.sum(gx0, gy0, gx1, gy1) else iMass.sum(gx0, gy0, gx1, gy1)
                    if (mass > 1e-9) {
                        val mx = (if (hasFaces) iFX!!.sum(gx0, gy0, gx1, gy1) else iX.sum(gx0, gy0, gx1, gy1)) / mass
                        val my = (if (hasFaces) iFY!!.sum(gx0, gy0, gx1, gy1) else iY.sum(gx0, gy0, gx1, gy1)) / mass
                        val u = ((mx - x0) / wn).toFloat()
                        val v = ((my - y0) / hn).toFloat()
                        var dMin = Float.MAX_VALUE
                        for (p in THIRDS) dMin = min(dMin, hypot(u - p[0], v - p[1]))
                        thirds = (dMin / 0.47f).toDouble()
                    }
                    val wThirds = 0.6 * (1 - min(1.0, tArea / area))
                    val centerDist = hypot((x0 + wn / 2) - 0.5, (y0 + hn / 2) - 0.5)
                    val cost = 3.0 * outside + 2.0 * boxOut + 8.0 * faceOut + 1.2 * waste + wThirds * thirds + 0.15 * (1 - s) + 0.02 * centerDist
                    if (best == null || cost < best.cost) {
                        best = Frame((x0 + wn / 2).toFloat(), (y0 + hn / 2).toFloat(), s, x0.toFloat(), y0.toFloat(), x1.toFloat(), y1.toFloat(), cost.toFloat(), "")
                        bestZoom = s
                    }
                }
            }
        }
        val b = best ?: return centered("không thấy chủ thể rõ nên giữ khung ở giữa")
        val parts = ArrayList<String>()
        if (hasFaces) parts.add("giữ trọn khuôn mặt")
        if (bestZoom < 0.95f) parts.add("phóng khung vào chủ thể")
        parts.add("chừa lề quanh chủ thể")
        val note = if (b.coversAll) "khung hiện tại đã hợp với chủ thể" else parts.joinToString(", ")
        return Frame(b.cx, b.cy, b.scale, b.x0, b.y0, b.x1, b.y1, b.cost, note)
    }
}
