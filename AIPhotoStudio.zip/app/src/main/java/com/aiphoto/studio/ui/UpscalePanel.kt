@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aiphoto.studio.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiphoto.studio.MainViewModel
import com.aiphoto.studio.UiState
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.Upscale
import com.aiphoto.studio.engine.UpscaleFidelity
import com.aiphoto.studio.engine.UpscaleTarget
import kotlin.math.roundToInt
import com.aiphoto.studio.i18n.Text

/**
 * R46 - thẻ "Phóng to" (Upscale) như các app ảnh khác: chọn ×2 / ×3 / ×4 hoặc đạt cạnh dài Full HD / 2K / 4K, thấy trước kích thước ra (và vì sao bị giới hạn),
 * biết đang dùng AI hay nội suy, có tiến độ + Hủy khi chạy. Kế hoạch tính ở engine/UpscalePlan.kt (có test); việc phóng do MainViewModel.upscale.
 *
 * @param onSettings mở Cài đặt (để tải model AI khi app không có model đi kèm)
 */
@Composable
fun UpscalePanel(st: UiState, vm: MainViewModel, onSettings: () -> Unit) {
    var target by remember { mutableStateOf(UpscaleTarget.X2) }
    var showLicense by remember { mutableStateOf(false) }
    val w = st.imgW
    val h = st.imgH
    val plan = Upscale.plan(target, w, h, ImageEngine.upscaleMaxSide(w, h, ImageEngine.heapHeadroom()))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Phóng to ảnh (Upscale): tăng số điểm ảnh để in khổ lớn hoặc xem trên màn hình lớn. Có model AI thì chi tiết nét hơn nội suy.",
            style = MaterialTheme.typography.bodySmall
        )
        if (!st.hasImage || w <= 0 || h <= 0) {
            Text("Chọn một ảnh để bắt đầu.", style = MaterialTheme.typography.bodySmall)
            return@Column
        }
        Text("Ảnh hiện tại: ${w}×${h} (${mpText(w, h)} MP)", style = MaterialTheme.typography.bodyMedium)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (t in UpscaleTarget.values()) {
                FilterChip(selected = t == target, onClick = { target = t }, enabled = !st.busy, label = { Text(t.label) })
            }
        }
        // kết quả dự kiến
        when {
            !plan.needed -> Text("Ảnh đã đạt cạnh dài này nên không cần phóng thêm.", style = MaterialTheme.typography.bodySmall)
            !plan.canRun -> Text("Không đủ bộ nhớ để phóng thêm ở máy này.", style = MaterialTheme.typography.bodySmall)
            else -> {
                Text("Kết quả: ${plan.outW}×${plan.outH} (×${factorText(plan.factor)}), khoảng ${mpText(plan.outW, plan.outH)} MP", style = MaterialTheme.typography.bodyMedium)
                if (plan.limited) {
                    Text(
                        "Bị giới hạn bởi bộ nhớ hoặc cạnh dài tối đa của máy: chỉ được ×${factorText(plan.factor)} thay vì ×${plan.wantFactor}.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        // đang dùng AI hay nội suy
        if (st.esrganReady) {
            Text(
                "Phóng bằng AI (Real-ESRGAN): chi tiết nét hơn nội suy. Ảnh lớn trên máy yếu có thể mất vài phút — có thể bấm Hủy.",
                style = MaterialTheme.typography.bodySmall
            )
            // R51: kiểm soát chi tiết AI tự thêm vào
            Text("Độ trung thực: ${(st.upscaleFidelity * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = st.upscaleFidelity,
                onValueChange = { vm.setUpscaleFidelity(it) },
                valueRange = 0f..UpscaleFidelity.MAX_BLEND,
                enabled = !st.busy
            )
            Text(
                "Thấp: nét hơn nhưng AI tự thêm nhiều chi tiết. Cao: bám sát ảnh gốc hơn, mềm hơn. Với chữ, giấy tờ, khuôn mặt cần chính xác nên để cao.",
                style = MaterialTheme.typography.labelSmall
            )
            if (plan.canRun) {
                val tiles = Upscale.tileCount(w, h, plan.factor)
                if (tiles > 0) Text("AI sẽ xử lý khoảng $tiles ô ảnh.", style = MaterialTheme.typography.labelSmall)
            }
        } else {
            Text("Chưa có model AI: phóng bằng nội suy + làm nét (ảnh mềm hơn).", style = MaterialTheme.typography.bodySmall)
            if (st.esrganBuiltIn) {
                OutlinedButton(onClick = { vm.useBuiltInEsrgan() }, enabled = !st.busy) { Text("Dùng model AI có sẵn trong app") }
            } else {
                OutlinedButton(onClick = onSettings) { Text("Mở Cài đặt để tải model AI") }
            }
        }
        if (st.busy && st.upscaleTotal > 0) {
            Text(
                if (st.upscaleEtaSec >= 0) "Đang phóng to: ${st.upscaleDone}/${st.upscaleTotal} ô, còn khoảng ${st.upscaleEtaSec} giây"
                else "Đang phóng to: ${st.upscaleDone}/${st.upscaleTotal} ô",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.upscale(target) }, enabled = !st.busy && plan.canRun) { Text("Phóng to ảnh") }
            if (st.busy) OutlinedButton(onClick = { vm.cancel() }) { Text("Hủy") }
            if (st.esrganReady) TextButton(onClick = { showLicense = true }) { Text("Giấy phép model") }
        }
        Text(
            "Các thao tác này làm đổi ảnh nền nên các lớp sẽ được gộp vào ảnh (vẫn hoàn tác được).",
            style = MaterialTheme.typography.labelSmall
        )
    }
    if (showLicense) {
        val text = remember { vm.builtInLicenseText() }
        AlertDialog(
            onDismissRequest = { showLicense = false },
            title = { Text("Giấy phép model phóng to (Real-ESRGAN)") },
            text = {
                Column(modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text(text.ifBlank { "Không đọc được tệp giấy phép." }, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showLicense = false }) { Text("Đóng") } }
        )
    }
}

/** Triệu điểm ảnh, 1 chữ số thập phân theo ngôn ngữ máy. */
private fun mpText(w: Int, h: Int): String = "%.1f".format(w.toDouble() * h / 1_000_000.0)

private fun factorText(f: Float): String = "%.2f".format(f).trimEnd('0').trimEnd('.', ',')
