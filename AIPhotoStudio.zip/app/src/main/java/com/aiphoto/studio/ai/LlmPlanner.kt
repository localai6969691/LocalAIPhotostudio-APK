package com.aiphoto.studio.ai

import android.content.Context
import org.json.JSONObject

/**
 * Biến prompt tự do (và, nếu model đa phương thức, cả ẢNH) thành danh sách phép chỉnh sửa dạng JSON bằng LLM chạy hoàn toàn trên máy.
 * Backend sinh văn bản là [TextGen]: MediaPipe LLM Inference (.task, Gemma 3 1B - đang ở chế độ bảo trì) hoặc LiteRT-LM (.litertlm,
 * Gemma 3n/4, GPU, nhận ảnh; chỉ có khi build với -PuseLiteRtLm=true). Chọn theo đuôi tệp model, xem [LlmBackends].
 * Toàn bộ phần còn lại của app chỉ phụ thuộc vào hàm [planFull]/[planFromImage].
 */
class LlmPlanner(private val gen: TextGen) : AutoCloseable {

    constructor(context: Context, modelPath: String) : this(LlmBackends.create(context, modelPath))

    /** Bộ tăng tốc đang chạy (NPU / GPU / CPU / MediaPipe) - lấy từ backend. */
    val backendName: String get() = gen.backendName

    /** true = có thể gọi [planFromImage] (model đa phương thức đã nạp bộ mã hóa ảnh). */
    val supportsImage: Boolean get() = gen.supportsImage

    /** Trả về danh sách phép chỉnh (chưa sanitize) hoặc null nếu model trả lời không đúng định dạng. */
    @Synchronized
    fun plan(userPrompt: String): List<EditOp>? = planFull(userPrompt)?.ops?.takeIf { it.isNotEmpty() }

    /** Như [plan] nhưng giữ cả các nhóm phép chỉnh theo vùng ("scope"). */
    @Synchronized
    fun planFull(userPrompt: String): PlanJson.Parsed? =
        PlanJson.parseFull(gen.generate(LlmPrompts.plan(userPrompt)))

    /**
     * Nhìn ảnh ([imagePath] = tệp JPEG/PNG đã thu nhỏ) + yêu cầu -> kế hoạch chỉnh. Null nếu backend không hỗ trợ ảnh hoặc model
     * trả lời sai định dạng. Ảnh KHÔNG rời máy (khác Agent AI ở máy chủ).
     */
    @Synchronized
    fun planFromImage(imagePath: String, userPrompt: String): PlanJson.Parsed? {
        if (!gen.supportsImage) return null
        return PlanJson.parseFull(gen.generate(LlmPrompts.imagePlan(userPrompt), imagePath))
    }

    /** Dịch mô tả (vd. tiếng Việt) thành prompt tiếng Anh ngắn cho Stable Diffusion. */
    @Synchronized
    fun translateToEnglish(text: String): String {
        val body = LlmPrompts.translate(text) ?: return text
        val out = gen.generate(body).trim().lines().firstOrNull().orEmpty().trim().trim('"')
        return out.ifBlank { text }
    }

    override fun close() {
        try { gen.close() } catch (e: Throwable) { }
    }
}

object PlanJson {

    class Parsed(val ops: List<EditOp>, val scoped: List<ScopedOps>)

    /** Phép chỉnh không có "scope" -> toàn ảnh; có "scope" hợp lệ -> nhóm theo vùng. Null nếu không có phép chỉnh nào. */
    fun parseFull(raw: String): Parsed? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try {
            val root = JSONObject(raw.substring(start, end + 1))
            val arr = root.optJSONArray("ops") ?: return null
            val ops = ArrayList<EditOp>()
            val scoped = ArrayList<ScopedOps>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val type = OpType.fromKey(o.optString("op")) ?: continue
                val value = o.optDouble("value", 1.0).toFloat()
                val arg = o.optString("arg", "").ifBlank { null }
                val scope = o.optString("scope", "").trim().lowercase()
                val op = EditOp(type, value, arg)
                if (scope.isEmpty()) ops.add(op)
                else if (scope in Scope.ALL) scoped.add(ScopedOps(scope, listOf(op)))
            }
            if (ops.isEmpty() && scoped.isEmpty()) null else Parsed(ops, scoped)
        } catch (e: Exception) {
            null
        }
    }

    fun parse(raw: String): List<EditOp>? = parseFull(raw)?.ops?.takeIf { it.isNotEmpty() }
}
