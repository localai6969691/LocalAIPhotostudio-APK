package com.aiphoto.studio.engine

import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * "Làm nét lại" (Unblur) KHÔNG cần model: ước lượng nhân mờ từ chính ảnh rồi khử tích chập.
 *  - Nhân mờ thuộc hai họ: Gauss đẳng hướng (mất nét, rung nhẹ) và nhòe chuyển động thẳng (độ dài + góc).
 *    Chuỗi mô tả ([Psf]): "g:<σ/cạnh dài>" hoặc "m:<độ dài/cạnh dài>,<góc°>" — theo TỈ LỆ cạnh dài nên cùng một mô tả đúng cho
 *    ảnh xem trước và ảnh đầy đủ.
 *  - Ước lượng ([estimate]): đo ĐỘ RỘNG CẠNH (khoảng cách 10%–90% của bước chuyển) trên vài nghìn cạnh rõ, chia theo hướng pháp tuyến;
 *    nhân nhòe chuyển động làm độ rộng phụ thuộc hướng: width² = c0 + c1·cos2φ + c2·sin2φ (hồi quy bình phương tối thiểu) cho độ dài
 *    + góc nhòe, phần đẳng hướng còn lại (trừ độ rộng cạnh "nét" tối thiểu [INTRINSIC_WIDTH]) cho σ Gauss. Dưới ngưỡng
 *    ([MIN_SIGMA], [MIN_MOTION]) → arg null ("ảnh đã khá nét", không làm gì).
 *  - Khử mờ: Richardson–Lucy có điều hòa TV (Dey và cộng sự 2006) trên kênh độ chói, giới hạn tỉ lệ hiệu chỉnh để hạn chế quầng.
 *  - Ảnh lớn: khử mờ ở cạnh dài ≤ [CAP], phần CHÊNH (sau − trước) phóng lên rồi cộng vào ảnh gốc: chi phí có trần, ảnh giữ nguyên
 *    độ phân giải nhưng chi tiết siêu mịn vượt độ phân giải CAP không được phục hồi.
 * Không phải phép màu: ảnh mờ nặng/nhiễu mạnh không cứu được; nhân mờ KHÔNG đều trong khung (rung xoay, vật chuyển động riêng) cũng không.
 */
object Deblur {

    const val CAP = 1280
    const val SIGMA_MIN = 0.6f
    const val SIGMA_MAX = 4.0f
    const val LEN_MIN = 2.5f
    const val LEN_MAX = 40f
    /** Điều hòa TV của Richardson–Lucy (đơn vị ảnh 0..1). */
    const val TV_LAMBDA = 0.004f
    const val ITERS = 20

    class Psf(val gauss: Boolean, val size: Float, val angle: Float = 0f)

    fun parse(arg: String?): Psf? {
        val a = arg?.trim() ?: return null
        if (a.startsWith("g:")) {
            val s = a.substring(2).toFloatOrNull() ?: return null
            if (!(s > 0f && s < 0.05f)) return null
            return Psf(true, s)
        }
        if (a.startsWith("m:")) {
            val p = a.substring(2).split(',')
            val l = p.getOrNull(0)?.trim()?.toFloatOrNull() ?: return null
            val t = p.getOrNull(1)?.trim()?.toFloatOrNull() ?: 0f
            if (!(l > 0f && l < 0.1f) || t.isNaN()) return null
            return Psf(false, l, ((t % 180f) + 180f) % 180f)
        }
        return null
    }

    fun format(p: Psf): String =
        if (p.gauss) String.format(Locale.US, "g:%.5f", p.size) else String.format(Locale.US, "m:%.5f,%.1f", p.size, p.angle)

    /** Chuỗi hợp lệ viết lại chuẩn, hoặc null nếu không hợp lệ (arg null/rỗng nghĩa là "tự ước lượng"). */
    fun canonical(arg: String?): String? = parse(arg)?.let { format(it) }

    fun describe(arg: String?): String {
        val p = parse(arg) ?: return "tự nhận dạng độ mờ"
        return if (p.gauss) "mờ lấy nét" else "nhòe chuyển động góc ${p.angle.toInt()}°"
    }

    // ------------------------------------------------------------------ nhân mờ
    /** Nhân Gauss tách được ([sep] 1 chiều, bán kính [radius]) hoặc nhân thưa [dx],[dy],[wt] (tổng trọng số = 1). */
    class Kernel(val sep: FloatArray?, val dx: IntArray, val dy: IntArray, val wt: FloatArray, val radius: Int)

    fun gaussKernel(sigma: Float): Kernel {
        val r = max(1, ceil(3.0 * sigma).toInt())
        val g = FloatArray(2 * r + 1)
        var s = 0f
        for (i in -r..r) { val v = exp(-(i * i) / (2.0 * sigma * sigma)).toFloat(); g[i + r] = v; s += v }
        for (i in g.indices) g[i] /= s
        return Kernel(g, IntArray(0), IntArray(0), FloatArray(0), r)
    }

    /** Nhân nhòe chuyển động: đoạn thẳng dài [len] điểm ảnh, hướng [angleDeg] (0 = ngang, tăng theo chiều kim đồng hồ), rải song tuyến tính. */
    fun motionKernel(len: Float, angleDeg: Float): Kernel {
        val a = Math.toRadians(angleDeg.toDouble())
        val ux = cos(a)
        val uy = sin(a)
        val n = ceil(len * 4.0).toInt() + 1
        val acc = HashMap<Long, Float>()
        fun put(ix: Int, iy: Int, v: Float) { val key = (ix.toLong() shl 32) xor (iy.toLong() and 0xffffffffL); acc[key] = (acc[key] ?: 0f) + v }
        for (i in 0 until n) {
            val t = if (n == 1) 0.0 else (i.toDouble() / (n - 1) - 0.5) * len
            val px = t * ux
            val py = t * uy
            val x0 = Math.floor(px).toInt()
            val y0 = Math.floor(py).toInt()
            val fx = (px - x0).toFloat()
            val fy = (py - y0).toFloat()
            val wgt = 1f / n
            put(x0, y0, wgt * (1 - fx) * (1 - fy))
            put(x0 + 1, y0, wgt * fx * (1 - fy))
            put(x0, y0 + 1, wgt * (1 - fx) * fy)
            put(x0 + 1, y0 + 1, wgt * fx * fy)
        }
        val keys = acc.keys.sorted()
        val dx = ArrayList<Int>(); val dy = ArrayList<Int>(); val wt = ArrayList<Float>()
        var total = 0f
        for (k in keys) {
            val v = acc[k]!!
            if (v < 1e-4f) continue
            dx.add((k shr 32).toInt()); dy.add(k.toInt()); wt.add(v); total += v
        }
        var rad = 1
        for (i in dx.indices) rad = max(rad, max(abs(dx[i]), abs(dy[i])))
        return Kernel(null, dx.toIntArray(), dy.toIntArray(), FloatArray(wt.size) { wt[it] / total }, rad)
    }

    /** Nhân tương ứng [p] ở ảnh [iw]×[ih]; null nếu nhân nhỏ hơn nửa ngưỡng tối thiểu (mờ không đáng kể ở độ phân giải này). */
    fun kernelFor(p: Psf, iw: Int, ih: Int): Kernel? {
        val px = p.size * max(iw, ih)
        return if (p.gauss) {
            if (px < SIGMA_MIN * 0.5f) null else gaussKernel(px.coerceIn(SIGMA_MIN, SIGMA_MAX))
        } else {
            if (px < LEN_MIN * 0.5f) null else motionKernel(px.coerceIn(LEN_MIN, LEN_MAX), p.angle)
        }
    }

    /** Tích chập có đệm lặp biên; giữ sẵn bộ đệm để vòng lặp Richardson–Lucy không cấp phát lại. */
    private class Conv(val w: Int, val h: Int, val k: Kernel) {
        private val r = k.radius
        private val padW = w + 2 * r
        private val pad = FloatArray(padW * (h + 2 * r))
        private val tmp = if (k.sep != null) FloatArray(w * h) else FloatArray(0)
        private val offs = IntArray(k.wt.size)
        private val offsFlip = IntArray(k.wt.size)
        init {
            // out(p) = Σ k(d)·in(p − d)  (tích chập thật); phép chuyển vị (flip) dùng in(p + d)
            for (i in offs.indices) {
                offs[i] = -k.dy[i] * padW - k.dx[i]
                offsFlip[i] = k.dy[i] * padW + k.dx[i]
            }
        }

        private fun fill(src: FloatArray) {
            for (y in 0 until h + 2 * r) {
                val sy = (y - r).coerceIn(0, h - 1)
                val sRow = sy * w
                val dRow = y * padW
                for (x in 0 until padW) pad[dRow + x] = src[sRow + (x - r).coerceIn(0, w - 1)]
            }
        }

        fun apply(src: FloatArray, dst: FloatArray, flip: Boolean) {
            val sep = k.sep
            if (sep != null) {
                // ngang rồi dọc (Gauss đối xứng nên không cần lật); vùng trong chạy không kẹp chỉ số, chỉ viền mới kẹp
                val n = sep.size
                for (y in 0 until h) {
                    val row = y * w
                    for (x in 0 until w) {
                        var acc = 0f
                        if (x >= r && x < w - r) {
                            val b0 = row + x - r
                            for (i in 0 until n) acc += sep[i] * src[b0 + i]
                        } else {
                            for (i in 0 until n) acc += sep[i] * src[row + (x + i - r).coerceIn(0, w - 1)]
                        }
                        tmp[row + x] = acc
                    }
                }
                for (y in 0 until h) {
                    val inner = y >= r && y < h - r
                    for (x in 0 until w) {
                        var acc = 0f
                        if (inner) {
                            val b0 = (y - r) * w + x
                            for (i in 0 until n) acc += sep[i] * tmp[b0 + i * w]
                        } else {
                            for (i in 0 until n) acc += sep[i] * tmp[(y + i - r).coerceIn(0, h - 1) * w + x]
                        }
                        dst[y * w + x] = acc
                    }
                }
                return
            }
            fill(src)
            val o = if (flip) offsFlip else offs
            val wt = k.wt
            for (y in 0 until h) {
                val rowBase = (y + r) * padW + r
                for (x in 0 until w) {
                    val c = rowBase + x
                    var acc = 0f
                    for (t in wt.indices) acc += wt[t] * pad[c + o[t]]
                    dst[y * w + x] = acc
                }
            }
        }
    }

    // ------------------------------------------------------------------ Richardson–Lucy + TV
    /** Khử mờ kênh [y] (0..1, w×h) với nhân [k]. */
    fun richardsonLucy(y: FloatArray, w: Int, h: Int, k: Kernel, iters: Int = ITERS, tv: Float = TV_LAMBDA): FloatArray {
        val n = w * h
        val conv = Conv(w, h, k)
        val x = y.copyOf()
        val est = FloatArray(n)
        val ratio = FloatArray(n)
        val corr = FloatArray(n)
        val pxa = FloatArray(n)
        val pya = FloatArray(n)
        val eps = 1e-3f
        repeat(iters) {
            conv.apply(x, est, false)
            for (i in 0 until n) ratio[i] = ((y[i] + eps) / (est[i] + eps)).coerceIn(0.5f, 2f)
            conv.apply(ratio, corr, true)
            if (tv > 0f) {
                for (yy in 0 until h) for (xx in 0 until w) {
                    val i = yy * w + xx
                    val gx = if (xx < w - 1) x[i + 1] - x[i] else 0f
                    val gy = if (yy < h - 1) x[i + w] - x[i] else 0f
                    val nrm = sqrt(gx * gx + gy * gy + 1e-4f)
                    pxa[i] = gx / nrm
                    pya[i] = gy / nrm
                }
                for (yy in 0 until h) for (xx in 0 until w) {
                    val i = yy * w + xx
                    val div = pxa[i] - (if (xx > 0) pxa[i - 1] else 0f) + pya[i] - (if (yy > 0) pya[i - w] else 0f)
                    x[i] = (x[i] * corr[i] / max(0.2f, 1f - tv * div)).coerceIn(0f, 1f)
                }
            } else {
                for (i in 0 until n) x[i] = (x[i] * corr[i]).coerceIn(0f, 1f)
            }
        }
        return x
    }

    // ------------------------------------------------------------------ ước lượng nhân mờ
    /** [arg] = mô tả nhân tìm được (null = không thấy mờ đáng sửa); [note] giải thích; [widthPx] = độ rộng cạnh trung vị (điểm ảnh). */
    class Estimate(val arg: String?, val widthPx: Float, val note: String)

    /** Độ rộng cạnh của ảnh "nét" (điểm ảnh, sau làm mượt 3×3): cạnh nét thật trong ảnh chụp cũng không bao giờ sắc hơn mức này. */
    const val INTRINSIC_WIDTH = 2.3f
    /** Phần mờ DƯ (σ Gauss tương đương) tối thiểu để coi là mờ lấy nét đáng sửa, tính theo điểm ảnh ở độ phân giải đang xét. */
    const val MIN_SIGMA = 0.9f
    /** Độ dài nhòe chuyển động tối thiểu (điểm ảnh) để coi là có rung/nhòe thẳng. */
    const val MIN_MOTION = 3.0f
    private const val BINS = 12
    private const val MIN_EDGES_PER_BIN = 20
    private const val PROFILE_R = 24f

    private fun smooth3(a: FloatArray, w: Int, h: Int): FloatArray {
        val t = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w
            t[i + x] = 0.25f * a[i + max(0, x - 1)] + 0.5f * a[i + x] + 0.25f * a[i + min(w - 1, x + 1)]
        }
        val o = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            o[y * w + x] = 0.25f * t[max(0, y - 1) * w + x] + 0.5f * t[y * w + x] + 0.25f * t[min(h - 1, y + 1) * w + x]
        }
        return o
    }

    private fun sample(a: FloatArray, w: Int, h: Int, x: Float, y: Float): Float {
        val cx = x.coerceIn(0f, w - 1f)
        val cy = y.coerceIn(0f, h - 1f)
        val x0 = cx.toInt()
        val y0 = cy.toInt()
        val x1 = min(w - 1, x0 + 1)
        val y1 = min(h - 1, y0 + 1)
        val fx = cx - x0
        val fy = cy - y0
        return (a[y0 * w + x0] * (1 - fx) + a[y0 * w + x1] * fx) * (1 - fy) + (a[y1 * w + x0] * (1 - fx) + a[y1 * w + x1] * fx) * fy
    }

    /** Một cạnh: hướng pháp tuyến φ ∈ [0,π) và độ rộng (điểm ảnh). */
    class EdgeSample(val phi: Float, val width: Float)

    /**
     * Đo độ rộng các cạnh mạnh, cô lập: dọc pháp tuyến lấy mẫu đạo hàm g(t), rộng = Σg / max g trên đoạn mà g còn ≥ 10% đỉnh.
     * Cạnh nhòe theo phương chuyển động rộng hơn cạnh song song với phương đó nên độ rộng phụ thuộc hướng.
     */
    fun edgeWidths(lum: FloatArray, w: Int, h: Int, maxEdges: Int = 6000): List<EdgeSample> {
        val a = smooth3(lum, w, h)
        val n = w * h
        val gm = FloatArray(n)
        val gxA = FloatArray(n)
        val gyA = FloatArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = (a[i + 1] - a[i - 1]) * 0.5f
            val gy = (a[i + w] - a[i - w]) * 0.5f
            gxA[i] = gx; gyA[i] = gy
            gm[i] = sqrt(gx * gx + gy * gy)
        }
        // ngưỡng: top 3% độ lớn gradient nhưng không dưới 0,04/điểm ảnh
        val sorted = gm.copyOf(); java.util.Arrays.sort(sorted)
        val thr = max(0.04f, sorted[(n * 0.97f).toInt().coerceIn(0, n - 1)])
        val cand = ArrayList<Int>()
        for (y in 4 until h - 4) for (x in 4 until w - 4) {
            val i = y * w + x
            val g = gm[i]
            if (g < thr) continue
            val ux = gxA[i] / g
            val uy = gyA[i] / g
            // cực đại cục bộ theo hướng gradient (NMS)
            val g1 = sample(gm, w, h, x + ux, y + uy)
            val g2 = sample(gm, w, h, x - ux, y - uy)
            if (g >= g1 && g > g2) cand.add(i)
        }
        val step = max(1, cand.size / maxEdges)
        val out = ArrayList<EdgeSample>()
        val half = (PROFILE_R * 2).toInt()
        val prof = FloatArray(2 * half + 1)
        var ci = 0
        while (ci < cand.size) {
            val i = cand[ci]
            ci += step
            val x = (i % w).toFloat()
            val y = (i / w).toFloat()
            var ux = gxA[i] / gm[i]
            var uy = gyA[i] / gm[i]
            for (k in -half..half) {
                val t = k * 0.5f
                prof[k + half] = sample(a, w, h, x + ux * (t + 0.5f), y + uy * (t + 0.5f)) - sample(a, w, h, x + ux * (t - 0.5f), y + uy * (t - 0.5f))
            }
            // đỉnh gần tâm (±1 điểm ảnh)
            var pk = half
            for (k in half - 2..half + 2) if (prof[k] > prof[pk]) pk = k
            val peak = prof[pk]
            if (peak < thr * 0.7f) continue
            var sum = peak
            var k = pk + 1
            while (k <= 2 * half && prof[k] >= 0.1f * peak) { sum += prof[k]; k++ }
            val rightOpen = k > 2 * half
            k = pk - 1
            while (k >= 0 && prof[k] >= 0.1f * peak) { sum += prof[k]; k-- }
            val leftOpen = k < 0
            if (rightOpen || leftOpen) continue // cạnh không khép lại trong cửa sổ: không phải cạnh cô lập
            val width = sum * 0.5f / peak // bước lấy mẫu 0,5 điểm ảnh
            var phi = Math.atan2(gyA[i].toDouble(), gxA[i].toDouble())
            if (phi < 0) phi += Math.PI
            if (phi >= Math.PI) phi -= Math.PI
            out.add(EdgeSample(phi.toFloat(), width))
        }
        return out
    }

    /** Ước lượng nhân mờ từ kênh sáng [lum] (0..1, w×h; nên ở cạnh dài ≤ [CAP]). arg null = không thấy mờ đáng sửa. */
    fun estimate(lum: FloatArray, w: Int, h: Int): Estimate {
        require(lum.size == w * h)
        if (min(w, h) < 48) return Estimate(null, 0f, "ảnh quá nhỏ để nhận dạng độ mờ")
        val edges = edgeWidths(lum, w, h)
        if (edges.size < 60) return Estimate(null, 0f, "ít cạnh rõ để nhận dạng độ mờ")
        val long = max(w, h).toFloat()
        // trung vị độ rộng theo từng ô hướng
        val binW = Array(BINS) { ArrayList<Float>() }
        for (e in edges) binW[min(BINS - 1, (e.phi / Math.PI.toFloat() * BINS).toInt())].add(e.width)
        val allW = edges.map { it.width }.sorted()
        val medAll = allW[allW.size / 2]
        // hồi quy bình phương tối thiểu: width² = c0 + c1·cos2φ + c2·sin2φ (trọng số = số cạnh)
        var s00 = 0.0; var s01 = 0.0; var s02 = 0.0; var s11 = 0.0; var s12 = 0.0; var s22 = 0.0
        var b0 = 0.0; var b1 = 0.0; var b2 = 0.0
        var used = 0
        for (b in 0 until BINS) {
            val l = binW[b]
            if (l.size < MIN_EDGES_PER_BIN) continue
            l.sort()
            val m = l[l.size / 2].toDouble()
            val phi = (b + 0.5) / BINS * Math.PI
            val c = cos(2 * phi); val sn = sin(2 * phi)
            val wt = l.size.toDouble()
            val y2 = m * m
            s00 += wt; s01 += wt * c; s02 += wt * sn; s11 += wt * c * c; s12 += wt * c * sn; s22 += wt * sn * sn
            b0 += wt * y2; b1 += wt * y2 * c; b2 += wt * y2 * sn
            used++
        }
        var c0 = medAll.toDouble() * medAll
        var c1 = 0.0
        var c2 = 0.0
        if (used >= 5) {
            // giải hệ 3×3 (Cramer)
            fun det(a: DoubleArray) = a[0] * (a[4] * a[8] - a[5] * a[7]) - a[1] * (a[3] * a[8] - a[5] * a[6]) + a[2] * (a[3] * a[7] - a[4] * a[6])
            val m = doubleArrayOf(s00, s01, s02, s01, s11, s12, s02, s12, s22)
            val d = det(m)
            if (abs(d) > 1e-9) {
                c0 = det(doubleArrayOf(b0, s01, s02, b1, s11, s12, b2, s12, s22)) / d
                c1 = det(doubleArrayOf(s00, b0, s02, s01, b1, s12, s02, b2, s22)) / d
                c2 = det(doubleArrayOf(s00, s01, b0, s01, s11, b1, s02, s12, b2)) / d
            }
        }
        val amp = sqrt(c1 * c1 + c2 * c2)
        val motionLen = sqrt(2.0 * amp).toFloat()                       // width² = a + L²·cos²(φ − θ)  →  biên độ cos2φ = L²/2
        val theta = (0.5 * Math.atan2(c2, c1)).let { if (it < 0) it + Math.PI else it }
        val iso = max(0.0, c0 - motionLen.toDouble() * motionLen / 2.0)      // a = c0 − L²/2 : phần đẳng hướng
        val excess = max(0.0, iso - INTRINSIC_WIDTH.toDouble() * INTRINSIC_WIDTH)
        val sigma = sqrt(excess / (2 * Math.PI)).toFloat()
        val note0 = "độ rộng cạnh trung vị ${"%.1f".format(Locale.US, medAll)} px"
        if (motionLen >= MIN_MOTION && used >= 5) {
            val psf = Psf(false, motionLen / long, Math.toDegrees(theta).toFloat())
            return Estimate(format(psf), medAll, "nhòe chuyển động ~${"%.0f".format(Locale.US, motionLen)} px góc ${Math.toDegrees(theta).toInt()}° ($note0)")
        }
        if (sigma >= MIN_SIGMA) {
            return Estimate(format(Psf(true, sigma / long)), medAll, "mờ lấy nét σ≈${"%.1f".format(Locale.US, sigma)} px ($note0)")
        }
        return Estimate(null, medAll, "ảnh đã khá nét ($note0)")
    }

    // ------------------------------------------------------------------ áp dụng lên ảnh ARGB
    fun lumaOf(px: IntArray): FloatArray = FloatArray(px.size) {
        val p = px[it]
        (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
    }

    /**
     * Làm nét lại ảnh ARGB [px] (w×h). [strength] 0..1 = phần chênh khử mờ được cộng vào; [arg] = mô tả nhân ([parse]) hoặc null để tự ước lượng.
     * Không ước lượng được / ảnh đã nét → trả lại [px] nguyên vẹn. Alpha giữ nguyên; màu giữ nguyên (chỉ cộng cùng một độ chênh chói vào R,G,B).
     */
    fun apply(px: IntArray, w: Int, h: Int, strength: Float, arg: String?, iters: Int = ITERS): IntArray {
        val s = strength.coerceIn(0f, 1f)
        if (s < 0.01f || w < 8 || h < 8 || px.size != w * h) return px
        val y = lumaOf(px)
        val (iw, ih) = Resample.capped(w, h, CAP)
        val same = iw == w && ih == h
        val yi = if (same) y else Resample.area(y, w, h, iw, ih)
        val psf = parse(arg) ?: parse(estimate(yi, iw, ih).arg) ?: return px
        val k = kernelFor(psf, iw, ih) ?: return px
        val dec = richardsonLucy(yi, iw, ih, k, iters, TV_LAMBDA)
        val di = FloatArray(dec.size) { dec[it] - yi[it] }
        val delta = if (same) di else Resample.bilinear(di, iw, ih, w, h)
        return IntArray(px.size) { i ->
            val p = px[i]
            val d = s * 255f * delta[i]
            val r = (((p shr 16) and 255) + d + 0.5f).toInt().coerceIn(0, 255)
            val g = (((p shr 8) and 255) + d + 0.5f).toInt().coerceIn(0, 255)
            val b = ((p and 255) + d + 0.5f).toInt().coerceIn(0, 255)
            (p and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
    }
}
