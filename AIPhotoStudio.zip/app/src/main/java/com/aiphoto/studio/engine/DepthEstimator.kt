package com.aiphoto.studio.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.graphics.Bitmap
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Tiền xử lý cho model đo độ sâu từ MỘT ảnh (thuần Kotlin để kiểm thử). Hợp đồng đã tra cứu (10/2026) cho Depth Anything V2 Small bản ONNX
 * (DINOv2-ViT-S + DPT, ~25 triệu tham số, **Apache-2.0** — chỉ bản Small; bản Base/Large/Giant là CC-BY-NC nên KHÔNG dùng):
 *  - đầu vào `pixel_values [1,3,H,W]` float32 RGB, (điểm/255 − mean) / std theo ImageNet, H và W là bội của 14 (kích thước mảnh của ViT);
 *  - đầu ra `predicted_depth [1,H,W]` = nghịch đảo độ sâu TƯƠNG ĐỐI: giá trị lớn = gần camera, thang đo theo từng ảnh (không phải mét);
 *  - cỡ vào chuẩn 518 ở cạnh dài (giữ tỉ lệ); một số bản xuất ONNX cố định 518×518 (ép vuông) hoặc đóng băng cỡ đầu ra — nên cỡ đầu vào lấy theo shape
 *    model khai báo nếu cố định, và cỡ đầu ra lấy theo tensor thật trả về chứ không suy từ cỡ vào.
 * Cùng giao diện (vào ảnh RGB chuẩn hóa ImageNet, ra bản đồ tương đối) cũng khớp họ MiDaS small (MIT) nếu bản xuất của nó nhận cỡ bội của 14 hoặc cố định.
 */
object DepthProfile {
    const val PATCH = 14
    const val LONG_EDGE = 518
    val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)
    val STD = floatArrayOf(0.229f, 0.224f, 0.225f)

    /**
     * Kích thước (cao, rộng) đưa vào model. Shape cố định ([fixedH] và [fixedW] > 0) thì theo shape đó; ngược lại cạnh dài = [longEdge] (làm tròn về bội của
     * [PATCH], tối thiểu một mảnh), cạnh ngắn theo tỉ lệ rồi cũng làm tròn về bội của [PATCH] (tối thiểu một mảnh).
     */
    fun inputSize(h: Int, w: Int, fixedH: Int, fixedW: Int, longEdge: Int = LONG_EDGE): Pair<Int, Int> {
        if (fixedH > 0 && fixedW > 0) return Pair(fixedH, fixedW)
        val hh = max(1, h)
        val ww = max(1, w)
        val target = max(PATCH, longEdge)
        val k = target.toFloat() / max(hh, ww)
        val rh = max(1, (hh * k / PATCH).roundToInt()) * PATCH
        val rw = max(1, (ww * k / PATCH).roundToInt()) * PATCH
        return Pair(rh, rw)
    }

    /** Điểm ảnh ARGB → tensor NCHW (3 · n số thực): (điểm/255 − mean) / std theo từng kênh R, G, B. */
    fun toNchw(px: IntArray): FloatArray {
        val plane = px.size
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val p = px[i]
            data[i] = (((p shr 16) and 255) / 255f - MEAN[0]) / STD[0]
            data[plane + i] = (((p shr 8) and 255) / 255f - MEAN[1]) / STD[1]
            data[2 * plane + i] = ((p and 255) / 255f - MEAN[2]) / STD[2]
        }
        return data
    }
}

/**
 * Đo độ sâu tương đối từ một ảnh bằng model ONNX (xem [DepthProfile]); TÙY CHỌN — không nạp model thì Reframe dùng độ sâu giả như R29.
 * Chỉ nhận model có input `[batch,3,H,W]`; kết quả là [Reframe.Field] THÔ (chưa chuẩn hóa), việc kéo giãn do [Reframe.stretch] làm.
 */
class DepthEstimator(modelPath: String) : AutoCloseable {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String
    /** Số lần suy luận THÀNH CÔNG của phiên này (0 = lần đầu: có thể gồm biên dịch / cấp phát nên [Adaptive] không học từ nó). */
    @Volatile var runs: Int = 0
        private set
    /** Kích thước cố định (cao, rộng) nếu model khai báo shape tĩnh; 0 = động. */
    private val fixedH: Int
    private val fixedW: Int

    init {
        val s = OrtTuning.createSession(env, modelPath)
        var name = ""
        var h0 = 0
        var w0 = 0
        try {
            name = s.inputNames.iterator().next()
            val shape = (s.inputInfo[name]?.info as? TensorInfo)?.shape
            require(shape != null && shape.size == 4) { "Không phải model ảnh (cần input [batch,3,H,W])" }
            require(shape[1] == 3L || shape[1] < 0L) { "Model đo độ sâu cần input 3 kênh màu, model này có ${shape[1]} kênh" }
            h0 = if (shape[2] > 0) shape[2].toInt() else 0
            w0 = if (shape[3] > 0) shape[3].toInt() else 0
        } catch (e: Throwable) {
            // model sai hợp đồng: đóng phiên rồi mới báo lỗi, tránh giữ tệp / bộ nhớ của một model không dùng được
            try { s.close() } catch (e2: Throwable) { }
            throw e
        }
        session = s
        inputName = name
        fixedH = h0
        fixedW = w0
    }

    /** Đo độ sâu tương đối của [bitmap]. [longEdge] chỉ có tác dụng khi model nhận cỡ động (shape cố định thì theo shape). Gọi trên luồng nền. */
    @Synchronized
    fun estimate(bitmap: Bitmap, longEdge: Int = DepthProfile.LONG_EDGE): Reframe.Field {
        val size = DepthProfile.inputSize(bitmap.height, bitmap.width, fixedH, fixedW, longEdge)
        val inH = size.first
        val inW = size.second
        val small = Bitmap.createScaledBitmap(bitmap, inW, inH, true)
        val px = IntArray(inW * inH)
        small.getPixels(px, 0, inW, 0, 0, inW, inH)
        if (small !== bitmap) small.recycle()
        val data = DepthProfile.toNchw(px)

        val rows = ArrayList<FloatArray>()
        val shape = longArrayOf(1, 3, inH.toLong(), inW.toLong())
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { tensor ->
            session.run(mapOf(inputName to tensor)).use { result ->
                collectRows(result.get(0).value, rows)
            }
        }
        require(rows.isNotEmpty()) { "Model không trả về bản đồ độ sâu hợp lệ" }
        val mh = rows.size
        val mw = rows[0].size
        require(mw > 0 && rows.all { it.size == mw }) { "Bản đồ độ sâu không đều hàng" }
        val out = FloatArray(mw * mh)
        for (y in 0 until mh) System.arraycopy(rows[y], 0, out, y * mw, mw)
        runs++
        return Reframe.Field(out, mw, mh)
    }

    private fun collectRows(v: Any?, acc: MutableList<FloatArray>) {
        when (v) {
            is FloatArray -> acc.add(v)
            is Array<*> -> for (e in v) collectRows(e, acc)
        }
    }

    override fun close() {
        try { session.close() } catch (e: Throwable) { }
    }
}
