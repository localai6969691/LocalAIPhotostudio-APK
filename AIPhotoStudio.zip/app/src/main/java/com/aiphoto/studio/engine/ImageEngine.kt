package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.OpType
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Cho phép cắm bất kỳ model tách nền nào: trả về mặt nạ foreground 0..1 có kích thước w*h. */
interface Segmenter {
    fun foregroundMask(bitmap: Bitmap): FloatArray
}

/**
 * Bộ máy xử lý ảnh thuần Kotlin (không cần thư viện ngoài). Thứ tự xử lý cố định,
 * không phụ thuộc thứ tự AI trả về: hình học -> tông màu -> chi tiết -> hiệu ứng -> phông.
 */
object ImageEngine {

    /** Trần CỨNG cạnh dài (điểm ảnh) của ảnh sau khi phóng to (giới hạn kích thước bitmap khi hiển thị / xuất); trần thực tế còn bị bộ nhớ hạ thấp thêm ([upscaleMaxSide]). */
    const val UPSCALE_MAX_SIDE = 4096

    /**
     * Số byte trên heap Java cho MỖI ĐIỂM ẢNH ĐẦU RA ở đỉnh của đường phóng, ĐẾM TRỰC TIẾP từ mã: `upscale` → `sharpen` giữ cùng lúc năm mảng Int cỡ ảnh đầu ra
     * (`src` = pixelArray, `Blur.gaussian` giữ `a`, `b`, `tmp`, rồi `out`) = 5 × 4 byte. (Bitmap nằm ở bộ nhớ native từ API 26 nên không tính vào heap Java.)
     */
    const val UPSCALE_HEAP_BYTES_PER_PIXEL = 20
    /** Chỉ dùng tối đa phần này của heap còn trống (chừa chỗ cho GC / cấp phát khác của app). */
    const val UPSCALE_HEAP_SAFETY = 0.6f

    /** Heap Java còn trống (byte) = trần heap − đang dùng. Là biến để bài kiểm đặt giá trị cố định (kết quả không phụ thuộc máy chạy test). */
    @Volatile var heapHeadroom: () -> Long = {
        val rt = Runtime.getRuntime()
        rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
    }

    /**
     * Cạnh dài tối đa cho ảnh sau khi phóng, SUY RA từ heap còn trống thay vì một hằng số: điểm ảnh tối đa = heap·[UPSCALE_HEAP_SAFETY] / [UPSCALE_HEAP_BYTES_PER_PIXEL];
     * giữ tỉ lệ khung của ảnh vào (w×h) nên cạnh dài L thỏa L²/tỉ_lệ = điểm ảnh. Không vượt [UPSCALE_MAX_SIDE], không nhỏ hơn cạnh dài của ảnh vào (thiếu bộ nhớ ⇒ không phóng).
     */
    fun upscaleMaxSide(w: Int, h: Int, headroomBytes: Long): Int {
        val long = max(w, h)
        val short = max(1, min(w, h))
        if (long <= 0) return UPSCALE_MAX_SIDE
        val pixels = max(0L, headroomBytes).toDouble() * UPSCALE_HEAP_SAFETY / UPSCALE_HEAP_BYTES_PER_PIXEL
        val side = sqrt(pixels * long / short).toInt()
        return max(long, min(UPSCALE_MAX_SIDE, side))
    }

    /**
     * Hệ số phóng THỰC TẾ: không vượt [want], và không làm cạnh dài vượt [maxSide]; ≤ 1,01 coi như không phóng (trả 1).
     * Ví dụ ảnh 1536 px cạnh dài xin ×4 chỉ được ×2,67 (4096 / 1536).
     */
    fun upscaleFactor(w: Int, h: Int, want: Float, maxSide: Int = UPSCALE_MAX_SIDE): Float {
        val long = max(w, h)
        if (long <= 0 || maxSide <= 0) return 1f
        var f = want
        if (long * f > maxSide) f = maxSide.toFloat() / long
        return if (f <= 1.01f) 1f else f
    }

    fun process(
        src: Bitmap,
        ops: List<EditOp>,
        segmenter: Segmenter?,
        preview: Boolean,
        notes: MutableList<String>
    ): Bitmap {
        val active = ops.filter { it.arg != "reduce" && (!it.type.scalable || abs(it.value) > 0.005f) }
        if (active.isEmpty()) return src
        val opMap = active.associateBy { it.type }
        var bmp = src
        fun fx(f: (IntArray) -> IntArray) { bmp = makeBitmap(f(bmp.pixelArray()), bmp.width, bmp.height) }

        // 1. Hình học
        opMap[OpType.STRAIGHTEN]?.let { bmp = straighten(bmp, it.value) }
        opMap[OpType.PERSPECTIVE]?.let { bmp = perspective(bmp, it.arg) }
        opMap[OpType.CROP_RATIO]?.let { bmp = cropRatio(bmp, it.value, it.arg) }
        val rot = opMap[OpType.ROTATE]?.value ?: 0f
        val flipH = OpType.FLIP_H in opMap
        val flipV = OpType.FLIP_V in opMap
        if (rot != 0f || flipH || flipV) bmp = transform(bmp, rot, flipH, flipV)
        if (!preview) opMap[OpType.UPSCALE]?.let { bmp = upscale(bmp, it.value) }
        opMap[OpType.LIQUIFY]?.let { bmp = ToneOps.liquify(bmp, it.arg) }
        opMap[OpType.MESH_WARP]?.let { bmp = MeshWarp.apply(bmp, it.arg) }
        // xóa bụi/xước/sợi mảnh sớm: trước làm nét / rõ nét / kết cấu để các phép đó không khuếch đại vết bẩn
        opMap[OpType.DUST]?.let { op ->
            val (cw, ch) = bmp.width to bmp.height
            val src = bmp.pixelArray()
            val cleaned = Despeckle.apply(src, cw, ch, op.value)
            if (cleaned !== src) bmp = makeBitmap(cleaned, cw, ch)
        }
        // R25: khử moiré rồi mới làm nét lại (làm nét trước sẽ khuếch đại vân); cả hai nặng nên thường chỉ chạy một lần qua đường "bake"
        opMap[OpType.MOIRE]?.let { op ->
            val (cw, ch) = bmp.width to bmp.height
            val src = bmp.pixelArray()
            val rep = Moire.applyReport(src, cw, ch, op.value)
            if (rep.out === src) notes.add("Không thấy vân moiré rõ ràng nên giữ nguyên ảnh.")
            else {
                bmp = makeBitmap(rep.out, cw, ch)
                notes.add("Khử moiré: bắt ${rep.total} đỉnh tần số (độ chói ${rep.peaksY}, màu ${rep.peaksCb + rep.peaksCr}).")
            }
        }
        opMap[OpType.UNBLUR]?.let { op ->
            val (cw, ch) = bmp.width to bmp.height
            val src = bmp.pixelArray()
            val out = Deblur.apply(src, cw, ch, op.value, op.arg)
            if (out === src) notes.add("Không thấy ảnh bị nhòe/rung rõ ràng (hoặc không ước lượng được độ nhòe) nên chưa làm nét lại.")
            else bmp = makeBitmap(out, cw, ch)
        }
        if (opMap[OpType.SKY_RELIGHT] != null && opMap[OpType.SKY_REPLACE] == null) {
            notes.add("\"Khớp ánh sáng tiền cảnh\" chỉ có tác dụng khi dùng cùng \"Thay bầu trời\".")
        }
        // thay trời trước phần tông màu để các phép chỉnh sau (ấm, tương phản...) áp dụng đồng đều lên cả trời mới
        opMap[OpType.SKY_REPLACE]?.let { op ->
            val (cw, ch) = bmp.width to bmp.height
            val src = bmp.pixelArray()
            val relight = opMap[OpType.SKY_RELIGHT]?.value ?: 0f
            val ownName = SkyStore.nameFromArg(op.arg)
            var missing = false
            val replaced = if (ownName != null) {
                val sky = SkyStore.load(ownName)
                if (sky == null) {
                    missing = true
                    notes.add("Không tìm thấy ảnh trời \"$ownName\" trên máy này (cần nhập lại ảnh trời).")
                    src
                } else SkyFx.replaceWithImage(src, cw, ch, sky.first, sky.second, sky.third, op.value, relight)
            } else SkyFx.replace(src, cw, ch, op.arg ?: "blue", op.value, relight)
            if (replaced === src) { if (!missing) notes.add("Không thấy bầu trời nối với mép trên ảnh nên chưa thay được.") }
            else bmp = makeBitmap(replaced, cw, ch)
        }

        // 2. Tông màu
        opMap[OpType.AUTO_ENHANCE]?.let { bmp = autoEnhance(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.DEHAZE]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { ProTone.dehaze(it, cw, ch, op.value) } }
        opMap[OpType.SHADOWS]?.let { bmp = shadows(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.HIGHLIGHTS]?.let { op -> fx { ProTone.highlights(it, op.value) } }
        opMap[OpType.COLOR_MATCH]?.let { bmp = ToneOps.colorMatch(bmp, it.arg) }
        opMap[OpType.LEVELS]?.let { bmp = ToneOps.levels(bmp, it.arg) }
        opMap[OpType.CURVES]?.let { bmp = ToneOps.curves(bmp, it.arg) }
        bmp = colorPass(bmp, opMap)
        opMap[OpType.HSL]?.let { bmp = ToneOps.hsl(bmp, it.arg) }
        opMap[OpType.HUE]?.let { op ->
            bmp = makeBitmap(ColorFx.hueShift(bmp.pixelArray(), op.value.coerceIn(-1f, 1f) * 180f), bmp.width, bmp.height)
        }
        opMap[OpType.VIBRANCE]?.let { op -> fx { ProTone.vibrance(it, op.value) } }
        opMap[OpType.TINT]?.let { op -> fx { ProTone.tint(it, op.value) } }
        opMap[OpType.COLORIZE]?.let { op -> fx { FilterFx.colorize(it, FilterFx.hexRgb(op.arg, 0x808080), op.value) } }
        opMap[OpType.DUOTONE]?.let { op -> fx { FilterFx.duotone(it, op.value, op.arg) } }
        opMap[OpType.SELECTIVE_COLOR]?.let { op ->
            val out = SelectiveColor.apply(bmp.pixelArray(), op.arg)
            if (out != null) bmp = makeBitmap(out, bmp.width, bmp.height)
        }
        opMap[OpType.COLOR_BALANCE]?.let { bmp = ToneOps.colorBalance(bmp, it.arg) }
        opMap[OpType.SPLIT_TONE]?.let { op ->
            SplitTone.parse(op.arg)?.let { p -> val (cw, ch) = bmp.width to bmp.height; fx { SplitTone.apply(it, cw, ch, p) } }
        }
        opMap[OpType.LUT]?.let { op ->
            val lut = LutStore.get(op.arg)
            if (lut == null) notes.add("Không tìm thấy LUT \"${op.arg.orEmpty()}\" trên máy này (cần nhập lại tệp .cube).")
            else fx { CubeLut.apply(it, lut, op.value) }
        }
        opMap[OpType.CINEMATIC]?.let { bmp = cinematic(bmp, it.value.coerceIn(0f, 1f)) }

        // 3. Chi tiết
        opMap[OpType.DENOISE]?.let { bmp = ToneOps.denoise(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.FREQ_SEP]?.let { bmp = ToneOps.freqSep(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.SKIN_SMOOTH]?.let { bmp = skinSmooth(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.BLUR]?.let { bmp = globalBlur(bmp, it.value.coerceIn(0f, 1.5f)) }
        opMap[OpType.MOTION_BLUR]?.let { bmp = ToneOps.motionBlur(bmp, it.value.coerceIn(0f, 1f), it.arg?.toFloatOrNull() ?: 0f) }
        opMap[OpType.RADIAL_BLUR]?.let { bmp = ToneOps.radialBlur(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.SHARPEN]?.let { bmp = sharpen(bmp, it.value.coerceIn(0f, 1.5f)) }
        opMap[OpType.CLARITY]?.let { bmp = ToneOps.clarity(bmp, it.value.coerceIn(-1f, 1f)) }
        opMap[OpType.TEXTURE]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { ProTone.texture(it, cw, ch, op.value) } }

        // 4. Hiệu ứng + phông
        opMap[OpType.STYLE]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { Stylize.apply(it, cw, ch, op.value, op.arg) } }
        opMap[OpType.POSTERIZE]?.let { op -> fx { FilterFx.posterize(it, op.value) } }
        opMap[OpType.PIXELATE]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { FilterFx.pixelate(it, cw, ch, op.value) } }
        opMap[OpType.EMBOSS]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { FilterFx.emboss(it, cw, ch, op.value) } }
        opMap[OpType.SKETCH]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { FilterFx.sketch(it, cw, ch, op.value) } }
        opMap[OpType.GLOW]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { FilterFx.glow(it, cw, ch, op.value) } }
        opMap[OpType.CHROMA]?.let { op -> val (cw, ch) = bmp.width to bmp.height; fx { FilterFx.chroma(it, cw, ch, op.value) } }
        opMap[OpType.MATTE]?.let { op -> fx { FilterFx.matte(it, op.value) } }
        opMap[OpType.VIGNETTE]?.let { bmp = vignette(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.GRAIN]?.let { bmp = ToneOps.grain(bmp, it.value.coerceIn(0f, 1f)) }
        opMap[OpType.LENS_FLARE]?.let { op ->
            val xy = op.arg?.split(',')?.mapNotNull { v -> v.trim().toFloatOrNull() }
            bmp = makeBitmap(
                ColorFx.lensFlare(bmp.pixelArray(), bmp.width, bmp.height, op.value, xy?.getOrNull(0) ?: 0.78f, xy?.getOrNull(1) ?: 0.2f),
                bmp.width, bmp.height
            )
        }
        opMap[OpType.BG_BLUR]?.let { bmp = backgroundBlur(bmp, it.value.coerceIn(0f, 1f), segmenter, notes) }
        opMap[OpType.BG_REMOVE]?.let { bmp = removeBackground(bmp, it.arg, segmenter, notes) }
        return bmp
    }

    // ------------------------------------------------------------------ tiện ích pixel
    private fun red(p: Int) = (p shr 16) and 255
    private fun green(p: Int) = (p shr 8) and 255
    private fun blue(p: Int) = p and 255
    private fun pack(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    private fun lum(p: Int): Float = 0.299f * red(p) + 0.587f * green(p) + 0.114f * blue(p)
    private fun cl(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()

    private fun Bitmap.pixelArray(): IntArray {
        val a = IntArray(width * height)
        getPixels(a, 0, width, 0, 0, width, height)
        return a
    }

    private fun IntArray.toBitmap(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.setPixels(this, 0, w, 0, 0, w, h)
        return b
    }

    private fun mixPx(bg: Int, fg: Int, m: Float): Int {
        val inv = 1f - m
        return pack(
            255,
            cl(red(bg) * inv + red(fg) * m),
            cl(green(bg) * inv + green(fg) * m),
            cl(blue(bg) * inv + blue(fg) * m)
        )
    }

    private fun smoothstep(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    // ------------------------------------------------------------------ hình học
    /** Cắt theo tỉ lệ; [arg] = "cx,cy,scale" của Auto Frame (không có = cắt giữa như cũ). */
    private fun cropRatio(b: Bitmap, ratio: Float, arg: String? = null): Bitmap {
        val w = b.width
        val h = b.height
        val t = AutoFrame.parseArg(arg)
        val r = if (t == null) AutoFrame.cropRect(w, h, ratio) else AutoFrame.cropRect(w, h, ratio, t.first, t.second, t.third)
        if (r[2] == w && r[3] == h) return b
        return Bitmap.createBitmap(b, r[0], r[1], r[2], r[3])
    }

    private fun transform(b: Bitmap, rotate: Float, flipH: Boolean, flipV: Boolean): Bitmap {
        val m = Matrix()
        if (flipH) m.postScale(-1f, 1f, b.width / 2f, b.height / 2f)
        if (flipV) m.postScale(1f, -1f, b.width / 2f, b.height / 2f)
        if (rotate != 0f) m.postRotate(rotate)
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    /** Phóng to nội suy + làm nét bù. Để phóng to bằng AI thật, thay bằng model ONNX super-resolution. */
    private fun upscale(b: Bitmap, factor: Float): Bitmap {
        val f = upscaleFactor(b.width, b.height, factor, upscaleMaxSide(b.width, b.height, heapHeadroom()))
        if (f <= 1f) return b
        val scaled = Bitmap.createScaledBitmap(b, (b.width * f).roundToInt(), (b.height * f).roundToInt(), true)
        return sharpen(scaled, 0.4f)
    }

    /**
     * Chỉnh thẳng ảnh: xoay [deg] độ quanh tâm rồi cắt hình chữ nhật lớn nhất CÙNG TỈ LỆ nằm gọn trong ảnh đã xoay
     * (không để lại góc trống, không đổi tỉ lệ khung).
     *
     * Hình chữ nhật cùng tâm cỡ (s·w, s·h) nằm gọn trong ảnh w×h xoay góc a khi và chỉ khi bốn đỉnh của nó, xoay ngược −a,
     * còn nằm trong ảnh gốc: s·(w·|cos a| + h·|sin a|) ≤ w và s·(w·|sin a| + h·|cos a|) ≤ h. Lấy s lớn nhất thỏa cả hai.
     * (Công thức "hình chữ nhật xoay có DIỆN TÍCH lớn nhất" thường gặp KHÔNG giữ tỉ lệ - từng dùng ở đây và làm khung ảnh bị đổi tỉ lệ.)
     */
    fun largestRotatedRect(w: Int, h: Int, rad: Double): Pair<Int, Int> {
        val sa = abs(sin(rad))
        val ca = abs(cos(rad))
        val s = minOf(w / (w * ca + h * sa), h / (w * sa + h * ca)).coerceAtMost(1.0)
        return Pair((w * s).toInt().coerceIn(1, w), (h * s).toInt().coerceIn(1, h))
    }

    /** Phối cảnh: hình thang nguồn (trong ảnh) -> chữ nhật đầy khung, bằng phép biến đổi phối cảnh 4 điểm. */
    private fun perspective(b: Bitmap, arg: String?): Bitmap {
        val kv = Keystone.parse(arg) ?: return b
        val w = b.width
        val h = b.height
        val src = Keystone.sourceQuad(w, h, kv.first, kv.second)
        val dst = floatArrayOf(0f, 0f, w.toFloat(), 0f, w.toFloat(), h.toFloat(), 0f, h.toFloat())
        val m = Matrix()
        if (!m.setPolyToPoly(src, 0, dst, 0, 4)) return b
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        Canvas(out).drawBitmap(b, m, paint)
        return out
    }

    private fun straighten(b: Bitmap, deg: Float): Bitmap {
        if (abs(deg) < 0.05f) return b
        val (cw, ch) = largestRotatedRect(b.width, b.height, Math.toRadians(deg.toDouble()))
        val out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.postTranslate(-b.width / 2f, -b.height / 2f)
        m.postRotate(deg)
        m.postTranslate(cw / 2f, ch / 2f)
        Canvas(out).drawBitmap(b, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ------------------------------------------------------------------ tông màu
    private fun colorPass(b: Bitmap, ops: Map<OpType, EditOp>): Bitmap {
        val cm = ColorMatrix()
        var used = false
        fun add(m: ColorMatrix) { cm.postConcat(m); used = true }

        ops[OpType.WARMTH]?.let { op ->
            val w = op.value.coerceIn(-1f, 1f)
            add(ColorMatrix(floatArrayOf(
                1f + 0.14f * w, 0f, 0f, 0f, 10f * w,
                0f, 1f + 0.02f * w, 0f, 0f, 0f,
                0f, 0f, 1f - 0.14f * w, 0f, -10f * w,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        ops[OpType.SATURATION]?.let { op ->
            val s = (1f + op.value.coerceIn(-1f, 1f)).coerceAtLeast(0f)
            add(ColorMatrix().apply { setSaturation(s) })
        }
        if (OpType.GRAYSCALE in ops) add(ColorMatrix().apply { setSaturation(0f) })
        ops[OpType.SEPIA]?.let { op ->
            val s = op.value.coerceIn(0f, 1f)
            val sep = floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            val id = floatArrayOf(
                1f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            add(ColorMatrix(FloatArray(20) { i -> id[i] * (1f - s) + sep[i] * s }))
        }
        ops[OpType.CONTRAST]?.let { op ->
            val c = 1f + op.value.coerceIn(-1f, 1f)
            val t = 128f * (1f - c)
            add(ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        ops[OpType.BRIGHTNESS]?.let { op ->
            val o = op.value.coerceIn(-1f, 1f) * 80f
            add(ColorMatrix(floatArrayOf(
                1f, 0f, 0f, 0f, o,
                0f, 1f, 0f, 0f, o,
                0f, 0f, 1f, 0f, o,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        if (!used) return b

        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(b, 0f, 0f, paint)
        return out
    }

    /** Kéo giãn histogram (cắt 0.5% hai đầu) + chỉnh gamma đưa độ sáng trung bình về ~46%. */
    private fun autoEnhance(b: Bitmap, strength: Float): Bitmap {
        val w = b.width
        val h = b.height
        val px = b.pixelArray()
        val hist = IntArray(256)
        var n = 0
        val step = max(1, px.size / 200_000)
        var i = 0
        while (i < px.size) {
            hist[lum(px[i]).roundToInt().coerceIn(0, 255)]++
            n++
            i += step
        }
        fun percentile(p: Float): Int {
            var acc = 0
            val target = (n * p).toInt()
            for (v in 0..255) { acc += hist[v]; if (acc >= target) return v }
            return 255
        }
        var lo = percentile(0.005f)
        var hi = percentile(0.995f)
        if (hi - lo < 40) { lo = 0; hi = 255 }
        val scale = 255f / (hi - lo)

        var sum = 0.0
        for (v in 0..255) sum += ((v - lo) * scale).coerceIn(0f, 255f) * hist[v]
        val mean = (sum / max(n, 1)).toFloat() / 255f
        val gamma = if (mean in 0.05f..0.95f) (ln(0.46f) / ln(mean)).coerceIn(0.65f, 1.5f) else 1f

        val lut = IntArray(256) { v ->
            val x = (((v - lo) * scale) / 255f).coerceIn(0f, 1f).pow(gamma)
            val o = (v / 255f) * (1f - strength) + x * strength
            (o * 255f).roundToInt().coerceIn(0, 255)
        }
        val out = IntArray(px.size)
        for (j in px.indices) {
            val p = px[j]
            out[j] = pack(p ushr 24, lut[red(p)], lut[green(p)], lut[blue(p)])
        }
        return out.toBitmap(w, h)
    }

    /** Nâng sáng riêng vùng tối (giữ vùng sáng). */
    private fun shadows(b: Bitmap, strength: Float): Bitmap {
        val w = b.width
        val h = b.height
        val px = b.pixelArray()
        for (i in px.indices) {
            val p = px[i]
            val l = lum(p) / 255f
            val lift = strength * 0.45f * (1f - l) * (1f - l)
            val r = red(p); val g = green(p); val bl = blue(p)
            px[i] = pack(p ushr 24, cl(r + (255 - r) * lift), cl(g + (255 - g) * lift), cl(bl + (255 - bl) * lift))
        }
        return px.toBitmap(w, h)
    }

    /** Teal & orange: vùng tối ngả xanh lục-lam, vùng sáng ngả cam + tăng tương phản nhẹ. */
    private fun cinematic(b: Bitmap, s: Float): Bitmap {
        val w = b.width
        val h = b.height
        val px = b.pixelArray()
        val contrast = 1f + 0.12f * s
        for (i in px.indices) {
            val p = px[i]
            val r = red(p); val g = green(p); val bl = blue(p)
            val l = lum(p) / 255f
            val sh = 1f - l
            var nr = r + s * (l * 22f - sh * 12f)
            var ng = g + s * (sh * 6f - l * 2f)
            var nb = bl + s * (sh * 24f - l * 16f)
            nr = (nr - 128f) * contrast + 128f
            ng = (ng - 128f) * contrast + 128f
            nb = (nb - 128f) * contrast + 128f
            px[i] = pack(p ushr 24, cl(nr), cl(ng), cl(nb))
        }
        return px.toBitmap(w, h)
    }

    // ------------------------------------------------------------------ chi tiết
    /**
     * Làm mịn da: phát hiện vùng da (YCbCr) -> làm mờ có bảo toàn cạnh -> trộn theo mặt nạ mềm.
     * Cạnh mạnh (mắt, môi, tóc) có trọng số thấp nên được giữ nét.
     */
    private fun skinSmooth(b: Bitmap, strength: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = b.pixelArray()
        val long = max(w, h)
        val radius = max(2, (long * 0.006f * (0.6f + strength)).roundToInt())
        val blurred = Blur.gaussian(src, w, h, radius)

        val mask = IntArray(w * h)
        for (i in src.indices) {
            val p = src[i]
            val r = red(p).toFloat(); val g = green(p).toFloat(); val bl = blue(p).toFloat()
            val cb = 128f - 0.168736f * r - 0.331264f * g + 0.5f * bl
            val cr = 128f + 0.5f * r - 0.418688f * g - 0.081312f * bl
            val y = 0.299f * r + 0.587f * g + 0.114f * bl
            val m = if (cb in 77f..127f && cr in 133f..173f && y > 40f) 255 else 0
            mask[i] = pack(255, m, m, m)
        }
        val soft = Blur.gaussian(mask, w, h, max(2, long / 250))

        val out = IntArray(w * h)
        val t = 20f
        for (i in src.indices) {
            val p = src[i]
            val q = blurred[i]
            val d = abs(lum(p) - lum(q))
            val edge = 1f / (1f + (d / t) * (d / t))
            val m = (soft[i] and 255) / 255f
            val k = (strength * m * (0.35f + 0.65f * edge)).coerceIn(0f, 1f)
            out[i] = pack(
                p ushr 24,
                cl(red(p) + (red(q) - red(p)) * k),
                cl(green(p) + (green(q) - green(p)) * k),
                cl(blue(p) + (blue(q) - blue(p)) * k)
            )
        }
        return out.toBitmap(w, h)
    }

    private fun globalBlur(b: Bitmap, s: Float): Bitmap {
        val w = b.width
        val h = b.height
        val r = max(1, (max(w, h) * 0.02f * s).roundToInt())
        return Blur.gaussian(b.pixelArray(), w, h, r).toBitmap(w, h)
    }

    /** Unsharp mask. */
    private fun sharpen(b: Bitmap, s: Float): Bitmap {
        val w = b.width
        val h = b.height
        val src = b.pixelArray()
        val r = max(1, (max(w, h) / 700f).roundToInt())
        val bl = Blur.gaussian(src, w, h, r)
        val amount = 1.6f * s
        val out = IntArray(src.size)
        for (i in src.indices) {
            val p = src[i]
            val q = bl[i]
            out[i] = pack(
                p ushr 24,
                cl(red(p) + amount * (red(p) - red(q))),
                cl(green(p) + amount * (green(p) - green(q))),
                cl(blue(p) + amount * (blue(p) - blue(q)))
            )
        }
        return out.toBitmap(w, h)
    }

    private fun vignette(b: Bitmap, s: Float): Bitmap {
        val w = b.width
        val h = b.height
        val px = b.pixelArray()
        val cx = w / 2f
        val cy = h / 2f
        val maxD = sqrt(cx * cx + cy * cy)
        for (y in 0 until h) {
            val dy = y - cy
            for (x in 0 until w) {
                val dx = x - cx
                val d = sqrt(dx * dx + dy * dy) / maxD
                val f = 1f - s * 0.75f * smoothstep(0.35f, 1f, d)
                val i = y * w + x
                val p = px[i]
                px[i] = pack(p ushr 24, cl(red(p) * f), cl(green(p) * f), cl(blue(p) * f))
            }
        }
        return px.toBitmap(w, h)
    }

    // ------------------------------------------------------------------ phông / nền
    private fun maskFor(b: Bitmap, seg: Segmenter?, notes: MutableList<String>): FloatArray? {
        if (seg == null) return null
        return try {
            val m = seg.foregroundMask(b)
            for (i in m.indices) m[i] = smoothstep(0.1f, 0.9f, m[i])
            m
        } catch (e: Throwable) {
            notes.add("Model tách nền lỗi: ${e.message ?: e.javaClass.simpleName}")
            null
        }
    }

    private fun ellipseMask(w: Int, h: Int): FloatArray {
        val m = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x - w / 2f) / (w * 0.38f)
            val ny = (y - h / 2f) / (h * 0.46f)
            m[y * w + x] = 1f - smoothstep(0.7f, 1.15f, sqrt(nx * nx + ny * ny))
        }
        return m
    }

    private fun backgroundBlur(b: Bitmap, strength: Float, seg: Segmenter?, notes: MutableList<String>): Bitmap {
        val w = b.width
        val h = b.height
        val mask = maskFor(b, seg, notes) ?: ellipseMask(w, h).also {
            notes.add("Chưa có model tách nền (.onnx): đang dùng mặt nạ hình elip ở giữa ảnh.")
        }
        val src = b.pixelArray()
        val r = max(2, (max(w, h) * 0.02f * (0.4f + strength)).roundToInt())
        val blurred = Blur.gaussian(src, w, h, r)
        val out = IntArray(w * h)
        for (i in src.indices) out[i] = mixPx(blurred[i], src[i], mask[i])
        return out.toBitmap(w, h)
    }

    private fun removeBackground(b: Bitmap, arg: String?, seg: Segmenter?, notes: MutableList<String>): Bitmap {
        val mask = maskFor(b, seg, notes)
        if (mask == null) {
            if (seg == null) notes.add("Cần nạp model tách nền (.onnx) để tách/xóa nền - đã bỏ qua bước này.")
            return b
        }
        val w = b.width
        val h = b.height
        // khử màu viền: điểm ảnh bán trong suốt lấy màu của chủ thể thay vì màu nền cũ (Refine Edge → decontaminate)
        val src = EdgeOps.decontaminate(b.pixelArray(), mask, w, h, max(3, max(w, h) / 180))
        val bg: Int? =
            if (arg == null || arg == "transparent") null
            else runCatching { Color.parseColor(arg) }.getOrNull()
        val out = IntArray(w * h)
        for (i in src.indices) {
            val p = src[i]
            out[i] = if (bg == null) {
                ((mask[i] * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (p and 0xFFFFFF)
            } else {
                mixPx(bg, p, mask[i])
            }
        }
        return out.toBitmap(w, h)
    }
}
