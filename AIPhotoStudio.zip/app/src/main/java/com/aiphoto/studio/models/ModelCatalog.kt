package com.aiphoto.studio.models

import org.json.JSONObject

/**
 * R43: danh mục model cho trình tải trong app. Dữ liệu là JSON — một bản CÓ SẴN trong app (assets/model_catalog.json, chỉ các mục đã kiểm chứng SHA-256)
 * và bản mới nhất ở địa chỉ catalogUrl (GitHub Release của kho, do workflow Mirror models sinh ra). Phần này thuần Kotlin để kiểm bằng JUnit.
 */
class ModelEntry(
    val id: String,
    val slot: String,
    val name: String,
    val file: String,
    val sizeBytes: Long,
    val sha256: String,
    val urls: List<String>,
    val license: String,
    val licenseUrl: String,
    val descVi: String,
    val descEn: String,
    val riskVi: String,
    val riskEn: String,
    val recommended: Boolean
) {
    /** Dung lượng làm tròn theo MB (tối thiểu 1). */
    val sizeMb: Int get() = ((sizeBytes + (1L shl 19)) shr 20).toInt().coerceAtLeast(1)

    /** Mô tả theo ngôn ngữ giao diện: tiếng Việt cho "vi", các ngôn ngữ khác dùng bản tiếng Anh (nếu thiếu thì lùi về tiếng Việt). */
    fun desc(lang: String): String = if (lang == "vi" || descEn.isBlank()) descVi else descEn
    fun risk(lang: String): String = if (lang == "vi" || riskEn.isBlank()) riskVi else riskEn
}

class ModelCatalog(val catalogUrl: String, val releaseBase: String, val models: List<ModelEntry>, val source: String)

/** Các "ô" model mà app biết nạp; mục danh mục có slot khác bị ẩn (bản app cũ gặp danh mục mới). */
object ModelSlots {
    val ALL: Set<String> = setOf(
        "seg", "seg_hq", "portrait", "lama", "migan", "esrgan", "sam_encoder", "sam_decoder", "face", "hair", "person", "depth"
    )
}

object ModelCatalogs {
    /** CI thay chuỗi này bằng "chủ/kho" thật khi dựng APK; còn nguyên nghĩa là chưa cấu hình ⇒ không có địa chỉ máy chủ. */
    const val REPO_PLACEHOLDER = "__REPO__"
    private val SHA = Regex("[0-9a-f]{64}")
    private val ID = Regex("[a-z0-9_]{1,40}")

    class Invalid(message: String) : IllegalArgumentException(message)

    fun parse(json: String, source: String): ModelCatalog {
        val root = try { JSONObject(json) } catch (e: Exception) { throw Invalid("không phải JSON hợp lệ") }
        if (root.optInt("version", 0) < 1) throw Invalid("thiếu version")
        val arr = root.optJSONArray("models") ?: throw Invalid("thiếu danh sách models")
        val out = ArrayList<ModelEntry>()
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: throw Invalid("mục $i không phải đối tượng")
            val id = o.optString("id", "")
            if (!ID.matches(id)) throw Invalid("id không hợp lệ ở mục $i")
            if (!seen.add(id)) throw Invalid("trùng id: $id")
            val sha = o.optString("sha256", "").lowercase()
            if (!SHA.matches(sha)) throw Invalid("SHA-256 không hợp lệ ở $id")
            val size = o.optLong("sizeBytes", 0L)
            if (size <= 0L) throw Invalid("sizeBytes không hợp lệ ở $id")
            val ua = o.optJSONArray("urls") ?: throw Invalid("thiếu urls ở $id")
            val urls = ArrayList<String>()
            for (k in 0 until ua.length()) { val u = ua.optString(k, ""); if (u.isNotBlank()) urls.add(u) }
            if (urls.isEmpty()) throw Invalid("urls rỗng ở $id")
            out.add(
                ModelEntry(
                    id, o.optString("slot", ""), o.optString("name", id), o.optString("file", id), size, sha, urls,
                    o.optString("license", ""), o.optString("licenseUrl", ""),
                    o.optString("vi", ""), o.optString("en", ""), o.optString("riskVi", ""), o.optString("riskEn", ""),
                    o.optBoolean("recommended", false)
                )
            )
        }
        if (out.isEmpty()) throw Invalid("danh mục rỗng")
        return ModelCatalog(root.optString("catalogUrl", ""), root.optString("releaseBase", ""), out, source)
    }

    /**
     * Địa chỉ dùng được của một mục: thay {release} bằng releaseBase; bỏ địa chỉ còn chứa __REPO__ (chưa cấu hình);
     * chỉ giữ https (http chỉ khi [allowHttp] — dành cho test với máy chủ cục bộ).
     */
    fun resolveUrls(e: ModelEntry, releaseBase: String, allowHttp: Boolean = false): List<String> {
        val out = ArrayList<String>()
        for (u in e.urls) {
            val r = if (u.startsWith("{release}")) {
                if (releaseBase.isBlank()) continue
                releaseBase.trimEnd('/') + u.removePrefix("{release}")
            } else u
            if (r.contains(REPO_PLACEHOLDER)) continue
            if (r.startsWith("https://") || (allowHttp && r.startsWith("http://"))) out.add(r)
        }
        return out
    }

    /** Địa chỉ tải danh mục mới nhất, hoặc null nếu chưa cấu hình. */
    fun remoteUrl(c: ModelCatalog, allowHttp: Boolean = false): String? {
        val u = c.catalogUrl
        if (u.isBlank() || u.contains(REPO_PLACEHOLDER)) return null
        return if (u.startsWith("https://") || (allowHttp && u.startsWith("http://"))) u else null
    }
}
