package com.aiphoto.studio.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Ước lượng góc QUAY NGANG (yaw) của đầu từ điểm mốc MediaPipe CÓ chiều sâu, và cổng giảm hiệu ứng Liquify khi mặt quay nghiêng (R17).
 *
 * Vì sao chỉ là CỔNG AN TOÀN chứ không chỉnh hệ số theo góc: [FaceLiquify] đã đo mọi độ dời theo bề rộng mặt trong ảnh nên đã co
 * theo phối cảnh ở bậc một; còn khi mặt quay mạnh, đường viền hàm bên xa bị che/nén và đẩy đối xứng sẽ làm méo. Chưa có ảnh thật để hiệu
 * chỉnh nên KHÔNG bịa hệ số từng bên — chỉ giảm mượt về 0 khi mặt gần nghiêng hẳn.
 *
 * Mảng điểm mốc: [x0,y0, x1,y1, …] (2N, chuẩn hóa 0..1) rồi, nếu có chiều sâu, thêm khối [z0 … zN-1] (N = 478). MediaPipe: z có cùng thước với x
 * (chuẩn hóa theo CHIỀU RỘNG ảnh), càng nhỏ càng gần camera - chỉ cần độ lớn nên không phụ thuộc dấu. Mọi chỗ cũ chỉ so `size >= 2*468`
 * nên khối z thêm vào cuối không ảnh hưởng.
 *
 * yaw = góc giữa trục ngang gò má-gò má (234 → 454) và mặt phẳng ảnh = atan2(|Δz|, độ dài trong mặt phẳng ảnh). Xoay trong mặt phẳng (roll)
 * không đổi kết quả; pitch lớn làm lệch (đã đo ở tools/verify_ports/head_pose.py, ghi ở A98). Bản port kiểm số học.
 */
object HeadPose {
    const val POINTS = 478
    const val CHEEK_R = 234
    const val CHEEK_L = 454

    /** Dưới ngưỡng này (độ) Liquify giữ nguyên 100%. */
    const val YAW_FULL_DEG = 20f

    /** Từ ngưỡng này (độ) trở lên Liquify tắt hẳn (gần như mặt nghiêng). */
    const val YAW_ZERO_DEG = 55f

    /** Mặt nhỏ hơn mức này (px giữa hai gò má) thì không ước lượng. */
    const val MIN_FACE_PX = 8f

    fun hasDepth(lm: FloatArray): Boolean = lm.size >= 3 * POINTS

    /** Góc quay ngang tuyệt đối (độ, 0 = nhìn thẳng); null nếu không có chiều sâu / mặt quá nhỏ / dữ liệu suy biến. */
    fun yawAbsDeg(lm: FloatArray, w: Int, h: Int): Float? {
        if (w <= 0 || h <= 0 || !hasDepth(lm)) return null
        val dx = (lm[2 * CHEEK_L] - lm[2 * CHEEK_R]) * w
        val dy = (lm[2 * CHEEK_L + 1] - lm[2 * CHEEK_R + 1]) * h
        val inPlane = hypot(dx, dy)
        if (inPlane < MIN_FACE_PX) return null
        val dz = (lm[2 * POINTS + CHEEK_L] - lm[2 * POINTS + CHEEK_R]) * w
        val deg = (atan2(abs(dz), inPlane) * 180.0 / PI).toFloat()
        return if (deg.isNaN()) null else deg
    }

    private fun smooth(t: Float): Float {
        val c = if (t < 0f) 0f else if (t > 1f) 1f else t
        return c * c * (3f - 2f * c)
    }

    /** Hệ số 0..1 nhân vào mọi tham số Liquify: 1 khi mặt gần thẳng, giảm mượt về 0 khi yaw tiến tới [YAW_ZERO_DEG]. Không biết góc -> 1. */
    fun liquifyGain(yawAbsDeg: Float?): Float {
        if (yawAbsDeg == null) return 1f
        return 1f - smooth((yawAbsDeg - YAW_FULL_DEG) / (YAW_ZERO_DEG - YAW_FULL_DEG))
    }
}
