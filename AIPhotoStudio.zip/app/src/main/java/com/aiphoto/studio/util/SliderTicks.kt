package com.aiphoto.studio.util

/**
 * Vạch rung cho thanh trượt (R35). PDF DeepSeek (UI/UX): "phản hồi xúc giác — rung nhẹ khi chạm và kéo, giúp người dùng cảm nhận được thao tác mà không cần nhìn";
 * trước R35 thanh trượt chỉ rung MỘT lần khi thả tay. Nay mỗi lần ngón tay kéo qua một vạch chia thang thành [DIVISIONS] phần bằng nhau thì rung nhẹ một nhịp
 * (tối đa [DIVISIONS] nhịp trên cả thang nên không "rung liên tục" làm khó chịu hay tốn pin).
 */
object SliderTicks {
    const val DIVISIONS = 10

    /** Vị trí vạch (0..[DIVISIONS]) của [v] trên thang [start]..[end]; ngoài thang bị kẹp, thang suy biến (end <= start) ⇒ 0. */
    fun notch(v: Float, start: Float, end: Float): Int {
        val span = end - start
        if (!(span > 0f)) return 0
        val t = ((v - start) / span).coerceIn(0f, 1f)
        return (t * DIVISIONS).toInt()
    }

    /** Có đi qua ít nhất một vạch khi chuyển từ [old] sang [new] không. */
    fun crossed(old: Float, new: Float, start: Float, end: Float): Boolean = notch(old, start, end) != notch(new, start, end)
}
