package com.aiphoto.studio.ai

import java.text.Normalizer
import java.util.Locale

/**
 * "Giữ nguyên X" (bảo vệ vùng): tách cụm như "giữ nguyên khuôn mặt", "trừ bầu trời", "except the hair", "keep the sky unchanged" khỏi lệnh chỉnh
 * rồi trả về (a) phần lệnh còn lại để planner hiểu và (b) danh sách vùng [Scope] cần được GIỮ NGUYÊN. Nơi gọi áp phần chỉnh toàn cục lên mặt nạ ĐẢO
 * của các vùng đó (xem [Scope.protect]); không dựng được mặt nạ thì phải từ chối chứ không chỉnh cả ảnh (người dùng đã dặn rõ).
 *
 * Quy tắc nhận biết (chỉ thuần văn bản, VI không dấu / có dấu và EN):
 *  - Cụm kích hoạt: "giữ nguyên", "giữ lại", "giữ", "không đổi/chỉnh/sửa/động vào", "đừng …", "trừ", "ngoại trừ", "except", "but not", "without changing",
 *    "don't touch", "protect", "preserve"; riêng "keep" chỉ tính khi kèm "unchanged / untouched / intact / as is" (vì "keep the sky blue" là lệnh màu).
 *  - Sau cụm kích hoạt là một danh sách vùng nối bằng "và / and / hay / dấu phẩy" (xen các từ đệm như "màu", "của", "the"); chỉ tính khi có ÍT NHẤT
 *    một vùng nhận ra được: khuôn mặt / da → [Scope.SKIN]; mắt → EYES; răng → TEETH; tóc → HAIR; bầu trời → SKY; nền / phông → BACKGROUND;
 *    chủ thể / người / nhân vật → SUBJECT. Cụm không có vùng nào nhận ra (vd. "giữ nguyên logo") KHÔNG bị cắt — lệnh đi nguyên vẹn như cũ.
 *  - Tiếng Việt có dấu được phân biệt: "mặt" (khuôn mặt) ≠ "mắt" (mắt), "nền" (nền) ≠ "nên" (nên), "răng" ≠ "rằng", "da" ≠ "đã". Câu gõ KHÔNG dấu
 *    (toàn ASCII) thì các từ mơ hồ được hiểu theo nghĩa vùng khi đứng sau cụm kích hoạt ("giu nguyen mat" = khuôn mặt).
 * Giới hạn: không hiểu vật cụ thể ngoài danh sách (logo, cái xe, chữ…); "khuôn mặt" chỉ bảo vệ vùng DA mặt (không gồm tóc / mắt / răng — nói thêm nếu cần);
 * không phân biệt "giữ nguyên" áp cho phần nào của vế sau khi câu có nhiều vế ("sáng nền, giữ nguyên mặt, làm ấm" vẫn đúng vì chỉ cắt đến hết danh sách vùng).
 */
object ProtectIntent {

    /** [rest] = lệnh đã bỏ cụm bảo vệ (đúng nguyên chuỗi gốc nếu không có gì bị cắt); [protect] = các [Scope] cần giữ nguyên, không trùng, theo thứ tự xuất hiện. */
    class Result(val rest: String, val protect: List<String>) {
        val any: Boolean get() = protect.isNotEmpty()
    }

    private class Tok(val start: Int, val end: Int, val canon: String, val hard: Boolean, val soft: Boolean)

    // khóa là các token chuẩn hóa (bỏ dấu, chữ thường) nối bằng dấu cách; "mat_face"/"mat_eyes" tách "mặt"/"mắt" có dấu
    private val OBJECT_KEYS: Map<String, String> = LinkedHashMap<String, String>().apply {
        for (k in listOf("khuon mat_face", "guong mat_face", "da mat_face", "khuon mat_amb", "guong mat_amb", "da mat_amb", "mat_face", "mau da", "da", "skin", "face", "faces")) put(k, Scope.SKIN)
        for (k in listOf("doi mat_eyes", "mat_eyes", "eyes", "eye")) put(k, Scope.EYES)
        for (k in listOf("hang rang", "rang", "teeth", "tooth")) put(k, Scope.TEETH)
        for (k in listOf("mai toc", "toc", "hair")) put(k, Scope.HAIR)
        for (k in listOf("bau troi", "troi", "sky")) put(k, Scope.SKY)
        for (k in listOf("phong nen", "hau canh", "nen", "background", "backdrop")) put(k, Scope.BACKGROUND)
        for (k in listOf("chu the", "nhan vat", "nguoi", "subject", "person", "people", "foreground", "tien canh")) put(k, Scope.SUBJECT)
    }

    private val TRIGGERS: Set<String> = setOf(
        "giu nguyen", "giu lai", "giu y", "giu",
        "khong doi", "dung doi", "khong chinh", "dung chinh", "khong dong vao", "dung dong vao", "khong cham vao", "dung cham vao",
        "khong sua", "dung sua", "khong thay doi", "dung thay doi", "khong anh huong", "khong ap dung cho",
        "ngoai tru", "tru ra", "tru",
        "except for", "except", "but not", "excluding", "exclude", "without changing", "without touching", "leave alone",
        "dont touch", "do not touch", "dont change", "do not change", "protect", "preserve", "keep"
    )

    /** Từ đệm được phép xen giữa cụm kích hoạt / các vùng. */
    private val FILLER: Set<String> = setOf(
        "mau", "sac", "cua", "cac", "nhung", "ca", "toan", "bo", "tat", "nay", "do", "the", "a", "an", "its", "original", "as", "is",
        "unchanged", "untouched", "intact", "same", "alone", "phan", "vung", "khu", "vuc", "nguyen", "lai", "y", "anh", "tu", "nhien", "of", "on"
    )
    /** "nhưng" (but) và "những" (plural) cùng gấp thành "nhung": đứng TRƯỚC vùng là từ đệm ("giữ nguyên những vùng da"), đứng SAU vùng là từ nối mở lệnh mới. */
    private const val BUT = "nhung"
    private val CONNECT: Set<String> = setOf("va", "and", "hay", "voi", "cung", "plus", "or")

    /** Từ đứng sau vùng cần cắt theo luôn ("giữ khuôn mặt nguyên", "keep the sky unchanged"). */
    private val TAIL: Set<String> = setOf("unchanged", "untouched", "intact", "alone", "same", "original", "nguyen")
    private val KEEP_WORDS: Set<String> = setOf("unchanged", "untouched", "intact", "alone", "same", "original")

    // từ nối khi dọn phần lệnh còn lại
    private val LEAD_CONNECT: Set<String> = setOf("nhung", "but", "va", "and", "con", "roi", "then", "cung", "voi", "with", "hay", "or")

    private fun canon(core: String, accented: Boolean): String {
        val c = Normalizer.normalize(core, Normalizer.Form.NFC).lowercase(Locale.ROOT)
        when (c) {
            "mắt" -> return "mat_eyes"
            "mặt" -> return "mat_face"
            "nền" -> return "nen"
            "nên" -> return "nen_x"
            "răng" -> return "rang"
            "rằng" -> return "rang_x"
            "tóc" -> return "toc"
        }
        val f = GenIntent.fold(c).replace(" ", "")
        return when (f) {
            "mat" -> if (accented) "mat_amb" else "mat_face"
            "nen" -> if (accented) "nen_x" else "nen"
            "da" -> if (c == "da" || !accented) "da" else "da_x"
            "rang" -> if (accented) "rang_x" else "rang"
            else -> f
        }
    }

    private fun tokenize(text: String, accented: Boolean): List<Tok> {
        val out = ArrayList<Tok>()
        for (m in Regex("\\S+").findAll(text)) {
            val raw = m.value
            val core = raw.trim { !it.isLetterOrDigit() }
            val last = raw.last()
            out.add(Tok(m.range.first, m.range.last + 1, if (core.isEmpty()) "" else canon(core, accented), last == '.' || last == '!' || last == '?', last == ',' || last == ';' || last == ':'))
        }
        return out
    }

    private fun keyAt(toks: List<Tok>, k: Int, n: Int): String? {
        if (k + n > toks.size) return null
        val sb = StringBuilder()
        for (j in 0 until n) {
            val c = toks[k + j].canon
            if (c.isEmpty()) return null
            if (j > 0) sb.append(' ')
            sb.append(c)
        }
        return sb.toString()
    }

    private fun triggerLen(toks: List<Tok>, i: Int): Int {
        for (n in 3 downTo 1) { val key = keyAt(toks, i, n); if (key != null && key in TRIGGERS) return n }
        return 0
    }

    private fun objectAt(toks: List<Tok>, k: Int): Pair<String, Int>? {
        for (n in 3 downTo 1) { val key = keyAt(toks, k, n); if (key != null) OBJECT_KEYS[key]?.let { return Pair(it, n) } }
        return null
    }

    /**
     * Sau một vùng kết thúc bằng dấu phẩy ("giữ nguyên mặt, …"): phần vùng đứng tiếp theo có thuộc danh sách không?
     * Có khi vùng đó kết thúc bằng dấu câu ("…, tóc," / "…, tóc."), khi sau nó hết câu hoặc có "và" ("…, tóc và làm sáng ảnh"); không khi nó đứng trước
     * một từ khác không có dấu ("mặt, nền sáng hơn": "nền" là chủ ngữ của lệnh mới). ("nhưng" sau vùng do [split] dừng lại trước, không cần xét ở đây.)
     */
    private fun listContinues(toks: List<Tok>, from: Int): Boolean {
        var k = from
        while (k < toks.size) {
            val om = objectAt(toks, k)
            if (om != null) {
                k += om.second
                if (toks[k - 1].hard || toks[k - 1].soft) return true
                continue
            }
            val c = toks[k].canon
            if (c in FILLER || c.isEmpty()) {
                k++
                if (toks[k - 1].hard) break                    // từ đệm kết câu ("tóc của ảnh."): vùng sau dấu chấm thuộc câu khác
                continue
            }
            break
        }
        if (k >= toks.size) return true
        if (toks[k - 1].hard) return true
        return toks[k].canon in CONNECT
    }

    fun split(prompt: String): Result {
        if (prompt.isBlank()) return Result(prompt, emptyList())
        val accented = prompt.any { it.code > 127 }
        val toks = tokenize(prompt, accented)
        val cuts = ArrayList<IntRange>()
        val protect = LinkedHashSet<String>()
        var i = 0
        while (i < toks.size) {
            val tl = triggerLen(toks, i)
            if (tl == 0) { i++; continue }
            val isKeep = toks[i].canon == "keep"
            var k = i + tl
            var endIdx = -1                       // token cuối (không gồm) của phần sẽ bị cắt
            val found = ArrayList<String>()
            while (k < toks.size) {
                val om = objectAt(toks, k)
                if (om != null) {
                    found.add(om.first); k += om.second; endIdx = k
                    if (toks[k - 1].hard) break
                    if (toks[k - 1].soft && !listContinues(toks, k)) break
                    continue
                }
                val c = toks[k].canon
                if (c == BUT && found.isNotEmpty()) break      // "giữ nguyên mặt nhưng nền thì sáng": sau vùng, "nhưng" kết thúc cụm
                if (c in CONNECT || c in FILLER || c.isEmpty()) {
                    val t = toks[k]
                    k++
                    if (found.isNotEmpty() && c in TAIL) endIdx = k          // "… unchanged" đứng ngay sau vùng bị cắt theo
                    if (t.hard) {
                        if (found.isNotEmpty()) endIdx = k                   // từ đệm kết câu ("tóc của ảnh.") thuộc cụm bảo vệ
                        break
                    }
                    continue
                }
                break
            }
            if (found.isEmpty()) { i += tl; continue }
            if (isKeep) {
                // "keep the sky blue" là lệnh màu; chỉ "keep X unchanged / as is" mới là bảo vệ
                var ok = false
                for (j in (i + 1) until minOf(toks.size, endIdx + 3)) {
                    if (toks[j].canon in KEEP_WORDS) ok = true
                    if (toks[j].canon == "as" && j + 1 < toks.size && toks[j + 1].canon == "is") ok = true
                }
                if (!ok) { i += tl; continue }
            }
            // "unchanged / untouched / as is" đứng sau vùng cũng bị cắt theo (mọi cụm kích hoạt: "protect the skin as is")
            while (endIdx < toks.size && (toks[endIdx].canon in KEEP_WORDS || (toks[endIdx].canon == "as" && endIdx + 1 < toks.size && toks[endIdx + 1].canon == "is"))) {
                endIdx += if (toks[endIdx].canon == "as") 2 else 1
            }
            cuts.add(toks[i].start until toks[endIdx - 1].end)
            protect.addAll(found)
            i = endIdx
        }
        if (cuts.isEmpty()) return Result(prompt, emptyList())
        val sb = StringBuilder()
        var pos = 0
        for (c in cuts) { sb.append(prompt, pos, c.first).append(' '); pos = c.last + 1 }
        sb.append(prompt, pos, prompt.length)
        return Result(tidy(sb.toString()), protect.toList())
    }

    /** Dọn phần còn lại: bỏ từ nối đứng đầu/cuối và nối trùng nhau ("nhưng và"), bỏ token chỉ có dấu câu. */
    private fun tidy(s: String): String {
        val parts = s.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val keep = ArrayList<String>()
        var prevConnect = true                                // coi đầu câu như vừa có từ nối ⇒ bỏ từ nối đứng đầu
        for (p in parts) {
            val core = p.trim { !it.isLetterOrDigit() }
            if (core.isEmpty()) continue
            val isConnect = GenIntent.fold(core).replace(" ", "") in LEAD_CONNECT
            if (isConnect && prevConnect) continue
            prevConnect = isConnect
            keep.add(p)
        }
        while (keep.isNotEmpty() && GenIntent.fold(keep.last().trim { !it.isLetterOrDigit() }).replace(" ", "") in LEAD_CONNECT) keep.removeAt(keep.size - 1)
        return keep.joinToString(" ").trim().trimEnd(',', ';', ':')
    }
}
