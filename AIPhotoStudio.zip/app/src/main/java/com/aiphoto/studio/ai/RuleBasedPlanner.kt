package com.aiphoto.studio.ai

import com.aiphoto.studio.ai.OpType.*
import com.aiphoto.studio.engine.SplitTone
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

// ---------------------------------------------------------------------------------------------
//  Bộ hiểu prompt OFFLINE (tiếng Việt + tiếng Anh) - luôn chạy được, không cần model.
//  Dùng làm phương án dự phòng khi chưa nạp LLM hoặc LLM trả về kết quả không hợp lệ.
// ---------------------------------------------------------------------------------------------

private val regexCache = ConcurrentHashMap<String, Regex>()

/** key kết thúc bằng "!" = khớp nguyên từ; không có "!" = khớp đầu từ (prefix). */
private fun rx(key: String): Regex = regexCache.getOrPut(key) {
    val exact = key.endsWith("!")
    val body = Regex.escape(if (exact) key.dropLast(1) else key)
    Regex("(?<![a-z0-9])" + body + (if (exact) "(?![a-z0-9])" else ""))
}

private class Clause(var text: String) {
    fun has(vararg keys: String): Boolean = keys.any { rx(it).containsMatchIn(text) }

    /** Kiểm tra và "ăn" luôn cụm từ khỏi câu để các luật sau không bị nhiễu. */
    fun take(vararg keys: String): Boolean {
        var found = false
        for (k in keys) {
            val r = rx(k)
            if (r.containsMatchIn(text)) {
                found = true
                text = r.replace(text, " ")
            }
        }
        return found
    }
}

object RuleBasedPlanner {

    private val STRONG = listOf("rat!", "manh!", "nhieu!", "cuc!", "very!", "strong", "much!", "heavy", "max!")
    private val WEAK = listOf("nhe!", "chut!", "hoi!", "slight", "little!", "bit!", "subtle")
    private val RATIO = Regex("(\\d{1,2})\\s*[:/x]\\s*(\\d{1,2})")

    // ---- chia tông màu: "highlight màu cam", "shadow xanh ngọc", "cam cho vùng sáng", "teal in the shadows" ...
    private const val HI_KEY = "(?:highlights?|vung sang|phan sang|tong sang)"
    private const val SH_KEY = "(?:shadows?|vung toi|phan toi|tong toi|vung bong)"
    private const val FILLER = "(?:mau|color|colour|tone|tong|sac|ve|sang|thanh|toward|towards|to|with|la|nga|nghieng|ngam|hoi)"
    private val COLOR_ALT: String by lazy { SplitTone.COLOR_WORDS.joinToString("|") { Regex.escape(it) } }
    private fun splitRx(key: String): Regex =
        Regex("(?<![a-z0-9])$key(?![a-z0-9])\\s+(?:$FILLER\\s+){0,2}($COLOR_ALT)(?![a-z0-9])")
    private fun splitRxRev(key: String): Regex =
        Regex("(?<![a-z0-9])($COLOR_ALT)(?![a-z0-9])\\s+(?:cho|o|in|for|on|at)\\s+(?:the\\s+)?$key(?![a-z0-9])")
    private val HI_RX by lazy { splitRx(HI_KEY) }
    private val SH_RX by lazy { splitRx(SH_KEY) }
    private val HI_RX_REV by lazy { splitRxRev(HI_KEY) }
    private val SH_RX_REV by lazy { splitRxRev(SH_KEY) }

    fun plan(prompt: String): EditPlan {
        val raw = Normalizer.normalize(prompt.lowercase(Locale.ROOT), Normalizer.Form.NFC)
            .replace("nâng", "tăng") // "nâng" (raise) sau khi bỏ dấu trùng "nắng" (sun) -> bị hiểu nhầm là tông ấm
            .replace("sang trọng", "cao cấp") // "sang trọng" (classy) sau khi bỏ dấu trùng "sáng trong" (bright, clear)
            .replace("black and white", "grayscale")
            .replace("black & white", "grayscale")
            .replace(Regex("(teal|xanh ngọc|xanh lơ)\\s*(and|&|,|/|và|-)\\s*(orange|cam)"), "teal orange look")
            .replace(Regex("(orange|cam)\\s*(and|&|,|/|và|-)\\s*(teal|xanh ngọc|xanh lơ)"), "teal orange look")
            // "trái và phải" bị tách thành hai mệnh đề ở "và" -> gộp trước khi tách (dùng cho "mở rộng ảnh sang trái và phải")
            .replace(Regex("(trái|phải)\\s*(và|,|and|&)\\s*(phải|trái)"), "hai bên")
            .replace(Regex("(left|right)\\s*(and|,|&)\\s*(right|left)"), "both sides")
            .replace(Regex("(trên|dưới)\\s*(và|,|and|&)\\s*(dưới|trên)"), "trên dưới")
            .replace(Regex("(top|bottom|up|down)\\s*(and|,|&)\\s*(bottom|top|down|up)"), "top bottom")
        val rawClauses = raw.split(Regex("[,;.!?\\n]+|\\s+(?:và|and|rồi|then|với|kèm|đồng thời|also)\\s+"))
        // giữ cả bản CÒN DẤU của từng mệnh đề để phân biệt "mắt" (eye) với "mặt" (face), vì bỏ dấu thì hai từ trùng nhau
        val clauses = rawClauses.map { Pair(it.trim(), normalize(it)) }.filter { it.second.isNotBlank() }

        val ops = ArrayList<EditOp>()
        val scopedRaw = ArrayList<ScopedOps>()
        for ((orig, t) in clauses) {
            if (!processScoped(orig, t, scopedRaw)) processClause(t, ops)
        }

        val merged = mergeOps(ops).mapNotNull { it.sanitized() }
        val scoped = normalizeScoped(scopedRaw)
        val notes = if (merged.isEmpty() && scoped.isEmpty()) {
            listOf("Chưa hiểu yêu cầu. Thử: \"tăng sáng, làm da mịn, tông ấm\" hoặc \"xóa nền, nền trắng\".")
        } else emptyList()
        return EditPlan(merged, "Bộ quy tắc offline", notes, scoped)
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9%:/&\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun intensity(t: String): Float = when {
        STRONG.any { rx(it).containsMatchIn(t) } -> 1.6f
        WEAK.any { rx(it).containsMatchIn(t) } -> 0.5f
        else -> 1f
    }

    /**
     * Các yêu cầu chỉ áp dụng cho MỘT VÙNG (răng, mắt, quầng thâm, bầu trời, chủ thể, nền) -> nhóm phép chỉnh kèm vùng.
     * Trả về true nếu đã "tiêu thụ" cả mệnh đề (khi đó không xử lý như phép chỉnh toàn ảnh nữa).
     * [orig] là mệnh đề còn dấu (để phân biệt "mắt"/"mặt"), [t] là bản đã bỏ dấu.
     */
    private fun processScoped(orig: String, t: String, out: MutableList<ScopedOps>): Boolean {
        val c = Clause(t)
        val k = intensity(t)
        val reduce = c.has("giam", "bot!", "less!", "reduce", "lower", "decrease")
        fun add(scope: String, vararg ops: EditOp) { out.add(ScopedOps(scope, ops.toList())) }
        fun v(base: Float): Float = (base * k).coerceAtMost(1f)

        // Dodge & Burn tự động trên khuôn mặt ("làm nổi khối", "tạo khối mặt", "contour", "dodge burn"): sáng thêm chỗ sáng, tối thêm chỗ tối
        if (c.has("noi khoi", "tao khoi", "contour", "sculpt", "dodge burn", "dodge and burn", "dodge & burn", "dodge/burn")) {
            if (!reduce) {
                add(Scope.FACE_LIGHT, EditOp(OpType.BRIGHTNESS, v(0.20f)))
                add(Scope.FACE_SHADOW, EditOp(OpType.BRIGHTNESS, -v(0.20f)))
            }
            return true
        }
        // Sợi tóc lạc / tóc bay: xóa vật mảnh trên DA và NỀN (tóc thật, lông mi, lông mày nằm ngoài hai mặt nạ này nên được giữ)
        if (c.has("soi toc lac", "soi toc thua", "toc bay", "stray hair", "flyaway", "loose hair")) {
            add(Scope.SKIN, EditOp(OpType.DUST, v(0.8f)))
            add(Scope.BACKGROUND, EditOp(OpType.DUST, v(0.8f)))
            return true
        }
        // Tóc: nhuộm / đổi màu / bóng mượt / đậm nhạt (mặt nạ từ Hair Segmenter)
        if (c.has("toc!", "hair!")) {
            val hex: String? = when {
                c.has("xanh duong", "xanh lam", "blue") -> "#2D6CDF"
                c.has("xanh la", "xanh luc", "green") -> "#2E9E57"
                c.has("bac!", "xam!", "silver", "grey!", "gray!", "ghi!") -> "#B8B8C4"
                c.has("vang!", "blonde", "bach kim", "platinum") -> "#D8B25A"
                c.has("nau!", "brown", "hat de", "chestnut") -> "#6B4423"
                c.has("do!", "red!", "do dong") -> "#B3261E"
                c.has("cam!", "orange") -> "#D9731A"
                c.has("hong!", "pink") -> "#E85D9E"
                c.has("tim!", "purple", "violet") -> "#7B3FA0"
                c.has("den!", "black") -> "#1A1A1A"
                c.has("trang!", "white") -> "#EEEEEE"
                else -> null
            }
            val dye = c.has("nhuom", "doi mau", "mau!", "color", "colour", "dye", "tint")
            // "phong" khớp đầu từ nên loại "phong cách / phong thái"; KHÔNG dùng "xù" (= rối, không phải phồng)
            val volume = c.has("phong", "day hon", "day dan", "volume", "fuller", "thicker", "thick!", "bong len") &&
                !c.has("phong cach", "phong thai")
            when {
                volume && !reduce && hex == null -> add(Scope.HAIR, EditOp(OpType.HAIR_VOLUME, v(0.6f)))
                hex != null && (dye || !reduce) -> add(Scope.HAIR, EditOp(OpType.COLORIZE, v(0.85f), hex))
                c.has("bong", "muot", "shine", "shiny", "silky", "glossy", "smooth") && !reduce ->
                    add(Scope.HAIR, EditOp(OpType.CLARITY, v(0.30f)), EditOp(OpType.CONTRAST, v(0.15f)))
                c.has("dam hon", "toi hon", "darker") -> add(Scope.HAIR, EditOp(OpType.BRIGHTNESS, -v(0.22f)))
                c.has("sang hon", "nhat hon", "lighter") -> add(Scope.HAIR, EditOp(OpType.BRIGHTNESS, v(0.22f)))
            }
            return true
        }
        // Quầng thâm / bọng mắt (kiểm tra trước "mắt" vì cùng chứa chữ "mat")
        if (c.has("quang tham", "bong mat", "tham mat", "dark circle", "under eye", "under-eye", "eye bag", "eyebag")) {
            if (!reduce) add(Scope.DARK_CIRCLES, EditOp(OpType.SHADOWS, v(0.55f)), EditOp(OpType.BRIGHTNESS, v(0.10f)))
            return true
        }
        // Răng trắng hơn
        if (c.has("trang rang", "rang trang", "tay trang rang", "whiten", "teeth", "tooth")) {
            add(Scope.TEETH, EditOp(OpType.BRIGHTNESS, v(0.22f)), EditOp(OpType.SATURATION, -(v(0.45f))))
            return true
        }
        // Mắt sáng / long lanh. Chỉ nhận khi có "mắt" CÒN DẤU (hoặc eye/eyes/long lanh): bỏ dấu thì "mắt" và "mặt" trùng nhau
        // ("sang mat" có thể là "sáng mặt"), nên viết không dấu sẽ rơi về chỉnh sáng toàn ảnh thay vì đoán sai.
        val eyeWord = orig.contains("mắt") || c.has("eye!", "eyes!", "long lanh")
        if (eyeWord && c.has("sang", "bright", "long lanh", "ro!", "net", "lam ro", "sharp")) {
            if (!reduce) add(Scope.EYES, EditOp(OpType.BRIGHTNESS, v(0.15f)), EditOp(OpType.CLARITY, v(0.35f)), EditOp(OpType.CONTRAST, v(0.10f)))
            return true
        }
        // Chủ thể nổi bật hơn
        if (c.has("chu the", "subject") && c.has("noi bat", "pop", "sang", "bright", "ro!", "net", "lam ro")) {
            if (!reduce) add(Scope.SUBJECT, EditOp(OpType.BRIGHTNESS, v(0.12f)), EditOp(OpType.CONTRAST, v(0.15f)), EditOp(OpType.CLARITY, v(0.30f)))
            return true
        }
        // Nền tối / nhạt hơn (không phải xóa nền, mờ nền)
        if (c.has("toi nen", "toi phong", "toi hau canh", "darken background", "dim background", "background darker")) {
            add(Scope.BACKGROUND, EditOp(OpType.BRIGHTNESS, -v(0.30f)))
            return true
        }
        if (c.has("nhat nen", "bot mau nen", "desaturate background", "muted background")) {
            add(Scope.BACKGROUND, EditOp(OpType.SATURATION, -v(0.50f)))
            return true
        }
        // "thay/đổi bầu trời" = phép chỉnh toàn ảnh SKY_REPLACE (xử lý ở processClause), không phải chỉnh màu vùng trời
        if (c.has("thay bau troi", "doi bau troi", "replace sky", "change sky", "sky replacement", "bau troi moi")) return false
        // Bầu trời
        if (c.has("bau troi", "sky!")) {
            val ops = ArrayList<EditOp>()
            when {
                c.has("an tuong", "kich tinh", "dramatic", "hung vi") -> {
                    ops.add(EditOp(OpType.CLARITY, v(0.40f))); ops.add(EditOp(OpType.CONTRAST, v(0.25f))); ops.add(EditOp(OpType.SATURATION, v(0.20f)))
                }
                c.has("hoang hon", "sunset", "am ap", "warm", "vang!", "cam!") -> {
                    ops.add(EditOp(OpType.WARMTH, v(0.40f))); ops.add(EditOp(OpType.SATURATION, v(0.20f)))
                }
                c.has("toi!", "dark", "dim") -> ops.add(EditOp(OpType.BRIGHTNESS, -v(0.20f)))
                c.has("sang", "bright") -> ops.add(EditOp(OpType.BRIGHTNESS, v(0.20f)))
                c.has("xanh", "blue") -> {
                    ops.add(EditOp(OpType.SATURATION, v(0.35f))); ops.add(EditOp(OpType.CONTRAST, v(0.10f)))
                }
                else -> {
                    ops.add(EditOp(OpType.SATURATION, v(0.25f))); ops.add(EditOp(OpType.CONTRAST, v(0.10f)))
                }
            }
            if (reduce) return true
            out.add(ScopedOps(Scope.SKY, ops))
            return true
        }
        return false
    }

    private fun processClause(t: String, out: MutableList<EditOp>) {
        val c = Clause(t)
        val k = intensity(t)
        val pct = Regex("(\\d{1,3})\\s*%").find(t)?.groupValues?.get(1)?.toFloatOrNull()?.div(100f)

        fun mag(def: Float): Float = pct ?: (def * k)
        fun preset(def: Float): Float = (def * k).coerceAtMost(1f)
        fun add(type: OpType, v: Float, arg: String? = null) { out.add(EditOp(type, v, arg)) }
        fun signed(type: OpType, def: Float, negative: Boolean) {
            add(type, if (negative) -mag(def) else mag(def))
        }

        val reduce = c.has("giam", "bot!", "thap", "less!", "reduce", "lower", "decrease", "bo bot", "qua!", "too!", "ha!")

        // ---------------- Mở rộng ảnh (outpainting) ----------------
        // Phải đặt TRƯỚC luật "mờ": bỏ dấu thì "mở rộng" = "mo rong" mà "mo!" lại là từ khóa làm mờ (bug cũ: "mở rộng ảnh" → làm mờ 35%).
        val whole = Clause(t)   // bản chưa bị "ăn" từ khóa: "wider/taller" vừa là lệnh mở vừa cho biết hướng
        if (c.take("mo rong", "keo dai", "keo rong", "outpaint", "uncrop", "extend", "expand", "widen", "wider!", "taller!", "zoom out")) {
            val left = c.has("trai!", "left!")
            val right = c.has("phai!", "right!")
            val top = c.has("tren!", "top!", "len!", "above", "up!")
            val bottom = c.has("duoi!", "bottom!", "xuong!", "below", "down!")
            val both = whole.has("hai ben", "hai phia", "ngang!", "horizontal", "both sides", "wider!", "widen", "sides!", "chieu rong")
            val vert = whole.has("tren duoi", "top bottom", "doc!", "vertical", "taller!", "chieu cao")
            val all = c.has("xung quanh", "moi phia", "bon phia", "bon ben", "tat ca", "all around", "all sides", "every side", "around!")
            val ratioMatch = RATIO.find(c.text)
            val square = c.has("vuong", "square")
            val amount = (pct ?: (0.2f * k)).coerceIn(0.02f, 1f)
            val sides = listOf(left, right, top, bottom).count { it }
            if (ratioMatch != null || square) {
                val r = if (ratioMatch != null) ratioMatch.groupValues[1].toFloat() / ratioMatch.groupValues[2].toFloat().coerceAtLeast(1f) else 1f
                val anchor = when {
                    sides == 1 && left -> 'l'
                    sides == 1 && right -> 'r'
                    sides == 1 && top -> 't'
                    sides == 1 && bottom -> 'b'
                    else -> 'c'
                }
                add(OUTPAINT, 1f, String.format(Locale.US, "ratio=%.4f,a=%c", r, anchor))
            } else {
                val h = both || all || (left && right)
                val v = vert || all || (top && bottom)
                val noneNamed = !(left || right || top || bottom || both || vert || all)
                val l = if (left || h || noneNamed) amount else 0f
                val rr = if (right || h || noneNamed) amount else 0f
                val t = if (top || v || noneNamed) amount else 0f
                val b = if (bottom || v || noneNamed) amount else 0f
                add(OUTPAINT, 1f, String.format(Locale.US, "l=%.3f,r=%.3f,t=%.3f,b=%.3f", l, rr, t, b))
            }
            return
        }

        // ---------------- Chia tông màu (split toning / color grading) ----------------
        // Xét trước "vùng sáng/vùng tối" (HIGHLIGHTS/SHADOWS) vì cùng từ khóa; chỉ khi kèm tên MÀU mới là nhuộm tông, không thì giữ nghĩa cũ.
        run {
            var sh: Float? = null
            var hi: Float? = null
            fun grab(rx: Regex): Float? {
                val m = rx.find(c.text) ?: return null
                val hue = SplitTone.hueOf(m.groupValues[1])
                c.text = rx.replace(c.text, " ")
                return hue
            }
            if (c.has("teal orange look")) {
                sh = 185f; hi = 28f
                c.text = c.text.replace("teal orange look", " ")
            } else {
                hi = grab(HI_RX) ?: grab(HI_RX_REV)
                sh = grab(SH_RX) ?: grab(SH_RX_REV)
            }
            if (hi != null || sh != null) {
                val sat = (pct ?: (0.55f * k)).coerceIn(0.05f, 1f)
                add(
                    SPLIT_TONE, 1f,
                    SplitTone.format(SplitTone.Params(sh ?: 0f, if (sh != null) sat else 0f, hi ?: 0f, if (hi != null) sat else 0f))
                )
            }
        }

        // ---------------- Câu mơ hồ kiểu người dùng không chuyên (PDF: "trông chuyên nghiệp hơn, da đẹp tự nhiên, màu ấm áp") ----------------
        // Mỗi cụm đổi thành một BỘ phép chỉnh có thứ tự hợp lý (da → tông/màu → chi tiết), cường độ theo "hơi/rất". Phải xét trước các luật
        // từ đơn bên dưới ("sang" = sáng, "đẹp hơn" = làm đẹp...) để cụm dài không bị "ăn" mất một nửa.
        if (c.take(
                "da dep", "da khoe", "da tu nhien", "da muot", "da sang min", "da trong sang", "natural skin", "healthy skin",
                "clear skin", "glowing skin", "skin look", "skin looks"
            )
        ) {
            // giữ kết cấu lỗ chân lông (tách tần số) + làm mịn nhẹ; không "da nhựa"
            add(FREQ_SEP, preset(0.5f)); add(SKIN_SMOOTH, preset(0.25f))
        }
        if (c.take(
                "chuyen nghiep", "professional", "pro look", "studio", "tap chi", "magazine", "cao cap", "sang chanh",
                "luxury", "high end", "polished", "commercial look"
            )
        ) {
            add(AUTO_ENHANCE, preset(0.6f)); add(CONTRAST, preset(0.1f)); add(VIBRANCE, preset(0.25f))
            add(SHARPEN, preset(0.25f)); add(VIGNETTE, preset(0.12f))
        }
        if (c.take("noi bat", "bat mat", "an tuong", "make it pop", "pop!", "eye catching", "eye-catching", "striking")) {
            add(CONTRAST, preset(0.2f)); add(VIBRANCE, preset(0.35f)); add(CLARITY, preset(0.25f))
        }
        if (c.take(
                "look better", "looks better", "better looking", "nicer", "prettier", "more beautiful", "improve", "polish",
                "dep len", "xin hon", "ra dep hon", "dep ra", "tot hon", "ung y hon", "cho dep"
            )
        ) {
            add(AUTO_ENHANCE, preset(0.6f)); add(CONTRAST, preset(0.08f)); add(VIBRANCE, preset(0.2f)); add(SHARPEN, preset(0.2f))
        }

        // Hạt film phải xét TRƯỚC preset vintage (vì "film" nằm trong cả hai)
        if (c.take("hat film", "film grain", "grain", "nhieu hat")) add(GRAIN, mag(0.4f), if (reduce) "reduce" else null)

        // ---------------- Preset tổng hợp ----------------
        if (c.take("lam dep", "dep hon", "beautify", "beauty", "retouch")) {
            add(AUTO_ENHANCE, preset(0.6f)); add(SKIN_SMOOTH, preset(0.5f))
            add(BRIGHTNESS, preset(0.06f)); add(SATURATION, preset(0.1f)); add(SHARPEN, preset(0.2f))
        }
        if (c.take("chan dung", "portrait")) {
            add(SKIN_SMOOTH, preset(0.4f)); add(AUTO_ENHANCE, preset(0.4f)); add(WARMTH, preset(0.1f))
        }
        if (c.take("phong canh", "landscape")) {
            add(SATURATION, preset(0.25f)); add(CONTRAST, preset(0.15f))
            add(AUTO_ENHANCE, preset(0.5f)); add(SHARPEN, preset(0.3f))
        }
        if (c.take("thieu sang", "toi qua", "low light", "nguoc sang", "backlit", "dem!", "ban dem")) {
            add(SHADOWS, preset(0.7f)); add(BRIGHTNESS, preset(0.15f)); add(AUTO_ENHANCE, preset(0.5f))
        }
        if (c.take("hdr!")) {
            add(AUTO_ENHANCE, preset(0.8f)); add(SHADOWS, preset(0.5f))
            add(CONTRAST, preset(0.2f)); add(SATURATION, preset(0.2f)); add(SHARPEN, preset(0.4f))
        }
        if (c.take("vintage", "co dien", "retro", "phim cu", "film!")) {
            add(SATURATION, -0.2f); add(WARMTH, preset(0.3f)); add(CONTRAST, -0.1f)
            add(SEPIA, preset(0.25f)); add(VIGNETTE, preset(0.4f))
        }
        if (c.take("dien anh", "cinematic", "cinema", "teal")) {
            add(CINEMATIC, preset(0.8f)); add(CONTRAST, preset(0.1f)); add(VIGNETTE, preset(0.25f))
        }
        if (c.take("song ao", "instagram", "tiktok")) {
            add(AUTO_ENHANCE, preset(0.5f)); add(SATURATION, preset(0.25f))
            add(CONTRAST, preset(0.1f)); add(WARMTH, preset(0.1f))
        }
        if (c.take("sepia")) add(SEPIA, preset(0.8f))
        if (c.take("den trang", "trang den", "grayscale", "monochrome", "b&w", "bw!", "grey", "gray")) {
            add(GRAYSCALE, 1f)
        }

        // ---------------- Thay bầu trời (tự nhận diện trời, thay bằng trời mẫu) ----------------
        if (c.take("thay bau troi", "doi bau troi", "replace sky", "change sky", "sky replacement", "bau troi moi")) {
            val sky = when {
                c.has("hoang hon", "sunset", "binh minh", "sunrise", "cam!") -> "sunset"
                c.has("chang vang", "dusk", "twilight", "tim!") -> "dusk"
                c.has("am u", "overcast", "xam!", "may mu", "cloudy") -> "overcast"
                c.has("dem!", "night", "sao!", "star") -> "night"
                else -> "blue"
            }
            add(SKY_REPLACE, 1f, sky)
            c.take("hoang hon", "sunset", "binh minh", "sunrise", "chang vang", "dusk", "twilight", "am u", "overcast",
                "may mu", "cloudy", "dem!", "night", "sao!", "star", "xanh duong", "xanh!", "blue")
        }

        // ---------------- Phông / nền ----------------
        if (c.take("mo phong", "mo nen", "blur background", "background blur", "bokeh", "lam mo hau canh")) {
            add(BG_BLUR, mag(0.7f))
        }
        val idPhoto = c.take("anh the")
        val bgRemove = c.take(
            "xoa nen", "xoa phong", "tach nen", "tach phong", "bo nen", "bo phong",
            "cat nen", "cat phong", "remove background", "remove bg", "xoa background",
            "nen trong suot", "transparent background", "doi nen", "thay nen", "doi phong",
            "thay phong", "change background", "change the background", "replace background", "replace the background", "swap background", "swap the background", "white background",
            "nen trang", "nen xanh", "nen den", "nen do", "nen hong", "nen vang", "nen xam",
            "phong trang", "phong xanh"
        )
        if (bgRemove || idPhoto) {
            val cc = Clause(t) // dò màu trên câu gốc (vì các cụm trên đã bị "ăn")
            val color = when {
                cc.has("trong suot", "transparent") -> "transparent"
                cc.has("trang", "white") -> "#FFFFFF"
                cc.has("xanh duong", "blue", "xanh!") -> "#2D6CDF"
                cc.has("xanh la", "green") -> "#2E9E57"
                cc.has("den!", "black") -> "#000000"
                cc.has("nen do", "phong do", "red") -> "#D32F2F"
                cc.has("hong", "pink") -> "#F48FB1"
                cc.has("vang!", "yellow") -> "#FFD54F"
                cc.has("xam", "gray", "grey") -> "#9E9E9E"
                idPhoto -> "#FFFFFF"
                else -> "transparent"
            }
            add(BG_REMOVE, 1f, color)
            if (idPhoto) {
                val m = RATIO.find(t)
                val r = m?.let { it.groupValues[1].toFloat() / it.groupValues[2].toFloat() } ?: 0.75f
                add(CROP_RATIO, r)
            }
            return
        }

        // ---------------- Hình học ----------------
        if (c.take("xoay", "rotate", "quay")) {
            val deg = Regex("(\\d{2,3})").find(c.text)?.groupValues?.get(1)?.toIntOrNull()
            val d = when {
                deg != null -> deg
                c.has("trai", "left", "nguoc") -> 270
                else -> 90
            }
            add(ROTATE, d.toFloat())
        }
        if (c.take("lat ngang", "flip horizontal", "mirror", "guong", "doi xung")) add(FLIP_H, 1f)
        if (c.take("lat doc", "flip vertical")) add(FLIP_V, 1f)

        val ratioMatch = RATIO.find(c.text)
        if ((c.has("cat", "crop", "ti le", "ratio") && ratioMatch != null) || c.has("vuong", "square")) {
            val r = ratioMatch?.let { it.groupValues[1].toFloat() / it.groupValues[2].toFloat() } ?: 1f
            add(CROP_RATIO, r)
            c.take("vuong", "square")
            c.text = RATIO.replace(c.text, " ")
        }
        if (c.take(
                "phong to", "tang do phan giai", "upscale", "tang kich thuoc", "sieu phan giai",
                "super resolution", "2x", "x2", "4x", "x4", "4k", "hd!"
            )
        ) {
            val big = t.contains("4x") || t.contains("x4") || t.contains("4k")
            add(UPSCALE, if (big) 4f else 2f)
        }

        // ---------------- Tông / chi tiết ----------------
        if (c.take("vung toi", "shadow", "vung bong")) {
            add(SHADOWS, mag(0.5f), if (reduce) "reduce" else null)
            c.take("sang", "lighten", "bright") // "làm sáng vùng tối" = chỉ nâng vùng tối
        }
        // R13: khớp ánh sáng tiền cảnh với trời mới (đi kèm "thay bầu trời")
        if (c.take("khop anh sang", "tai chieu sang", "relight", "anh sang tien canh")) add(SKY_RELIGHT, mag(0.6f))
        // R12: xóa bụi / vết xước toàn ảnh (bộ lọc trung vị có ngưỡng)
        if (c.take("xoa bui", "loai bo bui", "sach bui", "bui ban", "bui!", "dust", "vet xuoc", "xuoc!", "scratch")) add(DUST, mag(0.5f))
        // R25: khử moiré (chụp màn hình, vải kẻ mịn) và làm nét lại ảnh nhòe/rung (khác "làm nét" = sharpen). Hai phép đi đường "bake";
        // đặt TRƯỚC luật "motion blur" / "làm nét" / "mờ" để "remove motion blur", "làm nét lại", "khử mờ" không bị luật cũ ăn từ khóa.
        if (c.take("moire", "soc man hinh", "van man hinh", "khu soc", "xoa soc", "screen pattern", "remove stripe")) add(MOIRE, preset(1f))
        if (!c.has("mo hoi") && c.take(
                "khu mo!", "khu nhoe", "het mo!", "het nhoe", "sua anh mo", "anh bi mo", "bi nhoe", "bi rung", "rung tay", "khu rung", "chong rung",
                "unblur", "deblur", "de blur", "lam net lai", "net lai", "phuc hoi do net", "mat net", "fix blur", "remove blur", "remove motion blur", "restore sharp"
            )
        ) add(UNBLUR, mag(0.8f))
        // R11: khử/thêm sương mù, vùng sáng, vibrance, tint, kết cấu — xét TRƯỚC các luật độ sáng/bão hòa để không bị "ăn" từ khóa
        if (c.take("them suong", "tao suong", "add haze", "add fog", "foggy")) add(DEHAZE, -mag(0.5f))
        else if (c.take("khu suong", "bot suong", "het suong", "xuyen suong", "mo suong", "phu suong", "mu suong", "suong mu", "suong!", "hazy", "dehaze", "de haze", "remove haze", "remove fog", "haze!", "fog!")) add(DEHAZE, mag(0.6f))
        if (c.take("chay sang", "blown", "overexposed", "cuu vung sang", "recover highlight")) add(HIGHLIGHTS, -mag(0.6f))
        else if (c.take("vung sang", "highlight", "phan sang")) signed(HIGHLIGHTS, 0.45f, reduce)
        if (c.take("vibrance", "mau thong minh", "smart saturation", "mau tu nhien", "natural saturation")) signed(VIBRANCE, 0.4f, reduce)
        val tintGreen = c.take("green tint", "tint xanh la", "tint luc", "sac luc", "ngam luc")
        val tintMagenta = c.take("magenta", "tint tim", "tint hong", "sac tim", "ngam tim", "pink tint", "purple tint")
        if (tintGreen || tintMagenta) signed(TINT, 0.35f, tintGreen != reduce)
        val smoothish = c.has("lam min", "min!", "smooth", "mem mai", "soft")
        if (c.take("ket cau", "texture", "cau truc", "structure")) {
            signed(TEXTURE, 0.4f, reduce || smoothish)
            // "làm mịn kết cấu" (không nhắc da) chỉ là giảm texture, không kèm làm mịn da; nhắc "da/mặt" thì giữ cả hai
            if (smoothish && !c.has("da!", "skin", "mat!", "face")) c.take("lam min", "min!", "smooth", "mem mai", "soft")
        }
        if (c.take("tu dong", "auto", "cai thien", "enhance", "toi uu", "lam ro")) add(AUTO_ENHANCE, mag(0.8f))
        if (c.take("tach tan so", "frequency separation")) add(FREQ_SEP, mag(0.6f), if (reduce) "reduce" else null)
        if (c.take("hat film", "film grain", "grain", "nhieu hat")) add(GRAIN, mag(0.4f), if (reduce) "reduce" else null)
        if (c.take("da min", "min da", "min!", "lam min", "smooth", "mun", "skin", "lam tron da", "tri mun")) {
            add(SKIN_SMOOTH, mag(0.55f), if (reduce) "reduce" else null)
        }
        if (c.take("vignette", "vien toi", "toi goc", "goc toi", "toi vien")) add(VIGNETTE, mag(0.5f), if (reduce) "reduce" else null)
        // Filter Gallery
        if (c.take("posterize", "poster hoa", "giam so mau")) add(POSTERIZE, mag(0.5f), if (reduce) "reduce" else null)
        if (c.take("pixelate", "pixel hoa", "mosaic", "o vuong", "pixel art")) add(PIXELATE, mag(0.4f), if (reduce) "reduce" else null)
        if (c.take("duotone", "hai tong mau")) add(DUOTONE, preset(0.9f))
        if (c.take("emboss", "dap noi")) add(EMBOSS, mag(0.9f), if (reduce) "reduce" else null)
        if (c.take("phac hoa", "sketch", "but chi", "pencil", "ve chi")) add(SKETCH, mag(0.9f), if (reduce) "reduce" else null)
        if (c.take("phat sang", "glow", "orton", "mong ao", "dreamy", "bloom")) add(GLOW, mag(0.6f), if (reduce) "reduce" else null)
        if (c.take("chromatic", "lech mau", "glitch")) add(CHROMA, mag(0.6f), if (reduce) "reduce" else null)
        if (c.take("matte", "phai mau", "faded", "fade!", "phai mau")) add(MATTE, mag(0.6f), if (reduce) "reduce" else null)
        // R25: phong cách tranh cổ điển chạy ngay trên máy (OpType.STYLE); anime / Ghibli / Van Gogh… đi đường AI (WholeEditIntent)
        val styleName = when {
            c.take("son dau", "oil painting", "oil paint") -> "oil"
            c.take("hoat hinh", "cartoon", "toon") -> "cartoon"
            c.take("mau nuoc", "watercolor", "watercolour", "water color") -> "watercolor"
            else -> null
        }
        if (styleName != null) add(STYLE, mag(0.9f), styleName)

        if (c.take("khu nhieu", "giam nhieu", "denoise", "noise reduction", "lam sach nhieu")) add(DENOISE, mag(0.5f))
        if (c.take("mo chuyen dong", "motion blur")) add(MOTION_BLUR, mag(0.4f), "0")
        if (c.take("mo xuyen tam", "radial blur", "zoom blur")) add(RADIAL_BLUR, mag(0.4f))
        if (c.take("lam net", "net hon", "sac net", "sharp", "chi tiet", "detail", "clarity", "net!", "sac!")) {
            if (reduce) add(BLUR, mag(0.3f)) else add(SHARPEN, mag(0.5f))
        }
        if (c.take("lam mo", "blur", "mo!", "mo hon")) {
            if (reduce) add(SHARPEN, mag(0.4f)) else add(BLUR, mag(0.35f))
        }

        if (c.take("tuong phan", "contrast")) signed(CONTRAST, 0.2f, reduce)

        val satNeg = c.take("nhat mau", "desaturat", "bot mau", "muted")
        // "màu ấm áp / màu lạnh" chỉ là danh từ "màu" đi với tông ấm-lạnh, không phải yêu cầu tăng bão hòa
        val colorIsTone = c.has("am ap", "tong am", "am!", "warm", "golden", "hoang hon", "sunset", "nang!", "lanh", "cool", "cold", "tong mat", "lam mat", "blue tone")
        val satWord = c.take(
            "bao hoa", "saturat", "ruc ro", "sinh dong", "vibrant", "vivid", "mau sac",
            "colorful", "dam mau", "tuoi!", "tuoi tan"
        )
        val mauWord = c.take("mau!")
        val satPos = satWord || (mauWord && !colorIsTone)
        if (satNeg || satPos) signed(SATURATION, 0.25f, satNeg || reduce)

        val warmNeg = c.take("lanh", "cool", "cold", "tong mat", "lam mat", "blue tone")
        val warmPos = c.take("am ap", "tong am", "am!", "warm", "golden", "hoang hon", "sunset", "nang!")
        if (warmNeg || warmPos) signed(WARMTH, 0.3f, warmNeg || reduce)

        val dark = c.take("toi!", "dark", "dim", "darken")
        val bright = c.take("sang", "bright", "lighten", "exposure")
        if (dark || bright) {
            val negative = if (dark && !bright) !reduce else reduce
            signed(BRIGHTNESS, 0.18f, negative)
        }
    }
}
