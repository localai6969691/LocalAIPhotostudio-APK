package com.aiphoto.studio.engine

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Toán mặt nạ thuần Kotlin (kiểm thử được): mặt nạ theo KÊNH màu (RGB / HSV / Lab) và Focus Area (vùng nét theo độ tương phản cục bộ).
 * Bản port Python kiểm số học (Lab so với OpenCV, Focus trên ảnh nét/phẳng): tools/verify_ports/geo_ports.py.
 */
object MaskMath {
    const val SPACE_RGB = 0
    const val SPACE_HSV = 1
    const val SPACE_LAB = 2

    fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** sRGB (0..255) -> CIE Lab (D65): L 0..100, a/b khoảng ±128. */
    fun rgbToLab(r: Int, g: Int, b: Int): FloatArray {
        fun lin(c8: Int): Float {
            val c = c8 / 255f
            return if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
        }
        val rl = lin(r); val gl = lin(g); val bl = lin(b)
        val x = (0.4124564f * rl + 0.3575761f * gl + 0.1804375f * bl) / 0.95047f
        val y = 0.2126729f * rl + 0.7151522f * gl + 0.0721750f * bl
        val z = (0.0193339f * rl + 0.1191920f * gl + 0.9503041f * bl) / 1.08883f
        fun f(t: Float): Float = if (t > 216f / 24389f) Math.cbrt(t.toDouble()).toFloat() else (24389f / 27f * t + 16f) / 116f
        val fx = f(x); val fy = f(y); val fz = f(z)
        return floatArrayOf(116f * fy - 16f, 500f * (fx - fy), 200f * (fy - fz))
    }

    /** Giá trị kênh [ch] (0..2) của điểm ảnh [p] trong không gian [space], chuẩn hóa 0..1. */
    fun channelValue(p: Int, space: Int, ch: Int): Float {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return when (space) {
            SPACE_RGB -> when (ch) { 0 -> r; 1 -> g; else -> b } / 255f
            SPACE_HSV -> {
                val rf = r / 255f; val gf = g / 255f; val bf = b / 255f
                val mx = max(rf, max(gf, bf)); val mn = min(rf, min(gf, bf)); val d = mx - mn
                when (ch) {
                    0 -> {
                        if (d < 1e-6f) 0f
                        else {
                            val t = when {
                                mx == rf -> (gf - bf) / d
                                mx == gf -> (bf - rf) / d + 2f
                                else -> (rf - gf) / d + 4f
                            }
                            (60f * (if (t < 0f) t + 6f else t)) / 360f
                        }
                    }
                    1 -> if (mx <= 0f) 0f else d / mx
                    else -> mx
                }
            }
            else -> {
                val lab = rgbToLab(r, g, b)
                when (ch) {
                    0 -> lab[0] / 100f
                    1 -> ((lab[1] + 128f) / 255f).coerceIn(0f, 1f)
                    else -> ((lab[2] + 128f) / 255f).coerceIn(0f, 1f)
                }
            }
        }
    }

    fun channelMask(px: IntArray, space: Int, ch: Int, lo: Float, hi: Float): FloatArray {
        val out = FloatArray(px.size)
        for (i in px.indices) {
            val v = channelValue(px[i], space, ch)
            out[i] = smooth(lo - 0.04f, lo, v) * (1f - smooth(hi, hi + 0.04f, v))
        }
        return out
    }

    /** Vùng NÉT: biên độ gradient Sobel của độ sáng, chuẩn hóa theo phân vị 95, làm mềm Gauss; lo..hi trên thang 0..1. */
    fun focusMask(px: IntArray, w: Int, h: Int, lo: Float, hi: Float): FloatArray {
        val n = w * h
        val g = FloatArray(n) { val p = px[it]; 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255) }
        val mag = FloatArray(n)
        for (y in 0 until h) {
            val ya = max(0, y - 1); val yb = min(h - 1, y + 1)
            for (x in 0 until w) {
                val xa = max(0, x - 1); val xb = min(w - 1, x + 1)
                val gx = (g[ya * w + xb] + 2f * g[y * w + xb] + g[yb * w + xb]) - (g[ya * w + xa] + 2f * g[y * w + xa] + g[yb * w + xa])
                val gy = (g[yb * w + xa] + 2f * g[yb * w + x] + g[yb * w + xb]) - (g[ya * w + xa] + 2f * g[ya * w + x] + g[ya * w + xb])
                mag[y * w + x] = hypot(gx, gy)
            }
        }
        val step = max(1, n / 20000)
        val sample = FloatArray((n + step - 1) / step) { mag[it * step] }
        sample.sort()
        val ref = max(4f, sample[((sample.size - 1) * 0.95f).toInt()])
        val gray = IntArray(n) { val v = (mag[it] * 255f / ref).toInt().coerceIn(0, 255); (255 shl 24) or (v shl 16) or (v shl 8) or v }
        val blurred = Blur.gaussian(gray, w, h, max(2, max(w, h) / 80))
        val out = FloatArray(n)
        for (i in 0 until n) {
            val s = (blurred[i] and 255) / 255f
            out[i] = smooth(lo - 0.1f, lo, s) * (1f - smooth(hi, hi + 0.1f, s))
        }
        return out
    }
}
