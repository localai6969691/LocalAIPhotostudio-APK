package com.aiphoto.studio.engine

/**
 * FFT 1 chiều / 2 chiều cơ số 2 (thuần Kotlin, mảng Float). Kích thước mỗi chiều PHẢI là lũy thừa của 2.
 * Biến đổi thuận: X[k] = Σ x[n]·e^(−2πi·kn/N); biến đổi ngược chia 1/N (2D: chia 1/(w·h)) nên ngược(thuận(x)) = x.
 */
object Fft {

    fun isPow2(n: Int): Boolean = n > 0 && (n and (n - 1)) == 0

    fun nextPow2(n: Int): Int {
        var p = 1
        while (p < n) p = p shl 1
        return p
    }

    private class Plan(val n: Int) {
        val rev = IntArray(n)
        val cosT = FloatArray(maxOf(1, n / 2))
        val sinT = FloatArray(maxOf(1, n / 2))

        init {
            var bits = 0
            while ((1 shl bits) < n) bits++
            for (i in 0 until n) {
                var r = 0
                var x = i
                for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }
                rev[i] = r
            }
            for (k in 0 until n / 2) {
                val a = 2.0 * Math.PI * k / n
                cosT[k] = Math.cos(a).toFloat()
                sinT[k] = Math.sin(a).toFloat()
            }
        }
    }

    private val plans = HashMap<Int, Plan>()

    @Synchronized
    private fun plan(n: Int): Plan = plans.getOrPut(n) { Plan(n) }

    /** FFT tại chỗ cho đoạn liền kề [off, off+n) của [re]/[im]. [inverse] KHÔNG tự chia 1/N (xem [transform2d]). */
    fun transform(re: FloatArray, im: FloatArray, off: Int, n: Int, inverse: Boolean) {
        require(isPow2(n)) { "độ dài FFT phải là lũy thừa của 2: $n" }
        if (n == 1) return
        val p = plan(n)
        for (i in 0 until n) {
            val j = p.rev[i]
            if (j > i) {
                val tr = re[off + i]; re[off + i] = re[off + j]; re[off + j] = tr
                val ti = im[off + i]; im[off + i] = im[off + j]; im[off + j] = ti
            }
        }
        val sgn = if (inverse) 1f else -1f
        var len = 2
        while (len <= n) {
            val half = len shr 1
            val step = n / len
            var i = 0
            while (i < n) {
                var k = 0
                for (j in 0 until half) {
                    val wr = p.cosT[k]
                    val wi = sgn * p.sinT[k]
                    val a = off + i + j
                    val b = a + half
                    val xr = re[b] * wr - im[b] * wi
                    val xi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - xr
                    im[b] = im[a] - xi
                    re[a] += xr
                    im[a] += xi
                    k += step
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** FFT 2D theo hàng rồi cột cho mảng hàng-chính [w]×[h]; [inverse] = true thì chia 1/(w·h). */
    fun transform2d(re: FloatArray, im: FloatArray, w: Int, h: Int, inverse: Boolean) {
        require(re.size == w * h && im.size == w * h && isPow2(w) && isPow2(h))
        for (y in 0 until h) transform(re, im, y * w, w, inverse)
        val cr = FloatArray(h)
        val ci = FloatArray(h)
        for (x in 0 until w) {
            for (y in 0 until h) { cr[y] = re[y * w + x]; ci[y] = im[y * w + x] }
            transform(cr, ci, 0, h, inverse)
            for (y in 0 until h) { re[y * w + x] = cr[y]; im[y * w + x] = ci[y] }
        }
        if (inverse) {
            val s = 1f / (w.toFloat() * h)
            for (i in re.indices) { re[i] *= s; im[i] *= s }
        }
    }
}
