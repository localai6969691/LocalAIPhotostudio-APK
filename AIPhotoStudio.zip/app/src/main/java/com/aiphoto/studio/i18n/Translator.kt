package com.aiphoto.studio.i18n

/**
 * Tra cứu bản dịch (R33). KHÓA là chính chuỗi tiếng Việt nguồn; khóa có chỗ trống `{0}`, `{1}`… là MẪU cho chuỗi có nội suy
 * (`"Credits còn lại: ${st.credits}"` ⇒ khóa `Credits còn lại: {0}`); phần khớp vào chỗ trống được dịch tiếp nếu là một khóa nguyên văn. Thứ tự thử: khớp CHÍNH XÁC → khớp MẪU → không có bản dịch (null).
 * Thuần Kotlin (không Android) nên kiểm thử được trên JVM; bản port Python tương đương ở tools/verify_ports/i18n_translator.py.
 */
class Translator(entries: Map<String, String>) {
    private class Tmpl(val regex: Regex, val out: String, val fixedLen: Int)

    private val exact = HashMap<String, String>()
    private val templates = ArrayList<Tmpl>()

    // bộ nhớ đệm LRU cho kết quả khớp mẫu (cả "không có"): Text() gọi lại mỗi lần vẽ lại
    private val cache = object : LinkedHashMap<String, String?>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String?>?): Boolean = size > CACHE_MAX
    }

    val size: Int get() = exact.size + templates.size

    init {
        for ((k, v) in entries) {
            if (v.isEmpty()) continue
            if (PLACEHOLDER.containsMatchIn(k)) {
                val b = StringBuilder("^")
                var last = 0
                var fixed = 0
                for (m in PLACEHOLDER.findAll(k)) {
                    val lit = k.substring(last, m.range.first)
                    b.append(Regex.escape(lit)).append("(.+?)")
                    fixed += lit.length
                    last = m.range.last + 1
                }
                val tail = k.substring(last)
                b.append(Regex.escape(tail)).append("$")
                fixed += tail.length
                templates.add(Tmpl(Regex(b.toString(), RegexOption.DOT_MATCHES_ALL), v, fixed))
            } else {
                exact[k] = v
            }
        }
        // mẫu có nhiều chữ cố định thử trước: mẫu ngắn kiểu "{0} lớp" không được nuốt mẫu cụ thể hơn
        templates.sortByDescending { it.fixedLen }
    }

    /** Bản dịch của [s] hoặc null nếu chưa có. */
    fun lookup(s: String): String? {
        if (s.isEmpty() || s.length > MAX_LEN) return null
        exact[s]?.let { return it }
        if (templates.isEmpty()) return null
        synchronized(cache) {
            if (cache.containsKey(s)) return cache[s]
        }
        var result: String? = null
        for (t in templates) {
            val m = t.regex.matchEntire(s) ?: continue
            result = PLACEHOLDER.replace(t.out) { p ->
                val idx = p.groupValues[1].toInt()
                // phần chữ nằm trong chỗ trống cũng được dịch nếu là một khóa nguyên văn (ví dụ "Nhuộm {0}" với {0} = "Nâu"); số, tên riêng thì giữ nguyên
                if (idx + 1 < m.groupValues.size) m.groupValues[idx + 1].let { cap -> exact[cap] ?: cap } else p.value
            }
            break
        }
        synchronized(cache) { cache[s] = result }
        return result
    }

    fun translate(s: String): String = lookup(s) ?: s

    companion object {
        private val PLACEHOLDER = Regex("\\{(\\d+)\\}")
        private const val MAX_LEN = 400
        private const val CACHE_MAX = 512
    }
}
