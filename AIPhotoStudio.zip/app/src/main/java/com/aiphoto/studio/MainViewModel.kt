package com.aiphoto.studio

import com.aiphoto.studio.ai.normalizeScoped
import com.aiphoto.studio.ai.sanitized
import com.aiphoto.studio.ai.mergeOps
import com.aiphoto.studio.ai.EditPlan
import com.aiphoto.studio.ai.PlanJson
import com.aiphoto.studio.engine.Monetization
import com.aiphoto.studio.engine.Watermark
import com.aiphoto.studio.billing.accountHash
import com.aiphoto.studio.billing.PlayBillingFactory
import com.aiphoto.studio.billing.BillingProduct
import com.aiphoto.studio.billing.BillingGateway
import com.aiphoto.studio.billing.BillingEvent
import com.aiphoto.studio.billing.BILLING_PRODUCTS
import com.aiphoto.studio.billing.BILLING_SUBSCRIPTIONS
import android.app.Activity
import com.aiphoto.studio.engine.MaskMath
import com.aiphoto.studio.engine.MeshWarp
import com.aiphoto.studio.engine.FaceLiquify
import com.aiphoto.studio.engine.HairSegmenterEngine
import com.aiphoto.studio.engine.HairVolume
import com.aiphoto.studio.engine.HeadPose
import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiphoto.studio.ai.EditOp
import com.aiphoto.studio.ai.BackgroundScene
import com.aiphoto.studio.ai.GenIntent
import com.aiphoto.studio.ai.ProtectIntent
import com.aiphoto.studio.ai.StrangerIntent
import com.aiphoto.studio.ai.GenKind
import com.aiphoto.studio.ai.LlmBackends
import com.aiphoto.studio.ai.LlmPlanner
import com.aiphoto.studio.ai.OpType
import com.aiphoto.studio.ai.PromptPlanner
import com.aiphoto.studio.ai.Scope
import com.aiphoto.studio.ai.ScopedOps
import com.aiphoto.studio.ai.Refine
import com.aiphoto.studio.doc.AdjustmentLayer
import com.aiphoto.studio.doc.BlendMode
import com.aiphoto.studio.doc.Compositor
import com.aiphoto.studio.doc.DocState
import com.aiphoto.studio.doc.Layer
import com.aiphoto.studio.doc.LayerMask
import com.aiphoto.studio.doc.Layers
import com.aiphoto.studio.doc.Looks
import com.aiphoto.studio.doc.MaskSpec
import com.aiphoto.studio.doc.HistoryLabels
import com.aiphoto.studio.doc.OverlayLayer
import com.aiphoto.studio.doc.PatchLayer
import com.aiphoto.studio.doc.MaskRenderer
import com.aiphoto.studio.doc.RecipeCodec
import com.aiphoto.studio.doc.RecipeStore
import com.aiphoto.studio.doc.ProjectStore
import com.aiphoto.studio.doc.RenderCache
import com.aiphoto.studio.engine.ClassicInpaint
import com.aiphoto.studio.engine.InpaintComplexity
import com.aiphoto.studio.engine.BackgroundSwap
import com.aiphoto.studio.engine.Outpaint
import com.aiphoto.studio.engine.AutoFrame
import com.aiphoto.studio.engine.Moire
import com.aiphoto.studio.engine.BestTake
import com.aiphoto.studio.engine.Reframe
import com.aiphoto.studio.engine.SkyFx
import com.aiphoto.studio.engine.Sketch
import com.aiphoto.studio.ai.WholeEditIntent
import com.aiphoto.studio.routing.Tier
import com.aiphoto.studio.engine.MoveObject
import com.aiphoto.studio.ai.AutoFrameIntent
import com.aiphoto.studio.engine.StrangerMask
import com.aiphoto.studio.engine.PatchMatchInpaint
import com.aiphoto.studio.engine.PersonDetectorEngine
import com.aiphoto.studio.engine.TeamInfo
import com.aiphoto.studio.engine.TeamText
import com.aiphoto.studio.engine.SplitTone
import com.aiphoto.studio.engine.Adaptive
import com.aiphoto.studio.engine.CubeLut
import com.aiphoto.studio.engine.DepthEstimator
import com.aiphoto.studio.engine.DepthProfile
import com.aiphoto.studio.engine.PolygonEdit
import com.aiphoto.studio.engine.PolygonFill
import com.aiphoto.studio.engine.QuickSelect
import com.aiphoto.studio.engine.SkyStore
import com.aiphoto.studio.engine.LutStore
import com.aiphoto.studio.engine.FaceGeometry
import com.aiphoto.studio.engine.FaceLandmarkerEngine
import com.aiphoto.studio.engine.MagicWand
import com.aiphoto.studio.engine.SegProfile
import com.aiphoto.studio.engine.SelectiveColor
import com.aiphoto.studio.engine.readPixels
import com.aiphoto.studio.util.SecretStore
import com.aiphoto.studio.util.CrashStore
import com.aiphoto.studio.util.DiagAndroid
import com.aiphoto.studio.util.DiagLog
import com.aiphoto.studio.util.DiagReport
import com.aiphoto.studio.engine.CloneTool
import com.aiphoto.studio.engine.GeminiImageBackend
import com.aiphoto.studio.engine.GenProvider
import com.aiphoto.studio.engine.GenOptions
import com.aiphoto.studio.engine.GenQuality
import com.aiphoto.studio.engine.GenerativeFill
import com.aiphoto.studio.engine.ImageEngine
import com.aiphoto.studio.engine.LocalSdBackend
import com.aiphoto.studio.engine.LocalSdServer
import com.aiphoto.studio.engine.MiganInpainter
import com.aiphoto.studio.engine.ModelPool
import com.aiphoto.studio.engine.OnnxUpscaler
import com.aiphoto.studio.engine.OrtTuning
import com.aiphoto.studio.engine.PerfCalibrator
import com.aiphoto.studio.engine.ProxyBackend
import com.aiphoto.studio.engine.SamSegmenter
import com.aiphoto.studio.engine.Segmenter
import com.aiphoto.studio.engine.makeBitmap
import com.aiphoto.studio.engine.ImageStats
import com.aiphoto.studio.engine.Inpainter
import com.aiphoto.studio.engine.LamaInpainter
import com.aiphoto.studio.engine.MaskBuilder
import com.aiphoto.studio.engine.OnnxSegmenter
import com.aiphoto.studio.engine.Pt
import com.aiphoto.studio.engine.SdWebUiBackend
import com.aiphoto.studio.engine.TiledInpaint
import com.aiphoto.studio.engine.ToneOps
import com.aiphoto.studio.engine.MemoryLedger
import com.aiphoto.studio.integrity.IntegrityGatewayFactory
import com.aiphoto.studio.integrity.IntegrityCoordinator
import com.aiphoto.studio.engine.ModelMemory
import com.aiphoto.studio.routing.DeviceInfo
import com.aiphoto.studio.routing.PerfMeasure
import com.aiphoto.studio.routing.PerfModel
import com.aiphoto.studio.routing.PerfProfile
import com.aiphoto.studio.routing.ProviderSpec
import com.aiphoto.studio.routing.Routing
import com.aiphoto.studio.routing.RoutingConfig
import com.aiphoto.studio.util.ImageIO
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

enum class Panel { NONE, AI, TOOLS, LOOKS, CROP, LAYERS }
enum class PaintMode { OFF, SELECT, TAP, REVEAL, HIDE, CLONE, LIQUIFY, WARP, PATCH, QUICK, LASSO, POLY_EDIT, SKETCH }
data class ChatMsg(val fromUser: Boolean, val text: String)

/** Một phiên làm việc đã lưu: mã ngăn + dòng mô tả để hiện cho người dùng. */
data class SavedProjectItem(val id: String, val text: String)

data class UiState(
    val before: Bitmap? = null,            // ảnh nền (bản thu nhỏ để xem)
    val preview: Bitmap? = null,           // kết quả ghép các lớp (null = chưa có lớp nào)
    val layers: List<Layer> = emptyList(),
    val activeId: Long? = null,
    val panel: Panel = Panel.NONE,
    val paintMode: PaintMode = PaintMode.OFF,
    val strokes: List<List<Pt>> = emptyList(),
    /** R26: màu từng nét (chỉ có nghĩa ở PaintMode.SKETCH; có thể lệch độ dài so với strokes — dùng Sketch.alignColors) và màu đang chọn. */
    val strokeColors: List<Int> = emptyList(),
    val sketchColor: Int = Sketch.DEFAULT_COLOR,
    /** R28 Best Take: các ảnh phụ (cùng cảnh, chụp liên tiếp) để chọn khuôn mặt đẹp nhất; chỉ giữ Uri, ảnh được giải mã khi chạy. */
    val bestTakeUris: List<Uri> = emptyList(),
    /** R29 Reframe 2.5D: góc xoay ngang / dọc (−1..1, 0 = giữ nguyên) và hệ số độ sâu (0..2) của các thanh trượt; chỉ chạy khi bấm "Áp dụng góc nhìn". */
    val reframeX: Float = 0f,
    val reframeY: Float = 0f,
    val reframeGain: Float = 1f,
    val brush: Float = 0.03f,
    val genKind: GenKind? = null,          // != null: có kết quả xóa/thêm vật thể đang chờ áp dụng
    val chat: List<ChatMsg> = emptyList(),
    val prompt: String = "",
    val busy: Boolean = false,
    val status: String = "Chọn một ảnh để bắt đầu.",
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val llmReady: Boolean = false,
    val llmLoading: Boolean = false,
    /** Bộ tăng tốc LLM cục bộ đang chạy thực tế (NPU / GPU / CPU / MediaPipe); rỗng nếu chưa nạp. */
    val llmBackend: String = "",
    val segReady: Boolean = false,
    val lamaReady: Boolean = false,
    val genProvider: GenProvider = GenProvider.CLOUD_GEMINI,
    val cloudKey: String = "",
    val cloudModel: String = GeminiImageBackend.DEFAULT_MODEL,
    val sdUrl: String = "",
    val sdSize: Int = 512,
    val serverInfo: String = "",
    val miganReady: Boolean = false,
    val sdLocalBinary: Boolean = false,
    val sdLocalModel: Boolean = false,
    val esrganReady: Boolean = false,
    val samReady: Boolean = false,
    val selection: Bitmap? = null,         // lớp phủ vùng đã chạm chọn (thu nhỏ)
    val tapPoints: List<Pt> = emptyList(),
    val proxyUrl: String = "",
    val proxyToken: String = "",
    val credits: Int? = null,
    /** R23 dùng thử miễn phí: số lượt AI đã dùng trên máy chủ trong 24 giờ qua (-1 = chưa biết) và trần ngày (0 = không giới hạn). */
    val betaUsedToday: Int = -1,
    val betaDailyLimit: Int = 0,
    /** R23: máy chủ có cung cấp AI đám mây bằng khóa của chủ app không (mặc định có; bản dùng thử mặc định KHÔNG: tester dùng khóa của mình / model trên máy). */
    val serverAiOk: Boolean = true,
    /** R24 báo lỗi cho tester: nội dung báo cáo đang xem trước (null = không hiện hộp thoại), tiêu đề, lời giải thích, và có kèm lỗi đóng đột ngột chưa gửi không. */
    val diagReport: String? = null,
    val diagTitle: String = "",
    val diagHint: String = "",
    val diagCrash: Boolean = false,
    val perfInfo: String = "",
    val suggestions: List<Pair<String, String>> = emptyList(),
    val genQuality: GenQuality = GenQuality.FAST,
    /** Xóa vật thể tô tay ở chế độ CHÍNH XÁC: chỉ đổi đúng điểm đã tô (không nới, không hòa mép). Cũng bật được bằng lời: "xóa chính xác". */
    val exactRemove: Boolean = false,
    val genSeed: String = "",
    val genNegative: String = "",
    val genStrength: Float = 0f,
    val styleReady: Boolean = false,
    val cloneSource: Pt? = null,
    val cloneHeal: Boolean = true,
    val recipes: List<String> = emptyList(),
    val routingSummary: String = "",
    val routingUrl: String = "",
    val faceReady: Boolean = false,
    val personReady: Boolean = false,
    val depthReady: Boolean = false,
    val portraitReady: Boolean = false,
    val segHqReady: Boolean = false,
    val hairReady: Boolean = false,
    /** Thon hàm / to mắt / thu mũi / nâng khóe môi (0..1). */
    val faceShape: List<Float> = listOf(0f, 0f, 0f, 0f),
    /** AI Brush: chỉ nhận nét tô nằm trong vùng này (Scope.*), null = cọ thường. */
    val brushLimit: String? = null,
    val patchPick: Boolean = false,
    val favTools: Set<String> = emptySet(),
    val scrubType: OpType? = null,
    /** Gói do máy chủ quyết định: "free" | "pro" (planUntil = giây Unix). */
    val plan: String = "free",
    val planUntil: Long = 0L,
    /** R22: nhóm Team/Enterprise đang tham gia (do máy chủ báo qua /v1/account), thông báo thao tác nhóm, mã mời vừa được cấp (chỉ hiện một lần). */
    val team: TeamInfo? = null,
    val teamBusy: Boolean = false,
    val teamMessage: String = "",
    val teamInviteCode: String = "",
    /** Agent AI: gửi ảnh thu nhỏ + yêu cầu cho mô hình đa phương thức ở máy chủ để lập kế hoạch chỉnh. */
    val agentMode: Boolean = false,
    /** R30: đã chọn ảnh MẪU phong cách cho Agent AI (chỉ giữ trong bộ nhớ, không ghi ra đĩa). */
    val agentRefReady: Boolean = false,
    val billingProducts: List<BillingProduct> = emptyList(),
    val subscriptionProducts: List<BillingProduct> = emptyList(),
    /** Tên các tệp LUT .cube đã nhập (kho filesDir/luts). */
    val luts: List<String> = emptyList(),
    /** Các phiên làm việc đã tự lưu (mới nhất trước, tối đa ProjectSlots.MAX_SLOTS) — hiện danh sách "Mở lại" ở màn hình chưa mở ảnh. */
    val savedProjects: List<SavedProjectItem> = emptyList(),
    /** Dung sai Quick Selection 0..1 (cao = lan rộng hơn theo màu). */
    val quickTol: Float = 0.5f,
    /** Warp lưới / Free Transform: góc xoay tự do đang áp dụng (độ, + = theo chiều kim đồng hồ); thanh trượt "Xoay". */
    val warpAngle: Float = 0f,
    /** Tên các ảnh trời người dùng đã nhập (filesDir/skies). */
    val skies: List<String> = emptyList(),
    /** Panel Lịch sử: đang mở?, nhãn từng bước (cũ → mới, mục 0 = điểm bắt đầu), vị trí bước hiện tại. */
    val historyOpen: Boolean = false,
    val history: List<String> = emptyList(),
    val historyIndex: Int = 0
) {
    /** Pro còn hạn (planUntil là giây Unix; đã lưu trên máy nên ngoại tuyến vẫn đúng đến khi hết hạn). */
    val isPro: Boolean get() = plan == "pro" && planUntil * 1000L > System.currentTimeMillis()

    val hasImage: Boolean get() = before != null
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private companion object {
        const val POLY_HIT = 0.045f                     // bán kính chạm chọn điểm/cạnh lasso (đơn vị chiều cao ảnh)
        const val WARP_MAX_DEG = 45f                    // thanh "Xoay" của Free Transform: ±45° (MeshWarp.rotated còn tự giới hạn theo từng ảnh)
        const val LLM_FILE = "llm.task"
        const val LLM_LITERTLM_FILE = "llm.litertlm"   // R15: model LiteRT-LM (Gemma 3n / Gemma 4), chỉ chạy được khi build -PuseLiteRtLm=true
        const val SEG_FILE = "segmenter.onnx"
        const val SEG_HQ_FILE = "segmenter_hq.onnx"
        const val SEG_PORTRAIT_FILE = "segmenter_portrait.onnx"
        const val FACE_FILE = "face_landmarker.task"
        const val HAIR_FILE = "hair_segmenter.tflite"
        const val PERSON_FILE = "efficientdet_lite0.tflite"   // R21: phát hiện người (kể cả quay lưng) cho "Xóa người lạ"
        const val DEPTH_FILE = "depth.onnx"                    // R30: model đo độ sâu từ một ảnh (Depth Anything V2 Small, Apache-2.0) — tùy chọn, cho Reframe 2.5D
        const val KEY_FAV = "fav_tools"
        const val KEY_PLAN = "plan"
        const val KEY_PLAN_UNTIL = "plan_until"
        const val KEY_PERF_MS_PER_MP = "perf_ms_per_mp"   // R30g: ms / megapixel của chuỗi hiệu chuẩn (PerfCalibrator), đã gộp bằng PerfModel.blend
        const val LAMA_FILE = "lama.onnx"
        const val MIGAN_FILE = "migan.onnx"
        const val ESRGAN_FILE = "esrgan.onnx"
        const val LORA_DIR = "loras"
        const val LORA_FILE = "lcm.safetensors"
        const val SAM_ENC_FILE = "sam_encoder.onnx"
        const val SAM_DEC_FILE = "sam_decoder.onnx"
        const val KEY_PROXY_URL = "proxy_url"
        const val KEY_PROXY_TOKEN = "proxy_token"
        const val KEY_DEVICE_ID = "device_id"
        const val KEY_STYLE = "style_dna"
        const val PREFS = "ai_photo"
        const val KEY_URL = "sd_url"
        const val KEY_SIZE = "sd_size"
        const val KEY_PROVIDER = "gen_provider"
        const val KEY_CLOUD_KEY = "cloud_key"
        const val KEY_CLOUD_MODEL = "cloud_model"
        const val KEY_ROUTING_URL = "routing_url"
        const val KEY_EXIT_SEEN = "diag_exit_seen"     // R24: mốc thời gian lần kết thúc tiến trình đã báo cho người dùng
        const val OUTPAINT_PROMPT = "Extend the photo beyond its current borders. Continue the existing scene seamlessly with the same " +
            "lighting, perspective, colors, style and film grain. Keep the existing part unchanged. Do not add text, borders or frames."
        val BAKE_TYPES = setOf(
            OpType.CROP_RATIO, OpType.ROTATE, OpType.FLIP_H, OpType.FLIP_V, OpType.UPSCALE, OpType.BG_REMOVE,
            OpType.STRAIGHTEN, OpType.PERSPECTIVE, OpType.HAIR_VOLUME, OpType.OUTPAINT,
            OpType.UNBLUR, OpType.MOIRE     // R25: nặng (FFT / Richardson–Lucy) nên áp MỘT lần vào ảnh nền thay vì mỗi lần dựng lại lớp
        )
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var bg: Bitmap? = null              // ảnh nền độ phân giải làm việc (<= 2048px), bất biến
    private var previewHi: Bitmap? = null       // bản xem trước (khi thả tay)
    private var previewLo: Bitmap? = null       // bản xem trước thấp (khi đang kéo thanh trượt) -> không giật
    @Volatile private var perf: PerfProfile = PerfProfile.from(DeviceInfo(4096, "", 30), emptyMap())
    private var selectionMask: ByteArray? = null
    private val renderCache = RenderCache()
    private val projectStore by lazy { ProjectStore(appCtx) }
    private var autosaveJob: Job? = null
    private var textEditUndoFor = -1L // lớp chữ đang gõ: chỉ đẩy MỘT bước hoàn tác cho cả đợt gõ (không phải mỗi phím)
    private val localSd by lazy { LocalSdServer(appCtx) }
    private val pool = ModelPool { perf.poolCapacity }
    private val styleMap = HashMap<String, FloatArray>() // khóa phép chỉnh -> [trung bình trượt, số lần]
    @Volatile private var renderVersion = 0
    private var pending: PatchLayer? = null     // kết quả AI chờ áp dụng
    private var idCounter = 1L
    private val undoStack = ArrayDeque<DocState>()
    private val redoStack = ArrayDeque<DocState>()
    private var editOpen = false
    private var renderJob: Job? = null
    @Volatile private var renderQueued = false

    @Volatile private var llm: LlmPlanner? = null
    @Volatile private var segmenter: OnnxSegmenter? = null
    @Volatile private var lama: LamaInpainter? = null
    @Volatile private var migan: MiganInpainter? = null
    @Volatile private var esrgan: OnnxUpscaler? = null
    @Volatile private var sam: SamSegmenter? = null
    @Volatile private var face: FaceLandmarkerEngine? = null
    @Volatile private var hair: HairSegmenterEngine? = null
    @Volatile private var person: PersonDetectorEngine? = null
    @Volatile private var depthEst: DepthEstimator? = null
    @Volatile private var agentRef: Bitmap? = null
    @Volatile private var portraitSeg: OnnxSegmenter? = null
    private var segChoice: Pair<Bitmap, Segmenter?>? = null
    private var faceCache: Pair<Bitmap, FaceGeometry.Parts?>? = null
    private var faceLmCache: Pair<Bitmap, List<FloatArray>>? = null
    private var hairCache: Pair<Bitmap, ByteArray?>? = null
    private var faceShapeJob: Job? = null
    private var warpNode = -1
    private var polyNode = -1                          // điểm lasso đang kéo (POLY_EDIT)
    private var warpRotBase: MeshWarp.Mesh? = null   // lưới lúc bắt đầu một lần kéo thanh "Xoay" (xoay từ gốc, không cộng dồn sai số mã hóa)
    private var warpRotBaseAngle = 0f
    private var billing: BillingGateway? = null
    private val scrubOrder = listOf(OpType.BRIGHTNESS, OpType.CONTRAST, OpType.SATURATION, OpType.WARMTH, OpType.CLARITY, OpType.SHARPEN, OpType.VIGNETTE, OpType.HUE)
    @Volatile private var activeBackend: GenerativeFill? = null
    @Volatile private var cancelled = false

    private var routing: RoutingConfig = RoutingConfig(1, emptyMap())
    private val recipeStore by lazy { RecipeStore(appCtx) }
    private val device by lazy { DeviceInfo.read(appCtx) }
    private val crashStore by lazy { CrashStore.at(appCtx.filesDir) }
    private val recentPrompts = ArrayDeque<String>()

    private val appCtx: Application get() = getApplication()
    private val modelDir: File get() = File(appCtx.filesDir, "models").apply { mkdirs() }
    private val prefs get() = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Bí mật (khóa API, token) lưu mã hóa bằng Android Keystore; giá trị cũ dạng chữ thường được tự chuyển sang dạng mã hóa. */
    private fun getSecret(key: String): String {
        val raw = prefs.getString(key, "").orEmpty()
        if (raw.isNotEmpty() && !SecretStore.isEncrypted(raw)) {
            val enc = SecretStore.encrypt(raw)
            if (enc != raw) prefs.edit().putString(key, enc).apply()
            return raw
        }
        return SecretStore.decrypt(raw)
    }

    private fun putSecret(key: String, value: String) {
        prefs.edit().putString(key, SecretStore.encrypt(value)).apply()
    }

    private fun ui(block: UiState.() -> UiState) {
        var before = ""
        var after = ""
        _state.update { cur -> before = cur.status; val n = cur.block(); after = n.status; n }
        if (after != before) DiagLog.add("trạng thái", after)   // nhật ký báo lỗi (R24): mọi thay đổi trạng thái hiện cho người dùng
    }

    // ---- R32: tầng bằng chứng cho RAM nạp model (số đo thật + dấu bị giết lúc nạp), cộng thêm ngưỡng tay `minRamMb`; chi tiết ở engine/ModelMemory.kt ----
    private val memLedger by lazy {
        MemoryLedger(object : MemoryLedger.Store {
            // commit() (đồng bộ) để dấu "đang nạp" còn trên đĩa nếu tiến trình bị giết ngay sau đó; việc nạp model chạy ở luồng nền
            override fun getInt(key: String, def: Int): Int = prefs.getInt(key, def)
            override fun putInt(key: String, value: Int) { prefs.edit().putInt(key, value).commit() }
            override fun getString(key: String, def: String): String = prefs.getString(key, def) ?: def
            override fun putString(key: String, value: String) { prefs.edit().putString(key, value).commit() }
        })
    }

    /** PSS của tiến trình (MB) — mọi trang đang dùng thật, kể cả trọng số model được ánh xạ bộ nhớ. */
    private fun pssMb(): Int = runCatching {
        val mi = android.os.Debug.MemoryInfo()
        android.os.Debug.getMemoryInfo(mi)
        mi.totalPss / 1024
    }.getOrDefault(0)

    /** Nạp model có ghi dấu chống chết giữa chừng + đo mức tăng PSS để lần sau ước lượng bằng số đo thật. [id] = id nhà cung cấp trong định tuyến. */
    private fun <T> trackLoad(id: String, load: () -> T): T {
        memLedger.beginLoad(id)
        val before = pssMb()
        val r = try { load() } catch (t: Throwable) { memLedger.abortLoad(); throw t }
        memLedger.endLoad(id, (pssMb() - before).coerceAtLeast(0))
        return r
    }

    private fun fileForToken(token: String): File? {
        val f: File? = when (token) {
            "file:llm.task" -> llmFile()
            "file:segmenter.onnx" -> File(modelDir, SEG_FILE)
            "file:segmenter_hq.onnx" -> File(modelDir, SEG_HQ_FILE)
            "file:face_landmarker.task" -> File(modelDir, FACE_FILE)
            "file:efficientdet_lite0.tflite" -> File(modelDir, PERSON_FILE)
            "file:depth.onnx" -> File(modelDir, DEPTH_FILE)
            "file:segmenter_portrait.onnx" -> File(modelDir, SEG_PORTRAIT_FILE)
            "file:lama.onnx" -> File(modelDir, LAMA_FILE)
            "file:migan.onnx" -> File(modelDir, MIGAN_FILE)
            "file:esrgan.onnx" -> File(modelDir, ESRGAN_FILE)
            "file:sd_inpaint", "file:sd_klein" -> sdModelFile(token.removePrefix("file:"))
            else -> null
        }
        return f?.takeIf { it.exists() }
    }

    private fun providerLoaded(id: String): Boolean = when (id) {
        "gemma" -> llm != null
        "lama" -> lama != null
        "migan" -> migan != null
        "isnet", "u2net" -> segmenter != null
        else -> false
    }

    /**
     * Tầng bằng chứng (R32) cộng thêm ngưỡng tay `minRamMb` của [Routing.chain]: chặn khi số đo thật hoặc dấu "app bị giết lúc nạp" cho thấy RAM trống chưa đủ.
     * Model ĐÃ nạp thì không kiểm lại (RAM của nó đã bị tính vào mức "đã dùng"); chưa có bằng chứng thì không chặn thêm.
     */
    private fun memoryFits(p: ProviderSpec): Boolean {
        if (providerLoaded(p.id)) return true
        val files = p.needs.filter { it.startsWith("file:") }.mapNotNull { fileForToken(it) }
        if (files.isEmpty()) return true            // không nạp tệp nào (đám mây, luật, PatchMatch…)
        val fileMb = files.sumOf { it.length() } / (1024L * 1024L)
        val est = ModelMemory.estimateMb(fileMb, memLedger.learnedMb(p.id), memLedger.kills(p.id))
        return ModelMemory.fits(est, availMemMb().toLong(), device.ramMb)
    }

    private fun newId(): Long = idCounter++

    init {
        DiagLog.add("khởi động", "mở app")
        memLedger.recoverAfterCrash()                 // R32: lần trước chết giữa lúc nạp model nào thì ghi nhận để ước lượng thận trọng hơn
        Routing.memoryGuard = { p -> memoryFits(p) }
        // R32: chứng thực Play Integrity khi máy chủ đòi (403 integrity_required). Bản stub: cổng không khả dụng ⇒ móc trả false, mọi thứ chạy như trước.
        val integrityGateway = IntegrityGatewayFactory.create(appCtx)
        if (integrityGateway.available) {
            val coordinator = IntegrityCoordinator()
            ProxyBackend.integrityHook = { base, token ->
                coordinator.ensure { ProxyBackend.attest(base, token, integrityGateway) }
            }
        }
        val provider = runCatching {
            GenProvider.valueOf(prefs.getString(KEY_PROVIDER, GenProvider.CLOUD_GEMINI.name).orEmpty())
        }.getOrDefault(GenProvider.CLOUD_GEMINI)
        ui {
            copy(
                sdUrl = prefs.getString(KEY_URL, "").orEmpty(),
                sdSize = prefs.getInt(KEY_SIZE, 512),
                genProvider = provider,
                cloudKey = getSecret(KEY_CLOUD_KEY),
                cloudModel = prefs.getString(KEY_CLOUD_MODEL, GeminiImageBackend.DEFAULT_MODEL).orEmpty(),
                routingUrl = prefs.getString(KEY_ROUTING_URL, "").orEmpty(),
                proxyUrl = prefs.getString(KEY_PROXY_URL, "").orEmpty(),
                proxyToken = getSecret(KEY_PROXY_TOKEN),
                plan = prefs.getString(KEY_PLAN, "free").orEmpty().ifBlank { "free" },
                planUntil = prefs.getLong(KEY_PLAN_UNTIL, 0L)
            )
        }
        routing = runCatching { Routing.load(appCtx) }.getOrDefault(routing)
        perf = computePerf()
        applyPerf()
        DiagLog.add("máy", perf.describe())
        viewModelScope.launch(Dispatchers.Default) { calibratePerf() }   // R30g: đo tốc độ THẬT của máy (một lần, nền) rồi suy hồ sơ hiệu năng từ số đo thay cho bảng theo RAM
        loadStyle()
        LutStore.dir = File(appCtx.filesDir, "luts")
        SkyStore.dir = File(appCtx.filesDir, "skies")
        viewModelScope.launch(Dispatchers.IO) { checkLastExit() }   // R24: lần trước app đóng đột ngột / bị hệ thống tắt thì báo ngay để tester gửi lỗi
        viewModelScope.launch(Dispatchers.IO) {
            restoreModels()
            refreshRecipes()
            refreshLuts()
            refreshSkies()
            refreshSavedProject()
            refreshRoutingSummary()
            refreshCredits()   // cập nhật gói Free/Pro + credits từ máy chủ ngay khi mở app (lỗi mạng thì dùng gói đã lưu)
        }
    }

    // ------------------------------------------------------------------ định tuyến
    private fun available(token: String): Boolean {
        val st = _state.value
        return when (token) {
            "net" -> true
            "key:cloud" -> st.cloudKey.isNotBlank()
            "url:sd" -> st.sdUrl.isNotBlank()
            "file:llm.task" -> llmFile() != null      // "LLM cục bộ": .task (MediaPipe) HOẶC .litertlm (LiteRT-LM)
            "file:segmenter.onnx" -> File(modelDir, SEG_FILE).exists()
            "file:segmenter_hq.onnx" -> File(modelDir, SEG_HQ_FILE).exists()
            "file:face_landmarker.task" -> File(modelDir, FACE_FILE).exists()
            "file:efficientdet_lite0.tflite" -> File(modelDir, PERSON_FILE).exists()
            "file:depth.onnx" -> File(modelDir, DEPTH_FILE).exists()
            "file:segmenter_portrait.onnx" -> File(modelDir, SEG_PORTRAIT_FILE).exists()
            "file:lama.onnx" -> File(modelDir, LAMA_FILE).exists()
            "file:migan.onnx" -> File(modelDir, MIGAN_FILE).exists()
            "file:esrgan.onnx" -> File(modelDir, ESRGAN_FILE).exists()
            "bin:sdserver" -> localSd.binaryPresent()
            "file:sd_inpaint", "file:sd_klein" -> sdModelFile(token.removePrefix("file:")) != null
            "token:proxy" -> Monetization.proxyAiUsable(st.proxyUrl, st.proxyToken, st.serverAiOk)
            else -> false
        }
    }

    // ---- nạp lười + hồ model: model nặng chỉ vào RAM khi cần, vượt sức chứa theo hạng máy thì giải phóng cái ít dùng nhất ----
    private fun touch(name: String) {
        when (name) {
            "llm" -> pool.register("llm", 2) { llm?.close(); llm = null }
            "lama" -> pool.register("lama", 1) { lama?.close(); lama = null }
            "migan" -> pool.register("migan", 1) { migan?.close(); migan = null }
            "sam" -> pool.register("sam", 1) { sam?.close(); sam = null }
            "face" -> pool.register("face", 1) { face?.close(); face = null; faceCache = null; faceLmCache = null }
            "hair" -> pool.register("hair", 1) { hair?.close(); hair = null; hairCache = null }
            "person" -> pool.register("person", 1) { person?.close(); person = null }
            "depth" -> pool.register("depth", 1) { depthEst?.close(); depthEst = null }
            "portrait" -> pool.register("portrait", 1) { portraitSeg?.close(); portraitSeg = null; segChoice = null }
            "sdlocal" -> pool.register("sdlocal", 4) { localSd.stop() }
        }
    }

    /** Tệp LLM cục bộ đang có: ưu tiên .litertlm (đa phương thức, GPU) rồi tới .task (MediaPipe, chỉ văn bản). */
    private fun llmFile(): File? =
        listOf(LLM_LITERTLM_FILE, LLM_FILE).map { File(modelDir, it) }.firstOrNull { it.exists() }

    @Synchronized
    private fun ensureLlm(): LlmPlanner? {
        llm?.let { touch("llm"); return it }
        val f = llmFile() ?: return null
        val m = trackLoad("gemma") { LlmPlanner(appCtx, f.absolutePath) }
        llm = m
        touch("llm")
        ui { copy(llmBackend = m.backendName) }
        return m
    }

    @Synchronized
    private fun ensureLama(): LamaInpainter? {
        lama?.let { touch("lama"); return it }
        val f = File(modelDir, LAMA_FILE)
        if (!f.exists()) return null
        val m = trackLoad("lama") { LamaInpainter(f.absolutePath) }
        lama = m
        touch("lama")
        return m
    }

    @Synchronized
    private fun ensureMigan(): MiganInpainter? {
        migan?.let { touch("migan"); return it }
        val f = File(modelDir, MIGAN_FILE)
        if (!f.exists()) return null
        val m = trackLoad("migan") { MiganInpainter(f.absolutePath) }
        migan = m
        touch("migan")
        return m
    }

    @Synchronized
    private fun ensureEsrgan(): OnnxUpscaler? {
        esrgan?.let { return it }
        val f = File(modelDir, ESRGAN_FILE)
        if (!f.exists()) return null
        val m = OnnxUpscaler(f.absolutePath)
        esrgan = m
        return m
    }

    @Synchronized
    private fun ensureFace(): FaceLandmarkerEngine? {
        // theo định tuyến "face_landmarks" nếu cấu hình có khai báo (máy chủ có thể tắt/đổi); cấu hình cũ chưa có task này thì vẫn dùng
        if (routing.tasks.containsKey("face_landmarks") && chain("face_landmarks").none { it.kind == "mp_face_landmarker" }) return null
        face?.let { touch("face"); return it }
        val f = File(modelDir, FACE_FILE)
        if (!f.exists()) return null
        val m = FaceLandmarkerEngine(appCtx, f.absolutePath)
        face = m
        touch("face")
        return m
    }

    /** Nhận diện khuôn mặt (MediaPipe Face Landmarker) trên ảnh nền và dựng mặt nạ các vùng; nhớ kết quả theo ảnh nền hiện tại. */
    private fun faceParts(bgFull: Bitmap): FaceGeometry.Parts? {
        faceCache?.let { if (it.first === bgFull) return it.second }
        val engine = ensureFace() ?: return null
        val faces = engine.detect(bgFull)
        faceLmCache = Pair(bgFull, faces)
        val parts = if (faces.isEmpty()) null else FaceGeometry.parts(faces, bgFull.width, bgFull.height)
        faceCache = Pair(bgFull, parts)
        return parts
    }

    /** Điểm mốc 478 điểm của mọi khuôn mặt trên ảnh nền (nhớ theo ảnh nền, dùng chung với [faceParts]). Gọi trên luồng nền. */
    private fun faceLandmarks(bgFull: Bitmap): List<FloatArray>? {
        faceLmCache?.let { if (it.first === bgFull) return it.second }
        val engine = ensureFace() ?: return null
        val faces = engine.detect(bgFull)
        faceLmCache = Pair(bgFull, faces)
        return faces
    }

    @Synchronized
    private fun ensureHair(): HairSegmenterEngine? {
        hair?.let { touch("hair"); return it }
        // theo định tuyến "hair_segment" nếu cấu hình có khai báo; cấu hình cũ chưa có task này thì vẫn dùng
        if (routing.tasks.containsKey("hair_segment") && chain("hair_segment").none { it.kind == "mp_hair_segmenter" }) return null
        val f = File(modelDir, HAIR_FILE)
        if (!f.exists()) return null
        val m = HairSegmenterEngine(appCtx, f.absolutePath)
        hair = m
        touch("hair")
        return m
    }

    @Synchronized
    private fun ensurePerson(): PersonDetectorEngine? {
        person?.let { touch("person"); return it }
        // theo định tuyến "person_detect" nếu cấu hình có khai báo; cấu hình cũ chưa có task này thì vẫn dùng
        if (routing.tasks.containsKey("person_detect") && chain("person_detect").none { it.kind == "mp_person_detector" }) return null
        val f = File(modelDir, PERSON_FILE)
        if (!f.exists()) return null
        val m = PersonDetectorEngine(appCtx, f.absolutePath)
        person = m
        touch("person")
        return m
    }

    /** Model đo độ sâu (R30, tùy chọn): theo định tuyến "depth_estimate" nếu cấu hình có khai báo; cấu hình cũ chưa có task này thì vẫn dùng. Không có tệp ⇒ null. */
    @Synchronized
    private fun ensureDepth(): DepthEstimator? {
        depthEst?.let { touch("depth"); return it }
        if (routing.tasks.containsKey("depth_estimate") && chain("depth_estimate").none { it.kind == "depth_onnx" }) return null
        val f = File(modelDir, DEPTH_FILE)
        if (!f.exists()) return null
        val m = DepthEstimator(f.absolutePath)
        depthEst = m
        touch("depth")
        return m
    }

    /**
     * Đo độ sâu với cạnh vào THÍCH NGHI (R30f): `edge` của định tuyến chỉ là TRẦN (và `budget_ms` là ngân sách thời gian, mặc định [Adaptive.DEFAULT_BUDGET_MS]); cạnh thật được học
     * từ thời gian chạy thực tế của chính máy này ([Adaptive.nextEdge]) và nhớ giữa các lần mở app, khóa theo (kích thước tệp model, bộ tăng tốc, số luồng). Hết bộ nhớ thì thu nhỏ rồi thử lại
     * ([Adaptive.afterFailure]); lỗi khác thì trả null (Reframe quay về độ sâu giả). Lần chạy đầu của phiên không bị dùng để học (có thể gồm biên dịch).
     */
    private fun estimateDepthAdaptive(m: DepthEstimator, bmp: Bitmap): Reframe.Field? {
        val params = chain("depth_estimate").firstOrNull()?.params
        val patch = DepthProfile.PATCH
        val maxEdge = (params?.get("edge")?.toIntOrNull() ?: DepthProfile.LONG_EDGE).coerceIn(patch * Adaptive.MIN_PATCHES, patch * 56)
        val minEdge = patch * Adaptive.MIN_PATCHES
        val budget = params?.get("budget_ms")?.toLongOrNull()?.coerceIn(500L, 60_000L) ?: Adaptive.DEFAULT_BUDGET_MS
        // khóa học theo (tệp model, bộ tăng tốc, số luồng): đổi một trong ba thì cạnh đã học không còn đúng và phải học lại
        val key = "depth_edge_" + File(modelDir, DEPTH_FILE).length() + "_" + OrtTuning.accel.joinToString("+") + "_" + OrtTuning.threads
        var edge = prefs.getInt(key, maxEdge).coerceIn(minEdge, maxEdge)
        repeat(4) {
            val cold = m.runs == 0
            val t0 = System.nanoTime()
            val r = runCatching { m.estimate(bmp, edge) }
            val ms = (System.nanoTime() - t0) / 1_000_000L
            if (r.isSuccess) {
                val learned = Adaptive.nextEdge(edge, ms, budget, minEdge, maxEdge, patch, cold)
                if (learned != edge) prefs.edit().putInt(key, learned).apply()
                return r.getOrNull()
            }
            val msg = r.exceptionOrNull()?.message.orEmpty()
            val oom = r.exceptionOrNull() is OutOfMemoryError || msg.contains("alloc", ignoreCase = true) || msg.contains("memory", ignoreCase = true)
            if (!oom) return null
            val smaller = Adaptive.afterFailure(edge, minEdge, patch)
            if (smaller >= edge) return null
            edge = smaller
            prefs.edit().putInt(key, edge).apply()
        }
        return null
    }

    /** Mặt nạ tóc 0/255 (kích thước ảnh nền) hoặc null nếu chưa nạp model / không thấy tóc. Gọi trên luồng nền. */
    private fun hairMaskFor(bgFull: Bitmap): ByteArray? {
        hairCache?.let { if (it.first === bgFull) return it.second }
        val engine = ensureHair() ?: return null
        val m = runCatching { engine.hairMask(bgFull) }.getOrNull()?.takeIf { arr -> arr.any { it.toInt() != 0 } }
        hairCache = Pair(bgFull, m)
        return m
    }

    @Synchronized
    private fun ensurePortrait(): OnnxSegmenter? {
        portraitSeg?.let { touch("portrait"); return it }
        val f = File(modelDir, SEG_PORTRAIT_FILE)
        if (!f.exists()) return null
        val m = OnnxSegmenter(f.absolutePath, SegProfile.MODNET)
        portraitSeg = m
        touch("portrait")
        return m
    }

    /** MODNet chỉ dành cho chân dung: dùng khi (đã nạp model chân dung) và thấy khuôn mặt (cần Face Landmarker để biết). */
    private fun portraitFor(b: Bitmap): Segmenter? {
        if (!File(modelDir, SEG_PORTRAIT_FILE).exists()) return null
        if (routing.tasks.containsKey("segment_portrait") && chain("segment_portrait").none { it.kind == "modnet_onnx" }) return null
        if (runCatching { faceParts(b) }.getOrNull() == null) return null
        return runCatching { ensurePortrait() }.getOrNull()
    }

    /**
     * Model tách nền cho ẢNH NỀN hiện tại: MODNet nếu là ảnh chân dung (thấy khuôn mặt), không thì model chung (IS-Net/U²-Net).
     * Nhớ theo ảnh nền để xem trước không phải dò mặt lại. GỌI TRÊN LUỒNG NỀN (có thể chạy nhận diện khuôn mặt).
     */
    private fun currentSeg(): Segmenter? {
        val b = bg ?: return segmenter
        segChoice?.let { if (it.first === b) return it.second }
        val choice: Segmenter? = portraitFor(b) ?: segmenter
        segChoice = Pair(b, choice)
        return choice
    }

    private fun scopeFeather(scope: String): Float = when (scope) {
        Scope.TEETH -> 0.006f
        Scope.EYES -> 0.01f
        Scope.DARK_CIRCLES -> 0.03f
        Scope.FACE_LIGHT, Scope.FACE_SHADOW -> 0.04f
        else -> 0.02f
    }

    /** Dựng mặt nạ cho một vùng của kế hoạch AI. Trả về null (kèm lý do trong [notes]) nếu chưa dựng được. */
    private suspend fun maskForScope(scope: String, bgFull: Bitmap, notes: MutableList<String>, segOverride: Segmenter? = null): LayerMask? {
        if (Scope.isProtect(scope)) return maskForProtect(Scope.protectedOf(scope), bgFull, notes, segOverride)
        val w = bgFull.width
        val h = bgFull.height
        return withContext(Dispatchers.Default) {
            when (scope) {
                Scope.SKY -> LayerMask(MaskSpec.Sky(0.5f), feather = 0.01f)
                Scope.SUBJECT, Scope.BACKGROUND -> {
                    val seg = segOverride ?: currentSeg()
                    if (seg == null) {
                        notes.add("Cần nạp model tách nền (.onnx) để chọn ${Scope.label(scope).lowercase()}.")
                        null
                    } else {
                        val m = seg.foregroundMask(bgFull)
                        val bytes = ByteArray(m.size) { (m[it] * 255f).toInt().coerceIn(0, 255).toByte() }
                        LayerMask(MaskSpec.Painted(bytes, w, h), invert = scope == Scope.BACKGROUND, feather = 0.01f)
                    }
                }
                Scope.HAIR -> {
                    val data = hairMaskFor(bgFull)
                    if (data == null) {
                        notes.add(
                            if (!File(modelDir, HAIR_FILE).exists()) "Cần nạp model hair_segmenter.tflite (Cài đặt) để chỉnh tóc."
                            else "Không nhận ra tóc trong ảnh."
                        )
                        null
                    } else LayerMask(MaskSpec.Painted(data, w, h), feather = 0.012f)
                }
                else -> {
                    val parts = faceParts(bgFull)
                    if (parts == null) {
                        notes.add(
                            if (!File(modelDir, FACE_FILE).exists()) "Cần nạp model face_landmarker.task (Cài đặt) để chỉnh ${Scope.label(scope).lowercase()}."
                            else "Không thấy khuôn mặt trong ảnh nên không chỉnh được ${Scope.label(scope).lowercase()}."
                        )
                        null
                    } else {
                        val data: ByteArray? = when (scope) {
                            Scope.SKIN -> parts.skin.copyOf()
                            Scope.EYES -> parts.eyes.copyOf()
                            Scope.DARK_CIRCLES -> parts.underEyes.copyOf()
                            Scope.TEETH -> FaceGeometry.teethMask(parts.mouth, readPixels(bgFull))
                            Scope.FACE_LIGHT -> FaceGeometry.tonalMask(parts.skin, readPixels(bgFull), true)
                            Scope.FACE_SHADOW -> FaceGeometry.tonalMask(parts.skin, readPixels(bgFull), false)
                            else -> null
                        }
                        if (data == null) null else LayerMask(MaskSpec.Painted(data, w, h), feather = scopeFeather(scope))
                    }
                }
            }
        }
    }

    /**
     * Mặt nạ của phần NGOÀI các vùng [scopes] ("giữ nguyên X", R27). Một vùng ⇒ đảo mặt nạ của vùng đó (giữ tính tham số của mặt nạ trời);
     * nhiều vùng ⇒ hợp các mặt nạ (max) thành mặt nạ tô tay rồi đảo. Một vùng nào không dựng được ⇒ null (lý do đã nằm trong [notes]) —
     * nơi gọi phải TỪ CHỐI thay vì chỉnh cả ảnh.
     */
    private suspend fun maskForProtect(scopes: List<String>, bgFull: Bitmap, notes: MutableList<String>, segOverride: Segmenter? = null): LayerMask? {
        if (scopes.isEmpty()) return null
        val masks = ArrayList<LayerMask>()
        for (sc in scopes) masks.add(maskForScope(sc, bgFull, notes, segOverride) ?: return null)
        if (masks.size == 1) { val m = masks[0]; return m.copy(invert = !m.invert) }
        return withContext(Dispatchers.Default) {
            val w = bgFull.width
            val h = bgFull.height
            val acc = FloatArray(w * h)
            for (m in masks) {
                val r = MaskRenderer.render(m, bgFull)
                for (i in acc.indices) if (r[i] > acc[i]) acc[i] = r[i]
            }
            val bytes = ByteArray(acc.size) { (acc[it] * 255f + 0.5f).toInt().coerceIn(0, 255).toByte() }
            LayerMask(MaskSpec.Painted(bytes, w, h), invert = true, feather = 0f)
        }
    }

    /** Mỗi nhóm phép chỉnh theo vùng của kế hoạch AI thành một lớp có mặt nạ riêng. Trả về số lớp đã tạo. */
    private suspend fun addScopedLayers(scoped: List<ScopedOps>, bgFull: Bitmap, notes: MutableList<String>): Int {
        var n = 0
        for (sc in scoped) {
            val mask = maskForScope(sc.scope, bgFull, notes) ?: continue
            val l = AdjustmentLayer(newId(), "AI: ${Scope.label(sc.scope)}", sc.ops, mask = mask, kind = "ai", scope = sc.scope)
            ui { copy(layers = layers + l, activeId = l.id) }
            n++
        }
        if (n > 0) requestRender()
        return n
    }

    private fun samFilesPresent(): Boolean =
        File(modelDir, SAM_ENC_FILE).exists() && File(modelDir, SAM_DEC_FILE).exists()

    @Synchronized
    private fun ensureSam(): SamSegmenter? {
        sam?.let { touch("sam"); return it }
        if (!samFilesPresent()) return null
        val m = SamSegmenter(File(modelDir, SAM_ENC_FILE).absolutePath, File(modelDir, SAM_DEC_FILE).absolutePath)
        sam = m
        touch("sam")
        return m
    }

    private fun genOptions(st: UiState) = GenOptions(
        st.genQuality, st.genSeed.trim().toLongOrNull() ?: -1L, st.genNegative.trim(), st.genStrength.takeIf { it > 0.01f }
    )

    private fun sdModelFile(slot: String): File? = modelDir.listFiles()?.firstOrNull { it.name.startsWith("$slot.") }

    private fun sdLocalModelFile(): File? = sdModelFile("sd_inpaint") ?: sdModelFile("sd_klein")

    private fun chain(task: String): List<ProviderSpec> =
        Routing.chain(routing, task, device, "pro") { t -> available(t) }

    /** Hồ sơ hiệu năng: đã ĐO máy thì suy từ số đo ([PerfProfile.derive]); chưa đo (lần mở đầu tiên) thì dùng bảng theo RAM làm giá trị KHỞI ĐẦU ([PerfProfile.from]). */
    private fun computePerf(): PerfProfile {
        val ms = prefs.getFloat(KEY_PERF_MS_PER_MP, 0f).toDouble()
        if (!(ms > 0.0)) return PerfProfile.from(device, routing.perf)
        return PerfProfile.derive(device, PerfMeasure(ms, displayRefreshHz(), ImageEngine.heapHeadroom(), availMemMb()), routing.perf)
    }

    private fun applyPerf() {
        Moire.capDefault = Moire.capFor(perf.tier == Tier.LOW)
        OrtTuning.threads = perf.threads
        OrtTuning.accel = perf.accel
        ui { copy(perfInfo = perf.describe()) }
    }

    /** Tần số làm tươi THẬT của màn hình (Hz) để suy ngân sách một khung hình; không đọc được thì 60. */
    private fun displayRefreshHz(): Float = runCatching {
        val dm = appCtx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        dm.getDisplay(android.view.Display.DEFAULT_DISPLAY).refreshRate
    }.getOrDefault(60f).coerceIn(30f, 240f)

    /** RAM hệ thống còn trống (MB) lúc này. */
    private fun availMemMb(): Int = runCatching {
        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        (mi.availMem / (1024 * 1024)).toInt()
    }.getOrDefault(1024)

    /** Đo tốc độ máy bằng bộ máy dựng ảnh của chính app ([PerfCalibrator]), gộp với số đã lưu rồi áp dụng; lỗi thì giữ hồ sơ hiện tại. Gọi ở luồng nền. */
    private fun calibratePerf() {
        val measured = runCatching { PerfCalibrator.measureMsPerMp() }.getOrNull() ?: return
        val merged = PerfModel.blend(prefs.getFloat(KEY_PERF_MS_PER_MP, 0f).toDouble(), measured)
        prefs.edit().putFloat(KEY_PERF_MS_PER_MP, merged.toFloat()).apply()
        perf = computePerf()
        applyPerf()
        DiagLog.add("máy", "Đã đo: %.0f ms/MP (gộp %.0f) → %s".format(measured, merged, perf.describe()))
    }

    private fun refreshRoutingSummary() {
        ui { copy(routingSummary = Routing.describe(routing, device, "pro") { t -> available(t) }) }
    }

    private fun refreshRecipes() {
        ui { copy(recipes = recipeStore.names()) }
    }

    private fun refreshLuts() {
        ui { copy(luts = LutStore.list()) }
    }

    private fun refreshSkies() {
        ui { copy(skies = SkyStore.list()) }
    }

    /** Nhập ảnh trời riêng rồi áp ngay làm trời thay thế. */
    fun importSky(uri: Uri) {
        if (bg == null) return
        launchTask("Đang nạp ảnh trời…") {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    var display = "sky.jpg"
                    appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0)?.let { display = it }
                    }
                    val bmp = ImageIO.decode(appCtx, uri, SkyStore.MAX_SIDE)
                    SkyStore.save(display, bmp)
                }.getOrNull()
            }
            refreshSkies()
            if (saved == null) {
                ui { copy(status = "Không nhập được ảnh trời (tệp hỏng hoặc không đọc được).") }
            } else {
                setOp(OpType.SKY_REPLACE, 1f, SkyStore.arg(saved))
                endEdit()
                ui { copy(status = "Đã dùng ảnh trời \"${saved.removeSuffix(".jpg")}\". Kéo \"Thay bầu trời (cường độ)\" để chỉnh.") }
            }
        }
    }

    fun deleteSky(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { SkyStore.delete(name) }
            refreshSkies()
        }
    }

    // ------------------------------------------------------------------ lớp phủ: chữ / ảnh (phơi sáng kép)
    fun addTextLayer() {
        if (bg == null) return
        pushUndo()
        val l = OverlayLayer(newId(), "Chữ", "text", text = "Nhập chữ", size = 0.10f)
        ui { copy(layers = layers + l, activeId = l.id, panel = Panel.LAYERS, status = "Đã thêm lớp chữ. Sửa nội dung, màu, cỡ và vị trí bên dưới.") }
        requestRender()
    }

    /** [doubleExposure] = true: chế độ Screen, độ mờ 70%, phủ kín khung (phơi sáng kép); false: ảnh phủ thường nửa chiều rộng. */
    fun addImageOverlay(uri: Uri, doubleExposure: Boolean) {
        if (bg == null) return
        launchTask("Đang thêm ảnh…") {
            val bmp = withContext(Dispatchers.IO) { ImageIO.decode(appCtx, uri, 1024) }
            pushUndo()
            val l = OverlayLayer(
                newId(), if (doubleExposure) "Phơi sáng kép" else "Ảnh phủ", "image", image = bmp,
                size = if (doubleExposure) 1f else 0.5f,
                blend = if (doubleExposure) BlendMode.SCREEN else BlendMode.NORMAL,
                opacity = if (doubleExposure) 0.7f else 1f
            )
            ui {
                copy(
                    layers = layers + l, activeId = l.id, panel = Panel.LAYERS,
                    status = if (doubleExposure) "Đã thêm phơi sáng kép. Chỉnh độ mờ / chế độ hòa trộn / vị trí bên dưới." else "Đã thêm ảnh phủ."
                )
            }
            requestRender()
        }
    }

    /** Sửa tham số lớp phủ (vị trí, cỡ, góc xoay, màu...) — dùng cho thanh trượt; gọi [endEdit] khi thả tay. */
    fun updateOverlay(id: Long, f: (OverlayLayer) -> OverlayLayer) {
        touchEdit()
        updateLayer(id) { if (it is OverlayLayer) OverlayLayer.clampParams(f(it)) else it }
    }

    /** Kéo / chụm / xoay trực tiếp lớp phủ trên khung ảnh (xem EditorScreen). */
    fun transformOverlay(id: Long, dx: Float, dy: Float, zoom: Float, rotationDeg: Float) {
        updateOverlay(id) { it.transformed(dx, dy, zoom, rotationDeg) }
    }

    fun setOverlayText(id: Long, text: String) {
        if (textEditUndoFor != id) {
            pushUndo()
            textEditUndoFor = id
        }
        updateLayer(id) {
            if (it is OverlayLayer) {
                val head = text.lineSequence().firstOrNull().orEmpty().take(16)
                OverlayLayer.clampParams(it.copy(text = text, name = if (head.isBlank()) "Chữ" else "Chữ: $head"))
            } else it
        }
    }

    // ------------------------------------------------------------------ phiên làm việc (tự lưu / khôi phục)
    private fun describeProject(i: com.aiphoto.studio.doc.ProjectInfo): String {
        val whenText = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(i.savedAt))
        return "${i.layerCount} lớp · ${i.w}×${i.h} · lưu $whenText"
    }

    private fun refreshSavedProject() {
        val items = runCatching { projectStore.list() }.getOrDefault(emptyList())
        ui { copy(savedProjects = items.map { SavedProjectItem(it.id, describeProject(it.info)) }) }
    }

    /** Tự lưu sau khi người dùng ngừng thao tác ~2,5 giây (không lưu khi đang kéo thanh trượt hoặc đang chạy tác vụ nặng). */
    private fun scheduleAutosave() {
        if (bg == null) return
        autosaveJob?.cancel()
        val slot = projectStore.currentSlot()   // ngăn của phiên đang làm việc LÚC LÊN LỊCH (mở ảnh khác giữa chừng thì không ghi nhầm)
        autosaveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(2500)
            var waited = 0
            while ((editOpen || _state.value.busy) && waited < 20) { delay(1000); waited++ }
            val b = bg ?: return@launch
            val layers = _state.value.layers
            val counter = idCounter
            runCatching { projectStore.save(b, layers, counter, forSlot = slot) }
        }
    }

    /** Mở lại một phiên làm việc đã tự lưu ([id] = mã ngăn): ảnh nền + toàn bộ lớp (vẫn chỉnh sửa lại được từng thông số). */
    fun restoreProject(id: String) {
        launchTask("Đang khôi phục phiên làm việc…") {
            autosaveJob?.cancel()
            val p = withContext(Dispatchers.IO) {
                runCatching { projectStore.switchTo(id) }.getOrNull() ?: return@withContext null
                projectStore.load()
            }
            if (p == null) {
                refreshSavedProject()
                ui { copy(status = "Không đọc được phiên đã lưu (tệp hỏng hoặc bị xóa).") }
                return@launchTask
            }
            undoStack.clear()
            redoStack.clear()
            pending = null
            editOpen = false
            idCounter = maxOf(idCounter, p.idCounter)
            setBackgroundOnly(p.background)
            val stats = withContext(Dispatchers.Default) { ImageStats.compute(p.background) }
            ui {
                copy(
                    suggestions = ImageStats.suggestions(stats),
                    layers = p.layers, activeId = null, strokes = emptyList(), genKind = null,
                    paintMode = PaintMode.OFF, canUndo = false, canRedo = false, chat = emptyList(),
                    panel = Panel.LAYERS,
                    status = "Đã khôi phục ${p.layers.size} lớp" + if (p.skipped > 0) " (bỏ qua ${p.skipped} lớp hỏng)." else "."
                )
            }
            requestRender()
        }
    }

    fun discardProject(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { projectStore.delete(id) }
            refreshSavedProject()
        }
    }

    /** Xuất ảnh rồi mở bảng chia sẻ của hệ thống (cần Android 10+; bản cũ hơn chỉ lưu và báo đường dẫn). */
    fun saveAndShare() {
        val bgFull = bg ?: return
        launchTask("Đang xuất ảnh để chia sẻ…") {
            val stack = _state.value.layers + listOfNotNull(pending)
            val notes = ArrayList<String>()
            val (where, uri, png) = withContext(Dispatchers.Default) {
                val rendered = Compositor.render(bgFull, stack, bgFull.width, currentSeg(), false, notes)
                val st = _state.value
                val flat = if (Monetization.needsWatermark(st.proxyUrl.isNotBlank() && st.proxyToken.isNotBlank(), st.isPro)) Watermark.apply(rendered) else rendered
                val isPng = ImageIO.hasTransparency(flat)
                val r = ImageIO.saveToGalleryUri(appCtx, flat, isPng)
                Triple(r.first, r.second, isPng)
            }
            if (uri == null) {
                ui { copy(status = "Đã lưu: $where (chia sẻ trực tiếp cần Android 10 trở lên).") }
            } else {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = if (png) "image/png" else "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(send, "Chia sẻ ảnh").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { appCtx.startActivity(chooser) }
                ui { copy(status = "Đã lưu: $where") }
            }
        }
    }

    // ------------------------------------------------------------------ nhiệm vụ nền (1 việc nặng/lần)
    private fun launchTask(message: String, block: suspend () -> Unit) {
        if (_state.value.busy) return
        cancelled = false
        DiagLog.add("việc", message)
        ui { copy(busy = true, status = message) }
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                DiagLog.add("lỗi", "hết bộ nhớ khi: $message", 900)
                ui { copy(status = "Hết bộ nhớ - hãy thử vùng nhỏ hơn hoặc bớt lớp.") }
            } catch (e: Throwable) {
                DiagLog.add("lỗi", "khi: $message → ${DiagReport.formatThrowable(e, 8).replace('\n', '|')}", 900)
                val msg = if (cancelled) "Đã hủy." else "Lỗi: ${e.message ?: e.javaClass.simpleName}"
                ui { copy(status = msg) }
            } finally {
                activeBackend = null
                ui { copy(busy = false) }
            }
        }
    }

    fun cancel() {
        cancelled = true
        activeBackend?.cancel()
        ui { copy(status = "Đang hủy…") }
    }

    // ------------------------------------------------------------------ báo lỗi cho tester (R24)
    /** Gom dữ kiện (không có ảnh, khóa AI, token) và ghép báo cáo; khóa/email/đường dẫn ảnh còn lọt vào văn bản sẽ bị DiagReport.compose ẩn. */
    private fun buildDiagReport(): String {
        val st = _state.value
        val models = listOf(
            "tách nền" to st.segReady, "tách nền chất lượng cao" to st.segHqReady, "tách nền chân dung" to st.portraitReady,
            "khuôn mặt" to st.faceReady, "tóc" to st.hairReady, "phát hiện người" to st.personReady, "độ sâu" to st.depthReady, "LaMa" to st.lamaReady,
            "MI-GAN" to st.miganReady, "ESRGAN" to st.esrganReady, "SAM" to st.samReady,
            "LLM" + (if (st.llmReady && st.llmBackend.isNotBlank()) " (${st.llmBackend})" else "") to st.llmReady,
            "SD cục bộ: chương trình" to st.sdLocalBinary, "SD cục bộ: model" to st.sdLocalModel
        )
        val files = modelDir.listFiles()?.filter { it.isFile && !it.name.endsWith(".name") }?.sortedBy { it.name }?.take(40)?.map { it.name to it.length() }.orEmpty()
        val settings = listOf(
            "nhà cung cấp tạo ảnh" to st.genProvider.name,
            "model Gemini" to st.cloudModel,
            "khóa Gemini của người dùng" to if (st.cloudKey.isNotBlank()) "đã nhập" else "chưa nhập",
            "máy chủ riêng" to (DiagReport.hostOf(st.proxyUrl).ifBlank { "chưa đặt" } + if (st.proxyToken.isNotBlank()) " (đã đăng ký)" else ""),
            "máy chủ SD mạng LAN" to DiagReport.hostOf(st.sdUrl).ifBlank { "chưa đặt" },
            "máy chủ cho phép dùng AI của chủ app" to if (st.serverAiOk) "có" else "không (dùng khóa riêng / model trên máy)",
            "Agent AI" to if (st.agentMode) "bật" else "tắt",
            "chất lượng tạo ảnh" to st.genQuality.name,
            "xóa chính xác" to if (st.exactRemove) "bật" else "tắt",
            "bản dùng thử miễn phí" to if (com.aiphoto.studio.engine.Monetization.ENABLED) "không (đang bán)" else "có"
        )
        val layers = st.layers.take(30).joinToString(", ") {
            when (it) {
                is AdjustmentLayer -> "${it.kind}(${it.ops.size} phép${if (it.visible) "" else ", ẩn"})"
                is PatchLayer -> "vá ${it.patch.width}×${it.patch.height}"
                else -> it.javaClass.simpleName
            }
        }
        val doc = listOf(
            "ảnh xem trước" to (st.before?.let { "${it.width}×${it.height}" } ?: "chưa mở ảnh"),
            "ảnh làm việc" to (bg?.let { "${it.width}×${it.height}" } ?: "chưa có"),
            "số lớp" to "${st.layers.size}" + if (layers.isNotEmpty()) " [$layers]" else "",
            "bước hoàn tác" to "${undoStack.size}",
            "thẻ đang mở" to st.panel.name,
            "phiên model đang giữ trong RAM" to pool.loaded().joinToString(", ").ifBlank { "không có" },
            "chế độ tô" to st.paintMode.name,
            "đang bận" to if (st.busy) "có" else "không"
        )
        val input = DiagReport.Input(
            appVersion = DiagAndroid.appVersion(appCtx),
            device = DiagAndroid.deviceFields(appCtx),
            perf = perf.describe(),
            modelsReady = models.filter { it.second }.map { it.first },
            modelsMissing = models.filter { !it.second }.map { it.first },
            modelFiles = files,
            settings = settings,
            doc = doc,
            status = st.status,
            recentPrompts = synchronized(recentPrompts) { recentPrompts.toList() },
            log = DiagLog.snapshot(),
            crash = crashStore.peek(),
            exits = DiagAndroid.exitRecords(appCtx)
        )
        return DiagReport.compose(input)
    }

    /** Nút "Gửi thông tin lỗi" trong Cài đặt: lập báo cáo rồi hiện để người dùng xem trước khi gửi. */
    fun prepareDiagReport() {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) { buildDiagReport() }
            val hasCrash = withContext(Dispatchers.IO) { crashStore.peek() != null }
            ui {
                copy(
                    diagReport = text, diagCrash = hasCrash,
                    diagTitle = "Gửi thông tin lỗi",
                    diagHint = "Báo cáo chỉ có thông số máy, model đã nạp, cài đặt và nhật ký thao tác - không có ảnh của bạn, không có khóa AI/token. Xem bên dưới rồi bấm Gửi để chọn ứng dụng gửi (Zalo, Telegram, email...)."
                )
            }
        }
    }

    /** Kiểm tra lần chạy trước có kết thúc bất thường không; có thì hiện hộp thoại báo lỗi kèm báo cáo. */
    private fun checkLastExit() {
        val crash = crashStore.pendingUnseen()
        val exits = DiagAndroid.exitRecords(appCtx)
        val seen = prefs.getLong(KEY_EXIT_SEEN, 0L)
        val unseen = DiagReport.pickUnseen(exits, seen)
        val latest = DiagReport.latestTs(exits)
        if (latest > seen) prefs.edit().putLong(KEY_EXIT_SEEN, latest).apply()
        val title: String
        val hint: String
        when {
            crash != null -> {
                crashStore.markShown()
                title = "Lần trước app đóng đột ngột"
                hint = "App gặp lỗi và tự đóng. Gửi báo cáo cho người phát triển để sửa (không có ảnh của bạn, không có khóa AI)."
                DiagLog.add("lỗi", "lần chạy trước đóng đột ngột (có báo cáo lỗi)")
            }
            unseen != null -> {
                title = "Lần trước app bị hệ thống tắt (${DiagReport.reasonName(unseen.reason)})"
                hint = DiagReport.explainExit(unseen.reason).ifBlank { "App bị kết thúc bất thường." } + " Gửi báo cáo nếu bạn muốn giúp tìm nguyên nhân."
                DiagLog.add("lỗi", "lần chạy trước bị hệ thống tắt: ${DiagReport.describeExit(unseen)}")
            }
            else -> return
        }
        val text = buildDiagReport()
        ui { copy(diagReport = text, diagTitle = title, diagHint = hint, diagCrash = crash != null) }
    }

    /** Gửi báo cáo (kèm ghi chú của tester) qua hộp chia sẻ của hệ thống; không có gì tự gửi đi. */
    fun shareDiagReport(note: String) {
        val st = _state.value
        val report = st.diagReport ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "AI Photo Studio - thông tin lỗi")
            putExtra(Intent.EXTRA_TEXT, DiagReport.withNote(note, report))
        }
        val chooser = Intent.createChooser(send, "Gửi thông tin lỗi").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { appCtx.startActivity(chooser) }
        if (st.diagCrash) viewModelScope.launch(Dispatchers.IO) { crashStore.clear() }   // đã đưa cho người dùng gửi: không báo lại
        ui { copy(diagReport = null, diagTitle = "", diagHint = "", diagCrash = false, status = "Đã mở hộp chia sẻ thông tin lỗi.") }
    }

    /** Đóng hộp thoại báo lỗi. [forget] = true: bỏ hẳn lỗi đóng đột ngột đã lưu; false: giữ để lần sau bấm "Gửi thông tin lỗi" trong Cài đặt vẫn kèm theo. */
    fun dismissDiagReport(forget: Boolean) {
        if (forget && _state.value.diagCrash) viewModelScope.launch(Dispatchers.IO) { crashStore.clear() }
        ui { copy(diagReport = null, diagTitle = "", diagHint = "", diagCrash = false) }
    }

    // ------------------------------------------------------------------ lịch sử (snapshot danh sách lớp)
    private fun docSnapshot(): DocState? = bg?.let { DocState(it, _state.value.layers) }

    private fun pushUndo() {
        textEditUndoFor = -1L
        docSnapshot()?.let { undoStack.addLast(it) }
        if (undoStack.size > 15) undoStack.removeFirst()
        redoStack.clear()
        ui { copy(canUndo = true, canRedo = false) }
    }

    private fun restore(d: DocState) {
        if (d.background !== bg) setBackgroundOnly(d.background)
        pending = null
        warpRotBase = null
        polyNode = -1
        ui {
            copy(
                layers = d.layers,
                activeId = if (d.layers.any { it.id == activeId }) activeId else null,
                genKind = null,
                warpAngle = 0f   // lưới đã đổi theo bước quay về: thanh "Xoay" tính lại từ 0 so với lưới hiện tại
            )
        }
        requestRender()
    }

    fun undo() {
        if (_state.value.busy) return
        val prev = undoStack.removeLastOrNull() ?: return
        docSnapshot()?.let { redoStack.addLast(it) }
        editOpen = false
        restore(prev)
        ui { copy(canUndo = undoStack.isNotEmpty(), canRedo = true, status = "Đã hoàn tác.") }
    }

    fun redo() {
        if (_state.value.busy) return
        val next = redoStack.removeLastOrNull() ?: return
        docSnapshot()?.let { undoStack.addLast(it) }
        editOpen = false
        restore(next)
        ui { copy(canUndo = true, canRedo = redoStack.isNotEmpty(), status = "Đã làm lại.") }
    }

    // ------------------------------------------------------------------ Lịch sử
    /** Dòng thời gian = ngăn xếp hoàn tác (cũ → mới) + trạng thái hiện tại + ngăn xếp làm lại (gần → xa). */
    private fun historyStates(): List<DocState>? {
        val cur = docSnapshot() ?: return null
        val all = ArrayList<DocState>(undoStack.size + 1 + redoStack.size)
        all.addAll(undoStack)
        all.add(cur)
        for (i in redoStack.indices.reversed()) all.add(redoStack[i])
        return all
    }

    private fun refreshHistory() {
        val states = historyStates() ?: return
        val labels = ArrayList<String>(states.size)
        labels.add(if (undoStack.size >= 15) "Điểm xa nhất còn nhớ được" else "Bắt đầu (ảnh vừa mở)")
        for (i in 1 until states.size) {
            labels.add(HistoryLabels.describe(states[i - 1].background !== states[i].background, states[i - 1].layers, states[i].layers))
        }
        val idx = undoStack.size
        if (_state.value.history != labels || _state.value.historyIndex != idx) ui { copy(history = labels, historyIndex = idx) }
    }

    fun toggleHistory() {
        val open = !_state.value.historyOpen
        ui { copy(historyOpen = open) }
        if (open) refreshHistory()
    }

    /** Nhảy về bước [index] của dòng thời gian (0 = bắt đầu). Các bước sau vẫn còn trong ngăn xếp làm lại. */
    fun jumpToHistory(index: Int) {
        if (_state.value.busy) return
        val states = historyStates() ?: return
        if (index !in states.indices || index == undoStack.size) return
        undoStack.clear()
        redoStack.clear()
        for (i in 0 until index) undoStack.addLast(states[i])
        for (i in states.indices.reversed()) if (i > index) redoStack.addLast(states[i])
        editOpen = false
        restore(states[index])
        ui { copy(canUndo = index > 0, canRedo = index < states.size - 1, status = "Đã quay về bước ${index + 1}/${states.size}.") }
        refreshHistory()
    }

    fun touchEdit() {
        if (!editOpen) {
            pushUndo()
            editOpen = true
        }
    }

    fun endEdit() {
        warpRotBase = null
        if (editOpen) {
            editOpen = false
            recordStyle()
            requestRender() // thả tay -> dựng lại bản xem trước độ phân giải cao
        }
    }

    // ------------------------------------------------------------------ dựng xem trước (gộp các lần kéo thanh trượt)
    private fun requestRender() {
        renderVersion++
        scheduleAutosave()
        if (_state.value.historyOpen) refreshHistory()
        if (renderJob?.isActive == true) {
            renderQueued = true
            return
        }
        renderJob = viewModelScope.launch {
            do {
                renderQueued = false
                val myVersion = renderVersion
                val pb = (if (editOpen) previewLo else previewHi) ?: break
                val full = bg?.width ?: break
                val stack = _state.value.layers + listOfNotNull(pending)
                val notes = ArrayList<String>()
                val result = try {
                    withContext(Dispatchers.Default) {
                        // chỉ tính lại các lớp thay đổi (cache tiền tố) và dừng ngay nếu có yêu cầu mới hơn
                        Compositor.renderCached(pb, stack, full, currentSeg(), notes, renderCache) { renderVersion != myVersion }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    ui { copy(status = "Lỗi dựng xem trước: ${e.message ?: e.javaClass.simpleName}") }
                    null
                }
                if (result != null) ui { copy(preview = if (stack.isEmpty()) null else result) }
            } while (renderQueued)
        }
    }

    private fun setBackgroundOnly(b: Bitmap) {
        bg = b
        renderCache.clear()
        MaskRenderer.clearCache()
        selectionMask = null
        val hi = ImageIO.scaleToMax(b, perf.previewHi)
        previewHi = hi
        previewLo = ImageIO.scaleToMax(b, perf.previewLo)
        ui { copy(before = hi, preview = null, selection = null, tapPoints = emptyList(), bestTakeUris = emptyList(), reframeX = 0f, reframeY = 0f) }
    }

    // ------------------------------------------------------------------ mở ảnh / bố cục
    fun openImage(uri: Uri) {
        launchTask("Đang mở ảnh…") {
            val bmp = withContext(Dispatchers.IO) { ImageIO.decode(appCtx, uri, perf.maxSide) }
            autosaveJob?.cancel()
            withContext(Dispatchers.IO) { projectStore.startNew() }   // ảnh mới = phiên mới; các phiên cũ vẫn còn trong danh sách
            undoStack.clear()
            redoStack.clear()
            pending = null
            editOpen = false
            setBackgroundOnly(bmp)
            val stats = withContext(Dispatchers.Default) { ImageStats.compute(bmp) }
            ui { copy(suggestions = ImageStats.suggestions(stats)) }
            ui {
                copy(
                    layers = emptyList(), activeId = null, strokes = emptyList(), genKind = null,
                    paintMode = PaintMode.OFF, canUndo = false, canRedo = false, chat = emptyList(),
                    panel = Panel.AI,
                    status = "Ảnh ${bmp.width}×${bmp.height}. Gõ yêu cầu ở thẻ AI, hoặc mở Công cụ / Looks."
                )
            }
            requestRender()
        }
    }

    fun setPanel(p: Panel) {
        ui { copy(panel = p) }
    }

    fun onPrompt(text: String) {
        ui { copy(prompt = text) }
    }

    // ------------------------------------------------------------------ quản lý lớp
    fun selectLayer(id: Long?) {
        ui { copy(activeId = id) }
    }

    private fun updateLayer(id: Long, f: (Layer) -> Layer) {
        ui { copy(layers = layers.map { if (it.id == id) f(it) else it }) }
        requestRender()
    }

    private fun replaceLayer(new: Layer) = updateLayer(new.id) { new }

    fun toggleVisible(id: Long) {
        pushUndo()
        updateLayer(id) { it.update(visible = !it.visible) }
    }

    fun setOpacity(id: Long, v: Float) {
        touchEdit()
        updateLayer(id) { it.update(opacity = v.coerceIn(0f, 1f)) }
    }

    /** Bật/tắt clipping mask: lớp chỉ tác dụng trong phạm vi (mặt nạ / alpha) của lớp gần nhất bên dưới. */
    fun setClip(id: Long, v: Boolean) {
        pushUndo()
        updateLayer(id) { it.update(clip = v) }
    }

    fun setBlend(id: Long, m: BlendMode) {
        pushUndo()
        updateLayer(id) { it.update(blend = m) }
    }

    fun moveLayer(id: Long, delta: Int) {
        val list = _state.value.layers
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        pushUndo()
        val m = list.toMutableList()
        val tmp = m[i]; m[i] = m[j]; m[j] = tmp
        ui { copy(layers = m) }
        requestRender()
    }

    fun deleteLayer(id: Long) {
        pushUndo()
        ui { copy(layers = layers.filterNot { it.id == id }, activeId = if (activeId == id) null else activeId) }
        requestRender()
    }

    // ------------------------------------------------------------------ thanh trượt công cụ (sửa lớp đang chọn)
    private fun activeAdjustment(): AdjustmentLayer {
        val st = _state.value
        (st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer)?.let { return it }
        st.layers.filterIsInstance<AdjustmentLayer>().lastOrNull { it.kind == "basic" }?.let {
            ui { copy(activeId = it.id) }
            return it
        }
        val l = AdjustmentLayer(newId(), "Điều chỉnh cơ bản", emptyList(), kind = "basic")
        ui { copy(layers = layers + l, activeId = l.id) }
        return l
    }

    private fun isNeutral(type: OpType, value: Float, arg: String?): Boolean = when (type) {
        OpType.LEVELS -> {
            val p = arg?.split(',')?.mapNotNull { it.trim().toFloatOrNull() }
            p == null || p.size < 3 || (abs(p[0]) < 0.005f && abs(p[1] - 1f) < 0.005f && abs(p[2] - 1f) < 0.005f)
        }
        OpType.CURVES -> ToneOps.isIdentityCurves(arg)
        OpType.SELECTIVE_COLOR -> arg == null || arg.split(',').take(SelectiveColor.VALUES).all { (it.trim().toFloatOrNull() ?: 0f).let { v -> abs(v) < 0.005f } }
        OpType.HSL, OpType.COLOR_BALANCE -> arg == null || arg.split(',').all { (it.trim().toFloatOrNull() ?: 0f).let { v -> abs(v) < 0.005f } }
        OpType.SPLIT_TONE -> SplitTone.parse(arg)?.isIdentity ?: true
        OpType.GRAYSCALE -> value < 0.5f
        else -> if (type.signed) abs(value) < 0.005f else value < 0.005f
    }

    fun setOp(type: OpType, value: Float, arg: String? = null) {
        if (bg == null) return
        touchEdit()
        if (_state.value.scrubType != type) ui { copy(scrubType = type) }
        val layer = activeAdjustment()
        val ops = layer.ops.filter { it.type != type }.toMutableList()
        if (!isNeutral(type, value, arg)) ops.add(EditOp(type, value, arg))
        replaceLayer(layer.copy(ops = ops))
    }

    // ------------------------------------------------------------------ looks & công thức & hàng loạt
    fun applyLook(name: String) {
        val ops = Looks.byName(name) ?: return
        if (bg == null) return
        pushUndo()
        val l = AdjustmentLayer(newId(), "Look: $name", ops, kind = "look")
        ui { copy(layers = layers + l, activeId = l.id, status = "Đã thêm look \"$name\". Kéo thanh Cường độ để chỉnh.") }
        requestRender()
    }

    /** Nhập tệp LUT .cube (3D) từ bộ nhớ: kiểm tra định dạng rồi lưu vào kho LUT trên máy. */
    fun importLut(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp LUT…") }
            val (saved, error) = withContext(Dispatchers.IO) {
                runCatching {
                    var display = "lut.cube"
                    appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0)?.let { display = it }
                    }
                    val buf = java.io.ByteArrayOutputStream()
                    appCtx.contentResolver.openInputStream(uri)?.use { input ->
                        val chunk = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(chunk)
                            if (n < 0) break
                            buf.write(chunk, 0, n)
                            if (buf.size() > CubeLut.MAX_BYTES) break
                        }
                    }
                    if (buf.size() > CubeLut.MAX_BYTES) Pair<String?, String?>(null, "Tệp LUT quá lớn (tối đa 12 MB)")
                    else LutStore.save(display, buf.toString(Charsets.UTF_8.name()))
                }.getOrElse { Pair<String?, String?>(null, "Không đọc được tệp: ${it.message}") }
            }
            refreshLuts()
            ui {
                copy(status = if (saved != null) "Đã nhập LUT \"$saved\". Chạm tên LUT để áp dụng." else "Không nhập được LUT: ${error ?: "lỗi không rõ"}")
            }
        }
    }

    /** Thêm LUT làm một lớp "look" riêng (kéo Cường độ = độ mờ lớp, ẩn/hiện/xóa như mọi lớp khác). */
    fun applyLut(name: String) {
        if (bg == null) return
        if (LutStore.get(name) == null) {
            ui { copy(status = "Không đọc được LUT \"$name\" (tệp hỏng hoặc không phải LUT 3D).") }
            return
        }
        pushUndo()
        val l = AdjustmentLayer(newId(), "LUT: ${name.removeSuffix(".cube")}", listOf(EditOp(OpType.LUT, 1f, name)), kind = "look")
        ui { copy(layers = layers + l, activeId = l.id, status = "Đã thêm LUT \"${name.removeSuffix(".cube")}\". Kéo Cường độ để chỉnh.") }
        requestRender()
    }

    fun deleteLut(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { LutStore.delete(name) }
            refreshLuts()
        }
    }

    fun saveRecipe(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        val visible = _state.value.layers.filterIsInstance<AdjustmentLayer>().filter { it.visible }
        val ls = visible.filter { RecipeCodec.portable(it) }
        val dropped = visible.size - ls.size
        if (ls.isEmpty()) {
            ui { copy(status = "Chưa có lớp nào chuyển giao được để lưu thành công thức (mặt nạ tô tay gắn với riêng từng ảnh nên không lưu).") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { recipeStore.save(n, ls) }
            refreshRecipes()
            ui {
                copy(
                    status = "Đã lưu công thức \"$n\" (${ls.size} lớp" +
                        (if (dropped > 0) "; bỏ $dropped lớp mặt nạ tô tay vì không chuyển sang ảnh khác được" else "") + ")."
                )
            }
        }
    }

    /**
     * Dựng lớp từ công thức cho MỘT ảnh: lớp thường/mặt nạ tham số dùng nguyên; lớp theo vùng AI ([AdjustmentLayer.scope])
     * được dựng lại mặt nạ trên ảnh này (nhận diện khuôn mặt/tách nền riêng cho từng ảnh). Lớp không dựng được mặt nạ thì bỏ kèm lý do trong [notes].
     */
    private suspend fun materializeRecipe(
        tmpl: List<AdjustmentLayer>, target: Bitmap, notes: MutableList<String>, seg: Segmenter?, nextId: () -> Long
    ): List<AdjustmentLayer> {
        val out = ArrayList<AdjustmentLayer>()
        for (l in tmpl) {
            val sc = l.scope
            if (sc == null) {
                out.add(l.copy(id = nextId()))
                continue
            }
            val mask = maskForScope(sc, target, notes, seg) ?: continue
            out.add(l.copy(id = nextId(), mask = mask))
        }
        return out
    }

    fun applyRecipe(name: String) {
        val tmpl = recipeStore.get(name) ?: return
        val bgFull = bg ?: return
        launchTask("Đang áp dụng công thức…") {
            val notes = ArrayList<String>()
            val added = materializeRecipe(tmpl, bgFull, notes, null) { newId() }
            if (added.isEmpty()) {
                ui { copy(status = "Không áp dụng được công thức \"$name\". " + notes.distinct().joinToString(" ")) }
                return@launchTask
            }
            pushUndo()
            ui {
                copy(
                    layers = layers + added, activeId = added.last().id,
                    status = ("Đã áp dụng công thức \"$name\" (${added.size}/${tmpl.size} lớp). " + notes.distinct().joinToString(" ")).trim()
                )
            }
            requestRender()
        }
    }

    fun deleteRecipe(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { recipeStore.delete(name) }
            refreshRecipes()
        }
    }

    /** Áp công thức đã lưu cho nhiều ảnh, lưu thẳng vào thư viện (Pictures/AIPhotoStudio). */
    fun batchApply(uris: List<Uri>, recipeName: String) {
        val tmpl = recipeStore.get(recipeName)
        if (tmpl == null || uris.isEmpty()) {
            ui { copy(status = "Chưa chọn ảnh hoặc không tìm thấy công thức.") }
            return
        }
        launchTask("Đang xử lý hàng loạt…") {
            var ok = 0
            for ((i, uri) in uris.withIndex()) {
                ui { copy(status = "Hàng loạt ${i + 1}/${uris.size}…") }
                try {
                    val bmp = withContext(Dispatchers.Default) { ImageIO.decode(appCtx, uri, perf.maxSide) }
                    // lớp theo vùng AI (khuôn mặt, răng, bầu trời, chủ thể...) được dựng lại mặt nạ RIÊNG cho từng ảnh
                    val segForThis = withContext(Dispatchers.Default) { portraitFor(bmp) ?: segmenter }
                    var seq = 0L
                    val ls = materializeRecipe(tmpl, bmp, ArrayList(), segForThis) { ++seq }
                    withContext(Dispatchers.Default) {
                        val out = Compositor.render(bmp, ls, bmp.width, segmenter, false, ArrayList())
                        ImageIO.saveToGallery(appCtx, out, ImageIO.hasTransparency(out))
                    }
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // bỏ qua ảnh lỗi, xử lý ảnh tiếp theo
                }
            }
            ui { copy(status = "Hàng loạt xong: $ok/${uris.size} ảnh đã lưu vào Pictures/AIPhotoStudio.") }
        }
    }

    // ------------------------------------------------------------------ mặt nạ / chỉnh cục bộ
    private fun addLocal(name: String, mask: LayerMask, ops: List<EditOp> = emptyList(), scope: String? = null) {
        pushUndo()
        val l = AdjustmentLayer(newId(), name, ops, mask = mask, kind = "local", scope = scope)
        ui {
            copy(
                layers = layers + l, activeId = l.id, panel = Panel.TOOLS,
                status = "Đã tạo lớp cục bộ \"$name\". Kéo thanh trượt trong Công cụ để chỉnh riêng vùng này."
            )
        }
        requestRender()
    }

    fun addLocalLayer(kind: String) {
        val bgFull = bg ?: return
        val w = bgFull.width
        val h = bgFull.height
        when (kind) {
            "subject" -> launchTask("Đang chọn chủ thể…") {
                val m = withContext(Dispatchers.Default) {
                    (currentSeg() ?: error("Cần nạp model tách nền (.onnx) để chọn chủ thể.")).foregroundMask(bgFull)
                }
                val bytes = ByteArray(m.size) { (m[it] * 255f).toInt().coerceIn(0, 255).toByte() }
                addLocal("Chủ thể", LayerMask(MaskSpec.Painted(bytes, w, h), feather = 0.01f), emptyList(), Scope.SUBJECT)
            }
            "brush", "dodge", "burn" -> {
                val ops = when (kind) {
                    "dodge" -> listOf(EditOp(OpType.BRIGHTNESS, 0.3f))
                    "burn" -> listOf(EditOp(OpType.BRIGHTNESS, -0.3f))
                    else -> emptyList()
                }
                val name = when (kind) { "dodge" -> "Dodge (làm sáng)"; "burn" -> "Burn (làm tối)"; else -> "Vùng tô tay" }
                addLocal(name, LayerMask(MaskSpec.Painted(ByteArray(w * h), w, h), feather = 0.02f), ops)
                ui { copy(paintMode = PaintMode.REVEAL, strokes = emptyList()) }
            }
            else -> {
                val lm = when (kind) {
                    "bright" -> LayerMask(MaskSpec.Luminance(0.6f, 1f)) to "Vùng sáng"
                    "dark" -> LayerMask(MaskSpec.Luminance(0f, 0.4f)) to "Vùng tối"
                    "sky" -> LayerMask(MaskSpec.Sky(0.5f), feather = 0.01f) to "Bầu trời (tự nhận diện)"
                    "center" -> LayerMask(MaskSpec.Radial(0.5f, 0.5f, 0.45f), feather = 0.05f) to "Tâm ảnh"
                    "top" -> LayerMask(MaskSpec.Linear(90f, 0.5f), invert = true, feather = 0.03f) to "Nửa trên"
                    "bottom" -> LayerMask(MaskSpec.Linear(90f, 0.5f), feather = 0.03f) to "Nửa dưới"
                    "chR" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_RGB, 0, 0.6f, 1f)) to "Kênh đỏ (R) cao"
                    "chG" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_RGB, 1, 0.6f, 1f)) to "Kênh lục (G) cao"
                    "chB" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_RGB, 2, 0.6f, 1f)) to "Kênh lam (B) cao"
                    "chS" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_HSV, 1, 0.45f, 1f)) to "Bão hòa cao (HSV-S)"
                    "chV" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_HSV, 2, 0f, 0.35f)) to "Độ sáng thấp (HSV-V)"
                    "chL" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_LAB, 0, 0.65f, 1f)) to "Sáng (Lab-L)"
                    "chA" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_LAB, 1, 0.58f, 1f)) to "Hồng-đỏ (Lab-a)"
                    "chBl" -> LayerMask(MaskSpec.Channel(MaskMath.SPACE_LAB, 2, 0.58f, 1f)) to "Vàng (Lab-b)"
                    "focus" -> LayerMask(MaskSpec.Focus(0.35f, 1f), feather = 0.01f) to "Vùng nét (Focus Area)"
                    "unfocus" -> LayerMask(MaskSpec.Focus(0f, 0.25f), feather = 0.01f) to "Vùng mờ (ngoài nét)"
                    else -> return
                }
                addLocal(lm.second, lm.first)
            }
        }
    }

    fun setPaintMode(m: PaintMode) {
        ui {
            copy(
                paintMode = m,
                patchPick = false,
                // vào / rời chế độ Phác thảo thì bỏ nét cũ (nét thường không có màu, nét phác không dùng làm mặt nạ tô)
                strokes = if (m == PaintMode.OFF || m == PaintMode.QUICK || m == PaintMode.LASSO || m == PaintMode.SKETCH || paintMode == PaintMode.SKETCH) emptyList() else strokes,
                strokeColors = emptyList(),
                cloneSource = if (m == PaintMode.CLONE) cloneSource else null
            )
        }
    }

    fun beginStroke(p: Pt) {
        ui {
            if (paintMode == PaintMode.SKETCH) {
                val colors = Sketch.alignColors(strokeColors, strokes.size, sketchColor)
                copy(strokes = strokes + listOf(listOf(p)), strokeColors = colors + sketchColor)
            } else copy(strokes = strokes + listOf(listOf(p)))
        }
    }

    fun setSketchColor(argb: Int) {
        ui { copy(sketchColor = argb or (0xFF shl 24)) }
    }

    fun addPoint(p: Pt) {
        ui {
            if (strokes.isEmpty()) this
            else copy(strokes = strokes.dropLast(1) + listOf(strokes.last() + p))
        }
    }

    fun setQuickTol(v: Float) {
        ui { copy(quickTol = v.coerceIn(0f, 1f)) }
    }

    /** Thả tay sau một nét kéo trong chế độ Quick Selection / Lasso. */
    fun finishStroke() {
        when (_state.value.paintMode) {
            PaintMode.QUICK -> quickSelectCommit()
            PaintMode.LASSO -> lassoCommit()
            else -> Unit
        }
    }

    /** Quick Selection: nét tô thành hạt giống → lan theo màu → hợp với vùng chọn hiện có (như chạm thêm ở chế độ Chạm chọn). */
    private fun quickSelectCommit() {
        val st = _state.value
        val bgFull = bg ?: return
        val stroke = st.strokes.lastOrNull() ?: return
        launchTask("Đang chọn theo màu…") {
            val seeds = MaskBuilder.build(listOf(stroke), st.brush, bgFull.width, bgFull.height, "")
            if (seeds == null) {
                ui { copy(strokes = emptyList()) }
                return@launchTask
            }
            val merged = withContext(Dispatchers.Default) {
                val sel = QuickSelect.select(readPixels(bgFull), bgFull.width, bgFull.height, seeds, st.quickTol)
                val prev = selectionMask
                if (prev != null && prev.size == sel.size) ByteArray(sel.size) { i -> if (prev[i].toInt() != 0 || sel[i].toInt() != 0) 255.toByte() else 0 } else sel
            }
            selectionMask = merged
            val overlay = withContext(Dispatchers.Default) { selectionOverlay(merged, bgFull.width, bgFull.height) }
            ui {
                copy(
                    strokes = emptyList(), selection = overlay,
                    status = "Đã chọn theo màu. Tô thêm để mở rộng (tăng Dung sai nếu chưa đủ), rồi \"Tạo lớp cục bộ\" hoặc dùng các việc gợi ý bên dưới."
                )
            }
        }
    }

    /** Lasso: nét kéo tay → đa giác vector (Douglas–Peucker) → lớp cục bộ có mặt nạ vector, chỉnh lại được bằng công thức. */
    private fun lassoCommit() {
        val stroke = _state.value.strokes.lastOrNull() ?: return
        val poly = PolygonFill.fromStroke(stroke)
        if (poly == null) {
            ui { copy(strokes = emptyList(), status = "Vòng lasso quá nhỏ hoặc không khép kín — hãy vẽ một vòng quanh vùng cần chọn.") }
            return
        }
        ui { copy(strokes = emptyList(), paintMode = PaintMode.OFF) }
        addLocal("Vùng lasso (${poly.size} điểm)", LayerMask(MaskSpec.Polygon(poly), feather = 0.01f))
    }

    fun undoStroke() {
        ui { copy(strokes = strokes.dropLast(1), strokeColors = Sketch.alignColors(strokeColors, strokes.size, sketchColor).dropLast(1)) }
    }

    fun clearStrokes() {
        ui { copy(strokes = emptyList(), strokeColors = emptyList()) }
    }

    fun setBrush(v: Float) {
        ui { copy(brush = v) }
    }

    /** Áp các nét đang tô vào mặt nạ của lớp đang chọn (REVEAL = hiện hiệu ứng, HIDE = che bớt). */
    fun commitMaskStrokes() {
        val st = _state.value
        val bgFull = bg ?: return
        val layer = st.layers.firstOrNull { it.id == st.activeId } ?: return
        if (st.strokes.isEmpty() || (st.paintMode != PaintMode.REVEAL && st.paintMode != PaintMode.HIDE)) return
        val w = bgFull.width
        val h = bgFull.height
        val painted = MaskBuilder.build(st.strokes, st.brush, w, h, "") ?: return
        val reveal = st.paintMode == PaintMode.REVEAL
        val limit = st.brushLimit
        if (limit == null) {
            paintIntoMask(layer.id, painted, reveal, w, h)
            return
        }
        // AI Brush giới hạn theo vùng: chỉ giữ phần nét tô nằm trong vùng AI (da / tóc / chủ thể / bầu trời / nền)
        launchTask("Đang giới hạn nét tô theo vùng…") {
            val notes = ArrayList<String>()
            val region = maskForScope(limit, bgFull, notes)
            if (region == null) {
                ui { copy(status = notes.firstOrNull() ?: "Không dựng được vùng giới hạn.") }
                return@launchTask
            }
            val rm = withContext(Dispatchers.Default) { MaskRenderer.render(region, bgFull) }
            for (i in painted.indices) if (rm[i] < 0.5f) painted[i] = 0
            paintIntoMask(layer.id, painted, reveal, w, h)
        }
    }

    private fun paintIntoMask(layerId: Long, painted: ByteArray, reveal: Boolean, w: Int, h: Int) {
        val layer = _state.value.layers.firstOrNull { it.id == layerId } ?: return
        val existing = layer.mask?.spec as? MaskSpec.Painted
        val data = if (existing != null && existing.w == w && existing.h == h) existing.data.copyOf()
        else ByteArray(w * h) { if (reveal) 0.toByte() else 255.toByte() }
        for (i in painted.indices) {
            if (painted[i].toInt() != 0) data[i] = if (reveal) 255.toByte() else 0.toByte()
        }
        pushUndo()
        val lm = LayerMask(
            MaskSpec.Painted(data, w, h),
            invert = layer.mask?.invert ?: false,
            feather = layer.mask?.feather ?: 0.02f
        )
        replaceLayer(layer.update(mask = lm))
        ui { copy(strokes = emptyList()) }
    }

    fun setBrushLimit(scope: String?) {
        ui { copy(brushLimit = scope) }
    }

    fun setMaskInvert(id: Long, v: Boolean) {
        pushUndo()
        updateLayer(id) { l -> l.update(mask = l.mask?.copy(invert = v)) }
    }

    fun setMaskFeather(id: Long, f: Float) {
        touchEdit()
        updateLayer(id) { l -> l.update(mask = l.mask?.copy(feather = f)) }
    }

    /** Dịch biên mặt nạ (Refine Edge): > 0 nở ra, < 0 co vào. */
    fun setMaskShift(id: Long, v: Float) {
        touchEdit()
        updateLayer(id) { l -> l.update(mask = l.mask?.copy(shift = v)) }
    }

    fun removeMask(id: Long) {
        pushUndo()
        updateLayer(id) { l -> l.update(mask = null) }
    }

    // ------------------------------------------------------------------ hình học (gộp lớp vào ảnh nền)
    private suspend fun bakeInternal(ops: List<EditOp>, notes: MutableList<String>) {
        val bgFull = bg ?: return
        val layersNow = _state.value.layers
        val up = ops.firstOrNull { it.type == OpType.UPSCALE }
        val hairVol = ops.firstOrNull { it.type == OpType.HAIR_VOLUME }
        val outpaintOp = ops.firstOrNull { it.type == OpType.OUTPAINT }
        val wantAi = up != null && chain("upscale").any { it.kind == "esrgan_onnx" }
        val processed = withContext(Dispatchers.Default) {
            val upscaler = if (wantAi) runCatching { ensureEsrgan() }.getOrNull() else null
            val rest = ops.filter { it.type != OpType.HAIR_VOLUME && it.type != OpType.OUTPAINT && !(upscaler != null && it.type == OpType.UPSCALE) }
            var flat = Compositor.render(bgFull, layersNow, bgFull.width, currentSeg(), false, notes)
            if (upscaler != null && up != null) {
                flat = upscaler.upscale(flat, up.value.toInt().coerceIn(2, 4), ImageEngine.upscaleMaxSide(flat.width, flat.height, ImageEngine.heapHeadroom()))
                notes.add("Phóng to bằng AI (Real-ESRGAN).")
            } else if (up != null) {
                notes.add("Chưa nạp model phóng to AI (hoặc đã tắt trong định tuyến) nên phóng bằng nội suy + làm nét, ảnh sẽ mềm hơn; nạp Real-ESRGAN ở Cài đặt để rõ nét hơn.")
            }
            val done = ImageEngine.process(flat, rest, currentSeg(), false, notes)
            if (hairVol != null) applyHairVolume(done, hairVol.value, notes) else done
        }
        // Phóng to bị giới hạn bởi cạnh dài tối đa (máy yếu / ảnh lớn): nói rõ hệ số THỰC TẾ thay vì để người dùng tưởng đã ×4
        if (up != null && ops.size == 1) {
            val want = up.value.roundToInt().coerceIn(2, 4)
            val got = processed.width.toFloat() / bgFull.width
            if (got < want - 0.05f) notes.add("Phóng ×$want bị giới hạn còn ×${"%.2f".format(got)} (cạnh dài tối đa ${ImageEngine.upscaleMaxSide(bgFull.width, bgFull.height, ImageEngine.heapHeadroom())} điểm theo bộ nhớ còn trống của máy) để không hết bộ nhớ.")
        }
        // Mở rộng ảnh chạy SAU các phép khác để phần mới khớp với bức ảnh đã chỉnh; dùng dịch vụ sinh ảnh / engine cục bộ nên là suspend
        val out = if (outpaintOp != null) outpaintBitmap(processed, outpaintOp.arg, notes) else processed
        setBackgroundOnly(out)
        ui { copy(layers = emptyList(), activeId = null) }
        requestRender()
    }

    /**
     * Tóc phồng (R16): mặt nạ tóc MediaPipe + vùng bảo vệ = da mặt (nếu đã nạp Face Landmarker) -> [HairVolume]. Thiếu model tóc hoặc không thấy tóc
     * thì giữ nguyên ảnh và báo lý do. Gọi trên luồng nền.
     */
    private fun applyHairVolume(bmp: Bitmap, strength: Float, notes: MutableList<String>): Bitmap {
        val hairMask = hairMaskFor(bmp)
        if (hairMask == null) {
            notes.add(if (ensureHair() == null) "Cần nạp model tóc (hair_segmenter.tflite) trong Cài đặt để làm tóc phồng." else "Không thấy tóc trong ảnh.")
            return bmp
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val protect = runCatching { faceParts(bmp)?.skin }.getOrNull()      // không phủ tóc lên da mặt
        val res = HairVolume.apply(px, w, h, hairMask, protect, strength.coerceIn(0f, 1f))
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(res, 0, w, 0, 0, w, h)
        notes.add("Tóc phồng ${(strength.coerceIn(0f, 1f) * 100).roundToInt()}%" + if (protect != null) " (giữ nguyên da mặt)." else ".")
        return out
    }

    /** Cắt / xoay / lật / phóng to / tách nền làm đổi kích thước hoặc điểm ảnh nền nên các lớp được gộp vào ảnh (hoàn tác được). */
    fun bake(ops: List<EditOp>) {
        if (bg == null) return
        launchTask(if (ops.any { it.type == OpType.OUTPAINT }) "Đang mở rộng ảnh (có thể mất vài chục giây)…" else "Đang áp dụng…") {
            pushUndo()
            val notes = ArrayList<String>()
            bakeInternal(ops, notes)
            ui { copy(status = "Đã áp dụng. Các lớp đã được gộp vào ảnh (có thể hoàn tác). ${notes.joinToString(" ")}".trim()) }
        }
    }

    // ------------------------------------------------------------------ AI: prompt -> lớp / xóa / thêm vật thể
    private fun addChat(fromUser: Boolean, text: String) {
        ui { copy(chat = (chat + ChatMsg(fromUser, text)).takeLast(20)) }
    }

    fun run() {
        val st = _state.value
        if (st.busy || bg == null) return
        val prompt = st.prompt.trim()
        if (prompt.isNotEmpty()) {
            DiagLog.add("lời nhắc", prompt.take(160))
            synchronized(recentPrompts) { recentPrompts.addLast(prompt.take(160)); while (recentPrompts.size > 3) recentPrompts.removeFirst() }
        }
        val hasSel = (st.strokes.isNotEmpty() && st.paintMode == PaintMode.SELECT) || selectionMask != null
        val kind = GenIntent.detect(prompt, hasSel)
        if (prompt.isNotEmpty()) addChat(true, prompt)
        // R26: chế độ Phác thảo — nét màu + lời mô tả → AI vẽ vật thật; đứng trước mọi nhánh hiểu ý vì người dùng đã chọn chế độ này một cách tường minh
        if (st.paintMode == PaintMode.SKETCH) { runSketch(prompt); return }
        // Đã tô vùng thì tôn trọng vùng người dùng tô; chưa tô thì hiểu ý "xóa người lạ" / "thay nền thành <cảnh>"
        val scene = if (hasSel) null else BackgroundScene.extract(prompt)
        val frameReq = AutoFrameIntent.detect(prompt)
        // R25: xóa phản chiếu / bóng đổ / đổi phong cách bằng AI tác động lên CẢ ẢNH (hoặc vùng đã tô); phải đứng trước GenIntent vì "xóa phản chiếu" chứa từ "xóa"
        val wholeReq = if (frameReq == null) WholeEditIntent.detect(prompt) else null
        when {
            frameReq != null -> autoFrame(frameReq.ratio)
            wholeReq != null -> runWholeEdit(wholeReq)
            !hasSel && StrangerIntent.isStrangerRemoval(prompt) -> runStrangerRemoval()
            scene != null -> runBackgroundReplace(scene)
            kind != null -> runGenerative(kind, prompt)
            else -> runClassic(prompt)
        }
    }

    // ------------------------------------------------------------------ Auto Frame (R24)
    /**
     * Bản đồ quan trọng của ảnh nền trên lưới ≤ 96 px: nổi bật cổ điển (luôn có) + mặt nạ chủ thể của model tách nền (nếu đã nạp) + khuôn mặt
     * (nếu đã nạp face_landmarker). Trả về kèm chuỗi mô tả nguồn đã dùng để báo cho người dùng biết độ tin cậy. Chạy trên luồng nền.
     */
    private fun autoFrameMaps(bgFull: Bitmap): Pair<AutoFrame.Maps, String> {
        val long = maxOf(bgFull.width, bgFull.height)
        val f = minOf(1f, 96f / long)
        val gw = maxOf(8, (bgFull.width * f).roundToInt())
        val gh = maxOf(8, (bgFull.height * f).roundToInt())
        val thumb = Bitmap.createScaledBitmap(bgFull, gw, gh, true)
        val sal = AutoFrame.saliency(readPixels(thumb), gw, gh)
        val used = ArrayList<String>()
        used.add("độ nổi bật màu")
        var fg: FloatArray? = null
        val seg = currentSeg()
        if (seg != null) {
            runCatching {
                val sf = minOf(1f, 256f / long)
                val sw = maxOf(8, (bgFull.width * sf).roundToInt())
                val sh = maxOf(8, (bgFull.height * sf).roundToInt())
                val big = Bitmap.createScaledBitmap(bgFull, sw, sh, true)
                val m = seg.foregroundMask(big)
                if (m.size == sw * sh) {
                    val g = AutoFrame.resizeMean(m, sw, sh, gw, gh)
                    if (AutoFrame.fgUsable(g)) { fg = g; used.add("model tách nền") }
                }
            }
        }
        var faces: FloatArray? = null
        val parts = runCatching { faceParts(bgFull) }.getOrNull()
        if (parts != null && parts.faces > 0) {
            faces = AutoFrame.resizeMean(FloatArray(parts.w * parts.h) { (parts.skin[it].toInt() and 255) / 255f }, parts.w, parts.h, gw, gh)
            used.add("khuôn mặt")
        }
        return Pair(AutoFrame.Maps(gw, gh, AutoFrame.combine(sal, fg, faces), faces), used.joinToString(" + "))
    }

    /** Cắt theo chủ thể: [ratio] = rộng/cao muốn có, null = giữ tỉ lệ ảnh hiện tại và chỉ siết khung. Là phép gộp (hoàn tác được). */
    fun autoFrame(ratio: Float?) {
        if (bg == null) return
        launchTask("Đang tìm khung cắt theo chủ thể…") {
            val bgFull = bg ?: return@launchTask
            val r = ratio ?: (bgFull.width.toFloat() / bgFull.height)
            val (frame, sources) = withContext(Dispatchers.Default) {
                val (maps, src) = autoFrameMaps(bgFull)
                Pair(AutoFrame.suggest(maps, bgFull.width, bgFull.height, r), src)
            }
            DiagLog.add("auto frame", "tỉ lệ ${"%.2f".format(java.util.Locale.US, r)}, nguồn: $sources, khung ${AutoFrame.encodeArg(frame)}, ${frame.note}")
            if (frame.coversAll) {
                ui { copy(status = "Auto Frame: ${frame.note}; không cần cắt (dựa trên $sources).") }
                return@launchTask
            }
            pushUndo()
            val notes = ArrayList<String>()
            bakeInternal(listOf(EditOp(OpType.CROP_RATIO, r, AutoFrame.encodeArg(frame))), notes)
            ui { copy(status = "Auto Frame: ${frame.note} (dựa trên $sources). Có thể hoàn tác. ${notes.joinToString(" ")}".trim()) }
        }
    }

    /**
     * Agent AI chạy TRÊN MÁY: ảnh thu nhỏ (≤ 768 px, JPEG) + yêu cầu -> LLM đa phương thức cục bộ (LiteRT-LM) -> kế hoạch chỉnh.
     * Null nếu chưa nạp model .litertlm, model không nhận ảnh, hoặc trả lời sai định dạng (khi đó rơi về Agent ở máy chủ / bộ hiểu prompt).
     */
    private fun localVisionPlan(img: Bitmap, prompt: String): PlanJson.Parsed? {
        val m = ensureLlm() ?: return null
        if (!m.supportsImage) return null
        val longSide = maxOf(img.width, img.height)
        val k = if (longSide > 768) 768f / longSide else 1f
        val small = if (k < 1f) Bitmap.createScaledBitmap(img, maxOf(1, (img.width * k).toInt()), maxOf(1, (img.height * k).toInt()), true) else img
        val f = File(appCtx.cacheDir, "agent_thumb.jpg")
        try {
            f.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return m.planFromImage(f.absolutePath, prompt)
        } finally {
            f.delete()
            if (small !== img) small.recycle()
        }
    }

    private fun runClassic(prompt: String) {
        if (prompt.isEmpty()) {
            ui { copy(status = "Hãy nhập yêu cầu, hoặc bật \"Tô vùng\" rồi tô lên vật thể để xóa.") }
            return
        }
        // R27: "giữ nguyên khuôn mặt / trừ bầu trời…" → cắt khỏi lệnh, phần chỉnh toàn cục sẽ áp lên mặt nạ ĐẢO của các vùng đó
        val protectReq = ProtectIntent.split(prompt)
        val planPrompt = protectReq.rest
        if (protectReq.any && planPrompt.isBlank()) {
            ui { copy(status = "Bạn muốn giữ nguyên ${protectReq.protect.joinToString(", ") { Scope.label(it).lowercase() }} — hãy nói thêm muốn chỉnh gì ở phần còn lại (vd. \"làm sáng ảnh, giữ nguyên khuôn mặt\").") }
            return
        }
        launchTask("AI đang phân tích yêu cầu…") {
            val useLlm = chain("understand_prompt").any { it.kind == "gemma_mediapipe" }
            // Agent AI (nhìn ảnh): mô hình đa phương thức ở máy chủ đọc ảnh thu nhỏ + yêu cầu -> kế hoạch chỉnh; lỗi thì rơi về bộ hiểu prompt cục bộ
            val st0 = _state.value
            var agentNote: String? = null
            val agentParsed: PlanJson.Parsed? = if (st0.agentMode) {
                val img = bg
                // R15: nếu LLM cục bộ là model đa phương thức (.litertlm Gemma 3n/4) thì nhìn ảnh NGAY TRÊN MÁY (ảnh không rời máy, không tốn credit)
                val local = if (img == null) null else withContext(Dispatchers.Default) { runCatching { localVisionPlan(img, planPrompt) }.getOrNull() }
                if (local != null) {
                    agentNote = if (agentRef != null) "chạy trên máy (ảnh mẫu chỉ dùng khi Agent chạy ở máy chủ)" else "chạy trên máy"
                    local
                } else if (img == null || !Monetization.proxyAiUsable(st0.proxyUrl, st0.proxyToken, st0.serverAiOk)) null else {
                    val r = withContext(Dispatchers.IO) { runCatching { ProxyBackend.editPlan(st0.proxyUrl, st0.proxyToken, img, planPrompt, agentRef) } }
                    r.fold(
                        { pair ->
                            ui { copy(credits = pair.second) }
                            val parsed = PlanJson.parseFull(pair.first)
                            if (parsed == null) agentNote = "Agent AI trả kế hoạch rỗng"
                            parsed
                        },
                        { e ->
                            agentNote = "Agent AI lỗi: ${e.message ?: e.javaClass.simpleName}"
                            null
                        }
                    )
                }
            } else null
            val basePlan = if (agentParsed != null) {
                EditPlan(
                    mergeOps(agentParsed.ops).mapNotNull { it.sanitized() }, "Agent AI (nhìn ảnh)", emptyList(),
                    normalizeScoped(agentParsed.scoped)
                )
            } else withContext(Dispatchers.Default) {
                PromptPlanner.plan(planPrompt, if (useLlm) runCatching { ensureLlm() }.getOrNull() else null)
            }
            val plan = agentNote?.let { basePlan.copy(source = basePlan.source + " · " + it) } ?: basePlan
            val reduceOps = plan.ops.filter { it.arg == "reduce" }
            val addOps = plan.ops.filter { it.arg != "reduce" }
            var bakeOps = addOps.filter { it.type in BAKE_TYPES }
            var layerOps = addOps.filter { it.type !in BAKE_TYPES }
            var scoped = plan.scoped
            // "Tóc phồng" tác động CẢ BÊN NGOÀI mặt nạ tóc nên không thể áp theo mặt nạ như lớp thường -> chuyển sang nhóm bake (R16)
            val hairVolumeOps = scoped.filter { it.scope == Scope.HAIR }.flatMap { it.ops }.filter { it.type == OpType.HAIR_VOLUME }
            if (hairVolumeOps.isNotEmpty()) {
                scoped = scoped.map { sc -> if (sc.scope == Scope.HAIR) sc.copy(ops = sc.ops.filter { it.type != OpType.HAIR_VOLUME }) else sc }
                    .filter { it.ops.isNotEmpty() }
                bakeOps = bakeOps + hairVolumeOps
            }
            val reply: String
            // Giảm / tăng lớp đã có không dựng mặt nạ mới nên không thể giữ nguyên vùng: nói rõ thay vì lặng lẽ bỏ qua
            val protectUnusedNote = if (protectReq.any) " (Việc giảm/tăng lớp cũ không áp dụng \"giữ nguyên\" được.)" else ""

            // Retouch da chỉ trên DA MẶT khi đã nạp Face Landmarker và thấy khuôn mặt (PDF: Frequency Separation + Face Landmarker);
            // không có model/khuôn mặt thì giữ đường cũ (mặt nạ màu da YCbCr trong ImageEngine).
            val bgNow = bg ?: return@launchTask
            val skinOps = layerOps.filter { it.type == OpType.SKIN_SMOOTH || it.type == OpType.FREQ_SEP }
            if (skinOps.isNotEmpty() && withContext(Dispatchers.Default) { runCatching { faceParts(bgNow) }.getOrNull() } != null) {
                layerOps = layerOps.filter { it !in skinOps }
                scoped = scoped + ScopedOps(Scope.SKIN, skinOps)
            }

            // R27: vùng được giữ nguyên. Phép chỉnh toàn cục chỉ áp NGOÀI các vùng đó; phép "bake" (cắt, xoay, làm nét lại…) không áp theo mặt nạ được
            // nên bị bỏ (có ghi chú); nhóm theo vùng trùng vùng được giữ cũng bị bỏ. Không dựng được mặt nạ ⇒ từ chối, KHÔNG chỉnh cả ảnh.
            val protectNotes = ArrayList<String>()
            var protectMask: LayerMask? = null
            val protectKey: String? = if (protectReq.any) Scope.protect(protectReq.protect) else null
            if (protectKey != null) {
                val protectedLabel = protectReq.protect.joinToString(", ") { Scope.label(it).lowercase() }
                if (skinOps.isNotEmpty() && Scope.SKIN in protectReq.protect) {
                    layerOps = layerOps.filter { it !in skinOps }
                    scoped = scoped.filter { it.scope != Scope.SKIN }
                    protectNotes.add("Bỏ phần chỉnh da vì bạn muốn giữ nguyên da mặt.")
                }
                val before = scoped.size
                scoped = scoped.filter { it.scope !in protectReq.protect }
                if (scoped.size < before) protectNotes.add("Bỏ phần chỉnh theo vùng trùng vùng giữ nguyên ($protectedLabel).")
                if (bakeOps.isNotEmpty()) {
                    protectNotes.add("Không giữ nguyên được ($protectedLabel) khi ${bakeOps.joinToString(", ") { it.describe() }} — các phép này đổi cả ảnh nên đã bỏ qua.")
                    bakeOps = emptyList()
                }
                if (layerOps.isNotEmpty()) {
                    val mnotes = ArrayList<String>()
                    protectMask = maskForProtect(protectReq.protect, bgNow, mnotes)
                    if (protectMask == null) {
                        ui { copy(status = "Chưa chỉnh gì: không dựng được vùng cần giữ nguyên ($protectedLabel). ${mnotes.distinct().joinToString(" ")}".trim()) }
                        return@launchTask
                    }
                }
            }

            if (layerOps.isNotEmpty() || bakeOps.isNotEmpty() || scoped.isNotEmpty()) {
                pushUndo()
                if (layerOps.isNotEmpty()) {
                    val l = AdjustmentLayer(
                        newId(), "AI: ${planPrompt.take(24)}", layerOps, mask = protectMask, kind = "ai", scope = if (protectMask != null) protectKey else null
                    )
                    ui { copy(layers = layers + l, activeId = l.id) }
                    requestRender()
                }
                val notes = ArrayList<String>()
                notes.addAll(protectNotes)
                if (bakeOps.isNotEmpty()) bakeInternal(bakeOps, notes)
                if (scoped.isNotEmpty()) {
                    val bgAfter = bg ?: return@launchTask // sau bakeInternal ảnh nền có thể đã đổi -> dựng mặt nạ trên ảnh nền mới
                    addScopedLayers(scoped, bgAfter, notes)
                }
                val described = (layerOps + bakeOps).map { it.describe() } +
                    scoped.map { sc -> Scope.label(sc.scope) + ": " + sc.ops.joinToString(", ") { it.describe() } }
                val kept = if (protectMask != null) " (giữ nguyên ${protectReq.protect.joinToString(", ") { Scope.label(it).lowercase() }})" else ""
                reply = (plan.source + ": " + described.joinToString("; ") + kept + " " + notes.joinToString(" ")).trim()
            } else if (reduceOps.isNotEmpty()) {
                var newLayers = _state.value.layers
                var changed = false
                for (r in reduceOps) {
                    val factor = (1f - r.value).coerceIn(0f, 1f)
                    val target = newLayers.filterIsInstance<AdjustmentLayer>()
                        .lastOrNull { l -> l.ops.any { it.type == r.type } }
                    if (target != null) {
                        val nl = target.copy(ops = target.ops.map { if (it.type == r.type) it.scaled(factor) else it })
                        newLayers = newLayers.map { if (it.id == nl.id) nl else it }
                        changed = true
                    }
                }
                if (changed) {
                    pushUndo()
                    val finalLayers = newLayers
                    ui { copy(layers = finalLayers) }
                    requestRender()
                }
                reply = (if (changed) "Đã giảm bớt hiệu ứng theo yêu cầu." else "Chưa có hiệu ứng đó để giảm.") + protectUnusedNote
            } else {
                val f = Refine.factor(planPrompt)
                val last = _state.value.layers.filterIsInstance<AdjustmentLayer>().lastOrNull { it.kind == "ai" || it.kind == "look" }
                if (f != null && last != null) {
                    pushUndo()
                    val nl = last.copy(ops = last.ops.map { it.scaled(f) })
                    replaceLayer(nl)
                    reply = (if (f < 1f) "Đã giảm nhẹ lớp \"${last.name}\"." else "Đã tăng lớp \"${last.name}\".") + protectUnusedNote
                } else {
                    reply = plan.notes.firstOrNull() ?: "Chưa hiểu yêu cầu."
                }
            }
            addChat(false, reply)
            ui { copy(prompt = "", status = reply) }
        }
    }

    // ------------------------------------------------------------------ Best Take (R28)
    fun addBestTakeUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val merged = (_state.value.bestTakeUris + uris).distinct().take(BestTake.MAX_FRAMES)
        ui { copy(bestTakeUris = merged, status = "Best Take: đã có ${merged.size} ảnh phụ. Bấm \"Chọn mặt đẹp nhất\" để so sánh ${merged.size + 1} ảnh.") }
    }

    fun clearBestTake() {
        ui { copy(bestTakeUris = emptyList()) }
    }

    /** Giải mã một ảnh phụ về ĐÚNG cỡ ảnh gốc (w×h); null (kèm lý do trong [notes]) nếu không đọc được hoặc khác khung hình. */
    private fun decodeBestTakeFrame(uri: Uri, w: Int, h: Int, label: String, notes: MutableList<String>): Bitmap? {
        val bmp = runCatching { ImageIO.decode(appCtx, uri, max(w, h)) }.getOrNull()
        if (bmp == null) { notes.add("$label: không đọc được, bỏ qua."); return null }
        if (!BestTake.sameFraming(w, h, bmp.width, bmp.height)) {
            notes.add("$label: khác khung hình (${bmp.width}×${bmp.height}), bỏ qua.")
            bmp.recycle()
            return null
        }
        if (bmp.width == w && bmp.height == h) return bmp
        val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
        if (scaled !== bmp) bmp.recycle()
        return scaled
    }

    /**
     * Best Take (R28): với MỖI khuôn mặt của ảnh hiện tại chọn, trong ảnh hiện tại + các ảnh phụ, khuôn mặt mắt mở / cười đẹp nhất rồi ghép vào
     * ([BestTake]). Lượt 1 chỉ nhận mặt + đo từng ảnh phụ (giải mã xong là bỏ ngay); lượt 2 giải mã lại CHỈ các khung được chọn để ghép — nên tại một thời điểm
     * chỉ giữ ảnh gốc + một ảnh phụ trong RAM. Kết quả là lớp vá chờ "Áp dụng" (hoàn tác được); ngoài khung bao các khuôn mặt được đổi, ảnh giữ nguyên từng bit.
     */
    fun runBestTake() {
        val st = _state.value
        val uris = st.bestTakeUris
        if (uris.isEmpty()) {
            ui { copy(status = "Best Take: hãy thêm các ảnh chụp liền nhau cùng cảnh (nút \"Thêm ảnh cùng cảnh\") rồi bấm lại.") }
            return
        }
        launchTask("Best Take: đang so sánh các khuôn mặt…") {
            val bgFull = bg ?: return@launchTask
            val engine = ensureFace()
            if (engine == null) {
                ui { copy(status = "Best Take cần model face_landmarker.task (nạp trong Cài đặt) để đo mắt mở / nụ cười.") }
                return@launchTask
            }
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val w = base.width
            val h = base.height
            val basePx = withContext(Dispatchers.Default) { readPixels(base) }
            val baseLm = withContext(Dispatchers.Default) { engine.detect(base) }
            if (baseLm.isEmpty()) {
                ui { copy(status = "Không thấy khuôn mặt trong ảnh hiện tại — Best Take cần ít nhất một khuôn mặt.") }
                return@launchTask
            }
            val frames = ArrayList<BestTake.FaceFrame>()
            val frameUris = ArrayList<Uri?>()
            val frameLabels = ArrayList<String>()
            frames.add(BestTake.FaceFrame(baseLm, FloatArray(baseLm.size) { BestTake.sharpness(basePx, w, h, baseLm[it]) }, 0f, 0f))
            frameUris.add(null)
            frameLabels.add("ảnh gốc")
            val baseThumb = BestTake.thumb(basePx, w, h)
            for ((i, uri) in uris.withIndex()) {
                val label = "ảnh phụ ${i + 1}"
                ui { copy(status = "Best Take: phân tích $label/${uris.size}…") }
                val bmp = withContext(Dispatchers.Default) { decodeBestTakeFrame(uri, w, h, label, notes) } ?: continue
                try {
                    val measured = withContext(Dispatchers.Default) {
                        val lm = engine.detect(bmp)
                        if (lm.isEmpty()) null else {
                            val px = readPixels(bmp)
                            Triple(lm, FloatArray(lm.size) { BestTake.sharpness(px, w, h, lm[it]) }, BestTake.alignShift(baseThumb, BestTake.thumb(px, w, h), w, h))
                        }
                    }
                    if (measured == null) { notes.add("$label: không thấy khuôn mặt, bỏ qua."); continue }
                    frames.add(BestTake.FaceFrame(measured.first, measured.second, measured.third[0], measured.third[1]))
                    frameUris.add(uri)
                    frameLabels.add(label)
                } finally {
                    bmp.recycle()
                }
            }
            if (frames.size == 1) {
                ui { copy(status = "Best Take: không có ảnh phụ nào dùng được. ${notes.joinToString(" ")}".trim()) }
                return@launchTask
            }
            val picks = BestTake.plan(frames, w, h)
            val changed = picks.filter { it.changed }
            if (changed.isEmpty()) {
                val msg = "Best Take: ảnh hiện tại đã có khuôn mặt tốt nhất cho cả ${picks.size} người trong ${frames.size} ảnh. ${notes.joinToString(" ")}".trim()
                addChat(false, msg)
                ui { copy(status = msg) }
                return@launchTask
            }
            ui { copy(status = "Best Take: đang ghép ${changed.size} khuôn mặt…") }
            val out = basePx.copyOf()
            var applied = 0
            val done = ArrayList<String>()
            for (f in changed.map { it.frame }.distinct()) {
                val uri = frameUris[f] ?: continue
                val bmp = withContext(Dispatchers.Default) { decodeBestTakeFrame(uri, w, h, frameLabels[f], notes) } ?: continue
                try {
                    withContext(Dispatchers.Default) {
                        val px = readPixels(bmp)
                        for (p in changed.filter { it.frame == f }) {
                            if (BestTake.applyFace(out, w, h, px, frames[f].lm[p.frameFace], baseLm[p.face])) {
                                applied++
                                done.add(BestTake.describe(p, frameLabels[f]))
                            } else notes.add("Mặt ${p.face + 1}: không căn được với ${frameLabels[f]}, giữ ảnh gốc.")
                        }
                    }
                } finally {
                    bmp.recycle()
                }
            }
            if (applied == 0) {
                ui { copy(status = "Best Take: không ghép được khuôn mặt nào. ${notes.joinToString(" ")}".trim()) }
                return@launchTask
            }
            val result = withContext(Dispatchers.Default) { makeBitmap(out, w, h) }
            val notesAll = ArrayList<String>()
            notesAll.add("Đã đổi $applied/${picks.size} khuôn mặt: ${done.joinToString("; ")}.")
            notesAll.addAll(notes)
            offerPatch(GenKind.FILL, base, result, "Best Take", notesAll, retryTip = false)
        }
    }

    // ------------------------------------------------------------------ Reframe 2.5D (R29)
    fun setReframe(x: Float? = null, y: Float? = null, gain: Float? = null) {
        ui { copy(reframeX = (x ?: reframeX).coerceIn(-1f, 1f), reframeY = (y ?: reframeY).coerceIn(-1f, 1f), reframeGain = (gain ?: reframeGain).coerceIn(0f, 2f)) }
    }

    fun resetReframe() {
        ui { copy(reframeX = 0f, reframeY = 0f, reframeGain = 1f) }
    }

    /**
     * Reframe 2.5D (R29): đổi góc nhìn nhẹ từ MỘT ảnh ([Reframe]). Độ sâu GIẢ dựng từ mặt nạ chủ thể (model tách nền nếu đã nạp), bầu trời ([SkyFx]) và vị trí
     * trong ảnh; nền trượt quanh chủ thể, chỗ lộ ra được lấp bằng màu nền, ảnh phóng nhẹ để che viền. Chạy ở cỡ ≤ [Reframe.WORK_SIDE] (và ≤ cỡ ảnh của hạng máy)
     * để RAM không tràn trên máy yếu, rồi phóng kết quả về đúng cỡ ảnh. Kết quả là lớp vá chờ "Áp dụng" (hoàn tác được); không gọi dịch vụ AI nên không tốn hạn mức.
     */
    fun runReframe() {
        val st = _state.value
        val ax = st.reframeX
        val ay = st.reframeY
        val gain = st.reframeGain
        if (max(abs(ax), abs(ay)) < 0.02f || gain < 0.02f) {
            ui { copy(status = "Reframe: kéo \"Xoay ngang\" hoặc \"Xoay dọc\" khỏi giữa (và để \"Độ sâu\" > 0) rồi bấm \"Áp dụng góc nhìn\".") }
            return
        }
        launchTask("Reframe 2.5D: đang dựng độ sâu và đổi góc nhìn…") {
            val bgFull = bg ?: return@launchTask
            val notes = ArrayList<String>()
            var depthNote = ""
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val out = withContext(Dispatchers.Default) {
                val work = ImageIO.scaleToMax(base, minOf(Reframe.WORK_SIDE, perf.maxSide))
                try {
                    val w = work.width
                    val h = work.height
                    val px = readPixels(work)
                    val fg = runCatching { currentSeg()?.foregroundMask(work) }.getOrNull()
                    // R30: độ sâu do model đo (nếu đã nạp) thay cho độ sâu giả; model thiếu / lỗi / ra bản đồ phẳng thì quay về độ sâu giả như R29
                    val depthModel = runCatching { ensureDepth() }.getOrNull()
                    val field = if (depthModel == null) null else estimateDepthAdaptive(depthModel, work)
                    val s = Reframe.shift(ax, ay, gain, w, h)
                    // độ dịch lớn nhất (điểm ảnh) quyết định phải làm phẳng độ lồi của chủ thể bao nhiêu để không nứt (Reframe.reliefKeep)
                    val measured = if (field == null) null else Reframe.depthFromField(px, w, h, field, fg, maxOf(abs(s[0]), abs(s[1])))
                    if (measured == null && File(modelDir, DEPTH_FILE).exists()) depthNote = "Không đo được độ sâu bằng model (model lỗi, bị tắt trong định tuyến hoặc ảnh quá phẳng) nên dùng độ sâu giả."
                    val depth = measured ?: Reframe.depthMap(px, w, h, fg, runCatching { SkyFx.mask(px, w, h) }.getOrNull())
                    val r = Reframe.render(px, w, h, depth, s[0], s[1])
                    if (r == null) null else {
                        var bmp = makeBitmap(r.px, w, h)
                        if (w != base.width || h != base.height) {
                            val up = Bitmap.createScaledBitmap(bmp, base.width, base.height, true)
                            if (up !== bmp) bmp.recycle()
                            bmp = up
                        }
                        Triple(bmp, Reframe.describe(ax, ay, gain, r, depth), depth.fromModel)
                    }
                } finally {
                    if (work !== base) work.recycle()
                }
            }
            if (out == null) {
                ui { copy(status = "Reframe: không có gì để dịch (góc quá nhỏ hoặc độ sâu gần như phẳng). Kéo thanh xa hơn.") }
                return@launchTask
            }
            val notesAll = ArrayList<String>()
            notesAll.add(out.second)
            if (depthNote.isNotEmpty()) notesAll.add(depthNote)
            notesAll.add(
                if (out.third) "Độ sâu do model đo là TƯƠNG ĐỐI (không phải mét) và có thể sai ở vật mảnh / kính / gương; chỗ lộ ra sau chủ thể được lấp mờ."
                else "Độ sâu là ước đoán (không đo được) nên chỉ mang tính thẩm mỹ; chỗ lộ ra sau chủ thể được lấp mờ. Nạp model độ sâu (Cài đặt) để dùng độ sâu đo thật."
            )
            offerPatch(GenKind.FILL, base, out.first, "Reframe 2.5D", notesAll, retryTip = false)
        }
    }

    /**
     * Phác thảo → ảnh (R26): nét màu người dùng vẽ + lời mô tả → ảnh dẫn (nền + nét phác) và mặt nạ (vùng nét nới ra) → dịch vụ sinh ảnh → lớp vá chờ "Áp dụng".
     * Gemini / máy chủ nhận câu lệnh chỉ dẫn ([Sketch.instruction]); SD (cục bộ / LAN) nhận mô tả ảnh ([Sketch.sdPrompt], dịch sang tiếng Anh nếu có LLM)
     * với img2img `strength` 0,85 — nét màu của ảnh dẫn giữ bố cục, SD vẽ lại chi tiết. Ngoài mặt nạ ảnh giữ NGUYÊN điểm ảnh gốc.
     */
    private fun runSketch(prompt: String) {
        val st = _state.value
        val strokes = st.strokes
        if (!Sketch.hasStrokes(strokes)) {
            ui { copy(status = "Hãy chọn màu rồi vẽ nét phác lên chỗ muốn thêm vật thể, sau đó mô tả vật đó và bấm \"Vẽ thành ảnh\".") }
            return
        }
        val colors = Sketch.alignColors(st.strokeColors, strokes.size, st.sketchColor)
        launchTask("Phác thảo → ảnh: AI đang vẽ (có thể mất vài chục giây)…") {
            val bgFull = bg ?: return@launchTask
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val w = base.width
            val h = base.height
            val prepared = withContext(Dispatchers.Default) {
                val sk = Sketch.rasterize(strokes, colors, st.brush, w, h)
                val m = Sketch.mask(sk, w, h, Sketch.growFor(w, h))
                if (m == null) null else {
                    val g = Sketch.overlay(readPixels(base), sk, copy = false)
                    Pair(makeBitmap(g, w, h), m)
                }
            }
            if (prepared == null) {
                ui { copy(status = "Nét phác quá nhỏ hoặc nằm ngoài ảnh — hãy vẽ lại to hơn.") }
                return@launchTask
            }
            val (guide, mask) = prepared
            val needSd = chain("generative_fill").any { it.kind == "sd_webui" || it.kind == "sdcpp_local" }
            val desc = if (!needSd) prompt else withContext(Dispatchers.Default) {
                val l = runCatching { ensureLlm() }.getOrNull()
                if (l == null || prompt.isBlank()) prompt else runCatching { l.translateToEnglish(prompt) }.getOrDefault(prompt)
            }
            val instruction = Sketch.instruction(prompt, Sketch.usedColorNames(strokes, colors))
            val result = fillWithRouting(
                guide, mask, instruction, st, notes,
                instructionOnly = false, sdPrompt = Sketch.sdPrompt(desc),
                optsOverride = { o -> o.copy(strength = o.strength ?: 0.85f) }
            )
            offerPatch(GenKind.FILL, base, result, "Phác thảo: ${prompt.take(20)}", notes, retryTip = true)
        }
    }

    /**
     * AI toàn ảnh (R25): xóa phản chiếu / bóng đổ, đổi phong cách nghệ thuật. Mặt nạ = vùng người dùng đã tô/chọn, không có thì CẢ ẢNH.
     * Lệnh dạng chỉ dẫn chỉ gửi cho dịch vụ hiểu lệnh (Gemini / máy chủ proxy); SD cục bộ chỉ làm được đổi phong cách (img2img).
     * Kết quả vào một lớp vá chờ "Áp dụng", y như tạo/xóa vật thể.
     */
    private fun runWholeEdit(req: WholeEditIntent.Request) {
        val st = _state.value
        launchTask("${req.label}: AI đang xử lý (có thể mất vài chục giây)…") {
            val bgFull = bg ?: return@launchTask
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val mask = withContext(Dispatchers.Default) {
                val painted = if (st.strokes.isEmpty()) null else MaskBuilder.build(st.strokes, st.brush, base.width, base.height, "")
                val sel = selectionMask?.takeIf { it.size == base.width * base.height }
                when {
                    painted != null && sel != null -> ByteArray(sel.size) { if (sel[it].toInt() != 0 || painted[it].toInt() != 0) 255.toByte() else 0.toByte() }
                    painted != null -> painted
                    sel != null -> sel
                    else -> ByteArray(base.width * base.height) { 255.toByte() }
                }
            }
            val sdPrompt = if (req.kind == WholeEditIntent.Kind.RESTYLE) "${req.styleName}, highly detailed" else null
            val result = fillWithRouting(
                base, mask, req.instruction, st, notes,
                instructionOnly = req.kind != WholeEditIntent.Kind.RESTYLE, sdPrompt = sdPrompt,
                optsOverride = { o -> if (req.kind == WholeEditIntent.Kind.RESTYLE) o.copy(strength = o.strength ?: 0.6f) else o }
            )
            offerPatch(GenKind.FILL, base, result, req.label, notes, retryTip = true)
        }
    }

    private fun runGenerative(kind: GenKind, prompt: String) {
        val st = _state.value
        val label = if (kind == GenKind.REMOVE) "Đang xóa vật thể…" else "Đang tạo vật thể (có thể mất vài chục giây)…"
        launchTask(label) {
            val bgFull = bg ?: return@launchTask
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val mask = withContext(Dispatchers.Default) {
                val painted = MaskBuilder.build(st.strokes, st.brush, base.width, base.height, prompt)
                val sel = selectionMask
                if (sel == null || sel.size != base.width * base.height) painted
                else if (painted == null) sel
                else ByteArray(sel.size) { if (sel[it].toInt() != 0 || painted[it].toInt() != 0) 255.toByte() else 0.toByte() }
            }
            if (mask == null) {
                ui { copy(status = "Hãy tô lên vùng cần xử lý, hoặc nêu vị trí trong yêu cầu (bên trái / phải / giữa / trên / dưới).") }
                return@launchTask
            }
            val exact = kind == GenKind.REMOVE && (st.exactRemove || GenIntent.wantsExact(prompt))
            if (exact) notes.add("Chế độ chính xác: chỉ đổi đúng vùng đã tô (không nới, không hòa mép).")
            val result = if (kind == GenKind.REMOVE) removeWithRouting(base, mask, notes, exact)
            else fillWithRouting(base, mask, prompt, st, notes)
            val name = if (kind == GenKind.REMOVE) "Xóa vật thể" else "Tạo: ${prompt.take(20)}"
            val patch = withContext(Dispatchers.Default) { Layers.diffPatch(base, result, newId(), name) }
            if (patch == null) {
                ui { copy(status = "Không có thay đổi nào. ${notes.joinToString(" ")}".trim()) }
                return@launchTask
            }
            pending = patch
            val tip = if (kind == GenKind.FILL) " Không ưng ý: bấm \"Tạo lại\"." else ""
            val reply = "Xong. Bấm \"Áp dụng\" để giữ kết quả.$tip ${notes.joinToString(" ")}".trim()
            addChat(false, reply)
            ui { copy(genKind = kind, status = reply) }
            requestRender()
        }
    }

    /** Đưa kết quả tạo sinh thành bản xem trước (lớp chờ áp dụng) - dùng chung cho xóa người lạ / thay nền. */
    private suspend fun offerPatch(kind: GenKind, base: Bitmap, result: Bitmap, name: String, notes: List<String>, retryTip: Boolean) {
        val patch = withContext(Dispatchers.Default) { Layers.diffPatch(base, result, newId(), name) }
        if (patch == null) {
            ui { copy(status = "Không có thay đổi nào. ${notes.joinToString(" ")}".trim()) }
            return
        }
        pending = patch
        val tip = if (retryTip) " Không ưng ý: bấm \"Tạo lại\"." else ""
        val reply = "Xong. Bấm \"Áp dụng\" để giữ kết quả.$tip ${notes.joinToString(" ")}".trim()
        addChat(false, reply)
        ui { copy(genKind = kind, status = reply) }
        requestRender()
    }

    /**
     * Thay nền bằng CẢNH tạo sinh nhưng giữ nguyên chủ thể (PDF): model tách nền cho chủ thể → dịch vụ sinh ảnh vẽ lại phần nền theo mô tả
     * (kèm ràng buộc khớp ánh sáng) → ghép điểm ảnh GỐC của chủ thể đè lên bằng matte mềm. Cần model tách nền + dịch vụ tạo ảnh.
     */
    private fun runBackgroundReplace(scene: String) {
        val st = _state.value
        launchTask("Đang thay nền (có thể mất vài chục giây)…") {
            val bgFull = bg ?: return@launchTask
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val seg = withContext(Dispatchers.Default) { currentSeg() }
            if (seg == null) {
                ui { copy(status = "Cần nạp model tách nền (.onnx, mục Cài đặt) để giữ nguyên chủ thể khi thay nền.") }
                return@launchTask
            }
            if (chain("generative_fill").isEmpty()) {
                ui { copy(status = "Thay nền bằng cảnh cần dịch vụ tạo ảnh (API key Gemini, máy chủ SD hoặc máy chủ của bạn) trong Cài đặt. Nền màu trơn thì dùng \"xóa nền, nền trắng\".") }
                return@launchTask
            }
            val w = base.width
            val h = base.height
            val fg = withContext(Dispatchers.Default) { seg.foregroundMask(base) }
            val cover = BackgroundSwap.subjectCoverage(fg)
            if (cover < BackgroundSwap.MIN_SUBJECT || cover > BackgroundSwap.MAX_SUBJECT) {
                ui { copy(status = "Không tách được chủ thể rõ ràng (chiếm ${(cover * 100).roundToInt()}% ảnh) nên không thay nền để tránh làm hỏng ảnh. Có thể tô vùng nền rồi mô tả cảnh.") }
                return@launchTask
            }
            val grow = BackgroundSwap.growFor(w, h)
            val mask = withContext(Dispatchers.Default) { BackgroundSwap.backgroundMask(fg, w, h, grow) }
            val gen = fillWithRouting(base, mask, BackgroundScene.generationPrompt(scene), st, notes)
            if (gen.width != w || gen.height != h) error("dịch vụ trả ảnh sai kích thước ${gen.width}×${gen.height}")
            val result = withContext(Dispatchers.Default) {
                makeBitmap(BackgroundSwap.composite(readPixels(base), readPixels(gen), fg, w, h, grow, BackgroundSwap.featherFor(w, h)), w, h)
            }
            notes.add("Chủ thể ${(cover * 100).roundToInt()}% ảnh được giữ nguyên.")
            offerPatch(GenKind.FILL, base, result, "Thay nền: ${scene.take(20)}", notes, retryTip = true)
        }
    }

    /**
     * Xóa người lạ (PDF): nhận diện mọi khuôn mặt → giữ nhóm có mặt lớn nhất (chủ thể), xóa những người nhỏ hơn hẳn (xa/phía sau) bằng
     * chuỗi xóa vật thể theo độ khó. Người quay lưng / che mặt / mặt quá nhỏ không nhận ra được → báo rõ để người dùng tô tay.
     */
    private fun runStrangerRemoval() {
        launchTask("Đang tìm người lạ để xóa…") {
            val bgFull = bg ?: return@launchTask
            val st = _state.value
            val notes = ArrayList<String>()
            val hasFace = File(modelDir, FACE_FILE).exists()
            val hasPerson = File(modelDir, PERSON_FILE).exists()
            if (!hasFace && !hasPerson) {
                ui { copy(status = "Cần nạp model face_landmarker.task (nhận mặt) và/hoặc efficientdet_lite0.tflite (nhận cả người quay lưng) trong Cài đặt để nhận ra người trong ảnh. Hoặc bật \"Tô vùng\", tô lên người cần xóa rồi bấm gửi.") }
                return@launchTask
            }
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val built = withContext(Dispatchers.Default) {
                val faces = if (hasFace) ensureFace()?.detect(base).orEmpty() else emptyList()
                // lỗi bộ phát hiện người không làm hỏng cả tính năng: rơi về chỉ dùng khuôn mặt
                val people = if (hasPerson) runCatching { ensurePerson()?.detect(base) }.getOrNull() else null
                val fg = runCatching { currentSeg()?.foregroundMask(base) }.getOrNull()
                val found = StrangerMask.analyze(faces, people, base.width, base.height).let { it.keep.size + it.drop.size }
                Pair(found, StrangerMask.build(faces, base.width, base.height, fg, people))
            }
            val found = built.first
            val res = built.second
            if (found == 0) {
                ui { copy(status = "Không thấy ai trong ảnh. Hãy bật \"Tô vùng\" và tô lên người cần xóa.") }
                return@launchTask
            }
            if (res == null) {
                val tail = if (hasPerson) "Người quá nhỏ/ở xa hoặc bị che gần hết thì bật \"Tô vùng\" và tô tay."
                else "Người quay lưng hoặc che mặt thì nạp efficientdet_lite0.tflite (Cài đặt) hoặc bật \"Tô vùng\" và tô tay."
                ui { copy(status = "Chỉ thấy $found người cùng cỡ (không có ai nhỏ/xa hơn hẳn) nên không có \"người lạ\" để xóa. $tail") }
                return@launchTask
            }
            notes.add("Giữ ${res.kept} người (cỡ lớn nhất), xóa ${res.removed} người ở xa hơn (${(res.coverage * 100).roundToInt()}% ảnh).")
            if (res.detectorOnly > 0) notes.add("${res.detectorOnly} người bị xóa là người quay lưng/che mặt (nhận bằng hộp người, không thấy mặt).")
            notes.add(
                if (hasPerson) "Người quá nhỏ/ở xa hoặc bị che gần hết có thể chưa nhận ra — nếu còn sót, tô thêm rồi xóa."
                else "Người quay lưng hoặc mặt quá nhỏ không nhận ra được (nạp efficientdet_lite0.tflite để nhận người quay lưng) — nếu còn sót, tô thêm rồi xóa."
            )
            val result = removeWithRouting(base, res.mask, notes)
            offerPatch(GenKind.REMOVE, base, result, "Xóa người lạ", notes, retryTip = false)
        }
    }

    /**
     * [exact] = vùng lấp phải đúng bằng mặt nạ, không nới/hòa vào ảnh cũ — áp dụng cho MỌI engine (cổ điển, PatchMatch, LaMa, MI-GAN):
     * mở rộng ảnh (ảnh gốc không được bị đụng tới) và "Xóa đúng vùng tô".
     */
    private suspend fun removeWithRouting(base: Bitmap, mask: ByteArray, notes: MutableList<String>, exact: Boolean = false): Bitmap {
        val all = chain("inpaint_remove")
        if (all.isEmpty()) error("Không có engine xóa vật thể khả dụng (kiểm tra cấu hình định tuyến).")
        // Đo độ khó của vùng xóa (kích thước + độ phức tạp nền quanh nó) rồi để cấu hình định tuyến chọn engine:
        // việc dễ → PatchMatch nhanh, không cần nạp model; việc khó → model thần kinh (nếu đã nạp).
        val report = withContext(Dispatchers.Default) { InpaintComplexity.analyze(base, mask) }
        val candidates = Routing.forDifficulty(all, report.difficulty)
        notes.add(report.describe())
        var lastErr: Throwable? = null
        for (p in candidates) {
            val engine: Inpainter = withContext(Dispatchers.Default) {
                when (p.kind) {
                    "lama_onnx" -> runCatching { ensureLama() }.getOrNull()
                    "migan_onnx" -> runCatching { ensureMigan() }.getOrNull()
                    "patchmatch_fill" -> PatchMatchInpaint(
                        maxWorkHolePx = p.params["max_work_hole_px"]?.toIntOrNull() ?: 90_000,
                        maxCropSide = p.params["max_crop_side"]?.toIntOrNull() ?: 1280
                    )
                    "classic_fill" -> ClassicInpaint
                    else -> null
                }
            } ?: continue
            try {
                val out = withContext(Dispatchers.Default) { TiledInpaint.run(base, mask, engine, exact = exact) }
                notes.add("Engine: ${p.id}.")
                return out
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                lastErr = e
                notes.add("${p.id} lỗi (${e.message ?: e.javaClass.simpleName}) → thử engine kế tiếp.")
            }
        }
        throw lastErr ?: IllegalStateException("Không xóa được vật thể.")
    }

    /**
     * Mở rộng ảnh (R20): nới khung theo [arg] (xem [Outpaint]) rồi lấp phần mới. Thứ tự: dịch vụ sinh ảnh nếu đã cấu hình
     * (proxy / SD cục bộ / Gemini / SD WebUI; phần mới sinh từ ngữ cảnh, ảnh gốc được ghép lại nguyên vẹn) → rơi về chuỗi xóa vật thể
     * theo cấu hình (LaMa / MI-GAN / PatchMatch / push-pull; chọn theo độ khó). Không yêu cầu model hay dịch vụ nào cụ thể.
     */
    private suspend fun outpaintBitmap(src: Bitmap, arg: String?, notes: MutableList<String>): Bitmap {
        val w = src.width
        val h = src.height
        val plan = Outpaint.resolve(arg, w, h)?.let { Outpaint.plan(w, h, it, perf.maxSide) }
        if (plan == null) {
            notes.add("Không cần mở rộng (ảnh đã đúng tỉ lệ hoặc yêu cầu không hợp lệ).")
            return src
        }
        val orig = withContext(Dispatchers.Default) { readPixels(src) }
        val tmp = ArrayList<String>()
        var result: IntArray? = null
        var rw = 0
        var rh = 0
        if (chain("generative_fill").isNotEmpty()) {
            try {
                val cv = withContext(Dispatchers.Default) { Outpaint.makeCanvas(orig, w, h, plan, blurPrefill = true) }
                val base = withContext(Dispatchers.Default) { makeBitmap(cv.px, cv.w, cv.h) }
                val gen = fillWithRouting(base, cv.mask, OUTPAINT_PROMPT, _state.value, tmp)
                if (gen.width != cv.w || gen.height != cv.h) error("dịch vụ trả ảnh sai kích thước ${gen.width}×${gen.height}")
                result = withContext(Dispatchers.Default) {
                    Outpaint.composite(cv.px, readPixels(gen), cv.mask, cv.w, cv.h, band = max(3, max(cv.w, cv.h) / 300))
                }
                rw = cv.w; rh = cv.h
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                if (cancelled) throw e
                tmp.add("Dịch vụ sinh ảnh lỗi (${e.message ?: e.javaClass.simpleName}) → dùng engine cục bộ.")
                result = null
            }
        }
        if (result == null) {
            val cv = withContext(Dispatchers.Default) { Outpaint.makeCanvas(orig, w, h, plan, blurPrefill = false) }
            val base = withContext(Dispatchers.Default) { makeBitmap(cv.px, cv.w, cv.h) }
            val filled = removeWithRouting(base, cv.mask, tmp, exact = true)
            result = withContext(Dispatchers.Default) {
                // ảnh gốc giữ nguyên tuyệt đối (engine "học" từ nó nhưng không được đổi nó)
                Outpaint.composite(cv.px, readPixels(filled), cv.mask, cv.w, cv.h, band = 0)
            }
            rw = cv.w; rh = cv.h
        }
        notes.add("Mở rộng khung ${w}×${h} → ${rw}×${rh}.")
        notes.addAll(tmp.distinct())
        val finalPx = result ?: return src
        return withContext(Dispatchers.Default) { makeBitmap(finalPx, rw, rh) }
    }

    private suspend fun fillWithRouting(
        base: Bitmap, mask: ByteArray, prompt: String, st: UiState, notes: MutableList<String>,
        instructionOnly: Boolean = false, sdPrompt: String? = null, optsOverride: ((GenOptions) -> GenOptions)? = null
    ): Bitmap {
        val preferred = if (st.genProvider == GenProvider.LAN_SD) "sd_webui" else "gemini_cloud"
        // Máy chủ của bạn (proxy) luôn ưu tiên số 1 khi đã đăng ký; sau đó đến nhà cung cấp người dùng chọn.
        val candidates = chain("generative_fill").sortedBy {
            when (it.kind) {
                "sdcpp_local" -> 0   // chạy trên máy: riêng tư, không tốn credits; lỗi/chậm thì rơi sang đám mây
                "proxy_cloud" -> 1
                preferred -> 2
                else -> 3
            }
        }
        if (candidates.isEmpty()) {
            error("Chưa cấu hình dịch vụ tạo ảnh (API key Gemini hoặc máy chủ SD) trong Cài đặt.")
        }
        var lastErr: Throwable? = null
        for (p in candidates) {
            val backend: GenerativeFill = when (p.kind) {
                "gemini_cloud" -> {
                    val picked = if (st.genQuality == GenQuality.HIGH) p.params["model_high"] else p.params["model_fast"]
                    val model = if (st.cloudModel != GeminiImageBackend.DEFAULT_MODEL) st.cloudModel
                    else (picked ?: p.params["model"] ?: st.cloudModel)
                    GeminiImageBackend(st.cloudKey.trim(), model)
                }
                "sdcpp_local" -> {
                    val model = sdModelFile(p.params["slot"] ?: "sd_inpaint") ?: continue
                    val loras = File(modelDir, LORA_DIR).takeIf { it.isDirectory }
                    val extra = File(modelDir, "sdextra").takeIf { it.isDirectory }
                    touch("sdlocal")
                    LocalSdBackend(localSd, model.absolutePath, perf.threads, loras?.absolutePath, extra?.absolutePath, p.params)
                }
                "proxy_cloud" -> ProxyBackend(st.proxyUrl, st.proxyToken)
                "sd_webui" -> SdWebUiBackend(st.sdUrl)
                else -> continue
            }
            val isSd = p.kind == "sd_webui" || p.kind == "sdcpp_local"
            if (isSd && instructionOnly && sdPrompt == null) {
                // SD diễn giải prompt như MÔ TẢ ảnh, không hiểu lệnh "xóa X": bỏ qua thay vì cho kết quả bậy
                notes.add("${p.id} không làm được lệnh dạng chỉ dẫn (xóa phản chiếu / bóng đổ); cần Gemini hoặc máy chủ của bạn.")
                continue
            }
            activeBackend = backend
            val finalPrompt = if (isSd) {
                if (sdPrompt != null) sdPrompt else withContext(Dispatchers.Default) {
                    val l = runCatching { ensureLlm() }.getOrNull()
                    if (l == null) prompt else runCatching { l.translateToEnglish(prompt) }.getOrDefault(prompt)
                }
            } else prompt
            try {
                val opts = genOptions(st).let { o -> if (optsOverride != null) optsOverride(o) else o }
                val out = withContext(Dispatchers.IO) { backend.inpaint(base, mask, finalPrompt, st.sdSize, opts) }
                notes.add("Dịch vụ: ${p.id}.")
                (backend as? ProxyBackend)?.credits?.let { c -> ui { copy(credits = c) } }
                return out
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                if (cancelled) throw e
                lastErr = e
                notes.add("${p.id} lỗi (${e.message ?: e.javaClass.simpleName}).")
            }
        }
        throw lastErr ?: IllegalStateException("Không tạo được ảnh.")
    }

    fun applyPending() {
        val p = pending ?: return
        pushUndo()
        pending = null
        selectionMask = null
        ui {
            copy(
                layers = layers + p, activeId = p.id, genKind = null, strokes = emptyList(),
                selection = null, tapPoints = emptyList(),
                paintMode = PaintMode.OFF, prompt = "", status = "Đã áp dụng thành lớp \"${p.name}\"."
            )
        }
        requestRender()
    }

    fun discardPending() {
        pending = null
        ui { copy(genKind = null, status = "Đã bỏ kết quả.") }
        requestRender()
    }

    // ------------------------------------------------------------------ xuất ảnh
    fun save() {
        val bgFull = bg ?: return
        launchTask("Đang xuất ảnh…") {
            val stack = _state.value.layers + listOfNotNull(pending)
            val notes = ArrayList<String>()
            val where = withContext(Dispatchers.Default) {
                val rendered = Compositor.render(bgFull, stack, bgFull.width, currentSeg(), false, notes)
                // Gói Free khi dùng máy chủ thương mại: đóng dấu mờ; chế độ cá nhân (không máy chủ) hoặc gói Pro: không đóng dấu
                val st = _state.value
                val flat = if (Monetization.needsWatermark(st.proxyUrl.isNotBlank() && st.proxyToken.isNotBlank(), st.isPro)) Watermark.apply(rendered) else rendered
                ImageIO.saveToGallery(appCtx, flat, ImageIO.hasTransparency(flat))
            }
            ui { copy(status = "Đã lưu: $where") }
        }
    }

    // ------------------------------------------------------------------ dịch vụ tạo ảnh
    fun setSdUrl(url: String) {
        prefs.edit().putString(KEY_URL, url).apply()
        ui { copy(sdUrl = url) }
        refreshRoutingSummary()
    }

    fun setSdSize(size: Int) {
        prefs.edit().putInt(KEY_SIZE, size).apply()
        ui { copy(sdSize = size) }
    }

    fun setGenProvider(p: GenProvider) {
        prefs.edit().putString(KEY_PROVIDER, p.name).apply()
        ui { copy(genProvider = p, serverInfo = "") }
    }

    fun setCloudKey(key: String) {
        putSecret(KEY_CLOUD_KEY, key)
        ui { copy(cloudKey = key) }
        refreshRoutingSummary()
    }

    fun setCloudModel(model: String) {
        prefs.edit().putString(KEY_CLOUD_MODEL, model).apply()
        ui { copy(cloudModel = model) }
    }

    fun testServer() {
        val st = _state.value
        viewModelScope.launch {
            ui { copy(serverInfo = "Đang kiểm tra…") }
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    when (st.genProvider) {
                        GenProvider.CLOUD_GEMINI -> {
                            if (st.cloudKey.isBlank()) error("Chưa nhập API key.")
                            GeminiImageBackend(st.cloudKey.trim(), st.cloudModel).ping()
                        }
                        GenProvider.LAN_SD -> {
                            if (st.sdUrl.isBlank()) error("Chưa nhập địa chỉ máy chủ.")
                            SdWebUiBackend(st.sdUrl).ping()
                        }
                    }
                }
            }
            ui { copy(serverInfo = r.fold({ it }, { "Không kết nối được: ${it.message ?: it.javaClass.simpleName}" })) }
        }
    }

    // ------------------------------------------------------------------ cấu hình định tuyến
    fun setRoutingUrl(url: String) {
        prefs.edit().putString(KEY_ROUTING_URL, url).apply()
        ui { copy(routingUrl = url) }
    }

    fun updateRouting() {
        val url = _state.value.routingUrl.trim()
        viewModelScope.launch {
            ui { copy(status = "Đang tải cấu hình định tuyến…") }
            val r = withContext(Dispatchers.IO) {
                runCatching { Routing.saveValidated(appCtx, Routing.fetch(url)) }
            }
            r.onSuccess { routing = it }
            refreshRoutingSummary()
            ui { copy(status = r.fold({ "Đã cập nhật cấu hình định tuyến." }, { "Không cập nhật được: ${it.message ?: it.javaClass.simpleName}" })) }
        }
    }

    fun importRouting(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val text = appCtx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Không đọc được tệp")
                    Routing.saveValidated(appCtx, text)
                }
            }
            r.onSuccess { routing = it }
            refreshRoutingSummary()
            ui { copy(status = r.fold({ "Đã nạp cấu hình định tuyến từ tệp." }, { "Cấu hình không hợp lệ: ${it.message ?: it.javaClass.simpleName}" })) }
        }
    }

    fun resetRouting() {
        routing = runCatching { Routing.reset(appCtx) }.getOrDefault(routing)
        refreshRoutingSummary()
        ui { copy(status = "Đã khôi phục cấu hình định tuyến mặc định.") }
    }

    // ------------------------------------------------------------------ quản lý model cục bộ
    private fun restoreModels() {
        // Chỉ model tách nền nhỏ được nạp sẵn (IS-Net chất lượng cao nếu có và máy đủ RAM, không thì U²-Net-P ~5 MB);
        // LLM, LaMa, MI-GAN, SAM, ESRGAN, Face Landmarker nạp lười khi dùng (xem ModelPool).
        loadSegmenterFromRouting()
        ui {
            copy(
                segReady = segmenter != null,
                segHqReady = File(modelDir, SEG_HQ_FILE).exists(),
                faceReady = File(modelDir, FACE_FILE).exists(),
                hairReady = File(modelDir, HAIR_FILE).exists(),
                personReady = File(modelDir, PERSON_FILE).exists(),
                depthReady = File(modelDir, DEPTH_FILE).exists(),
                favTools = prefs.getStringSet(KEY_FAV, emptySet())?.toSet() ?: emptySet(),
                portraitReady = File(modelDir, SEG_PORTRAIT_FILE).exists(),
                lamaReady = File(modelDir, LAMA_FILE).exists(),
                miganReady = File(modelDir, MIGAN_FILE).exists(),
                esrganReady = File(modelDir, ESRGAN_FILE).exists(),
                samReady = samFilesPresent(),
                llmReady = llmFile() != null,
                sdLocalBinary = localSd.binaryPresent(),
                sdLocalModel = sdLocalModelFile() != null
            )
        }
    }

    fun importLlm(uri: Uri) {
        viewModelScope.launch {
            ui { copy(llmLoading = true, status = "Đang sao chép model LLM (vài trăm MB, có thể mất vài phút)…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    llm?.close()
                    llm = null
                    val isLiteRt = displayName(uri)?.endsWith(".litertlm", ignoreCase = true) == true
                    val dest = File(modelDir, if (isLiteRt) LLM_LITERTLM_FILE else LLM_FILE)
                    val other = File(modelDir, if (isLiteRt) LLM_FILE else LLM_LITERTLM_FILE)
                    other.delete()                                                                  // chỉ giữ MỘT model LLM
                    File(other.absolutePath + ".name").delete()
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        // giữ tên tệp GỐC: hậu tố SoC cho biết đây có phải bản NPU biên dịch cho đúng chip này (AcceleratorPolicy)
                        LlmBackends.writeOriginalName(dest.absolutePath, displayName(uri))
                        llm = LlmPlanner(appCtx, dest.absolutePath)
                        touch("llm")
                    } catch (e: Throwable) {
                        dest.delete()
                        File(dest.absolutePath + ".name").delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    llmLoading = false,
                    llmReady = llm != null,
                    llmBackend = llm?.backendName.orEmpty(),
                    status = result.fold(
                        { "Đã nạp LLM cục bộ - prompt tự do sẽ do AI hiểu và dịch sang tiếng Anh cho bước tạo ảnh." },
                        { "Không nạp được LLM: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** Chọn model tách nền đầu tiên khả dụng theo định tuyến `segment` (isnet_onnx → u2net_onnx), lỗi thì thử cái kế. */
    private fun loadSegmenterFromRouting() {
        segmenter?.close()
        segmenter = null
        segChoice = null
        for (p in chain("segment")) {
            val isnet = p.kind == "isnet_onnx"
            if (!isnet && p.kind != "u2net_onnx") continue
            val f = File(modelDir, if (isnet) SEG_HQ_FILE else SEG_FILE)
            if (!f.exists()) continue
            val m = runCatching { trackLoad(if (isnet) "isnet" else "u2net") { OnnxSegmenter(f.absolutePath, if (isnet) "isnet" else "u2net") } }.getOrNull()
            if (m != null) {
                segmenter = m
                return
            }
        }
    }

    private fun importSegFile(uri: Uri, fileName: String, profile: String, label: String) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model $label…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    segmenter?.close()
                    segmenter = null
                    val dest = File(modelDir, fileName)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        OnnxSegmenter(dest.absolutePath, profile).close() // kiểm tra nạp được rồi mới giữ tệp
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    loadSegmenterFromRouting()
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    segReady = segmenter != null,
                    segHqReady = File(modelDir, SEG_HQ_FILE).exists(),
                    status = result.fold(
                        { "Đã nạp model $label." },
                        { "Không nạp được model $label: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    fun importSegmenter(uri: Uri) = importSegFile(uri, SEG_FILE, "u2net", "tách nền")

    /** IS-Net (DIS, tệp isnet-general-use.onnx của rembg, 1024px): tách nền/chọn chủ thể chính xác hơn U²-Net-P. */
    fun importSegmenterHq(uri: Uri) = importSegFile(uri, SEG_HQ_FILE, "isnet", "tách nền chất lượng cao (IS-Net)")

    /**
     * MODNet (Apache-2.0; ONNX xuất từ bản chính thức, input `input [batch,3,H,W]` → output `output [batch,1,H,W]`):
     * tách nền CHÂN DUNG chi tiết hơn (tóc). Chỉ được dùng khi ảnh có khuôn mặt (cần nạp thêm Face Landmarker).
     */
    fun importPortrait(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model chân dung (MODNet)…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    portraitSeg?.close()
                    portraitSeg = null
                    segChoice = null
                    val dest = File(modelDir, SEG_PORTRAIT_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        OnnxSegmenter(dest.absolutePath, SegProfile.MODNET).close() // kiểm tra nạp được rồi mới giữ tệp
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    portraitReady = File(modelDir, SEG_PORTRAIT_FILE).exists(),
                    status = result.fold(
                        { "Đã nạp MODNet - dùng cho ảnh chân dung (cần model khuôn mặt để nhận biết chân dung)." },
                        { "Không nạp được MODNet: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** Face Landmarker (face_landmarker.task, MediaPipe): dựng mặt nạ da/mắt/răng/quầng thâm từ 478 điểm khuôn mặt. */
    fun importFace(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model khuôn mặt…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    face?.close()
                    face = null
                    faceCache = null
                    val dest = File(modelDir, FACE_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        face = FaceLandmarkerEngine(appCtx, dest.absolutePath)
                        touch("face")
                    } catch (e: Throwable) {
                        dest.delete()
                        face = null
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    faceReady = File(modelDir, FACE_FILE).exists() && face != null,
                    status = result.fold(
                        { "Đã nạp model khuôn mặt - dùng Công cụ → Cục bộ (Da mặt, Mắt, Răng, Quầng thâm) hoặc gõ \"làm trắng răng\"." },
                        { "Không nạp được model khuôn mặt: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** Nút nhanh: tạo lớp chỉnh theo vùng khuôn mặt với phép chỉnh mặc định (chỉnh tiếp bằng thanh trượt). */
    fun addFaceLayer(scope: String) {
        val bgFull = bg ?: return
        if (!Scope.needsFace(scope)) return
        val ops = when (scope) {
            Scope.SKIN -> listOf(EditOp(OpType.FREQ_SEP, 0.6f), EditOp(OpType.SKIN_SMOOTH, 0.3f))
            Scope.EYES -> listOf(EditOp(OpType.BRIGHTNESS, 0.15f), EditOp(OpType.CLARITY, 0.35f))
            Scope.TEETH -> listOf(EditOp(OpType.BRIGHTNESS, 0.22f), EditOp(OpType.SATURATION, -0.45f))
            Scope.FACE_LIGHT -> listOf(EditOp(OpType.BRIGHTNESS, 0.20f))
            Scope.FACE_SHADOW -> listOf(EditOp(OpType.BRIGHTNESS, -0.20f))
            else -> listOf(EditOp(OpType.SHADOWS, 0.55f), EditOp(OpType.BRIGHTNESS, 0.10f))
        }
        launchTask("Đang nhận diện khuôn mặt…") {
            val notes = ArrayList<String>()
            val mask = maskForScope(scope, bgFull, notes)
            if (mask != null) {
                addLocal(Scope.label(scope), mask, ops, scope)
            } else if (scope == Scope.SKIN) {
                // dự phòng: không có model/khuôn mặt -> lớp retouch da toàn ảnh (ImageEngine tự giới hạn theo màu da)
                pushUndo()
                val l = AdjustmentLayer(newId(), "Da (ước lượng màu da)", ops, kind = "local")
                ui { copy(layers = layers + l, activeId = l.id, panel = Panel.TOOLS, status = notes.firstOrNull().orEmpty() + " Đã dùng nhận diện màu da thay thế.") }
                requestRender()
            } else {
                ui { copy(status = notes.firstOrNull() ?: "Không dựng được vùng.") }
            }
        }
    }

    fun importLama(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model xóa vật thể (LaMa)…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    lama?.close()
                    lama = null
                    val dest = File(modelDir, LAMA_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        lama = LamaInpainter(dest.absolutePath)
                        touch("lama")
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    lamaReady = lama != null,
                    status = result.fold(
                        { "Đã nạp model xóa vật thể. Mở thẻ AI → Tô vùng → tô lên vật thể → Chỉnh." },
                        { "Không nạp được model LaMa: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    private fun displayName(uri: Uri): String? = runCatching {
        appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    /** Model inpainting SD 1.5 dạng .gguf/.safetensors/.ckpt (có thể vài GB) cho sd-server chạy trên máy. */
    fun importSdLocalModel(uri: Uri) = importSdSlot(uri, "sd_inpaint")

    /** FLUX.2 [klein] 4B (Apache-2.0): file diffusion-model .gguf. Cần thêm LLM (Qwen3) và VAE ở mục tệp phụ. */
    fun importSdKlein(uri: Uri) = importSdSlot(uri, "sd_klein")

    /** Tệp phụ cho model nhiều thành phần: which = "llm" | "vae" (lưu vào thư mục sdextra). */
    fun importSdExtra(uri: Uri, which: String) {
        viewModelScope.launch {
            ui { copy(status = "Đang sao chép tệp phụ ($which)…") }
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    localSd.stop()
                    val dir = File(modelDir, "sdextra").apply { mkdirs() }
                    dir.listFiles()?.filter { it.name.startsWith("$which.") }?.forEach { it.delete() }
                    val ext = displayName(uri)?.substringAfterLast('.', "gguf")?.lowercase() ?: "gguf"
                    ImageIO.copyUriToFile(appCtx, uri, File(dir, "$which.$ext"))
                    Unit
                }
            }
            ui { copy(status = r.fold({ "Đã nạp tệp phụ $which." }, { "Không nạp được: ${it.message ?: it.javaClass.simpleName}" })) }
        }
    }

    private fun importSdSlot(uri: Uri, slot: String) {
        viewModelScope.launch {
            ui { copy(status = "Đang sao chép model tạo ảnh trên máy (có thể vài GB)…") }
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    localSd.stop()
                    modelDir.listFiles()?.filter { it.name.startsWith("$slot.") }?.forEach { it.delete() }
                    val ext = displayName(uri)?.substringAfterLast('.', "gguf")?.lowercase()
                        ?.takeIf { it in setOf("gguf", "safetensors", "ckpt", "pt", "pth") } ?: "gguf"
                    ImageIO.copyUriToFile(appCtx, uri, File(modelDir, "$slot.$ext"))
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    sdLocalModel = sdLocalModelFile() != null,
                    status = r.fold(
                        {
                            if (localSd.binaryPresent()) "Đã nạp model. Lần tạo ảnh đầu tiên sẽ nạp model vào RAM (chậm)."
                            else "Đã lưu model, nhưng APK này chưa kèm sd-server (xem job build-sd-server của CI)."
                        },
                        { "Không nạp được model: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** LoRA LCM (tùy chọn) để tạo ảnh chỉ vài bước. */
    fun importSdLora(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = File(modelDir, LORA_DIR).apply { mkdirs() }
                    ImageIO.copyUriToFile(appCtx, uri, File(dir, LORA_FILE))
                    Unit
                }
            }
            ui { copy(status = r.fold({ "Đã nạp LoRA LCM (tạo ảnh ít bước hơn)." }, { "Không nạp được LoRA: ${it.message ?: it.javaClass.simpleName}" })) }
        }
    }

    fun stopLocalSd() {
        localSd.stop()
        ui { copy(status = "Đã giải phóng RAM của tiến trình tạo ảnh trên máy.") }
    }

    fun importEsrgan(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model phóng to AI…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    esrgan?.close()
                    esrgan = null
                    val dest = File(modelDir, ESRGAN_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        esrgan = OnnxUpscaler(dest.absolutePath)
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    esrganReady = esrgan != null,
                    status = result.fold(
                        { "Đã nạp model phóng to AI. Mở Cắt/Xoay → Phóng to ×2 hoặc ×4." },
                        { "Không nạp được model phóng to: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    fun importMigan(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model MI-GAN…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    migan?.close()
                    migan = null
                    val dest = File(modelDir, MIGAN_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        migan = MiganInpainter(dest.absolutePath)
                        touch("migan")
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    miganReady = migan != null,
                    status = result.fold(
                        { "Đã nạp MI-GAN (xóa vật thể nhẹ, nhanh)." },
                        { "Không nạp được MI-GAN: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    // ------------------------------------------------------------------ chạm để chọn vật thể (MobileSAM)
    private fun loadSam(strict: Boolean) {
        val e = File(modelDir, SAM_ENC_FILE)
        val d = File(modelDir, SAM_DEC_FILE)
        if (!e.exists() || !d.exists()) return
        if (strict) { sam = SamSegmenter(e.absolutePath, d.absolutePath); touch("sam") }
        else runCatching { sam = SamSegmenter(e.absolutePath, d.absolutePath); touch("sam") }
    }

    private fun importSamFile(uri: Uri, fileName: String) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model chọn vật thể…") }
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    sam?.close()
                    sam = null
                    ImageIO.copyUriToFile(appCtx, uri, File(modelDir, fileName))
                    loadSam(strict = true)
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    samReady = sam != null,
                    status = r.fold(
                        { if (sam != null) "Đã nạp đủ 2 tệp SAM - bật \"Chạm chọn\" ở thẻ AI." else "Đã nạp 1 tệp; cần cả encoder lẫn decoder." },
                        { "Không nạp được SAM: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    fun importSamEncoder(uri: Uri) = importSamFile(uri, SAM_ENC_FILE)
    fun importSamDecoder(uri: Uri) = importSamFile(uri, SAM_DEC_FILE)

    private fun selectionOverlay(m: ByteArray, w: Int, h: Int): Bitmap {
        val pv = previewHi ?: return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val pw = pv.width
        val ph = pv.height
        val px = IntArray(pw * ph)
        for (y in 0 until ph) {
            val sy = minOf(h - 1, y * h / ph)
            for (x in 0 until pw) {
                val sx = minOf(w - 1, x * w / pw)
                if (m[sy * w + sx].toInt() != 0) px[y * pw + x] = 0x8800B0FF.toInt()
            }
        }
        return makeBitmap(px, pw, ph)
    }

    /** Đũa thần cổ điển cho từng điểm chạm (hợp các vùng) - đường dự phòng khi chưa nạp / lỗi MobileSAM. */
    private fun wandSelect(b: Bitmap, pts: List<Pt>): ByteArray {
        val px = readPixels(b)
        val out = ByteArray(b.width * b.height)
        for (pt in pts) {
            val m = MagicWand.select(px, b.width, b.height, (pt.x * b.width).toInt(), (pt.y * b.height).toInt())
            for (i in out.indices) if (m[i].toInt() != 0) out[i] = 255.toByte()
        }
        return out
    }

    /**
     * Chạm lên vật thể để chọn (chạm thêm = mở rộng vùng chọn). Có MobileSAM thì dùng SAM (lần đầu mất vài giây để mã hóa ảnh);
     * chưa nạp SAM hoặc SAM lỗi thì rơi về đũa thần theo màu (nguyên tắc "mọi tác vụ AI đều có đường dự phòng").
     */
    fun tapSelect(p: Pt) {
        val bgFull = bg ?: return
        val useSam = samFilesPresent()
        val pts = _state.value.tapPoints + p
        launchTask(if (useSam) "Đang chọn vật thể…" else "Đang chọn vùng (đũa thần)…") {
            var usedWand = !useSam
            val m = withContext(Dispatchers.Default) {
                var res: ByteArray? = null
                if (useSam) {
                    try {
                        res = ensureSam()?.select(bgFull, pts)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        res = null
                    }
                }
                if (res == null) usedWand = true
                res ?: wandSelect(bgFull, pts)
            }
            selectionMask = m
            val overlay = withContext(Dispatchers.Default) { selectionOverlay(m, bgFull.width, bgFull.height) }
            ui {
                copy(
                    tapPoints = pts, selection = overlay,
                    status = (if (usedWand) "Đã chọn vùng cùng màu (đũa thần; nạp MobileSAM để chọn theo vật thể chính xác hơn). " else "Đã chọn. ") +
                        "Chạm thêm để mở rộng; mở thẻ AI → Chỉnh (trống = xóa) hoặc mô tả để thay; hoặc \"Tạo lớp cục bộ\"."
                )
            }
        }
    }

    fun clearSelection() {
        selectionMask = null
        ui { copy(selection = null, tapPoints = emptyList()) }
    }

    fun addLocalFromSelection() {
        val m = selectionMask ?: return
        val bgFull = bg ?: return
        addLocal("Vật thể đã chọn", LayerMask(MaskSpec.Painted(m.copyOf(), bgFull.width, bgFull.height), feather = 0.01f))
        clearSelection()
    }

    // ------------------------------------------------------------------ máy chủ trung gian (thương mại): đăng ký, credits, định tuyến từ xa
    fun setProxyUrl(url: String) {
        prefs.edit().putString(KEY_PROXY_URL, url).apply()
        ui { copy(proxyUrl = url) }
        refreshRoutingSummary()
    }

    fun registerProxy() {
        val url = _state.value.proxyUrl.trim()
        if (url.isEmpty()) {
            ui { copy(status = "Chưa nhập địa chỉ máy chủ.") }
            return
        }
        viewModelScope.launch {
            ui { copy(status = "Đang đăng ký với máy chủ…") }
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val id = prefs.getString(KEY_DEVICE_ID, null) ?: java.util.UUID.randomUUID().toString().also {
                        prefs.edit().putString(KEY_DEVICE_ID, it).apply()
                    }
                    ProxyBackend.register(url, id)
                }
            }
            r.onSuccess { pair ->
                putSecret(KEY_PROXY_TOKEN, pair.first)
                ui { copy(proxyToken = pair.first, credits = pair.second) }
            }
            refreshRoutingSummary()
            ui {
                copy(status = r.fold({ Monetization.registeredMessage(it.second) }, { "Không đăng ký được: ${it.message ?: it.javaClass.simpleName}" }))
            }
            if (r.isSuccess) refreshCredits()   // biết ngay máy chủ có cung cấp AI đám mây không (server_ai) để chọn đường gọi đúng
        }
    }

    fun refreshCredits() {
        val st = _state.value
        if (st.proxyUrl.isBlank() || st.proxyToken.isBlank()) return
        viewModelScope.launch {
            // /v1/account trả cả gói Free/Pro; máy chủ cũ chưa có thì rơi về /v1/credits
            val acc = withContext(Dispatchers.IO) { runCatching { ProxyBackend.fetchAccount(st.proxyUrl, st.proxyToken) } }
            if (acc.isSuccess) {
                val a = acc.getOrThrow()
                applyAccount(a.credits, a.plan, a.planUntil)
                ui { copy(team = a.team, betaUsedToday = if (a.openBeta) a.usageToday else -1, betaDailyLimit = if (a.openBeta) a.dailyLimit else 0, serverAiOk = a.serverAi) }
            } else {
                val r = withContext(Dispatchers.IO) { runCatching { ProxyBackend.fetchCredits(st.proxyUrl, st.proxyToken) } }
                r.onSuccess { c -> ui { copy(credits = c) } }
            }
        }
    }

    // ------------------------------------------------------------------ gói Team/Enterprise (R22)
    /** Chạy một lệnh nhóm ở luồng nền: chặn bấm trùng, báo lỗi bằng câu đọc được, rồi làm mới tài khoản (credits dùng được + Pro của nhóm). */
    private fun <T> teamRun(work: (String, String) -> T, onOk: (T) -> Unit) {
        val st = _state.value
        if (st.proxyUrl.isBlank() || st.proxyToken.isBlank()) {
            ui { copy(teamMessage = "Cần đăng ký với máy chủ trước.") }
            return
        }
        if (st.teamBusy) return
        ui { copy(teamBusy = true, teamMessage = "") }
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { work(st.proxyUrl, st.proxyToken) } }
            r.onSuccess { v -> onOk(v) }
            val err = r.exceptionOrNull()
            ui { copy(teamBusy = false, teamMessage = if (err != null) TeamText.friendlyError(err.message) else teamMessage) }
            if (err == null) refreshCredits()
        }
    }

    fun refreshTeam() = teamRun({ u, t -> ProxyBackend.fetchTeam(u, t) }) { t -> ui { copy(team = t) } }

    fun teamJoin(code: String) = teamRun({ u, t -> ProxyBackend.teamJoin(u, t, TeamText.normalizeCode(code)) }) { t ->
        ui { copy(team = t, teamInviteCode = "", teamMessage = if (t != null) "Đã vào nhóm \"${t.name}\"." else "") }
    }

    fun teamCreate(name: String) = teamRun({ u, t -> ProxyBackend.teamCreate(u, t, name.trim()) }) { p ->
        ui { copy(team = p.first, teamInviteCode = p.second, teamMessage = "Đã tạo nhóm. Gửi mã mời cho thành viên (mã chỉ hiện một lần).") }
    }

    fun teamLeave() = teamRun({ u, t -> ProxyBackend.teamLeave(u, t) }) {
        ui { copy(team = null, teamInviteCode = "", teamMessage = "Đã rời nhóm.") }
    }

    fun teamRemove(memberId: String) = teamRun({ u, t -> ProxyBackend.teamRemove(u, t, memberId) }) { t ->
        ui { copy(team = t, teamMessage = "Đã xóa thành viên.") }
    }

    fun teamTransfer(memberId: String) = teamRun({ u, t -> ProxyBackend.teamTransfer(u, t, memberId) }) { t ->
        ui { copy(team = t, teamInviteCode = "", teamMessage = "Đã chuyển quyền quản trị.") }
    }

    fun teamNewInvite() = teamRun({ u, t -> ProxyBackend.teamInvite(u, t) }) { code ->
        ui { copy(teamInviteCode = code, teamMessage = "Mã mời mới (mã cũ hết hiệu lực, chỉ hiện một lần).") }
    }

    fun teamFund(credits: Int) = teamRun({ u, t -> ProxyBackend.teamFund(u, t, credits) }) { p ->
        ui { copy(team = p.first, teamMessage = "Đã nạp $credits credits vào quỹ nhóm.") }
    }

    /** Ghi gói + credits do máy chủ báo vào state và prefs (để lần mở sau / ngoại tuyến vẫn biết là Pro). */
    private fun applyAccount(credits: Int, plan: String, planUntil: Long) {
        prefs.edit().putString(KEY_PLAN, plan).putLong(KEY_PLAN_UNTIL, planUntil).apply()
        ui { copy(credits = credits, plan = plan, planUntil = planUntil) }
    }

    fun setAgentMode(on: Boolean) {
        ui { copy(agentMode = on, status = Monetization.agentModeStatus(on, serverAi = serverAiOk)) }
    }

    /**
     * Ảnh MẪU phong cách cho Agent AI (R30): khi Agent chạy ở máy chủ, nó nhìn cả ảnh mẫu này để suy ra gu màu / tương phản / tông rồi chỉnh ảnh chính theo hướng đó
     * (lời nhắn của bạn vẫn được ưu tiên). Chỉ giữ bản thu nhỏ ≤ 512 px trong bộ nhớ, không ghi ra đĩa; gửi kèm mỗi lần Agent chạy cho tới khi bỏ.
     */
    fun setAgentReference(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ImageIO.decode(appCtx, uri, 512) } }
            r.fold(
                { b ->
                    agentRef = b
                    ui { copy(agentRefReady = true, status = "Đã chọn ảnh mẫu cho Agent AI. Bật Agent AI rồi nhập yêu cầu (vd. \"chỉnh theo phong cách ảnh mẫu\"); ảnh mẫu được gửi lên máy chủ AI cùng ảnh thu nhỏ của bạn.") }
                },
                { e -> ui { copy(status = "Không đọc được ảnh mẫu: ${e.message ?: e.javaClass.simpleName}") } }
            )
        }
    }

    fun clearAgentReference() {
        agentRef = null
        ui { copy(agentRefReady = false, status = "Đã bỏ ảnh mẫu của Agent AI.") }
    }

    // ------------------------------------------------------------------ mua credits / gói Pro (Google Play Billing, bật bằng -PuseBilling=true)
    private fun billingGw(): BillingGateway = billing ?: PlayBillingFactory.create(appCtx).also { billing = it }

    fun loadBillingProducts() {
        val gw = billingGw()
        if (!gw.available) {
            ui { copy(status = "Bản build này chưa bật thanh toán (build với -PuseBilling=true).") }
            return
        }
        gw.connect(
            {
                gw.products(BILLING_PRODUCTS, { list -> ui { copy(billingProducts = list) } }, { m -> ui { copy(status = "Không tải được sản phẩm: $m") } })
                gw.subscriptions(BILLING_SUBSCRIPTIONS, { list -> ui { copy(subscriptionProducts = list) } }, { m -> ui { copy(status = "Không tải được gói đăng ký: $m") } })
            },
            { m -> ui { copy(status = "Không kết nối được Google Play: $m") } }
        )
    }

    fun buy(activity: Activity, productId: String) {
        startPurchase(activity, productId, false)
    }

    /** Đăng ký định kỳ (R14): mua trên Google Play -> /v1/billing/subscribe (máy chủ xác minh bằng subscriptionsv2). */
    fun buySubscription(activity: Activity, productId: String) {
        startPurchase(activity, productId, true)
    }

    private fun startPurchase(activity: Activity, productId: String, subscription: Boolean) {
        val st = _state.value
        val deviceId = prefs.getString(KEY_DEVICE_ID, null)
        if (st.proxyUrl.isBlank() || st.proxyToken.isBlank() || deviceId == null) {
            ui { copy(status = "Cần đăng ký với máy chủ trước khi mua.") }
            return
        }
        val onEvent: (BillingEvent) -> Unit = { ev ->
            when (ev) {
                is BillingEvent.Purchased ->
                    if (subscription) subscribePurchase(ev.productId, ev.token) else redeemPurchase(ev.productId, ev.token)
                BillingEvent.Pending -> ui { copy(status = "Giao dịch đang chờ thanh toán - sẽ cộng sau khi hoàn tất (mở lại Cài đặt → Khôi phục giao dịch).") }
                BillingEvent.Cancelled -> ui { copy(status = "Đã hủy giao dịch.") }
                is BillingEvent.Error -> ui { copy(status = "Lỗi thanh toán: ${ev.message}") }
            }
        }
        if (subscription) billingGw().purchaseSubscription(activity, productId, accountHash(deviceId), onEvent)
        else billingGw().purchase(activity, productId, accountHash(deviceId), onEvent)
    }

    private fun subscribePurchase(productId: String, purchaseToken: String) {
        val st = _state.value
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ProxyBackend.subscribe(st.proxyUrl, st.proxyToken, productId, purchaseToken) } }
            r.onSuccess { res ->
                val a = res.first
                if (res.second == "client") billingGw().acknowledge(purchaseToken) { }   // máy chủ không tự acknowledge (SUBSCRIPTION_ACK=client)
                applyAccount(a.credits, a.plan, a.planUntil)
                ui { copy(status = "Đã kích hoạt đăng ký. Credits: ${a.credits}" + if (a.isPro) " · gói Pro" else "") }
            }
            r.onFailure { e ->
                ui { copy(status = "Đã đăng ký nhưng máy chủ chưa ghi nhận (${e.message ?: e.javaClass.simpleName}). Bấm \"Khôi phục giao dịch\" để thử lại.") }
            }
        }
    }

    private fun redeemPurchase(productId: String, purchaseToken: String) {
        val st = _state.value
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ProxyBackend.redeem(st.proxyUrl, st.proxyToken, productId, purchaseToken) } }
            r.onSuccess { a ->
                billingGw().consume(purchaseToken) { }   // chỉ tiêu thụ SAU khi máy chủ đã ghi nhận
                applyAccount(a.credits, a.plan, a.planUntil)
                ui { copy(status = "Đã nhận quyền lợi. Credits: ${a.credits}" + if (a.isPro) " · gói Pro" else "") }
            }
            r.onFailure { e ->
                ui { copy(status = "Đã trả tiền nhưng chưa đổi được (${e.message ?: e.javaClass.simpleName}). Giao dịch được giữ, bấm \"Khôi phục giao dịch\" để thử lại.") }
            }
        }
    }

    /** Đổi lại các giao dịch đã trả tiền nhưng chưa được ghi nhận (app tắt giữa chừng, mất mạng...). */
    fun restorePurchases() {
        val gw = billingGw()
        if (!gw.available) {
            ui { copy(status = "Bản build này chưa bật thanh toán.") }
            return
        }
        gw.connect(
            { gw.activeSubscriptions { subs ->
                val mine = subs.filter { it.first in BILLING_SUBSCRIPTIONS }
                gw.unconsumed { list ->
                    if (list.isEmpty() && mine.isEmpty()) ui { copy(status = "Không có giao dịch nào cần khôi phục.") }
                    else {
                        list.forEach { (pid, tok) -> redeemPurchase(pid, tok) }
                        mine.forEach { (pid, tok) -> subscribePurchase(pid, tok) }   // báo lại an toàn (idempotent)
                    }
                }
            } },
            { m -> ui { copy(status = "Không kết nối được Google Play: $m") } }
        )
    }

    /** Lấy cấu hình định tuyến + hồ sơ hiệu năng do MÁY CHỦ quyết định cho hạng thiết bị này (không cần cập nhật app). */
    fun syncRoutingFromProxy() {
        val st = _state.value
        if (st.proxyUrl.isBlank() || st.proxyToken.isBlank()) {
            ui { copy(status = "Cần đăng ký với máy chủ trước.") }
            return
        }
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val json = ProxyBackend.fetchRouting(st.proxyUrl, st.proxyToken, perf.tier.name.lowercase(), "1.0")
                    Routing.saveValidated(appCtx, json)
                }
            }
            r.onSuccess {
                routing = it
                perf = computePerf()
                applyPerf()
            }
            refreshRoutingSummary()
            ui {
                copy(status = r.fold(
                    { "Đã đồng bộ cấu hình từ máy chủ (kích thước ảnh áp dụng từ lần mở ảnh sau)." },
                    { "Không đồng bộ được: ${it.message ?: it.javaClass.simpleName}" }
                ))
            }
        }
    }

    // ------------------------------------------------------------------ tùy chọn tạo ảnh (nhanh/chất lượng, seed, prompt phủ định, độ mạnh)
    fun setGenQuality(q: GenQuality) { ui { copy(genQuality = q) } }
    fun setExactRemove(on: Boolean) { ui { copy(exactRemove = on) } }
    fun setGenSeed(v: String) { ui { copy(genSeed = v.filter { it.isDigit() || it == '-' }.take(12)) } }
    fun setGenNegative(v: String) { ui { copy(genNegative = v.take(200)) } }
    fun setGenStrength(v: Float) { ui { copy(genStrength = v) } }

    // ------------------------------------------------------------------ khớp màu với ảnh mẫu + Style DNA
    fun addColorMatch(uri: Uri) {
        if (bg == null) return
        launchTask("Đang phân tích màu ảnh mẫu…") {
            val cdf = withContext(Dispatchers.IO) { ToneOps.histogramCdf(ImageIO.decode(appCtx, uri, 512)) }
            pushUndo()
            val l = AdjustmentLayer(
                newId(), "Khớp màu ảnh mẫu",
                listOf(EditOp(OpType.COLOR_MATCH, 1f, java.util.Base64.getEncoder().encodeToString(cdf))), kind = "look"
            )
            ui { copy(layers = layers + l, activeId = l.id, status = "Đã khớp màu với ảnh mẫu. Kéo Cường độ (độ mờ lớp) để giảm bớt.") }
            requestRender()
        }
    }

    private fun loadStyle() {
        runCatching {
            val o = JSONObject(prefs.getString(KEY_STYLE, "{}").orEmpty())
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                styleMap[k] = floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
            }
        }
        ui { copy(styleReady = styleOps().isNotEmpty()) }
    }

    private fun styleOps(): List<EditOp> = styleMap.mapNotNull { (k, e) ->
        OpType.fromKey(k)?.let { t -> if (e[1] >= 3f && abs(e[0]) > 0.03f) EditOp(t, e[0]) else null }
    }

    /** Học "gu" của người dùng: trung bình trượt (EMA) các giá trị thanh trượt họ chốt ở lớp điều chỉnh cơ bản. */
    private fun recordStyle() {
        val st = _state.value
        val layer = st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer ?: return
        if (layer.kind != "basic") return
        for (op in layer.ops) {
            if (op.arg != null || !op.type.scalable) continue
            val e = styleMap.getOrPut(op.type.key) { floatArrayOf(op.value, 0f) }
            e[0] = if (e[1] == 0f) op.value else 0.8f * e[0] + 0.2f * op.value
            e[1] += 1f
        }
        val o = JSONObject()
        for ((k, e) in styleMap) o.put(k, JSONArray().put(e[0].toDouble()).put(e[1].toDouble()))
        prefs.edit().putString(KEY_STYLE, o.toString()).apply()
        ui { copy(styleReady = styleOps().isNotEmpty()) }
    }

    fun applyStyleDna() {
        val ops = styleOps()
        if (ops.isEmpty() || bg == null) return
        pushUndo()
        val l = AdjustmentLayer(newId(), "Phong cách của tôi", ops, kind = "look")
        ui { copy(layers = layers + l, activeId = l.id, status = "Đã áp dụng phong cách học từ các lần chỉnh của bạn (${ops.size} thông số).") }
        requestRender()
    }

    // ------------------------------------------------------------------ thanh hành động ngữ cảnh sau khi chạm chọn (Select-and-Do)
    fun selectionAction(kind: String) {
        val m = selectionMask ?: return
        val bgFull = bg ?: return
        if (kind == "remove") {
            ui { copy(prompt = "") }
            run()
            return
        }
        if (kind == "move") {
            moveSelection()
            return
        }
        val (name, ops, invert) = when (kind) {
            "blur" -> Triple("Làm mờ vật thể", listOf(EditOp(OpType.BLUR, 0.6f)), false)
            "blurbg" -> Triple("Làm mờ nền", listOf(EditOp(OpType.BLUR, 0.7f)), true)
            "bright" -> Triple("Làm sáng vật thể", listOf(EditOp(OpType.BRIGHTNESS, 0.3f)), false)
            "dark" -> Triple("Làm tối vật thể", listOf(EditOp(OpType.BRIGHTNESS, -0.3f)), false)
            "color" -> Triple("Tăng màu vật thể", listOf(EditOp(OpType.SATURATION, 0.5f)), false)
            "hue" -> Triple("Đổi màu vật thể", listOf(EditOp(OpType.HUE, 0.5f)), false)
            "gray" -> Triple("Đen trắng vật thể", listOf(EditOp(OpType.GRAYSCALE, 1f)), false)
            "graybg" -> Triple("Đen trắng nền (giữ màu vật thể)", listOf(EditOp(OpType.GRAYSCALE, 1f)), true)
            else -> return
        }
        addLocal(name, LayerMask(MaskSpec.Painted(m.copyOf(), bgFull.width, bgFull.height), invert = invert, feather = 0.01f), ops)
        clearSelection()
    }

    // ------------------------------------------------------------------ Di chuyển vật thể (R24)
    /**
     * Vật thể đang chọn → lớp ảnh trong suốt (kéo/chụm/xoay trực tiếp trên khung ảnh) + xóa chỗ cũ bằng engine xóa vật thể.
     * Hai lớp mới (chỗ cũ đã vá, vật thể) nằm trên các lớp hiện có; hoàn tác một lần là về như trước khi bấm.
     */
    private fun moveSelection() {
        val m = selectionMask ?: return
        val bgFull = bg ?: return
        if (m.size != bgFull.width * bgFull.height) return
        launchTask("Đang tách vật thể để di chuyển…") {
            val notes = ArrayList<String>()
            val layersNow = _state.value.layers
            val base = withContext(Dispatchers.Default) { Compositor.render(bgFull, layersNow, bgFull.width, currentSeg(), false, notes) }
            val w = base.width
            val h = base.height
            val cut = withContext(Dispatchers.Default) { MoveObject.cutout(readPixels(base), w, h, m) }
            if (cut == null) {
                ui { copy(status = "Vùng chọn quá nhỏ hoặc quá lớn để di chuyển (cần từ 0,05% đến 85% ảnh). Chạm lại đúng vật thể rồi thử lại.") }
                return@launchTask
            }
            DiagLog.add("di chuyển", "vật thể ${cut.w}×${cut.h} (${"%.1f".format(java.util.Locale.US, cut.coverage * 100)}% ảnh)")
            ui { copy(status = "Đang xóa chỗ cũ của vật thể…") }
            val grown = withContext(Dispatchers.Default) { MoveObject.dilate(m, w, h, MoveObject.growFor(w, h)) }
            val result = removeWithRouting(base, grown, notes, false)
            val hole = withContext(Dispatchers.Default) { Layers.diffPatch(base, result, newId(), "Chỗ cũ của vật thể") }
            val obj = OverlayLayer(
                newId(), "Vật thể (kéo để di chuyển)", "image",
                image = withContext(Dispatchers.Default) { makeBitmap(cut.pixels, cut.w, cut.h) },
                cx = cut.cx, cy = cut.cy, size = cut.size
            )
            pushUndo()
            selectionMask = null
            ui {
                copy(
                    layers = layers + listOfNotNull(hole) + obj, activeId = obj.id, panel = Panel.LAYERS,
                    selection = null, tapPoints = emptyList(),
                    status = "Đã tách vật thể và xóa chỗ cũ. Kéo vật thể bằng một ngón, chụm hai ngón để đổi cỡ / xoay. ${notes.joinToString(" ")}".trim()
                )
            }
            requestRender()
        }
    }

    // ------------------------------------------------------------------ Clone Stamp / Heal Brush
    fun startClone(heal: Boolean) {
        if (bg == null) return
        ui {
            copy(
                paintMode = PaintMode.CLONE, cloneHeal = heal, cloneSource = null, strokes = emptyList(),
                status = "Chạm để chọn điểm NGUỒN, rồi tô vào vùng cần che và bấm \"Áp dụng\"."
            )
        }
    }

    fun setCloneSource(p: Pt) {
        ui { copy(cloneSource = p, status = "Đã chọn nguồn. Tô vào vùng đích rồi bấm \"Áp dụng\".") }
    }

    fun resetCloneSource() {
        ui { copy(cloneSource = null, strokes = emptyList()) }
    }

    fun applyClone() {
        val st = _state.value
        val bgFull = bg ?: return
        val src = st.cloneSource ?: return
        if (st.strokes.isEmpty() || st.busy) return
        val first = st.strokes.first().first()
        launchTask(if (st.cloneHeal) "Đang chữa lành…" else "Đang clone…") {
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) {
                Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes)
            }
            val mask = withContext(Dispatchers.Default) {
                MaskBuilder.build(st.strokes, st.brush, base.width, base.height, "")
            }
            if (mask == null) return@launchTask
            val dx = ((first.x - src.x) * base.width).toInt()
            val dy = ((first.y - src.y) * base.height).toInt()
            val result = withContext(Dispatchers.Default) { CloneTool.apply(base, mask, dx, dy, st.cloneHeal) }
            val patch = withContext(Dispatchers.Default) {
                Layers.diffPatch(base, result, newId(), if (st.cloneHeal) "Heal" else "Clone")
            }
            if (patch == null) {
                ui { copy(status = "Không có thay đổi (nguồn trùng đích?).") }
                return@launchTask
            }
            pending = patch
            ui { copy(genKind = GenKind.CLONE, status = "Xong. Bấm \"Áp dụng\" để giữ kết quả.") }
            requestRender()
        }
    }

    // ------------------------------------------------------------------ Liquify (đẩy điểm ảnh theo nét kéo, không phá hủy)
    fun startLiquify() {
        if (bg == null) return
        val existing = _state.value.layers.filterIsInstance<AdjustmentLayer>().lastOrNull { it.kind == "liquify" }
        val layer = existing ?: AdjustmentLayer(newId(), "Liquify", emptyList(), kind = "liquify").also { created ->
            pushUndo()
            ui { copy(layers = layers + created) }
        }
        ui {
            copy(
                paintMode = PaintMode.LIQUIFY, activeId = layer.id, strokes = emptyList(),
                status = "Kéo ngón tay trên ảnh để đẩy / biến dạng. Thanh \"Cọ\" = vùng ảnh hưởng."
            )
        }
    }

    fun liquifyDrag(a: Pt, b: Pt) {
        val st = _state.value
        val layer = st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer ?: return
        if (layer.kind != "liquify") return
        fun f(v: Float) = String.format(java.util.Locale.US, "%.4f", v)
        val seg = f(a.x) + "," + f(a.y) + "," + f(b.x - a.x) + "," + f(b.y - a.y) + "," + f(st.brush)
        val old = layer.ops.firstOrNull { it.type == OpType.LIQUIFY }?.arg.orEmpty()
        val arg = if (old.isEmpty()) seg else "$old;$seg"
        replaceLayer(layer.copy(ops = listOf(EditOp(OpType.LIQUIFY, 1f, arg))))
    }

    // ------------------------------------------------------------------ Tóc (MediaPipe Hair Segmenter)
    fun importHair(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model tóc…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    hair?.close()
                    hair = null
                    hairCache = null
                    val dest = File(modelDir, HAIR_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        hair = HairSegmenterEngine(appCtx, dest.absolutePath)
                        touch("hair")
                    } catch (e: Throwable) {
                        dest.delete()
                        hair = null
                        throw e
                    }
                    Unit
                }
            }
            ui {
                copy(
                    hairReady = File(modelDir, HAIR_FILE).exists() && hair != null,
                    status = result.fold(
                        { "Đã nạp model tóc - dùng Công cụ → Cục bộ → Tóc, hoặc gõ \"đổi màu tóc nâu\"." },
                        { "Không nạp được model tóc: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** Phát hiện người (efficientdet_lite0.tflite, MediaPipe): để "Xóa người lạ" thấy cả người quay lưng / che mặt. */
    fun importPerson(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model phát hiện người…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    person?.close()
                    person = null
                    val dest = File(modelDir, PERSON_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        person = PersonDetectorEngine(appCtx, dest.absolutePath)
                        touch("person")
                    } catch (e: Throwable) {
                        dest.delete()
                        person = null
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    personReady = File(modelDir, PERSON_FILE).exists() && person != null,
                    status = result.fold(
                        { "Đã nạp model phát hiện người - gõ \"xóa người lạ\" sẽ nhận cả người quay lưng." },
                        { "Không nạp được model phát hiện người: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /**
     * Model đo độ sâu từ một ảnh (R30, tùy chọn): Depth Anything V2 Small bản ONNX (Apache-2.0; bản Base/Large là CC-BY-NC nên đừng nạp) — input `pixel_values [1,3,H,W]`,
     * output `predicted_depth [1,H,W]` (nghịch đảo độ sâu tương đối). Có model thì Reframe 2.5D dùng độ sâu thật thay cho độ sâu giả; không có thì chạy như trước.
     */
    fun importDepth(uri: Uri) {
        viewModelScope.launch {
            ui { copy(status = "Đang nạp model độ sâu…") }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    depthEst?.close()
                    depthEst = null
                    val dest = File(modelDir, DEPTH_FILE)
                    try {
                        ImageIO.copyUriToFile(appCtx, uri, dest)
                        DepthEstimator(dest.absolutePath).close() // kiểm tra nạp được và đúng hợp đồng input rồi mới giữ tệp
                    } catch (e: Throwable) {
                        dest.delete()
                        throw e
                    }
                    Unit
                }
            }
            refreshRoutingSummary()
            ui {
                copy(
                    depthReady = File(modelDir, DEPTH_FILE).exists(),
                    status = result.fold(
                        { "Đã nạp model độ sâu - Reframe 2.5D sẽ dùng độ sâu do model đo (tương đối) thay cho độ sâu giả." },
                        { "Không nạp được model độ sâu: ${it.message ?: it.javaClass.simpleName}" }
                    )
                )
            }
        }
    }

    /** Lớp chỉnh riêng cho TÓC: [hex] != null = nhuộm màu (Colorize giữ sáng-tối), null = tóc bóng mượt. */
    fun addHairLayer(hex: String?) {
        val bgFull = bg ?: return
        val ops = if (hex != null) listOf(EditOp(OpType.COLORIZE, 0.85f, hex))
        else listOf(EditOp(OpType.CLARITY, 0.30f), EditOp(OpType.CONTRAST, 0.15f))
        launchTask("Đang nhận diện tóc…") {
            val notes = ArrayList<String>()
            val mask = maskForScope(Scope.HAIR, bgFull, notes)
            if (mask != null) addLocal(if (hex != null) "Tóc (nhuộm)" else "Tóc (bóng mượt)", mask, ops, Scope.HAIR)
            else ui { copy(status = notes.firstOrNull() ?: "Không dựng được vùng tóc.") }
        }
    }

    // ------------------------------------------------------------------ Dáng khuôn mặt (Liquify theo điểm mốc)
    fun setFaceShape(index: Int, v: Float) {
        val bgFull = bg ?: return
        if (index !in 0..3) return
        val shape = _state.value.faceShape.toMutableList().also { it[index] = v.coerceIn(0f, 1f) }
        ui { copy(faceShape = shape) }
        faceShapeJob?.cancel()
        faceShapeJob = viewModelScope.launch {
            val arg: String? = withContext(Dispatchers.Default) {
                val lms = runCatching { faceLandmarks(bgFull) }.getOrNull()
                if (lms.isNullOrEmpty()) null
                else lms.map { FaceLiquify.args(it, bgFull.width, bgFull.height, shape[0], shape[1], shape[2], shape[3]) }
                    .filter { it.isNotBlank() }.joinToString(";")
            }
            if (arg == null) {
                ui {
                    copy(
                        status = if (!File(modelDir, FACE_FILE).exists()) "Cần nạp model face_landmarker.task (Cài đặt) để chỉnh dáng khuôn mặt."
                        else "Không thấy khuôn mặt trong ảnh."
                    )
                }
                return@launch
            }
            // R17: mặt quay nghiêng -> Liquify được giảm mượt (cổng an toàn); báo để người dùng biết vì sao hiệu ứng nhẹ đi
            val gain = withContext(Dispatchers.Default) {
                runCatching { faceLandmarks(bgFull)?.minOfOrNull { HeadPose.liquifyGain(HeadPose.yawAbsDeg(it, bgFull.width, bgFull.height)) } }.getOrNull()
            }
            if (gain != null && gain < 0.99f) {
                ui {
                    copy(
                        status = if (gain < 0.02f) "Mặt đang quay nghiêng hẳn: tạm tắt chỉnh dáng khuôn mặt để không bị méo."
                        else "Mặt đang quay nghiêng: hiệu ứng giảm còn ${(gain * 100).roundToInt()}% để không bị méo."
                    )
                }
            }
            val existing = _state.value.layers.filterIsInstance<AdjustmentLayer>().lastOrNull { it.kind == "faceshape" }
            val ops = if (arg.isBlank()) emptyList() else listOf(EditOp(OpType.LIQUIFY, 1f, arg))
            if (existing == null) {
                if (ops.isEmpty()) return@launch
                pushUndo()
                val l = AdjustmentLayer(newId(), "Dáng khuôn mặt", ops, kind = "faceshape")
                ui { copy(layers = layers + l, activeId = l.id) }
                requestRender()
            } else {
                touchEdit()
                replaceLayer(existing.copy(ops = ops))
            }
        }
    }

    // ------------------------------------------------------------------ Warp lưới / Free Transform
    private fun warpLayer(): AdjustmentLayer? {
        val st = _state.value
        return (st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer)?.takeIf { it.kind == "warp" }
    }

    private fun warpMesh(layer: AdjustmentLayer): MeshWarp.Mesh =
        MeshWarp.parse(layer.ops.firstOrNull { it.type == OpType.MESH_WARP }?.arg)
            ?: MeshWarp.identity(MeshWarp.DEFAULT_GRID, MeshWarp.DEFAULT_GRID)

    fun startWarp() {
        if (bg == null) return
        val existing = _state.value.layers.filterIsInstance<AdjustmentLayer>().lastOrNull { it.kind == "warp" }
        val layer = existing ?: AdjustmentLayer(newId(), "Warp lưới", emptyList(), kind = "warp").also { created ->
            pushUndo()
            ui { copy(layers = layers + created) }
        }
        ui {
            copy(
                paintMode = PaintMode.WARP, activeId = layer.id, strokes = emptyList(), warpAngle = 0f,
                status = "Kéo các điểm trắng để biến dạng ảnh. Kéo 4 điểm GÓC = Free Transform (co giãn / nghiêng); thanh \"Xoay\" xoay tự do."
            )
        }
    }

    /** Chạm xuống: chọn nút lưới gần ngón tay nhất (trong bán kính 12% ảnh). */
    fun warpBegin(p: Pt) {
        val layer = warpLayer() ?: return
        val m = warpMesh(layer)
        var best = -1
        var bd = 0.12f * 0.12f
        for (j in 0..m.gy) for (i in 0..m.gx) {
            val n = j * (m.gx + 1) + i
            val nx = i / m.gx.toFloat() + m.d[2 * n]
            val ny = j / m.gy.toFloat() + m.d[2 * n + 1]
            val d2 = (nx - p.x) * (nx - p.x) + (ny - p.y) * (ny - p.y)
            if (d2 < bd) { bd = d2; best = n }
        }
        warpNode = best
        if (best >= 0) touchEdit()
    }

    fun warpDrag(a: Pt, b: Pt) {
        if (warpNode < 0) return
        val layer = warpLayer() ?: return
        val m = warpMesh(layer)
        val i = warpNode % (m.gx + 1)
        val j = warpNode / (m.gx + 1)
        replaceLayer(layer.copy(ops = listOf(EditOp(OpType.MESH_WARP, 1f, MeshWarp.encode(MeshWarp.moved(m, i, j, b.x - a.x, b.y - a.y))))))
    }

    fun resetWarp() {
        val layer = warpLayer() ?: return
        pushUndo()
        warpRotBase = null
        replaceLayer(layer.copy(ops = emptyList()))
        ui { copy(warpAngle = 0f) }
    }

    /**
     * Xoay tự do (Free Transform): thanh trượt đặt góc [deg] (độ) so với lúc mở công cụ; xoay toàn bộ lưới (cả biến dạng cục bộ) quanh tâm ảnh.
     * Mỗi lần kéo xoay từ lưới GỐC lúc bắt đầu kéo nên không tích lũy sai số làm tròn; góc bị giới hạn khi một nút chạm biên độ dời lưu được
     * ([MeshWarp.rotated]) và thanh trượt hiện đúng góc thực sự áp dụng.
     */
    fun setWarpAngle(deg: Float) {
        val layer = warpLayer() ?: return
        val full = bg ?: return
        if (warpRotBase == null) {
            warpRotBase = warpMesh(layer)
            warpRotBaseAngle = _state.value.warpAngle
        }
        val base = warpRotBase ?: return
        val target = deg.coerceIn(-WARP_MAX_DEG, WARP_MAX_DEG)
        touchEdit()
        val r = MeshWarp.rotated(base, full.width, full.height, Math.toRadians((target - warpRotBaseAngle).toDouble()))
        val mesh = r.mesh
        val op = if (MeshWarp.isIdentity(mesh)) emptyList() else listOf(EditOp(OpType.MESH_WARP, 1f, MeshWarp.encode(mesh)))
        replaceLayer(layer.copy(ops = op))
        ui { copy(warpAngle = warpRotBaseAngle + Math.toDegrees(r.appliedRad).toFloat()) }
    }

    // ------------------------------------------------------------------ Sửa điểm lasso (mặt nạ vector)
    private fun polyLayer(): Layer? {
        val st = _state.value
        return st.layers.firstOrNull { it.id == st.activeId }?.takeIf { it.mask?.spec is MaskSpec.Polygon }
    }

    private fun polyPoints(l: Layer): List<Pt> = (l.mask?.spec as? MaskSpec.Polygon)?.pts ?: emptyList()

    private fun polyAspect(): Float = bg?.let { it.width.toFloat() / max(1, it.height) } ?: 1f

    private fun setPolyPoints(l: Layer, pts: List<Pt>) {
        val m = l.mask ?: return
        replaceLayer(l.update(mask = m.copy(spec = MaskSpec.Polygon(pts))))
    }

    /** Vào chế độ sửa điểm cho lớp đang chọn nếu nó có mặt nạ lasso (đa giác vector). */
    fun startPolyEdit() {
        if (polyLayer() == null) {
            ui { copy(status = "Chọn lớp có vùng lasso (mặt nạ vector) để sửa điểm.") }
            return
        }
        polyNode = -1
        ui {
            copy(
                paintMode = PaintMode.POLY_EDIT, strokes = emptyList(), patchPick = false,
                status = "Kéo điểm trắng để chỉnh vùng lasso · chạm lên cạnh (hoặc kéo từ cạnh) để thêm điểm · chạm giữ một điểm để xóa."
            )
        }
    }

    /** Chạm xuống: bắt điểm gần nhất; không có thì chèn điểm mới lên cạnh gần nhất (rồi kéo luôn điểm đó). */
    fun polyBegin(p: Pt) {
        val layer = polyLayer() ?: return
        val pts = polyPoints(layer)
        val aspect = polyAspect()
        var i = PolygonEdit.nearestVertex(pts, p, POLY_HIT, aspect)
        if (i < 0) {
            val e = PolygonEdit.nearestEdge(pts, p, POLY_HIT, aspect)
            if (e != null) {
                val np = PolygonEdit.inserted(pts, e.edge, e.at)
                if (np.size > pts.size) {
                    touchEdit()
                    setPolyPoints(layer, np)
                    i = e.edge + 1
                }
            }
        }
        polyNode = i
        if (i >= 0) touchEdit()
    }

    fun polyDrag(p: Pt) {
        if (polyNode < 0) return
        val layer = polyLayer() ?: return
        val pts = polyPoints(layer)
        if (polyNode !in pts.indices) return
        setPolyPoints(layer, PolygonEdit.moved(pts, polyNode, p))
    }

    /** Chạm giữ: xóa điểm gần nhất (giữ tối thiểu 3 điểm). */
    fun polyDelete(p: Pt) {
        val layer = polyLayer() ?: return
        val pts = polyPoints(layer)
        val i = PolygonEdit.nearestVertex(pts, p, POLY_HIT, polyAspect())
        if (i < 0) return
        val np = PolygonEdit.removed(pts, i)
        if (np == null) {
            ui { copy(status = "Vùng lasso cần tối thiểu ${PolygonEdit.MIN_POINTS} điểm.") }
            return
        }
        pushUndo()
        setPolyPoints(layer, np)
        requestRender()
    }

    /** Chạm (không kéo) lên một cạnh, xa mọi điểm: chèn thêm điểm tại đó. */
    fun polyTap(p: Pt) {
        val layer = polyLayer() ?: return
        val pts = polyPoints(layer)
        val aspect = polyAspect()
        if (PolygonEdit.nearestVertex(pts, p, POLY_HIT, aspect) >= 0) return
        val e = PolygonEdit.nearestEdge(pts, p, POLY_HIT, aspect) ?: return
        val np = PolygonEdit.inserted(pts, e.edge, e.at)
        if (np.size == pts.size) return
        pushUndo()
        setPolyPoints(layer, np)
        requestRender()
    }

    // ------------------------------------------------------------------ Patch tool (vá bằng vùng sạch, kèm bù màu Heal)
    fun startPatch() {
        if (bg == null) return
        ui {
            copy(
                paintMode = PaintMode.PATCH, patchPick = false, cloneSource = null, strokes = emptyList(),
                status = "Tô quanh khuyết điểm cần vá, bấm \"Chọn nguồn\" rồi chạm vào vùng SẠCH dùng để thay thế."
            )
        }
    }

    fun beginPatchPick() {
        if (_state.value.strokes.isEmpty()) return
        ui { copy(patchPick = true, status = "Chạm vào vùng SẠCH muốn lấy làm nguồn (tâm vùng nguồn).") }
    }

    fun patchFromTap(p: Pt) {
        val st = _state.value
        val bgFull = bg ?: return
        if (st.strokes.isEmpty() || st.busy) return
        val pts = st.strokes.flatten()
        val cx = pts.map { it.x }.average().toFloat()
        val cy = pts.map { it.y }.average().toFloat()
        ui { copy(patchPick = false) }
        launchTask("Đang vá…") {
            val notes = ArrayList<String>()
            val base = withContext(Dispatchers.Default) { Compositor.render(bgFull, st.layers, bgFull.width, currentSeg(), false, notes) }
            val mask = withContext(Dispatchers.Default) { MaskBuilder.build(st.strokes, st.brush, base.width, base.height, "") }
            if (mask == null) return@launchTask
            val dx = ((cx - p.x) * base.width).toInt()
            val dy = ((cy - p.y) * base.height).toInt()
            val result = withContext(Dispatchers.Default) { CloneTool.apply(base, mask, dx, dy, true) }
            val patch = withContext(Dispatchers.Default) { Layers.diffPatch(base, result, newId(), "Patch") }
            if (patch == null) {
                ui { copy(status = "Không có thay đổi (nguồn trùng đích?).") }
                return@launchTask
            }
            pending = patch
            ui { copy(genKind = GenKind.CLONE, status = "Xong. Bấm \"Áp dụng\" để giữ kết quả vá.") }
            requestRender()
        }
    }

    // ------------------------------------------------------------------ Tab Faves + vuốt trên ảnh để chỉnh (thanh trượt đa chức năng)
    fun toggleFav(key: String) {
        val cur = _state.value.favTools
        val next = if (key in cur) cur - key else cur + key
        prefs.edit().putStringSet(KEY_FAV, next).apply()
        ui { copy(favTools = next) }
    }

    /** Vuốt NGANG trên ảnh: chỉnh thông số đang chọn (dxNorm = quãng vuốt / bề rộng vùng ảnh). */
    fun scrubValue(dxNorm: Float) {
        if (bg == null) return
        val st = _state.value
        val t = st.scrubType?.takeIf { it.scalable } ?: scrubOrder[0]
        val cur = (st.layers.firstOrNull { it.id == st.activeId } as? AdjustmentLayer)?.ops?.firstOrNull { it.type == t }
        val v = ((cur?.value ?: 0f) + dxNorm * 2f).coerceIn(if (t.signed) -1f else 0f, 1f)
        setOp(t, v, cur?.arg)
        ui { copy(status = "${t.label}: ${(v * 100).toInt()}%  (vuốt ngang: chỉnh · vuốt dọc: đổi thông số)") }
    }

    /** Vuốt DỌC: chuyển sang thông số kế tiếp / trước đó trong danh sách nhanh. */
    fun scrubCycle(dir: Int) {
        val cur = _state.value.scrubType ?: scrubOrder[0]
        val idx = scrubOrder.indexOf(cur).let { if (it < 0) 0 else it }
        val next = scrubOrder[(idx + dir + scrubOrder.size) % scrubOrder.size]
        ui { copy(scrubType = next, status = "Đang chỉnh: ${next.label} - vuốt ngang trên ảnh để chỉnh") }
    }

    fun removeModels() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                pool.clear()
                llm?.close(); llm = null
                segmenter?.close(); segmenter = null
                lama?.close(); lama = null
                migan?.close(); migan = null
                esrgan?.close(); esrgan = null
                localSd.stop()
                modelDir.listFiles()?.filter { it.name.startsWith("sd_inpaint.") || it.name.startsWith("sd_klein.") }?.forEach { it.delete() }
                File(modelDir, LORA_DIR).deleteRecursively()
                File(modelDir, "sdextra").deleteRecursively()
                sam?.close(); sam = null
                File(modelDir, LLM_FILE).delete()
                File(modelDir, LLM_LITERTLM_FILE).delete()
                File(modelDir, "$LLM_LITERTLM_FILE.name").delete()
                File(modelDir, "$LLM_FILE.name").delete()
                face?.close(); face = null; faceCache = null
                portraitSeg?.close(); portraitSeg = null; segChoice = null
                File(modelDir, SEG_PORTRAIT_FILE).delete()
                File(modelDir, SEG_FILE).delete()
                File(modelDir, SEG_HQ_FILE).delete()
                File(modelDir, FACE_FILE).delete()
                hair?.close(); hair = null; hairCache = null
                File(modelDir, HAIR_FILE).delete()
                person?.close(); person = null
                File(modelDir, PERSON_FILE).delete()
                depthEst?.close(); depthEst = null
                File(modelDir, DEPTH_FILE).delete()
                File(modelDir, LAMA_FILE).delete()
                File(modelDir, MIGAN_FILE).delete()
                File(modelDir, ESRGAN_FILE).delete()
                File(modelDir, SAM_ENC_FILE).delete()
                File(modelDir, SAM_DEC_FILE).delete()
            }
            refreshRoutingSummary()
            ui { copy(llmReady = false, segReady = false, segHqReady = false, faceReady = false, hairReady = false, personReady = false, depthReady = false, portraitReady = false, lamaReady = false, miganReady = false, esrganReady = false, samReady = false, sdLocalModel = false, status = "Đã gỡ các model.") }
        }
    }

    override fun onCleared() {
        llm?.close()
        segmenter?.close()
        lama?.close()
        migan?.close()
        esrgan?.close()
        sam?.close()
        face?.close()
        portraitSeg?.close()
        localSd.stop()
        super.onCleared()
    }
}
