package com.aiphoto.studio.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * R12 — Kho ẢNH TRỜI của người dùng (`filesDir/skies/<tên>.jpg`) cho phép chỉnh "Thay bầu trời" dùng ảnh riêng.
 * Phép chỉnh tham chiếu bằng arg = "img:<tên>.jpg" (không nhúng ảnh vào công thức/Agent → máy khác phải nhập lại, có ghi chú).
 * Ảnh được thu nhỏ ≤ [MAX_SIDE] px khi lưu để nhẹ và nhanh; chỉ giữ một ảnh đã giải mã trong bộ nhớ.
 */
object SkyStore {
    const val MAX_SIDE = 1280
    private const val PREFIX = "img:"
    private val NAME_RE = Regex("^[A-Za-z0-9_\\- ]{1,40}\\.jpg$")

    @Volatile var dir: File? = null

    private class Cached(val name: String, val stamp: Long, val px: IntArray, val w: Int, val h: Int)
    private var cached: Cached? = null

    fun isValidName(n: String?): Boolean = n != null && NAME_RE.matches(n)
    fun arg(name: String): String = PREFIX + name

    /** "img:abc.jpg" → "abc.jpg"; arg khác hoặc tên không hợp lệ → null. */
    fun nameFromArg(arg: String?): String? {
        if (arg == null || !arg.startsWith(PREFIX)) return null
        val n = arg.substring(PREFIX.length)
        return if (isValidName(n)) n else null
    }

    fun sanitizeName(raw: String): String {
        val base = raw.substringBeforeLast('.', raw).replace(Regex("[^A-Za-z0-9_\\- ]"), "_").trim().take(36)
        return (if (base.isBlank()) "sky" else base) + ".jpg"
    }

    fun list(): List<String> = dir?.listFiles()?.filter { it.isFile && isValidName(it.name) }?.map { it.name }?.sorted().orEmpty()

    /** Lưu ảnh (thu nhỏ nếu lớn) dưới tên đã làm sạch. Trả tên đã lưu hoặc null nếu ghi lỗi. */
    @Synchronized
    fun save(rawName: String, bmp: Bitmap): String? {
        val d = dir ?: return null
        d.mkdirs()
        val name = sanitizeName(rawName)
        val longSide = max(bmp.width, bmp.height)
        val src = if (longSide > MAX_SIDE) {
            val f = MAX_SIDE.toFloat() / longSide
            Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * f).roundToInt()), max(1, (bmp.height * f).roundToInt()), true)
        } else bmp
        return runCatching {
            FileOutputStream(File(d, name)).use { src.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            cached = null
            name
        }.getOrNull()
    }

    @Synchronized
    fun delete(name: String) {
        if (!isValidName(name)) return
        File(dir ?: return, name).delete()
        if (cached?.name == name) cached = null
    }

    /** Điểm ảnh ARGB + kích thước của ảnh trời [name]; null nếu thiếu/hỏng. */
    @Synchronized
    fun load(name: String): Triple<IntArray, Int, Int>? {
        if (!isValidName(name)) return null
        val f = File(dir ?: return null, name)
        if (!f.isFile) return null
        val stamp = f.lastModified() * 31 + f.length()
        cached?.let { if (it.name == name && it.stamp == stamp) return Triple(it.px, it.w, it.h) }
        val bmp = runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull() ?: return null
        val px = readPixels(bmp)
        val c = Cached(name, stamp, px, bmp.width, bmp.height)
        cached = c
        return Triple(c.px, c.w, c.h)
    }
}
