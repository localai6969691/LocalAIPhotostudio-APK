package com.aiphoto.studio.ai

/** Các prompt gửi cho LLM cục bộ (thuần Kotlin để kiểm thử trên JVM). Prompt kế hoạch giữ NGUYÊN VĂN như bản MediaPipe trước R15. */
object LlmPrompts {

    /** Số dòng "phép hiếm" tối đa chèn thêm vào một prompt. Ngân sách: MediaPipe `setMaxTokens(1024)` gồm cả prompt lẫn câu trả lời; prompt gốc ≈ 700 token, mỗi dòng thêm ≈ 30 token ⇒ 2 dòng vẫn chừa chỗ cho JSON trả lời. */
    const val MAX_EXTRA_LINES = 2

    /** Một dòng mô tả phép hiếm + các từ khóa (đã bỏ dấu, chữ thường) khiến dòng đó được chèn vào prompt. */
    private class Hint(val keys: List<String>, val line: String)

    /**
     * R36: 13 phép KHÔNG có trong prompt gốc (prompt gốc bị ghim kích thước vì model nhỏ chỉ có ngữ cảnh 1024 token, xem R15Test). Thay vì nhét hết vào mọi prompt
     * (tốn token, làm model nhỏ đáp tệ hơn ở các phép thường dùng), chỉ chèn dòng của phép nào mà CÂU LỆNH nhắc tới từ khóa của nó (truy xuất công cụ theo yêu cầu).
     * Phép cần tham số phức tạp (curves, levels, hsl, color_balance, selective_color, liquify, mesh_warp, lut, perspective, color_match) cố ý KHÔNG có ở đây:
     * model 1B không sinh đúng chuỗi số dài; các phép đó đi qua bộ hiểu lệnh offline và giao diện.
     */
    private val HINTS: List<Hint> = listOf(
        Hint(listOf("clarity", "local contrast", "ro net cuc bo", "tuong phan cuc bo"), "clarity: value in -1.0..1.0 (positive = crisper local contrast)"),
        Hint(listOf("hue", "xoay mau", "doi sac do", "sac do"), "hue: value in -1.0..1.0 = rotate all colors around the color wheel (1.0 = half turn)"),
        Hint(listOf("grain", "hat film", "film grain", "hieu ung hat"), "grain: value in 0.0..1.0 = film grain"),
        Hint(listOf("denoise", "khu nhieu", "giam nhieu", "noise reduction", "reduce noise"), "denoise: value in 0.0..1.0 = reduce image noise"),
        Hint(listOf("dust", "scratch", "bui xuoc", "xoa bui", "xoa xuoc", "xuoc"), "dust: value in 0.0..1.0 = remove dust specks and scratches"),
        Hint(listOf("frequency separation", "tach tan so", "retouch da"), "freq_sep: value in 0.0..1.0 = natural skin retouch that keeps pores (use scope \\\"skin\\\")"),
        Hint(listOf("motion blur", "mo chuyen dong", "mo dong"), "motion_blur: value in 0.0..1.0 = length, arg = angle in degrees like \\\"0\\\" (horizontal)"),
        Hint(listOf("radial blur", "zoom blur", "mo xuyen tam"), "radial_blur: value in 0.0..1.0 = zoom blur toward the center"),
        Hint(listOf("straighten", "chinh thang", "nan thang", "horizon"), "straighten: value = degrees -45..45 (levels a tilted horizon, crops the empty corners)"),
        Hint(listOf("lens flare", "flare", "loe sang", "choi sang"), "lens_flare: value in 0.0..1.0, arg = \\\"x,y\\\" light position 0..1 (default 0.78,0.2)"),
        Hint(listOf("duotone", "hai tong mau", "two tone", "hai mau"), "duotone: value in 0.0..1.0, arg = \\\"#shadowHex,#highlightHex\\\" (optional)"),
        Hint(listOf("thay troi", "doi troi", "sky replace", "replace the sky", "replace sky", "change the sky", "new sky"),
            "sky_replace: value 0.0..1.0, arg = blue, sunset, dusk, overcast or night (add sky_relight value 0.0..1.0 to match the ground light to the new sky)")
    )

    /** Các dòng mô tả phép hiếm mà [userPrompt] nhắc tới (tối đa [MAX_EXTRA_LINES], theo thứ tự khai báo). Không từ khóa nào khớp ⇒ rỗng ⇒ prompt đúng bản gốc. */
    fun extraOpLines(userPrompt: String): List<String> {
        val t = " " + GenIntent.fold(userPrompt) + " "
        val out = ArrayList<String>()
        for (h in HINTS) {
            if (out.size >= MAX_EXTRA_LINES) break
            if (h.keys.any { " $it " in t }) out.add(h.line)
        }
        return out
    }

    /** Dịch mô tả (vd. tiếng Việt) thành prompt tiếng Anh cho Stable Diffusion; null nếu đã là ASCII (không cần dịch). */
    fun translate(text: String): String? {
        if (text.all { it.code < 128 }) return null
        val clean = text.replace('"', '\'').replace('\n', ' ').trim()
        return "Translate this image-editing description into a short English prompt for a Stable Diffusion " +
            "image generator. Describe only the object to appear (appearance, color, style), no position words. " +
            "Reply with the English prompt only.\nText: \"$clean\""
    }

    /** Kế hoạch chỉnh từ ẢNH + yêu cầu (model đa phương thức): thêm đoạn dẫn nhìn ảnh rồi dùng đúng prompt kế hoạch văn bản. */
    fun imagePlan(userPrompt: String): String =
        "The attached photo is the image to edit. Look at it carefully (lighting, exposure, skin, sky, subject, background) " +
            "and choose edits that fit THIS photo.\n" + plan(userPrompt)

    fun plan(userPrompt: String): String {
        val clean = userPrompt.replace('"', '\'').replace('\n', ' ').trim()
        val extra = extraOpLines(userPrompt).joinToString("") { it + "\n" } // R36: rỗng với đa số câu lệnh ⇒ prompt giữ nguyên văn bản gốc
        return """
You convert photo editing requests (Vietnamese or English) into a JSON edit plan.
Reply with ONLY the JSON object, no explanation.
Format: {"ops":[{"op":"<name>","value":<number>,"arg":"<optional>"}]}
Allowed ops:
brightness, contrast, saturation, warmth: value in -1.0..1.0 (0 = unchanged, warmth>0 = warmer)
highlights (negative = recover blown highlights), vibrance, tint (positive = magenta, negative = green), dehaze (positive = remove haze, negative = add haze), texture (negative = smooth): value in -1.0..1.0
shadows, sharpen, blur, skin_smooth, vignette, sepia, cinematic, auto_enhance, bg_blur: value in 0.0..1.0
grayscale, flip_h, flip_v: value 1
bg_remove: value 1, arg = "transparent" or a hex color like "#FFFFFF"
rotate: value = 90, 180 or 270 (clockwise)
crop_ratio: value = width/height (1.0 square, 1.78 for 16:9, 0.75 for 3:4)
upscale: value = 2
posterize, pixelate, emboss, sketch, glow, chroma, matte: value in 0.0..1.0
colorize: value 0.0..1.0, arg = target hex color like \"#6B4423\" (use scope \"hair\" to dye hair)
hair_volume: value 0.0..1.0 = fuller / thicker hair (use scope \"hair\"; needs the hair model)
outpaint: value 1, arg = \"l=0.2,r=0.2,t=0,b=0\" (add 20% on a side) or \"ratio=1.78\" (extend the frame to that width/height)
split_tone: value 1, arg = \"shadowHue,shadowSat,highlightHue,highlightSat\" (hue 0-360, sat 0..1; teal shadows + orange highlights = \"185,0.5,28,0.5\")
unblur: value 0.0..1.0 = restore a blurry or shaky photo (no arg: the app measures the blur itself)
moire: value 0.0..1.0 = remove moire stripes from a photo of a screen or fine fabric
style: value 0.0..1.0, arg = \"oil\" or \"cartoon\" or \"watercolor\" (turn the photo into that kind of painting on the device)
${extra}Optional \"scope\": teeth, eyes, skin, sky, subject, background, hair (omit = whole photo)
Use 0.1-0.3 for "slightly", 0.4-0.7 normally, up to 1.0 for "very strong".
Examples:
Request: "làm da mịn và sáng hơn, tông ấm"
{"ops":[{"op":"skin_smooth","value":0.5},{"op":"brightness","value":0.15},{"op":"warmth","value":0.3}]}
Request: "xóa nền, nền trắng"
{"ops":[{"op":"bg_remove","value":1,"arg":"#FFFFFF"}]}
Request: "make it black and white with strong contrast"
{"ops":[{"op":"grayscale","value":1},{"op":"contrast","value":0.4}]}
Request: "làm đẹp tự nhiên cho ảnh chân dung"
{"ops":[{"op":"auto_enhance","value":0.5},{"op":"skin_smooth","value":0.4},{"op":"warmth","value":0.1}]}
Request: "làm trắng răng và bầu trời xanh hơn"
{"ops":[{"op":"brightness","value":0.2,"scope":"teeth"},{"op":"saturation","value":-0.4,"scope":"teeth"},{"op":"saturation","value":0.35,"scope":"sky"}]}
Request: "nhuộm tóc màu nâu"
{"ops":[{"op":"colorize","value":0.85,"arg":"#6B4423","scope":"hair"}]}
Request: "$clean"
""".trimIndent() + "\n"
    }
}
