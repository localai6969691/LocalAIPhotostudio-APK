package com.aiphoto.studio.ai

/** Các prompt gửi cho LLM cục bộ (thuần Kotlin để kiểm thử trên JVM). Prompt kế hoạch giữ NGUYÊN VĂN như bản MediaPipe trước R15. */
object LlmPrompts {

    /** Dịch mô tả (vd. tiếng Việt) thành prompt tiếng Anh cho Stable Diffusion; null nếu đã là ASCII (không cần dịch). */
    fun translate(text: String): String? {
        if (text.all { it.code < 128 }) return null
        val clean = text.replace('"', '\'').replace('\n', ' ').trim()
        return "Translate this image-editing description into a short English prompt for a Stable Diffusion " +
            "image generator. Describe only the object to appear (appearance, color, style), no position words. " +
            "Reply with the English prompt only.\nText: \"$clean\""
    }

    /** Kế hoạch chỉnh từ ẢNH + yêu cầu (model đa phương thức): thêm đoạn dẫn nhìn ảnh rồi dùng đúng prompt kế hoạch văn bản. */
    fun imagePlan(userPrompt: String): String =
        "The attached photo is the image to edit. Look at it carefully (lighting, exposure, skin, sky, subject, background) " +
            "and choose edits that fit THIS photo.\n" + plan(userPrompt)

    fun plan(userPrompt: String): String {
        val clean = userPrompt.replace('"', '\'').replace('\n', ' ').trim()
        return """
You convert photo editing requests (Vietnamese or English) into a JSON edit plan.
Reply with ONLY the JSON object, no explanation.
Format: {"ops":[{"op":"<name>","value":<number>,"arg":"<optional>"}]}
Allowed ops:
brightness, contrast, saturation, warmth: value in -1.0..1.0 (0 = unchanged, warmth>0 = warmer)
highlights (negative = recover blown highlights), vibrance, tint (positive = magenta, negative = green), dehaze (positive = remove haze, negative = add haze), texture (negative = smooth): value in -1.0..1.0
shadows, sharpen, blur, skin_smooth, vignette, sepia, cinematic, auto_enhance, bg_blur: value in 0.0..1.0
grayscale, flip_h, flip_v: value 1
bg_remove: value 1, arg = "transparent" or a hex color like "#FFFFFF"
rotate: value = 90, 180 or 270 (clockwise)
crop_ratio: value = width/height (1.0 square, 1.78 for 16:9, 0.75 for 3:4)
upscale: value = 2
posterize, pixelate, emboss, sketch, glow, chroma, matte: value in 0.0..1.0
colorize: value 0.0..1.0, arg = target hex color like \"#6B4423\" (use scope \"hair\" to dye hair)
hair_volume: value 0.0..1.0 = fuller / thicker hair (use scope \"hair\"; needs the hair model)
outpaint: value 1, arg = \"l=0.2,r=0.2,t=0,b=0\" (add 20% on a side) or \"ratio=1.78\" (extend the frame to that width/height)
split_tone: value 1, arg = \"shadowHue,shadowSat,highlightHue,highlightSat\" (hue 0-360, sat 0..1; teal shadows + orange highlights = \"185,0.5,28,0.5\")
unblur: value 0.0..1.0 = restore a blurry or shaky photo (no arg: the app measures the blur itself)
moire: value 0.0..1.0 = remove moire stripes from a photo of a screen or fine fabric
style: value 0.0..1.0, arg = \"oil\" or \"cartoon\" or \"watercolor\" (turn the photo into that kind of painting on the device)
Optional \"scope\": teeth, eyes, skin, sky, subject, background, hair (omit = whole photo)
Use 0.1-0.3 for "slightly", 0.4-0.7 normally, up to 1.0 for "very strong".
Examples:
Request: "làm da mịn và sáng hơn, tông ấm"
{"ops":[{"op":"skin_smooth","value":0.5},{"op":"brightness","value":0.15},{"op":"warmth","value":0.3}]}
Request: "xóa nền, nền trắng"
{"ops":[{"op":"bg_remove","value":1,"arg":"#FFFFFF"}]}
Request: "make it black and white with strong contrast"
{"ops":[{"op":"grayscale","value":1},{"op":"contrast","value":0.4}]}
Request: "làm đẹp tự nhiên cho ảnh chân dung"
{"ops":[{"op":"auto_enhance","value":0.5},{"op":"skin_smooth","value":0.4},{"op":"warmth","value":0.1}]}
Request: "làm trắng răng và bầu trời xanh hơn"
{"ops":[{"op":"brightness","value":0.2,"scope":"teeth"},{"op":"saturation","value":-0.4,"scope":"teeth"},{"op":"saturation","value":0.35,"scope":"sky"}]}
Request: "nhuộm tóc màu nâu"
{"ops":[{"op":"colorize","value":0.85,"arg":"#6B4423","scope":"hair"}]}
Request: "$clean"
""".trimIndent() + "\n"
    }
}
