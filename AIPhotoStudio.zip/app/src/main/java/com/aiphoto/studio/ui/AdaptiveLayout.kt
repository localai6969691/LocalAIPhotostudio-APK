package com.aiphoto.studio.ui

/**
 * R39 - quy tắc chọn bố cục thích ứng (thuần Kotlin để kiểm thử JVM được; EditorScreen dùng).
 *  - RỘNG (hai khung: ảnh trái, bảng điều khiển cuộn được bên phải) khi: chiều rộng >= 840dp (máy tính bảng, màn gập mở ra, cửa sổ rộng),
 *    hoặc điện thoại / máy tính bảng nằm NGANG và rộng >= 600dp.
 *  - Ngược lại: bố cục một cột dọc như trước (điện thoại cầm dọc, cửa sổ chia đôi màn hình hẹp).
 * Số đo là dp từ Configuration.screenWidthDp / screenHeightDp (đã tính theo cửa sổ hiện tại nên chia đôi màn hình / gập mở tự đổi).
 */
const val WIDE_MIN_WIDTH_DP = 840
const val WIDE_LANDSCAPE_MIN_WIDTH_DP = 600
const val SIDE_PANEL_MIN_DP = 300
const val SIDE_PANEL_MAX_DP = 460

fun isWideLayout(widthDp: Int, heightDp: Int): Boolean {
    if (widthDp <= 0 || heightDp <= 0) return false
    return widthDp >= WIDE_MIN_WIDTH_DP || (widthDp >= WIDE_LANDSCAPE_MIN_WIDTH_DP && widthDp > heightDp)
}

/** Bề rộng khung bảng điều khiển bên phải: 36% chiều rộng, kẹp trong [300, 460] dp (ảnh luôn còn >= ~270dp). */
fun sidePanelWidthDp(widthDp: Int): Int = (widthDp * 36 / 100).coerceIn(SIDE_PANEL_MIN_DP, SIDE_PANEL_MAX_DP)

// ---------------------------------------------------------------------------------------------------------------------------------------
// R45 - sửa lỗi bố cục thấy trên máy thật (điện thoại 1080x2400, ~411dp): thanh trên có 7 nút nhưng không đủ chỗ ⇒ ô tiêu đề (weight 1) bị ép về
// rộng 0 ⇒ chữ "AI Photo Studio" xuống dòng từng ký tự, thanh trên cao ~1000px, vùng ảnh còn 0px (ảnh mở rồi mà "không thấy đâu") và nút ⚙ bị đẩy
// ra ngoài màn hình. Ba quy tắc thuần Kotlin (kiểm được bằng JUnit) dưới đây chặn lỗi đó; EditorScreen dùng.
// ---------------------------------------------------------------------------------------------------------------------------------------

/** Bề rộng tối thiểu (dp) của mỗi nút trên thanh trên (vùng chạm hơi dưới 48dp để đủ 7 nút trên điện thoại hẹp). */
const val TOP_BAR_ACTION_MIN_DP = 44

/** Số nút trên thanh trên: Mở, hoàn tác, làm lại, Lưu, chia sẻ, Trợ giúp, Cài đặt. */
const val TOP_BAR_ACTION_COUNT = 7

/** Khoảng cách giữa các nút (dp). */
const val TOP_BAR_GAP_DP = 2

/** Chữ "AI Photo Studio" chỉ hiện khi thanh còn thừa chỗ (≥ 420dp); hẹp hơn thì ẩn hẳn thay vì bị ép xuống dòng từng ký tự. */
const val TOP_BAR_TITLE_MIN_DP = 420

/** Bề rộng ngắn nhất (dp) để cả 7 nút nằm gọn không cần cuộn: nhãn "Lưu" rộng hơn một chút nên cộng thêm 4dp. */
fun topBarActionsMinWidthDp(): Int = TOP_BAR_ACTION_COUNT * TOP_BAR_ACTION_MIN_DP + (TOP_BAR_ACTION_COUNT - 1) * TOP_BAR_GAP_DP + 4

/** [barWidthDp]: bề rộng khả dụng của thanh trên (đã trừ lề). */
fun topBarShowsTitle(barWidthDp: Int): Boolean = barWidthDp >= TOP_BAR_TITLE_MIN_DP

/**
 * Chiều cao TỐI ĐA của bảng điều khiển dưới ảnh ở bố cục dọc: 45% chiều cao cửa sổ (không dưới 140dp). Vượt thì bảng cuộn bên trong, để vùng ảnh luôn còn
 * chỗ (trước đây bảng AI cao ~50% màn hình cộng thanh trên cao vọt ⇒ ảnh bị ép còn 0).
 */
fun controlsMaxHeightDp(windowHeightDp: Int): Int = (windowHeightDp * 45 / 100).coerceAtLeast(140)

/** Việc cần làm khi người dùng vuốt / bấm Back, theo thứ tự ưu tiên từ trong ra ngoài. */
enum class BackAction {
    /** Đang ở chế độ tô / chọn vùng ⇒ thoát chế độ đó (không thoát app). */
    LEAVE_PAINT,

    /** Đang mở một thẻ (AI / Công cụ / Looks / Cắt / Lớp) ⇒ thu gọn để thấy trọn ảnh. */
    CLOSE_PANEL,

    /** Còn ảnh đang mở ⇒ hỏi trước khi thoát (cử chỉ vuốt Back rất dễ chạm nhầm). */
    CONFIRM_EXIT,

    /** Chưa có ảnh ⇒ để hệ thống thoát như thường. */
    SYSTEM
}

fun decideBack(paintActive: Boolean, panelOpen: Boolean, hasImage: Boolean): BackAction = when {
    paintActive -> BackAction.LEAVE_PAINT
    panelOpen -> BackAction.CLOSE_PANEL
    hasImage -> BackAction.CONFIRM_EXIT
    else -> BackAction.SYSTEM
}
