package com.aiphoto.studio.ui

/**
 * R39 - quy tắc chọn bố cục thích ứng (thuần Kotlin để kiểm thử JVM được; EditorScreen dùng).
 *  - RỘNG (hai khung: ảnh trái, bảng điều khiển cuộn được bên phải) khi: chiều rộng >= 840dp (máy tính bảng, màn gập mở ra, cửa sổ rộng),
 *    hoặc điện thoại / máy tính bảng nằm NGANG và rộng >= 600dp.
 *  - Ngược lại: bố cục một cột dọc như trước (điện thoại cầm dọc, cửa sổ chia đôi màn hình hẹp).
 * Số đo là dp từ Configuration.screenWidthDp / screenHeightDp (đã tính theo cửa sổ hiện tại nên chia đôi màn hình / gập mở tự đổi).
 */
const val WIDE_MIN_WIDTH_DP = 840
const val WIDE_LANDSCAPE_MIN_WIDTH_DP = 600
const val SIDE_PANEL_MIN_DP = 300
const val SIDE_PANEL_MAX_DP = 460

fun isWideLayout(widthDp: Int, heightDp: Int): Boolean {
    if (widthDp <= 0 || heightDp <= 0) return false
    return widthDp >= WIDE_MIN_WIDTH_DP || (widthDp >= WIDE_LANDSCAPE_MIN_WIDTH_DP && widthDp > heightDp)
}

/** Bề rộng khung bảng điều khiển bên phải: 36% chiều rộng, kẹp trong [300, 460] dp (ảnh luôn còn >= ~270dp). */
fun sidePanelWidthDp(widthDp: Int): Int = (widthDp * 36 / 100).coerceIn(SIDE_PANEL_MIN_DP, SIDE_PANEL_MAX_DP)
