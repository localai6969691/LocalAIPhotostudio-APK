# Hướng dẫn dành cho tester - AI Photo Studio

Bản này đang ở giai đoạn **dùng thử miễn phí để bắt lỗi**. Bạn không phải trả tiền, ảnh xuất ra không có watermark, và máy chủ của chủ app
**không** dùng khóa AI của chủ app để chạy thay bạn (nên chủ app không tốn tiền khi bạn thử). Việc của bạn là dùng app thật và báo lại
chỗ nào sai, treo, đóng đột ngột hoặc kết quả xấu.

> Trung thực về tình trạng: mã nguồn đã qua rất nhiều bài kiểm tra tự động, nhưng bản APK đầu tiên **chưa từng được chạy trên máy thật** trước khi
> đến tay bạn. Rất có thể có lỗi - đó chính là lý do cần bạn.

## 1. Cài app

1. Nhận file `app-debug.apk` từ người gửi (hoặc tải từ GitHub: tab *Actions* → lần chạy *Build APK* mới nhất → *Artifacts* → `AIPhotoStudio-debug-apk`, giải nén).
2. Mở file trên điện thoại, cho phép *cài từ nguồn này* khi máy hỏi. Cần Android 8.0 trở lên.
3. Các bản build từ GitHub ký bằng cùng một khóa debug cố định nên **cài đè bản mới lên bản cũ được**, ảnh đã lưu và model đã nạp vẫn còn.
   Nếu máy báo xung đột chữ ký (chỉ xảy ra khi bản cũ của bạn đến từ nguồn khác), phải gỡ bản cũ rồi cài lại - khi đó **model đã nạp và phiên đã lưu sẽ mất**, hãy giữ lại các file model đã tải.

## 2. Cần chuẩn bị gì? (làm đến mức nào tùy bạn)

| Mức | Bạn cần | Dùng được |
|---|---|---|
| **0 - không chuẩn bị gì** | Chỉ cài app | Chỉnh màu, làm đẹp cơ bản, cắt/xoay/lật, filter/Look, xóa vật thể nhẹ bằng thuật toán cổ điển, vẽ/gõ chữ, lớp và mặt nạ |
| **1 - vài model nhỏ trên máy** (nên làm) | Tải file model về máy, vào *Cài đặt (Model AI)* → bấm nút *Chọn model …* tương ứng | Tách nền, xóa vật thể chất lượng cao (LaMa), retouch khuôn mặt, nhuộm tóc, xóa người lạ chính xác hơn |
| **2 - tạo/thay vật thể bằng AI đám mây** | Khóa API Gemini **của chính bạn** | Thêm/thay vật thể, mở rộng ảnh, Agent AI qua Gemini |

Gợi ý model cho mức 1 (chi tiết và nguồn tải xem `README.md` mục 3; app **không** tự tải model, bạn tự tải rồi chọn file):

- `u2netp.onnx` (~4.7 MB) - tách nền, nhỏ nhất, nên nạp đầu tiên.
- `face_landmarker.task` - retouch da/mắt/răng, và cần cho "xóa người lạ".
- `lama.onnx` hoặc `migan.onnx` - xóa vật thể đẹp hơn thuật toán cổ điển (MI-GAN nhẹ hơn).
- `hair_segmenter.tflite` - nhuộm tóc; `efficientdet_lite0.tflite` - nhận cả người quay lưng khi "xóa người lạ".
- `depth.onnx` (Depth Anything V2 **Small**, Apache-2.0; KHÔNG dùng bản Base/Large) - tùy chọn: Reframe 2.5D dùng độ sâu đo thật. Nếu sau khi nạp mà vật GẦN lại dịch ÍT hơn vật xa thì model của bạn xuất độ sâu thường (lớn = xa) - hãy báo lỗi kèm tên tệp model.
- Không cần nạp tất cả. Máy RAM thấp: nạp ít model nhỏ thôi, app tự nạp theo nhu cầu và nhả bớt khi thiếu bộ nhớ.

Về khóa Gemini (mức 2):

1. Tạo khóa trong Google AI Studio bằng tài khoản Google của bạn.
2. Dán vào *Cài đặt → Tạo ảnh → khóa Gemini*. Khóa được mã hóa lưu trên máy bạn và app gọi **thẳng tới Google**, không qua máy chủ của chủ app.
3. **Chi phí và hạn mức do Google quy định cho tài khoản của bạn.** Có thể có bậc miễn phí hay không tùy khu vực và model; chủ app chưa xác minh và không hứa miễn phí. Hãy tự xem trang giá/hạn mức của Google trước khi dùng nhiều. Không thích thì bỏ qua mức 2, các mức còn lại vẫn thử đầy đủ.

## 3. Nên thử những gì

Không cần làm hết; thử càng đa dạng càng tốt, nhất là trên **máy của bạn** (mỗi loại máy lỗi khác nhau):

- Mở ảnh lớn (≥ 12 MP) và ảnh nhỏ; xoay màn hình; mở lại phiên đã lưu từ màn hình đầu.
- Gõ vài yêu cầu khác nhau: `làm đẹp tự nhiên`, `tông điện ảnh`, `xóa nền`, `mờ phông`, `xóa người lạ`, `cắt vuông`.
- Tô tay lên vật thể rồi xóa (thử cả chế độ "xóa chính xác").
- **Mới (R25):** `làm nét lại` trên ảnh rung tay/mờ (và thử trên ảnh ĐÃ nét: phải báo không đổi); `khử moiré` trên ảnh chụp màn hình hoặc vải kẻ; `tranh sơn dầu`, `hoạt hình`, `màu nước`; thêm ảnh phủ rồi kéo thanh *Hòa màu với nền*. Nhìn kỹ: vòng sáng quanh cạnh, mất chi tiết, ảnh xấu/giả, hay chậm/giật ở ảnh lớn. **Giữ nguyên X (R27):** `làm sáng ảnh nhưng giữ nguyên khuôn mặt` / `tông ấm, trừ bầu trời` / gõ không dấu / tiếng Anh - da mặt có thật sự không đổi, viền có lệch không; ảnh không có mặt thì phải báo "Chưa chỉnh gì". **Best Take (R28):** nạp model Face Landmarker, chụp 3–5 ảnh nhóm liên tiếp bằng chân máy (mỗi người nhắm mắt / không cười ít nhất một lần), mở ảnh đầu → tab AI → *Best Take: thêm ảnh cùng cảnh* → *Chọn mặt đẹp nhất* - mắt có mở không, mối ghép quanh mặt có lộ không (lệch màu da, cổ / tóc), có ghép nhầm người không, người đang đẹp có bị đổi vô ích không; thử cả ảnh cầm tay và ảnh khác khung hình (phải báo bỏ qua). **Reframe 2.5D (R29):** mở ảnh phong cảnh có trời + đất và người / vật đứng giữa (nạp model tách nền), tab AI → *Reframe 2.5D: đổi góc nhìn* → kéo *Xoay ngang* ~50 % → *Áp dụng góc nhìn* - nền có trượt quanh chủ thể không, vệt mờ sau chủ thể (thử nền cỏ / gạch), quầng ở viền chủ thể, ảnh có bị phóng mất rìa quá không; thử ảnh trong nhà (độ sâu sai tới mức nào), ảnh không có chủ thể rõ, và ảnh 12 MP trên máy yếu (ghi thời gian + có hết RAM không).
Với mức 2 (có khóa Gemini): **Phác thảo → ảnh** (chip trong ô tô vùng: chọn màu, vẽ nét, gõ mô tả, *Vẽ thành ảnh*) - vật có đúng chỗ/màu nét không, có còn lộ nét vẽ không; `xóa phản chiếu`, `xóa bóng đổ`, `anime` - kết quả có giữ nguyên bố cục và khuôn mặt không?
- Chồng nhiều lớp, ẩn/hiện, đổi độ mờ, hoàn tác/làm lại nhiều lần.
- Lưu ảnh và chia sẻ; kiểm tra ảnh trong thư viện đúng như đã xem.
- Nạp 2-3 model cùng lúc rồi dùng liên tục xem máy có nóng/giật/bị tắt app không.

## 4. Khi gặp lỗi

1. Vào **Cài đặt → Gửi thông tin lỗi**. App gom: thông số máy (hãng, Android, RAM), model đã nạp, cài đặt (không kèm khóa/token), vài thao tác gần nhất và nhật ký trạng thái. Bạn **xem được toàn bộ nội dung trước khi gửi**.
2. Ghi ngắn *bạn đang làm gì* vào ô ghi chú, bấm **Gửi** rồi chọn Zalo/Telegram/email gửi cho người phát triển. Không có gì tự gửi đi.
3. **Không có trong báo cáo:** ảnh của bạn, khóa AI, token, tên tệp ảnh trong máy, email (đều được app tự che trước khi hiện).
4. Nếu app **đóng đột ngột** hoặc **bị hệ thống tắt** (hết bộ nhớ, treo), lần mở sau app tự hiện hộp thoại báo lỗi kèm sẵn báo cáo - chỉ cần bấm Gửi.
5. Nếu được, kèm **ảnh chụp màn hình** và ảnh gốc gây lỗi (gửi riêng, tùy bạn).

Lỗi nào cũng giúp ích, kể cả "kết quả xấu / không như mong đợi" - hãy ghi rõ bạn gõ gì và mong đợi gì.


## Trợ giúp và ngôn ngữ trong app

* **Hướng dẫn đầy đủ nằm ngay trong app:** bấm **?** ở thanh trên. Có ô tìm kiếm; bấm tiêu đề mục để mở / gập nội dung. Lần đầu mở app sẽ có hộp thoại chào, bấm "Xem hướng dẫn" để vào thẳng.
* **Đổi ngôn ngữ:** ⚙ → Ngôn ngữ (hoặc nút "Ngôn ngữ" ở hộp thoại chào). Có 13 lựa chọn và "Tự động (theo hệ thống)"; đổi là áp dụng ngay. Con số % cạnh tên ngôn ngữ là phần giao diện đã dịch, phần còn lại hiện bằng tiếng Anh.
* **Giúp dịch tốt hơn:** bản dịch do AI soạn, chưa có người bản ngữ kiểm. Thấy chỗ dịch sai / gượng, gửi kèm ảnh chụp màn hình và tên ngôn ngữ qua ⚙ → "Gửi thông tin lỗi" (ô mô tả), hoặc sửa thẳng tệp `tools/i18n/src/<mã>.txt` nếu bạn có repo.
* Ngôn ngữ giao diện **không** đổi cách app hiểu câu lệnh bạn gõ ở thẻ AI: bộ quy tắc offline hiểu tiếng Việt và tiếng Anh.

