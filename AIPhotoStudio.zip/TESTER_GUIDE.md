# Hướng dẫn dành cho tester - AI Photo Studio

Bản này đang ở giai đoạn **dùng thử miễn phí để bắt lỗi**. Bạn không phải trả tiền, ảnh xuất ra không có watermark, và máy chủ của chủ app
**không** dùng khóa AI của chủ app để chạy thay bạn (nên chủ app không tốn tiền khi bạn thử). Việc của bạn là dùng app thật và báo lại
chỗ nào sai, treo, đóng đột ngột hoặc kết quả xấu.

> Trung thực về tình trạng: mã nguồn đã qua rất nhiều bài kiểm tra tự động, nhưng bản APK đầu tiên **chưa từng được chạy trên máy thật** trước khi
> đến tay bạn. Rất có thể có lỗi - đó chính là lý do cần bạn.

## 1. Cài app

1. Nhận file `app-debug.apk` từ người gửi (hoặc tải từ GitHub: tab *Actions* → lần chạy *Build APK* mới nhất → *Artifacts* → `AIPhotoStudio-debug-apk`, giải nén).
2. Mở file trên điện thoại, cho phép *cài từ nguồn này* khi máy hỏi. Cần Android 8.0 trở lên.
3. Các bản build từ GitHub ký bằng cùng một khóa debug cố định nên **cài đè bản mới lên bản cũ được**, ảnh đã lưu và model đã nạp vẫn còn.
   Nếu máy báo xung đột chữ ký (chỉ xảy ra khi bản cũ của bạn đến từ nguồn khác), phải gỡ bản cũ rồi cài lại - khi đó **model đã nạp và phiên đã lưu sẽ mất**, hãy giữ lại các file model đã tải.

**Chọn đúng tệp trong *Artifacts*** (mỗi lần chạy *Build APK* có thể có tới 6 mục — **chỉ cần cài `AIPhotoStudio-debug-apk`**, các mục còn lại là tùy chọn hoặc không phải ứng dụng):

| Tên trong Artifacts | Là gì | Bạn cần? |
|---|---|---|
| `AIPhotoStudio-debug-apk` | **Bản thử chính**: nhắm Android 14 (targetSdk 34), có đủ tính năng, cài đè được lên bản cũ | **Cài cái này** |
| `AIPhotoStudio-perf-apk` | Cùng mã với bản chính nhưng dựng như bản bán (không debuggable) — dùng để SO ĐỘ MƯỢT (xem mục "So độ mượt" bên dưới); cài đè được vì cùng khóa ký | Tùy chọn: cài sau khi đã thử bản chính nếu muốn so |
| `AIPhotoStudio-perf-r8-apk` | Bản perf có R8 (thu nhỏ + tối ưu mã); chỉ xuất hiện khi chạy tay có tích ô **perf_r8**; thử nghiệm, R8 có thể cắt nhầm mã gây lỗi lạ | Không cần cho tester |
| `perf-r8-diagnostics` | Tệp văn bản chẩn đoán R8 (vài trăm KB), không phải ứng dụng | Không cài; gửi cho người phát triển nếu bản R8 lỗi |
| `compose-compiler-reports` | Báo cáo Compose compiler (nếu có), chỉ cho người phát triển | Không phải ứng dụng |
| `AIPhotoStudio-play-api36-apk` | Bản dựng thử theo điều kiện Google Play (targetSdk 36) để biết trước có đạt yêu cầu Play không | Không cần cài (cùng khóa nên vẫn cài được, nhưng chỉ dành cho kiểm tra) |
| `sd-server-arm64` | Chương trình tạo ảnh trên máy (stable-diffusion.cpp) — **đã nằm sẵn trong APK** | Không phải ứng dụng, đừng cài |

Biết mình đang cài đúng bản mới nhất chưa: mở **⚙ Cài đặt** → dòng **Phiên bản: x (mã N)**; N chính là số thứ tự lượt chạy trên trang *Actions* (chữ `#N` cạnh tên lần chạy).
Muốn bật cùng lúc Play Billing + LiteRT-LM + Play Integrity thật: *Run workflow* → tích ô **use_all** (một ô thay cho ba ô riêng).

**Màn hình rộng:** khi nằm ngang (rộng từ 600 dp) hoặc máy tính bảng / màn gập mở ra (rộng từ 840 dp), app tự chia **hai khung** — ảnh và thanh trên bên trái, bảng công cụ **cuộn được** bên phải; xoay máy không làm mất ảnh đang chỉnh. Cầm dọc trên điện thoại vẫn là một cột như trước.


## 2. Cần chuẩn bị gì? (làm đến mức nào tùy bạn)

| Mức | Bạn cần | Dùng được |
|---|---|---|
| **0 - không chuẩn bị gì** | Chỉ cài app | Chỉnh màu, làm đẹp cơ bản, cắt/xoay/lật, filter/Look, xóa vật thể nhẹ bằng thuật toán cổ điển, vẽ/gõ chữ, lớp và mặt nạ |
| **1 - vài model nhỏ trên máy** (nên làm) | Vào *⚙ Cài đặt → Tải model AI*, bấm *Tải* ở vài model nhỏ (app tự tải, kiểm tra và nạp); hoặc tự tải file rồi chọn bằng các nút *Chọn model …* | Tách nền, xóa vật thể chất lượng cao (LaMa), retouch khuôn mặt, nhuộm tóc, xóa người lạ chính xác hơn |
| **2 - tạo/thay vật thể bằng AI đám mây** | Khóa API Gemini **của chính bạn** | Thêm/thay vật thể, mở rộng ảnh, Agent AI qua Gemini |

Gợi ý model cho mức 1 (**nên bấm *Tải* trong app**; nguồn gốc và giấy phép từng model xem `README.md` mục 3; app KHÔNG tải gì khi bạn chưa bấm *Tải*, và bạn vẫn có thể tự tải file rồi chọn bằng nút *Chọn model …*):

- `u2netp.onnx` (~4.7 MB) - tách nền, nhỏ nhất, nên nạp đầu tiên.
- `face_landmarker.task` - retouch da/mắt/răng, và cần cho "xóa người lạ".
- `lama.onnx` hoặc `migan.onnx` - xóa vật thể đẹp hơn thuật toán cổ điển (MI-GAN nhẹ hơn).
- `hair_segmenter.tflite` - nhuộm tóc (đúng tên này; **đừng** dùng `hair_segmentation.tflite` — mô hình cũ, nạp vào sẽ báo lỗi); `efficientdet_lite0.tflite` - nhận cả người quay lưng khi "xóa người lạ".
- `depth.onnx` (Depth Anything V2 **Small**, Apache-2.0; KHÔNG dùng bản Base/Large) - tùy chọn: Reframe 2.5D dùng độ sâu đo thật. Nếu sau khi nạp mà vật GẦN lại dịch ÍT hơn vật xa thì model của bạn xuất độ sâu thường (lớn = xa) - hãy báo lỗi kèm tên tệp model.
- Không cần nạp tất cả. Máy RAM thấp: nạp ít model nhỏ thôi, app tự nạp theo nhu cầu và nhả bớt khi thiếu bộ nhớ.

Về khóa Gemini (mức 2):

1. Tạo khóa trong Google AI Studio bằng tài khoản Google của bạn.
2. Dán vào *Cài đặt → Tạo ảnh → khóa Gemini*. Khóa được mã hóa lưu trên máy bạn và app gọi **thẳng tới Google**, không qua máy chủ của chủ app.
3. **Chi phí và hạn mức do Google quy định cho tài khoản của bạn.** Có thể có bậc miễn phí hay không tùy khu vực và model; chủ app chưa xác minh và không hứa miễn phí. Hãy tự xem trang giá/hạn mức của Google trước khi dùng nhiều. Không thích thì bỏ qua mức 2, các mức còn lại vẫn thử đầy đủ.

## 3. Nên thử những gì

Không cần làm hết; thử càng đa dạng càng tốt, nhất là trên **máy của bạn** (mỗi loại máy lỗi khác nhau):

- Mở ảnh lớn (≥ 12 MP) và ảnh nhỏ; xoay màn hình; mở lại phiên đã lưu từ màn hình đầu.
- Gõ vài yêu cầu khác nhau: `làm đẹp tự nhiên`, `tông điện ảnh`, `xóa nền`, `mờ phông`, `xóa người lạ`, `cắt vuông`.
- Tô tay lên vật thể rồi xóa (thử cả chế độ "xóa chính xác").
- **Mới (R25):** `làm nét lại` trên ảnh rung tay/mờ (và thử trên ảnh ĐÃ nét: phải báo không đổi); `khử moiré` trên ảnh chụp màn hình hoặc vải kẻ; `tranh sơn dầu`, `hoạt hình`, `màu nước`; thêm ảnh phủ rồi kéo thanh *Hòa màu với nền*. Nhìn kỹ: vòng sáng quanh cạnh, mất chi tiết, ảnh xấu/giả, hay chậm/giật ở ảnh lớn. **Giữ nguyên X (R27):** `làm sáng ảnh nhưng giữ nguyên khuôn mặt` / `tông ấm, trừ bầu trời` / gõ không dấu / tiếng Anh - da mặt có thật sự không đổi, viền có lệch không; ảnh không có mặt thì phải báo "Chưa chỉnh gì". **Best Take (R28):** nạp model Face Landmarker, chụp 3–5 ảnh nhóm liên tiếp bằng chân máy (mỗi người nhắm mắt / không cười ít nhất một lần), mở ảnh đầu → tab AI → *Best Take: thêm ảnh cùng cảnh* → *Chọn mặt đẹp nhất* - mắt có mở không, mối ghép quanh mặt có lộ không (lệch màu da, cổ / tóc), có ghép nhầm người không, người đang đẹp có bị đổi vô ích không; thử cả ảnh cầm tay và ảnh khác khung hình (phải báo bỏ qua). **Reframe 2.5D (R29):** mở ảnh phong cảnh có trời + đất và người / vật đứng giữa (nạp model tách nền), tab AI → *Reframe 2.5D: đổi góc nhìn* → kéo *Xoay ngang* ~50 % → *Áp dụng góc nhìn* - nền có trượt quanh chủ thể không, vệt mờ sau chủ thể (thử nền cỏ / gạch), quầng ở viền chủ thể, ảnh có bị phóng mất rìa quá không; thử ảnh trong nhà (độ sâu sai tới mức nào), ảnh không có chủ thể rõ, và ảnh 12 MP trên máy yếu (ghi thời gian + có hết RAM không).
Với mức 2 (có khóa Gemini): **Phác thảo → ảnh** (chip trong ô tô vùng: chọn màu, vẽ nét, gõ mô tả, *Vẽ thành ảnh*) - vật có đúng chỗ/màu nét không, có còn lộ nét vẽ không; `xóa phản chiếu`, `xóa bóng đổ`, `anime` - kết quả có giữ nguyên bố cục và khuôn mặt không?
- **Tải model trong app (R43):** *⚙ Cài đặt → Tải model AI*. Phải thấy danh sách model (tên, dung lượng, mô tả). Bấm **Tải** ⇒ hộp thoại **điều khoản** (giấy phép, dung lượng, cảnh báo rủi ro nếu có) ⇒ **Đồng ý và tải** ⇒ hiện "Đang tải N%" ⇒ xong thì dòng đó đổi thành **Đã có** và tính năng tương ứng dùng được (vd. tải *U²-Net-P* rồi thử `xóa nền`). Thử: bấm **Hủy** giữa chừng; tắt Wi-Fi / bật chế độ máy bay giữa chừng (phải báo "Mất kết nối…" và khi bật lại bấm *Tải* thì **tiếp tục từ chỗ đã tải**, không tải lại từ đầu); tải lần 2 cùng model (không hỏi điều khoản nữa); máy gần đầy bộ nhớ (phải báo "Không đủ dung lượng"). Thử Wi-Fi / 4G, thoát app khi đang tải và nút Gỡ: xem mục R44 ngay dưới. Nếu thấy "Tệp tải về không khớp mã SHA-256" hoặc "Tải … lỗi" thì chụp màn hình gửi kèm tên model. **Lưu ý:** danh mục mới nhất lấy từ GitHub Release của kho; nếu người phát triển chưa chạy workflow *Mirror models*, app báo "Chưa lấy được danh mục mới…" nhưng vẫn tải được 8 model trong danh mục có sẵn (gồm LaMa) từ nguồn gốc của chúng.
- **Chỉ tải bằng Wi-Fi, tải nền, gỡ từng model (R44):** cùng mục *⚙ Cài đặt → Tải model AI*. **(1)** Công tắc **Chỉ tải bằng Wi-Fi** mặc định BẬT; dòng "Mạng hiện tại" phải đổi đúng khi bạn bật / tắt Wi-Fi. Tắt Wi-Fi (chỉ để 4G/5G) rồi bấm **Tải** ⇒ KHÔNG được tải, hiện "Đang chờ Wi-Fi" cùng nút **Tải bằng dữ liệu di động lần này**; bật Wi-Fi lại ⇒ tự tải tiếp (không cần bấm). Đang tải bằng Wi-Fi mà tắt Wi-Fi ⇒ phải **tạm dừng** (không báo lỗi, giữ phần đã tải) và tự tiếp tục khi có Wi-Fi. Tắt công tắc ⇒ tải được bằng 4G. Thử thêm: Wi-Fi phát từ điện thoại khác (hệ điều hành coi là có tính cước ⇒ phải chờ). **(2)** Bấm **Tải** ở 2–3 model ⇒ xếp hàng, tải lần lượt; **Hủy** từng dòng hoặc **Hủy tất cả**. **(3)** **Thoát app khi đang tải** (nút Home hoặc vuốt app khỏi danh sách gần đây): thanh thông báo vẫn hiện tiến độ (Android 13+: app hỏi quyền thông báo MỘT lần — từ chối vẫn tải, chỉ không thấy thông báo); nút **Hủy** trên thông báo dừng tất cả; tải xong khi app ở nền ⇒ có thông báo "Đã tải xong …"; mở lại app ⇒ model hiện **Đã có** và dùng được. **(4)** Model đã có hiện nút **Gỡ** ⇒ hộp thoại xác nhận ⇒ model hết "Đã có", tính năng tương ứng chuyển sang cách dự phòng, các model khác vẫn giữ nguyên; tải lại được. MobileSAM gồm hai tệp nên gỡ một thì cả hai bị xóa. Nếu có gì lạ, chụp màn hình kèm tên model và loại mạng (Wi-Fi / 4G / máy bay).
- **Mở ảnh, thanh trên, nút Back (R45) — THỬ LẠI NGAY SAU KHI CÀI BẢN MỚI:** **(1)** Mở app khi chưa có ảnh: thanh trên phải thấy ĐỦ 7 nút (Mở, ↶, ↷, Lưu, ↗, ?, ⚙) trong MỘT hàng thấp (~1 cm), KHÔNG còn khoảng trống lớn phía trên; ô ảnh (ca-rô) nằm ngay dưới thanh trên. Thử với chữ hệ thống cỡ lớn ("Kích thước phông chữ" tối đa) — hàng nút có thể cuộn ngang nhưng không được cao vọt. **(2)** Bấm **Mở**: hiện bộ chọn ảnh ⇒ chọn ảnh ⇒ ảnh PHẢI hiện trong ô ảnh (cả khi thẻ AI đang mở). Nếu không hiện bộ chọn: phải xuất hiện dòng "Chưa chọn ảnh nào…" ngay lập tức (ghi lại điều này!); khi đó thử **Chọn từ trình quản lý tệp** ở giữa ô ảnh. **(3)** Kéo-thả một ảnh vào app: ảnh phải hiện (trước đây vùng ảnh cao 0). **(4)** Nút **Back** / vuốt quay lại khi đang tô hoặc đang mở thẻ AI / Công cụ: lần 1 thoát chế độ tô, lần 2 thu gọn thẻ (thấy trọn ảnh), lần 3 hiện hộp thoại "Thoát khỏi AI Photo Studio?" (Ở lại / Thoát); chưa mở ảnh thì Back thoát bình thường. Báo lại: model điện thoại, kích thước màn hình, có thấy bộ chọn ảnh không, dòng thông báo nào hiện ra.
- **Phóng to / Upscale (R46):** mở ảnh bất kỳ ⇒ thẻ **Phóng to** (hàng tab dưới, cạnh Cắt / Xoay). Phải thấy: dòng "Ảnh hiện tại: R×C"; hàng chip **×2 ×3 ×4 Full HD 2K 4K**; dòng "Kết quả: R×C (×hệ số), khoảng N MP" đổi theo chip (ảnh đã đủ lớn thì báo "không cần phóng thêm"; ảnh lớn thì có dòng "Bị giới hạn…" nói rõ vì sao); dòng "Phóng bằng AI (Real-ESRGAN)…" — lần đầu mở app model AI đã được nạp sẵn (nếu thấy "Chưa có model AI" thì bấm **Dùng model AI có sẵn trong app**). Bấm **Phóng to ảnh**: thanh trạng thái và thẻ báo "Đang phóng to: n/N ô, còn khoảng … giây"; bấm **Hủy** giữa chừng ⇒ dừng, ảnh KHÔNG đổi; xong ⇒ ảnh to hơn, ↶ hoàn tác được. **Ghi lại:** model điện thoại, kích thước ảnh, hệ số, **thời gian thực tế** (ảnh 1080×2400 ×2 là 60 ô, ×4 là 230 ô — máy yếu có thể mất vài phút), và so sánh bằng mắt với nội suy (gỡ model hoặc thử máy khác). Nút **Giấy phép model** phải hiện văn bản BSD-3 của Real-ESRGAN.
- **Kéo-thả ảnh từ trình quản lý tệp (R42):** mở ứng dụng quản lý tệp cạnh AI Photo Studio — chia đôi màn hình, cửa sổ nổi / cửa sổ nhỏ, hoặc chế độ desktop của máy — rồi chạm giữ một ảnh và kéo sang AI Photo Studio. Phải thấy lớp phủ **"Thả ảnh vào đây để mở"** khi ngón tay vào cửa sổ app và lớp phủ biến mất khi kéo ra ngoài / hủy. Thả ảnh ⇒ mở như khi bấm *Mở* (ảnh đang chỉnh trước đó nằm lại trong danh sách phiên). Thử: JPG / PNG / WebP / HEIC; một tệp KHÔNG phải ảnh (phải báo "không phải ảnh", không văng); thả nhiều ảnh (chỉ mở ảnh đầu tiên); thả lúc app đang xử lý (phải báo "Đang xử lý"); thả khi đã có ảnh đang chỉnh. **Không phải trình quản lý tệp nào cũng cho kéo ảnh ra ngoài** — nếu chạm giữ mà không kéo được thì đó là giới hạn của ứng dụng kia; khi báo lỗi hãy ghi tên ứng dụng quản lý tệp và dòng máy.
- Chồng nhiều lớp, ẩn/hiện, đổi độ mờ, hoàn tác/làm lại nhiều lần.
- Lưu ảnh và chia sẻ; kiểm tra ảnh trong thư viện đúng như đã xem.
- Nạp 2-3 model cùng lúc rồi dùng liên tục xem máy có nóng/giật/bị tắt app không.

## 4. Khi gặp lỗi

1. Vào **Cài đặt → Gửi thông tin lỗi**. App gom: thông số máy (hãng, Android, RAM), model đã nạp, cài đặt (không kèm khóa/token), vài thao tác gần nhất và nhật ký trạng thái. Bạn **xem được toàn bộ nội dung trước khi gửi**.
2. Ghi ngắn *bạn đang làm gì* vào ô ghi chú, bấm **Gửi** rồi chọn Zalo/Telegram/email gửi cho người phát triển. Không có gì tự gửi đi.
3. **Không có trong báo cáo:** ảnh của bạn, khóa AI, token, tên tệp ảnh trong máy, email (đều được app tự che trước khi hiện).
4. Nếu app **đóng đột ngột** hoặc **bị hệ thống tắt** (hết bộ nhớ, treo), lần mở sau app tự hiện hộp thoại báo lỗi kèm sẵn báo cáo - chỉ cần bấm Gửi.
5. Nếu được, kèm **ảnh chụp màn hình** và ảnh gốc gây lỗi (gửi riêng, tùy bạn).

Lỗi nào cũng giúp ích, kể cả "kết quả xấu / không như mong đợi" - hãy ghi rõ bạn gõ gì và mong đợi gì.


## Trợ giúp và ngôn ngữ trong app

* **Hướng dẫn đầy đủ nằm ngay trong app:** bấm **?** ở thanh trên. Có ô tìm kiếm; bấm tiêu đề mục để mở / gập nội dung. Lần đầu mở app sẽ có hộp thoại chào, bấm "Xem hướng dẫn" để vào thẳng.
* **Đổi ngôn ngữ:** ⚙ → Ngôn ngữ (hoặc nút "Ngôn ngữ" ở hộp thoại chào). Có 13 lựa chọn và "Tự động (theo hệ thống)"; đổi là áp dụng ngay. Con số % cạnh tên ngôn ngữ là phần giao diện đã dịch, phần còn lại hiện bằng tiếng Anh.
* **Giúp dịch tốt hơn:** bản dịch do AI soạn, chưa có người bản ngữ kiểm. Thấy chỗ dịch sai / gượng, gửi kèm ảnh chụp màn hình và tên ngôn ngữ qua ⚙ → "Gửi thông tin lỗi" (ô mô tả), hoặc sửa thẳng tệp `tools/i18n/src/<mã>.txt` nếu bạn có repo.
* Ngôn ngữ giao diện **không** đổi cách app hiểu câu lệnh bạn gõ ở thẻ AI: bộ quy tắc offline hiểu tiếng Việt và tiếng Anh.

## So độ mượt: bản debug và bản "perf" (R36)

Bản tester là build **debug**, mà Compose ở bản debug chạy chậm hơn bản thật khá nhiều, nên "giật" có thể do build chứ không do mã. Mỗi lần chạy Build APK còn dựng thêm bản **perf** (giống bản bán, không debuggable, ký cùng khóa nên cài ĐÈ được):

1. Vào lần chạy Build APK → mục **Artifacts** → tải `AIPhotoStudio-perf-apk`, giải nén, cài đè lên bản đang có (cùng máy).
2. So hai bản ở thẻ Công cụ (kéo thanh trượt), vuốt chuyển thẻ, mở thẻ Looks; ghi lại "mượt hơn rõ / hơi / như nhau".
3. Mở trang **Summary** của lần chạy → mục "Báo cáo Compose compiler" và dán vào chat cùng kết quả bước 2. Job này không chặn bản tester: nếu nó đỏ, bản debug vẫn cài bình thường.

## Thử nhập bằng giọng nói và rung khi kéo (R35)

* **Giọng nói:** thẻ AI → bấm **🎤** cạnh ô yêu cầu → nói, ví dụ "làm sáng ảnh, da mịn hơn". Phải thấy: hộp nhận dạng của hệ thống hiện ra (app KHÔNG xin quyền micro), chữ nghe được nằm trong ô yêu cầu, app KHÔNG tự chạy — bạn bấm **Chỉnh**. Nói thêm lần nữa sẽ nối vào ô. Đổi ngôn ngữ giao diện sang English rồi nói "make it brighter" để thử nhận dạng tiếng Anh.
* **Máy không có dịch vụ nhận dạng** (không có Google): bấm 🎤 phải hiện thông báo "Máy chưa có dịch vụ nhận dạng giọng nói…" và app không văng. Nếu gặp bất cứ điều gì lạ, mở ⚙ → "Gửi thông tin lỗi" và dán nhật ký chẩn đoán.
* **Rung khi kéo:** thẻ Công cụ → kéo một thanh trượt chậm từ đầu đến cuối: sẽ cảm nhận ~10 nhịp rung nhẹ, rồi một nhịp mạnh hơn khi thả tay (nếu tắt "phản hồi xúc giác" của hệ thống thì không rung — bình thường).

