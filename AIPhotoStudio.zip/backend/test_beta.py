"""Kiểm thử chế độ DÙNG THỬ MIỄN PHÍ (R23, OPEN_BETA). Được test_server.py gọi (dùng chung máy chủ thử, cấu hình đổi tại chỗ như các phần khác)."""
import base64
import os
import time

import server


def run(cfg, srv, base, results, ok, call, png):
    store = srv.store
    p = base64.b64encode(png()).decode()
    fill = {"image": p, "mask": p, "prompt": "a red cat", "quality": "fast"}
    high = {**fill, "quality": "high"}
    plan = {"image": p, "prompt": "nhuộm tóc nâu, sáng hơn"}
    n = [0]

    def reg():
        n[0] += 1
        did = "beta-device-%04d" % n[0]
        st, r = call(base, "POST", "/v1/register", {"device_id": did})
        return did, {"Authorization": "Bearer " + r["token"]}

    def acct(h):
        return call(base, "GET", "/v1/account", headers=h)[1]

    saved = (cfg.open_beta, cfg.beta_daily_limit, cfg.free_high_quality, cfg.upstream, cfg.billing_mode, cfg.beta_global_limit, cfg.beta_owner_pays, cfg.routing_file)
    # Các phần ngay dưới kiểm cơ chế trần/không-trừ-credits khi CHỦ APP TỰ NGUYỆN TRẢ (BETA_OWNER_PAYS=1); mặc định (không trả) kiểm ở đoạn "chủ app không trả" cuối tệp.
    cfg.beta_owner_pays = True
    cfg.beta_global_limit = 0       # các phần dưới kiểm trần theo thiết bị riêng; trần toàn máy chủ có đoạn riêng ở cuối

    # ------------------------------------------------------------ mặc định
    # test_server.py đặt OPEN_BETA=0 ở môi trường để các phần cũ kiểm hành vi tính phí; ở đây gỡ nó ra để đo MẶC ĐỊNH thật của mã.
    saved_env = {k: os.environ.pop(k, None) for k in ("OPEN_BETA", "BETA_DAILY_LIMIT", "BETA_GLOBAL_LIMIT", "BETA_OWNER_PAYS")}
    try:
        dc = server.Config()
        results.append(ok(dc.open_beta is True and dc.beta_daily_limit == 100 and dc.beta_global_limit == 2000,
                          "cấu hình mặc định: dùng thử miễn phí BẬT, trần 100 lượt/thiết bị/ngày và 2000 lượt/toàn máy chủ"))
        results.append(ok(dc.beta_owner_pays is False and server.server_ai_off(dc) is True,
                          "cấu hình mặc định: chủ app KHÔNG trả tiền AI (máy chủ không dùng khóa của chủ)"))
        os.environ["OPEN_BETA"] = "0"
        os.environ["BETA_DAILY_LIMIT"] = "7"
        os.environ["BETA_GLOBAL_LIMIT"] = "55"
        os.environ["BETA_OWNER_PAYS"] = "1"
        dc = server.Config()
        results.append(ok(dc.open_beta is False and dc.beta_daily_limit == 7 and dc.beta_global_limit == 55 and dc.beta_owner_pays is True,
                          "biến môi trường OPEN_BETA=0 / BETA_DAILY_LIMIT=7 / BETA_GLOBAL_LIMIT=55 / BETA_OWNER_PAYS=1 có hiệu lực"))
        results.append(ok(server.server_ai_off(dc) is False, "OPEN_BETA=0: không chặn AI máy chủ (tính phí như cũ)"))
    finally:
        for k, v in saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    # ------------------------------------------------------------ OPEN_BETA=0: hành vi tính phí cũ còn nguyên (module để đó, bật lại được)
    cfg.open_beta = False
    cfg.beta_daily_limit = 100
    cfg.free_high_quality = False
    d0, h0 = reg()
    a = acct(h0)
    results.append(ok(a["open_beta"] is False and a["limits"]["watermark"] is True and a["limits"]["high_quality"] is False and a["daily_limit"] == 0,
                      "OPEN_BETA=0: /v1/account báo có watermark, không chất lượng cao, không có trần ngày"))
    st, r = call(base, "POST", "/v1/generative_fill", high, h0)
    results.append(ok(st == 403 and r.get("code") == "pro_required", "OPEN_BETA=0: chất lượng cao vẫn cần Pro -> 403"))
    st, r = call(base, "POST", "/v1/generative_fill", fill, h0)
    results.append(ok(st == 200 and r["credits"] == a["credits"] - cfg.cost_fast, "OPEN_BETA=0: vẫn trừ credits như cũ"))
    results.append(ok(store.usage_today(d0) == 0, "OPEN_BETA=0: không ghi lượt dùng (bảng usage không phình)"))
    st, r = call(base, "GET", "/v1/routing?tier=mid", headers=h0)
    results.append(ok(r["server_hint"]["plan"] == "free", "OPEN_BETA=0: định tuyến báo plan=free cho tài khoản Free"))

    # ------------------------------------------------------------ OPEN_BETA=1
    cfg.open_beta = True
    cfg.beta_daily_limit = 100
    d1, h1 = reg()
    a = acct(h1)
    results.append(ok(a["open_beta"] is True and a["limits"]["watermark"] is False and a["limits"]["high_quality"] is True,
                      "dùng thử: /v1/account báo KHÔNG watermark, được chất lượng cao"))
    results.append(ok(a["plan"] == "free" and a["plan_until"] == 0, "dùng thử: không giả làm Pro (plan vẫn là free, trung thực)"))
    results.append(ok(a["daily_limit"] == 100 and a["usage_today"] == 0, "dùng thử: báo trần 100 và đã dùng 0"))
    cr0 = a["credits"]

    st, r = call(base, "POST", "/v1/generative_fill", high, h1)
    results.append(ok(st == 200 and r["credits"] == cr0, "dùng thử: chất lượng cao KHÔNG cần Pro và KHÔNG trừ credits"))
    st, r = call(base, "POST", "/v1/generative_fill", fill, h1)
    results.append(ok(st == 200 and r["credits"] == cr0, "dùng thử: chất lượng nhanh không trừ credits"))
    st, r = call(base, "POST", "/v1/edit_plan", plan, h1)
    results.append(ok(st == 200 and r["credits"] == cr0 and len(r.get("plan", {}).get("ops", [])) > 0, "dùng thử: Agent AI (edit_plan) trả kế hoạch, không trừ credits"))
    results.append(ok(acct(h1)["usage_today"] == 3, "dùng thử: ghi đúng 3 lượt thành công"))
    st, r = call(base, "GET", "/v1/routing?tier=mid", headers=h1)
    results.append(ok(r["server_hint"]["plan"] == "pro", "dùng thử: định tuyến cho cấu hình đầy đủ (plan=pro), tester dùng đủ tính năng"))

    # tài khoản hết sạch credits vẫn dùng được (đây là điểm mấu chốt của dùng thử)
    d2, h2 = reg()
    store.db.execute("UPDATE accounts SET credits=0 WHERE device_id=?", (d2,))
    st, r = call(base, "POST", "/v1/generative_fill", fill, h2)
    results.append(ok(st == 200 and r["credits"] == 0, "dùng thử: tài khoản 0 credits vẫn dùng được (không bị 402)"))
    st, r = call(base, "POST", "/v1/edit_plan", plan, h2)
    results.append(ok(st == 200, "dùng thử: 0 credits vẫn dùng được Agent AI"))
    # tắt dùng thử -> lại bị 402 (chứng minh cổng tính phí còn nguyên, chỉ bị bỏ qua)
    cfg.open_beta = False
    st, r = call(base, "POST", "/v1/generative_fill", fill, h2)
    results.append(ok(st == 402, "tắt dùng thử: cùng tài khoản 0 credits -> 402 (cổng tính phí vẫn còn)"))
    cfg.open_beta = True

    # ------------------------------------------------------------ lỗi nhà cung cấp không tính vào trần
    d3, h3 = reg()
    cfg.upstream = "fail"
    st, r = call(base, "POST", "/v1/generative_fill", fill, h3)
    st2, r2 = call(base, "POST", "/v1/edit_plan", plan, h3)
    cfg.upstream = "mock"
    results.append(ok(st == 502 and st2 == 502 and store.usage_today(d3) == 0, "nhà cung cấp lỗi (502) KHÔNG tính vào trần dùng trong ngày"))

    # ------------------------------------------------------------ trần dùng trong ngày
    cfg.beta_daily_limit = 3
    d4, h4 = reg()
    sts = [call(base, "POST", "/v1/generative_fill", fill, h4)[0] for _ in range(3)]
    st, r = call(base, "POST", "/v1/generative_fill", fill, h4)
    results.append(ok(sts == [200, 200, 200] and st == 429 and r.get("code") == "beta_daily_limit", "trần 3: 3 lượt đầu 200, lượt thứ 4 -> 429 beta_daily_limit"))
    results.append(ok("giới hạn" in r.get("error", ""), "429 có thông báo tiếng Việt cho người dùng"))
    st, r = call(base, "POST", "/v1/edit_plan", plan, h4)
    results.append(ok(st == 429 and r.get("code") == "beta_daily_limit", "trần dùng chung cho cả generative_fill và edit_plan"))
    a = acct(h4)
    results.append(ok(a["usage_today"] == 3 and a["daily_limit"] == 3, "bị chặn không ghi thêm lượt; /v1/account báo 3/3"))
    results.append(ok(call(base, "GET", "/v1/credits", headers=h4)[0] == 200 and call(base, "GET", "/v1/routing?tier=mid", headers=h4)[0] == 200,
                      "chạm trần chỉ chặn lệnh gọi AI tốn tiền; tải cấu hình/xem tài khoản vẫn được"))
    d5, h5 = reg()
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, h5)[0] == 200, "trần tính RIÊNG từng thiết bị (thiết bị khác không bị ảnh hưởng)"))

    # cửa sổ trượt 24 giờ: lượt cũ hơn 24h không tính; lượt cũ hơn 2 ngày được dọn
    now = time.time()
    d6, h6 = reg()
    store.usage_note(d6, now - 90000)           # 25 giờ trước
    store.usage_note(d6, now - 3600)            # 1 giờ trước
    results.append(ok(store.usage_today(d6, now) == 1, "cửa sổ 24 giờ: lượt 25 giờ trước không tính, lượt 1 giờ trước có tính"))
    store.usage_note(d6, now - 200000)          # 55 giờ trước
    store.usage_note(d6, now)                   # ghi mới -> dọn dòng > 2 ngày
    left = store.db.execute("SELECT COUNT(*) FROM usage WHERE device_id=?", (d6,)).fetchone()[0]
    results.append(ok(left == 3, "dọn dòng quá 2 ngày của thiết bị khi ghi lượt mới (còn đúng 3)"))
    cfg.beta_daily_limit = 2
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, h6)[0] == 429, "đã có 2 lượt trong 24 giờ + trần 2 -> chặn"))
    cfg.beta_daily_limit = 0
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, h6)[0] == 200, "BETA_DAILY_LIMIT=0 -> không giới hạn"))
    a = acct(h6)
    results.append(ok(a["daily_limit"] == 0, "BETA_DAILY_LIMIT=0 -> /v1/account báo daily_limit=0 (không giới hạn)"))

    # ------------------------------------------------------------ Team + dùng thử: quỹ nhóm không bị trừ
    cfg.beta_daily_limit = 100
    saved_team = cfg.team_enabled
    cfg.team_enabled = True
    dm, hm = reg()
    st, r = call(base, "POST", "/v1/admin/team", {"action": "create", "admin_device": dm, "name": "Beta Studio", "seats": 2, "credits": 5},
                 {"X-Admin-Key": "adm"})
    before = acct(hm)["credits"]
    st, r = call(base, "POST", "/v1/generative_fill", high, hm)
    results.append(ok(st == 200 and r["credits"] == before and store.team_info(dm)["credits"] == 5, "dùng thử + Team: quỹ chung KHÔNG bị trừ"))
    cfg.team_enabled = saved_team

    # ------------------------------------------------------------ trần TOÀN MÁY CHỦ (chốt chặn ngân sách; trần theo thiết bị chỉ là mềm vì ai cũng đăng ký được mã mới)
    cfg.beta_daily_limit = 100
    base_total = store.usage_total_today()
    cfg.beta_global_limit = base_total + 3
    dg1, hg1 = reg()
    dg2, hg2 = reg()
    sts = [call(base, "POST", "/v1/generative_fill", fill, hg1)[0], call(base, "POST", "/v1/edit_plan", plan, hg2)[0],
           call(base, "POST", "/v1/generative_fill", fill, hg2)[0]]
    results.append(ok(sts == [200, 200, 200], "trần toàn máy chủ: 3 lượt cuối trước ngưỡng vẫn qua (cộng dồn từ nhiều thiết bị và cả hai loại lệnh)"))
    st, r = call(base, "POST", "/v1/generative_fill", fill, hg1)
    st2, r2 = call(base, "POST", "/v1/edit_plan", plan, hg2)
    results.append(ok(st == 429 and r.get("code") == "beta_global_limit" and st2 == 429 and r2.get("code") == "beta_global_limit",
                      "trần toàn máy chủ: thiết bị nào cũng bị 429 beta_global_limit khi tổng đã đủ"))
    results.append(ok("hết lượt" in r.get("error", "") and r.get("error") != "đã đạt giới hạn dùng thử trong ngày, mai dùng tiếp nhé",
                      "thông báo của trần toàn máy chủ khác thông báo trần cá nhân (người dùng biết không phải lỗi của mình)"))
    dg3, hg3 = reg()
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, hg3)[0] == 429, "thiết bị MỚI đăng ký cũng bị chặn: lách trần theo thiết bị bằng mã thiết bị mới không ăn thua"))
    results.append(ok(call(base, "GET", "/v1/account", headers=hg3)[0] == 200 and call(base, "GET", "/v1/routing?tier=mid", headers=hg3)[0] == 200,
                      "chạm trần toàn máy chủ chỉ chặn lệnh gọi AI tốn tiền"))
    results.append(ok(store.usage_total_today() == base_total + 3, "bị chặn không ghi thêm lượt (tổng đúng bằng ngưỡng)"))
    # trần cá nhân được báo trước khi nói tới trần toàn máy chủ (người dùng nhiều biết mình dùng nhiều)
    cfg.beta_daily_limit = 1
    store.usage_note(dg1)
    st, r = call(base, "POST", "/v1/generative_fill", fill, hg1)
    results.append(ok(st == 429 and r.get("code") == "beta_daily_limit", "cả hai trần cùng chạm: báo trần theo thiết bị trước"))
    cfg.beta_daily_limit = 100
    # 0 = không giới hạn; nâng trần thì dùng tiếp được
    cfg.beta_global_limit = 0
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, hg3)[0] == 200, "BETA_GLOBAL_LIMIT=0 -> không giới hạn toàn máy chủ"))
    cfg.beta_global_limit = store.usage_total_today() + 1
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, hg3)[0] == 200 and call(base, "POST", "/v1/generative_fill", fill, hg3)[0] == 429,
                      "nâng trần thêm 1 lượt -> đúng 1 lượt nữa rồi lại chặn"))
    # chỉ lượt trong 24 giờ qua mới tính vào tổng
    now = time.time()
    cfg.beta_global_limit = 0
    t0 = store.usage_total_today(now)
    store.usage_note("beta-device-cu", now - 90000)
    results.append(ok(store.usage_total_today(now) == t0, "tổng toàn máy chủ: lượt 25 giờ trước không tính"))
    # OPEN_BETA=0: trần toàn máy chủ không có tác dụng
    cfg.beta_global_limit = 1
    cfg.open_beta = False
    cfg.free_high_quality = False
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, hg3)[0] == 200, "OPEN_BETA=0: trần toàn máy chủ không chặn (chỉ còn luật credits cũ)"))

    # ------------------------------------------------------------ MẶC ĐỊNH: chủ app KHÔNG trả tiền AI (BETA_OWNER_PAYS=0) -> 0 đồng nhà cung cấp
    cfg.open_beta = True
    cfg.beta_owner_pays = False
    cfg.beta_daily_limit = 100
    cfg.beta_global_limit = 2000
    cfg.billing_mode = "off"
    do, ho = reg()
    store.db.execute("UPDATE accounts SET credits=50 WHERE device_id=?", (do,))
    cr_before, tot_before = acct(ho)["credits"], store.usage_total_today()
    cfg.upstream = "fail"      # nếu máy chủ có thử gọi nhà cung cấp thì sẽ ra 502, KHÔNG ra 403 -> 403 chứng minh KHÔNG có cuộc gọi nào tới nhà cung cấp của chủ app
    st1, r1 = call(base, "POST", "/v1/generative_fill", fill, ho)
    st2, r2 = call(base, "POST", "/v1/generative_fill", high, ho)
    st3, r3 = call(base, "POST", "/v1/edit_plan", plan, ho)
    results.append(ok(st1 == 403 and st2 == 403 and st3 == 403 and all(x.get("code") == "byok_required" for x in (r1, r2, r3)),
                      "chủ app không trả: generative_fill (nhanh/cao) và edit_plan -> 403 byok_required, KHÔNG gọi nhà cung cấp (upstream=fail vẫn ra 403 chứ không 502)"))
    results.append(ok("khóa AI của bạn" in r1.get("error", "") and "model chạy trên máy" in r1.get("error", ""),
                      "câu báo lỗi chỉ cho tester cách tự chuẩn bị: nhập khóa AI của họ hoặc dùng model trên máy"))
    cfg.upstream = "mock"
    results.append(ok(call(base, "POST", "/v1/generative_fill", fill, ho)[0] == 403, "chủ app không trả: nhà cung cấp tốt cũng không được gọi (vẫn 403)"))
    results.append(ok(acct(ho)["credits"] == cr_before and store.usage_total_today() == tot_before and store.usage_today(do) == 0,
                      "chủ app không trả: không trừ credits, không ghi lượt dùng"))
    a = acct(ho)
    results.append(ok(a["open_beta"] is True and a["server_ai"] is False and a["daily_limit"] == 0 and a["limits"]["watermark"] is False,
                      "/v1/account báo server_ai=false (app biết máy chủ không cung cấp AI), không đòi trần, vẫn không watermark"))
    results.append(ok(call(base, "GET", "/v1/credits", headers=ho)[0] == 200 and call(base, "GET", "/v1/routing?tier=mid", headers=ho)[0] == 200,
                      "chủ app không trả: tài khoản/định tuyến vẫn dùng được (chỉ đường gọi AI tốn tiền bị chặn)"))
    # định tuyến không còn proxy_cloud nhưng vẫn còn đường trên máy
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=ho)
    kinds = [p["kind"] for t in rt["tasks"].values() for p in t["providers"]]
    results.append(ok("proxy_cloud" not in kinds and any(k == "sdcpp_local" for k in kinds) and len(rt["tasks"]["inpaint_remove"]["providers"]) >= 5,
                      "định tuyến chủ app không trả: bỏ proxy_cloud ở MỌI tác vụ, giữ nguyên nhà cung cấp trên máy"))
    # routing_file tùy chỉnh cũng bị lọc
    import json as _json, tempfile as _tf
    rf = os.path.join(_tf.mkdtemp(), "routing.json")
    with open(rf, "w", encoding="utf-8") as f:
        _json.dump({"version": 9, "tasks": {"a": {"providers": [{"id": "p", "kind": "proxy_cloud", "needs": []}, {"id": "q", "kind": "rules", "needs": []}]},
                                              "b": {"providers": [{"id": "p2", "kind": "proxy_cloud", "needs": []}]}}}, f)
    cfg.routing_file = rf
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=ho)
    results.append(ok([p["id"] for p in rt["tasks"]["a"]["providers"]] == ["q"] and rt["tasks"]["b"]["providers"] == [],
                      "ROUTING_FILE tùy chỉnh cũng bị lọc proxy_cloud (giữ phần còn lại)"))
    cfg.beta_owner_pays = True
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=ho)
    results.append(ok([p["id"] for p in rt["tasks"]["a"]["providers"]] == ["p", "q"], "chủ app tự nguyện trả (BETA_OWNER_PAYS=1): giữ proxy_cloud"))
    cfg.routing_file = ""
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=ho)
    results.append(ok(any(p["kind"] == "proxy_cloud" for p in rt["tasks"]["generative_fill"]["providers"]) and acct(ho)["server_ai"] is True,
                      "BETA_OWNER_PAYS=1: định tuyến mặc định có proxy_cloud trở lại, /v1/account báo server_ai=true"))
    results.append(ok(acct(ho)["daily_limit"] == 100, "BETA_OWNER_PAYS=1: /v1/account báo trần 100/ngày"))
    cfg.beta_owner_pays = False
    cfg.open_beta = False
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=ho)
    a = acct(ho)
    results.append(ok(any(p["kind"] == "proxy_cloud" for p in rt["tasks"]["generative_fill"]["providers"]) and a["server_ai"] is True,
                      "OPEN_BETA=0 (bán thật): định tuyến có proxy_cloud, server_ai=true (không ảnh hưởng đường tính phí)"))
    cfg.billing_mode = "off"
    st, r = call(base, "POST", "/v1/generative_fill", fill, ho)
    results.append(ok(st == 200 and r["credits"] == 50 - cfg.cost_fast, "OPEN_BETA=0: tính phí cũ chạy bình thường (không bị cổng byok chặn nhầm)"))

    cfg.open_beta, cfg.beta_daily_limit, cfg.free_high_quality, cfg.upstream, cfg.billing_mode, cfg.beta_global_limit, cfg.beta_owner_pays, cfg.routing_file = saved
