"""Kiểm thử gói Team/Enterprise (R22). Được test_server.py gọi (dùng chung máy chủ thử, cấu hình đổi tại chỗ như các phần khác)."""
import base64
import json
import threading
import time

import server


def run(cfg, srv, base, results, ok, call, png):
    store = srv.store
    p = base64.b64encode(png()).decode()
    fill = {"image": p, "mask": p, "prompt": "a red cat", "quality": "fast"}
    ADM = {"X-Admin-Key": "adm"}
    n = [0]

    def reg(prefix="team"):
        n[0] += 1
        did = "%s-device-%04d" % (prefix, n[0])
        st, r = call(base, "POST", "/v1/register", {"device_id": did})
        return did, {"Authorization": "Bearer " + r["token"]}

    def acct(h):
        return call(base, "GET", "/v1/account", headers=h)[1]

    def mk_team(admin_h_did, seats=3, credits=0, plan_days=0, name="Studio A"):
        did = admin_h_did
        st, r = call(base, "POST", "/v1/admin/team", {"action": "create", "admin_device": did, "name": name, "seats": seats,
                                                      "credits": credits, "plan_days": plan_days}, ADM)
        return st, r

    saved = (cfg.team_enabled, cfg.team_self_serve, cfg.team_default_seats, cfg.billing_mode, dict(cfg.team_products), cfg.upstream)

    # ------------------------------------------------------------ mặc định TẮT
    cfg.team_enabled = False
    da, ha = reg()
    st, r = call(base, "GET", "/v1/team", headers=ha)
    results.append(ok(st == 503, "Team tắt (mặc định): GET /v1/team -> 503"))
    st, r = call(base, "POST", "/v1/team/join", {"code": "AAAAA-AAAAA"}, ha)
    results.append(ok(st == 503, "Team tắt: join -> 503"))
    a = acct(ha)
    results.append(ok(a["team"] is None and a["credits_team"] == 0 and a["credits_personal"] == a["credits"], "Team tắt: /v1/account có team=null, credits_team=0, không đổi số dư"))
    results.append(ok(server.Config().team_enabled is False and server.Config().team_products == {} and server.Config().team_self_serve is False,
                      "cấu hình mặc định: Team TẮT, không tự cấp, chưa bán gói nào"))

    # ------------------------------------------------------------ bật; không tự cấp -> chỉ vận hành tạo
    cfg.team_enabled = True
    cfg.team_self_serve = False
    st, r = call(base, "POST", "/v1/team/create", {"name": "X"}, ha)
    results.append(ok(st == 403 and r.get("code") == "team_contract_only", "không tự cấp: người dùng tạo nhóm -> 403 team_contract_only"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "list"}, {"X-Admin-Key": "sai"})[0] == 403, "admin/team sai khóa -> 403"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "create", "admin_device": "khong-co-tai-khoan", "name": "N", "seats": 2}, ADM)[0] == 404,
                      "tạo nhóm cho tài khoản không tồn tại -> 404"))
    results.append(ok(mk_team(da, name="   ")[0] == 400, "tên nhóm rỗng -> 400"))
    results.append(ok(mk_team(da, seats=0)[0] == 400 and mk_team(da, seats=100000)[0] == 400, "số ghế 0 hoặc quá lớn -> 400"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "bay-gio"}, ADM)[0] == 400, "action lạ -> 400"))

    # ------------------------------------------------------------ nhóm theo hợp đồng
    st, r = mk_team(da, seats=3, credits=10, plan_days=30)
    code = r["invite_code"]
    team_id = r["team_id"]
    results.append(ok(st == 200 and len(code) == 11 and code[5] == "-" and all(c in server.INVITE_ALPHABET + "-" for c in code), "vận hành tạo nhóm: có mã mời dạng XXXXX-XXXXX"))
    st, t = call(base, "GET", "/v1/team", headers=ha)
    t = t["team"]
    results.append(ok(st == 200 and t["role"] == "admin" and t["seats"] == 3 and t["members"] == 1 and t["credits"] == 10 and t["plan_until"] > time.time(),
                      "quản trị viên xem nhóm: ghế 3, 1 thành viên, quỹ 10, Pro còn hạn"))
    raw = json.dumps(t)
    results.append(ok(da not in raw and len(t["member_list"]) == 1 and t["member_list"][0]["member_id"] == server.account_hash(da),
                      "danh sách thành viên chỉ có mã BĂM, không lộ mã thiết bị thật"))
    results.append(ok(mk_team(da)[0] == 409, "đã ở trong nhóm thì không tạo thêm -> 409"))
    dbhash = [x[0] for x in store.db.execute("SELECT invite_hash FROM teams").fetchall()]
    results.append(ok(code not in dbhash and code.replace("-", "") not in dbhash and server.invite_hash(code) in dbhash, "CSDL chỉ lưu BĂM mã mời, không lưu mã"))

    # thành viên: gõ mã chữ thường, không dấu gạch
    db_, hb = reg()
    st, r = call(base, "POST", "/v1/team/join", {"code": code.replace("-", "").lower()}, hb)
    results.append(ok(st == 200 and r["team"]["role"] == "member" and "member_list" not in r["team"], "thành viên vào bằng mã (không phân biệt hoa thường/dấu gạch); không thấy danh sách"))
    b = acct(hb)
    results.append(ok(b["plan"] == "pro" and b["credits_team"] == 10 and b["credits_personal"] == 2 and b["credits"] == 12 and b["limits"]["watermark"] is False,
                      "thành viên hưởng Pro của nhóm và thấy 2 (cá nhân) + 10 (quỹ) = 12"))
    st, r = call(base, "POST", "/v1/team/join", {"code": code}, hb)
    results.append(ok(st == 409, "đã ở trong nhóm -> join lại 409"))

    # dò mã: sai quá 10 lần -> 429, chỉ chặn thiết bị đó
    dc_, hc = reg()
    codes = [call(base, "POST", "/v1/team/join", {"code": "ZZZZZ-ZZZZ%d" % (i % 10)}, hc)[0] for i in range(server.JOIN_FAIL_LIMIT)]
    results.append(ok(all(c == 403 for c in codes), "mã sai -> 403 (10 lần đầu)"))
    results.append(ok(call(base, "POST", "/v1/team/join", {"code": code}, hc)[0] == 429, "sau 10 lần sai: kể cả mã đúng cũng 429 (chặn dò mã)"))
    dd, hd = reg()
    results.append(ok(call(base, "POST", "/v1/team/join", {"code": code}, hd)[0] == 200, "thiết bị khác không bị chặn lây"))
    de, he = reg()
    st, r = call(base, "POST", "/v1/team/join", {"code": code}, he)
    results.append(ok(st == 409 and "ghế" in r["error"], "hết ghế (3/3) -> 409"))

    # ------------------------------------------------------------ trừ credits: quỹ trước, ví sau; hoàn đúng nguồn
    st, r = call(base, "POST", "/v1/generative_fill", fill, hb)
    results.append(ok(st == 200 and r["credits"] == 11, "tạo ảnh trừ 1 từ QUỸ NHÓM (số dư dùng được 12 → 11)"))
    b = acct(hb)
    results.append(ok(b["credits_team"] == 9 and b["credits_personal"] == 2, "quỹ 10 → 9, ví cá nhân vẫn 2"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": team_id, "credits": -8}, ADM)
    results.append(ok(st == 200 and r["team"]["credits"] == 1, "vận hành thu lại 8 credits: quỹ còn 1"))
    st, r = call(base, "POST", "/v1/generative_fill", {**fill, "quality": "high"}, hb)     # giá 2: 1 từ quỹ + 1 từ ví
    b = acct(hb)
    results.append(ok(st == 200 and b["credits_team"] == 0 and b["credits_personal"] == 1 and r["credits"] == 1, "giá 2 mà quỹ chỉ còn 1: lấy 1 ở quỹ + 1 ở ví cá nhân"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": team_id, "credits": 1}, ADM)
    cfg.upstream = "fail"
    st, r = call(base, "POST", "/v1/generative_fill", {**fill, "quality": "high"}, hb)     # 1 quỹ + 1 ví -> lỗi nhà cung cấp -> hoàn đúng nguồn
    b = acct(hb)
    results.append(ok(st == 502 and b["credits_team"] == 1 and b["credits_personal"] == 1 and r["credits"] == 2, "nhà cung cấp lỗi: hoàn ĐÚNG nguồn (quỹ 1, ví 1), không hoàn nhầm"))
    cfg.upstream = "mock"
    st, r = call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": team_id, "credits": -1}, ADM)
    # rút ví cá nhân về 0 bằng cách dùng hết: 1 lần tạo ảnh (giá 1)
    call(base, "POST", "/v1/generative_fill", fill, hb)
    b = acct(hb)
    st, r = call(base, "POST", "/v1/generative_fill", fill, hb)
    results.append(ok(b["credits"] == 0 and st == 402 and r["credits"] == 0, "hết cả quỹ lẫn ví: 402, không trừ gì"))

    # ------------------------------------------------------------ Pro kế thừa & mất khi rời nhóm
    st, r = call(base, "POST", "/v1/team/leave", {}, hb)
    b = acct(hb)
    results.append(ok(st == 200 and b["plan"] == "free" and b["team"] is None and b["credits_team"] == 0, "thành viên rời nhóm: mất Pro, không còn quỹ"))
    st, r = call(base, "POST", "/v1/team/leave", {}, hb)
    results.append(ok(st == 404, "rời khi không ở nhóm nào -> 404"))
    st, r = call(base, "POST", "/v1/team/leave", {}, ha)
    results.append(ok(st == 409, "quản trị viên còn thành viên khác: không rời được -> 409"))

    # ------------------------------------------------------------ quản trị: xóa/chuyển quyền/đổi mã
    st, t = call(base, "GET", "/v1/team", headers=ha)
    mem = [m for m in t["team"]["member_list"] if m["role"] == "member"][0]["member_id"]
    results.append(ok(call(base, "POST", "/v1/team/remove", {"member_id": mem}, hd)[0] == 403, "thành viên thường không xóa được ai -> 403"))
    results.append(ok(call(base, "POST", "/v1/team/remove", {"member_id": server.account_hash(da)}, ha)[0] == 409, "không tự xóa mình -> 409"))
    results.append(ok(call(base, "POST", "/v1/team/remove", {"member_id": "khong-co"}, ha)[0] == 404, "xóa thành viên không có -> 404"))
    results.append(ok(call(base, "POST", "/v1/team/invite", {}, hd)[0] == 403, "thành viên thường không đổi được mã mời -> 403"))
    st, r = call(base, "POST", "/v1/team/invite", {}, ha)
    newcode = r["invite_code"]
    results.append(ok(newcode != code and call(base, "POST", "/v1/team/join", {"code": code}, he)[0] == 403, "đổi mã mời: mã mới khác mã cũ và mã cũ bị từ chối (403)"))
    results.append(ok(call(base, "POST", "/v1/team/remove", {"member_id": mem}, ha)[0] == 200, "quản trị viên xóa thành viên -> 200, trả ghế"))
    df, hf = reg()
    results.append(ok(call(base, "POST", "/v1/team/join", {"code": code}, hf)[0] == 403, "mã mời CŨ hết hiệu lực sau khi đổi -> 403"))
    results.append(ok(call(base, "POST", "/v1/team/join", {"code": newcode}, hf)[0] == 200, "mã mời mới dùng được"))
    st, t = call(base, "GET", "/v1/team", headers=ha)
    mem2 = [m for m in t["team"]["member_list"] if m["role"] == "member" and m["member_id"] != server.account_hash(dd)][0]["member_id"]
    st, r = call(base, "POST", "/v1/team/transfer", {"member_id": mem2}, ha)
    results.append(ok(st == 200 and r["team"]["role"] == "member", "chuyển quyền quản trị: người cũ thành thành viên"))
    st, t2 = call(base, "GET", "/v1/team", headers=hf)
    results.append(ok(t2["team"]["role"] == "admin" and len(t2["team"]["member_list"]) == 2, "người nhận quyền thành quản trị viên, thấy danh sách (2 người)"))
    results.append(ok(call(base, "POST", "/v1/team/remove", {"member_id": server.account_hash(dd)}, ha)[0] == 403, "quản trị viên cũ hết quyền xóa -> 403"))

    # ------------------------------------------------------------ quỹ nhóm: nạp từ ví cá nhân
    cfg.team_self_serve = True
    cfg.team_default_seats = 4
    dg, hg = reg()
    st, r = call(base, "POST", "/v1/team/create", {"name": "  Nhóm\tcủa\n  tôi\x00  "}, hg)
    results.append(ok(st == 200 and r["team"]["name"] == "Nhóm của tôi" and r["team"]["seats"] == 4 and len(r["invite_code"]) == 11,
                      "tự cấp: tạo nhóm, tên được làm sạch (khoảng trắng/ký tự điều khiển), ghế = TEAM_DEFAULT_SEATS (4)"))
    g = acct(hg)
    results.append(ok(g["plan"] == "free" and g["credits_team"] == 0, "nhóm tự tạo chưa có gói/credits (phải mua hoặc nạp)"))
    results.append(ok(call(base, "POST", "/v1/team/create", {"name": "Hai"}, hg)[0] == 409, "đã có nhóm: tạo nhóm thứ hai -> 409"))
    results.append(ok(call(base, "POST", "/v1/team/create", {"name": ""}, reg()[1])[0] == 400, "tự cấp: tên rỗng -> 400"))
    results.append(ok(call(base, "POST", "/v1/team/fund", {"credits": 0}, hg)[0] == 400, "nạp 0 -> 400"))
    results.append(ok(call(base, "POST", "/v1/team/fund", {"credits": "abc"}, hg)[0] == 400, "nạp không phải số -> 400"))
    results.append(ok(call(base, "POST", "/v1/team/fund", {"credits": 99}, hg)[0] == 402, "nạp nhiều hơn ví cá nhân -> 402"))
    results.append(ok(call(base, "POST", "/v1/team/fund", {"credits": 1}, hf)[0] == 200, "quản trị viên (đã nhận quyền) nạp được 1 credit vào quỹ nhóm của mình"))
    st, r = call(base, "POST", "/v1/team/fund", {"credits": 2}, hg)
    g = acct(hg)
    results.append(ok(st == 200 and g["credits_team"] == 2 and g["credits_personal"] == 0 and g["credits"] == 2, "nạp 2: ví cá nhân 2 → 0, quỹ 0 → 2, tổng dùng được không đổi"))
    dh, hh = reg()
    invg = call(base, "POST", "/v1/team/invite", {}, hg)[1]["invite_code"]
    results.append(ok(call(base, "POST", "/v1/team/join", {"code": invg}, hh)[0] == 200, "thành viên thứ hai vào nhóm tự tạo"))
    results.append(ok(call(base, "POST", "/v1/team/fund", {"credits": 1}, hh)[0] == 403, "thành viên thường không nạp quỹ nhóm -> 403"))
    st, r = call(base, "POST", "/v1/team/leave", {}, hh)
    # giải thể: quản trị viên là người cuối -> quỹ trả về ví cá nhân
    st, r = call(base, "POST", "/v1/team/leave", {}, hg)
    g = acct(hg)
    results.append(ok(st == 200 and g["team"] is None and g["credits_personal"] == 2, "quản trị viên cuối rời nhóm = giải thể, quỹ 2 trả về ví cá nhân"))
    results.append(ok(store.db.execute("SELECT COUNT(*) FROM team_members WHERE device_id=?", (dg,)).fetchone()[0] == 0, "giải thể xóa cả bản ghi thành viên"))

    # ------------------------------------------------------------ vận hành: sửa ghế/credits/hạn, danh sách, giải thể
    di, hi = reg()
    st, r = mk_team(di, seats=2, credits=5)
    tid = r["team_id"]
    code2 = r["invite_code"]
    dj, hj = reg()
    call(base, "POST", "/v1/team/join", {"code": code2}, hj)
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": tid, "seats": 1}, ADM)[0] == 409, "giảm ghế dưới số thành viên hiện có -> 409"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": tid, "credits": -6}, ADM)[0] == 409, "thu quá số quỹ đang có (âm) -> 409"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": "khong-co"}, ADM)[0] == 404, "cập nhật nhóm không tồn tại -> 404"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": tid, "seats": 10, "plan_days": 30}, ADM)
    results.append(ok(st == 200 and r["team"]["seats"] == 10 and r["team"]["plan_until"] > time.time() + 29 * 86400, "vận hành nâng ghế 10 và cấp 30 ngày Pro"))
    st1, until1 = call(base, "POST", "/v1/admin/team", {"action": "update", "team_id": tid, "plan_days": 30}, ADM)
    results.append(ok(until1["team"]["plan_until"] > r["team"]["plan_until"] + 29 * 86400, "cấp thêm hạn thì CỘNG DỒN từ hạn hiện tại"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "list"}, ADM)
    results.append(ok(st == 200 and any(x["team_id"] == tid and x["members"] == 2 for x in r["teams"]), "danh sách nhóm cho vận hành: có số thành viên"))
    before = acct(hi)["credits_personal"]
    st, r = call(base, "POST", "/v1/admin/team", {"action": "disband", "team_id": tid}, ADM)
    after = acct(hi)
    results.append(ok(st == 200 and r["returned_credits"] == 5 and after["credits_personal"] == before + 5 and after["team"] is None and acct(hj)["team"] is None,
                      "vận hành giải thể: quỹ 5 trả về quản trị viên, mọi thành viên ra khỏi nhóm"))

    # ------------------------------------------------------------ vận hành xử lý mất quản trị viên (cài lại app / mất máy)
    do, ho = reg()
    st, r = mk_team(do, seats=3, credits=2)
    codeO = r["invite_code"]; tidO = r["team_id"]
    dp, hp = reg()
    dq, hq = reg()
    call(base, "POST", "/v1/team/join", {"code": codeO}, hp)
    call(base, "POST", "/v1/team/join", {"code": codeO}, hq)
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "set_admin", "team_id": tidO, "device_id": dp}, {"X-Admin-Key": "sai"})[0] == 403, "set_admin sai khóa -> 403"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "set_admin", "team_id": tidO, "device_id": "khong-thuoc-nhom"}, ADM)[0] == 404, "set_admin cho thiết bị ngoài nhóm -> 404"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "set_admin", "team_id": "khong-co", "device_id": dp}, ADM)[0] == 404, "set_admin nhóm không có -> 404"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "remove", "team_id": tidO, "device_id": do}, ADM)[0] == 409, "vận hành không xóa trực tiếp quản trị viên -> 409"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "set_admin", "team_id": tidO, "device_id": dp}, ADM)
    tp = call(base, "GET", "/v1/team", headers=hp)[1]["team"]
    to = call(base, "GET", "/v1/team", headers=ho)[1]["team"]
    results.append(ok(st == 200 and tp["role"] == "admin" and to["role"] == "member" and "member_list" in tp and "member_list" not in to, "vận hành chuyển quyền: thành viên thành quản trị viên, người cũ thành thành viên"))
    results.append(ok(call(base, "POST", "/v1/team/invite", {}, ho)[0] == 403 and call(base, "POST", "/v1/team/invite", {}, hp)[0] == 200, "quyền quản trị mới có hiệu lực ngay (người cũ hết quyền)"))
    st, r = call(base, "POST", "/v1/admin/team", {"action": "remove", "team_id": tidO, "device_id": do}, ADM)
    results.append(ok(st == 200 and acct(ho)["team"] is None and call(base, "GET", "/v1/team", headers=hp)[1]["team"]["members"] == 2, "vận hành xóa thành viên cũ (mất máy): trả ghế, nhóm còn 2 người"))
    results.append(ok(call(base, "POST", "/v1/admin/team", {"action": "remove", "team_id": tidO, "device_id": do}, ADM)[0] == 404, "xóa lần hai (đã không còn trong nhóm) -> 404"))

    # ------------------------------------------------------------ mua gói Team qua Google Play (mock)
    cfg.billing_mode = "mock"
    cfg.team_products = {"team_30d": {"days": 30, "credits": 100, "seats": 8}}
    dk, hk = reg()
    dl, hl = reg()
    st, r = mk_team(dk, seats=3)
    code3 = r["invite_code"]
    call(base, "POST", "/v1/team/join", {"code": code3}, hl)
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-1"}, hl)
    results.append(ok(st == 403 and r.get("code") == "team_admin_required", "gói Team: thành viên thường mua -> 403 team_admin_required"))
    dm, hm = reg()
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-2"}, hm)
    results.append(ok(st == 403 and r.get("code") == "team_admin_required", "gói Team: người không có nhóm mua -> 403"))
    pk_before = acct(hk)["credits_personal"]
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-3"}, hk)
    t = acct(hk)["team"]
    results.append(ok(st == 200 and r["granted"] == 100 and t["credits"] == 100 and t["seats"] == 8 and t["plan_until"] > time.time() + 29 * 86400
                      and acct(hk)["credits_personal"] == pk_before and r["team"]["credits"] == 100,
                      "quản trị viên mua gói Team: +100 vào QUỸ NHÓM, ghế ≥ 8, +30 ngày Pro; ví cá nhân không đổi"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-3"}, hk)
    results.append(ok(st == 409 and acct(hk)["team"]["credits"] == 100, "cùng giao dịch đổi lần hai -> 409, không cộng thêm"))
    call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-4"}, hk)
    until_after = acct(hk)["team"]["plan_until"]
    results.append(ok(acct(hk)["team"]["credits"] == 200 and until_after > time.time() + 59 * 86400, "mua tiếp: quỹ cộng dồn 200, hạn cộng dồn ~60 ngày"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-personal-1"}, hk)
    results.append(ok(st == 200 and acct(hk)["credits_personal"] == pk_before + 20 and acct(hk)["team"]["credits"] == 200, "gói credits cá nhân vẫn vào VÍ CÁ NHÂN, không vào quỹ nhóm"))
    cfg.team_enabled = False      # tắt Team: mã sản phẩm Team không còn được hiểu là gói Team
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "team_30d", "purchase_token": "ok-team-5"}, hk)
    results.append(ok(st == 400, "Team tắt: mã sản phẩm Team không hợp lệ -> 400 (không cộng nhầm vào ví cá nhân)"))
    cfg.team_enabled = True

    # ------------------------------------------------------------ nguyên tử: nhiều thành viên trừ quỹ cùng lúc
    dn, hn = reg()
    st, r = mk_team(dn, seats=6, credits=10)
    codeN = r["invite_code"]
    devs = []
    for _ in range(4):
        d, h = reg("conc")
        store.db.execute("UPDATE accounts SET credits=0 WHERE device_id=?", (d,))
        call(base, "POST", "/v1/team/join", {"code": codeN}, h)
        devs.append(d)
    ok_count = [0]
    lk = threading.Lock()

    def worker(d):
        for _ in range(6):
            left, rec = store.charge_ex(d, 1, "race")
            if left is not None:
                with lk:
                    ok_count[0] += 1
    th = [threading.Thread(target=worker, args=(d,)) for d in devs]
    [x.start() for x in th]
    [x.join() for x in th]
    pool = store.team_info(devs[0])["credits"]
    results.append(ok(ok_count[0] == 10 and pool == 0, "4 thành viên trừ quỹ 10 credits cùng lúc: đúng 10 lần thành công, quỹ = 0 (không âm)"))
    ledger = store.db.execute("SELECT COALESCE(SUM(delta),0) FROM team_ledger WHERE team_id=(SELECT team_id FROM team_members WHERE device_id=?)", (devs[0],)).fetchone()[0]
    results.append(ok(ledger == 0, "sổ cái quỹ nhóm khớp số dư (10 cấp - 10 trừ = 0)"))

    # ------------------------------------------------------------ routing thấy Pro của nhóm; CSDL cũ tự nâng cấp
    st, r = call(base, "GET", "/v1/routing?tier=mid", headers=hl)
    results.append(ok(st == 200 and r["server_hint"]["plan"] == "pro", "routing coi thành viên của nhóm có Pro là Pro"))
    import os
    import sqlite3
    import tempfile
    old_path = os.path.join(tempfile.mkdtemp(), "old2.db")
    odb = sqlite3.connect(old_path)
    odb.execute("CREATE TABLE accounts(device_id TEXT PRIMARY KEY, credits INTEGER NOT NULL, created REAL)")
    odb.execute("INSERT INTO accounts VALUES('device-old-0002', 7, 0)")
    odb.commit(); odb.close()
    st2 = server.Store(old_path)
    st2.db.execute("SELECT 1 FROM teams LIMIT 1"); st2.db.execute("SELECT 1 FROM team_members LIMIT 1"); st2.db.execute("SELECT 1 FROM team_ledger LIMIT 1")
    results.append(ok(st2.credits("device-old-0002") == 7 and st2.team_info("device-old-0002") is None and not st2.is_pro("device-old-0002"),
                      "CSDL cũ (chưa có bảng nhóm) tự nâng cấp; tài khoản cũ không bị ảnh hưởng"))

    cfg.team_enabled, cfg.team_self_serve, cfg.team_default_seats, cfg.billing_mode, cfg.team_products, cfg.upstream = saved
