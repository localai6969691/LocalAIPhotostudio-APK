#!/usr/bin/env python3
"""Kiểm thử đầu-cuối máy chủ tham chiếu (không cần mạng): đăng ký, trừ/hoàn credits, 401/402/502, định tuyến, admin."""
import base64, json, os, struct, tempfile, threading, time, urllib.error, urllib.request, zlib

os.environ.update({"QUIET": "1", "UPSTREAM": "mock", "FREE_CREDITS": "2", "COST_FAST": "1", "COST_HIGH": "2",
                   "SECRET": "test-secret", "ADMIN_KEY": "adm", "PORT": "0", "OPEN_BETA": "0",
                   "RATE_REGISTER_PER_IP_HOUR": "0", "RATE_PER_DEVICE_MINUTE": "0",   # các phép thử cũ đăng ký / gọi dồn dập từ một IP; giới hạn tần suất do test_rate.py kiểm riêng
                   "DB_PATH": os.path.join(tempfile.mkdtemp(), "t.db")})
import server  # noqa: E402


def png(w=4, h=4):
    raw = b"".join(b"\x00" + b"\xff\x00\x00" * w for _ in range(h))
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


def call(base, method, path, body=None, headers=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(base + path, data=data, method=method, headers={"Content-Type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def main():
    cfg = server.Config()
    srv = server.serve(cfg)
    base = "http://127.0.0.1:%d" % srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    ok = lambda c, m: print(("PASS " if c else "FAIL ") + m) or c
    results = []

    results.append(ok(call(base, "GET", "/healthz")[0] == 200, "healthz"))
    st, r = call(base, "POST", "/v1/register", {"device_id": "device-12345678"})
    token = r["token"]
    results.append(ok(st == 200 and r["credits"] == 2, "đăng ký tặng 2 credits"))
    st, r2 = call(base, "POST", "/v1/register", {"device_id": "device-12345678"})
    results.append(ok(r2["credits"] == 2 and r2["token"] == token, "đăng ký lại không cộng thêm (idempotent)"))
    auth = {"Authorization": "Bearer " + token}
    results.append(ok(call(base, "GET", "/v1/credits")[0] == 401, "không token -> 401"))
    results.append(ok(call(base, "GET", "/v1/credits", headers={"Authorization": "Bearer x.y"})[0] == 401, "token giả -> 401"))

    p = base64.b64encode(png()).decode()
    body = {"image": p, "mask": p, "prompt": "a red cat", "quality": "fast"}
    st, r = call(base, "POST", "/v1/generative_fill", body, auth)
    results.append(ok(st == 200 and r["credits"] == 1 and r["image"] == p, "tạo ảnh (mock) trừ 1 credit"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "quality": "high"}, auth)
    results.append(ok(st == 403 and r.get("code") == "pro_required" and r["credits"] == 1, "gói Free + chất lượng cao -> 403 pro_required, không trừ"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "prompt": ""}, auth)
    results.append(ok(st == 400, "thiếu prompt -> 400"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "image": base64.b64encode(b"khong-phai-png").decode()}, auth)
    results.append(ok(st == 400, "ảnh không phải PNG -> 400"))

    st, r = call(base, "POST", "/v1/admin/grant", {"device_id": "device-12345678", "credits": 5}, {"X-Admin-Key": "sai"})
    results.append(ok(st == 403, "grant sai khóa quản trị -> 403"))
    st, r = call(base, "POST", "/v1/admin/grant", {"device_id": "device-12345678", "credits": 5, "reason": "test"}, {"X-Admin-Key": "adm"})
    results.append(ok(st == 200 and r["credits"] == 6, "grant +5 -> 6"))

    cfg.upstream = "fail"
    st, r = call(base, "POST", "/v1/generative_fill", body, auth)
    results.append(ok(st == 502 and r["credits"] == 6, "nhà cung cấp lỗi -> 502 và HOÀN credits (vẫn 6)"))
    cfg.upstream = "mock"

    st, r = call(base, "GET", "/v1/routing?tier=low&app=1.0", headers=auth)
    results.append(ok(st == 200 and r["tasks"]["generative_fill"]["providers"][0]["kind"] == "proxy_cloud" and "low" in r["perf"],
                      "routing trả cấu hình + perf theo hạng"))
    # --- upstream kiểu OpenAI /v1/images/edits (tự host FLUX.2 klein / sd.cpp ...) bằng máy chủ giả ---
    import http.server
    seen = {}

    class Fake(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n)
            seen["ctype"] = self.headers.get("Content-Type", "")
            seen["raw"] = raw
            out = json.dumps({"data": [{"b64_json": p}]}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)

    fake = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Fake)
    threading.Thread(target=fake.serve_forever, daemon=True).start()
    cfg.upstream = "openai_edits"
    cfg.edits_url = "http://127.0.0.1:%d/v1/images/edits" % fake.server_address[1]
    cfg.edits_model = "flux2-klein"
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "mask_alpha": p, "prompt": "add a red hat"}, auth)
    raw = seen.get("raw", b"")
    results.append(ok(st == 200 and r["image"] == p, "upstream openai_edits trả ảnh"))
    results.append(ok(seen.get("ctype", "").startswith("multipart/form-data; boundary=") and b'name="prompt"' in raw and b"add a red hat" in raw
                      and b'name="image[]"' in raw and b'name="mask"' in raw and b'name="model"' in raw,
                      "multipart có prompt + image[] + mask + model"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "mask_alpha": "####"}, auth)
    results.append(ok(st == 400, "mask_alpha không phải PNG -> 400"))
    cfg.edits_url = ""
    st, r = call(base, "POST", "/v1/generative_fill", body, auth)
    results.append(ok(st == 502, "thiếu EDITS_URL -> 502 và hoàn credits"))
    fake.shutdown()
    cfg.upstream = "mock"

    # --- thanh toán Google Play: đổi giao dịch thành credits ---
    st0, cur = call(base, "GET", "/v1/credits", headers=auth)
    before = cur["credits"]
    cfg.billing_mode = "off"
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-1"}, auth)
    results.append(ok(st == 503, "billing tắt -> 503"))
    cfg.billing_mode = "mock"
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-1"})
    results.append(ok(st == 401, "đổi credits không đăng nhập -> 401"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-1"}, auth)
    results.append(ok(st == 200 and r["granted"] == 20 and r["credits"] == before + 20, "giao dịch hợp lệ +20 credits"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-1"}, auth)
    results.append(ok(st == 409 and call(base, "GET", "/v1/credits", headers=auth)[1]["credits"] == before + 20, "đổi lại cùng token -> 409, KHÔNG cộng thêm"))
    st, r_b = call(base, "POST", "/v1/register", {"device_id": "device-87654321"})
    auth_b = {"Authorization": "Bearer " + r_b["token"]}
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "ok-1"}, auth_b)
    results.append(ok(st == 409, "tài khoản khác dùng lại token đã đổi -> 409"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "khong-co", "purchase_token": "ok-2"}, auth)
    results.append(ok(st == 400, "sản phẩm lạ -> 400"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "pending-1"}, auth)
    results.append(ok(st == 409, "giao dịch chờ thanh toán -> 409, chưa cộng"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "gia-mao"}, auth)
    results.append(ok(st == 400, "giao dịch không tồn tại -> 400"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_100", "purchase_token": "ok-3"}, auth)
    results.append(ok(st == 200 and r["granted"] == 110, "gói 100 tặng 110 credits"))

    # --- chế độ play: gọi đúng URL + Bearer, đối chiếu tài khoản, ánh xạ lỗi (thay http_json bằng bản giả) ---
    cfg.billing_mode = "play"
    cfg.play_package = "com.aiphoto.studio"
    server._PLAY_TOKEN.update({"tok": "tok-giả", "exp": 9e12})
    calls = []
    me = "device-12345678"

    def fake_http(url, method="GET", headers=None, data=None, timeout=15):
        calls.append((url, headers))
        if url.endswith("/tokens/p-ok"):
            return 200, {"purchaseState": 0, "orderId": "GPA.1", "obfuscatedExternalAccountId": server.account_hash(me)}
        if url.endswith("/tokens/p-other"):
            return 200, {"purchaseState": 0, "orderId": "GPA.2", "obfuscatedExternalAccountId": "tai-khoan-khac"}
        if url.endswith("/tokens/p-cancel"):
            return 200, {"purchaseState": 1}
        if url.endswith("/tokens/p-404"):
            return 404, {}
        return 500, {}

    real_http = server.http_json
    server.http_json = fake_http
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "p-ok"}, auth)
    results.append(ok(st == 200 and calls and calls[0][0] == "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/com.aiphoto.studio/purchases/products/credits_20/tokens/p-ok"
                      and calls[0][1]["Authorization"] == "Bearer tok-giả", "play: gọi đúng URL purchases.products.get + Bearer"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "p-other"}, auth)
    results.append(ok(st == 403, "play: giao dịch của tài khoản khác -> 403"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "p-cancel"}, auth)
    results.append(ok(st == 400, "play: giao dịch đã hủy -> 400"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "p-404"}, auth)
    results.append(ok(st == 400, "play: Google trả 404 -> 400"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "credits_20", "purchase_token": "p-loi"}, auth)
    results.append(ok(st == 502, "play: Google trả 500 -> 502"))
    server.http_json = real_http
    cfg.billing_mode = "off"

    # --- ký JWT RS256 bằng openssl: chữ ký phải kiểm chứng được bằng khóa công khai ---
    import shutil, subprocess
    if shutil.which("openssl"):
        d = tempfile.mkdtemp()
        subprocess.run(["openssl", "genrsa", "-out", d + "/k.pem", "2048"], check=True, capture_output=True)
        subprocess.run(["openssl", "rsa", "-in", d + "/k.pem", "-pubout", "-out", d + "/p.pem"], check=True, capture_output=True)
        pem = open(d + "/k.pem").read()
        jwt = server.build_service_account_jwt({"client_email": "sa@x.iam", "private_key": pem}, now=1_700_000_000)
        h, c, sig = jwt.split(".")
        pad = lambda x: x + "=" * (-len(x) % 4)
        claims = json.loads(base64.urlsafe_b64decode(pad(c)))
        open(d + "/sig.bin", "wb").write(base64.urlsafe_b64decode(pad(sig)))
        v = subprocess.run(["openssl", "dgst", "-sha256", "-verify", d + "/p.pem", "-signature", d + "/sig.bin"],
                           input=(h + "." + c).encode(), capture_output=True)
        results.append(ok(v.returncode == 0 and b"Verified OK" in v.stdout, "JWT RS256 ký bằng openssl kiểm chứng được bằng khóa công khai"))
        results.append(ok(claims["iss"] == "sa@x.iam" and claims["scope"] == server.PLAY_SCOPE and claims["exp"] - claims["iat"] == 3600
                          and claims["aud"] == "https://oauth2.googleapis.com/token", "JWT claims đúng (iss, scope androidpublisher, aud, hạn 1 giờ)"))


    # ---- Gói Free / Pro, Agent AI nhìn ảnh, định tuyến theo gói (R10)
    cfg.billing_mode = "mock"
    st, r = call(base, "POST", "/v1/register", {"device_id": "device-pro-0001"})
    pro_auth = {"Authorization": "Bearer " + r["token"]}
    st, r = call(base, "POST", "/v1/register", {"device_id": "device-free-0002"})
    free_auth = {"Authorization": "Bearer " + r["token"]}
    st, acc = call(base, "GET", "/v1/account", headers=free_auth)
    results.append(ok(st == 200 and acc["plan"] == "free" and acc["limits"]["watermark"] and not acc["limits"]["high_quality"], "tài khoản mới: gói Free, có watermark, không chất lượng cao"))
    results.append(ok(call(base, "GET", "/v1/account")[0] == 401, "/v1/account không token -> 401"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "pro_30d", "purchase_token": "ok-pro-1"}, pro_auth)
    results.append(ok(st == 200 and r["plan"] == "pro" and r["granted"] == 50 and r["credits"] == 52, "mua pro_30d: lên Pro + tặng 50 credits"))
    until1 = r["plan_until"]
    results.append(ok(abs(until1 - (time.time() + 30 * 86400)) < 120, "hạn Pro = bây giờ + 30 ngày"))
    st, acc = call(base, "GET", "/v1/account", headers=pro_auth)
    results.append(ok(acc["plan"] == "pro" and not acc["limits"]["watermark"] and acc["limits"]["high_quality"], "gói Pro: không watermark, được chất lượng cao"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "pro_30d", "purchase_token": "ok-pro-1"}, pro_auth)
    st, acc = call(base, "GET", "/v1/account", headers=pro_auth)
    results.append(ok(acc["plan_until"] == until1 and acc["credits"] == 52, "đổi lại cùng giao dịch: không gia hạn / không cộng thêm"))
    st, r = call(base, "POST", "/v1/billing/redeem", {"product_id": "pro_30d", "purchase_token": "ok-pro-2"}, pro_auth)
    results.append(ok(st == 200 and abs(r["plan_until"] - (until1 + 30 * 86400)) < 5, "mua thêm 30 ngày: cộng dồn vào hạn hiện tại"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "quality": "high"}, pro_auth)
    results.append(ok(st == 200 and r["credits"] == 102 - 2, "Pro dùng chất lượng cao, trừ 2 credits"))
    before = call(base, "GET", "/v1/credits", headers=pro_auth)[1]["credits"]
    st, r = call(base, "GET", "/v1/routing?tier=mid", headers=pro_auth)
    results.append(ok(st == 200 and r["server_hint"]["plan"] == "pro" and "hair_segment" in r["tasks"], "định tuyến báo plan=pro và có tác vụ hair_segment"))
    results.append(ok("person_detect" in r["tasks"], "định tuyến có tác vụ person_detect (R21: phát hiện người cho \"xóa người lạ\")"))
    results.append(ok(r.get("version", 0) >= 7, "định tuyến mặc định version >= 7 (R30 thêm depth_estimate, R30f đổi sang cạnh thích nghi; app chỉ thay cấu hình đã lưu khi version nhỏ hơn)"))
    dep = r["tasks"].get("depth_estimate", {}).get("providers", [])
    results.append(ok(len(dep) == 1 and dep[0]["kind"] == "depth_onnx" and dep[0]["needs"] == ["file:depth.onnx"] and dep[0]["params"] == {"edge": "518", "budget_ms": "3000"} and "minRamMb" not in dep[0],
                      "định tuyến có tác vụ depth_estimate (R30f: MỘT nhà cung cấp, edge = trần 518 và budget_ms = 3000 là ngân sách thời gian; KHÔNG còn ngưỡng RAM — cạnh thật do app học từ thời gian chạy)"))
    st, r = call(base, "GET", "/v1/routing?tier=mid", headers=free_auth)
    results.append(ok(r["server_hint"]["plan"] == "free", "định tuyến báo plan=free cho tài khoản Free"))

    ep = {"image": p, "prompt": "nhuộm tóc nâu, sáng hơn"}
    results.append(ok(call(base, "POST", "/v1/edit_plan", ep)[0] == 401, "edit_plan không token -> 401"))
    st, r = call(base, "POST", "/v1/edit_plan", ep, free_auth)
    ops = r.get("plan", {}).get("ops", [])
    results.append(ok(st == 200 and r["credits"] == 1 and any(o["op"] == "colorize" and o["arg"] == "#6B4423" and o["scope"] == "hair" for o in ops),
                      "edit_plan (mock): trả kế hoạch đã lọc, màu viết hoa, trừ 1 credit (Free)"))
    st, r = call(base, "POST", "/v1/edit_plan", ep, pro_auth)
    results.append(ok(st == 200 and r["credits"] == before, "edit_plan: gói Pro không tốn credits"))
    results.append(ok(call(base, "POST", "/v1/edit_plan", {**ep, "image": base64.b64encode(b"khong-phai-anh").decode()}, free_auth)[0] == 400, "edit_plan ảnh không hợp lệ -> 400"))
    results.append(ok(call(base, "POST", "/v1/edit_plan", {**ep, "prompt": "  "}, free_auth)[0] == 400, "edit_plan thiếu prompt -> 400"))
    cfg.upstream = "fail"
    st, r = call(base, "POST", "/v1/edit_plan", ep, free_auth)
    results.append(ok(st == 502 and r["credits"] == 1, "edit_plan lỗi nhà cung cấp -> 502 và hoàn credit"))
    cfg.upstream = "mock"
    st, r = call(base, "POST", "/v1/edit_plan", ep, free_auth)
    results.append(ok(st == 200 and r["credits"] == 0, "edit_plan dùng credit cuối -> còn 0"))
    st, r = call(base, "POST", "/v1/edit_plan", ep, free_auth)
    results.append(ok(st == 402 and r["credits"] == 0, "edit_plan khi hết credits -> 402"))

    # lọc kế hoạch do mô hình trả về
    sp = server.sanitize_plan('xin chào {"ops":[{"op":"brightness","value":5},{"op":"hack","value":1},{"op":"colorize","value":0.5},'
                              '{"op":"colorize","value":0.5,"arg":"#abcdef","scope":"hair"},{"op":"vignette","value":0.4,"scope":"moon"},'
                              '{"op":"saturation","value":"x"},{"op":"matte","value":-3}]} hết')
    got = [(o["op"], o["value"]) for o in sp["ops"]]
    results.append(ok(got == [("brightness", 1.0), ("colorize", 0.5), ("matte", 0.0)], "sanitize_plan: kẹp giá trị, bỏ phép lạ / thiếu màu / vùng lạ / giá trị rác"))
    try:
        server.sanitize_plan("không phải json"); bad = False
    except ValueError:
        bad = True
    results.append(ok(bad, "sanitize_plan: văn bản không có JSON -> lỗi"))
    many = '{"ops":[' + ",".join('{"op":"contrast","value":0.1}' for _ in range(40)) + ']}'
    results.append(ok(len(server.sanitize_plan(many)["ops"]) == server.PLAN_MAX_OPS, "sanitize_plan: tối đa %d phép" % server.PLAN_MAX_OPS))
    # R11: phép chuyên nghiệp mới + thay bầu trời
    sp = server.sanitize_plan('{"ops":[{"op":"highlights","value":-3},{"op":"vibrance","value":0.4},{"op":"tint","value":-0.2},'
                              '{"op":"dehaze","value":9},{"op":"texture","value":-0.5}]}')
    got = [(o["op"], o["value"]) for o in sp["ops"]]
    results.append(ok(got == [("highlights", -1.0), ("vibrance", 0.4), ("tint", -0.2), ("dehaze", 1.0), ("texture", -0.5)],
                      "sanitize_plan: highlights/vibrance/tint/dehaze/texture được giữ và kẹp -1..1"))
    sp = server.sanitize_plan('{"ops":[{"op":"sky_replace","value":1,"arg":"Sunset"},{"op":"sky_replace","value":0.5,"arg":"lava"},'
                              '{"op":"sky_replace","value":2}]}')
    results.append(ok([(o["op"], o["value"], o["arg"]) for o in sp["ops"]] ==
                      [("sky_replace", 1.0, "sunset"), ("sky_replace", 0.5, "blue"), ("sky_replace", 1.0, "blue")],
                      "sanitize_plan: sky_replace chỉ nhận trời mẫu hợp lệ, còn lại về 'blue', value kẹp 0..1"))
    results.append(ok("sky_replace" in server.PLAN_INSTRUCTION and "highlights" in server.PLAN_INSTRUCTION,
                      "PLAN_INSTRUCTION nhắc tới phép mới cho Agent"))
    sp = server.sanitize_plan('{"ops":[{"op":"hair_volume","value":0.6,"scope":"hair"},{"op":"hair_volume","value":7},{"op":"hair_volume","value":0},'
                              '{"op":"hair_volume","value":"x"},{"op":"hair_volume","value":0.5,"scope":"moon"}]}')
    got = [(o["op"], o["value"], o.get("scope")) for o in sp["ops"]]
    # giống mọi phép khác: kẹp 0..1, GIỮ giá trị 0 (app tự loại < 0,01 ở sanitized()), bỏ cả phép nếu giá trị rác hoặc vùng lạ
    results.append(ok(got == [("hair_volume", 0.6, "hair"), ("hair_volume", 1.0, None), ("hair_volume", 0.0, None)],
                      "sanitize_plan: hair_volume được giữ (kẹp 0..1; bỏ phép có giá trị rác hoặc vùng lạ)"))
    results.append(ok("hair_volume" in server.PLAN_INSTRUCTION and "fuller" in server.PLAN_INSTRUCTION,
                      "PLAN_INSTRUCTION nhắc Agent về hair_volume (tóc phồng/dày)"))
    sp = server.sanitize_plan('{"ops":[{"op":"outpaint","value":5,"arg":"l=0.3,r=0.3"},{"op":"outpaint","arg":"ratio=1.78,a=R"},{"op":"outpaint","arg":"rác"},'
                              '{"op":"outpaint","arg":"ratio=99"},{"op":"outpaint","arg":"l=9,t=-3"},{"op":"outpaint"}]}')
    got = [(o["op"], o["value"], o.get("arg")) for o in sp["ops"]]
    results.append(ok(got == [("outpaint", 1.0, "l=0.300,r=0.300,t=0.000,b=0.000"), ("outpaint", 1.0, "ratio=1.7800,a=r"),
                              ("outpaint", 1.0, "l=1.000,r=0.000,t=0.000,b=0.000")],
                      "sanitize_plan: outpaint chuẩn hóa arg (kẹp 0..1, ratio 0.2..5, neo l/r/t/b/c); bỏ arg rác/thiếu"))
    results.append(ok("outpaint" in server.PLAN_INSTRUCTION and "ratio=1.78" in server.PLAN_INSTRUCTION,
                      "PLAN_INSTRUCTION nhắc Agent về outpaint (mở rộng ảnh)"))
    sp = server.sanitize_plan('{"ops":[{"op":"split_tone","arg":"185,0.5,28,0.5"},{"op":"split_tone","arg":"-30,9,400,0.2,3"},{"op":"split_tone","arg":"10,0,20,0"},'
                              '{"op":"split_tone","arg":"abc"},{"op":"split_tone","arg":"1,2,3"},{"op":"split_tone"}]}')
    got = [(o["op"], o.get("arg")) for o in sp["ops"]]
    results.append(ok(got == [("split_tone", "185.0,0.500,28.0,0.500,0.000"), ("split_tone", "330.0,1.000,40.0,0.200,1.000")],
                      "sanitize_plan: split_tone chuẩn hóa (hue mod 360, sat/balance kẹp); bỏ arg rác / sat=0 / thiếu số"))
    results.append(ok("split_tone" in server.PLAN_INSTRUCTION and "teal shadows" in server.PLAN_INSTRUCTION,
                      "PLAN_INSTRUCTION nhắc Agent về split_tone (chia tông sáng/tối)"))


    # ======================================================================= R14: ĐĂNG KÝ ĐỊNH KỲ (subscriptionsv2 + RTDN)
    import datetime as _dt
    import hashlib as _hl
    cfg.billing_mode = "mock"
    cfg.play_package = "com.aiphoto.studio"
    cfg.rtdn_secret = "rt-secret"
    cfg.sub_ack = "server"
    server.MOCK_SUBS.clear(); server.MOCK_ACKS.clear(); server.MOCK_ACK_FAIL["on"] = False
    store = srv.store
    sha = lambda t: _hl.sha256(t.encode()).hexdigest()
    rfc = lambda ts: _dt.datetime.fromtimestamp(ts, _dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    def gsub(state="ACTIVE", days=30, order="GPA.1", product="pro_monthly", dev=None, ack=True, linked=None, items=None):
        info = {"kind": "androidpublisher#subscriptionPurchaseV2", "subscriptionState": "SUBSCRIPTION_STATE_" + state, "latestOrderId": order,
                "acknowledgementState": "ACKNOWLEDGEMENT_STATE_PENDING" if ack else "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED",
                "lineItems": items if items is not None else [{"productId": product, "expiryTime": rfc(time.time() + days * 86400)}]}
        if dev:
            info["externalAccountIdentifiers"] = {"obfuscatedExternalAccountId": server.account_hash(dev)}
        if linked:
            info["linkedPurchaseToken"] = linked
        return info

    def push(token, key="rt-secret", ntype=2, pkg="com.aiphoto.studio", note=None, data=None):
        n = note if note is not None else {"version": "1.0", "packageName": pkg, "eventTimeMillis": "1",
                                          "subscriptionNotification": {"version": "1.0", "notificationType": ntype, "purchaseToken": token}}
        env = {"message": {"data": data if data is not None else base64.b64encode(json.dumps(n).encode()).decode(), "messageId": "1"},
               "subscription": "projects/x/subscriptions/y"}
        return call(base, "POST", "/v1/billing/rtdn?key=" + key, env)

    DA, DB, DC = "device-sub-0001", "device-sub-0002", "device-sub-0003"
    auths = {}
    for d in (DA, DB, DC):
        auths[d] = {"Authorization": "Bearer " + call(base, "POST", "/v1/register", {"device_id": d})[1]["token"]}
    A, B, C = auths[DA], auths[DB], auths[DC]
    cr = lambda a: call(base, "GET", "/v1/credits", headers=a)[1]["credits"]
    acct = lambda a: call(base, "GET", "/v1/account", headers=a)[1]
    sub = lambda a, tok, prod="pro_monthly": call(base, "POST", "/v1/billing/subscribe", {"product_id": prod, "purchase_token": tok}, a)

    # --- 1. mua mới ---
    tA = "tok-A-1"
    server.MOCK_SUBS[tA] = gsub("ACTIVE", 30, "GPA.1.0", dev=DA)
    c0 = cr(A)
    st, r = sub(A, tA)
    results.append(ok(st == 200 and r["plan"] == "pro" and r["granted"] == 50 and r["credits"] == c0 + 50, "sub: mua mới -> Pro + tặng 50 credits của kỳ đầu"))
    results.append(ok(abs(r["plan_until"] - (time.time() + 30 * 86400)) < 120, "sub: hạn Pro = ngày hết hạn của Google"))
    results.append(ok(r["ack"] == "ok" and server.MOCK_ACKS == [tA], "sub: máy chủ tự acknowledge (Google hoàn tiền sau 3 ngày nếu không)"))
    results.append(ok(r["subscription"]["product_id"] == "pro_monthly" and r["subscription"]["state"] == "active", "sub: trả thông tin đăng ký"))
    a = acct(A)
    results.append(ok(a["plan"] == "pro" and a["subscription"]["product_id"] == "pro_monthly" and not a["limits"]["watermark"] and a["limits"]["high_quality"],
                      "sub: /v1/account báo Pro, kèm đăng ký, không watermark, được chất lượng cao"))
    st, rt = call(base, "GET", "/v1/routing?tier=mid", headers=A)
    results.append(ok(rt["server_hint"]["plan"] == "pro", "sub: định tuyến báo plan=pro nhờ đăng ký"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "quality": "high"}, A)
    results.append(ok(st == 200, "sub: Pro nhờ đăng ký dùng được chất lượng cao"))
    # --- 2. idempotent ---
    server.MOCK_SUBS[tA]["acknowledgementState"] = "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED"      # Google đã ghi nhận
    c1 = cr(A)
    st, r = sub(A, tA)
    results.append(ok(st == 200 and r["granted"] == 0 and cr(A) == c1 and len(server.MOCK_ACKS) == 1, "sub: báo lại cùng giao dịch (khôi phục) -> không cộng thêm, không acknowledge lại"))
    # --- 3. gia hạn qua RTDN: kỳ mới = mã đơn mới -> cộng đúng MỘT lần ---
    server.MOCK_SUBS[tA] = gsub("ACTIVE", 60, "GPA.1.1", dev=DA, ack=False)
    st, r = push(tA)
    results.append(ok(st == 200 and r.get("ok") and cr(A) == c1 + 50, "rtdn: gia hạn (đơn mới) -> +50 credits"))
    results.append(ok(abs(acct(A)["plan_until"] - (time.time() + 60 * 86400)) < 120, "rtdn: hạn Pro được gia hạn theo Google"))
    push(tA); push(tA)
    results.append(ok(cr(A) == c1 + 50, "rtdn: thông báo trùng lặp không cộng credits lần nữa"))
    # --- 4. hủy gia hạn nhưng còn hạn / ân hạn: vẫn Pro; không cộng thêm ---
    server.MOCK_SUBS[tA] = gsub("CANCELED", 20, "GPA.1.1", dev=DA, ack=False)
    push(tA, ntype=3)
    a = acct(A)
    results.append(ok(a["plan"] == "pro" and cr(A) == c1 + 50 and a["subscription"]["state"] == "canceled", "rtdn: CANCELED còn hạn -> vẫn Pro tới ngày hết hạn, không cộng thêm"))
    server.MOCK_SUBS[tA] = gsub("IN_GRACE_PERIOD", 3, "GPA.1.1", dev=DA, ack=False)
    push(tA, ntype=6)
    results.append(ok(acct(A)["plan"] == "pro", "rtdn: IN_GRACE_PERIOD -> vẫn Pro"))
    # --- 5. mất quyền lợi ---
    server.MOCK_SUBS[tA] = gsub("ON_HOLD", 3, "GPA.1.1", dev=DA, ack=False)
    push(tA, ntype=5)
    a = acct(A)
    results.append(ok(a["plan"] == "free" and a["subscription"] is None and a["limits"]["watermark"], "rtdn: ON_HOLD -> về Free ngay, có watermark"))
    st, r = call(base, "POST", "/v1/generative_fill", {**body, "quality": "high"}, A)
    results.append(ok(st == 403 and r.get("code") == "pro_required", "rtdn: mất Pro -> chất lượng cao bị chặn lại"))
    # --- 6. phục hồi: kỳ mới -> cộng 1 lần ---
    server.MOCK_SUBS[tA] = gsub("ACTIVE", 30, "GPA.1.2", dev=DA, ack=False)
    cb = cr(A)
    push(tA, ntype=1)
    results.append(ok(acct(A)["plan"] == "pro" and cr(A) == cb + 50, "rtdn: RECOVERED (đơn mới) -> Pro lại + 50 credits"))
    # --- 7. hết hạn / trạng thái lạ / hạn đã qua: ĐÓNG ---
    server.MOCK_SUBS[tA] = gsub("EXPIRED", -3, "GPA.1.2", dev=DA, ack=False)
    push(tA, ntype=13)
    results.append(ok(acct(A)["plan"] == "free", "rtdn: EXPIRED -> Free"))
    server.MOCK_SUBS[tA] = gsub("NEW_STATE_FROM_GOOGLE", 30, "GPA.1.3", dev=DA, ack=False)
    cb = cr(A)
    push(tA)
    results.append(ok(acct(A)["plan"] == "free" and cr(A) == cb, "tên trạng thái LẠ -> không cấp Pro, không cộng credits (đóng khi không chắc)"))
    server.MOCK_SUBS[tA] = gsub("ACTIVE", -1, "GPA.1.3", dev=DA, ack=False)
    push(tA)
    results.append(ok(acct(A)["plan"] == "free", "state ACTIVE nhưng expiryTime đã qua -> không cấp Pro"))
    results.append(ok(call(base, "POST", "/v1/billing/subscribe", {"product_id": "pro_monthly", "purchase_token": tA}, A)[0] == 400, "báo mua một đăng ký đã hết hiệu lực -> 400"))

    # --- 8. xác minh đầu vào + chủ sở hữu ---
    results.append(ok(call(base, "POST", "/v1/billing/subscribe", {"product_id": "pro_monthly", "purchase_token": "x"})[0] == 401, "subscribe không token -> 401"))
    results.append(ok(sub(B, "khong-co-trong-mock")[0] == 400, "sub: token Google không biết -> 400"))
    results.append(ok(sub(B, "tok", "khong-co")[0] == 400 and call(base, "POST", "/v1/billing/subscribe", {"product_id": "pro_monthly"}, B)[0] == 400,
                      "sub: gói không bán / thiếu token -> 400"))
    server.MOCK_SUBS["tok-pend"] = gsub("PENDING", 30, "GPA.2.0", dev=DB)
    results.append(ok(sub(B, "tok-pend")[0] == 409, "sub: đang chờ thanh toán -> 409"))
    server.MOCK_SUBS["tok-own"] = gsub("ACTIVE", 30, "GPA.2.1", dev=DA)
    results.append(ok(sub(B, "tok-own")[0] == 403 and acct(B)["plan"] == "free", "sub: giao dịch của tài khoản khác -> 403, không cấp"))
    server.MOCK_SUBS["tok-yr"] = gsub("ACTIVE", 365, "GPA.2.2", product="pro_yearly", dev=DB)
    results.append(ok(sub(B, "tok-yr", "pro_monthly")[0] == 400, "sub: đăng ký là gói khác với gói app khai báo -> 400"))
    server.MOCK_SUBS["tok-other"] = gsub("ACTIVE", 30, "GPA.2.3", dev=DB, items=[{"productId": "san-pham-la", "expiryTime": rfc(time.time() + 86400)}])
    results.append(ok(sub(B, "tok-other")[0] == 400, "sub: line item không thuộc gói nào app bán -> 400"))
    server.MOCK_SUBS["tok-dead"] = gsub("EXPIRED", -10, "GPA.2.4", dev=DB)
    results.append(ok(sub(B, "tok-dead")[0] == 400 and store.subscription_by_hash(sha("tok-dead")) is None, "sub: token mới đã hết hạn -> 400 và KHÔNG ghi gì vào CSDL"))
    # token chỉ thuộc người đầu tiên đăng ký (khi Google không có mã tài khoản ẩn danh)
    server.MOCK_SUBS["tok-shared"] = gsub("ACTIVE", 30, "GPA.2.5")
    results.append(ok(sub(A, "tok-shared")[0] == 200, "sub: token không có mã tài khoản -> người đầu tiên đăng ký được nhận"))
    cbb = cr(B)
    st, r = sub(B, "tok-shared")
    results.append(ok(st == 409 and cr(B) == cbb and acct(B)["plan"] == "free", "sub: người thứ hai dùng lại token -> 409, không cấp"))
    # --- 9. đổi gói (linkedPurchaseToken) ---
    server.MOCK_SUBS["tok-old"] = gsub("ACTIVE", 30, "GPA.3.0", dev=DB, ack=False)
    server.MOCK_SUBS["tok-new"] = gsub("ACTIVE", 365, "GPA.3.1", product="pro_yearly", dev=DB, ack=False, linked="tok-old")
    st, r = sub(B, "tok-old")
    results.append(ok(st == 200 and r["granted"] == 50, "sub: gói tháng -> +50 credits"))
    st, r = sub(B, "tok-new", "pro_yearly")
    old = store.subscription_by_hash(sha("tok-old"))
    results.append(ok(st == 200 and r["granted"] == 600 and old and not old["entitled"] and old["state"] == "SUPERSEDED", "sub: nâng lên gói năm -> +600 credits, đăng ký cũ bị thay thế"))
    results.append(ok(abs(acct(B)["plan_until"] - (time.time() + 365 * 86400)) < 120, "sub: hạn Pro theo gói năm"))
    # --- 10. acknowledge lỗi rồi thử lại ---
    server.MOCK_ACK_FAIL["on"] = True
    server.MOCK_SUBS["tok-ack"] = gsub("ACTIVE", 30, "GPA.4.0", dev=DC, ack=True)
    st, r = sub(C, "tok-ack")
    row = store.subscription_by_hash(sha("tok-ack"))
    results.append(ok(st == 200 and r["ack"] == "pending" and row["ack_pending"] and acct(C)["plan"] == "pro", "ack lỗi: vẫn cấp Pro nhưng đánh dấu ack_pending"))
    server.MOCK_ACK_FAIL["on"] = False
    push("tok-ack")
    row = store.subscription_by_hash(sha("tok-ack"))
    results.append(ok(not row["ack_pending"] and "tok-ack" in server.MOCK_ACKS, "ack: lần đồng bộ sau (RTDN) tự thử lại và thành công"))
    cfg.sub_ack = "client"
    server.MOCK_SUBS["tok-cl"] = gsub("ACTIVE", 30, "GPA.4.1", dev=DC, ack=True)
    st, r = sub(C, "tok-cl")
    results.append(ok(r["ack"] == "client" and "tok-cl" not in server.MOCK_ACKS, "SUBSCRIPTION_ACK=client: máy chủ không acknowledge, báo để app làm"))
    cfg.sub_ack = "server"
    # --- 11. nhiều nguồn Pro: lấy hạn MUỘN NHẤT (gói mua một lần vs đăng ký) ---
    server.MOCK_SUBS["tok-short"] = gsub("ACTIVE", 10, "GPA.5.0", dev=DC, ack=False)
    sub(C, "tok-short")
    call(base, "POST", "/v1/billing/redeem", {"product_id": "pro_30d", "purchase_token": "ok-c-pack"}, C)
    results.append(ok(abs(acct(C)["plan_until"] - (time.time() + 30 * 86400)) < 300, "gộp: có đăng ký 10 ngày + gói 30 ngày + đăng ký 30 ngày -> hạn muộn nhất"))
    server.MOCK_SUBS["tok-long"] = gsub("ACTIVE", 90, "GPA.5.1", dev=DC, ack=False)
    sub(C, "tok-long")
    results.append(ok(abs(acct(C)["plan_until"] - (time.time() + 90 * 86400)) < 300, "gộp: đăng ký 90 ngày vượt gói 30 ngày -> hạn 90 ngày"))

    # --- 12. RTDN: xác thực và độ bền ---
    results.append(ok(push(tA, key="sai")[0] == 403, "rtdn: sai khóa -> 403"))
    cfg.rtdn_secret = ""
    results.append(ok(push(tA, key="")[0] == 503, "rtdn: chưa đặt RTDN_SECRET -> 503 (tắt)"))
    cfg.rtdn_secret = "rt-secret"
    st, r = push(tA, data="@@không-phải-base64@@")
    results.append(ok(st == 200 and "ignored" in r, "rtdn: dữ liệu không phải base64 -> 200 bỏ qua (không bắt Pub/Sub gửi lại vô hạn)"))
    st, r = push(tA, data=base64.b64encode(b"khong phai json").decode())
    results.append(ok(st == 200 and "ignored" in r, "rtdn: base64 nhưng không phải JSON -> 200 bỏ qua"))
    st, r = push(tA, note={"version": "1.0", "packageName": "com.aiphoto.studio", "testNotification": {"version": "1.0"}})
    results.append(ok(st == 200 and "ignored" in r, "rtdn: testNotification -> 200 bỏ qua"))
    st, r = push(tA, pkg="com.ung.dung.khac")
    results.append(ok(st == 200 and "ignored" in r, "rtdn: thông báo của ứng dụng khác -> bỏ qua"))
    before_rows = store.subscription_by_hash(sha("tok-gia-mao"))
    server.MOCK_SUBS["tok-gia-mao"] = gsub("ACTIVE", 999, "GPA.6.0", dev=DA)
    st, r = push("tok-gia-mao")
    results.append(ok(before_rows is None and st == 200 and "ignored" in r and store.subscription_by_hash(sha("tok-gia-mao")) is None,
                      "rtdn: token chưa đăng ký qua app -> bỏ qua, KHÔNG tự tạo/cấp gì (giả mạo vô hại)"))
    st, r = push("x", note={"packageName": "com.aiphoto.studio", "subscriptionNotification": {"notificationType": 2}})
    results.append(ok(st == 200 and "ignored" in r, "rtdn: thiếu purchaseToken -> bỏ qua"))

    # --- 13. chế độ play: đúng URL, Bearer, acknowledge, lỗi Google -> 502 để Pub/Sub gửi lại ---
    cfg.billing_mode = "play"
    server._PLAY_TOKEN.update({"tok": "tok-giả", "exp": 9e12})
    gcalls = []
    BASE = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/com.aiphoto.studio/purchases/"

    def fake_http2(url, method="GET", headers=None, data=None, timeout=15):
        gcalls.append((url, method, headers, data))
        if url == BASE + "subscriptionsv2/tokens/p-sub":
            return 200, {"kind": "androidpublisher#subscriptionPurchaseV2", "subscriptionState": "SUBSCRIPTION_STATE_ACTIVE",
                         "latestOrderId": "GPA.7.0", "acknowledgementState": "ACKNOWLEDGEMENT_STATE_PENDING",
                         "lineItems": [{"productId": "pro_monthly", "expiryTime": rfc(time.time() + 30 * 86400).replace("Z", ".123456Z")}],
                         "externalAccountIdentifiers": {"obfuscatedExternalAccountId": server.account_hash(DA)}}
        if url == BASE + "subscriptions/pro_monthly/tokens/p-sub:acknowledge":
            return 200, {}
        if "tokens/p-404" in url:
            return 404, {}
        return 500, {}

    real_http2 = server.http_json
    server.http_json = fake_http2
    cA = cr(A)
    st, r = sub(A, "p-sub")
    results.append(ok(st == 200 and gcalls[0][0] == BASE + "subscriptionsv2/tokens/p-sub" and gcalls[0][1] == "GET"
                      and gcalls[0][2]["Authorization"] == "Bearer tok-giả", "play: gọi đúng URL purchases.subscriptionsv2.get + Bearer"))
    results.append(ok(r["granted"] == 50 and cr(A) == cA + 50 and abs(r["plan_until"] - (time.time() + 30 * 86400)) < 120,
                      "play: đọc được expiryTime có phần thập phân giây + hậu tố Z"))
    ack_calls = [c for c in gcalls if c[0].endswith(":acknowledge")]
    results.append(ok(len(ack_calls) == 1 and ack_calls[0][0] == BASE + "subscriptions/pro_monthly/tokens/p-sub:acknowledge" and ack_calls[0][1] == "POST"
                      and ack_calls[0][2]["Content-Type"] == "application/json" and ack_calls[0][3] == b"{}", "play: acknowledge gọi đúng URL ':acknowledge' bằng POST"))
    results.append(ok(sub(A, "p-404")[0] == 400, "play: Google trả 404 -> 400"))
    results.append(ok(sub(A, "p-loi")[0] == 502, "play: Google trả 500 -> 502"))
    st, r = push("p-sub")
    results.append(ok(st == 200 and r.get("ok"), "play: RTDN cho token đã biết -> đồng bộ lại qua Google"))
    server.http_json = lambda *a, **k: (500, {})
    st, r = push("p-sub")
    results.append(ok(st == 502, "play: Google lỗi 500 lúc RTDN -> trả 502 để Pub/Sub gửi lại sau"))
    server.http_json = real_http2
    cfg.billing_mode = "mock"

    # --- 14. hàm thuần ---
    pr = server.parse_rfc3339
    results.append(ok(pr("1970-01-02T00:00:00Z") == 86400.0 and pr("1970-01-02T00:00:00.999Z") == 86400.0, "parse_rfc3339: Z và phần thập phân giây"))
    results.append(ok(pr("1970-01-02T07:00:00+07:00") == 86400.0 and pr("1970-01-01T20:00:00-04:00") == 86400.0 and pr("1970-01-01T20:00:00-04:00") == pr("1970-01-02T00:00:00Z"),
                      "parse_rfc3339: +07:00 và -04:00 quy đổi đúng"))
    results.append(ok(all(pr(x) is None for x in ("", "khong", None, 5, "2026-13-45T00:00:00Z", "2026-10-17 09:00:00Z")), "parse_rfc3339: đầu vào xấu -> None"))
    now = 1_000_000.0
    two = {"subscriptionState": "SUBSCRIPTION_STATE_ACTIVE", "latestOrderId": "GPA.X",
           "lineItems": [{"productId": "pro_monthly", "expiryTime": rfc(now + 100)}, {"productId": "pro_yearly", "expiryTime": rfc(now + 9000)},
                         {"productId": "la", "expiryTime": rfc(now + 99999)}, "rác", {"expiryTime": rfc(now + 5)}]}
    ps = server.parse_subscription(cfg, two, now=now)
    results.append(ok(ps["product_id"] == "pro_yearly" and abs(ps["expiry"] - (now + 9000)) < 1 and ps["entitled"] and ps["owner"] is None and not ps["ack_pending"],
                      "parse_subscription: nhiều line item -> chọn gói app bán có hạn muộn nhất, bỏ qua mục lạ/rác"))
    ps = server.parse_subscription(cfg, {**two, "subscriptionState": "SUBSCRIPTION_STATE_PAUSED"}, now=now)
    results.append(ok(not ps["entitled"], "parse_subscription: PAUSED không được hưởng"))
    ps = server.parse_subscription(cfg, {**two, "lineItems": [{"productId": "pro_monthly", "expiryTime": "hỏng"}]}, now=now)
    results.append(ok(not ps["entitled"] and ps["expiry"] == 0.0, "parse_subscription: expiryTime hỏng -> không được hưởng"))
    ps = server.parse_subscription(cfg, {}, now=now)
    results.append(ok(not ps["entitled"] and ps["product_id"] is None, "parse_subscription: JSON rỗng -> không được hưởng, không ném lỗi"))
    results.append(ok(server.SUB_ENTITLED_STATES == {"SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_CANCELED", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"},
                      "chỉ ACTIVE / CANCELED / IN_GRACE_PERIOD được hưởng quyền lợi"))
    # --- 15. CSDL cũ nâng cấp được; cấu hình mặc định ---
    import sqlite3
    old_path = os.path.join(tempfile.mkdtemp(), "old.db")
    odb = sqlite3.connect(old_path)
    odb.execute("CREATE TABLE accounts(device_id TEXT PRIMARY KEY, credits INTEGER NOT NULL, created REAL)")
    odb.execute("INSERT INTO accounts VALUES('device-old-0001', 7, 0)")
    odb.commit(); odb.close()
    st2 = server.Store(old_path)
    st2.db.execute("SELECT 1 FROM subscriptions LIMIT 1"); st2.db.execute("SELECT 1 FROM sub_orders LIMIT 1")
    res, why = st2.apply_subscription("device-old-0001", "h1", "t1", "pro_monthly", "SUBSCRIPTION_STATE_ACTIVE", True, time.time() + 1000, "GPA.O", False, 50)
    results.append(ok(res and res["credits"] == 57 and st2.is_pro("device-old-0001"), "CSDL cũ (chưa có bảng đăng ký) tự nâng cấp và dùng được"))
    results.append(ok(st2.apply_subscription("không-có", "h2", "t2", "pro_monthly", "S", True, 1.0, "o", False, 5)[1] == "không có tài khoản", "đăng ký cho tài khoản không tồn tại -> bị từ chối"))
    dc = server.Config()
    results.append(ok(set(dc.subscription_products) == {"pro_monthly", "pro_yearly"} and dc.sub_ack == "server", "cấu hình mặc định: pro_monthly/pro_yearly, acknowledge ở máy chủ"))
    cfg.rtdn_secret = ""

    import test_rate
    test_rate.run(cfg, srv, base, results, ok, call, png)    # R30: giới hạn tần suất + ảnh mẫu phong cách cho Agent AI
    import test_team
    test_team.run(cfg, srv, base, results, ok, call, png)    # R22: gói Team/Enterprise
    import test_beta
    test_beta.run(cfg, srv, base, results, ok, call, png)    # R23: chế độ dùng thử miễn phí
    import test_integrity
    test_integrity.run(cfg, srv, base, results, ok, call, png)    # R32: Play Integrity phía máy chủ (verdict, thử thách, ép buộc)

    cfg.billing_mode = "off"
    srv.shutdown()
    print("\nTỔNG: %d/%d đạt" % (sum(results), len(results)))
    raise SystemExit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
