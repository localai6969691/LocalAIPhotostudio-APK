"""Kiểm thử R30: giới hạn tần suất (cửa sổ trượt) và ảnh MẪU phong cách cho Agent AI (/v1/edit_plan). Được test_server.py gọi.
Mỗi phép thử giới hạn dựng một máy chủ RIÊNG với đồng hồ giả (không ngủ thật) nên chạy tức thì."""
import base64
import json
import os
import tempfile
import threading
import urllib.error
import urllib.request

import server


def run(cfg, srv, base, results, ok, call, png):
    def start(**over):
        c = server.Config()
        c.db_path = os.path.join(tempfile.mkdtemp(), "rl.db")
        c.rate_register_ip_hour = 0
        c.rate_device_minute = 0
        for k, v in over.items():
            setattr(c, k, v)
        t = [1000.0]
        c.clock = lambda: t[0]
        s = server.serve(c)
        threading.Thread(target=s.serve_forever, daemon=True).start()
        return c, s, "http://127.0.0.1:%d" % s.server_address[1], t

    def raw(b, method, path, body=None, headers=None):
        """Như call() nhưng trả thêm tiêu đề phản hồi."""
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(b + path, data=data, method=method, headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read()), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read()), dict(e.headers)

    def reg(b, n, headers=None):
        return raw(b, "POST", "/v1/register", {"device_id": "rate-device-%08d" % n}, headers)

    # ---------------------------------------------------------------- RateLimiter (đơn vị)
    t = [0.0]
    rl = server.RateLimiter(lambda: t[0])
    seq = []
    for now in (0.0, 1.0, 2.0):
        t[0] = now
        seq.append(rl.hit("k", 3, 10))
    t[0] = 3.0
    blocked = rl.hit("k", 3, 10)
    results.append(ok(all(a for a, _ in seq) and blocked[0] is False and 1 <= blocked[1] <= 10,
                      "RateLimiter: 3 lượt đầu qua, lượt thứ 4 bị chặn kèm số giây chờ hợp lý (1..10)"))
    t[0] = 10.5
    after_expiry = rl.hit("k", 3, 10)          # lượt t=0 đã hết hạn
    t[0] = 10.6
    still_full = rl.hit("k", 3, 10)             # còn t=1, t=2, t=10.5 -> đầy; lượt bị chặn lúc t=3 KHÔNG được tính
    results.append(ok(after_expiry[0] is True and still_full[0] is False and still_full[1] == 1,
                      "RateLimiter: hết hạn thì được đi tiếp; lượt bị chặn không kéo dài cửa sổ; chờ tối thiểu 1 giây"))
    results.append(ok(rl.hit("khác", 3, 10)[0] is True and all(rl.hit("tắt", 0, 10)[0] for _ in range(50)) and all(rl.hit("âm", -5, 10)[0] for _ in range(50)),
                      "RateLimiter: khóa độc lập; limit 0 hoặc âm = tắt (không bao giờ chặn)"))
    old_max = server.RateLimiter.MAX_KEYS
    server.RateLimiter.MAX_KEYS = 10
    try:
        t2 = [5000.0]
        small = server.RateLimiter(lambda: t2[0])
        for i in range(40):
            t2[0] += 0.001
            small.hit("ip-%d" % i, 5, 3600)
        bounded = len(small._hits) <= 20
        t2[0] += 0.001
        still_works = small.hit("ip-sau-cung", 5, 3600)[0]
    finally:
        server.RateLimiter.MAX_KEYS = old_max
    results.append(ok(bounded and still_works, "RateLimiter: số khóa bị chặn trên (chống phình bộ nhớ khi bị tấn công bằng nhiều IP), vẫn hoạt động sau khi dọn"))
    t3 = [0.0]
    gc_rl = server.RateLimiter(lambda: t3[0])
    for i in range(30):
        gc_rl.hit("cũ-%d" % i, 2, 60)
    t3[0] = 1000.0
    gc_rl.hit("mới", 2, 60)
    results.append(ok(set(gc_rl._hits) == {"mới"}, "RateLimiter: khóa hết hạn được dọn định kỳ"))

    # ---------------------------------------------------------------- /v1/register theo IP
    c1, s1, b1, t1 = start(rate_register_ip_hour=3)
    st = [reg(b1, i)[0] for i in range(3)]
    s4, r4, h4 = reg(b1, 3)
    results.append(ok(st == [200, 200, 200] and s4 == 429 and r4["code"] == "rate_limited" and isinstance(r4["retry_after"], int) and r4["retry_after"] >= 1
                      and h4.get("Retry-After") == str(r4["retry_after"]),
                      "register: 3 lần/giờ/IP qua, lần 4 -> 429 code rate_limited + retry_after + tiêu đề Retry-After"))
    t1[0] += 3601
    results.append(ok(reg(b1, 4)[0] == 200, "register: sau một giờ lại đăng ký được"))
    results.append(ok(call(b1, "GET", "/healthz")[0] == 200, "healthz không bị giới hạn"))

    # X-Forwarded-For mặc định KHÔNG được tin (khách tự khai được)
    c2, s2, b2, t_ = start(rate_register_ip_hour=2)
    sp = [reg(b2, 10 + i, {"X-Forwarded-For": "10.0.0.%d" % i})[0] for i in range(3)]
    results.append(ok(sp == [200, 200, 429], "register: mặc định (TRUST_PROXY_HOPS=0) bỏ qua X-Forwarded-For nên không lách được bằng tiêu đề giả"))
    # Có 1 reverse proxy tin cậy: lấy mục cuối (do proxy thêm), phần bên trái do khách khai bị bỏ qua
    c3, s3, b3, t_ = start(rate_register_ip_hour=2, trust_proxy_hops=1)
    p = [reg(b3, 20, {"X-Forwarded-For": "1.1.1.1, 9.9.9.9"})[0], reg(b3, 21, {"X-Forwarded-For": "2.2.2.2, 9.9.9.9"})[0],
         reg(b3, 22, {"X-Forwarded-For": "3.3.3.3, 9.9.9.9"})[0], reg(b3, 23, {"X-Forwarded-For": "4.4.4.4, 8.8.8.8"})[0]]
    results.append(ok(p == [200, 200, 429, 200], "register: TRUST_PROXY_HOPS=1 tính theo mục phải nhất; giả mục trái không lách được, IP khác vẫn đi qua"))
    results.append(ok(reg(b3, 24)[0] in (200, 429), "register: thiếu X-Forwarded-For khi có proxy tin cậy -> rơi về địa chỉ kết nối, không lỗi"))

    # ---------------------------------------------------------------- lệnh POST theo thiết bị
    c4, s4_, b4, t4 = start(rate_device_minute=4)
    tokA = call(b4, "POST", "/v1/register", {"device_id": "rate-device-AAAAAAAA"})[1]["token"]
    tokB = call(b4, "POST", "/v1/register", {"device_id": "rate-device-BBBBBBBB"})[1]["token"]
    hA, hB = {"Authorization": "Bearer " + tokA}, {"Authorization": "Bearer " + tokB}
    credits_before = call(b4, "GET", "/v1/credits", None, hA)[1]["credits"]
    codes = [call(b4, "POST", "/v1/generative_fill", {}, hA)[0] for _ in range(4)]
    s5, r5, h5 = raw(b4, "POST", "/v1/generative_fill", {}, hA)
    results.append(ok(all(c != 429 for c in codes) and s5 == 429 and r5["code"] == "rate_limited" and "Retry-After" in h5,
                      "thiết bị: 4 lệnh POST/phút qua (bị 400 vì thân rỗng, không phải 429), lệnh thứ 5 -> 429"))
    results.append(ok(call(b4, "POST", "/v1/generative_fill", {}, hB)[0] != 429, "thiết bị: giới hạn theo từng thiết bị, thiết bị khác không bị vạ lây"))
    results.append(ok(call(b4, "GET", "/v1/credits", None, hA)[1]["credits"] == credits_before, "thiết bị: lệnh bị chặn không trừ credits; GET (rẻ) không bị giới hạn"))
    anon = [call(b4, "POST", "/v1/generative_fill", {})[0] for _ in range(10)]
    results.append(ok(all(c == 401 for c in anon), "thiết bị: yêu cầu không đăng nhập vẫn 401 (không bị tính vào hạn mức của ai)"))
    rtdn = [call(b4, "POST", "/v1/billing/rtdn?secret=sai", {})[0] for _ in range(10)]
    results.append(ok(all(c != 429 for c in rtdn), "RTDN (Google Pub/Sub gọi) không bị giới hạn theo thiết bị"))
    t4[0] += 61
    results.append(ok(call(b4, "POST", "/v1/generative_fill", {}, hA)[0] != 429, "thiết bị: sau một phút dùng tiếp được"))
    c5, s5_, b5, t5 = start(rate_device_minute=0)
    tok0 = call(b5, "POST", "/v1/register", {"device_id": "rate-device-CCCCCCCC"})[1]["token"]
    free = [call(b5, "POST", "/v1/generative_fill", {}, {"Authorization": "Bearer " + tok0})[0] for _ in range(40)]
    results.append(ok(all(c != 429 for c in free), "thiết bị: RATE_PER_DEVICE_MINUTE=0 tắt giới hạn"))
    saved = {k: os.environ.pop(k) for k in ("RATE_REGISTER_PER_IP_HOUR", "RATE_PER_DEVICE_MINUTE", "TRUST_PROXY_HOPS") if k in os.environ}
    try:
        dc = server.Config()
    finally:
        os.environ.update(saved)
    results.append(ok(dc.rate_register_ip_hour == 60 and dc.rate_device_minute == 60 and dc.trust_proxy_hops == 0,
                      "cấu hình mặc định: 60 lần đăng ký/IP/giờ, 60 lệnh/thiết bị/phút, không tin X-Forwarded-For"))

    # ---------------------------------------------------------------- Agent AI + ảnh mẫu phong cách
    def new_dev(n):
        return {"Authorization": "Bearer " + call(base, "POST", "/v1/register", {"device_id": "ref-device-%08d" % n})[1]["token"]}

    img = base64.b64encode(png(8, 8)).decode()
    ref = base64.b64encode(png(6, 6)).decode()
    d1 = new_dev(1)
    s_a, r_a = call(base, "POST", "/v1/edit_plan", {"image": img, "prompt": "làm ấm", "reference": ref}, d1)
    had_ref = cfg.last_plan_had_reference
    d2 = new_dev(2)
    s_b, r_b = call(base, "POST", "/v1/edit_plan", {"image": img, "prompt": "làm ấm"}, d2)
    results.append(ok(s_a == 200 and had_ref is True and r_a["plan"]["ops"] and s_b == 200 and cfg.last_plan_had_reference is False,
                      "edit_plan: có reference -> chuyển tới nhà cung cấp; không có -> như cũ (không đổi hành vi)"))
    d3 = new_dev(3)
    cr0 = call(base, "GET", "/v1/credits", None, d3)[1]["credits"]
    bad_cases = {
        "không phải base64": "!!!không-phải-base64!!!",
        "không phải ảnh": base64.b64encode(b"day khong phai anh").decode(),
        "quá lớn": base64.b64encode(b"\xff\xd8\xff" + b"0" * 1_600_000).decode(),
    }
    outs = {k: call(base, "POST", "/v1/edit_plan", {"image": img, "prompt": "x", "reference": v}, d3) for k, v in bad_cases.items()}
    results.append(ok(all(o[0] == 400 for o in outs.values()) and call(base, "GET", "/v1/credits", None, d3)[1]["credits"] == cr0,
                      "edit_plan: ảnh mẫu sai (không base64 / không phải ảnh / > 1.5 MB) -> 400 và KHÔNG trừ credits"))
    results.append(ok("ảnh mẫu" in outs["không phải ảnh"][1]["error"] and "ảnh mẫu" in outs["quá lớn"][1]["error"],
                      "edit_plan: thông báo lỗi nói rõ là ảnh MẪU"))

    # nội dung gửi cho Gemini: ảnh chính trước, rồi ghi chú + ảnh mẫu
    captured = []

    class FakeResp:
        def __init__(self, payload): self._p = payload
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def read(self): return self._p

    def fake_urlopen(req, timeout=60):
        captured.append(json.loads(req.data))
        return FakeResp(json.dumps({"candidates": [{"content": {"parts": [{"text": "{\"ops\":[]}"}]}}]}).encode())

    real = server.urllib.request.urlopen
    server.urllib.request.urlopen = fake_urlopen
    try:
        gc = server.Config()
        gc.gemini_key = "k"
        server.call_gemini_plan(gc, "MAIN64", "warm", "image/jpeg", ("REF64", "image/png"))
        server.call_gemini_plan(gc, "MAIN64", "warm", "image/jpeg")
    finally:
        server.urllib.request.urlopen = real
    with_ref, without_ref = captured[0]["contents"][0]["parts"], captured[1]["contents"][0]["parts"]
    results.append(ok(len(with_ref) == 4 and with_ref[1]["inlineData"]["data"] == "MAIN64" and "STYLE REFERENCE" in with_ref[2]["text"]
                      and with_ref[3]["inlineData"] == {"mimeType": "image/png", "data": "REF64"},
                      "Gemini: [lệnh, ảnh chính, ghi chú 'ảnh mẫu phong cách', ảnh mẫu] đúng thứ tự và mime"))
    results.append(ok(len(without_ref) == 2 and "inlineData" in without_ref[1], "Gemini: không có ảnh mẫu thì yêu cầu giữ nguyên như trước (2 phần)"))
    txt = with_ref[0]["text"]
    results.append(ok(txt.endswith("User request: warm") and "{request}" not in txt and "20% on a side" in txt,
                      "Gemini: câu lệnh gửi đi có yêu cầu người dùng ở cuối, KHÔNG còn chỗ trống, dấu % thật được giữ (trước R30 mọi lần gọi Gemini thật đều TypeError)"))
    server.urllib.request.urlopen = fake_urlopen
    try:
        server.call_gemini_plan(gc, "MAIN64", "tăng 20% độ sáng %s %d {request}", "image/jpeg")
    finally:
        server.urllib.request.urlopen = real
    tricky_txt = captured[-1]["contents"][0]["parts"][0]["text"]
    results.append(ok(tricky_txt.endswith("User request: tăng 20% độ sáng %s %d {request}"), "Gemini: yêu cầu chứa %, %s, %d, {request} không làm vỡ câu lệnh"))
    # các đường gọi nhà cung cấp THẬT khác cũng dựng được yêu cầu (test cũ chỉ chạy upstream giả nên chưa từng chạy các đoạn này)
    one_px = base64.b64encode(b"\x89PNG\r\n\x1a\n").decode()

    def fake_provider(req, timeout=60):
        if "generateContent" in req.full_url:
            return FakeResp(json.dumps({"candidates": [{"content": {"parts": [{"inlineData": {"mimeType": "image/png", "data": one_px}}]}}]}).encode())
        return FakeResp(json.dumps({"data": [{"b64_json": one_px}]}).encode())

    server.urllib.request.urlopen = fake_provider
    try:
        pc = server.Config()
        pc.gemini_key, pc.edits_url, pc.edits_key = "k", "http://example.invalid/edits", "k"
        img4 = base64.b64encode(png()).decode()
        got = [server.call_gemini(pc, img4, img4, "mèo 20% %s %d {x}"), server.call_openai_edits(pc, img4, img4, "mèo 20% %s %d {x}")]
        good = all(isinstance(g, str) and g for g in got)
    except Exception as e:  # noqa: BLE001
        good = False
        print("   lỗi:", type(e).__name__, e)
    finally:
        server.urllib.request.urlopen = real
    results.append(ok(good, "call_gemini / call_openai_edits dựng yêu cầu được với prompt chứa %, %s, %d, {x} (không TypeError / KeyError)"))
    for s_ in (s1, s2, s3, s4_, s5_):
        s_.shutdown()
