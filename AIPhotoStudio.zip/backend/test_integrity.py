"""Kiểm thử R32: Play Integrity phía máy chủ (đánh giá verdict theo định dạng chính thức, thử thách dùng một lần, chống phát lại, hết hạn, ép buộc).
Được test_server.py gọi. Dựng máy chủ RIÊNG ở chế độ `mock` (token = JSON verdict) với đồng hồ giả; chế độ `play` kiểm bằng http_json giả."""
import base64
import json
import os
import tempfile
import threading

import integrity
import server

PKG = "com.aiphoto.studio"
CERT_B64 = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip("=")   # dấu vân tay chứng chỉ mẫu (sha256 = 32 byte, base64url không đệm)


def verdict(dev, challenge, now_s, **over):
    """Verdict đạt đầy đủ theo định dạng chính thức; `over` ghi đè từng khối để dựng ca lỗi."""
    v = {
        "requestDetails": {"requestPackageName": PKG, "requestHash": integrity.expected_request_hash(dev, challenge), "timestampMillis": str(int(now_s * 1000))},
        "appIntegrity": {"appRecognitionVerdict": "PLAY_RECOGNIZED", "packageName": PKG, "certificateSha256Digest": [CERT_B64], "versionCode": "42"},
        "deviceIntegrity": {"deviceRecognitionVerdict": ["MEETS_DEVICE_INTEGRITY"]},
        "accountDetails": {"appLicensingVerdict": "LICENSED"},
    }
    v.update(over)
    return v


def run(cfg, srv, base, results, ok, call, png):
    # ------------------------------------------------------------------ A. hàm thuần evaluate_verdict
    now = 1_000_000.0
    h = integrity.expected_request_hash("dev-1", "abc")
    ev = lambda p, **kw: integrity.evaluate_verdict(p, PKG, h, int(now * 1000), **kw)
    good = verdict("dev-1", "abc", now)
    results.append(ok(ev(good)[0], "integrity: verdict đạt đầy đủ → ok"))
    results.append(ok(integrity.expected_request_hash("dev-1", "abc") != integrity.expected_request_hash("dev-2", "abc")
                      and integrity.expected_request_hash("dev-1", "abc") != integrity.expected_request_hash("dev-1", "abd"),
                      "integrity: requestHash phụ thuộc cả thiết bị lẫn thử thách"))
    bad_cases = [
        ("sai package", verdict("dev-1", "abc", now, requestDetails={**good["requestDetails"], "requestPackageName": "evil.app"})),
        ("sai requestHash", verdict("dev-1", "OTHER", now)),
        ("thiếu requestHash", verdict("dev-1", "abc", now, requestDetails={"requestPackageName": PKG, "timestampMillis": str(int(now * 1000))})),
        ("token quá cũ (11 phút)", verdict("dev-1", "abc", now - 660)),
        ("dấu thời gian ở tương lai", verdict("dev-1", "abc", now + 120)),
        ("thiếu timestamp", verdict("dev-1", "abc", now, requestDetails={"requestPackageName": PKG, "requestHash": h})),
        ("UNRECOGNIZED_VERSION", verdict("dev-1", "abc", now, appIntegrity={"appRecognitionVerdict": "UNRECOGNIZED_VERSION"})),
        ("UNEVALUATED", verdict("dev-1", "abc", now, appIntegrity={"appRecognitionVerdict": "UNEVALUATED"})),
        ("packageName trong appIntegrity lệch", verdict("dev-1", "abc", now, appIntegrity={"appRecognitionVerdict": "PLAY_RECOGNIZED", "packageName": "evil.app"})),
        ("thiết bị rỗng (không nhãn nào)", verdict("dev-1", "abc", now, deviceIntegrity={})),
        ("thiết bị chỉ có nhãn khác", verdict("dev-1", "abc", now, deviceIntegrity={"deviceRecognitionVerdict": ["MEETS_BASIC_INTEGRITY"]})),
        ("thiếu khối deviceIntegrity", {k: v for k, v in good.items() if k != "deviceIntegrity"}),
        ("thiếu khối appIntegrity", {k: v for k, v in good.items() if k != "appIntegrity"}),
        ("không phải đối tượng", ["x"]),
    ]
    for name, payload in bad_cases:
        results.append(ok(not ev(payload)[0], "integrity: từ chối — " + name))
    results.append(ok(ev(verdict("dev-1", "abc", now, accountDetails={"appLicensingVerdict": "UNLICENSED"}))[0], "integrity: UNLICENSED vẫn ok khi không bắt buộc LICENSED (tester cài APK tay)"))
    results.append(ok(not ev(verdict("dev-1", "abc", now, accountDetails={"appLicensingVerdict": "UNLICENSED"}), require_licensed=True)[0], "integrity: UNLICENSED bị từ chối khi bắt buộc LICENSED"))
    results.append(ok(ev(good, cert_allowlist=(CERT_B64,))[0] and not ev(good, cert_allowlist=(bytes(32).hex(),))[0], "integrity: danh sách chứng chỉ cho phép được áp dụng"))
    results.append(ok(ev(verdict("dev-1", "abc", now - 590))[0], "integrity: token cũ 590 giây vẫn nằm trong cửa sổ 600 giây"))
    # dấu vân tay chứng chỉ: base64url (tài liệu hiện hành) và hex (bản mô tả API cũ / keytool) phải so khớp nhau
    raw = bytes(range(32))
    b64 = base64.urlsafe_b64encode(raw).decode().rstrip("=")
    hexs = raw.hex().upper()
    colon = ":".join(hexs[i:i + 2] for i in range(0, 64, 2))
    vcert = verdict("dev-1", "abc", now, appIntegrity={"appRecognitionVerdict": "PLAY_RECOGNIZED", "packageName": PKG, "certificateSha256Digest": [b64]})
    for form, lst in (("base64url", b64), ("hex", hexs), ("hex có dấu hai chấm", colon)):
        results.append(ok(ev(vcert, cert_allowlist=(lst,))[0], "integrity: danh sách chứng chỉ khai bằng %s khớp verdict base64url" % form))
    vhex = verdict("dev-1", "abc", now, appIntegrity={"appRecognitionVerdict": "PLAY_RECOGNIZED", "packageName": PKG, "certificateSha256Digest": [hexs]})
    results.append(ok(ev(vhex, cert_allowlist=(b64,))[0], "integrity: verdict dạng hex khớp danh sách base64url"))
    results.append(ok(not ev(vcert, cert_allowlist=(bytes(32).hex(),))[0], "integrity: chứng chỉ khác bị từ chối"))
    results.append(ok(not ev(vcert, cert_allowlist=("rac-khong-giai-duoc",))[0], "integrity: danh sách chứng chỉ rác ⇒ từ chối (không âm thầm bỏ kiểm)"))
    vtest = verdict("dev-1", "abc", now, testingDetails={"isTestingResponse": True})
    results.append(ok(not ev(vtest)[0], "integrity: phản hồi kiểm thử của Play Console bị từ chối mặc định"))
    results.append(ok(ev(vtest, allow_testing=True)[0], "integrity: phản hồi kiểm thử được chấp nhận khi người vận hành cho phép (QA)"))
    results.append(ok(ev(verdict("dev-1", "abc", now, testingDetails={"isTestingResponse": False}))[0], "integrity: testingDetails=false vẫn ok"))

    # ------------------------------------------------------------------ B. sổ thử thách / thiết bị
    t = [5000.0]
    att = integrity.Attestations(lambda: t[0])
    c1 = att.new_challenge("d")
    results.append(ok(att.take_challenge("d", c1), "integrity: thử thách đúng được chấp nhận"))
    results.append(ok(not att.take_challenge("d", c1), "integrity: thử thách chỉ dùng MỘT lần"))
    c2 = att.new_challenge("d")
    results.append(ok(not att.take_challenge("d", "sai") and not att.take_challenge("d", c2), "integrity: đoán sai thử thách làm thử thách bị hủy (không dò được nhiều lần)"))
    c3 = att.new_challenge("d")
    t[0] += integrity.CHALLENGE_TTL + 1
    results.append(ok(not att.take_challenge("d", c3), "integrity: thử thách hết hạn sau 5 phút"))
    att.mark("d", 100)
    results.append(ok(att.is_attested("d") and not att.is_attested("khac"), "integrity: chỉ thiết bị đã chứng thực mới được tin"))
    t[0] += 101
    results.append(ok(not att.is_attested("d"), "integrity: chứng thực hết hạn theo ttl"))

    # ------------------------------------------------------------------ C. đầu-cuối ở chế độ mock + ép buộc
    def start(**over):
        c = server.Config()
        c.db_path = os.path.join(tempfile.mkdtemp(), "ig.db")
        c.rate_register_ip_hour = 0
        c.rate_device_minute = 0
        c.play_package = PKG
        for k, v in over.items():
            setattr(c, k, v)
        tt = [1_000_000.0]
        c.clock = lambda: tt[0]
        s = server.serve(c)
        threading.Thread(target=s.serve_forever, daemon=True).start()
        return c, s, "http://127.0.0.1:%d" % s.server_address[1], tt

    c, s, b, tt = start(integrity_mode="mock", integrity_enforce=True, integrity_ttl=3600)
    try:
        st, r = call(b, "POST", "/v1/register", {"device_id": "integrity-dev-0001"})
        dev = "integrity-dev-0001"
        auth = {"Authorization": "Bearer " + r["token"]}
        p = base64.b64encode(png()).decode()
        fill = {"image": p, "mask": p, "prompt": "a red cat", "quality": "fast"}
        results.append(ok(call(b, "GET", "/v1/credits", headers=auth)[0] == 200, "integrity: /v1/credits KHÔNG bị ép buộc (chỉ các đường tốn tiền)"))
        st, r = call(b, "POST", "/v1/generative_fill", fill, auth)
        results.append(ok(st == 403 and r.get("code") == "integrity_required", "integrity: chưa chứng thực → generative_fill bị 403 integrity_required"))
        for path in ("/v1/edit_plan", "/v1/billing/redeem", "/v1/billing/subscribe"):
            st, r = call(b, "POST", path, {"image": p, "prompt": "x", "product_id": "credits_20", "purchase_token": "ok-1"}, auth)
            results.append(ok(st == 403 and r.get("code") == "integrity_required", "integrity: chưa chứng thực → %s bị 403" % path))
        st, r = call(b, "GET", "/v1/integrity/challenge")
        results.append(ok(st == 401, "integrity: xin thử thách cần đăng nhập"))
        st, r = call(b, "GET", "/v1/integrity/challenge", headers=auth)
        results.append(ok(st == 200 and len(r["challenge"]) == 48, "integrity: xin thử thách → 200"))
        ch = r["challenge"]
        # ca lỗi: token cho thử thách KHÁC (phát lại)
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": json.dumps(verdict(dev, "thu-thach-cu", tt[0])), "challenge": ch}, auth)
        results.append(ok(st == 403 and r.get("code") == "integrity_failed", "integrity: token gắn thử thách khác → 403 integrity_failed"))
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": json.dumps(verdict(dev, ch, tt[0])), "challenge": ch}, auth)
        results.append(ok(st == 400 and r.get("code") == "bad_challenge", "integrity: thử thách đã bị tiêu hao sau lần thất bại → 400 bad_challenge"))
        # ca lỗi: máy root
        ch = call(b, "GET", "/v1/integrity/challenge", headers=auth)[1]["challenge"]
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": json.dumps(verdict(dev, ch, tt[0], deviceIntegrity={})), "challenge": ch}, auth)
        results.append(ok(st == 403 and "MEETS_DEVICE_INTEGRITY" in r["error"], "integrity: thiết bị không đạt → 403 kèm lý do"))
        # ca lỗi: dữ liệu rác
        ch = call(b, "GET", "/v1/integrity/challenge", headers=auth)[1]["challenge"]
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": "khong-phai-json", "challenge": ch}, auth)
        results.append(ok(st == 400, "integrity: token rác → 400"))
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": "", "challenge": ch}, auth)
        results.append(ok(st == 400, "integrity: thiếu token → 400"))
        # ca đạt
        ch = call(b, "GET", "/v1/integrity/challenge", headers=auth)[1]["challenge"]
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": json.dumps(verdict(dev, ch, tt[0])), "challenge": ch}, auth)
        results.append(ok(st == 200 and r["ok"] is True and r["ttl"] == 3600, "integrity: verdict đạt → 200 ok"))
        st, r = call(b, "POST", "/v1/generative_fill", fill, auth)
        results.append(ok(st == 200, "integrity: đã chứng thực → generative_fill chạy bình thường (%s)" % st))
        # phát lại đúng token đó với thử thách mới
        ch2 = call(b, "GET", "/v1/integrity/challenge", headers=auth)[1]["challenge"]
        st, r = call(b, "POST", "/v1/integrity/verify", {"integrity_token": json.dumps(verdict(dev, ch, tt[0])), "challenge": ch2}, auth)
        results.append(ok(st == 403, "integrity: phát lại token cũ cho thử thách mới → 403"))
        # hết hạn
        tt[0] += 3601
        st, r = call(b, "POST", "/v1/generative_fill", fill, auth)
        results.append(ok(st == 403 and r.get("code") == "integrity_required", "integrity: hết hạn ttl → lại bị chặn"))
        # thiết bị khác không hưởng chứng thực của thiết bị này
        st, r2 = call(b, "POST", "/v1/register", {"device_id": "integrity-dev-0002"})
        st, r = call(b, "POST", "/v1/generative_fill", fill, {"Authorization": "Bearer " + r2["token"]})
        results.append(ok(st == 403, "integrity: chứng thực không lan sang thiết bị khác"))
    finally:
        s.shutdown()

    # ------------------------------------------------------------------ D. tắt / không ép buộc
    c, s, b, tt = start(integrity_mode="off", integrity_enforce=True)
    try:
        r = call(b, "POST", "/v1/register", {"device_id": "integrity-dev-0003"})[1]
        auth = {"Authorization": "Bearer " + r["token"]}
        results.append(ok(call(b, "GET", "/v1/integrity/challenge", headers=auth)[0] == 503, "integrity: mode=off → xin thử thách bị 503"))
        results.append(ok(call(b, "POST", "/v1/integrity/verify", {"integrity_token": "x", "challenge": "y"}, auth)[0] == 503, "integrity: mode=off → verify bị 503"))
        st, _ = call(b, "POST", "/v1/generative_fill", {"image": base64.b64encode(png()).decode(), "mask": base64.b64encode(png()).decode(), "prompt": "a", "quality": "fast"}, auth)
        results.append(ok(st == 200, "integrity: mode=off thì INTEGRITY_ENFORCE=1 cũng KHÔNG chặn (tránh khóa nhầm người dùng)"))
    finally:
        s.shutdown()
    c, s, b, tt = start(integrity_mode="mock", integrity_enforce=False)
    try:
        r = call(b, "POST", "/v1/register", {"device_id": "integrity-dev-0004"})[1]
        auth = {"Authorization": "Bearer " + r["token"]}
        st, _ = call(b, "POST", "/v1/generative_fill", {"image": base64.b64encode(png()).decode(), "mask": base64.b64encode(png()).decode(), "prompt": "a", "quality": "fast"}, auth)
        results.append(ok(st == 200, "integrity: bật mock nhưng không ép buộc → vẫn chạy (giai đoạn chạy thử / ghi nhận)"))
    finally:
        s.shutdown()

    # ------------------------------------------------------------------ E. chế độ play: gọi đúng URL / thân / Bearer, ánh xạ lỗi (http_json giả)
    pc = server.Config()
    pc.integrity_mode = "play"
    pc.play_package = PKG
    seen = {}
    real_http, real_tok = server.http_json, server.integrity_access_token
    server.integrity_access_token = lambda cfg_: "tok-integrity-giả"

    def fake(url, method="GET", headers=None, data=None, timeout=15):
        seen.update(url=url, method=method, headers=headers or {}, data=data)
        return seen.pop("reply", (200, {"tokenPayloadExternal": {"x": 1}}))

    server.http_json = fake
    try:
        payload = server.decode_integrity_token(pc, "TOKEN-123")
        results.append(ok(payload == {"x": 1} and seen["method"] == "POST"
                          and seen["url"] == "https://playintegrity.googleapis.com/v1/%s:decodeIntegrityToken" % PKG
                          and seen["headers"].get("Authorization") == "Bearer tok-integrity-giả"
                          and json.loads(seen["data"]) == {"integrityToken": "TOKEN-123"},
                          "integrity: chế độ play gọi đúng URL decodeIntegrityToken + Bearer + thân {integrityToken}"))
        for code, want in ((400, 400), (403, 502), (500, 502)):
            seen["reply"] = (code, {})
            try:
                server.decode_integrity_token(pc, "T")
                got = None
            except server.BillingError as e:
                got = e.status
            results.append(ok(got == want, "integrity: Google trả %d → máy chủ trả %s" % (code, want)))
        seen["reply"] = (200, {"thieu": 1})
        try:
            server.decode_integrity_token(pc, "T"); got = None
        except server.BillingError as e:
            got = e.status
        results.append(ok(got == 502, "integrity: 200 nhưng thiếu tokenPayloadExternal → 502"))
        pc.play_package = ""
        try:
            server.decode_integrity_token(pc, "T"); got = None
        except server.BillingError as e:
            got = e.status
        results.append(ok(got == 503, "integrity: thiếu PLAY_PACKAGE_NAME → 503"))
    finally:
        server.http_json, server.integrity_access_token = real_http, real_tok

    # JWT dùng đúng phạm vi playintegrity (không phải androidpublisher)
    real_sign = server.sign_rs256
    server.sign_rs256 = lambda pem, data: b"sig"
    try:
        def claims(scope=None):
            jwt = server.build_service_account_jwt({"client_email": "sa@x.iam", "private_key": "k"}, now=1_700_000_000, **({"scope": scope} if scope else {}))
            seg = jwt.split(".")[1]
            return json.loads(base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4)))
        results.append(ok(claims(integrity.INTEGRITY_SCOPE)["scope"] == "https://www.googleapis.com/auth/playintegrity", "integrity: JWT tài khoản dịch vụ mang phạm vi playintegrity"))
        results.append(ok(claims()["scope"] == server.PLAY_SCOPE, "integrity: JWT mặc định vẫn là androidpublisher (không phá thanh toán)"))
    finally:
        server.sign_rs256 = real_sign
