"""Play Integrity (R32) — phần MÁY CHỦ: đánh giá verdict và sổ thiết bị đã được chứng thực. Chỉ dùng thư viện chuẩn, không gọi mạng ở đây.

Định dạng verdict và cách kiểm đối chiếu trang chính thức "Integrity verdicts" của Google (developer.android.com/google/play/integrity/verdicts, tra cứu 03/11/2026):
  * requestDetails: requestPackageName và requestHash PHẢI khớp yêu cầu gốc; timestampMillis phải đủ mới (cửa sổ cho phép do người vận hành đặt);
  * appIntegrity.appRecognitionVerdict == "PLAY_RECOGNIZED" (app và chứng chỉ khớp bản phát hành trên Google Play);
  * deviceIntegrity.deviceRecognitionVerdict (mảng) phải chứa "MEETS_DEVICE_INTEGRITY";
  * accountDetails.appLicensingVerdict == "LICENSED" (tùy chọn: tester cài APK tay sẽ là UNLICENSED);
  * testingDetails.isTestingResponse (phản hồi do Play Console ghi đè cho tài khoản tester) bị từ chối trừ khi người vận hành cho phép.
Thứ tự trường trong JSON không được bảo đảm; trường có thể vắng ⇒ coi như không đạt.

Chống phát lại (replay): máy chủ phát một THỬ THÁCH ngẫu nhiên dùng một lần cho từng thiết bị; app băm "device_id|thử thách" làm requestHash khi xin token;
máy chủ tự tính lại đúng chuỗi đó rồi so với requestHash trong verdict — token lấy cho thử thách khác / thiết bị khác / lần khác đều bị từ chối.
"""
import base64
import binascii
import hashlib
import hmac
import os
import re
import threading

INTEGRITY_SCOPE = "https://www.googleapis.com/auth/playintegrity"
CHALLENGE_TTL = 300  # giây: app phải xin token và gửi lại trong 5 phút


def expected_request_hash(device_id, challenge):
    """requestHash mà app PHẢI dùng: SHA-256 (hex) của "device_id|thử thách". Máy chủ tự tính lại, không tin giá trị app gửi."""
    return hashlib.sha256(("%s|%s" % (device_id, challenge)).encode()).hexdigest()


def digest_bytes(s):
    """Chuẩn hóa dấu vân tay chứng chỉ về bytes. Tài liệu hiện hành ghi sha256 dạng base64 an toàn URL, bản mô tả API cũ ghi "hex fingerprint"
    (có thể có dấu hai chấm) — chấp nhận cả hai để cấu hình dán từ keytool (hex) hay từ Play Console (base64url) đều đúng. Không giải được ⇒ None."""
    if not isinstance(s, str) or not s:
        return None
    h = s.replace(":", "").strip()
    if re.fullmatch(r"[0-9A-Fa-f]{64}", h):
        return bytes.fromhex(h)
    try:
        b = base64.urlsafe_b64decode(h + "=" * (-len(h) % 4))
    except (binascii.Error, ValueError):
        return None
    return b if len(b) == 32 else None


def evaluate_verdict(payload, package, request_hash, now_ms, window_ms=600_000, require_licensed=False, cert_allowlist=(), allow_testing=False):
    """Trả (ok, lý_do). `payload` là tokenPayloadExternal Google trả về sau decodeIntegrityToken."""
    if not isinstance(payload, dict):
        return False, "verdict không phải JSON đối tượng"
    rd = payload.get("requestDetails")
    if not isinstance(rd, dict):
        return False, "thiếu requestDetails"
    if rd.get("requestPackageName") != package:
        return False, "requestPackageName không khớp ứng dụng này"
    got_hash = rd.get("requestHash")
    if not isinstance(got_hash, str) or not hmac.compare_digest(got_hash, request_hash):
        return False, "requestHash không khớp thử thách (token cho yêu cầu khác / bị phát lại)"
    try:
        ts = int(rd.get("timestampMillis"))
    except (TypeError, ValueError):
        return False, "thiếu / sai timestampMillis"
    if now_ms - ts > window_ms:
        return False, "token quá cũ"
    if ts - now_ms > 60_000:
        return False, "token có dấu thời gian ở tương lai"
    ai = payload.get("appIntegrity")
    if not isinstance(ai, dict) or ai.get("appRecognitionVerdict") != "PLAY_RECOGNIZED":
        return False, "ứng dụng không được Google Play nhận diện (PLAY_RECOGNIZED)"
    if ai.get("packageName") not in (None, package):
        return False, "appIntegrity.packageName không khớp"
    if cert_allowlist:
        allowed = {digest_bytes(a) for a in cert_allowlist} - {None}
        got = {digest_bytes(d) for d in (ai.get("certificateSha256Digest") or []) if isinstance(d, str)} - {None}
        if not allowed or not (allowed & got):
            return False, "chứng chỉ ký ứng dụng không nằm trong danh sách cho phép"
    td = payload.get("testingDetails")
    if isinstance(td, dict) and td.get("isTestingResponse") and not allow_testing:
        # Phản hồi KIỂM THỬ do Play Console ghi đè tĩnh cho tài khoản tester — không phải bằng chứng thật về thiết bị
        return False, "phản hồi kiểm thử (testingDetails.isTestingResponse) không được chấp nhận ở môi trường thật"
    di = payload.get("deviceIntegrity")
    verdicts = di.get("deviceRecognitionVerdict") if isinstance(di, dict) else None
    if not isinstance(verdicts, list) or "MEETS_DEVICE_INTEGRITY" not in verdicts:
        return False, "thiết bị không đạt MEETS_DEVICE_INTEGRITY"
    if require_licensed:
        ad = payload.get("accountDetails")
        if not isinstance(ad, dict) or ad.get("appLicensingVerdict") != "LICENSED":
            return False, "tài khoản chưa có giấy phép Play của ứng dụng (LICENSED)"
    return True, "ok"


class Attestations:
    """Sổ trong bộ nhớ: thử thách dùng một lần + thiết bị đã chứng thực (hết hạn sau ttl). Khởi động lại máy chủ ⇒ app tự chứng thực lại khi gặp 403 integrity_required."""

    MAX_ENTRIES = 50_000

    def __init__(self, clock):
        self.clock = clock
        self.lock = threading.Lock()
        self.challenges = {}   # device_id -> (challenge, hết hạn)
        self.attested = {}     # device_id -> hết hạn

    def _trim(self, d):
        if len(d) > self.MAX_ENTRIES:
            now = self.clock()
            for k in [k for k, v in d.items() if (v[1] if isinstance(v, tuple) else v) <= now]:
                d.pop(k, None)
            while len(d) > self.MAX_ENTRIES:   # vẫn đầy: bỏ bớt mục cũ nhất theo thứ tự chèn
                d.pop(next(iter(d)))

    def new_challenge(self, device_id):
        ch = os.urandom(24).hex()
        with self.lock:
            self.challenges[device_id] = (ch, self.clock() + CHALLENGE_TTL)
            self._trim(self.challenges)
        return ch

    def take_challenge(self, device_id, challenge):
        """Dùng MỘT LẦN: khớp và còn hạn ⇒ True và xóa ngay (kể cả khi sau đó verdict bị từ chối, để không thử dò nhiều lần trên một thử thách)."""
        with self.lock:
            cur = self.challenges.pop(device_id, None)
        if not cur or not isinstance(challenge, str):
            return False
        return hmac.compare_digest(cur[0], challenge) and cur[1] > self.clock()

    def mark(self, device_id, ttl):
        with self.lock:
            self.attested[device_id] = self.clock() + ttl
            self._trim(self.attested)

    def is_attested(self, device_id):
        with self.lock:
            exp = self.attested.get(device_id)
        return bool(exp and exp > self.clock())
