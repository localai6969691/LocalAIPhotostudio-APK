#!/usr/bin/env python3
"""
Máy chủ trung gian tham chiếu cho AI Photo Studio (chỉ dùng thư viện chuẩn Python 3.9+, không cần pip).

Vai trò (hướng thương mại):
  * Giữ KHÓA nhà cung cấp AI ở phía máy chủ - app không chứa khóa nào.
  * Tính CREDITS cho mỗi lần tạo ảnh (trừ trước, hoàn lại nếu nhà cung cấp lỗi).
  * Trả CẤU HÌNH ĐỊNH TUYẾN + hồ sơ hiệu năng theo hạng thiết bị -> đổi model/nhà cung cấp không cần phát hành lại app.

Endpoints:
  GET  /healthz
  POST /v1/register          {"device_id": "..."}                  -> {"token", "credits"}
  GET  /v1/credits           (Bearer)                              -> {"credits"}
  GET  /v1/routing?tier=&app= (Bearer)                             -> cấu hình định tuyến JSON
  POST /v1/generative_fill   (Bearer) {"image","mask","prompt","quality"}  (PNG base64) -> {"image","credits"}
  POST /v1/admin/grant       (X-Admin-Key) {"device_id","credits","reason"} -> {"credits"}
  POST /v1/billing/redeem    (Bearer) {"product_id","purchase_token"} -> {"credits","granted","plan","plan_until"}   <- đổi giao dịch Google Play thành credits / gói Pro
  GET  /v1/account           (Bearer)                              -> {"plan","plan_until","credits","limits":{"high_quality","watermark"},"subscription"}
  POST /v1/billing/subscribe (Bearer) {"product_id","purchase_token"} -> {"credits","granted","plan","plan_until","subscription","ack"}   <- ĐĂNG KÝ ĐỊNH KỲ (subscriptionsv2); cũng dùng để KHÔI PHỤC (idempotent)
  POST /v1/billing/rtdn?key=<RTDN_SECRET>  (Pub/Sub push của Google Play) -> chỉ là TÍN HIỆU: gọi lại Google lấy trạng thái thật rồi cập nhật hạn Pro
  POST /v1/edit_plan         (Bearer) {"image" (PNG/JPEG b64, nhỏ),"prompt","reference"? (PNG/JPEG b64, ≤ 1,5 MB: ảnh MẪU PHONG CÁCH để agent suy ra màu / tương phản / tông rồi chỉnh ảnh chính theo hướng đó)} -> {"plan":{"ops":[...]},"credits"}   <- Agent AI nhìn ảnh
  CHẾ ĐỘ DÙNG THỬ MIỄN PHÍ (R23, OPEN_BETA=1, MẶC ĐỊNH BẬT): mọi tài khoản dùng đủ tính năng, KHÔNG trừ credits, KHÔNG watermark, được dùng chất lượng cao/Agent AI;
  MẶC ĐỊNH CHỦ APP KHÔNG TRẢ TIỀN AI (BETA_OWNER_PAYS=0): máy chủ KHÔNG gọi nhà cung cấp AI bằng khóa của chủ; generative_fill/edit_plan trả 403 byok_required, routing không còn proxy_cloud,
  tester tự chuẩn bị khóa AI của họ (gọi thẳng từ app, khóa không qua máy chủ) hoặc dùng model chạy trên máy. Chủ app chỉ nên bật BETA_OWNER_PAYS=1 khi tự nguyện chi (vd có khóa miễn phí/ngân sách riêng);
  khi đó mới có hai trần dùng trong 24 giờ để bảo vệ chi phí nhà cung cấp AI: BETA_DAILY_LIMIT (mặc định 100 lượt/thiết bị) và BETA_GLOBAL_LIMIT (mặc định 2000 lượt cho TOÀN máy chủ;
  trần theo thiết bị chỉ là "mềm" vì ai cũng đăng ký được mã thiết bị mới, trần toàn máy chủ mới là chốt chặn ngân sách; 0 = không giới hạn). Module tính phí/Team vẫn nguyên, đặt OPEN_BETA=0 để bật lại.
  GÓI TEAM/ENTERPRISE (R22; chỉ hoạt động khi TEAM_ENABLED=1, mặc định TẮT - mọi số liệu kinh doanh là cấu hình):
  GET  /v1/team              (Bearer)                              -> {"team": null | {"team_id","name","role","seats","members","credits","plan_until","you","member_list"(chỉ quản trị viên)}}
  POST /v1/team/create       (Bearer) {"name"}                     -> {"team","invite_code"}   (cần TEAM_SELF_SERVE=1; không thì do vận hành tạo qua /v1/admin/team)
  POST /v1/team/join         (Bearer) {"code"}                     -> {"team"}                 (mã mời; sai quá 10 lần/giờ -> 429)
  POST /v1/team/leave        (Bearer)                              -> {"ok"}                   (quản trị viên chỉ rời được khi là người cuối cùng -> giải thể)
  POST /v1/team/remove       (Bearer, quản trị viên) {"member_id"} -> {"team"}
  POST /v1/team/transfer     (Bearer, quản trị viên) {"member_id"} -> {"team"}                 (chuyển quyền quản trị)
  POST /v1/team/invite       (Bearer, quản trị viên)               -> {"invite_code"}          (đổi mã mời, mã cũ hết hiệu lực)
  POST /v1/team/fund         (Bearer, quản trị viên) {"credits"}   -> {"team","credits"}       (chuyển credits cá nhân vào quỹ nhóm)
  POST /v1/admin/team        (X-Admin-Key) {"action": create|update|disband|list|set_admin|remove, ...}   <- bán theo hợp đồng (Enterprise): vận hành tạo nhóm, cấp ghế/credits/hạn

Biến môi trường: PORT, SECRET, ADMIN_KEY, DB_PATH, FREE_CREDITS, COST_FAST, COST_HIGH,
                 UPSTREAM (gemini|openai_edits|mock|fail), GEMINI_API_KEY, GEMINI_MODEL, ROUTING_FILE,
                 EDITS_URL, EDITS_MODEL, EDITS_API_KEY, EDITS_IMAGE_FIELD (khi UPSTREAM=openai_edits)
                 BILLING_VERIFY (off|play|mock; mặc định off), PLAY_PACKAGE_NAME, PLAY_SERVICE_ACCOUNT_FILE,
                 CREDIT_PACKS (JSON {"mã_sản_phẩm": số_credits}; mặc định {"credits_20": 20, "credits_100": 110})
                 SUBSCRIPTION_PRODUCTS (JSON {"mã_gói": {"credits": số_credits_mỗi_kỳ}}; mặc định pro_monthly 50, pro_yearly 600),
                 RTDN_SECRET (khóa trong URL đẩy của Pub/Sub; trống = tắt RTDN), SUBSCRIPTION_ACK (server|client; mặc định server)
                 OPEN_BETA (0|1; mặc định 1 = dùng thử miễn phí), BETA_DAILY_LIMIT (mặc định 100; 0 = không giới hạn), BETA_GLOBAL_LIMIT (mặc định 2000; 0 = không giới hạn),
                 BETA_OWNER_PAYS (0|1; mặc định 0 = chủ app KHÔNG trả tiền AI cho tester; 1 = máy chủ dùng khóa của chủ, có trần ở trên),
                 TEAM_ENABLED (0|1; mặc định 0), TEAM_SELF_SERVE (0|1; mặc định 0), TEAM_DEFAULT_SEATS (mặc định 5; chỉ cho nhóm tự tạo),
                 TEAM_PRODUCTS (JSON {"mã_sản_phẩm": {"days":N,"credits":N,"seats":N}}; mặc định {} = chưa bán gói Team qua Google Play)
Xác minh giao dịch: BILLING_VERIFY=play gọi Google Play Developer API (purchases.products.get) bằng tài khoản dịch vụ
(ký JWT RS256 qua lệnh `openssl` có sẵn trên máy chủ), mỗi purchase_token chỉ đổi được MỘT lần. mock chỉ để thử.
Giới hạn tần suất (R30, trong bộ nhớ, cửa sổ trượt): RATE_REGISTER_PER_IP_HOUR (mặc định 60 lần /v1/register mỗi IP mỗi giờ; 0 = tắt), RATE_PER_DEVICE_MINUTE
(mặc định 60 lệnh POST mỗi thiết bị đã đăng nhập mỗi phút; 0 = tắt), TRUST_PROXY_HOPS (mặc định 0 = dùng địa chỉ kết nối trực tiếp và KHÔNG đọc X-Forwarded-For;
đặt N khi có N reverse proxy tin cậy phía trước — lấy địa chỉ thứ N tính từ PHẢI của X-Forwarded-For vì đó là mục do proxy của bạn thêm, phần bên trái do khách tự khai).
Quá hạn mức -> 429 {"code":"rate_limited","retry_after":giây} + tiêu đề Retry-After. Trạng thái nằm trong bộ nhớ nên MỖI tiến trình có hạn mức riêng và mất khi khởi động lại
(chạy nhiều bản sao thì hạn mức thực tế nhân lên; muốn chặt hơn phải đặt giới hạn ở reverse proxy hoặc dùng kho chung).
LƯU Ý: đây là bản tham chiếu. Trước khi phát hành thật cần: HTTPS (reverse proxy) và xác thực người dùng thật (tài khoản/Play Integrity —
/v1/register vẫn cấp tài khoản cho bất kỳ ai nên giới hạn tần suất chỉ làm chậm việc lạm dụng chứ KHÔNG chặn được).
"""
import base64
import collections
import datetime
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import integrity  # R32: Play Integrity (đánh giá verdict + sổ thiết bị đã chứng thực); mặc định TẮT
from urllib.parse import parse_qs, urlparse

MAX_BODY = 24 * 1024 * 1024
PNG_SIG = b"\x89PNG\r\n\x1a\n"


class Config:
    def __init__(self):
        e = os.environ.get
        self.port = int(e("PORT", "8080"))
        self.secret = (e("SECRET") or os.urandom(32).hex()).encode()
        self.admin_key = e("ADMIN_KEY", "")
        self.db_path = e("DB_PATH", "photo_studio.db")
        self.free_credits = int(e("FREE_CREDITS", "5"))
        self.cost_fast = int(e("COST_FAST", "1"))
        self.cost_high = int(e("COST_HIGH", "2"))
        self.upstream = e("UPSTREAM", "gemini")
        self.gemini_key = e("GEMINI_API_KEY", "")
        self.gemini_model = e("GEMINI_MODEL", "gemini-3.1-flash-image")
        self.routing_file = e("ROUTING_FILE", "")
        # Nhà cung cấp tương thích OpenAI /v1/images/edits (OpenAI, stable-diffusion.cpp sd-server, vLLM-Omni...) - dùng để TỰ HOST
        # model giấy phép thương mại như FLUX.2 [klein] 4B (Apache-2.0) thay cho Gemini.
        self.edits_url = e("EDITS_URL", "")
        self.edits_model = e("EDITS_MODEL", "")
        self.edits_key = e("EDITS_API_KEY", "")
        self.edits_image_field = e("EDITS_IMAGE_FIELD", "image[]")
        # Thanh toán Google Play (gói credits mua một lần)
        self.billing_mode = e("BILLING_VERIFY", "off")  # off | play | mock
        self.play_package = e("PLAY_PACKAGE_NAME", "")
        self.play_sa_file = e("PLAY_SERVICE_ACCOUNT_FILE", "")
        self.credit_packs = json.loads(e("CREDIT_PACKS", "") or '{"credits_20": 20, "credits_100": 110}')
        # Gói Pro: mã sản phẩm Google Play (mua một lần, "N ngày Pro") -> số ngày + credits tặng kèm. Đăng ký định kỳ cần thêm
        # subscriptionsv2 (chưa làm - xem backend/README.md).
        self.plan_products = json.loads(e("PLAN_PRODUCTS", "") or '{"pro_30d": {"days": 30, "credits": 50}, "pro_365d": {"days": 365, "credits": 600}}')
        # Đăng ký định kỳ (subscriptionsv2): mã gói -> credits tặng cho MỖI KỲ thanh toán (mỗi mã đơn hàng mới = một kỳ, cộng đúng một lần)
        self.subscription_products = json.loads(e("SUBSCRIPTION_PRODUCTS", "") or '{"pro_monthly": {"credits": 50}, "pro_yearly": {"credits": 600}}')
        # Play Integrity (R32) — CHỨNG THỰC thiết bị/ứng dụng: off | mock | play. Mặc định TẮT; bật INTEGRITY_ENFORCE=1 chỉ khi bản app có client Play Integrity
        # đã phát hành (nếu không MỌI người dùng sẽ bị 403 integrity_required). mock: token chính là JSON verdict (chỉ để thử).
        self.integrity_mode = e("INTEGRITY_MODE", "off")
        self.integrity_enforce = e("INTEGRITY_ENFORCE", "0") == "1"
        self.integrity_ttl = int(e("INTEGRITY_TTL_SECONDS", "86400"))            # thiết bị đã chứng thực được tin trong bao lâu
        self.integrity_window_ms = int(e("INTEGRITY_WINDOW_SECONDS", "600")) * 1000   # token cũ hơn mức này bị từ chối
        self.integrity_require_licensed = e("INTEGRITY_REQUIRE_LICENSED", "0") == "1"  # bắt buộc LICENSED (tester cài APK tay sẽ bị từ chối)
        self.integrity_certs = tuple(x.strip() for x in e("INTEGRITY_CERT_SHA256", "").split(",") if x.strip())  # chứng chỉ ký được phép (sha256 dạng base64url HOẶC hex, có thể kèm dấu hai chấm), trống = không kiểm
        self.integrity_allow_testing = e("INTEGRITY_ALLOW_TESTING_RESPONSE", "0") == "1"   # chấp nhận phản hồi kiểm thử của Play Console (chỉ để QA)
        self.integrity_sa_file = e("INTEGRITY_SERVICE_ACCOUNT_FILE", "")        # trống = dùng PLAY_SERVICE_ACCOUNT_FILE (cùng dự án Google Cloud đã liên kết với app)
        self.attestations = integrity.Attestations(lambda: self.clock())
        self.rtdn_secret = e("RTDN_SECRET", "")             # khóa nằm trong URL đẩy Pub/Sub (so sánh hằng thời gian); trống = tắt RTDN
        self.sub_ack = e("SUBSCRIPTION_ACK", "server")      # server: máy chủ tự acknowledge | client: app tự acknowledgePurchase
        self.free_high_quality = e("FREE_HIGH_QUALITY", "0") == "1"   # gói Free có được dùng chất lượng cao không
        self.cost_plan = int(e("COST_PLAN", "1"))                      # credits cho một lần Agent AI (nhìn ảnh, lập kế hoạch chỉnh)
        self.pro_plan_free = e("PRO_PLAN_FREE", "1") == "1"            # gói Pro dùng Agent AI không tốn credits
        self.gemini_plan_model = e("GEMINI_PLAN_MODEL", "gemini-3.5-flash-lite")
        # Dùng thử miễn phí (R23): giai đoạn đầu KHÔNG tính phí. Module thanh toán/gói Pro/Team vẫn nguyên (đặt OPEN_BETA=0 để bật lại);
        # chỉ giữ một TRẦN dùng trong ngày cho mỗi thiết bị để một người không đốt hết ngân sách nhà cung cấp AI của bạn.
        self.open_beta = e("OPEN_BETA", "1") == "1"
        self.beta_daily_limit = int(e("BETA_DAILY_LIMIT", "100"))
        self.rate_register_ip_hour = int(e("RATE_REGISTER_PER_IP_HOUR", "60"))   # R30: /v1/register tối đa mỗi IP mỗi giờ (0 = tắt)
        self.rate_device_minute = int(e("RATE_PER_DEVICE_MINUTE", "60"))         # R30: lệnh POST tối đa mỗi thiết bị đã đăng nhập mỗi phút (0 = tắt)
        self.trust_proxy_hops = int(e("TRUST_PROXY_HOPS", "0"))                  # R30: số reverse proxy tin cậy phía trước (0 = không đọc X-Forwarded-For)
        self.clock = time.time                                                   # R30: đồng hồ của bộ giới hạn (test thay bằng đồng hồ giả)
        self.last_plan_had_reference = False                                     # R30: lần gọi edit_plan gần nhất có ảnh mẫu không (để test / giám sát)
        self.beta_global_limit = int(e("BETA_GLOBAL_LIMIT", "2000"))
        # Chủ app có trả tiền AI cho tester không (R23). Mặc định KHÔNG: miễn phí cho người dùng nghĩa là chủ app không bị tính tiền nhà cung cấp.
        self.beta_owner_pays = e("BETA_OWNER_PAYS", "0") == "1"
        # Gói Team/Enterprise (R22). MỌI con số kinh doanh (giá, số ghế, credits, thời hạn) nằm ở cấu hình / bảng giá Play Console / lệnh vận hành,
        # không hardcode trong mã. Mặc định TẮT: bật bằng TEAM_ENABLED=1.
        self.team_enabled = e("TEAM_ENABLED", "0") == "1"
        self.team_self_serve = e("TEAM_SELF_SERVE", "0") == "1"   # 1: bất kỳ tài khoản nào cũng tự tạo nhóm; 0: chỉ vận hành tạo (bán theo hợp đồng)
        self.team_default_seats = int(e("TEAM_DEFAULT_SEATS", "5"))
        self.team_products = json.loads(e("TEAM_PRODUCTS", "") or "{}")


TEAM_NAME_MAX = 60
TEAM_MAX_SEATS = 1000
INVITE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"      # bỏ 0/O/1/I dễ nhầm


class TeamError(Exception):
    def __init__(self, msg, status=400):
        super().__init__(msg)
        self.status = status


def new_invite_code():
    return "".join(secrets.choice(INVITE_ALPHABET) for _ in range(10))


def invite_hash(code):
    """Chỉ lưu BĂM của mã mời (như mật khẩu): lộ CSDL không lộ mã. Bỏ dấu gạch/khoảng trắng, không phân biệt hoa thường."""
    return hashlib.sha256(("team-invite:" + re.sub(r"[^A-Z0-9]", "", str(code).upper())).encode()).hexdigest()


def show_invite(code):
    return code[:5] + "-" + code[5:]


def clean_team_name(name):
    name = "".join(ch for ch in str(name) if ch.isprintable() or ch.isspace())
    return " ".join(name.split())[:TEAM_NAME_MAX]


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.lock = threading.Lock()
        with self.lock:
            self.db.execute("CREATE TABLE IF NOT EXISTS accounts(device_id TEXT PRIMARY KEY, credits INTEGER NOT NULL, created REAL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT, delta INTEGER, reason TEXT, ts REAL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS purchases(token_hash TEXT PRIMARY KEY, order_id TEXT, device_id TEXT, product_id TEXT, credits INTEGER, ts REAL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS subscriptions(token_hash TEXT PRIMARY KEY, token TEXT NOT NULL, device_id TEXT NOT NULL, "
                            "product_id TEXT, state TEXT, entitled INTEGER NOT NULL DEFAULT 0, expiry REAL DEFAULT 0, latest_order TEXT, "
                            "ack_pending INTEGER NOT NULL DEFAULT 0, updated REAL)")
            self.db.execute("CREATE INDEX IF NOT EXISTS sub_by_device ON subscriptions(device_id)")
            self.db.execute("CREATE TABLE IF NOT EXISTS sub_orders(order_id TEXT PRIMARY KEY, device_id TEXT, product_id TEXT, credits INTEGER, ts REAL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS usage(device_id TEXT NOT NULL, ts REAL NOT NULL)")
            self.db.execute("CREATE INDEX IF NOT EXISTS usage_by_device ON usage(device_id, ts)")
            self.db.execute("CREATE INDEX IF NOT EXISTS usage_by_ts ON usage(ts)")
            self.db.execute("CREATE TABLE IF NOT EXISTS teams(team_id TEXT PRIMARY KEY, name TEXT NOT NULL, admin_device TEXT NOT NULL, seats INTEGER NOT NULL, "
                            "credits INTEGER NOT NULL DEFAULT 0, plan_until REAL NOT NULL DEFAULT 0, invite_hash TEXT NOT NULL, created REAL)")
            self.db.execute("CREATE UNIQUE INDEX IF NOT EXISTS team_invite ON teams(invite_hash)")
            self.db.execute("CREATE TABLE IF NOT EXISTS team_members(device_id TEXT PRIMARY KEY, team_id TEXT NOT NULL, role TEXT NOT NULL, joined REAL)")
            self.db.execute("CREATE INDEX IF NOT EXISTS team_members_by_team ON team_members(team_id)")
            self.db.execute("CREATE TABLE IF NOT EXISTS team_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, team_id TEXT, device_id TEXT, delta INTEGER, reason TEXT, ts REAL)")
            cols = [r[1] for r in self.db.execute("PRAGMA table_info(accounts)").fetchall()]
            if "plan_until" not in cols:   # nâng cấp CSDL cũ: thêm hạn gói Pro
                self.db.execute("ALTER TABLE accounts ADD COLUMN plan_until REAL DEFAULT 0")

    def plan_until(self, device_id):
        """Hạn Pro = MUỘN NHẤT của (gói "N ngày" mua một lần) và (các đăng ký định kỳ đang được hưởng quyền lợi)."""
        with self.lock:
            row = self.db.execute("SELECT COALESCE(plan_until,0) FROM accounts WHERE device_id=?", (device_id,)).fetchone()
            if row is None:
                return 0.0
            sub = self.db.execute("SELECT COALESCE(MAX(expiry),0) FROM subscriptions WHERE device_id=? AND entitled=1", (device_id,)).fetchone()[0]
            t = self._team_row(device_id)       # thành viên nhóm được hưởng hạn Pro của NHÓM (rời nhóm là mất)
            return max(float(row[0]), float(sub or 0), float(t[5]) if t else 0.0)

    def is_pro(self, device_id):
        return self.plan_until(device_id) > time.time()

    def register(self, device_id, free):
        with self.lock:
            row = self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()
            if row is None:
                self.db.execute("INSERT INTO accounts(device_id, credits, created) VALUES(?,?,?)", (device_id, free, time.time()))
                self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, free, "free_signup", time.time()))
                return free
            return row[0]

    def credits(self, device_id):
        """Số credits DÙNG ĐƯỢC = ví cá nhân + quỹ nhóm (nếu là thành viên một nhóm)."""
        with self.lock:
            return self._usable(device_id)

    # ------------------------------------------------------------------ trần dùng trong ngày (chế độ dùng thử miễn phí, R23)
    def usage_today(self, device_id, now=None):
        now = time.time() if now is None else now
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM usage WHERE device_id=? AND ts>?", (device_id, now - 86400)).fetchone()[0]

    def usage_total_today(self, now=None):
        """Tổng lượt dùng của MỌI thiết bị trong 24 giờ qua (chốt chặn ngân sách nhà cung cấp AI)."""
        now = time.time() if now is None else now
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM usage WHERE ts>?", (now - 86400,)).fetchone()[0]

    def usage_note(self, device_id, now=None):
        """Ghi một lượt dùng THÀNH CÔNG (lỗi nhà cung cấp không tính). Tiện thể dọn mọi dòng quá 2 ngày (theo chỉ mục ts, rẻ)."""
        now = time.time() if now is None else now
        with self.lock:
            self.db.execute("INSERT INTO usage(device_id,ts) VALUES(?,?)", (device_id, now))
            self.db.execute("DELETE FROM usage WHERE ts<=?", (now - 2 * 86400,))

    def personal_credits(self, device_id):
        with self.lock:
            row = self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()
            return None if row is None else row[0]

    def _usable(self, device_id):       # người gọi đang giữ self.lock
        row = self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()
        if row is None:
            return None
        t = self._team_row(device_id)
        return row[0] + (t[4] if t else 0)

    def charge_ex(self, device_id, cost, reason):
        """Trừ NGUYÊN TỬ: lấy từ quỹ nhóm trước (nếu là thành viên), phần thiếu lấy ở ví cá nhân; không đủ thì KHÔNG trừ gì.
        Trả về (số dư dùng được, biên lai (từ_quỹ, từ_ví)) hoặc (None, None)."""
        with self.lock:
            row = self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()
            if row is None:
                return None, None
            t = self._team_row(device_id)
            from_pool = min(t[4], cost) if t else 0
            from_me = cost - from_pool
            if row[0] < from_me:
                return None, None
            now = time.time()
            if from_pool:
                self.db.execute("UPDATE teams SET credits = credits - ? WHERE team_id=?", (from_pool, t[0]))
                self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (t[0], device_id, -from_pool, reason, now))
            if from_me:
                self.db.execute("UPDATE accounts SET credits = credits - ? WHERE device_id=?", (from_me, device_id))
                self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, -from_me, reason, now))
            return self._usable(device_id), (from_pool, from_me)

    def refund(self, device_id, receipt, reason):
        """Hoàn đúng nguồn đã trừ (quỹ nhóm hoàn về quỹ nếu còn là thành viên, ngược lại về ví cá nhân). Trả về số dư dùng được."""
        pool, mine = receipt
        with self.lock:
            now = time.time()
            t = self._team_row(device_id)
            if pool:
                if t:
                    self.db.execute("UPDATE teams SET credits = credits + ? WHERE team_id=?", (pool, t[0]))
                    self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (t[0], device_id, pool, reason, now))
                else:
                    mine += pool
            if mine:
                self.db.execute("UPDATE accounts SET credits = credits + ? WHERE device_id=?", (mine, device_id))
                self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, mine, reason, now))
            return self._usable(device_id)

    def charge(self, device_id, cost, reason):
        """Trừ credits nguyên tử. Trả về số dư mới hoặc None nếu không đủ / không có tài khoản."""
        return self.charge_ex(device_id, cost, reason)[0]

    def grant(self, device_id, amount, reason):
        with self.lock:
            cur = self.db.execute("UPDATE accounts SET credits = credits + ? WHERE device_id=?", (amount, device_id))
            if cur.rowcount != 1:
                return None
            self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, amount, reason, time.time()))
            return self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()[0]


    def redeem(self, device_id, token_hash, order_id, product_id, credits, plan_days=0):
        """Cộng credits cho một giao dịch, NGUYÊN TỬ và mỗi purchase_token chỉ một lần. Trả về (số dư, None) hoặc (None, lý do)."""
        with self.lock:
            if self.db.execute("SELECT 1 FROM purchases WHERE token_hash=?", (token_hash,)).fetchone():
                return None, "đã đổi"
            if self.db.execute("SELECT 1 FROM accounts WHERE device_id=?", (device_id,)).fetchone() is None:
                return None, "không có tài khoản"
            self.db.execute("INSERT INTO purchases VALUES(?,?,?,?,?,?)", (token_hash, order_id, device_id, product_id, credits, time.time()))
            self.db.execute("UPDATE accounts SET credits = credits + ? WHERE device_id=?", (credits, device_id))
            self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, credits, "play:" + product_id, time.time()))
            if plan_days:   # gia hạn Pro: cộng dồn từ hạn hiện tại nếu còn, không thì từ bây giờ
                self.db.execute("UPDATE accounts SET plan_until = MAX(COALESCE(plan_until,0), ?) + ? WHERE device_id=?", (time.time(), plan_days * 86400, device_id))
            return self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()[0], None

    # ------------------------------------------------------------------ gói Team / Enterprise (R22)
    def _team_row(self, device_id):     # người gọi đang giữ self.lock
        """(team_id, name, admin_device, seats, credits, plan_until, role) của nhóm mà thiết bị đang tham gia, hoặc None."""
        return self.db.execute("SELECT t.team_id, t.name, t.admin_device, t.seats, t.credits, t.plan_until, m.role FROM team_members m "
                               "JOIN teams t ON t.team_id=m.team_id WHERE m.device_id=?", (device_id,)).fetchone()

    def _count(self, team_id):
        return self.db.execute("SELECT COUNT(*) FROM team_members WHERE team_id=?", (team_id,)).fetchone()[0]

    def _need_admin(self, device_id):
        t = self._team_row(device_id)
        if t is None:
            raise TeamError("tài khoản không thuộc nhóm nào", 404)
        if t[6] != "admin":
            raise TeamError("chỉ quản trị viên nhóm mới làm được việc này", 403)
        return t

    def is_team_admin(self, device_id):
        with self.lock:
            t = self._team_row(device_id)
            return t is not None and t[6] == "admin"

    def team_info(self, device_id, members=False):
        with self.lock:
            t = self._team_row(device_id)
            if t is None:
                return None
            now = time.time()
            info = {"team_id": t[0], "name": t[1], "role": t[6], "seats": t[3], "members": self._count(t[0]), "credits": t[4],
                    "plan_until": int(t[5]) if t[5] > now else 0, "you": account_hash(device_id)}
            if members and t[6] == "admin":      # id thành viên là BĂM ẩn danh, quản trị viên không thấy mã thiết bị thật
                info["member_list"] = [{"member_id": account_hash(d), "role": r, "joined": int(j or 0)}
                                       for d, r, j in self.db.execute("SELECT device_id, role, joined FROM team_members WHERE team_id=? ORDER BY joined", (t[0],))]
            return info

    def team_create(self, admin_device, name, seats, credits=0, plan_days=0):
        """Tạo nhóm, người tạo là quản trị viên. Trả về (team_id, mã mời) - mã mời CHỈ hiện lúc này (CSDL chỉ lưu băm)."""
        name = clean_team_name(name)
        if not name:
            raise TeamError("thiếu tên nhóm")
        seats = int(seats)
        if not (1 <= seats <= TEAM_MAX_SEATS):
            raise TeamError("số ghế không hợp lệ")
        with self.lock:
            if self.db.execute("SELECT 1 FROM accounts WHERE device_id=?", (admin_device,)).fetchone() is None:
                raise TeamError("không có tài khoản", 404)
            if self._team_row(admin_device):
                raise TeamError("tài khoản đã thuộc một nhóm", 409)
            now = time.time()
            team_id = secrets.token_hex(8)
            code = new_invite_code()
            credits = max(0, int(credits))
            until = now + int(plan_days) * 86400 if int(plan_days) > 0 else 0
            self.db.execute("INSERT INTO teams(team_id,name,admin_device,seats,credits,plan_until,invite_hash,created) VALUES(?,?,?,?,?,?,?,?)",
                            (team_id, name, admin_device, seats, credits, until, invite_hash(code), now))
            self.db.execute("INSERT INTO team_members(device_id,team_id,role,joined) VALUES(?,?,?,?)", (admin_device, team_id, "admin", now))
            if credits:
                self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (team_id, admin_device, credits, "create", now))
            return team_id, show_invite(code)

    def team_join(self, device_id, code):
        h = invite_hash(code)
        with self.lock:
            if self.db.execute("SELECT 1 FROM accounts WHERE device_id=?", (device_id,)).fetchone() is None:
                raise TeamError("không có tài khoản", 404)
            if self._team_row(device_id):
                raise TeamError("tài khoản đã thuộc một nhóm (rời nhóm cũ trước)", 409)
            row = self.db.execute("SELECT team_id, seats FROM teams WHERE invite_hash=?", (h,)).fetchone()
            if row is None:
                raise TeamError("mã mời không đúng", 403)
            if self._count(row[0]) >= row[1]:
                raise TeamError("nhóm đã đủ ghế", 409)
            self.db.execute("INSERT INTO team_members(device_id,team_id,role,joined) VALUES(?,?,?,?)", (device_id, row[0], "member", time.time()))

    def _disband(self, team_id, refund_to):      # người gọi đang giữ self.lock; quỹ còn lại trả về ví cá nhân của quản trị viên
        row = self.db.execute("SELECT credits FROM teams WHERE team_id=?", (team_id,)).fetchone()
        if row is None:
            return 0
        now = time.time()
        left = int(row[0])
        if left > 0 and refund_to and self.db.execute("SELECT 1 FROM accounts WHERE device_id=?", (refund_to,)).fetchone():
            self.db.execute("UPDATE accounts SET credits = credits + ? WHERE device_id=?", (left, refund_to))
            self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (refund_to, left, "team_disband", now))
        self.db.execute("DELETE FROM team_members WHERE team_id=?", (team_id,))
        self.db.execute("DELETE FROM teams WHERE team_id=?", (team_id,))
        return left

    def team_leave(self, device_id):
        with self.lock:
            t = self._team_row(device_id)
            if t is None:
                raise TeamError("tài khoản không thuộc nhóm nào", 404)
            if t[6] == "admin":
                if self._count(t[0]) > 1:
                    raise TeamError("quản trị viên cần chuyển quyền hoặc xóa hết thành viên trước khi rời", 409)
                self._disband(t[0], device_id)
            else:
                self.db.execute("DELETE FROM team_members WHERE device_id=?", (device_id,))

    def _member_by_id(self, team_id, member_id):
        for (d,) in self.db.execute("SELECT device_id FROM team_members WHERE team_id=?", (team_id,)).fetchall():
            if account_hash(d) == str(member_id):
                return d
        return None

    def team_remove(self, admin_device, member_id):
        with self.lock:
            t = self._need_admin(admin_device)
            d = self._member_by_id(t[0], member_id)
            if d is None:
                raise TeamError("không tìm thấy thành viên", 404)
            if d == admin_device:
                raise TeamError("không thể tự xóa mình (dùng rời nhóm)", 409)
            self.db.execute("DELETE FROM team_members WHERE device_id=?", (d,))

    def team_transfer(self, admin_device, member_id):
        with self.lock:
            t = self._need_admin(admin_device)
            d = self._member_by_id(t[0], member_id)
            if d is None:
                raise TeamError("không tìm thấy thành viên", 404)
            if d == admin_device:
                raise TeamError("đã là quản trị viên", 409)
            self.db.execute("UPDATE team_members SET role='member' WHERE device_id=?", (admin_device,))
            self.db.execute("UPDATE team_members SET role='admin' WHERE device_id=?", (d,))
            self.db.execute("UPDATE teams SET admin_device=? WHERE team_id=?", (d, t[0]))

    def team_rotate_invite(self, admin_device):
        with self.lock:
            t = self._need_admin(admin_device)
            code = new_invite_code()
            self.db.execute("UPDATE teams SET invite_hash=? WHERE team_id=?", (invite_hash(code), t[0]))
            return show_invite(code)

    def team_fund(self, admin_device, amount):
        """Chuyển credits từ ví cá nhân của quản trị viên vào quỹ nhóm (một chiều; muốn lấy lại phải giải thể nhóm)."""
        amount = int(amount)
        if amount <= 0:
            raise TeamError("số credits phải > 0")
        with self.lock:
            t = self._need_admin(admin_device)
            cur = self.db.execute("UPDATE accounts SET credits = credits - ? WHERE device_id=? AND credits >= ?", (amount, admin_device, amount))
            if cur.rowcount != 1:
                raise TeamError("không đủ credits cá nhân", 402)
            now = time.time()
            self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (admin_device, -amount, "team_fund", now))
            self.db.execute("UPDATE teams SET credits = credits + ? WHERE team_id=?", (amount, t[0]))
            self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (t[0], admin_device, amount, "fund", now))

    def team_redeem(self, admin_device, token_hash, order_id, product_id, credits, plan_days, seats):
        """Gói Team mua qua Google Play: cộng vào QUỸ NHÓM (credits), gia hạn Pro của nhóm, nâng số ghế tối thiểu. Mỗi purchase_token một lần."""
        with self.lock:
            if self.db.execute("SELECT 1 FROM purchases WHERE token_hash=?", (token_hash,)).fetchone():
                raise TeamError("đã đổi", 409)
            t = self._need_admin(admin_device)
            now = time.time()
            self.db.execute("INSERT INTO purchases VALUES(?,?,?,?,?,?)", (token_hash, order_id, admin_device, product_id, credits, now))
            if credits:
                self.db.execute("UPDATE teams SET credits = credits + ? WHERE team_id=?", (credits, t[0]))
                self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (t[0], admin_device, credits, "play:" + product_id, now))
            if plan_days:
                self.db.execute("UPDATE teams SET plan_until = MAX(plan_until, ?) + ? WHERE team_id=?", (now, plan_days * 86400, t[0]))
            if seats:
                self.db.execute("UPDATE teams SET seats = MAX(seats, ?) WHERE team_id=?", (min(int(seats), TEAM_MAX_SEATS), t[0]))

    # --- phía vận hành (X-Admin-Key): bán theo hợp đồng
    def team_admin_update(self, team_id, add_credits=0, plan_days=0, seats=None):
        with self.lock:
            row = self.db.execute("SELECT credits FROM teams WHERE team_id=?", (team_id,)).fetchone()
            if row is None:
                raise TeamError("không có nhóm này", 404)
            now = time.time()
            add_credits = int(add_credits)
            if row[0] + add_credits < 0:
                raise TeamError("quỹ nhóm không thể âm", 409)
            if seats is not None:
                seats = int(seats)
                if not (1 <= seats <= TEAM_MAX_SEATS):
                    raise TeamError("số ghế không hợp lệ")
                if seats < self._count(team_id):
                    raise TeamError("ít hơn số thành viên hiện có - xóa bớt thành viên trước", 409)
                self.db.execute("UPDATE teams SET seats=? WHERE team_id=?", (seats, team_id))
            if add_credits:
                self.db.execute("UPDATE teams SET credits = credits + ? WHERE team_id=?", (add_credits, team_id))
                self.db.execute("INSERT INTO team_ledger(team_id,device_id,delta,reason,ts) VALUES(?,?,?,?,?)", (team_id, "", add_credits, "admin", now))
            if int(plan_days) > 0:
                self.db.execute("UPDATE teams SET plan_until = MAX(plan_until, ?) + ? WHERE team_id=?", (now, int(plan_days) * 86400, team_id))
            r = self.db.execute("SELECT name, seats, credits, plan_until FROM teams WHERE team_id=?", (team_id,)).fetchone()
            return {"team_id": team_id, "name": r[0], "seats": r[1], "members": self._count(team_id), "credits": r[2], "plan_until": int(r[3]) if r[3] > now else 0}

    def team_admin_set_admin(self, team_id, device_id):
        """Vận hành chuyển quyền quản trị cho một thành viên có sẵn (vd quản trị viên cũ cài lại app/mất máy -> mất vai trò vì tài khoản theo device_id)."""
        with self.lock:
            if self.db.execute("SELECT 1 FROM teams WHERE team_id=?", (team_id,)).fetchone() is None:
                raise TeamError("không có nhóm này", 404)
            if self.db.execute("SELECT 1 FROM team_members WHERE team_id=? AND device_id=?", (team_id, device_id)).fetchone() is None:
                raise TeamError("thiết bị này không thuộc nhóm", 404)
            self.db.execute("UPDATE team_members SET role='member' WHERE team_id=? AND role='admin'", (team_id,))
            self.db.execute("UPDATE team_members SET role='admin' WHERE team_id=? AND device_id=?", (team_id, device_id))
            self.db.execute("UPDATE teams SET admin_device=? WHERE team_id=?", (device_id, team_id))

    def team_admin_remove(self, team_id, device_id):
        """Vận hành xóa một thành viên khỏi nhóm (trả ghế). Không xóa được quản trị viên - chuyển quyền hoặc giải thể trước."""
        with self.lock:
            m = self.db.execute("SELECT role FROM team_members WHERE team_id=? AND device_id=?", (team_id, device_id)).fetchone()
            if m is None:
                raise TeamError("thiết bị này không thuộc nhóm", 404)
            if m[0] == "admin":
                raise TeamError("không xóa được quản trị viên - chuyển quyền hoặc giải thể nhóm trước", 409)
            self.db.execute("DELETE FROM team_members WHERE team_id=? AND device_id=?", (team_id, device_id))

    def team_admin_disband(self, team_id):
        with self.lock:
            row = self.db.execute("SELECT admin_device FROM teams WHERE team_id=?", (team_id,)).fetchone()
            if row is None:
                raise TeamError("không có nhóm này", 404)
            return self._disband(team_id, row[0])

    def team_admin_list(self):
        with self.lock:
            now = time.time()
            return [{"team_id": r[0], "name": r[1], "seats": r[2], "members": self._count(r[0]), "credits": r[3], "plan_until": int(r[4]) if r[4] > now else 0}
                    for r in self.db.execute("SELECT team_id, name, seats, credits, plan_until FROM teams ORDER BY created").fetchall()]

    # ------------------------------------------------------------------ đăng ký định kỳ
    def subscription_by_hash(self, token_hash):
        with self.lock:
            r = self.db.execute("SELECT device_id, token, product_id, state, entitled, expiry, latest_order, ack_pending FROM subscriptions WHERE token_hash=?",
                                (token_hash,)).fetchone()
        if r is None:
            return None
        return {"device_id": r[0], "token": r[1], "product_id": r[2], "state": r[3], "entitled": bool(r[4]), "expiry": float(r[5] or 0),
                "latest_order": r[6], "ack_pending": bool(r[7])}

    def subscription_info(self, device_id):
        """Đăng ký đang hưởng quyền lợi có hạn muộn nhất của tài khoản (hoặc None)."""
        with self.lock:
            r = self.db.execute("SELECT product_id, state, expiry FROM subscriptions WHERE device_id=? AND entitled=1 ORDER BY expiry DESC LIMIT 1",
                                (device_id,)).fetchone()
        return None if r is None else {"product_id": r[0], "state": r[1].replace("SUBSCRIPTION_STATE_", "").lower(), "expiry": int(r[2])}

    def set_ack_pending(self, token_hash, pending):
        with self.lock:
            self.db.execute("UPDATE subscriptions SET ack_pending=? WHERE token_hash=?", (1 if pending else 0, token_hash))

    def apply_subscription(self, device_id, token_hash, token, product_id, state, entitled, expiry, order_id, ack_pending, period_credits, linked_hash=None):
        """Ghi/cập nhật một đăng ký; nếu còn hiệu lực thì cộng credits của kỳ hiện tại ĐÚNG MỘT LẦN cho mỗi mã đơn hàng.
        Trả về ({"granted","credits"}, None) hoặc (None, lý do). Mỗi token chỉ thuộc MỘT tài khoản (người đầu tiên đăng ký)."""
        now = time.time()
        with self.lock:
            if self.db.execute("SELECT 1 FROM accounts WHERE device_id=?", (device_id,)).fetchone() is None:
                return None, "không có tài khoản"
            row = self.db.execute("SELECT device_id FROM subscriptions WHERE token_hash=?", (token_hash,)).fetchone()
            if row is not None and row[0] != device_id:
                return None, "đăng ký thuộc tài khoản khác"
            self.db.execute("INSERT OR IGNORE INTO subscriptions(token_hash,token,device_id,product_id,state,entitled,expiry,latest_order,ack_pending,updated) "
                            "VALUES(?,?,?,?,?,?,?,?,?,?)", (token_hash, token, device_id, product_id, state, 0, 0.0, "", 0, now))
            self.db.execute("UPDATE subscriptions SET product_id=?, state=?, entitled=?, expiry=?, latest_order=?, ack_pending=?, updated=? WHERE token_hash=?",
                            (product_id, state, 1 if entitled else 0, float(expiry or 0), order_id, 1 if ack_pending else 0, now, token_hash))
            if linked_hash:   # đăng ký mới thay thế đăng ký cũ (đổi gói / đăng ký lại) -> đăng ký cũ hết hiệu lực
                self.db.execute("UPDATE subscriptions SET entitled=0, state='SUPERSEDED', updated=? WHERE token_hash=? AND device_id=?", (now, linked_hash, device_id))
            granted = 0
            if entitled and order_id and period_credits > 0:
                cur = self.db.execute("INSERT OR IGNORE INTO sub_orders(order_id,device_id,product_id,credits,ts) VALUES(?,?,?,?,?)",
                                      (order_id, device_id, product_id, period_credits, now))
                if cur.rowcount == 1:
                    self.db.execute("UPDATE accounts SET credits = credits + ? WHERE device_id=?", (period_credits, device_id))
                    self.db.execute("INSERT INTO ledger(device_id,delta,reason,ts) VALUES(?,?,?,?)", (device_id, period_credits, "sub:" + product_id, now))
                    granted = period_credits
            credits = self.db.execute("SELECT credits FROM accounts WHERE device_id=?", (device_id,)).fetchone()[0]
            return {"granted": granted, "credits": credits}, None


def make_token(cfg, device_id):
    sig = hmac.new(cfg.secret, device_id.encode(), hashlib.sha256).hexdigest()
    return device_id + "." + sig


def check_token(cfg, token):
    if not token or "." not in token:
        return None
    device_id, sig = token.rsplit(".", 1)
    good = hmac.new(cfg.secret, device_id.encode(), hashlib.sha256).hexdigest()
    return device_id if hmac.compare_digest(sig, good) else None


class BillingError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def http_json(url, method="GET", headers=None, data=None, timeout=15):
    """Gọi HTTP trả (status, JSON). Tách riêng để kiểm thử thay thế được."""
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except Exception:
            return e.code, {}


def _b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def sign_rs256(private_key_pem, data):
    """Ký RSA-SHA256 bằng `openssl dgst -sha256 -sign` (thư viện chuẩn Python không có RSA)."""
    fd, path = tempfile.mkstemp(suffix=".pem")
    try:
        os.write(fd, private_key_pem.encode())
        os.close(fd)
        os.chmod(path, 0o600)
        r = subprocess.run(["openssl", "dgst", "-sha256", "-sign", path], input=data, capture_output=True, timeout=15)
        if r.returncode != 0:
            raise BillingError("openssl ký JWT thất bại: " + r.stderr.decode(errors="replace")[:200], 500)
        return r.stdout
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


PLAY_SCOPE = "https://www.googleapis.com/auth/androidpublisher"


def build_service_account_jwt(sa, now=None, scope=PLAY_SCOPE):
    now = int(now or time.time())
    header = {"alg": "RS256", "typ": "JWT"}
    claims = {"iss": sa["client_email"], "scope": scope,
              "aud": sa.get("token_uri", "https://oauth2.googleapis.com/token"), "iat": now, "exp": now + 3600}
    signing_input = _b64url(json.dumps(header).encode()) + "." + _b64url(json.dumps(claims).encode())
    return signing_input + "." + _b64url(sign_rs256(sa["private_key"], signing_input.encode()))


_PLAY_TOKEN = {"tok": None, "exp": 0.0}
_PLAY_LOCK = threading.Lock()


def play_access_token(cfg):
    with _PLAY_LOCK:
        if _PLAY_TOKEN["tok"] and _PLAY_TOKEN["exp"] > time.time() + 60:
            return _PLAY_TOKEN["tok"]
        if not cfg.play_sa_file:
            raise BillingError("thiếu PLAY_SERVICE_ACCOUNT_FILE", 500)
        with open(cfg.play_sa_file, encoding="utf-8") as f:
            sa = json.load(f)
        assertion = build_service_account_jwt(sa)
        form = urllib.parse.urlencode({"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": assertion}).encode()
        status, data = http_json(sa.get("token_uri", "https://oauth2.googleapis.com/token"), "POST",
                                 {"Content-Type": "application/x-www-form-urlencoded"}, form)
        if status != 200 or "access_token" not in data:
            raise BillingError("không lấy được access token Google (mã %s)" % status, 502)
        _PLAY_TOKEN["tok"] = data["access_token"]
        _PLAY_TOKEN["exp"] = time.time() + int(data.get("expires_in", 3000))
        return _PLAY_TOKEN["tok"]


_INTEGRITY_TOKEN = {"tok": None, "exp": 0.0}
_INTEGRITY_LOCK = threading.Lock()


def integrity_access_token(cfg):
    """Access token OAuth cho Play Integrity API (phạm vi playintegrity) từ tài khoản dịch vụ; lưu đệm riêng với token Play Developer API."""
    with _INTEGRITY_LOCK:
        if _INTEGRITY_TOKEN["tok"] and _INTEGRITY_TOKEN["exp"] > time.time() + 60:
            return _INTEGRITY_TOKEN["tok"]
        sa_file = cfg.integrity_sa_file or cfg.play_sa_file
        if not sa_file:
            raise BillingError("thiếu INTEGRITY_SERVICE_ACCOUNT_FILE / PLAY_SERVICE_ACCOUNT_FILE", 500)
        with open(sa_file, encoding="utf-8") as f:
            sa = json.load(f)
        assertion = build_service_account_jwt(sa, scope=integrity.INTEGRITY_SCOPE)
        form = urllib.parse.urlencode({"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": assertion}).encode()
        status, data = http_json(sa.get("token_uri", "https://oauth2.googleapis.com/token"), "POST",
                                 {"Content-Type": "application/x-www-form-urlencoded"}, form)
        if status != 200 or "access_token" not in data:
            raise BillingError("không lấy được access token Google cho Play Integrity (mã %s)" % status, 502)
        _INTEGRITY_TOKEN["tok"] = data["access_token"]
        _INTEGRITY_TOKEN["exp"] = time.time() + int(data.get("expires_in", 3000))
        return _INTEGRITY_TOKEN["tok"]


def decode_integrity_token(cfg, token):
    """Giải mã + xác minh token Play Integrity ở máy chủ Google (decodeIntegrityToken) → tokenPayloadExternal. Lỗi -> BillingError."""
    if cfg.integrity_mode == "mock":  # chỉ để thử: token chính là JSON verdict
        try:
            payload = json.loads(token)
        except ValueError:
            raise BillingError("token không hợp lệ", 400)
        if not isinstance(payload, dict):
            raise BillingError("token không hợp lệ", 400)
        return payload
    if cfg.integrity_mode != "play" or not cfg.play_package:
        raise BillingError("Play Integrity chưa được bật trên máy chủ", 503)
    url = "https://playintegrity.googleapis.com/v1/%s:decodeIntegrityToken" % urllib.parse.quote(cfg.play_package, safe="")
    status, data = http_json(url, "POST", {"Authorization": "Bearer " + integrity_access_token(cfg), "Content-Type": "application/json"},
                             json.dumps({"integrityToken": token}).encode())
    if status == 400:
        raise BillingError("token Play Integrity không hợp lệ", 400)
    if status != 200 or not isinstance(data.get("tokenPayloadExternal"), dict):
        raise BillingError("Play Integrity trả mã %s" % status, 502)
    return data["tokenPayloadExternal"]


def verify_purchase(cfg, product_id, purchase_token):
    """Trả về dict kiểu ProductPurchase của Google (purchaseState, orderId, obfuscatedExternalAccountId...). Lỗi -> BillingError."""
    if cfg.billing_mode == "mock":  # chỉ để thử: ok-* hợp lệ, pending-* chờ thanh toán, còn lại không tồn tại
        if purchase_token.startswith("ok-"):
            return {"purchaseState": 0, "orderId": "GPA.MOCK-" + purchase_token, "productId": product_id}
        if purchase_token.startswith("pending-"):
            return {"purchaseState": 2, "orderId": "", "productId": product_id}
        raise BillingError("giao dịch không hợp lệ", 400)
    if cfg.billing_mode != "play" or not cfg.play_package:
        raise BillingError("thanh toán chưa được bật trên máy chủ", 503)
    url = ("https://androidpublisher.googleapis.com/androidpublisher/v3/applications/%s/purchases/products/%s/tokens/%s"
           % tuple(urllib.parse.quote(x, safe="") for x in (cfg.play_package, product_id, purchase_token)))
    status, data = http_json(url, headers={"Authorization": "Bearer " + play_access_token(cfg), "Accept": "application/json"})
    if status in (400, 404, 410):
        raise BillingError("giao dịch không hợp lệ", 400)
    if status != 200:
        raise BillingError("Google Play trả mã %s" % status, 502)
    return data


def account_hash(device_id):
    """Mã ẩn danh của tài khoản để app gắn vào giao dịch (setObfuscatedAccountId) và máy chủ đối chiếu lại."""
    return hashlib.sha256(device_id.encode()).hexdigest()[:32]


# ---------------------------------------------------------------------- ĐĂNG KÝ ĐỊNH KỲ (Google Play subscriptionsv2)
# Trạng thái được hưởng quyền lợi (đối chiếu tài liệu "Subscription lifecycle"): ACTIVE; CANCELED (đã tắt gia hạn nhưng còn hạn);
# IN_GRACE_PERIOD (thanh toán lỗi nhưng Google vẫn cho dùng). Mọi trạng thái khác - ON_HOLD, PAUSED, EXPIRED, PENDING,
# PENDING_PURCHASE_CANCELED và cả TÊN LẠ chưa biết - KHÔNG được hưởng (đóng khi không chắc).
SUB_ENTITLED_STATES = {"SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_CANCELED", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"}
MOCK_SUBS = {}                    # chỉ để thử (BILLING_VERIFY=mock): purchase_token -> JSON y như SubscriptionPurchaseV2 của Google
MOCK_ACKS = []                    # các token đã được "acknowledge" ở chế độ mock
MOCK_ACK_FAIL = {"on": False}     # đặt True để mô phỏng acknowledge lỗi

_RFC3339 = re.compile(r"(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})")


def parse_rfc3339(s):
    """'2026-10-17T09:00:00.123Z' / '...+07:00' -> epoch giây; sai định dạng -> None (chạy được trên Python 3.9)."""
    if not isinstance(s, str):
        return None
    m = _RFC3339.fullmatch(s.strip())
    if not m:
        return None
    tz = "+00:00" if m.group(3) == "Z" else m.group(3)
    try:
        return datetime.datetime.strptime(m.group(1) + "T" + m.group(2) + tz, "%Y-%m-%dT%H:%M:%S%z").timestamp()
    except ValueError:
        return None


def parse_subscription(cfg, info, now=None):
    """Chuẩn hóa SubscriptionPurchaseV2 của Google. Chỉ xét line item thuộc gói app bán (SUBSCRIPTION_PRODUCTS); có nhiều thì lấy hạn muộn nhất."""
    now = time.time() if now is None else now
    state = str(info.get("subscriptionState", ""))
    best = None
    for li in info.get("lineItems") or []:
        if not isinstance(li, dict) or li.get("productId") not in cfg.subscription_products:
            continue
        exp = parse_rfc3339(li.get("expiryTime"))
        if best is None or (exp or 0) > (best[1] or 0):
            best = (li["productId"], exp)
    product_id, expiry = best if best else (None, None)
    ids = info.get("externalAccountIdentifiers") or {}
    return {
        "state": state, "product_id": product_id, "expiry": expiry or 0.0,
        "entitled": bool(product_id and state in SUB_ENTITLED_STATES and expiry is not None and expiry > now),
        "order_id": str(info.get("latestOrderId", "")),
        "owner": ids.get("obfuscatedExternalAccountId") if isinstance(ids, dict) else None,
        "ack_pending": info.get("acknowledgementState") == "ACKNOWLEDGEMENT_STATE_PENDING",
        "linked": info.get("linkedPurchaseToken") or None,
        "test": bool(info.get("testPurchase")),
    }


def verify_subscription(cfg, purchase_token):
    """GET purchases.subscriptionsv2.get (chỉ cần token, không cần mã gói). Lỗi -> BillingError."""
    if cfg.billing_mode == "mock":
        info = MOCK_SUBS.get(purchase_token)
        if info is None:
            raise BillingError("giao dịch không hợp lệ", 400)
        return json.loads(json.dumps(info))
    if cfg.billing_mode != "play" or not cfg.play_package:
        raise BillingError("thanh toán chưa được bật trên máy chủ", 503)
    url = ("https://androidpublisher.googleapis.com/androidpublisher/v3/applications/%s/purchases/subscriptionsv2/tokens/%s"
           % tuple(urllib.parse.quote(x, safe="") for x in (cfg.play_package, purchase_token)))
    status, data = http_json(url, headers={"Authorization": "Bearer " + play_access_token(cfg), "Accept": "application/json"})
    if status in (400, 404, 410):
        raise BillingError("giao dịch không hợp lệ", 400)
    if status != 200:
        raise BillingError("Google Play trả mã %s" % status, 502)
    return data


def acknowledge_subscription(cfg, product_id, purchase_token):
    """POST purchases.subscriptions.acknowledge. Không acknowledge trong 3 ngày thì Google hoàn tiền và thu hồi đăng ký."""
    if cfg.billing_mode == "mock":
        if MOCK_ACK_FAIL["on"]:
            raise BillingError("acknowledge lỗi (mô phỏng)", 502)
        MOCK_ACKS.append(purchase_token)
        return
    url = ("https://androidpublisher.googleapis.com/androidpublisher/v3/applications/%s/purchases/subscriptions/%s/tokens/%s:acknowledge"
           % tuple(urllib.parse.quote(x, safe="") for x in (cfg.play_package, product_id, purchase_token)))
    status, _ = http_json(url, "POST", {"Authorization": "Bearer " + play_access_token(cfg), "Content-Type": "application/json"}, b"{}")
    if status != 200:
        raise BillingError("acknowledge lỗi mã %s" % status, 502)


def sync_subscription(cfg, store, device_id, token, expect_product=None, require_entitled=True):
    """Hỏi Google trạng thái MỚI NHẤT của một đăng ký rồi ghi vào CSDL (dùng cho cả app báo mua lẫn RTDN).
    Trả về dict {granted, credits, product_id, state, expiry, entitled, ack}; lỗi -> BillingError (status = mã HTTP phù hợp)."""
    th = hashlib.sha256(token.encode()).hexdigest()
    ps = parse_subscription(cfg, verify_subscription(cfg, token))
    if ps["product_id"] is None:
        raise BillingError("giao dịch không thuộc gói đăng ký nào của ứng dụng", 400)
    if expect_product and ps["product_id"] != expect_product:
        raise BillingError("giao dịch không phải gói này", 400)
    if ps["state"] == "SUBSCRIPTION_STATE_PENDING":
        raise BillingError("giao dịch đang chờ thanh toán, thử lại sau", 409)
    if ps["owner"] and ps["owner"] != account_hash(device_id):
        raise BillingError("giao dịch thuộc tài khoản khác", 403)
    if require_entitled and not ps["entitled"]:
        raise BillingError("đăng ký không còn hiệu lực (%s)" % (ps["state"].replace("SUBSCRIPTION_STATE_", "").lower() or "không rõ"), 400)
    linked = hashlib.sha256(ps["linked"].encode()).hexdigest() if ps["linked"] else None
    credits = int(cfg.subscription_products[ps["product_id"]].get("credits", 0))
    res, why = store.apply_subscription(device_id, th, token, ps["product_id"], ps["state"], ps["entitled"], ps["expiry"],
                                        ps["order_id"], ps["ack_pending"], credits, linked)
    if res is None:
        raise BillingError(why, 409 if "khác" in why else 404)
    ack = "ok"
    if ps["ack_pending"]:
        if cfg.sub_ack == "server":
            try:
                acknowledge_subscription(cfg, ps["product_id"], token)
                store.set_ack_pending(th, False)
            except Exception:
                ack = "pending"      # giữ ack_pending=1: lần đồng bộ sau (RTDN / app mở lại) sẽ thử lại
        else:
            ack = "client"
    res.update({"product_id": ps["product_id"], "state": ps["state"].replace("SUBSCRIPTION_STATE_", "").lower(),
                "expiry": int(ps["expiry"]), "entitled": ps["entitled"], "ack": ack})
    return res


DEFAULT_PERF = {
    "low": {"maxSide": "1536", "previewHi": "768", "previewLo": "448", "threads": "3"},
    "mid": {"maxSide": "2048", "previewHi": "1024", "previewLo": "576", "threads": "4"},
    "high": {"maxSide": "2560", "previewHi": "1280", "previewLo": "640", "threads": "4"},
}


BYOK_MESSAGE = ("bản dùng thử miễn phí không dùng khóa AI của máy chủ: hãy nhập khóa AI của bạn trong Cài đặt (mục Tạo ảnh) "
                "hoặc dùng model chạy trên máy")


def server_ai_off(cfg):
    """True khi máy chủ KHÔNG dùng khóa AI của chủ app: dùng thử miễn phí mà chủ app không tự nguyện trả tiền (OPEN_BETA=1, BETA_OWNER_PAYS=0)."""
    return bool(cfg.open_beta and not cfg.beta_owner_pays)


def routing_for(cfg, tier, app, plan="free"):
    """Cấu hình định tuyến máy chủ muốn client dùng. Sửa ROUTING_FILE (hoặc hàm này) để đổi model theo hạng máy/phiên bản app."""
    if cfg.routing_file and os.path.exists(cfg.routing_file):
        with open(cfg.routing_file, encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {
            "version": 7,
            "perf": DEFAULT_PERF,
            "tasks": {
                "understand_prompt": {"providers": [
                    {"id": "gemma", "kind": "gemma_mediapipe", "needs": ["file:llm.task"], "minRamMb": 4000},
                    {"id": "rules", "kind": "rules", "needs": []}]},
                "segment": {"providers": [
                    {"id": "isnet", "kind": "isnet_onnx", "needs": ["file:segmenter_hq.onnx"], "minRamMb": 4000},
                    {"id": "u2net", "kind": "u2net_onnx", "needs": ["file:segmenter.onnx"]}]},
                "segment_portrait": {"providers": [
                    {"id": "modnet", "kind": "modnet_onnx", "needs": ["file:segmenter_portrait.onnx"]}]},
                "face_landmarks": {"providers": [
                    {"id": "mediapipe_face", "kind": "mp_face_landmarker", "needs": ["file:face_landmarker.task"]}]},
                "hair_segment": {"providers": [
                    {"id": "mediapipe_hair", "kind": "mp_hair_segmenter", "needs": ["file:hair_segmenter.tflite"]}]},
                "person_detect": {"providers": [
                    {"id": "mediapipe_person", "kind": "mp_person_detector", "needs": ["file:efficientdet_lite0.tflite"]}]},
                "depth_estimate": {"providers": [
                    {"id": "depth_adaptive", "kind": "depth_onnx", "needs": ["file:depth.onnx"], "params": {"edge": "518", "budget_ms": "3000"}}]},
                "inpaint_remove": {"providers": [
                    {"id": "patchmatch_fast", "kind": "patchmatch_fill", "needs": [], "params": {"max_difficulty": "0.30"}},
                    {"id": "lama", "kind": "lama_onnx", "needs": ["file:lama.onnx"], "minRamMb": 6000},
                    {"id": "migan", "kind": "migan_onnx", "needs": ["file:migan.onnx"]},
                    {"id": "lama_lowram", "kind": "lama_onnx", "needs": ["file:lama.onnx"]},
                    {"id": "patchmatch", "kind": "patchmatch_fill", "needs": []},
                    {"id": "classic", "kind": "classic_fill", "needs": []}]},
                "upscale": {"providers": [{"id": "esrgan", "kind": "esrgan_onnx", "needs": ["file:esrgan.onnx"]}]},
                "generative_fill": {"providers": [
                    {"id": "proxy", "kind": "proxy_cloud", "needs": ["token:proxy", "net"]},
                    {"id": "sd_local_klein", "kind": "sdcpp_local", "needs": ["bin:sdserver", "file:sd_klein"], "minRamMb": 8000,
                     "params": {"slot": "sd_klein", "api": "sdcpp_edit", "size": "512", "steps_edit": "4", "cfg_edit": "1.0",
                                "vae_tiling": "true",
                                "cmd": "{bin} --diffusion-model {model} --llm {extra_dir}/llm.gguf --vae {extra_dir}/vae.safetensors --listen-ip 127.0.0.1 --listen-port {port} -t {threads}"}},
                    {"id": "sd_local", "kind": "sdcpp_local", "needs": ["bin:sdserver", "file:sd_inpaint"], "minRamMb": 6000,
                     "params": {"size": "512", "steps": "6", "steps_full": "20", "cfg": "1.0", "cfg_full": "7.0",
                                "strength": "1.0", "lora": "lcm.safetensors", "lora_mult": "1.0", "mask_invert": "false"}}]},
            },
        }
    if server_ai_off(cfg):
        # Chủ app không trả tiền AI: đừng bảo app thử máy chủ (sẽ bị từ chối); chỉ còn nhà cung cấp trên máy / khóa của chính người dùng
        for t in data.get("tasks", {}).values():
            t["providers"] = [p for p in t.get("providers", []) if p.get("kind") != "proxy_cloud"]
    data["server_hint"] = {"tier": tier, "app": app, "plan": plan}
    return data


def call_gemini(cfg, image_b64, mask_b64, prompt):
    instruction = (
        "You are a precise photo editor. The first image is the photo. The second image is a mask: the WHITE area is the only "
        "region you may change; every pixel in the BLACK area must stay exactly as it is. Task for the white area: %s. "
        "If the task is to remove something, fill the white area with a natural continuation of the surrounding background. "
        "If it is to add or replace something, make it photorealistic and match the photo's lighting, perspective, shadows, "
        "colors and grain. Return the edited photo with the same framing and aspect ratio as the first image." % prompt)
    body = {
        "contents": [{"role": "user", "parts": [
            {"text": instruction},
            {"inlineData": {"mimeType": "image/png", "data": image_b64}},
            {"inlineData": {"mimeType": "image/png", "data": mask_b64}}]}],
        "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]},
    }
    url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % cfg.gemini_model
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": cfg.gemini_key})
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            resp = json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError("upstream %d: %s" % (e.code, e.read()[:200].decode("utf-8", "replace")))
    for cand in resp.get("candidates", []):
        for part in cand.get("content", {}).get("parts", []):
            d = part.get("inlineData") or part.get("inline_data")
            if d and d.get("data"):
                return d["data"]
    raise RuntimeError("upstream không trả ảnh")


PLAN_OPS_SIGNED = {"brightness", "contrast", "saturation", "warmth", "clarity", "hue",
                   "highlights", "vibrance", "tint", "dehaze", "texture"}
PLAN_OPS_UNIT = {"shadows", "sharpen", "blur", "skin_smooth", "vignette", "sepia", "cinematic", "auto_enhance", "grain", "denoise", "freq_sep",
                 "posterize", "pixelate", "emboss", "sketch", "glow", "chroma", "matte", "duotone", "colorize", "bg_blur", "sky_replace", "sky_relight", "dust", "hair_volume"}
PLAN_SKY_PRESETS = {"blue", "sunset", "dusk", "overcast", "night"}


def canon_split_tone(arg):
    """Bản Python của SplitTone.canonical (Kotlin): "hueBóng,satBóng,hueSáng,satSáng[,balance]" -> chuỗi chuẩn hóa hoặc None."""
    if not isinstance(arg, str):
        return None
    try:
        v = [float(x) for x in arg.split(",")]
    except ValueError:
        return None
    if len(v) < 4 or any(x != x for x in v):
        return None
    hs, ss, hh, sh = v[0] % 360.0, max(0.0, min(1.0, v[1])), v[2] % 360.0, max(0.0, min(1.0, v[3]))
    bal = max(-1.0, min(1.0, v[4])) if len(v) > 4 else 0.0
    if ss < 0.005 and sh < 0.005:
        return None
    return "%.1f,%.3f,%.1f,%.3f,%.3f" % (hs, ss, hh, sh, bal)


def canon_outpaint(arg):
    """Bản Python của Outpaint.canonical (Kotlin): chuẩn hóa yêu cầu mở rộng ảnh, None nếu không hợp lệ / không mở gì."""
    if not isinstance(arg, str) or not arg.strip():
        return None
    kv = {}
    for part in arg.split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            kv[k.strip().lower()] = v.strip()

    def num(k):
        try:
            x = float(kv.get(k, ""))
        except ValueError:
            return None
        return None if x != x else x           # NaN

    ratio = num("ratio")
    if "ratio" in kv:
        if ratio is None or not (0.2 <= ratio <= 5.0):
            return None
        a = (kv.get("a", "c") or "c")[:1].lower()
        return "ratio=%.4f,a=%s" % (ratio, a if a in "lrtbc" else "c")
    sides = [max(0.0, min(1.0, num(k) or 0.0)) for k in ("l", "r", "t", "b")]
    if not any(x > 0 for x in sides):
        return None
    return "l=%.3f,r=%.3f,t=%.3f,b=%.3f" % tuple(sides)
PLAN_SCOPES = {"skin", "eyes", "teeth", "dark_circles", "sky", "subject", "background", "face_light", "face_shadow", "hair"}
PLAN_MAX_OPS = 12
HEX7 = __import__("re").compile(r"^#[0-9A-Fa-f]{6}$")


def sanitize_plan(raw):
    """Nhận văn bản do mô hình trả về, giữ lại CHỈ các phép chỉnh hợp lệ (tên, khoảng giá trị, màu, vùng). Trả về dict {"ops": [...]}."""
    a, b = raw.find("{"), raw.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("không có JSON")
    data = json.loads(raw[a:b + 1])
    out = []
    for o in (data.get("ops") or [])[:PLAN_MAX_OPS]:
        if not isinstance(o, dict):
            continue
        name = str(o.get("op", "")).strip().lower()
        try:
            v = float(o.get("value", 1.0))
        except (TypeError, ValueError):
            continue
        if name in PLAN_OPS_SIGNED:
            v = max(-1.0, min(1.0, v))
        elif name in PLAN_OPS_UNIT:
            v = max(0.0, min(1.0, v))
        elif name == "grayscale":
            v = 1.0
        elif name in ("outpaint", "split_tone"):
            v = 1.0
        else:
            continue
        item = {"op": name, "value": round(v, 3)}
        arg = o.get("arg")
        if name == "colorize":
            if not (isinstance(arg, str) and HEX7.match(arg.strip())):
                continue
            item["arg"] = arg.strip().upper()
        elif name == "outpaint":
            c = canon_outpaint(arg)
            if c is None:
                continue
            item["arg"] = c
        elif name == "split_tone":
            c = canon_split_tone(arg)
            if c is None:
                continue
            item["arg"] = c
        elif name == "sky_replace":
            a = arg.strip().lower() if isinstance(arg, str) else ""
            item["arg"] = a if a in PLAN_SKY_PRESETS else "blue"
        elif name == "duotone" and isinstance(arg, str):
            parts = [p.strip() for p in arg.split(",")]
            if len(parts) == 2 and all(HEX7.match(p) for p in parts):
                item["arg"] = ",".join(p.upper() for p in parts)
        scope = str(o.get("scope", "") or "").strip().lower()
        if scope:
            if scope not in PLAN_SCOPES:
                continue
            item["scope"] = scope
        out.append(item)
    if not out:
        raise ValueError("không có phép chỉnh hợp lệ")
    return {"ops": out}


PLAN_INSTRUCTION = (
    "You are a professional photo retoucher. LOOK at the photo (exposure, white balance, contrast, skin, sky, subject, background), "
    "then convert the user's request into a JSON edit plan. Reply with ONLY JSON: {\"ops\":[{\"op\":\"<name>\",\"value\":<number>,\"arg\":\"<optional>\",\"scope\":\"<optional>\"}]}. "
    "Order the ops like a retoucher: global tone first, then color, then local work. Allowed ops: brightness, contrast, saturation, warmth, clarity, hue, "
    "highlights (negative recovers blown highlights), vibrance, tint (positive = magenta, negative = green), dehaze (positive removes haze), texture "
    "(value -1..1); shadows, sharpen, blur, skin_smooth, vignette, sepia, cinematic, auto_enhance, grain, denoise, freq_sep, posterize, pixelate, emboss, "
    "sketch, glow, chroma, matte, bg_blur (value 0..1); grayscale (value 1); colorize (value 0..1, arg = target hex colour like #6B4423, use with scope hair); hair_volume (value 0..1, makes the hair fuller/thicker; use it for requests like fuller hair, more hair volume); "
    "dust (value 0..1, removes dust, scratches and thin stray hairs), duotone (value 0..1, arg = \"#shadowhex,#highlighthex\"); sky_replace (value 0..1, arg = one of blue, sunset, dusk, overcast, night; replaces the sky), sky_relight (value 0..1; warms/darkens the foreground to match the new sky, use together with sky_replace); outpaint (value 1, extends the canvas and fills the new area; arg = \"l=0.2,r=0.2,t=0,b=0\" adds 20%% on a side, or \"ratio=1.78\" extends to that width/height ratio, optional \",a=r\" anchors it to one side); split_tone (value 1, tints shadows and highlights with different colours; arg = \"shadowHue,shadowSat,highlightHue,highlightSat\", hue 0-360 degrees, sat 0..1, e.g. teal shadows and orange highlights = \"185,0.5,28,0.5\"). Optional scope limits an op to a region: skin, eyes, teeth, dark_circles, sky, subject, background, "
    "face_light, face_shadow, hair. Use small values (0.1-0.4) for natural results. At most %d ops. User request: {request}" % PLAN_MAX_OPS)
# Chỗ trống {request} được thay bằng .replace (KHÔNG dùng % lần thứ hai): chuỗi sau lần định dạng đầu còn dấu % thật (\"20% on a side\") nên
# `PLAN_INSTRUCTION % prompt` ném TypeError ở MỌI lần gọi Gemini thật — lỗi có từ trước R30, test cũ dùng upstream giả nên không bắt được.


PLAN_REFERENCE_NOTE = ("The SECOND image is a STYLE REFERENCE only - never edit or describe it. Infer its colour grading (warmth, tint, saturation, split-toning), "
                       "contrast, brightness and mood, then choose ops that move the FIRST image toward that look while keeping it natural. "
                       "The user's text request still takes priority where they conflict.")


def call_gemini_plan(cfg, image_b64, prompt, mime="image/jpeg", ref=None):
    parts = [{"text": PLAN_INSTRUCTION.replace("{request}", prompt)}, {"inlineData": {"mimeType": mime, "data": image_b64}}]
    if ref is not None:
        parts += [{"text": PLAN_REFERENCE_NOTE}, {"inlineData": {"mimeType": ref[1], "data": ref[0]}}]
    body = {
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.2},
    }
    url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % cfg.gemini_plan_model
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": cfg.gemini_key})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            resp = json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError("upstream %d: %s" % (e.code, e.read()[:200].decode("utf-8", "replace")))
    for cand in resp.get("candidates", []):
        for part in cand.get("content", {}).get("parts", []):
            if part.get("text"):
                return part["text"]
    raise RuntimeError("upstream không trả kế hoạch")


def run_plan_upstream(cfg, image_b64, prompt, mime, ref=None):
    cfg.last_plan_had_reference = ref is not None
    if cfg.upstream == "mock":
        return '{"ops":[{"op":"brightness","value":0.2},{"op":"colorize","value":0.8,"arg":"#6b4423","scope":"hair"}]}'
    if cfg.upstream == "fail":
        raise RuntimeError("mô phỏng lỗi nhà cung cấp")
    if not cfg.gemini_key:
        raise RuntimeError("máy chủ chưa cấu hình GEMINI_API_KEY")
    return call_gemini_plan(cfg, image_b64, prompt, mime, ref)


def _multipart(fields, files):
    """Dựng multipart/form-data bằng thư viện chuẩn. files: [(tên_trường, tên_tệp, content_type, bytes)]."""
    boundary = "----psb" + os.urandom(12).hex()
    out = bytearray()
    for k, v in fields.items():
        out += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (boundary, k, v)).encode()
    for name, fname, ctype, data in files:
        out += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n" % (boundary, name, fname, ctype)).encode()
        out += data + b"\r\n"
    out += ("--%s--\r\n" % boundary).encode()
    return bytes(out), "multipart/form-data; boundary=" + boundary


def call_openai_edits(cfg, image_b64, mask_alpha_b64, prompt):
    """POST {EDITS_URL} theo giao thức OpenAI images/edits. Mặt nạ (nếu có) là PNG RGBA: vùng TRONG SUỐT = vùng được sửa."""
    fields = {"prompt": prompt, "n": "1", "response_format": "b64_json"}
    if cfg.edits_model:
        fields["model"] = cfg.edits_model
    files = [(cfg.edits_image_field, "image.png", "image/png", base64.b64decode(image_b64))]
    if mask_alpha_b64:
        files.append(("mask", "mask.png", "image/png", base64.b64decode(mask_alpha_b64)))
    body, ctype = _multipart(fields, files)
    headers = {"Content-Type": ctype}
    if cfg.edits_key:
        headers["Authorization"] = "Bearer " + cfg.edits_key
    req = urllib.request.Request(cfg.edits_url, data=body, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            resp = json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError("edits %d: %s" % (e.code, e.read()[:200].decode("utf-8", "replace")))
    data = resp.get("data") or []
    if data and data[0].get("b64_json"):
        return data[0]["b64_json"]
    raise RuntimeError("edits không trả b64_json")


def run_upstream(cfg, image_b64, mask_b64, prompt, mask_alpha_b64=None):
    if cfg.upstream == "mock":
        return image_b64
    if cfg.upstream == "openai_edits":
        if not cfg.edits_url:
            raise RuntimeError("máy chủ chưa cấu hình EDITS_URL")
        return call_openai_edits(cfg, image_b64, mask_alpha_b64, prompt)
    if cfg.upstream == "fail":
        raise RuntimeError("mô phỏng lỗi nhà cung cấp")
    if not cfg.gemini_key:
        raise RuntimeError("máy chủ chưa cấu hình GEMINI_API_KEY")
    return call_gemini(cfg, image_b64, mask_b64, prompt)


JOIN_FAIL_LIMIT = 10          # số lần nhập sai mã mời tối đa mỗi giờ cho một thiết bị (mã 10 ký tự ≈ 50 bit; giới hạn để chặn dò mã)
JOIN_FAIL_WINDOW = 3600


class RateLimiter:
    """Giới hạn tần suất kiểu CỬA SỔ TRƯỢT trong bộ nhớ: mỗi khóa tối đa `limit` lượt trong `window` giây (limit <= 0 = tắt). An toàn đa luồng.
    Có dọn khóa cũ định kỳ và trần số khóa (chống kẻ tạo vô số IP / thiết bị làm phình bộ nhớ). Trạng thái chỉ sống trong tiến trình này."""
    MAX_KEYS = 50_000
    GC_EVERY = 300

    def __init__(self, clock=time.time):
        self._clock = clock
        self._hits = {}              # khóa -> (deque thời điểm, cửa sổ giây)
        self._lock = threading.Lock()
        self._last_gc = 0.0

    def hit(self, key, limit, window):
        """Ghi MỘT lượt cho `key`. Trả (True, 0) nếu còn trong hạn mức (lượt được tính), ngược lại (False, số giây nên chờ) và KHÔNG tính lượt."""
        if limit <= 0:
            return True, 0
        now = self._clock()
        with self._lock:
            self._gc(now)
            q, _w = self._hits.get(key, (None, window))
            if q is None:
                q = collections.deque()
                self._hits[key] = (q, window)
            cutoff = now - window
            while q and q[0] <= cutoff:
                q.popleft()
            if len(q) >= limit:
                return False, max(1, int(q[0] + window - now) + 1)
            q.append(now)
            return True, 0

    def _gc(self, now):
        if now - self._last_gc < self.GC_EVERY and len(self._hits) < self.MAX_KEYS:
            return
        self._last_gc = now
        for k in [k for k, (q, w) in self._hits.items() if not q or q[-1] <= now - w]:
            del self._hits[k]
        if len(self._hits) >= self.MAX_KEYS:      # vẫn quá nhiều khóa còn hiệu lực: bỏ nửa cũ nhất
            for k, _ in sorted(self._hits.items(), key=lambda kv: kv[1][0][-1])[: len(self._hits) // 2]:
                del self._hits[k]


def make_handler(cfg, store):
    limiter = RateLimiter(lambda: cfg.clock())
    join_fail = {}               # device_id -> [số lần sai, thời điểm bắt đầu cửa sổ]
    join_lock = threading.Lock()

    def beta_block(dev):
        """Chế độ dùng thử miễn phí: None nếu còn được dùng, ngược lại (code, thông báo). Trần theo thiết bị xét trước (báo đúng người dùng nhiều),
        rồi trần toàn máy chủ (0 = không giới hạn). Chỉ có hiệu lực khi OPEN_BETA=1."""
        if not cfg.open_beta:
            return None
        if cfg.beta_daily_limit > 0 and store.usage_today(dev) >= cfg.beta_daily_limit:
            return "beta_daily_limit", "đã đạt giới hạn dùng thử trong ngày, mai dùng tiếp nhé"
        if cfg.beta_global_limit > 0 and store.usage_total_today() >= cfg.beta_global_limit:
            return "beta_global_limit", "máy chủ dùng thử đã hết lượt hôm nay, mai thử lại nhé"
        return None

    def join_blocked(dev):
        with join_lock:
            f = join_fail.get(dev)
            if f is None:
                return False
            if time.time() - f[1] > JOIN_FAIL_WINDOW:
                del join_fail[dev]
                return False
            return f[0] >= JOIN_FAIL_LIMIT

    def join_note_fail(dev):
        with join_lock:
            now = time.time()
            f = join_fail.get(dev)
            if f is None or now - f[1] > JOIN_FAIL_WINDOW:
                join_fail[dev] = [1, now]
            else:
                f[0] += 1

    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            if os.environ.get("QUIET") != "1":
                sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

        def _send(self, code, obj, headers=None):
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            for hk, hv in (headers or {}).items():
                self.send_header(hk, hv)
            self.end_headers()
            self.wfile.write(data)

        def _client_ip(self):
            """Địa chỉ khách để tính giới hạn. Mặc định là địa chỉ kết nối trực tiếp; chỉ khi TRUST_PROXY_HOPS = N > 0 mới đọc X-Forwarded-For và lấy mục thứ N
            tính từ PHẢI (mục do reverse proxy tin cậy của bạn thêm vào; phần bên trái do khách tự khai nên giả được)."""
            ip = self.client_address[0]
            hops = cfg.trust_proxy_hops
            if hops > 0:
                parts = [x.strip() for x in (self.headers.get("X-Forwarded-For") or "").split(",") if x.strip()]
                if len(parts) >= hops:
                    ip = parts[-hops]
            return ip

        def _rate_block(self, key, limit, window):
            """True nếu `key` đã quá hạn mức (đã gửi 429 kèm Retry-After); False nếu được đi tiếp."""
            allowed, wait = limiter.hit(key, limit, window)
            if allowed:
                return False
            self._send(429, {"error": "quá nhiều yêu cầu, thử lại sau %d giây" % wait, "code": "rate_limited", "retry_after": wait},
                       {"Retry-After": str(wait)})
            return True

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise ValueError("body quá lớn")
            return json.loads(self.rfile.read(n) or b"{}")

        def _auth(self):
            h = self.headers.get("Authorization", "")
            return check_token(cfg, h[7:].strip() if h.startswith("Bearer ") else "")

        def _integrity_blocked(self, dev):
            """True (và đã trả 403) nếu máy chủ BẮT BUỘC chứng thực Play Integrity mà thiết bị này chưa chứng thực / đã hết hạn."""
            if cfg.integrity_mode == "off" or not cfg.integrity_enforce or cfg.attestations.is_attested(dev):
                return False
            self._send(403, {"error": "cần chứng thực thiết bị (Play Integrity) trước", "code": "integrity_required"})
            return True

        def _team_dev(self):
            """Mã thiết bị nếu gói Team đã bật và đã đăng nhập; ngược lại đã gửi lỗi và trả None."""
            if not cfg.team_enabled:
                self._send(503, {"error": "gói Team chưa được bật trên máy chủ"})
                return None
            dev = self._auth()
            if dev is None:
                self._send(401, {"error": "chưa đăng nhập"})
            return dev

        def do_GET(self):
            u = urlparse(self.path)
            if u.path == "/healthz":
                return self._send(200, {"ok": True})
            dev = self._auth()
            if dev is None:
                return self._send(401, {"error": "chưa đăng nhập"})
            if u.path == "/v1/integrity/challenge":
                if cfg.integrity_mode == "off":
                    return self._send(503, {"error": "Play Integrity chưa được bật trên máy chủ"})
                return self._send(200, {"challenge": cfg.attestations.new_challenge(dev), "ttl": integrity.CHALLENGE_TTL})
            if u.path == "/v1/credits":
                return self._send(200, {"credits": store.credits(dev)})
            if u.path == "/v1/account":
                until = store.plan_until(dev)
                pro = until > time.time()
                team = store.team_info(dev)
                return self._send(200, {"plan": "pro" if pro else "free", "plan_until": int(until) if pro else 0, "credits": store.credits(dev),
                                        "credits_personal": store.personal_credits(dev), "credits_team": team["credits"] if team else 0,
                                        "limits": {"high_quality": pro or cfg.free_high_quality or cfg.open_beta, "watermark": not (pro or cfg.open_beta)},
                                        "open_beta": cfg.open_beta, "server_ai": not server_ai_off(cfg), "usage_today": store.usage_today(dev),
                                        "daily_limit": cfg.beta_daily_limit if (cfg.open_beta and cfg.beta_owner_pays) else 0,
                                        "subscription": store.subscription_info(dev), "team": team})
            if u.path == "/v1/team":
                if not cfg.team_enabled:
                    return self._send(503, {"error": "gói Team chưa được bật trên máy chủ"})
                return self._send(200, {"team": store.team_info(dev, members=True)})
            if u.path == "/v1/routing":
                q = parse_qs(u.query)
                return self._send(200, routing_for(cfg, (q.get("tier") or ["mid"])[0], (q.get("app") or [""])[0],
                                                   "pro" if (cfg.open_beta or store.is_pro(dev)) else "free"))
            self._send(404, {"error": "không có đường dẫn này"})

        def do_POST(self):
            u = urlparse(self.path)
            try:
                body = self._body()
            except Exception as e:
                return self._send(400, {"error": str(e)})
            # R30: giới hạn tần suất TRƯỚC mọi việc tốn tiền / tài nguyên. RTDN do Google Pub/Sub gọi (khóa nằm trong URL) nên không tính theo thiết bị;
            # đường quản trị dùng ADMIN_KEY chứ không phải Bearer nên cũng không bị tính.
            if u.path == "/v1/register":
                if self._rate_block("reg:" + self._client_ip(), cfg.rate_register_ip_hour, 3600):
                    return
            elif u.path != "/v1/billing/rtdn":
                dev0 = self._auth()
                if dev0 is not None and self._rate_block("dev:" + dev0, cfg.rate_device_minute, 60):
                    return
            if u.path == "/v1/register":
                did = str(body.get("device_id", "")).strip()
                if not (8 <= len(did) <= 64) or "." in did:
                    return self._send(400, {"error": "device_id không hợp lệ"})
                credits = store.register(did, cfg.free_credits)
                return self._send(200, {"token": make_token(cfg, did), "credits": credits})
            if u.path == "/v1/admin/grant":
                if not cfg.admin_key or not hmac.compare_digest(self.headers.get("X-Admin-Key", ""), cfg.admin_key):
                    return self._send(403, {"error": "sai khóa quản trị"})
                left = store.grant(str(body.get("device_id", "")), int(body.get("credits", 0)), str(body.get("reason", "admin")))
                if left is None:
                    return self._send(404, {"error": "không có tài khoản"})
                return self._send(200, {"credits": left})
            if u.path == "/v1/admin/team":
                if not cfg.admin_key or not hmac.compare_digest(self.headers.get("X-Admin-Key", ""), cfg.admin_key):
                    return self._send(403, {"error": "sai khóa quản trị"})
                action = str(body.get("action", ""))
                try:
                    if action == "list":
                        return self._send(200, {"teams": store.team_admin_list()})
                    if action == "create":
                        tid, code = store.team_create(str(body.get("admin_device", "")), body.get("name", ""), body.get("seats", cfg.team_default_seats),
                                                      body.get("credits", 0), body.get("plan_days", 0))
                        return self._send(200, {"team_id": tid, "invite_code": code})
                    if action == "update":
                        return self._send(200, {"team": store.team_admin_update(str(body.get("team_id", "")), body.get("credits", 0), body.get("plan_days", 0),
                                                                                body.get("seats"))})
                    if action == "disband":
                        return self._send(200, {"returned_credits": store.team_admin_disband(str(body.get("team_id", "")))})
                    if action == "set_admin":
                        store.team_admin_set_admin(str(body.get("team_id", "")), str(body.get("device_id", "")))
                        return self._send(200, {"ok": True})
                    if action == "remove":
                        store.team_admin_remove(str(body.get("team_id", "")), str(body.get("device_id", "")))
                        return self._send(200, {"ok": True})
                except TeamError as e:
                    return self._send(e.status, {"error": str(e)})
                except (TypeError, ValueError):
                    return self._send(400, {"error": "tham số không hợp lệ"})
                return self._send(400, {"error": "action phải là create | update | disband | list | set_admin | remove"})
            if u.path.startswith("/v1/team/"):
                dev = self._team_dev()
                if dev is None:
                    return
                op = u.path[len("/v1/team/"):]
                try:
                    if op == "create":
                        if not cfg.team_self_serve:
                            return self._send(403, {"error": "nhóm do quản trị hệ thống cấp theo hợp đồng - liên hệ bán hàng", "code": "team_contract_only"})
                        tid, code = store.team_create(dev, body.get("name", ""), cfg.team_default_seats)
                        return self._send(200, {"team": store.team_info(dev, members=True), "invite_code": code})
                    if op == "join":
                        if join_blocked(dev):
                            return self._send(429, {"error": "nhập sai mã mời quá nhiều lần, thử lại sau"})
                        try:
                            store.team_join(dev, body.get("code", ""))
                        except TeamError as e:
                            if e.status == 403:
                                join_note_fail(dev)
                            raise
                        return self._send(200, {"team": store.team_info(dev)})
                    if op == "leave":
                        store.team_leave(dev)
                        return self._send(200, {"ok": True})
                    if op == "remove":
                        store.team_remove(dev, body.get("member_id", ""))
                        return self._send(200, {"team": store.team_info(dev, members=True)})
                    if op == "transfer":
                        store.team_transfer(dev, body.get("member_id", ""))
                        return self._send(200, {"team": store.team_info(dev, members=True)})
                    if op == "invite":
                        return self._send(200, {"invite_code": store.team_rotate_invite(dev)})
                    if op == "fund":
                        store.team_fund(dev, body.get("credits", 0))
                        t = store.team_info(dev, members=True)
                        return self._send(200, {"team": t, "credits": store.credits(dev)})
                except TeamError as e:
                    return self._send(e.status, {"error": str(e)})
                except (TypeError, ValueError):
                    return self._send(400, {"error": "tham số không hợp lệ"})
                return self._send(404, {"error": "không có đường dẫn này"})
            if u.path == "/v1/billing/rtdn":
                # Pub/Sub push: {"message":{"data":"<base64 DeveloperNotification>","messageId":...},"subscription":...}.
                # Thông báo CHỈ là tín hiệu: luôn gọi lại Google lấy trạng thái thật, nên kẻ giả mạo không cấp được gì.
                if not cfg.rtdn_secret:
                    return self._send(503, {"error": "RTDN chưa được bật (đặt RTDN_SECRET)"})
                if not hmac.compare_digest((parse_qs(u.query).get("key") or [""])[0], cfg.rtdn_secret):
                    return self._send(403, {"error": "sai khóa"})
                try:
                    note = json.loads(base64.b64decode((body.get("message") or {}).get("data", ""), validate=True))
                    if not isinstance(note, dict):
                        raise ValueError("không phải đối tượng")
                except Exception:
                    return self._send(200, {"ignored": "định dạng không hợp lệ"})    # 200 để Pub/Sub không gửi lại vô hạn
                if cfg.play_package and note.get("packageName") not in (None, "", cfg.play_package):
                    return self._send(200, {"ignored": "khác ứng dụng"})
                sn = note.get("subscriptionNotification")
                if not isinstance(sn, dict) or not isinstance(sn.get("purchaseToken"), str) or not sn["purchaseToken"] or len(sn["purchaseToken"]) > 2000:
                    return self._send(200, {"ignored": "không phải thông báo đăng ký"})
                token = sn["purchaseToken"]
                row = store.subscription_by_hash(hashlib.sha256(token.encode()).hexdigest())
                if row is None:
                    return self._send(200, {"ignored": "chưa biết token này (app sẽ báo qua /v1/billing/subscribe)"})
                try:
                    sync_subscription(cfg, store, row["device_id"], token, require_entitled=False)
                except BillingError as e:
                    if e.status >= 500:
                        return self._send(502, {"error": str(e)})      # lỗi tạm thời -> Pub/Sub gửi lại
                    return self._send(200, {"ignored": str(e)})
                except Exception as e:
                    return self._send(502, {"error": "không đồng bộ được: %s" % e})
                return self._send(200, {"ok": True})
            if u.path == "/v1/billing/subscribe":
                dev = self._auth()
                if dev is None:
                    return self._send(401, {"error": "chưa đăng nhập"})
                if self._integrity_blocked(dev):
                    return
                if cfg.billing_mode == "off":
                    return self._send(503, {"error": "thanh toán chưa được bật trên máy chủ"})
                product_id = str(body.get("product_id", "")).strip()
                token = str(body.get("purchase_token", "")).strip()
                if product_id not in cfg.subscription_products or not token or len(token) > 2000:
                    return self._send(400, {"error": "gói đăng ký hoặc mã giao dịch không hợp lệ"})
                try:
                    r = sync_subscription(cfg, store, dev, token, expect_product=product_id)
                except BillingError as e:
                    return self._send(e.status, {"error": str(e)})
                except Exception as e:
                    return self._send(502, {"error": "không xác minh được giao dịch: %s" % e})
                until = store.plan_until(dev)
                return self._send(200, {"credits": r["credits"], "granted": r["granted"], "plan": "pro" if until > time.time() else "free",
                                        "plan_until": int(until) if until > time.time() else 0, "ack": r["ack"],
                                        "subscription": {"product_id": r["product_id"], "state": r["state"], "expiry": r["expiry"]}})
            if u.path == "/v1/integrity/verify":
                dev = self._auth()
                if dev is None:
                    return self._send(401, {"error": "chưa đăng nhập"})
                if cfg.integrity_mode == "off":
                    return self._send(503, {"error": "Play Integrity chưa được bật trên máy chủ"})
                token = str(body.get("integrity_token", "")).strip()
                challenge = str(body.get("challenge", "")).strip()
                if not token or len(token) > 20000:
                    return self._send(400, {"error": "thiếu hoặc quá dài integrity_token"})
                if not cfg.attestations.take_challenge(dev, challenge):
                    return self._send(400, {"error": "thử thách không hợp lệ / đã dùng / hết hạn — xin thử thách mới", "code": "bad_challenge"})
                try:
                    payload = decode_integrity_token(cfg, token)
                except BillingError as e:
                    return self._send(e.status, {"error": str(e)})
                ok, why = integrity.evaluate_verdict(payload, cfg.play_package, integrity.expected_request_hash(dev, challenge),
                                                     int(cfg.clock() * 1000), cfg.integrity_window_ms, cfg.integrity_require_licensed, cfg.integrity_certs,
                                                     cfg.integrity_allow_testing)
                if not ok:
                    return self._send(403, {"error": "chứng thực thất bại: " + why, "code": "integrity_failed"})
                cfg.attestations.mark(dev, cfg.integrity_ttl)
                return self._send(200, {"ok": True, "ttl": cfg.integrity_ttl})
            if u.path == "/v1/billing/redeem":
                dev = self._auth()
                if dev is None:
                    return self._send(401, {"error": "chưa đăng nhập"})
                if self._integrity_blocked(dev):
                    return
                if cfg.billing_mode == "off":
                    return self._send(503, {"error": "thanh toán chưa được bật trên máy chủ"})
                product_id = str(body.get("product_id", "")).strip()
                token = str(body.get("purchase_token", "")).strip()
                team_prod = cfg.team_products.get(product_id) if cfg.team_enabled else None   # gói Team: cộng vào QUỸ NHÓM, không vào ví cá nhân
                plan = cfg.plan_products.get(product_id)
                credits = cfg.credit_packs.get(product_id)
                if credits is None and plan is not None:
                    credits = int(plan.get("credits", 0))
                if team_prod is not None:
                    credits = int(team_prod.get("credits", 0))
                if credits is None or not token or len(token) > 2000:
                    return self._send(400, {"error": "sản phẩm hoặc mã giao dịch không hợp lệ"})
                if team_prod is not None and not store.is_team_admin(dev):
                    return self._send(403, {"error": "gói Team chỉ quản trị viên nhóm mua được (tạo hoặc nhận quyền quản trị nhóm trước)", "code": "team_admin_required"})
                try:
                    info = verify_purchase(cfg, product_id, token)
                except BillingError as e:
                    return self._send(e.status, {"error": str(e)})
                except Exception as e:
                    return self._send(502, {"error": "không xác minh được giao dịch: %s" % e})
                state = info.get("purchaseState")
                if state == 2:
                    return self._send(409, {"error": "giao dịch đang chờ thanh toán, thử lại sau"})
                if state != 0:
                    return self._send(400, {"error": "giao dịch không ở trạng thái đã mua"})
                owner = info.get("obfuscatedExternalAccountId")
                if owner and owner != account_hash(dev):
                    return self._send(403, {"error": "giao dịch thuộc tài khoản khác"})
                if team_prod is not None:
                    try:
                        store.team_redeem(dev, hashlib.sha256(token.encode()).hexdigest(), str(info.get("orderId", "")), product_id, int(credits),
                                          int(team_prod.get("days", 0)), int(team_prod.get("seats", 0)))
                    except TeamError as e:
                        return self._send(e.status, {"error": "giao dịch " + str(e) if str(e) == "đã đổi" else str(e)})
                    return self._send(200, {"credits": store.credits(dev), "granted": int(credits), "plan": "pro" if store.is_pro(dev) else "free",
                                            "plan_until": int(store.plan_until(dev)), "team": store.team_info(dev)})
                left, why = store.redeem(dev, hashlib.sha256(token.encode()).hexdigest(), str(info.get("orderId", "")), product_id, int(credits),
                                          int(plan.get("days", 0)) if plan is not None else 0)
                if left is None:
                    return self._send(409 if why == "đã đổi" else 404, {"error": "giao dịch " + why if why == "đã đổi" else why})
                return self._send(200, {"credits": left, "granted": int(credits),
                                        "plan": "pro" if store.is_pro(dev) else "free", "plan_until": int(store.plan_until(dev))})
            if u.path == "/v1/generative_fill":
                dev = self._auth()
                if dev is None:
                    return self._send(401, {"error": "chưa đăng nhập"})
                if self._integrity_blocked(dev):
                    return
                try:
                    image_b64 = body["image"]
                    mask_b64 = body["mask"]
                    mask_alpha_b64 = body.get("mask_alpha")
                    if mask_alpha_b64 and base64.b64decode(mask_alpha_b64, validate=True)[:8] != PNG_SIG:
                        raise ValueError("mask_alpha phải là PNG")
                    prompt = str(body.get("prompt", "")).strip()[:500]
                    if base64.b64decode(image_b64, validate=True)[:8] != PNG_SIG or base64.b64decode(mask_b64, validate=True)[:8] != PNG_SIG:
                        raise ValueError("ảnh/mặt nạ phải là PNG")
                    if not prompt:
                        raise ValueError("thiếu prompt")
                except Exception as e:
                    return self._send(400, {"error": "yêu cầu không hợp lệ: %s" % e})
                if server_ai_off(cfg):
                    return self._send(403, {"error": BYOK_MESSAGE, "code": "byok_required", "credits": store.credits(dev)})
                high = body.get("quality") == "high"
                if high and not (cfg.free_high_quality or cfg.open_beta or store.is_pro(dev)):
                    return self._send(403, {"error": "chất lượng cao cần gói Pro", "code": "pro_required", "credits": store.credits(dev)})
                blocked = beta_block(dev)
                if blocked:
                    return self._send(429, {"error": blocked[1], "code": blocked[0], "credits": store.credits(dev)})
                cost = 0 if cfg.open_beta else (cfg.cost_high if high else cfg.cost_fast)
                left, receipt = store.charge_ex(dev, cost, "generative_fill")
                if left is None:
                    return self._send(402, {"error": "không đủ credits", "credits": store.credits(dev)})
                try:
                    out = run_upstream(cfg, image_b64, mask_b64, prompt, mask_alpha_b64)
                except Exception as e:
                    left = store.refund(dev, receipt, "refund_upstream_error")
                    return self._send(502, {"error": "nhà cung cấp AI lỗi: %s" % e, "credits": left})
                if cfg.open_beta:
                    store.usage_note(dev)
                return self._send(200, {"image": out, "credits": left})
            if u.path == "/v1/edit_plan":
                # Agent AI: mô hình ĐA PHƯƠNG THỨC nhìn ảnh thu nhỏ + yêu cầu -> kế hoạch chỉnh JSON (client áp bằng bộ lọc cục bộ, không phá hủy)
                dev = self._auth()
                if dev is None:
                    return self._send(401, {"error": "chưa đăng nhập"})
                if self._integrity_blocked(dev):
                    return
                try:
                    image_b64 = body["image"]
                    raw = base64.b64decode(image_b64, validate=True)
                    mime = "image/png" if raw[:8] == PNG_SIG else "image/jpeg" if raw[:3] == b"\xff\xd8\xff" else None
                    if mime is None or len(raw) > 2_500_000:
                        raise ValueError("ảnh phải là PNG/JPEG nhỏ (≤ 2.5 MB, nên thu về ≤ 768 px)")
                    prompt = str(body.get("prompt", "")).strip().replace('"', "'")[:300]
                    if not prompt:
                        raise ValueError("thiếu prompt")
                    ref = None                                    # R30: ảnh MẪU phong cách (tùy chọn) để agent suy ra gu màu / tông rồi chỉnh ảnh chính theo
                    if body.get("reference"):
                        ref_b64 = body["reference"]
                        ref_raw = base64.b64decode(ref_b64, validate=True)
                        ref_mime = "image/png" if ref_raw[:8] == PNG_SIG else "image/jpeg" if ref_raw[:3] == b"\xff\xd8\xff" else None
                        if ref_mime is None or len(ref_raw) > 1_500_000:
                            raise ValueError("ảnh mẫu phải là PNG/JPEG nhỏ (≤ 1.5 MB, nên thu về ≤ 512 px)")
                        ref = (ref_b64, ref_mime)
                except Exception as e:
                    return self._send(400, {"error": "yêu cầu không hợp lệ: %s" % e})
                if server_ai_off(cfg):
                    return self._send(403, {"error": BYOK_MESSAGE, "code": "byok_required", "credits": store.credits(dev)})
                blocked = beta_block(dev)
                if blocked:
                    return self._send(429, {"error": blocked[1], "code": blocked[0], "credits": store.credits(dev)})
                cost = 0 if (cfg.open_beta or (cfg.pro_plan_free and store.is_pro(dev))) else cfg.cost_plan
                left, receipt = store.charge_ex(dev, cost, "edit_plan") if cost else (store.credits(dev), None)
                if left is None:
                    return self._send(402, {"error": "không đủ credits", "credits": store.credits(dev)})
                try:
                    plan = sanitize_plan(run_plan_upstream(cfg, image_b64, prompt, mime, ref))
                except Exception as e:
                    if cost:
                        left = store.refund(dev, receipt, "refund_plan_error")
                    return self._send(502, {"error": "Agent AI lỗi: %s" % e, "credits": left})
                if cfg.open_beta:
                    store.usage_note(dev)
                return self._send(200, {"plan": plan, "credits": left})
            self._send(404, {"error": "không có đường dẫn này"})

    return H


def serve(cfg=None):
    cfg = cfg or Config()
    store = Store(cfg.db_path)
    srv = ThreadingHTTPServer(("0.0.0.0", cfg.port), make_handler(cfg, store))
    srv.store = store      # để test/giám sát truy cập trực tiếp
    return srv


if __name__ == "__main__":
    s = serve()
    print("AI Photo Studio backend lắng nghe cổng %d" % s.server_address[1])
    s.serve_forever()
