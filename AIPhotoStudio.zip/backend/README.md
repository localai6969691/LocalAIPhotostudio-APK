# Máy chủ trung gian (tham chiếu)

Chạy thử (không cần cài thêm gì, chỉ cần Python 3.9+):

```bash
UPSTREAM=mock FREE_CREDITS=5 ADMIN_KEY=doi-khoa-nay SECRET=chuoi-bi-mat-dai python3 backend/server.py   # thử, không gọi AI thật
GEMINI_API_KEY=... SECRET=... ADMIN_KEY=... python3 backend/server.py                                   # dùng Gemini thật
python3 backend/test_server.py                                                                          # chạy bộ kiểm thử (54 ca)
```

Trong app: Cài đặt → "Máy chủ của bạn" → nhập địa chỉ → **Đăng ký** (nhận credits tặng) → **Đồng bộ cấu hình**
(máy chủ trả thứ tự model + kích thước ảnh theo hạng thiết bị: sửa `ROUTING_FILE` là đổi cho mọi người dùng, không cần phát hành lại app).

## Thanh toán Google Play → credits (`POST /v1/billing/redeem`)

Máy chủ **tự xác minh** giao dịch với Google rồi mới cộng credits; mỗi `purchase_token` chỉ đổi được **một lần**.

```bash
# thử (không gọi Google): token bắt đầu bằng "ok-" hợp lệ, "pending-" chờ thanh toán
BILLING_VERIFY=mock UPSTREAM=mock SECRET=... ADMIN_KEY=... python3 backend/server.py

# thật
BILLING_VERIFY=play PLAY_PACKAGE_NAME=com.aiphoto.studio PLAY_SERVICE_ACCOUNT_FILE=/etc/aiphoto/sa.json \
CREDIT_PACKS='{"credits_20": 20, "credits_100": 110}' SECRET=... python3 backend/server.py
```

- Cần: tài khoản dịch vụ Google Cloud được cấp quyền trong Play Console (*Setup → API access*), và lệnh `openssl` trên máy chủ (dùng để ký JWT RS256; Python chuẩn không có RSA).
- Yêu cầu: `POST /v1/billing/redeem` (Bearer) `{"product_id": "credits_20", "purchase_token": "..."}` → `{"credits": <số dư>, "granted": 20}`.
  Mã lỗi: 401 chưa đăng nhập · 400 sản phẩm/giao dịch không hợp lệ hoặc đã hủy · 403 giao dịch của tài khoản khác · 409 đã đổi rồi / đang chờ thanh toán · 502 Google lỗi · 503 chưa bật.
- App nên đặt `setObfuscatedAccountId(sha256(device_id)[:32])` khi `launchBillingFlow` để máy chủ đối chiếu chủ giao dịch (`server.account_hash`), rồi **`consumeAsync`** sau khi nhận 200.
- Đã test với Google giả lập (URL, Bearer, ánh xạ lỗi) và chữ ký JWT kiểm chứng bằng khóa công khai; **chưa gọi Google thật**.

**Chưa có (bắt buộc trước khi bán thật):** HTTPS (đặt sau Caddy/Nginx), giới hạn tần suất, xác thực người dùng thật
(Play Integrity / tài khoản), chuyển SQLite sang cơ sở dữ liệu có sao lưu, theo dõi chi phí nhà cung cấp AI,
và thử client Play Billing của app trên máy thật (xem PROJECT_STATUS.md, P1-2 và P1-11).

## Gói Free / Pro (R10)

- **Pro** = đã mua một sản phẩm trong `PLAN_PRODUCTS` (mua một lần, tiêu thụ được, "N ngày"): `/v1/billing/redeem` cộng `credits` tặng kèm **và** gia hạn `plan_until` (cộng dồn nếu còn hạn). Mặc định:
  `PLAN_PRODUCTS='{"pro_30d": {"days": 30, "credits": 50}, "pro_365d": {"days": 365, "credits": 600}}'`. Đăng ký tự gia hạn: xem mục "Đăng ký định kỳ (R14)" bên dưới.
- `GET /v1/account` (Bearer) → `{"plan": "free"|"pro", "plan_until": <giây Unix>, "credits": n, "limits": {"high_quality": bool, "watermark": bool}}`. App dùng để đóng/không đóng watermark.
- Gói **Free không dùng được chất lượng cao**: `POST /v1/generative_fill` với `quality=high` → **403** `{"code": "pro_required"}` (không trừ credits). Đặt `FREE_HIGH_QUALITY=1` để cho phép.
- `GET /v1/routing` trả thêm `server_hint.plan` (`free`/`pro`) và task `hair_segment`.

## Agent AI nhìn ảnh (`POST /v1/edit_plan`)

`{"image": <PNG/JPEG base64, ≤ 2.5 MB, nên thu về ≤ 768 px>, "prompt": "...", "reference": <PNG/JPEG base64, ≤ 1.5 MB, nên ≤ 512 px; TÙY CHỌN>}` (Bearer) → `{"plan": {"ops": [{"op","value","arg"?,"scope"?}]}, "credits": n}`.
Gemini đa phương thức nhìn ảnh và lập kế hoạch; **máy chủ lọc lại** (`sanitize_plan`: chỉ nhận tên phép đã biết, kẹp giá trị, màu `#RRGGBB`, vùng hợp lệ, tối đa 12 phép) trước khi trả về, nên client không tin dữ liệu thô của mô hình.
Chi phí: `COST_PLAN` credits (mặc định 1), **gói Pro miễn phí** (`PRO_PLAN_FREE=1`); lỗi nhà cung cấp → 502 và **hoàn credits**. Mô hình: `GEMINI_PLAN_MODEL` (mặc định `gemini-3.5-flash-lite`, chưa thử với khóa thật);
**`reference` (R30)** là ảnh MẪU phong cách: Gemini nhận thêm ảnh này (sau ghi chú "chỉ để tham chiếu, đừng chỉnh/mô tả nó") và chọn phép chỉnh để đưa ảnh chính về gu màu / tương phản / tông của ảnh mẫu; lời nhắn người dùng vẫn được ưu tiên khi mâu thuẫn. Không có `reference` thì yêu cầu gửi đi y như cũ; ảnh mẫu sai (không base64 / không phải PNG-JPEG / > 1.5 MB) → 400 và KHÔNG trừ credits. Cùng chi phí.
**Sửa lỗi có từ trước (R30):** chuỗi hướng dẫn gửi Gemini bị định dạng `%` hai lần nên mọi lần gọi Gemini THẬT đều ném `TypeError` (người dùng thấy "Agent AI lỗi", credits được hoàn); test cũ dùng upstream giả nên không bắt được. Nay dùng chỗ trống `{request}` thay bằng `.replace`, có test chống tái phát (kể cả prompt chứa `%`, `%s`, `%d`, `{request}`).
lưu ý `generateContent` được Google ghi là API "legacy" (Interactions API là mặc định từ 06/2026) — xem PROJECT_STATUS.md 8.7. Ảnh thu nhỏ được gửi tới Google → nêu trong chính sách quyền riêng tư.

## Giới hạn tần suất (R30)

Cửa sổ trượt trong bộ nhớ (`RateLimiter`), chạy TRƯỚC mọi việc tốn tiền / tài nguyên. Quá hạn mức → `429` `{"code":"rate_limited","retry_after":giây}` + tiêu đề `Retry-After`; lệnh bị chặn không trừ credits và không tính vào cửa sổ.

| Biến môi trường | Mặc định | Ý nghĩa |
|---|---|---|
| `RATE_REGISTER_PER_IP_HOUR` | `60` | số lần `POST /v1/register` tối đa mỗi IP mỗi giờ; `0` = tắt |
| `RATE_PER_DEVICE_MINUTE` | `60` | số lệnh `POST` tối đa mỗi thiết bị đã đăng nhập mỗi phút (tính cả lệnh sau đó bị 400); `0` = tắt. GET, `/healthz`, `/v1/billing/rtdn` (Google gọi) và đường quản trị (`ADMIN_KEY`) không bị tính |
| `TRUST_PROXY_HOPS` | `0` | `0` = dùng địa chỉ kết nối trực tiếp, **bỏ qua** `X-Forwarded-For` (khách tự khai được). Đặt `N` khi có N reverse proxy tin cậy phía trước: lấy mục thứ N tính từ PHẢI của `X-Forwarded-For` (mục do proxy của bạn thêm) |

- **Giới hạn thật của cơ chế này (nói thẳng):** trạng thái nằm trong bộ nhớ của MỘT tiến trình — khởi động lại là mất, chạy nhiều bản sao thì hạn mức nhân lên; kẻ có nhiều IP vẫn đăng ký được nhiều thiết bị (`/v1/register` chưa có xác thực người dùng thật — Play Integrity / tài khoản — nên đây chỉ làm chậm lạm dụng, KHÔNG chặn). Số mặc định (60) là con số mình chọn, chưa đo trên lưu lượng thật (CGNAT nhà mạng có thể dồn nhiều người vào một IP): chỉnh sau khi có số liệu.
- Kiểm thử: `test_rate.py` (đồng hồ giả, không ngủ thật; đột biến bỏ giới hạn / tin nhầm `X-Forwarded-For` / tính lượt bị chặn đều bị bắt).

## Đăng ký định kỳ (R14): `subscriptionsv2` + RTDN

- **Mua trong app → báo máy chủ:** `POST /v1/billing/subscribe` (Bearer) `{"product_id": "pro_monthly", "purchase_token": "..."}` → máy chủ gọi
  `purchases.subscriptionsv2.get` (chỉ cần token), kiểm: gói khớp `SUBSCRIPTION_PRODUCTS`, chủ sở hữu (`obfuscatedExternalAccountId` = `account_hash(device_id)`),
  token chỉ thuộc **một** tài khoản. Trả `{credits, granted, plan, plan_until, ack, subscription}`. **Gọi lại nhiều lần an toàn** (cũng là cách khôi phục).
- **Ai được hưởng Pro:** chỉ `ACTIVE`, `CANCELED` (đã tắt gia hạn nhưng còn hạn) và `IN_GRACE_PERIOD` **và** `expiryTime` còn ở tương lai. `ON_HOLD`, `PAUSED`, `EXPIRED`, `PENDING`, `PENDING_PURCHASE_CANCELED` và mọi tên lạ → Free (đóng khi không chắc).
- **Hạn Pro** = muộn nhất của (gói "N ngày" mua một lần) và (các đăng ký đang hưởng). **Credits** của mỗi kỳ (`SUBSCRIPTION_PRODUCTS`, mặc định `pro_monthly` 50, `pro_yearly` 600)
  cộng **đúng một lần cho mỗi `latestOrderId`** — gia hạn = đơn mới = cộng lại; thông báo trùng không cộng thêm. Đổi gói (`linkedPurchaseToken`) → đăng ký cũ bị thay thế.
- **Acknowledge** (bắt buộc trong 3 ngày, không thì Google hoàn tiền): mặc định máy chủ tự gọi `purchases.subscriptions.acknowledge`; lỗi thì giữ `ack_pending` và tự thử lại ở lần đồng bộ sau.
  Đặt `SUBSCRIPTION_ACK=client` nếu muốn app tự `acknowledgePurchase` (máy chủ báo `ack: "client"`).
- **RTDN:** tạo topic Cloud Pub/Sub, bật *Real-time developer notifications* trong Play Console, tạo **push subscription** tới
  `https://<host>/v1/billing/rtdn?key=<RTDN_SECRET>` (đặt biến `RTDN_SECRET`; trống = tắt, trả 503). Thông báo **chỉ là tín hiệu**: máy chủ luôn gọi lại Google lấy trạng thái thật,
  nên thông báo giả không cấp được gì. Thông báo hỏng / khác app / token chưa biết → 200 bỏ qua (tránh Pub/Sub gửi lại vô hạn); Google lỗi tạm thời → 502 (để gửi lại).
- **Biến môi trường:** `SUBSCRIPTION_PRODUCTS` (JSON `{"mã_gói": {"credits": n}}`), `RTDN_SECRET`, `SUBSCRIPTION_ACK` (`server`|`client`). Mã gói phải khớp `BILLING_SUBSCRIPTIONS` trong app (`tools/static_check.py` kiểm).
- **Đã test:** 64 ca mới (vòng đời đầy đủ, bảo mật, idempotent, nhiều nguồn Pro, acknowledge lỗi/thử lại, RTDN hỏng/giả mạo, chế độ `play` với Google giả lập kiểm URL/Bearer/`:acknowledge`). **Chưa gọi Google thật**; các giả định chưa xác minh: PROJECT_STATUS.md 8.8, A84–A87.
- **Hạn chế:** tài khoản theo `device_id` nên cài lại app = mất liên kết đăng ký (mã ẩn danh lệch) — cần đăng nhập người dùng thật. Purchase token được lưu trong SQLite (cần để gọi lại Google) — bảo vệ/sao lưu CSDL.

## Dùng thử miễn phí cho tester (R23) — `OPEN_BETA`, mặc định BẬT; chủ app KHÔNG trả tiền AI

Giai đoạn đầu mọi tài khoản dùng đủ tính năng miễn phí để bắt lỗi; module tính phí (credits, Pro, Team, Google Play) **vẫn nguyên**, chỉ bị bỏ qua. **Miễn phí cho người dùng không có nghĩa chủ app trả tiền AI**: mặc định máy chủ không dùng khóa AI của chủ.

| Biến môi trường | Mặc định | Ý nghĩa |
|---|---|---|
| `OPEN_BETA` | `1` | `1`: không trừ credits (kể cả 0 credits), `/v1/account` báo `limits.watermark=false`/`high_quality=true` (nhưng `plan` vẫn `free`). `0`: hành vi tính phí cũ nguyên vẹn |
| `BETA_OWNER_PAYS` | `0` | `0`: máy chủ **KHÔNG** gọi nhà cung cấp AI bằng khóa của chủ — `POST /v1/generative_fill` và `/v1/edit_plan` trả `403 byok_required` (kiểm TRƯỚC khi trừ/gọi gì), `GET /v1/routing` bỏ `proxy_cloud` khỏi mọi tác vụ (kể cả `ROUTING_FILE`), `/v1/account` báo `server_ai=false`; tester dùng khóa của chính họ (app gọi thẳng nhà cung cấp) hoặc model trên máy. `1`: chủ app tự nguyện trả → AI máy chủ hoạt động, miễn credits, có hai trần dưới đây |
| `BETA_DAILY_LIMIT` | `100` | (chỉ khi `BETA_OWNER_PAYS=1`) số lượt AI thành công mỗi thiết bị trong 24 giờ trượt; `0` = không giới hạn. Trần MỀM (ai cũng đăng ký được mã thiết bị mới) |
| `BETA_GLOBAL_LIMIT` | `2000` | (chỉ khi `BETA_OWNER_PAYS=1`) tổng lượt AI thành công của TOÀN máy chủ trong 24 giờ trượt; `0` = không giới hạn. Chốt chặn ngân sách |

- Chạm trần → `429` với `code` = `beta_daily_limit` hoặc `beta_global_limit` và câu tiếng Việt trong `error`; trần thiết bị xét trước. Chỉ chặn `generative_fill`/`edit_plan`; xem tài khoản/định tuyến/credits vẫn được.
- Chỉ lượt THÀNH CÔNG được tính (lỗi nhà cung cấp → 502, không mất lượt). Bảng `usage(device_id, ts)` tự dọn dòng quá 2 ngày.
- `GET /v1/account` thêm `open_beta`, `server_ai`, `usage_today`, `daily_limit` (0 = không giới hạn / không áp dụng).
- Bật lại tính phí: `OPEN_BETA=0` **và** đổi `Monetization.ENABLED=true` trong app (hai công tắc phải đi cùng nhau).
- Kiểm thử: `python3 test_server.py` (gồm `test_beta.py`; có ca đặt `UPSTREAM=fail` để chứng minh chế độ mặc định KHÔNG gọi nhà cung cấp).

## Gói Team / Enterprise (R22) — cơ chế cấu hình được, mặc định TẮT

**Không có con số kinh doanh nào trong mã.** Giá bán nằm ở Play Console / hợp đồng; số ghế, credits, thời hạn là tham số cấu hình hoặc lệnh vận hành. Bật bằng `TEAM_ENABLED=1`.

- **Nhóm** = một quỹ credits dùng chung + một hạn Pro + số ghế. Thành viên vẫn có ví cá nhân; khi trừ credits, **quỹ nhóm bị trừ trước, phần thiếu lấy ở ví cá nhân** (nguyên tử; không đủ cả hai thì không trừ gì). Hoàn tiền khi nhà cung cấp AI lỗi **trả đúng nguồn đã trừ**. Thành viên **hưởng Pro của nhóm** (watermark, chất lượng cao, Agent AI miễn phí…) và mất khi rời nhóm.
- **Hai cách có nhóm:** (1) **bán theo hợp đồng (Enterprise)** — vận hành gọi `POST /v1/admin/team` `{"action":"create","admin_device","name","seats","credits","plan_days"}` (X-Admin-Key) → trả `team_id` + **mã mời**; (2) **tự phục vụ** — đặt `TEAM_SELF_SERVE=1` để người dùng tự `POST /v1/team/create` (số ghế = `TEAM_DEFAULT_SEATS`, mặc định 5; nhóm mới chưa có credits/Pro — phải mua gói Team, nạp quỹ hoặc để vận hành cấp).
- **Mua gói Team qua Google Play:** khai `TEAM_PRODUCTS='{"team_30d": {"days": 30, "credits": 300, "seats": 10}}'` (mặc định `{}` = chưa bán). Quản trị viên nhóm gọi `/v1/billing/redeem` như thường: credits vào **quỹ nhóm**, `days` cộng dồn vào hạn Pro của nhóm, `seats` nâng ghế tối thiểu (`MAX`). Mỗi `purchase_token` một lần; người không phải quản trị viên bị từ chối (403 `team_admin_required`) **trước khi** gọi Google. Gói credits cá nhân vẫn vào ví cá nhân.
- **Mã mời:** 10 ký tự (bỏ 0/O/1/I), chỉ hiện **một lần** lúc tạo/đổi; CSDL chỉ lưu **băm**. Gõ không phân biệt hoa thường/dấu gạch. Sai mã quá `JOIN_FAIL_LIMIT` = 10 lần/giờ → 429 (chặn dò mã). Quản trị viên `POST /v1/team/invite` để đổi mã (mã cũ hết hiệu lực).
- **Quyền riêng tư:** quản trị viên thấy thành viên bằng **mã băm ẩn danh** (`account_hash`), không thấy `device_id` thật.
- **Quản trị viên:** `GET /v1/team` (kèm `member_list`), `remove`, `transfer` (chuyển quyền), `invite`, `fund` (chuyển credits cá nhân vào quỹ — một chiều). Quản trị viên chỉ rời được khi là người cuối cùng (= giải thể, quỹ còn lại trả về ví cá nhân của họ).
- **Vận hành** (`/v1/admin/team`): `create`, `update` (`credits` cộng/trừ — không được âm quỹ, `plan_days` cộng dồn, `seats` — không thấp hơn số thành viên), `disband` (trả quỹ cho quản trị viên), `list`, `set_admin` (nhóm mất quản trị viên do cài lại app/mất máy), `remove` (xóa thành viên theo `device_id`).
- `GET /v1/account` thêm `team`, `credits_personal`, `credits_team`; `credits` = **số dùng được** (cá nhân + quỹ). Máy khách cũ bỏ qua các trường lạ.
- **Tắt `TEAM_ENABLED`** chỉ chặn tạo/tham gia/quản trị mới; thành viên hiện có vẫn dùng quỹ và Pro bình thường (muốn dừng hẳn: `disband`).
- **Đã test:** `test_team.py` (81 ca; có đột biến 16 kiểu lỗi cố ý đều bị bắt: đảo thứ tự trừ, hoàn nhầm nguồn, lộ `device_id`, mã mời lưu thô, ghế vượt, bỏ giới hạn dò mã, mua gói Team vào ví cá nhân…), gồm cả đua nhiều luồng trừ quỹ cùng lúc (đúng 10/10, không âm).
- **Hạn chế đã biết (cần quyết định kinh doanh hoặc làm thêm):** tài khoản vẫn theo `device_id` (cài lại app = mất vai trò → dùng `set_admin`/`remove`); chưa có gói Team **đăng ký định kỳ** (chỉ mua một lần + cấp tay); **chưa có hạn mức theo thành viên** (một người có thể dùng hết quỹ); chưa có API báo cáo sử dụng theo thành viên (sổ cái `team_ledger` đã ghi `device_id` từng lần trừ); nạp quỹ là một chiều; chưa có hóa đơn/thuế/hợp đồng; chưa thử với Google Play thật (chỉ chế độ `mock`).

## Chứng thực thiết bị bằng Play Integrity (R32) — mặc định TẮT

Phía máy chủ đã xong và đã test (64 ca, có đột biến); client trong app cũng đã viết (mặc định là bản stub; bật bằng `-PuseIntegrity=true -PintegrityCloudProject=<số dự án Cloud>`), nhưng **chưa chạy với Google thật** — xem PROJECT_STATUS.md P1-2, 8.16, A175–A179.
**Chỉ bật `INTEGRITY_ENFORCE=1` sau khi bản app có client đã phát hành** — nếu không, mọi người dùng sẽ nhận 403 `integrity_required`.

- `INTEGRITY_MODE`: `off` (mặc định) | `mock` (token chính là JSON verdict, chỉ để thử) | `play` (gọi `playintegrity.googleapis.com/v1/<gói>:decodeIntegrityToken`; cần `PLAY_PACKAGE_NAME` + tài khoản dịch vụ trong `INTEGRITY_SERVICE_ACCOUNT_FILE`, trống = dùng `PLAY_SERVICE_ACCOUNT_FILE`).
- `INTEGRITY_ENFORCE=1`: chặn 403 `integrity_required` ở `generative_fill`, `edit_plan`, `billing/redeem`, `billing/subscribe` nếu thiết bị chưa chứng thực (không có tác dụng khi `INTEGRITY_MODE=off`).
- `INTEGRITY_TTL_SECONDS` (mặc định 86400): thiết bị đã chứng thực được tin trong bao lâu. `INTEGRITY_WINDOW_SECONDS` (600): token cũ hơn mức này bị từ chối.
- `INTEGRITY_REQUIRE_LICENSED=1`: bắt buộc `LICENSED` (người cài APK tay sẽ bị từ chối). `INTEGRITY_CERT_SHA256=a,b`: danh sách chứng chỉ ký được phép (sha256 dạng base64url HOẶC hex, có thể kèm dấu hai chấm), trống = không kiểm. `INTEGRITY_ALLOW_TESTING_RESPONSE=1`: chấp nhận phản hồi kiểm thử do Play Console ghi đè cho tài khoản tester (chỉ để QA; mặc định từ chối).
- Luồng: `GET /v1/integrity/challenge` (cần đăng nhập) → app xin token với `requestHash = sha256("<device_id>|<challenge>")` (hex) → `POST /v1/integrity/verify {"integrity_token", "challenge"}` → 200 `{"ok": true, "ttl": …}`. Thử thách dùng MỘT lần, hết hạn sau 5 phút; sai là phải xin lại.
- Chứng thực một lần mỗi `INTEGRITY_TTL_SECONDS` (không chứng thực từng yêu cầu: Google giới hạn hạn mức gọi theo ngày). Sổ chứng thực nằm trong bộ nhớ: khởi động lại máy chủ thì client tự chứng thực lại khi gặp 403.
